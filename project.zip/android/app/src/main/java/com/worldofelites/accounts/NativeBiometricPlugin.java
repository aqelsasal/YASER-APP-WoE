package com.worldofelites.accounts;

import android.content.Intent;
import android.os.Build;
import android.provider.Settings;
import androidx.annotation.NonNull;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.util.concurrent.Executor;

/**
 * Native Android Biometric Authentication Plugin for Capacitor.
 * Directly integrates with Android's native BiometricPrompt API to support:
 * - Ultrasonic in-screen fingerprint scanners (e.g. Samsung Galaxy S21/S22/S23/S24)
 * - Optical and capacitive fingerprint scanners
 * - Face unlock / Biometric sensors
 * - Fallback to security settings if fingerprints need enrollment.
 */
@CapacitorPlugin(name = "NativeBiometric")
public class NativeBiometricPlugin extends Plugin {

    @PluginMethod
    public void isAvailable(PluginCall call) {
        try {
            BiometricManager biometricManager = BiometricManager.from(getContext());
            
            int canAuth = biometricManager.canAuthenticate(
                BiometricManager.Authenticators.BIOMETRIC_STRONG | BiometricManager.Authenticators.BIOMETRIC_WEAK
            );

            JSObject ret = new JSObject();
            switch (canAuth) {
                case BiometricManager.BIOMETRIC_SUCCESS:
                    ret.put("isAvailable", true);
                    ret.put("hasHardware", true);
                    ret.put("isEnrolled", true);
                    ret.put("code", "SUCCESS");
                    ret.put("message", "مستشعر البصمة البيومترية جاهز ومتاح للاستخدام.");
                    break;
                case BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED:
                    ret.put("isAvailable", false);
                    ret.put("hasHardware", true);
                    ret.put("isEnrolled", false);
                    ret.put("code", "NONE_ENROLLED");
                    ret.put("message", "الهاتف يدعم مستشعر البصمة، ولكن لم يتم تسجيل أي بصمة في إعدادات الهاتف بعد. يرجى تسجيل بصمة في إعدادات الهاتف أولاً.");
                    break;
                case BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE:
                    ret.put("isAvailable", false);
                    ret.put("hasHardware", false);
                    ret.put("isEnrolled", false);
                    ret.put("code", "NO_HARDWARE");
                    ret.put("message", "هذا الجهاز لا يحتوي على مستشعر بصمة بيومترية.");
                    break;
                case BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE:
                    ret.put("isAvailable", false);
                    ret.put("hasHardware", true);
                    ret.put("isEnrolled", true);
                    ret.put("code", "HW_UNAVAILABLE");
                    ret.put("message", "مستشعر البصمة غير متاح حالياً، يرجى المحاولة بعد قليل.");
                    break;
                case BiometricManager.BIOMETRIC_ERROR_SECURITY_UPDATE_REQUIRED:
                    ret.put("isAvailable", false);
                    ret.put("hasHardware", true);
                    ret.put("isEnrolled", true);
                    ret.put("code", "SECURITY_UPDATE_REQUIRED");
                    ret.put("message", "يتطلب مستشعر البصمة تحديث أمان للنظام.");
                    break;
                default:
                    ret.put("isAvailable", false);
                    ret.put("hasHardware", false);
                    ret.put("isEnrolled", false);
                    ret.put("code", "UNKNOWN_ERROR");
                    ret.put("message", "تعذر التحقق من حالة مستشعر البصمة.");
                    break;
            }
            call.resolve(ret);
        } catch (Exception e) {
            JSObject errRet = new JSObject();
            errRet.put("isAvailable", false);
            errRet.put("hasHardware", false);
            errRet.put("isEnrolled", false);
            errRet.put("code", "EXCEPTION");
            errRet.put("message", e.getMessage());
            call.resolve(errRet);
        }
    }

    @PluginMethod
    public void openBiometricSettings(PluginCall call) {
        try {
            Intent intent = null;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                intent = new Intent(Settings.ACTION_BIOMETRIC_ENROLL);
                intent.putExtra(
                    Settings.EXTRA_BIOMETRIC_AUTHENTICATORS_ALLOWED,
                    BiometricManager.Authenticators.BIOMETRIC_STRONG
                );
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                intent = new Intent(Settings.ACTION_FINGERPRINT_ENROLL);
            }
            
            if (intent == null || intent.resolveActivity(getContext().getPackageManager()) == null) {
                intent = new Intent(Settings.ACTION_SECURITY_SETTINGS);
            }
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(intent);

            JSObject ret = new JSObject();
            ret.put("success", true);
            call.resolve(ret);
        } catch (Exception e) {
            try {
                Intent fallback = new Intent(Settings.ACTION_SETTINGS);
                fallback.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                getContext().startActivity(fallback);
                JSObject ret = new JSObject();
                ret.put("success", true);
                call.resolve(ret);
            } catch (Exception e2) {
                call.reject("تعذر فتح إعدادات الهاتف: " + e2.getMessage());
            }
        }
    }

    @PluginMethod
    public void authenticate(PluginCall call) {
        String title = call.getString("title", "نظام الأمان والتحقق من الهوية");
        String subtitle = call.getString("subtitle", "المس مستشعر البصمة لفتح قفل التطبيق");
        String description = call.getString("description", "يرجى مسح بصمة إصبعك لتأكيد هويتك ومتابعة استخدام التطبيق بأمان");
        String negativeButtonText = call.getString("negativeButtonText", "إلغاء / استخدام كلمة المرور");

        getActivity().runOnUiThread(() -> {
            try {
                if (!(getActivity() instanceof FragmentActivity)) {
                    call.reject("Activity is not FragmentActivity");
                    return;
                }

                FragmentActivity fragmentActivity = (FragmentActivity) getActivity();
                Executor executor = ContextCompat.getMainExecutor(getContext());

                BiometricPrompt biometricPrompt = new BiometricPrompt(
                    fragmentActivity,
                    executor,
                    new BiometricPrompt.AuthenticationCallback() {
                        @Override
                        public void onAuthenticationError(int errorCode, @NonNull CharSequence errString) {
                            super.onAuthenticationError(errorCode, errString);
                            JSObject ret = new JSObject();
                            ret.put("verified", false);
                            ret.put("errorCode", errorCode);
                            ret.put("error", errString.toString());

                            if (errorCode == BiometricPrompt.ERROR_USER_CANCELED || errorCode == BiometricPrompt.ERROR_NEGATIVE_BUTTON) {
                                ret.put("cancelled", true);
                            } else {
                                ret.put("cancelled", false);
                            }
                            call.resolve(ret);
                        }

                        @Override
                        public void onAuthenticationSucceeded(@NonNull BiometricPrompt.AuthenticationResult result) {
                            super.onAuthenticationSucceeded(result);
                            JSObject ret = new JSObject();
                            ret.put("verified", true);
                            ret.put("cancelled", false);
                            call.resolve(ret);
                        }

                        @Override
                        public void onAuthenticationFailed() {
                            super.onAuthenticationFailed();
                            // Android's native BiometricPrompt automatically prompts user to try again
                        }
                    }
                );

                BiometricPrompt.PromptInfo promptInfo = new BiometricPrompt.PromptInfo.Builder()
                    .setTitle(title)
                    .setSubtitle(subtitle)
                    .setDescription(description)
                    .setNegativeButtonText(negativeButtonText)
                    .setConfirmationRequired(false)
                    .build();

                biometricPrompt.authenticate(promptInfo);
            } catch (Exception e) {
                call.reject("حدث خطأ أثناء تشغيل شاشة التحقق من البصمة: " + e.getMessage());
            }
        });
    }
}
