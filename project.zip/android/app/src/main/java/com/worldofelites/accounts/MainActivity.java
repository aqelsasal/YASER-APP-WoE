package com.worldofelites.accounts;

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    public MainActivity() {
        super();
        this.initialPlugins.add(ContactPickerPlugin.class);
        this.initialPlugins.add(NativeBiometricPlugin.class);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(ContactPickerPlugin.class);
        registerPlugin(NativeBiometricPlugin.class);
        super.onCreate(savedInstanceState);
    }
}
