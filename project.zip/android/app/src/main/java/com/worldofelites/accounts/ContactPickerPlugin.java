package com.worldofelites.accounts;

import android.Manifest;
import android.app.Activity;
import android.content.ContentUris;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.ContactsContract;
import androidx.activity.result.ActivityResult;
import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * Native Android Contact Picker Plugin for Capacitor.
 * Directly launches Android's native Phone Contacts screen to select a contact,
 * requests READ_CONTACTS permission if needed, and retrieves ALL phone numbers
 * associated with that selected contact.
 */
@CapacitorPlugin(
    name = "ContactPicker",
    permissions = {
        @Permission(
            alias = "contacts",
            strings = { Manifest.permission.READ_CONTACTS }
        )
    }
)
public class ContactPickerPlugin extends Plugin {

    @PluginMethod
    public void pickContact(PluginCall call) {
        if (getPermissionState("contacts") != PermissionState.GRANTED) {
            requestPermissionForAlias("contacts", call, "contactsPermCallback");
        } else {
            launchContactPickerIntent(call);
        }
    }

    @PermissionCallback
    public void contactsPermCallback(PluginCall call) {
        if (call == null) return;
        // Even if permission was denied by user, launch picker because
        // ACTION_PICK provides its own user-driven security clearance on Android
        launchContactPickerIntent(call);
    }

    private void launchContactPickerIntent(PluginCall call) {
        try {
            // Priority 1: CommonDataKinds.Phone.CONTENT_URI (Directly opens phone contacts list)
            Intent intent = new Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI);
            startActivityForResult(call, intent, "pickContactResult");
        } catch (Exception e) {
            try {
                // Fallback: ContactsContract.Contacts.CONTENT_URI
                Intent fallbackIntent = new Intent(Intent.ACTION_PICK, ContactsContract.Contacts.CONTENT_URI);
                startActivityForResult(call, fallbackIntent, "pickContactResult");
            } catch (Exception e2) {
                call.reject("تعذر فتح جهات اتصال الهاتف: " + e2.getMessage());
            }
        }
    }

    @ActivityCallback
    public void pickContactResult(PluginCall call, ActivityResult result) {
        if (call == null) return;

        if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
            Uri contactUri = result.getData().getData();
            if (contactUri == null) {
                JSObject ret = new JSObject();
                ret.put("cancelled", true);
                ret.put("phoneNumber", "");
                ret.put("phoneNumbers", new JSArray());
                ret.put("name", "");
                call.resolve(ret);
                return;
            }

            String contactId = null;
            String lookupKey = null;
            String displayName = "";
            Set<String> phoneSet = new LinkedHashSet<>();

            // 1. Inspect the picked URI directly (Extracts number, name, contactId, lookupKey)
            Cursor cursor = null;
            try {
                cursor = getContext().getContentResolver().query(contactUri, null, null, null, null);
                if (cursor != null && cursor.moveToFirst()) {
                    // Try getting Display Name
                    int nameCol = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME);
                    if (nameCol != -1) {
                        displayName = cursor.getString(nameCol);
                    }
                    if (displayName == null || displayName.isEmpty()) {
                        int altNameCol = cursor.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME);
                        if (altNameCol != -1) {
                            displayName = cursor.getString(altNameCol);
                        }
                    }

                    // Try getting direct Phone Number if picked from Phone.CONTENT_URI
                    int numCol = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER);
                    if (numCol != -1) {
                        String rawNum = cursor.getString(numCol);
                        if (rawNum != null && !rawNum.trim().isEmpty()) {
                            phoneSet.add(rawNum.trim());
                        }
                    }

                    // Try getting Contact ID
                    int phoneContactIdCol = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.CONTACT_ID);
                    if (phoneContactIdCol != -1) {
                        contactId = cursor.getString(phoneContactIdCol);
                    }
                    if (contactId == null || contactId.isEmpty()) {
                        int idCol = cursor.getColumnIndex(ContactsContract.Contacts._ID);
                        if (idCol != -1) {
                            contactId = cursor.getString(idCol);
                        }
                    }

                    // Try getting Lookup Key
                    int lookupCol = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.LOOKUP_KEY);
                    if (lookupCol != -1) {
                        lookupKey = cursor.getString(lookupCol);
                    }
                    if (lookupKey == null || lookupKey.isEmpty()) {
                        int altLookupCol = cursor.getColumnIndex(ContactsContract.Contacts.LOOKUP_KEY);
                        if (altLookupCol != -1) {
                            lookupKey = cursor.getString(altLookupCol);
                        }
                    }
                }
            } catch (Exception e) {
                // Ignore and proceed with subsequent queries
            } finally {
                if (cursor != null) cursor.close();
            }

            // 2. Query contact Data directory (Standard Android child URI for this contact)
            Cursor dataCursor = null;
            try {
                Uri dataUri = null;
                if (contactId != null && !contactId.isEmpty()) {
                    try {
                        long cId = Long.parseLong(contactId);
                        dataUri = Uri.withAppendedPath(
                            ContentUris.withAppendedId(ContactsContract.Contacts.CONTENT_URI, cId),
                            ContactsContract.Contacts.Data.CONTENT_DIRECTORY
                        );
                    } catch (Exception ignore) {}
                }
                if (dataUri == null) {
                    dataUri = Uri.withAppendedPath(contactUri, ContactsContract.Contacts.Data.CONTENT_DIRECTORY);
                }

                dataCursor = getContext().getContentResolver().query(dataUri, null, null, null, null);
                if (dataCursor != null) {
                    int mimeTypeCol = dataCursor.getColumnIndex(ContactsContract.Data.MIMETYPE);
                    int dataNumCol = dataCursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER);
                    int dataNameCol = dataCursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME);

                    while (dataCursor.moveToNext()) {
                        if (mimeTypeCol != -1) {
                            String mime = dataCursor.getString(mimeTypeCol);
                            if (ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE.equals(mime)) {
                                if (dataNumCol != -1) {
                                    String n = dataCursor.getString(dataNumCol);
                                    if (n != null && !n.trim().isEmpty()) {
                                        phoneSet.add(n.trim());
                                    }
                                }
                                if ((displayName == null || displayName.isEmpty()) && dataNameCol != -1) {
                                    displayName = dataCursor.getString(dataNameCol);
                                }
                            }
                        }
                    }
                }
            } catch (Exception e) {
                // Continue to global phone query
            } finally {
                if (dataCursor != null) dataCursor.close();
            }

            // 3. Query ALL phone numbers associated with this contactId or lookupKey via Phone.CONTENT_URI
            if ((contactId != null && !contactId.isEmpty()) || (lookupKey != null && !lookupKey.isEmpty())) {
                Cursor phoneCursor = null;
                try {
                    String[] projection = new String[]{
                        ContactsContract.CommonDataKinds.Phone.NUMBER,
                        ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME
                    };

                    String selection = null;
                    List<String> selectionArgsList = new ArrayList<>();

                    if (contactId != null && !contactId.isEmpty() && lookupKey != null && !lookupKey.isEmpty()) {
                        selection = ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ? OR " + ContactsContract.CommonDataKinds.Phone.LOOKUP_KEY + " = ?";
                        selectionArgsList.add(contactId);
                        selectionArgsList.add(lookupKey);
                    } else if (contactId != null && !contactId.isEmpty()) {
                        selection = ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?";
                        selectionArgsList.add(contactId);
                    } else if (lookupKey != null && !lookupKey.isEmpty()) {
                        selection = ContactsContract.CommonDataKinds.Phone.LOOKUP_KEY + " = ?";
                        selectionArgsList.add(lookupKey);
                    }

                    if (selection != null) {
                        phoneCursor = getContext().getContentResolver().query(
                            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                            projection,
                            selection,
                            selectionArgsList.toArray(new String[0]),
                            null
                        );

                        if (phoneCursor != null) {
                            int numberCol = phoneCursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER);
                            int nameCol = phoneCursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME);

                            while (phoneCursor.moveToNext()) {
                                if (numberCol != -1) {
                                    String num = phoneCursor.getString(numberCol);
                                    if (num != null && !num.trim().isEmpty()) {
                                        phoneSet.add(num.trim());
                                    }
                                }
                                if ((displayName == null || displayName.isEmpty()) && nameCol != -1) {
                                    displayName = phoneCursor.getString(nameCol);
                                }
                            }
                        }
                    }
                } catch (Exception e) {
                    // Fall back to phoneSet already gathered
                } finally {
                    if (phoneCursor != null) phoneCursor.close();
                }
            }

            if (phoneSet.isEmpty()) {
                call.reject("جهة الاتصال المحددة لا تحتوي على أي رقم هاتف مسجل.");
                return;
            }

            List<String> phoneList = new ArrayList<>(phoneSet);
            JSObject ret = new JSObject();
            JSArray phonesArray = new JSArray();
            for (String num : phoneList) {
                phonesArray.put(num);
            }

            ret.put("phoneNumbers", phonesArray);
            ret.put("phoneNumber", phoneList.get(0));
            ret.put("name", displayName != null ? displayName : "");
            ret.put("cancelled", false);
            call.resolve(ret);
        } else {
            // User cancelled / dismissed contacts picker without selection
            JSObject ret = new JSObject();
            ret.put("cancelled", true);
            ret.put("phoneNumber", "");
            ret.put("phoneNumbers", new JSArray());
            ret.put("name", "");
            call.resolve(ret);
        }
    }
}
