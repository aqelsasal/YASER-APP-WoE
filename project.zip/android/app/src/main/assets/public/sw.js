/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-afac4cd2'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "test_logo.png",
    "revision": "c8a840fabc71b1e98f33cd0ba87268b4"
  }, {
    "url": "registerSW.js",
    "revision": "1872c500de691dce40960bb85481de07"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "7c82c64162047ffefb7785508b9a9599"
  }, {
    "url": "pwa-512x512.png",
    "revision": "b705edd87b38175d9b0fb99e9b1eb73d"
  }, {
    "url": "pwa-192x192.png",
    "revision": "1f6382bec23f8b887153d5a2b7ba0be2"
  }, {
    "url": "logo.png",
    "revision": "68299690bf4484c55716d119c1c51b06"
  }, {
    "url": "index.html",
    "revision": "99f551c58bbd4c7c80a41f38e729f43a"
  }, {
    "url": "favicon.ico",
    "revision": "e9623abe55e2f069dc9f592a200f2438"
  }, {
    "url": "company_logo_small.jpg",
    "revision": "200aa6296536d6d2b91e0b8881eeb3df"
  }, {
    "url": "company_logo.svg",
    "revision": "8481bdb0a3f75ab61576b22ae65467d9"
  }, {
    "url": "company_logo.jpg",
    "revision": "f0934aa80fcf091b9b08645bff04d909"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "fda1624738102f5ee40284c12a24a081"
  }, {
    "url": "js/html2pdf.bundle.min.js",
    "revision": "5c6ee7cc4411e35934ae6b2e6cb6bb68"
  }, {
    "url": "assets/web-C4VgOk-l.js",
    "revision": null
  }, {
    "url": "assets/web-B2qVeEog.js",
    "revision": null
  }, {
    "url": "assets/index-CAUJLkBI.css",
    "revision": null
  }, {
    "url": "assets/index-BPZKB1Bp.js",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "fda1624738102f5ee40284c12a24a081"
  }, {
    "url": "company_logo.jpg",
    "revision": "f0934aa80fcf091b9b08645bff04d909"
  }, {
    "url": "company_logo.svg",
    "revision": "8481bdb0a3f75ab61576b22ae65467d9"
  }, {
    "url": "favicon.ico",
    "revision": "e9623abe55e2f069dc9f592a200f2438"
  }, {
    "url": "pwa-192x192.png",
    "revision": "1f6382bec23f8b887153d5a2b7ba0be2"
  }, {
    "url": "pwa-512x512.png",
    "revision": "b705edd87b38175d9b0fb99e9b1eb73d"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "7c82c64162047ffefb7785508b9a9599"
  }, {
    "url": "manifest.webmanifest",
    "revision": "648d96b8d2ad73407200d18c262dc552"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html")));
  workbox.registerRoute(/^https:\/\/fonts\.googleapis\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "google-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(/^https:\/\/fonts\.gstatic\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "gstatic-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');

}));
