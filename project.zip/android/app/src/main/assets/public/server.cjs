var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_express = __toESM(require("express"), 1);
var import_path = __toESM(require("path"), 1);
var import_fs = __toESM(require("fs"), 1);
var import_vite = require("vite");
var app = (0, import_express.default)();
var PORT = 3e3;
app.use(import_express.default.json({ limit: "50mb" }));
var DATA_DIR = import_path.default.join(process.cwd(), "data");
var PROJECTS_DIR = import_path.default.join(DATA_DIR, "projects");
if (!import_fs.default.existsSync(DATA_DIR)) {
  import_fs.default.mkdirSync(DATA_DIR);
}
if (!import_fs.default.existsSync(PROJECTS_DIR)) {
  import_fs.default.mkdirSync(PROJECTS_DIR);
}
var readProject = (id) => {
  const filePath = import_path.default.join(PROJECTS_DIR, `${id}.json`);
  if (!import_fs.default.existsSync(filePath)) return null;
  try {
    const raw = import_fs.default.readFileSync(filePath, "utf-8");
    return JSON.parse(raw);
  } catch (error) {
    console.error(`Error reading project ${id}:`, error);
    return null;
  }
};
var writeProject = (id, data) => {
  const filePath = import_path.default.join(PROJECTS_DIR, `${id}.json`);
  import_fs.default.writeFileSync(filePath, JSON.stringify(data, null, 2), "utf-8");
};
app.post("/api/projects/create", (req, res) => {
  try {
    const { budget, workers, employees, suppliers, expenses, projectName, name, location, client, status, notes, currency } = req.body;
    const projectId = "prj_" + Math.random().toString(36).substring(2, 10);
    const projectData = {
      id: projectId,
      name: projectName || name || "\u0645\u0634\u0631\u0648\u0639 \u0633\u062D\u0627\u0628\u064A",
      location: location || "",
      client: client || "",
      status: status || "active",
      notes: notes || "",
      currency: currency || "YER",
      isSyncActive: true,
      disabled: false,
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
      budget: budget || [],
      workers: workers || [],
      employees: employees || [],
      suppliers: suppliers || [],
      expenses: expenses || []
    };
    writeProject(projectId, projectData);
    res.json({ projectId });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
app.get("/api/projects/:id", (req, res) => {
  try {
    const { id } = req.params;
    const project = readProject(id);
    if (!project) {
      return res.status(404).json({ error: "\u0627\u0644\u0645\u0634\u0631\u0648\u0639 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F \u0623\u0648 \u062A\u0645 \u0625\u0644\u063A\u0627\u0621 \u0627\u0644\u0645\u0632\u0627\u0645\u0646\u0629 \u0627\u0644\u0633\u062D\u0627\u0628\u064A\u0629 \u0644\u0647", disabled: true });
    }
    if (project.disabled || project.isSyncActive === false) {
      return res.status(403).json({ error: "\u062A\u0645 \u0625\u0644\u063A\u0627\u0621 \u0627\u0644\u0645\u0632\u0627\u0645\u0646\u0629 \u0627\u0644\u0633\u062D\u0627\u0628\u064A\u0629 \u0644\u0647\u0630\u0627 \u0627\u0644\u0645\u0634\u0631\u0648\u0639 \u0645\u0646 \u0642\u0628\u0644 \u0627\u0644\u0645\u0627\u0644\u0643\u060C \u0648\u0644\u0645 \u064A\u0639\u062F \u0627\u0644\u0648\u0635\u0648\u0644 \u0623\u0648 \u0627\u0644\u0627\u0637\u0644\u0627\u0639 \u0639\u0628\u0631 \u0647\u0630\u0627 \u0627\u0644\u0631\u0627\u0628\u0637 \u0645\u062A\u0627\u062D\u0627\u064B.", disabled: true });
    }
    res.json(project);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
app.put("/api/projects/:id", (req, res) => {
  try {
    const { id } = req.params;
    const { budget, workers, employees, suppliers, expenses, projectName, name, location, client, status, notes, currency } = req.body;
    const existing = readProject(id);
    if (!existing) {
      return res.status(404).json({ error: "\u0627\u0644\u0645\u0634\u0631\u0648\u0639 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F", disabled: true });
    }
    if (existing.disabled || existing.isSyncActive === false) {
      return res.status(403).json({ error: "\u062A\u0645 \u0625\u0644\u063A\u0627\u0621 \u0627\u0644\u0645\u0632\u0627\u0645\u0646\u0629 \u0627\u0644\u0633\u062D\u0627\u0628\u064A\u0629 \u0644\u0647\u0630\u0627 \u0627\u0644\u0645\u0634\u0631\u0648\u0639 \u0645\u0646 \u0642\u0628\u0644 \u0627\u0644\u0645\u0627\u0644\u0643.", disabled: true });
    }
    const updatedProject = {
      ...existing,
      updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
      name: (projectName || name) !== void 0 ? projectName || name : existing.name,
      location: location !== void 0 ? location : existing.location,
      client: client !== void 0 ? client : existing.client,
      status: status !== void 0 ? status : existing.status,
      notes: notes !== void 0 ? notes : existing.notes,
      currency: currency !== void 0 ? currency : existing.currency,
      budget: budget !== void 0 ? budget : existing.budget,
      workers: workers !== void 0 ? workers : existing.workers,
      employees: employees !== void 0 ? employees : existing.employees || [],
      suppliers: suppliers !== void 0 ? suppliers : existing.suppliers,
      expenses: expenses !== void 0 ? expenses : existing.expenses
    };
    writeProject(id, updatedProject);
    res.json({ status: "ok", updatedAt: updatedProject.updatedAt });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
app.post("/api/projects/:id/cancel-sync", (req, res) => {
  try {
    const { id } = req.params;
    const existing = readProject(id);
    if (existing) {
      existing.isSyncActive = false;
      existing.disabled = true;
      existing.disabledAt = (/* @__PURE__ */ new Date()).toISOString();
      writeProject(id, existing);
    }
    res.json({ status: "ok", message: "\u062A\u0645 \u0625\u0644\u063A\u0627\u0621 \u0627\u0644\u0645\u0632\u0627\u0645\u0646\u0629 \u0627\u0644\u0633\u062D\u0627\u0628\u064A\u0629 \u0648\u062A\u0639\u0637\u064A\u0644 \u0631\u0627\u0628\u0637 \u0627\u0644\u0645\u0634\u0627\u0631\u0643\u0629 \u0628\u0646\u062C\u0627\u062D" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
app.post("/api/set-default-logo", (req, res) => {
  try {
    const { logoBase64 } = req.body;
    if (!logoBase64 || typeof logoBase64 !== "string" || !logoBase64.startsWith("data:image")) {
      return res.status(400).json({ error: "\u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u0634\u0639\u0627\u0631 \u063A\u064A\u0631 \u0635\u0627\u0644\u062D\u0629 \u0623\u0648 \u0644\u0627 \u062A\u062D\u062A\u0648\u064A \u0639\u0644\u0649 \u062A\u0646\u0633\u064A\u0642 \u0635\u0648\u0631\u0629 base64 \u0635\u0627\u0644\u062D" });
    }
    const companyLogoFile = import_path.default.join(process.cwd(), "src", "companyLogo.ts");
    const existingContent = import_fs.default.existsSync(companyLogoFile) ? import_fs.default.readFileSync(companyLogoFile, "utf-8") : "";
    if (!existingContent.includes(logoBase64)) {
      const fileContent = `/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

// \u0627\u0644\u0634\u0639\u0627\u0631 \u0627\u0644\u0623\u0635\u0644\u064A \u0627\u0644\u0631\u0633\u0645\u064A \u0627\u0644\u0645\u0639\u062A\u0645\u062F \u0644\u0644\u0646\u0638\u0627\u0645 (\u062A\u0645 \u0627\u0639\u062A\u0645\u0627\u062F\u0647 \u0648\u062D\u0641\u0638\u0647 \u0643\u0634\u0639\u0627\u0631 \u0627\u0641\u062A\u0631\u0627\u0636\u064A \u062F\u0627\u0626\u0645)
export const COMPANY_LOGO_BASE64 = ${JSON.stringify(logoBase64)};
`;
      import_fs.default.writeFileSync(companyLogoFile, fileContent, "utf-8");
      console.log("\u2705 Successfully updated default company logo in src/companyLogo.ts");
    }
    const dataLogoFile = import_path.default.join(DATA_DIR, "default_logo.txt");
    import_fs.default.writeFileSync(dataLogoFile, logoBase64, "utf-8");
    try {
      const match = logoBase64.match(/^data:image\/([a-zA-Z0-9+]+);base64,(.+)$/);
      if (match) {
        const ext = match[1] === "svg+xml" ? "svg" : match[1] === "jpeg" ? "jpg" : match[1];
        const buffer = Buffer.from(match[2], "base64");
        const pubDir = import_path.default.join(process.cwd(), "public");
        import_fs.default.writeFileSync(import_path.default.join(pubDir, `company_logo.${ext}`), buffer);
        import_fs.default.writeFileSync(import_path.default.join(pubDir, "company_logo.jpg"), buffer);
        import_fs.default.writeFileSync(import_path.default.join(pubDir, "logo.png"), buffer);
      }
    } catch (saveErr) {
      console.warn("Notice: Could not write secondary public image copies:", saveErr);
    }
    res.json({ status: "ok", message: "\u062A\u0645 \u0627\u0639\u062A\u0645\u0627\u062F \u0648\u062A\u062B\u0628\u064A\u062A \u0627\u0644\u0634\u0639\u0627\u0631 \u0628\u0646\u062C\u0627\u062D \u0643\u0634\u0639\u0627\u0631 \u0627\u0641\u062A\u0631\u0627\u0636\u064A \u0631\u0633\u0645\u064A \u0648\u062F\u0627\u0626\u0645 \u0644\u0644\u062A\u0637\u0628\u064A\u0642!" });
  } catch (err) {
    console.error("Error adopting default logo:", err);
    res.status(500).json({ error: err.message });
  }
});
app.get("/api/default-logo", (req, res) => {
  try {
    const dataLogoFile = import_path.default.join(DATA_DIR, "default_logo.txt");
    if (import_fs.default.existsSync(dataLogoFile)) {
      const logo = import_fs.default.readFileSync(dataLogoFile, "utf-8");
      return res.json({ logo });
    }
    const companyLogoFile = import_path.default.join(process.cwd(), "src", "companyLogo.ts");
    if (import_fs.default.existsSync(companyLogoFile)) {
      const content = import_fs.default.readFileSync(companyLogoFile, "utf-8");
      const match = content.match(/COMPANY_LOGO_BASE64\s*=\s*["']([^"']+)["']/);
      if (match && match[1]) {
        return res.json({ logo: match[1] });
      }
    }
    res.json({ logo: null });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
async function setupVite() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await (0, import_vite.createServer)({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = import_path.default.join(process.cwd(), "dist");
    app.use(import_express.default.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(import_path.default.join(distPath, "index.html"));
    });
  }
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}
setupVite();
//# sourceMappingURL=server.cjs.map
