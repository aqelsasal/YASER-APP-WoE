/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as XLSX from 'xlsx';
import { saveAndShareExcelWorkbook } from './utils/androidFileHelper';
import { directShareReportPDF } from './services/pdfExportService';
import { renderHeaderRightHtml, renderFooterHtml, renderSignatureBlocksHtml } from './utils/reportHeaderFooterConfig';
export { directShareReportPDF };

export const SUPPLIER_MATERIAL_CATEGORIES = [
  'مواد كهرباء',
  'مواد سباكة',
  'سمنت',
  'سمنت ابيض',
  'نيسة/رملة',
  'كري',
  'حديد تسليح',
  'حديد ورش',
  'ادوات ومعدات',
  'رنج/دهان',
  'مستلزمات',
  'بلك',
  'حجر',
  'خرسانة جاهزة',
  'كسر رخام',
] as const;

export type SupplierMaterialCategory = typeof SUPPLIER_MATERIAL_CATEGORIES[number] | string;

export interface SupplierMaterialItem {
  id: string;
  itemName: string;     // اسم الصنف / المادة
  unit: string;         // الوحدة (كيس، طن، متر، حبة، إلخ)
  quantity: number;     // الكمية
  unitPrice: number;    // سعر الوحدة
  category?: string;    // فئة الصنف (مواد كهرباء، مواد سباكة، سمنت، إلخ)
  total: number;        // الإجمالي (الكمية × سعر الوحدة)
  notes?: string;       // ملاحظات
  contractItemId?: string;     // معرف بند/فقرة جدول الكميات
  contractItemNumber?: string; // رقم البند (مثال: '1.1')
  contractItemName?: string;   // اسم البند (مثال: 'تلييس داخلي')
}

export interface LedgerEntry {
  id: string;
  date: string;
  amountOnHim: number; // المبلغ عليه
  amountForHim: number; // المبلغ له
  description: string;  // البيان
  notes: string;        // ملاحظات
  isPosted?: boolean;   // هل تم ترحيله من المصروفات اليومية
  isAutoDailyWage?: boolean; // هل هو احتساب تلقائي للأجر اليومي
  isAutoMonthlySalary?: boolean; // هل هو احتساب تلقائي للراتب الشهري
  salaryMonthKey?: string; // مفتاح الشهر (مثل: "2026-06") للاحتساب التلقائي الشهري
  isNutrition?: boolean; // هل هو احتساب تلقائي لبيانات التغذية
  nutritionPeriodId?: string; // معرف فترة التغذية الملتصق بها
  materialItems?: SupplierMaterialItem[]; // كشف تفصيلي بالأصناف والمواد المشتراة والموردة
  materialDiscount?: number; // الخصم / التخفيض في كشف تفاصيل المواد الموردة
  invoiceNumber?: string; // رقم الفاتورة أو السند المرتبط بالحركة
  invoiceImage?: string;  // صورة الفاتورة المرفقة (Base64)
  currency?: string;    // العملة (مثال: YER, SAR, USD)
  contractItemId?: string;     // معرف بند/فقرة جدول الكميات
  contractItemNumber?: string; // رقم البند (مثال: '1.1')
  contractItemName?: string;   // اسم البند
  isMigratedBalance?: boolean; // هل هو رصيد مالي مرحل من مشروع آخر
  migratedFromProject?: string; // اسم المشروع المرحل منه الرصيد
  createdBy?: string;   // الشخص الذي أضاف الحركة
  updatedBy?: string;   // الشخص الذي عدل الحركة
}

export interface WorkPeriod {
  id: string;
  startDate: string;
  endDate: string;
}

export interface NutritionPeriod {
  id: string;
  workerName: string;   // اسم العمال / العامل المساعد
  dailyAmount: number;  // مبلغ التغذية اليومية للعامل
  startDate: string;    // تاريخ البدء (إلزامي)
  endDate?: string;     // تاريخ الانتهاء (اختياري - إن ترك فارغاً فالفترة مستمرة)
  notes?: string;       // ملاحظات
  createdBy?: string;   // الشخص الذي أضاف السجل
  updatedBy?: string;   // الشخص الذي عدل السجل
}

// سجل الغياب أو الإجازة (يوم كامل أو نصف يوم)
export interface AbsenceRecord {
  id: string;
  date: string;          // تاريخ يوم الغياب أو الإجازة (YYYY-MM-DD)
  type: 'full' | 'half'; // يوم كامل (1.0 يوم) أو نصف يوم (0.5 يوم)
  reason?: string;       // السبب أو نوع الإجازة (إجازة، ظرف طارئ، غياب بدون إذن، إلخ)
  notes?: string;        // ملاحظات إضافية
  createdBy?: string;
  createdAt?: string;
}

export interface Worker {
  id: string;
  name: string;         // الاسم
  profession: string;   // المهنة
  startDate: string;    // تاريخ البدء
  endDate: string;      // تاريخ الانتهاء
  phoneNumbers?: string[]; // أرقام الهواتف
  notes?: string;       // ملاحظات
  ledger: LedgerEntry[];
  extraPeriods?: WorkPeriod[]; // فترات عمل إضافية
  nutritionPeriods?: NutritionPeriod[]; // فترات التغذية
  absences?: AbsenceRecord[];  // سجلات الغياب والإجازات المخصومة
  dailyWage?: number;          // الأجر اليومي (اختياري للاحتساب التلقائي)
  dailyWageCurrency?: string;  // عملة الأجر اليومي
  createdBy?: string;   // الشخص الذي أضاف العامل
  updatedBy?: string;   // الشخص الذي عدل العامل
}

export interface Employee {
  id: string;
  name: string;         // الاسم
  profession: string;   // المهنة / المسمى الوظيفي
  startDate: string;    // تاريخ البدء
  endDate: string;      // تاريخ الانتهاء (اختياري)
  wageType?: 'daily' | 'monthly'; // نوع الأجر: أجر يومي ('daily') أو راتب شهري ('monthly')
  dailyWage: number;    // الأجر اليومي
  dailyWageCurrency?: string; // عملة الأجر اليومي أو الراتب (YER, SAR, USD)
  currency?: string;          // عملة الحساب للموظف
  monthlySalary?: number; // مبلغ الراتب الشهري (عند اختيار الراتب الشهري)
  phoneNumbers?: string[]; // أرقام الهواتف
  notes?: string;       // ملاحظات
  ledger: LedgerEntry[];
  extraPeriods?: WorkPeriod[]; // فترات عمل إضافية
  nutritionPeriods?: NutritionPeriod[]; // فترات التغذية
  absences?: AbsenceRecord[];  // سجلات الغياب والإجازات المخصومة
  excludedSalaryMonthKeys?: string[]; // مفاتيح الأشهر المستبعدة من الاحتساب التلقائي للراتب الشهري (بناءً على رغبة المستخدم وحذفه للحركة)
  disableAutoSalaryCalculation?: boolean; // خيار لإيقاف الاحتساب التلقائي لرواتب الموظف يدوياً عند الرغبة
  createdBy?: string;   // الشخص الذي أضاف الموظف
  updatedBy?: string;   // الشخص الذي عدل الموظف
}

export interface Supplier {
  id: string;
  name: string;         // اسم المورد
  materialType: string; // نوع المواد
  material?: string;    // نوع أو صنف المادة (اسم بديل متوافق)
  phoneNumbers?: string[]; // أرقام الهواتف
  notes?: string;       // ملاحظات
  ledger: LedgerEntry[];
  createdBy?: string;   // الشخص الذي أضاف المورد
  updatedBy?: string;   // الشخص الذي عدل المورد
}

export interface Expense {
  id: string;
  date: string;         // التاريخ
  amount: number;       // المبلغ
  description: string;  // البيان
  notes: string;        // ملاحظات
  recipientId: string;  // معرف العامل، الموظف، أو المورد (للترحيل)
  recipientType: 'worker' | 'employee' | 'supplier' | 'none';
  recipientName: string; // اسم المرحل إليه للعرض السريع
  category?: string;    // فئة / بند المصروف (موارد، أجور، إلخ)
  categories?: string[]; // الفئات بخيارات متعددة (مواد استهلاكية - مواد غذائية - مواد بناء وكهرباء - اصول مضافة - مرتبات وموظفين - أجور وعمالة - أخرى)
  expenseType?: 'direct' | 'indirect' | string; // نوع النفقة: نفقات مباشرة / غير مباشرة أو نوع مخصص
  currency?: string;    // العملة
  contractItemId?: string;     // معرف بند/فقرة جدول الكميات المرتبط به
  contractItemNumber?: string; // رقم البند/الفقرة للعرض السريع (مثال: '1.1')
  contractItemName?: string;   // اسم البند/الفقرة للعرض السريع (مثال: 'تلييس داخلي للجدران')
  recordedDate?: string;       // تاريخ إضافة أو تعديل النفقة تلقائياً بحسب تاريخ الهاتف
  createdBy?: string;   // الشخص الذي أضاف المصروف
  updatedBy?: string;   // الشخص الذي عدل المصروف
}

// واجهة بند / فقرة جدول الكميات وعقد المشروع (BOQ Item)
export interface ContractItem {
  id: string;                  // معرف فريد للبند
  itemNumber: string;          // رقم البند أو الفقرة مثل '1', '1.1', '1.2', '2', '2.1'
  name: string;                // اسم البند أو الفقرة (مثل: تلييس داخلي للجدران)
  isMainItem?: boolean;        // هل هو بند رئيسي / عنوان قسم (مثال: بند 1 أعمال التلييس)
  parentItemNumber?: string;   // رقم البند الرئيسي التابع له، مثل '1' (إذا كان فقرة فرعية)
  parentName?: string;         // اسم البند الرئيسي التابع له
  category?: string;           // التصنيف الهندسي (معماري، إنشائي، كهرباء، صحي، إلخ)
  unit?: string;               // الوحدة (م²، م³، م.ط، كجم، طن، حبة، مقطوعية، نقطة...)
  quantity?: number;           // الكمية التعاقدية بجدول الكميات
  unitPrice?: number;          // سعر الوحدة التعاقدي
  totalAmount?: number;        // القيمة التعاقدية الإجمالية = الكمية × السعر
  estimatedBudget?: number;    // ميزانية التكلفة التقديرية المنفذة (Budgeted Cost)
  notes?: string;              // مواصفات وملاحظات تعاقدية
  status?: 'not_started' | 'in_progress' | 'completed' | 'paused'; // حالة تنفيذ البند
  completionPercentage?: number; // نسبة الإنجاز الميداني الفعلي بالموقع (0 - 100%)
  createdAt?: string;          // تاريخ الإضافة
  updatedAt?: string;          // تاريخ التحديث
  createdBy?: string;          // المستخدم الذي أضاف البند
  updatedBy?: string;          // المستخدم الذي عدل البند
}

export interface BudgetItem {
  id: string;
  date: string;         // التاريخ
  amount: number;       // المبلغ
  description: string;  // البيان
  notes: string;        // ملاحظات
  currency?: string;    // العملة
  createdBy?: string;   // الشخص الذي أضاف البند
  updatedBy?: string;   // الشخص الذي عدل البند
}

export interface Project {
  id: string;             // معرف فريد للمشروع
  name: string;           // اسم المشروع / موقع العمل
  location?: string;       // موقع العمل / المدينة
  client?: string;         // المالك / العميل
  status: 'active' | 'completed' | 'planning' | 'paused'; // حالة المشروع
  startDate?: string;     // تاريخ بدئ المشروع
  endDate?: string;       // تاريخ الانتهاء أو التسليم
  notes?: string;         // ملاحظات وتفاصيل إضافية
  syncProjectId?: string | null; // معرف المزامنة السحابية لمشروع المشترك إن وجد
  createdAt: string;      // تاريخ الإنشاء
  updatedAt: string;      // تاريخ التحديث
  budget: BudgetItem[];   // الميزانية المعتمدة للمشروع
  workers: Worker[];      // العمال المقيدين بالمشروع
  employees: Employee[];  // الموظفين المعتمدين بالمشروع
  suppliers: Supplier[];  // الموردين المعتمدين بالمشروع
  expenses: Expense[];    // مصروفات هذا المشروع
  contractItems?: ContractItem[]; // جداول الكميات وبنود العقد للمشروع
}

// Utility to calculate days of work
export function calculateDaysOfWork(startDate: string, endDate: string, isOwner: boolean = true): number {
  if (!startDate) return 0;
  if (!endDate && !isOwner) {
    return 0;
  }
  const start = new Date(startDate);
  const end = endDate ? new Date(endDate) : new Date();
  
  // Set times to midnight to calculate full days
  start.setHours(0, 0, 0, 0);
  end.setHours(0, 0, 0, 0);
  
  if (isNaN(start.getTime()) || !start.getTime() || isNaN(end.getTime()) || !end.getTime()) {
    return 0;
  }
  
  const diffTime = end.getTime() - start.getTime();
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  
  // Return positive diff + 1 (to count the start day), or 0 if start is after end
  return diffDays >= 0 ? diffDays + 1 : 0;
}

// Calculate total deducted days from absences (full = 1.0, half = 0.5)
export function getAbsenceTotalDays(absences?: AbsenceRecord[]): number {
  if (!absences || !Array.isArray(absences) || absences.length === 0) return 0;
  return absences.reduce((sum, a) => sum + (a.type === 'half' ? 0.5 : 1), 0);
}

// Helper to check if a worker or employee is active (مستمر) or stopped (متوقف) based on endDate
export function getPersonWorkStatus(endDate?: string | null): {
  isStopped: boolean;
  statusText: 'مستمر' | 'متوقف';
  badgeClass: string;
} {
  if (!endDate || endDate.trim() === '') {
    return {
      isStopped: false,
      statusText: 'مستمر',
      badgeClass: 'bg-emerald-50 text-emerald-700 border-emerald-200'
    };
  }

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const end = new Date(endDate);
  end.setHours(0, 0, 0, 0);

  // If today is past the end date, considered stopped
  if (!isNaN(end.getTime()) && today > end) {
    return {
      isStopped: true,
      statusText: 'متوقف',
      badgeClass: 'bg-rose-50 text-rose-700 border-rose-200'
    };
  }

  return {
    isStopped: false,
    statusText: 'مستمر',
    badgeClass: 'bg-emerald-50 text-emerald-700 border-emerald-200'
  };
}

// Utility to calculate actual working days dynamically based on the current system/phone date
export function calculateActualDaysOfWork(startDate: string, endDate: string | undefined | null, isOwner: boolean = true): number {
  if (!startDate || !isOwner) return 0;
  
  const start = new Date(startDate);
  const today = new Date();
  
  // Set times to midnight to calculate pure day differences
  start.setHours(0, 0, 0, 0);
  today.setHours(0, 0, 0, 0);
  
  let end = today;
  if (endDate) {
    const parsedEnd = new Date(endDate);
    parsedEnd.setHours(0, 0, 0, 0);
    // If today is equal or past the entered endDate, stop updating and stick to the entered endDate
    if (today >= parsedEnd) {
      end = parsedEnd;
    } else {
      // If today is before endDate, we update dynamically up to today
      end = today;
    }
  }
  
  if (isNaN(start.getTime()) || !start.getTime() || isNaN(end.getTime()) || !end.getTime()) {
    return 0;
  }
  
  const diffTime = end.getTime() - start.getTime();
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  
  return diffDays >= 0 ? diffDays + 1 : 0;
}

// Utility to calculate nutrition days automatically (inclusive: start to end or start to device today)
export function calculateNutritionDays(startDate: string, endDate?: string | null): number {
  if (!startDate) return 0;
  const start = new Date(startDate);
  start.setHours(0, 0, 0, 0);

  let end: Date;
  if (endDate && endDate.trim() !== '') {
    end = new Date(endDate);
  } else {
    end = new Date(); // Current system/device date
  }
  end.setHours(0, 0, 0, 0);

  if (isNaN(start.getTime()) || isNaN(end.getTime())) {
    return 0;
  }

  const diffTime = end.getTime() - start.getTime();
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

  return diffDays >= 0 ? diffDays + 1 : 0;
}

// Helper to clean posted tag strings from description text
export function cleanLedgerDescription(desc: string): string {
  if (!desc) return '';
  return desc
    .replace(/\s*\((مرحّل|مرحلة|مرحل)\s*(تلقائياً|تلقائيا)?\s*(من النفقات اليومية|من النفقات)?\)/gi, '')
    .trim();
}

// Synchronize nutrition periods with worker ledger entries
export function syncWorkerNutritionLedger(worker: Worker): Worker {
  const nutritionPeriods = worker.nutritionPeriods || [];
  if (nutritionPeriods.length === 0) {
    const updatedLedger = worker.ledger.filter(e => !e.isNutrition && !e.nutritionPeriodId && !e.id.startsWith('nutr_entry_'));
    if (updatedLedger.length === worker.ledger.length) return worker;
    return { ...worker, ledger: updatedLedger };
  }

  const todayStr = new Date().toISOString().split('T')[0];
  const validNutrIds = new Set(nutritionPeriods.map(np => np.id));

  let currentLedger = [...worker.ledger];

  // Remove stale nutrition entries
  currentLedger = currentLedger.filter(e => {
    if (e.isNutrition || e.nutritionPeriodId || e.id.startsWith('nutr_entry_')) {
      const nutrId = e.nutritionPeriodId || e.id.replace('nutr_entry_', '');
      return validNutrIds.has(nutrId);
    }
    return true;
  });

  // Sync or add nutrition entries
  nutritionPeriods.forEach(np => {
    const entryId = `nutr_entry_${np.id}`;
    const days = calculateNutritionDays(np.startDate, np.endDate);
    const totalAmount = days * np.dailyAmount;
    const effectiveEndDate = (np.endDate && np.endDate.trim() !== '') ? np.endDate : todayStr;
    const startDateFormatted = formatDateArabic(np.startDate);
    const endDateFormatted = formatDateArabic(effectiveEndDate);

    const desc = `إجمالي مبلغ التغذية لـ (${np.workerName}) لعدد أيام (${days}) من تاريخ (${startDateFormatted}) إلى تاريخ (${endDateFormatted})`;

    const existingIdx = currentLedger.findIndex(e => e.id === entryId || e.nutritionPeriodId === np.id);

    if (existingIdx !== -1) {
      currentLedger[existingIdx] = {
        ...currentLedger[existingIdx],
        date: effectiveEndDate,
        amountOnHim: totalAmount,
        amountForHim: 0,
        description: desc,
        notes: np.notes || '',
        isNutrition: true,
        nutritionPeriodId: np.id,
      };
    } else {
      const newEntry: LedgerEntry = {
        id: entryId,
        date: effectiveEndDate,
        amountOnHim: totalAmount,
        amountForHim: 0,
        description: desc,
        notes: np.notes || '',
        isNutrition: true,
        nutritionPeriodId: np.id,
        currency: 'YER',
        createdBy: np.createdBy || worker.createdBy || 'مالك المشروع'
      };
      currentLedger = [newEntry, ...currentLedger];
    }
  });

  return {
    ...worker,
    ledger: currentLedger
  };
}

// Synchronize daily wage with worker ledger entries (if dailyWage is set and > 0)
export function syncWorkerWageLedger(worker: Worker, isOwner: boolean = true): Worker {
  if (!worker.startDate) {
    return worker;
  }

  const targetCurrency = worker.dailyWageCurrency || 'YER';
  const todayStr = new Date().toISOString().split('T')[0];
  const autoEntryId = `auto_wage_worker_${worker.id}`;

  let currentLedger = [...worker.ledger];
  const dailyWage = Number(worker.dailyWage) || 0;

  if (dailyWage <= 0) {
    // If worker has no daily wage, remove any auto-wage entry
    const filtered = currentLedger.filter(e => !e.isAutoDailyWage && e.id !== autoEntryId);
    if (filtered.length !== currentLedger.length) {
      return { ...worker, ledger: filtered };
    }
    return worker;
  }

  const mainDays = calculateDaysOfWork(worker.startDate, worker.endDate, isOwner);
  const extraDays = (worker.extraPeriods || []).reduce(
    (sum, p) => sum + calculateDaysOfWork(p.startDate, p.endDate, isOwner),
    0
  );
  const grossDays = mainDays + extraDays;
  const totalAbsenceDays = getAbsenceTotalDays(worker.absences);
  const totalDays = Math.max(0, grossDays - totalAbsenceDays);
  const calculatedWage = totalDays * dailyWage;

  const effectiveEndDate = worker.endDate ? worker.endDate : todayStr;
  const startDateFormatted = formatDateArabic(worker.startDate);
  const endDateFormatted = worker.endDate ? formatDateArabic(worker.endDate) : formatDateArabic(effectiveEndDate);

  const periodsDetail = extraDays > 0 
    ? ` [الأساسية: ${mainDays} يوم + الإضافية: ${extraDays} يوم]` 
    : '';
  const absenceDetail = totalAbsenceDays > 0 ? ` [خصم غياب/إجازة: ${totalAbsenceDays} يوم]` : '';
  const autoDescription = `مجموع أجور العمل لعدد (${totalDays}) يوم عمل صافي${absenceDetail}${periodsDetail} للفترة من (${startDateFormatted}) إلى (${endDateFormatted})`;
  const autoNotes = `تم الاحتساب والتحديث تلقائياً بناءً على الأجر اليومي (${dailyWage.toLocaleString('en-US')} ${targetCurrency}) وصافي أيام العمل (${totalDays} يوم${totalAbsenceDays > 0 ? ` [إجمالي الفترة: ${grossDays} يوم - غياب: ${totalAbsenceDays} يوم]` : ''})`;

  const existingIdx = currentLedger.findIndex(
    entry => entry.isAutoDailyWage || entry.id === autoEntryId
  );

  if (existingIdx !== -1) {
    currentLedger[existingIdx] = {
      ...currentLedger[existingIdx],
      id: currentLedger[existingIdx].id || autoEntryId,
      date: effectiveEndDate,
      amountOnHim: currentLedger[existingIdx].amountOnHim || 0,
      amountForHim: calculatedWage,
      description: autoDescription,
      notes: autoNotes,
      isAutoDailyWage: true,
      currency: targetCurrency
    };
  } else {
    const newEntry: LedgerEntry = {
      id: autoEntryId,
      date: effectiveEndDate,
      amountOnHim: 0,
      amountForHim: calculatedWage,
      description: autoDescription,
      notes: autoNotes,
      isAutoDailyWage: true,
      currency: targetCurrency,
      createdBy: worker.createdBy || 'مالك المشروع'
    };
    currentLedger = [newEntry, ...currentLedger];
  }

  return {
    ...worker,
    ledger: currentLedger
  };
}

// Master synchronizer for worker: synchronizes both nutrition and wage ledgers
export function syncWorkerAllLedgers(worker: Worker, isOwner: boolean = true): Worker {
  const withNutrition = syncWorkerNutritionLedger(worker);
  return syncWorkerWageLedger(withNutrition, isOwner);
}


// Synchronize nutrition periods with employee ledger entries
export function syncEmployeeNutritionLedger(employee: Employee): Employee {
  const nutritionPeriods = employee.nutritionPeriods || [];
  if (nutritionPeriods.length === 0) {
    const updatedLedger = employee.ledger.filter(e => !e.isNutrition && !e.nutritionPeriodId && !e.id.startsWith('nutr_entry_'));
    if (updatedLedger.length === employee.ledger.length) return employee;
    return { ...employee, ledger: updatedLedger };
  }

  const todayStr = new Date().toISOString().split('T')[0];
  const validNutrIds = new Set(nutritionPeriods.map(np => np.id));

  let currentLedger = [...employee.ledger];

  // Remove stale nutrition entries
  currentLedger = currentLedger.filter(e => {
    if (e.isNutrition || e.nutritionPeriodId || e.id.startsWith('nutr_entry_')) {
      const nutrId = e.nutritionPeriodId || e.id.replace('nutr_entry_', '');
      return validNutrIds.has(nutrId);
    }
    return true;
  });

  // Sync or add nutrition entries
  nutritionPeriods.forEach(np => {
    const entryId = `nutr_entry_${np.id}`;
    const days = calculateNutritionDays(np.startDate, np.endDate);
    const totalAmount = days * np.dailyAmount;
    const effectiveEndDate = (np.endDate && np.endDate.trim() !== '') ? np.endDate : todayStr;
    const startDateFormatted = formatDateArabic(np.startDate);
    const endDateFormatted = formatDateArabic(effectiveEndDate);

    const desc = `إجمالي مبلغ التغذية لـ (${np.workerName}) لعدد أيام (${days}) من تاريخ (${startDateFormatted}) إلى تاريخ (${endDateFormatted})`;

    const existingIdx = currentLedger.findIndex(e => e.id === entryId || e.nutritionPeriodId === np.id);

    if (existingIdx !== -1) {
      currentLedger[existingIdx] = {
        ...currentLedger[existingIdx],
        date: effectiveEndDate,
        amountOnHim: totalAmount,
        amountForHim: 0,
        description: desc,
        notes: np.notes || '',
        isNutrition: true,
        nutritionPeriodId: np.id,
      };
    } else {
      const newEntry: LedgerEntry = {
        id: entryId,
        date: effectiveEndDate,
        amountOnHim: totalAmount,
        amountForHim: 0,
        description: desc,
        notes: np.notes || '',
        isNutrition: true,
        nutritionPeriodId: np.id,
        currency: employee.dailyWageCurrency || 'YER',
        createdBy: np.createdBy || employee.createdBy || 'مالك المشروع'
      };
      currentLedger = [newEntry, ...currentLedger];
    }
  });

  return {
    ...employee,
    ledger: currentLedger
  };
}

export const ARABIC_MONTH_NAMES: Record<number, string> = {
  1: 'يناير',
  2: 'فبراير',
  3: 'مارس',
  4: 'أبريل',
  5: 'مايو',
  6: 'يونيو',
  7: 'يوليو',
  8: 'أغسطس',
  9: 'سبتمبر',
  10: 'أكتوبر',
  11: 'نوفمبر',
  12: 'ديسمبر'
};

export interface MonthSalaryBreakdown {
  monthKey: string; // e.g. "2026-06"
  year: number;
  month: number;
  monthName: string;
  totalDaysInMonth: number;
  workedDaysInMonth: number;
  startDateInMonth: string;
  endDateInMonth: string;
  dailyRate: number;
  amountDue: number;
  description: string;
  notes: string;
}

// Calculate breakdown of monthly salary for each calendar month worked by the employee
export function calculateEmployeeMonthlySalaries(
  employee: Employee,
  isOwner: boolean = true
): MonthSalaryBreakdown[] {
  if (employee.disableAutoSalaryCalculation) {
    return [];
  }
  const monthlySalary = Number(employee.monthlySalary) || 0;
  if (!employee.startDate || monthlySalary <= 0) {
    return [];
  }

  const todayStr = new Date().toISOString().split('T')[0];

  interface DateRange {
    start: string;
    end: string;
  }
  const periods: DateRange[] = [];

  const mainEnd = employee.endDate ? employee.endDate : (isOwner ? todayStr : employee.startDate);
  if (employee.startDate && mainEnd >= employee.startDate) {
    periods.push({ start: employee.startDate, end: mainEnd });
  }

  (employee.extraPeriods || []).forEach(ep => {
    if (ep.startDate) {
      const epEnd = ep.endDate ? ep.endDate : (isOwner ? todayStr : ep.startDate);
      if (epEnd >= ep.startDate) {
        periods.push({ start: ep.startDate, end: epEnd });
      }
    }
  });

  if (periods.length === 0) return [];

  // Find min start date and max end date
  let minDate = periods[0].start;
  let maxDate = periods[0].end;
  periods.forEach(p => {
    if (p.start < minDate) minDate = p.start;
    if (p.end > maxDate) maxDate = p.end;
  });

  const [minYear, minMonth] = minDate.split('-').map(Number);
  const [maxYear, maxMonth] = maxDate.split('-').map(Number);

  const results: MonthSalaryBreakdown[] = [];

  let curY = minYear;
  let curM = minMonth;

  while (curY < maxYear || (curY === maxYear && curM <= maxMonth)) {
    const monthKey = `${curY}-${String(curM).padStart(2, '0')}`;
    const totalDaysInMonth = new Date(curY, curM, 0).getDate(); // Days in this month (28..31)
    const monthStartStr = `${curY}-${String(curM).padStart(2, '0')}-01`;
    const monthEndStr = `${curY}-${String(curM).padStart(2, '0')}-${String(totalDaysInMonth).padStart(2, '0')}`;

    let workedDaysInMonth = 0;
    let minWorkedDateInMonth = '';
    let maxWorkedDateInMonth = '';

    periods.forEach(p => {
      const overlapStart = p.start > monthStartStr ? p.start : monthStartStr;
      const overlapEnd = p.end < monthEndStr ? p.end : monthEndStr;

      if (overlapStart <= overlapEnd) {
        const days = calculateDaysOfWork(overlapStart, overlapEnd, true);
        workedDaysInMonth += days;

        if (!minWorkedDateInMonth || overlapStart < minWorkedDateInMonth) {
          minWorkedDateInMonth = overlapStart;
        }
        if (!maxWorkedDateInMonth || overlapEnd > maxWorkedDateInMonth) {
          maxWorkedDateInMonth = overlapEnd;
        }
      }
    });

    // Calculate absence deduction in this specific month
    const monthAbsences = (employee.absences || []).filter(a => {
      if (!a.date) return false;
      return a.date >= monthStartStr && a.date <= monthEndStr;
    });
    const absenceDaysInMonth = monthAbsences.reduce(
      (sum, a) => sum + (a.type === 'half' ? 0.5 : 1),
      0
    );
    const netWorkedDaysInMonth = Math.max(0, workedDaysInMonth - absenceDaysInMonth);

    if (workedDaysInMonth > 0) {
      const monthName = ARABIC_MONTH_NAMES[curM] || `شهر ${curM}`;
      const dailyRate = monthlySalary / totalDaysInMonth;
      
      // If worked the entire full month without absences, match full monthly salary exactly
      let amountDue = 0;
      if (workedDaysInMonth >= totalDaysInMonth && absenceDaysInMonth === 0) {
        amountDue = monthlySalary;
      } else {
        amountDue = Math.round((dailyRate * netWorkedDaysInMonth) * 100) / 100;
      }

      const startDateFormatted = formatDateArabic(minWorkedDateInMonth);
      const endDateFormatted = formatDateArabic(maxWorkedDateInMonth);
      const cur = employee.dailyWageCurrency || 'YER';

      const absenceText = absenceDaysInMonth > 0 ? ` [${workedDaysInMonth} يوم - خصم غياب/إجازة: ${absenceDaysInMonth} يوم]` : '';
      const description = `الراتب المستحق لشهر (${monthName} ${curY}) لعدد أيام العمل (${netWorkedDaysInMonth} يوم صافي${absenceText}) من تاريخ (${startDateFormatted}) إلى (${endDateFormatted})`;
      const notes = `احتساب تلقائي للراتب الشهري (${formatCurrency(monthlySalary, cur)} ÷ ${totalDaysInMonth} يوم = ${formatCurrency(dailyRate, cur)}/اليوم × ${netWorkedDaysInMonth} يوم عمل صافي${absenceDaysInMonth > 0 ? ` [خصم ${absenceDaysInMonth} يوم غياب]` : ''})`;

      results.push({
        monthKey,
        year: curY,
        month: curM,
        monthName,
        totalDaysInMonth,
        workedDaysInMonth: netWorkedDaysInMonth,
        startDateInMonth: minWorkedDateInMonth,
        endDateInMonth: maxWorkedDateInMonth,
        dailyRate,
        amountDue,
        description,
        notes
      });
    }

    curM++;
    if (curM > 12) {
      curM = 1;
      curY++;
    }
  }

  const excludedKeys = new Set(employee.excludedSalaryMonthKeys || []);
  return results.filter(r => !excludedKeys.has(r.monthKey));
}

// Synchronize daily wage and monthly salary with employee ledger entries
export function syncEmployeeWageLedger(employee: Employee, isOwner: boolean = true, forceRegenerate: boolean = false): Employee {
  if (!employee.startDate) {
    return employee;
  }

  // If auto calculation was disabled by a previous deletion, but forceRegenerate is true, re-enable it
  if (employee.disableAutoSalaryCalculation && !forceRegenerate) {
    return employee;
  }

  const wageType = employee.wageType || 'daily';
  const targetCurrency = employee.dailyWageCurrency || employee.currency || 'YER';
  const todayStr = new Date().toISOString().split('T')[0];

  if (wageType === 'monthly') {
    // 1. Remove any daily wage entries if switched to monthly
    let currentLedger = employee.ledger.filter(e => !e.isAutoDailyWage && e.id !== `auto_wage_${employee.id}` && !e.id.startsWith(`auto_wage_`));

    // 2. Compute monthly breakdowns
    const breakdowns = calculateEmployeeMonthlySalaries(employee, isOwner);
    const validMonthKeys = new Set(breakdowns.map(b => b.monthKey));
    const excludedKeys = forceRegenerate ? new Set<string>() : new Set(employee.excludedSalaryMonthKeys || []);

    // Remove monthly entries that are no longer valid for updated periods
    currentLedger = currentLedger.filter(e => {
      if (e.isAutoMonthlySalary && e.salaryMonthKey) {
        return validMonthKeys.has(e.salaryMonthKey);
      }
      return true;
    });

    // Add or update monthly entries
    breakdowns.forEach(b => {
      if (excludedKeys.has(b.monthKey)) return;

      const entryId = `auto_salary_${employee.id}_${b.monthKey}`;
      const existingIdx = currentLedger.findIndex(
        entry => entry.id === entryId || (entry.isAutoMonthlySalary && entry.salaryMonthKey === b.monthKey) || entry.salaryMonthKey === b.monthKey
      );

      const targetDate = b.endDateInMonth || todayStr;

      if (existingIdx !== -1) {
        currentLedger[existingIdx] = {
          ...currentLedger[existingIdx],
          date: targetDate,
          amountOnHim: currentLedger[existingIdx].amountOnHim || 0,
          amountForHim: b.amountDue,
          description: b.description,
          notes: b.notes,
          isAutoMonthlySalary: true,
          salaryMonthKey: b.monthKey,
          currency: targetCurrency
        };
      } else if (b.amountDue > 0) {
        const newEntry: LedgerEntry = {
          id: entryId,
          date: targetDate,
          amountOnHim: 0,
          amountForHim: b.amountDue,
          description: b.description,
          notes: b.notes,
          isAutoMonthlySalary: true,
          salaryMonthKey: b.monthKey,
          currency: targetCurrency,
          createdBy: employee.createdBy || 'مالك المشروع'
        };
        currentLedger = [newEntry, ...currentLedger];
      }
    });

    return {
      ...employee,
      disableAutoSalaryCalculation: forceRegenerate ? false : employee.disableAutoSalaryCalculation,
      excludedSalaryMonthKeys: forceRegenerate ? [] : employee.excludedSalaryMonthKeys,
      ledger: currentLedger
    };
  }

  // Wage type is 'daily'
  // Remove any legacy auto monthly salary entries if switched to daily
  let currentLedger = employee.ledger.filter(e => !e.isAutoMonthlySalary && !e.id.startsWith(`auto_salary_`));

  const mainDays = calculateDaysOfWork(employee.startDate, employee.endDate, isOwner);
  const extraDays = (employee.extraPeriods || []).reduce(
    (sum, p) => sum + calculateDaysOfWork(p.startDate, p.endDate, isOwner),
    0
  );
  const grossDays = mainDays + extraDays;
  const totalAbsenceDays = getAbsenceTotalDays(employee.absences);
  const totalDays = Math.max(0, grossDays - totalAbsenceDays);
  const dailyWage = Number(employee.dailyWage) || 0;
  const calculatedWage = totalDays * dailyWage;

  const effectiveEndDate = employee.endDate ? employee.endDate : todayStr;
  const startDateFormatted = formatDateArabic(employee.startDate);
  const endDateFormatted = employee.endDate ? formatDateArabic(employee.endDate) : formatDateArabic(effectiveEndDate);

  const periodsDetail = extraDays > 0 
    ? ` [الأساسية: ${mainDays} يوم + الإضافية: ${extraDays} يوم]` 
    : '';
  const absenceDetail = totalAbsenceDays > 0 ? ` [خصم غياب/إجازة: ${totalAbsenceDays} يوم]` : '';
  const autoDescription = `مجموع أجور العمل لعدد (${totalDays}) يوم عمل صافي${absenceDetail}${periodsDetail} للفترة من (${startDateFormatted}) إلى (${endDateFormatted})`;
  const autoNotes = `تم الاحتساب والتحديث تلقائياً بناءً على الأجر اليومي (${dailyWage.toLocaleString('en-US')} ${targetCurrency}) وصافي أيام العمل (${totalDays} يوم${totalAbsenceDays > 0 ? ` [إجمالي الفترة: ${grossDays} يوم - غياب: ${totalAbsenceDays} يوم]` : ''})`;

  const autoEntryId = `auto_wage_${employee.id}`;
  const existingIdx = currentLedger.findIndex(
    entry => entry.isAutoDailyWage || entry.id === autoEntryId || (entry.id && entry.id.startsWith(`auto_wage_`))
  );

  if (dailyWage > 0 || totalDays > 0) {
    if (existingIdx !== -1) {
      currentLedger[existingIdx] = {
        ...currentLedger[existingIdx],
        id: currentLedger[existingIdx].id || autoEntryId,
        date: effectiveEndDate,
        amountOnHim: currentLedger[existingIdx].amountOnHim || 0,
        amountForHim: calculatedWage,
        description: autoDescription,
        notes: autoNotes,
        isAutoDailyWage: true,
        currency: targetCurrency
      };
    } else {
      const newEntry: LedgerEntry = {
        id: autoEntryId,
        date: effectiveEndDate,
        amountOnHim: 0,
        amountForHim: calculatedWage,
        description: autoDescription,
        notes: autoNotes,
        isAutoDailyWage: true,
        currency: targetCurrency,
        createdBy: employee.createdBy || 'مالك المشروع'
      };
      currentLedger = [newEntry, ...currentLedger];
    }
  } else if (existingIdx !== -1) {
    currentLedger[existingIdx] = {
      ...currentLedger[existingIdx],
      date: effectiveEndDate,
      amountOnHim: currentLedger[existingIdx].amountOnHim || 0,
      amountForHim: 0,
      description: 'لا يوجد أجر يومي محدد للموظف',
      notes: 'الأجر اليومي 0',
      isAutoDailyWage: true,
      currency: targetCurrency
    };
  }

  return {
    ...employee,
    disableAutoSalaryCalculation: forceRegenerate ? false : employee.disableAutoSalaryCalculation,
    excludedSalaryMonthKeys: forceRegenerate ? [] : employee.excludedSalaryMonthKeys,
    ledger: currentLedger
  };
}

// Master synchronizer for employee: synchronizes both nutrition and wage/salary ledgers
export function syncEmployeeAllLedgers(employee: Employee, isOwner: boolean = true, forceRegenerate: boolean = false): Employee {
  const withNutrition = syncEmployeeNutritionLedger(employee);
  return syncEmployeeWageLedger(withNutrition, isOwner, forceRegenerate);
}

// Convert any Eastern Arabic numerals (٠-٩, ۰-۹) to standard English/Latin digits (0-9)
export function toEnglishDigits(str: string | number | null | undefined): string {
  if (str === null || str === undefined) return '';
  const s = String(str);
  return s
    .replace(/[٠١٢٣٤٥٦٧٨٩]/g, (d) => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)))
    .replace(/[۰۱۲۳۴۵۶۷۸۹]/g, (d) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d)));
}

// Format currency beautifully in Arabic (YER, SAR, or USD) using English digits (123)
export function formatCurrency(amount: number, currencyCode: string = 'YER'): string {
  const formatted = new Intl.NumberFormat('en-US', {
    style: 'decimal',
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  }).format(amount || 0);
  
  const cleanNum = toEnglishDigits(formatted);

  switch (currencyCode) {
    case 'SAR':
      return `${cleanNum} ر.س`;
    case 'USD':
      return `$${cleanNum}`;
    case 'YER':
    default:
      return `${cleanNum} ر.ي`;
  }
}

// Month names constants for text date formatting
export const ARABIC_GREGORIAN_MONTHS = [
  'يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو',
  'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'
];

export const ENGLISH_SHORT_MONTHS = [
  'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
  'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
];

export const ENGLISH_FULL_MONTHS = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December'
];

let cachedDateFormat: string = typeof window !== 'undefined' 
  ? (localStorage.getItem('site_date_format') || 'D-MMMM_AR-YYYY') 
  : 'D-MMMM_AR-YYYY';

if (typeof window !== 'undefined') {
  window.addEventListener('date_format_changed', (e: any) => {
    if (e.detail) {
      cachedDateFormat = e.detail;
    } else {
      cachedDateFormat = localStorage.getItem('site_date_format') || 'D-MMMM_AR-YYYY';
    }
  });
  window.addEventListener('storage', (e) => {
    if (e.key === 'site_date_format' && e.newValue) {
      cachedDateFormat = e.newValue;
    }
  });
}

export function getActiveDateFormat(): string {
  if (typeof window !== 'undefined') {
    return cachedDateFormat || localStorage.getItem('site_date_format') || 'D-MMMM_AR-YYYY';
  }
  return 'D-MMMM_AR-YYYY';
}

export function setActiveDateFormat(format: string): void {
  cachedDateFormat = format;
  if (typeof window !== 'undefined') {
    try {
      localStorage.setItem('site_date_format', format);
      window.dispatchEvent(new CustomEvent('date_format_changed', { detail: format }));
    } catch {}
  }
}

// Format date to chosen user format across the entire application using English digits (123)
export function formatDateArabic(dateString: string, forcedFormat?: string): string {
  if (!dateString) return '';
  const cleanStr = String(dateString).trim();
  
  // Extract year, month, day safely without timezone drift
  let year: number | null = null;
  let month: number | null = null; // 1-12
  let day: number | null = null;

  // Pattern 1: ISO or YYYY-MM-DD or YYYY/MM/DD (e.g. 2026-10-20 or 2026/10/20 or 2026-10-20T...)
  const ymdMatch = cleanStr.match(/^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})/);
  if (ymdMatch) {
    year = parseInt(ymdMatch[1], 10);
    month = parseInt(ymdMatch[2], 10);
    day = parseInt(ymdMatch[3], 10);
  } else {
    // Pattern 2: DD-MM-YYYY or DD/MM/YYYY
    const dmyMatch = cleanStr.match(/^(\d{1,2})[-/.](\d{1,2})[-/.](\d{4})/);
    if (dmyMatch) {
      day = parseInt(dmyMatch[1], 10);
      month = parseInt(dmyMatch[2], 10);
      year = parseInt(dmyMatch[3], 10);
    } else {
      // Pattern 3: Check if already text formatted with a known month name
      for (let i = 0; i < 12; i++) {
        if (cleanStr.includes(ARABIC_GREGORIAN_MONTHS[i])) {
          month = i + 1;
          break;
        }
        if (cleanStr.toLowerCase().includes(ENGLISH_FULL_MONTHS[i].toLowerCase())) {
          month = i + 1;
          break;
        }
        if (cleanStr.toLowerCase().includes(ENGLISH_SHORT_MONTHS[i].toLowerCase())) {
          month = i + 1;
          break;
        }
      }
      if (month !== null) {
        const digits = cleanStr.match(/\d+/g);
        if (digits && digits.length >= 2) {
          day = parseInt(digits[0], 10);
          year = parseInt(digits[1], 10);
          if (day > 1000 && year < 1000) {
            const tmp = day; day = year; year = tmp;
          }
        }
      }

      // Fallback Date object parsing
      if (!year || !month || !day) {
        const d = new Date(cleanStr);
        if (!isNaN(d.getTime())) {
          year = d.getFullYear();
          month = d.getMonth() + 1;
          day = d.getDate();
        }
      }
    }
  }

  if (!year || !month || !day || month < 1 || month > 12 || isNaN(year) || isNaN(month) || isNaN(day)) {
    return toEnglishDigits(cleanStr);
  }

  const format = forcedFormat || getActiveDateFormat();
  const monthIdx = month - 1;
  const dayStr = String(day);
  const dayPadded = String(day).padStart(2, '0');
  const monthPadded = String(month).padStart(2, '0');
  const monthStr = String(month);
  const yearStr = String(year);
  const arMonth = ARABIC_GREGORIAN_MONTHS[monthIdx] || '';
  const enShortMonth = ENGLISH_SHORT_MONTHS[monthIdx] || '';
  const enFullMonth = ENGLISH_FULL_MONTHS[monthIdx] || '';

  let result = '';
  switch (format) {
    // 1. Text Month in Arabic (e.g. 1-يناير-2026, 01-يناير-2026)
    case 'D-MMMM_AR-YYYY':
      result = `${dayStr}-${arMonth}-${yearStr}`;
      break;
    case 'DD-MMMM_AR-YYYY':
      result = `${dayPadded}-${arMonth}-${yearStr}`;
      break;

    // 2. Text Month in Short English (e.g. 1-Jan-2026, 01-Jan-2026)
    case 'D-MMM_EN-YYYY':
      result = `${dayStr}-${enShortMonth}-${yearStr}`;
      break;
    case 'DD-MMM_EN-YYYY':
      result = `${dayPadded}-${enShortMonth}-${yearStr}`;
      break;

    // 3. Text Month in Full English (e.g. 1-January-2026, 01-January-2026)
    case 'D-MMMM_EN-YYYY':
      result = `${dayStr}-${enFullMonth}-${yearStr}`;
      break;
    case 'DD-MMMM_EN-YYYY':
      result = `${dayPadded}-${enFullMonth}-${yearStr}`;
      break;

    // 4. Numeric: Day, Month, Year
    case 'DD/MM/YYYY':
      result = `${dayPadded}/${monthPadded}/${yearStr}`;
      break;
    case 'DD-MM-YYYY':
      result = `${dayPadded}-${monthPadded}-${yearStr}`;
      break;
    case 'D/M/YYYY':
      result = `${dayStr}/${monthStr}/${yearStr}`;
      break;
    case 'D-M-YYYY':
      result = `${dayStr}-${monthStr}-${yearStr}`;
      break;

    // 5. Numeric: Year, Month, Day
    case 'YYYY-MM-DD':
      result = `${yearStr}-${monthPadded}-${dayPadded}`;
      break;
    case 'YYYY/MM/DD':
      result = `${yearStr}/${monthPadded}/${dayPadded}`;
      break;

    default:
      if (format.includes('DD/MM/YYYY')) {
        result = `${dayPadded}/${monthPadded}/${yearStr}`;
      } else if (format.includes('DD-MM-YYYY')) {
        result = `${dayPadded}-${monthPadded}-${yearStr}`;
      } else {
        result = `${dayStr}-${arMonth}-${yearStr}`;
      }
      break;
  }

  return toEnglishDigits(result);
}

// Helper to get local device/phone date as YYYY-MM-DD
export function getTodayDateString(): string {
  const today = new Date();
  const year = today.getFullYear();
  const month = String(today.getMonth() + 1).padStart(2, '0');
  const day = String(today.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

// Helper to format date for report filenames (e.g. 04-08-2026)
export function getFormattedReportDate(date: Date = new Date()): string {
  const day = String(date.getDate()).padStart(2, '0');
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const year = date.getFullYear();
  return `${day}-${month}-${year}`;
}

// Ensures that any report title/filename contains the date formatted as DD-MM-YYYY (e.g. 04-08-2026)
export function ensureDateInFilename(filename: string): string {
  if (!filename) return `تقرير_${getFormattedReportDate()}`;

  // If filename already contains YYYY-MM-DD or DD-MM-YYYY date format
  const ymdPattern = /(\d{4})-(\d{2})-(\d{2})/;
  const dmyPattern = /(\d{2})-(\d{2})-(\d{4})/;

  if (ymdPattern.test(filename)) {
    // Convert YYYY-MM-DD to DD-MM-YYYY (e.g., 2026-08-04 -> 04-08-2026)
    return filename.replace(ymdPattern, '$3-$2-$1');
  }

  if (dmyPattern.test(filename)) {
    return filename;
  }

  const dateStr = getFormattedReportDate();

  // Strip extension if present
  let baseName = filename;
  let ext = '';
  if (baseName.toLowerCase().endsWith('.xlsx')) {
    baseName = baseName.slice(0, -5);
    ext = '.xlsx';
  } else if (baseName.toLowerCase().endsWith('.csv')) {
    baseName = baseName.slice(0, -4);
    ext = '.csv';
  } else if (baseName.toLowerCase().endsWith('.html')) {
    baseName = baseName.slice(0, -5);
    ext = '.html';
  } else if (baseName.toLowerCase().endsWith('.pdf')) {
    baseName = baseName.slice(0, -4);
    ext = '.pdf';
  } else if (baseName.toLowerCase().endsWith('.json')) {
    baseName = baseName.slice(0, -5);
    ext = '.json';
  }

  baseName = baseName.trim().replace(/[-_]+$/, '');

  const separator = baseName.includes('_') ? '_' : ' ';
  return `${baseName}${separator}${dateStr}${ext}`;
}

// Helper to export Multi-Sheet Excel (.xlsx) files with SheetJS
export interface ExcelSheetConfig {
  sheetName: string;
  headers: string[];
  rows: (string | number | Date | null | undefined)[][];
}

/**
 * Universal cell processor for Excel export.
 * Recognizes dates as native Date objects and numbers as native numeric values,
 * while preventing unintended conversion of phone numbers and identifiers.
 */
export function processExcelCell(cell: any): any {
  if (cell === null || cell === undefined) return '';
  if (cell instanceof Date) return cell;
  if (typeof cell === 'number') {
    return isNaN(cell) ? '' : cell;
  }
  if (typeof cell === 'string') {
    const trimmed = cell.trim();
    if (trimmed === '' || trimmed === '-') return '';

    // Check for ISO Date pattern YYYY-MM-DD or YYYY/MM/DD
    const isoDateMatch = trimmed.match(/^(\d{4})[-/](\d{1,2})[-/](\d{1,2})$/);
    if (isoDateMatch) {
      const y = parseInt(isoDateMatch[1], 10);
      const m = parseInt(isoDateMatch[2], 10);
      const d = parseInt(isoDateMatch[3], 10);
      const dateObj = new Date(Date.UTC(y, m - 1, d));
      if (!isNaN(dateObj.getTime())) return dateObj;
    }

    // Check for pure numeric string (prevent converting phone numbers like '077...', codes, or very long numbers)
    const isNumeric = /^-?\d+(\.\d+)?$/.test(trimmed);
    const isSpecialCodeOrPhone = (trimmed.length > 1 && trimmed.startsWith('0') && !trimmed.startsWith('0.'));
    if (isNumeric && !isSpecialCodeOrPhone && trimmed.length < 15) {
      const num = Number(trimmed);
      if (!isNaN(num)) return num;
    }
    return trimmed;
  }
  return cell;
}

/**
 * Creates a formatted SheetJS worksheet where:
 * 1. Numbers are true numeric cells (cell.t = 'n') with '#,##0' or '#,##0.00' formatting, so users can calculate SUM, AVERAGE, formulas.
 * 2. Dates are true date cells (cell.t = 'd') with 'yyyy-mm-dd' formatting, so users can sort, filter and perform date math.
 * 3. Column widths are automatically calculated.
 * 4. RTL support is activated for Arabic layout in Excel.
 */
export function createFormattedWorksheet(
  headers: string[],
  rows: (string | number | Date | null | undefined)[][]
): XLSX.WorkSheet {
  const processedRows = rows.map(row => (row || []).map(processExcelCell));
  const data = [headers, ...processedRows];
  const worksheet = XLSX.utils.aoa_to_sheet(data, { cellDates: true });

  // Format worksheet cells with proper Excel number formats and date formats
  Object.keys(worksheet).forEach(cellRef => {
    if (cellRef.startsWith('!')) return;
    const cell = worksheet[cellRef];
    if (!cell) return;

    if (cell.t === 'd') {
      cell.z = 'yyyy-mm-dd';
    } else if (cell.t === 'n') {
      if (Number.isInteger(cell.v)) {
        cell.z = '#,##0';
      } else {
        cell.z = '#,##0.00';
      }
    }
  });

  // Auto-calculate column widths
  const colWidths = headers.map((header, colIndex) => {
    let maxLen = (header || '').toString().length;
    processedRows.forEach(row => {
      const val = row[colIndex];
      if (val !== undefined && val !== null) {
        const strVal = val instanceof Date ? val.toISOString().split('T')[0] : val.toString();
        const len = strVal.length;
        if (len > maxLen) maxLen = len;
      }
    });
    return { wch: Math.min(Math.max(maxLen + 4, 12), 60) };
  });
  worksheet['!cols'] = colWidths;

  // Set Right-To-Left (RTL) view for Arabic presentation in Excel
  (worksheet as any)['!views'] = [{ RTL: true }];

  return worksheet;
}

export function exportMultiSheetXLSX(filename: string, sheets: ExcelSheetConfig[]) {
  try {
    const datedFilename = ensureDateInFilename(filename);
    const workbook = XLSX.utils.book_new();

    sheets.forEach(({ sheetName, headers, rows }) => {
      const worksheet = createFormattedWorksheet(headers, rows);
      XLSX.utils.book_append_sheet(workbook, worksheet, sheetName);
    });

    const cleanFilename = datedFilename.toLowerCase().endsWith('.xlsx') ? datedFilename : `${datedFilename}.xlsx`;
    saveAndShareExcelWorkbook(workbook, cleanFilename, 'تصدير ملف Excel الشامل');

    if (typeof window !== 'undefined' && (window as any).showToast) {
      (window as any).showToast(`تم تصدير ملف Excel الشامل التفصيلي (${cleanFilename}) بنجاح!`);
    }
  } catch (err) {
    console.error("Multi-sheet XLSX export failed:", err);
  }
}

// Helper to export Excel (.xlsx) files with SheetJS with native numeric and date cell types
export function exportToXLSX(filename: string, headers: string[], rows: (string | number | Date | null | undefined)[][], sheetName: string = 'التقرير') {
  try {
    const datedFilename = ensureDateInFilename(filename);
    const worksheet = createFormattedWorksheet(headers, rows);

    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, sheetName);

    // Ensure extension is .xlsx
    const cleanFilename = datedFilename.toLowerCase().endsWith('.xlsx') ? datedFilename : `${datedFilename}.xlsx`;
    saveAndShareExcelWorkbook(workbook, cleanFilename, 'تصدير ملف Excel');

    // Copy TSV to clipboard for quick paste
    try {
      const processedRows = rows.map(row => (row || []).map(processExcelCell));
      const tsvContent = [
        headers.join('\t'),
        ...processedRows.map(row => row.map(val => {
          if (val === undefined || val === null) return '';
          if (val instanceof Date) return val.toISOString().split('T')[0];
          return val.toString().replace(/[\t\r\n]/g, ' ');
        }).join('\t'))
      ].join('\n');
      
      if (typeof navigator !== 'undefined' && navigator.clipboard) {
        navigator.clipboard.writeText(tsvContent).catch(() => {});
      }
    } catch (e) {}

    if (typeof window !== 'undefined' && (window as any).showToast) {
      (window as any).showToast(`تم تحميل ملف Excel بفرز وتنسيق كامل (${cleanFilename}) بنجاح!`);
    }
  } catch (err) {
    console.error("XLSX export failed:", err);
  }
}

// Backward compatible export function alias that always exports .xlsx files
export function exportToCSV(filename: string, headers: string[], rows: (string | number)[][]) {
  const cleanName = filename.replace(/\.csv$/i, '');
  exportToXLSX(cleanName, headers, rows);
}

import { COMPANY_LOGO_BASE64 } from './companyLogo';
export { COMPANY_LOGO_BASE64 };

export interface OfficialReportOptions {
  title: string;
  subtitle?: string;
  projectName?: string;
  companyName?: string;
  companyAddress?: string;
  companyPhone?: string;
  companyLogo?: string;
  statusText?: string;
  bodyHtml: string;
  extraStyles?: string;
}

export const DEFAULT_COMPANY_NAME_AR = 'ورلد أوف إيليتس للتجارة والمقاولات';
export const DEFAULT_COMPANY_NAME_EN = 'World of Elites for Trading & Contracting';
export const DEFAULT_COMPANY_ADDRESS = "صنعاء - بيت بوس - شارع الخمسين - 50 St - Bait Boos - Sana'a";
export const DEFAULT_COMPANY_EMAIL = 'Info@WorldofElites.com';
export const DEFAULT_COMPANY_WEBSITE = 'www.WorldofElites.com';
export const DEFAULT_COMPANY_MOBILES = '+967 782 222 877 | +967 779 992 996';
export const DEFAULT_COMPANY_PHONES = '+967 101915558 | +967 1-699888';

/**
 * Standard generator for official, print-ready reports across all application windows.
 * Guarantees a unified 3-column header, repeating table-header on print, and unified 2-column footer with corporate visual identity.
 */
export function createOfficialReportHtml(options: OfficialReportOptions): string {
  let compName = options.companyName || (typeof localStorage !== 'undefined' ? localStorage.getItem('site_company_name') : null) || DEFAULT_COMPANY_NAME_AR;
  if (compName === 'شركة ورلد أوف إيليتس للمقاولات والخدمات' || compName === 'ورلد أوف إيليتس للمقاولات والخدمات') {
    compName = DEFAULT_COMPANY_NAME_AR;
  }
  const compNameEn = DEFAULT_COMPANY_NAME_EN;

  const projName = options.projectName || (typeof localStorage !== 'undefined' ? localStorage.getItem('site_project_name') : null) || 'مشروع المقاولات والإنشاءات الرئيسي';
  
  let compAddress = options.companyAddress || (typeof localStorage !== 'undefined' ? localStorage.getItem('site_company_address') : null) || DEFAULT_COMPANY_ADDRESS;
  if (compAddress === 'صنعاء - شارع الستين - عمارة النخبة' || compAddress === 'صنعاء - شارع الستين') {
    compAddress = DEFAULT_COMPANY_ADDRESS;
  }

  const compLogo = options.companyLogo || (typeof localStorage !== 'undefined' ? localStorage.getItem('site_company_custom_logo') : null) || COMPANY_LOGO_BASE64;
  const extractionDate = new Date().toLocaleDateString('ar-EG-u-nu-latn');
  const rawStatus = options.statusText || 'كشف معتمد داخلياً';
  const status = (rawStatus === 'تقرير رسمي معتمد' || rawStatus === 'الحالة: تقرير رسمي معتمد') ? 'كشف معتمد داخلياً' : rawStatus;
  // Subtitle in the center below title and logo: remove "تاريخ استخراج التقرير" as it is duplicated elsewhere
  const centerSubtitle = (options.subtitle && !options.subtitle.includes('تاريخ استخراج التقرير')) ? options.subtitle : '';

  const showSignatures = typeof localStorage !== 'undefined' ? localStorage.getItem('site_show_signature_blocks') === 'true' : false;
  const showAttribution = typeof localStorage !== 'undefined' ? localStorage.getItem('site_show_designer_attribution') !== 'false' : true;
  const footerNotes = typeof localStorage !== 'undefined' ? (localStorage.getItem('site_report_footer_notes') || '').trim() : '';

  let footerAppendedHtml = '';
  if (footerNotes) {
    footerAppendedHtml += `
      <div style="margin-top: 20px; padding: 12px 16px; background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; font-size: 11px; color: #334155; line-height: 1.6; page-break-inside: avoid;">
        <strong style="color: #002B49; display: block; margin-bottom: 4px; font-size: 12px;">📌 الملاحظات الختامية والشروط:</strong>
        <div style="white-space: pre-wrap;">${footerNotes}</div>
      </div>
    `;
  }

  if (showSignatures) {
    footerAppendedHtml += renderSignatureBlocksHtml();
  }

  if (showAttribution) {
    footerAppendedHtml += `
      <div class="footer-note" style="margin-top: 20px; text-align: center; font-size: 10px; color: #64748b; border-top: 1px solid #f1f5f9; padding-top: 8px; page-break-inside: avoid;">
        تم توليد هذا التقرير تلقائياً بواسطة تطبيق الحسابات وادارة المشاريع - ${compName} | توقيع المهندس/المصمم ومطور النظام المعتمد | تاريخ الطباعة: ${extractionDate}
      </div>
    `;
  }

  return `
    <div class="pdf-report-root" dir="rtl">
      <style>
        @media print {
          @page {
            margin: 10mm 10mm 12mm 10mm;
            size: A4 portrait;
          }
          body {
            margin: 0 !important;
            padding: 0 !important;
            font-family: 'Cairo', 'Segoe UI', Tahoma, sans-serif !important;
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
          }
          thead.report-header {
            display: table-header-group !important;
          }
          tfoot.report-footer {
            display: table-footer-group !important;
          }
          h1, h2, h3, h4, h5, h6, .report-section-title, .report-heading {
            break-after: avoid !important;
            page-break-after: avoid !important;
          }
          table, .report-data-table {
            break-before: auto !important;
            page-break-before: auto !important;
          }
          tr {
            break-inside: avoid !important;
            page-break-inside: avoid !important;
          }
          .chart-single-page {
            break-inside: avoid !important;
            page-break-inside: avoid !important;
            max-height: 940px !important;
          }
        }

        h1, h2, h3, h4, h5, h6, .report-section-title {
          break-after: avoid !important;
          page-break-after: avoid !important;
        }

        .report-section-title {
          font-size: 13px;
          font-weight: 800;
          color: #002B49;
          background-color: #f8fafc;
          border-right: 4px solid #E85D25;
          border-bottom: 1px solid #e2e8f0;
          padding: 8px 12px;
          margin-top: 14px;
          margin-bottom: 8px;
          border-radius: 4px;
          break-after: avoid !important;
          page-break-after: avoid !important;
        }

        table.report-data-table {
          width: 100%;
          border-collapse: collapse;
          margin-top: 8px;
          margin-bottom: 15px;
          font-size: 11.5px;
        }

        table.report-data-table th {
          background-color: #002B49 !important;
          color: #ffffff !important;
          font-weight: bold;
          text-align: right;
          padding: 8px 10px;
          border: 1px solid #002B49;
          font-size: 11.5px;
        }

        table.report-data-table td {
          padding: 7px 10px;
          border: 1px solid #cbd5e1;
          text-align: right;
          font-size: 11.5px;
        }

        table.report-data-table tr:nth-child(even) td {
          background-color: #f8fafc;
        }

        /* عمود البيان: مساحة أكبر من باقي الأعمدة */
        table.report-data-table th.col-statement,
        table.report-data-table td.col-statement,
        table th.col-statement,
        table td.col-statement,
        .col-statement,
        .col-description,
        .col-desc {
          width: 38% !important;
          min-width: 170px !important;
          font-weight: 700 !important;
          text-align: right !important;
        }

        /* عمود الملاحظات: أصغر حجماً والخط فيه بحجم صغير */
        table.report-data-table th.col-notes,
        table.report-data-table td.col-notes,
        table th.col-notes,
        table td.col-notes,
        .col-notes {
          width: 14% !important;
          font-size: 9.5px !important;
          color: #64748b !important;
          line-height: 1.35 !important;
          font-weight: normal !important;
          word-break: break-word !important;
        }

        ${options.extraStyles || ''}
      </style>

      <table style="width: 100%; border-collapse: collapse; margin: 0; padding: 0;">
        <thead class="official-report-header report-header" style="display: table-header-group;">
          <tr>
            <td style="border: none; padding: 0 0 12px 0;">
              <div style="padding-bottom: 10px; border-bottom: 3px double #002B49; margin-bottom: 12px;">
                <div style="display: flex; justify-content: space-between; align-items: center; direction: rtl; gap: 12px;">
                  
                  <!-- Right Side (الجانب الأيمن): الهوية البصرية الرسمية للشركة -->
                  <div style="text-align: right; flex: 1.35;">
                    ${renderHeaderRightHtml()}
                  </div>

                  <!-- Center (الوسط) -->
                  <div style="text-align: center; flex: 1; display: flex; flex-direction: column; align-items: center; justify-content: center;">
                    <div style="width: 72px; height: 50px; border-radius: 8px; overflow: hidden; display: flex; align-items: center; justify-content: center; margin-bottom: 4px; background-color: #ffffff; padding: 2px;">
                      <img src="${compLogo}" style="max-width: 100%; max-height: 100%; object-fit: contain;" alt="شعار الشركة" />
                    </div>
                    <div style="font-size: 14px; font-weight: 800; color: #002B49; line-height: 1.2;">${options.title}</div>
                    ${centerSubtitle ? `<div style="font-size: 9.5px; color: #64748b; margin-top: 2px;">${centerSubtitle}</div>` : ''}
                  </div>

                  <!-- Left Side (الجانب الأيسر) -->
                  <div style="text-align: left; flex: 1;">
                    <div style="font-size: 11px; font-weight: bold; color: #002B49;">الحسابات وإدارة المشاريع</div>
                    <div style="font-size: 10.5px; font-weight: bold; color: #E85D25; margin-top: 2px;">المشروع: ${projName}</div>
                    <div style="font-size: 9.5px; color: #475569; margin-top: 2px;">تاريخ استخراج التقرير: ${extractionDate}</div>
                    <div style="font-size: 9.5px; font-weight: bold; color: #16a34a; margin-top: 2px;">${status.startsWith('الحالة:') ? status : `الحالة: ${status}`}</div>
                  </div>

                </div>
              </div>
            </td>
          </tr>
        </thead>

        <tbody>
          <tr>
            <td style="border: none; padding: 0;">
              ${options.bodyHtml}
              ${footerAppendedHtml}
            </td>
          </tr>
        </tbody>

        <tfoot class="official-report-footer report-footer" style="display: table-footer-group;">
          <tr>
            <td style="border: none; padding-top: 14px;">
              <div style="border-top: 2px solid #002B49; padding-top: 10px; font-size: 11.5px; color: #002B49; direction: rtl; line-height: 1.5; font-family: 'Cairo', 'Segoe UI', Tahoma, sans-serif;">
                ${renderFooterHtml()}
              </div>
            </td>
          </tr>
        </tfoot>
      </table>
    </div>
  `;
}

// Helper to open a stylized, print-ready window for PDF exporting/printing
export function printPDF(title: string, htmlContent: string) {
  // If htmlContent is not yet wrapped in the official template structure, wrap it automatically
  const isAlreadyOfficial = htmlContent.includes('pdf-report-root') || htmlContent.includes('official-report-header');
  const finalHtml = isAlreadyOfficial ? htmlContent : createOfficialReportHtml({
    title,
    bodyHtml: htmlContent
  });

  if (typeof window !== 'undefined' && (window as any).showPrintPreview) {
    (window as any).showPrintPreview(title, finalHtml);
    return;
  }

  const printWindow = window.open('', '_blank');
  if (!printWindow) {
    alert('الرجاء السماح بالنوافذ المنبثقة لتتمكن من طباعة التقرير.');
    return;
  }

  printWindow.document.write(`
    <!DOCTYPE html>
    <html dir="rtl" lang="ar">
      <head>
        <title>${title}</title>
        <meta charset="utf-8">
        <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700;800&display=swap" rel="stylesheet">
        <style>
          @media print {
            @page {
              size: A4 portrait;
              margin: 10mm 10mm 12mm 10mm;
            }
            body { margin: 0 !important; padding: 0 !important; }
            .no-print-btn { display: none !important; }
            thead.report-header {
              display: table-header-group !important;
            }
            tfoot.report-footer {
              display: table-footer-group !important;
            }
            h1, h2, h3, h4, h5, h6, .report-section-title, .report-heading {
              break-after: avoid !important;
              page-break-after: avoid !important;
            }
            table, .report-data-table {
              break-before: auto !important;
              page-break-before: auto !important;
            }
            tr {
              break-inside: avoid !important;
              page-break-inside: avoid !important;
            }
            .chart-single-page {
              break-inside: avoid !important;
              page-break-inside: avoid !important;
              max-height: 940px !important;
            }
          }
          body {
            font-family: 'Cairo', sans-serif;
            padding: 24px;
            color: #334155;
            direction: rtl;
            background-color: #fff;
          }
        </style>
      </head>
      <body>
        <div class="no-print-btn" style="text-align: left; margin-bottom: 12px;">
          <button onclick="window.print()" style="background-color: #0284c7; color: white; border: none; padding: 8px 16px; border-radius: 6px; cursor: pointer; font-family: 'Cairo', sans-serif; font-weight: bold;">طباعة التقرير / حفظ كـ PDF 🖨️</button>
        </div>
        ${finalHtml}
      </body>
    </html>
  `);
  printWindow.document.close();
}

// ==========================================
// 🏢 نماذج بيانات الديون والالتزامات العامة والمشاريع (حسابات الأطراف والشركاء)
// ==========================================

export interface GeneralDebtEntry {
  id: string;
  amount: number;
  currency: 'YER' | 'SAR' | 'USD';
  date: string;
  description?: string;
  projectScope: 'general' | 'project'; // 'general' = دين عام | 'project' = مرتبط بمشروع
  projectId?: string; // معرف المشروع المسجل بالتطبيق
  projectName?: string; // اسم المشروع (المسجل بالتطبيق أو المكتوب يدوياً)
  notes?: string;
  receiptNumber?: string;
  createdBy?: string;
  createdAt?: string;
}

export interface GeneralDebtPayment {
  id: string;
  date: string;
  amount: number;
  currency?: 'YER' | 'SAR' | 'USD'; // عملة السداد (افتراضياً عملة الدين)
  notes?: string;
  receiptNumber?: string;
  createdBy?: string;
  createdAt?: string;
}

export interface GeneralDebt {
  id: string;
  personOrEntityName: string;
  type: 'receivable' | 'payable'; // 'receivable' = لنا (مستحق للشركة) | 'payable' = علينا (مستحق على الشركة)
  description: string;
  totalAmount: number;
  currency: 'YER' | 'SAR' | 'USD';
  projectScope?: 'general' | 'project'; // نطاق الدين الأساسي (دين عام أو مرتبط بمشروع)
  projectId?: string; // معرف المشروع المرتبط
  projectName?: string; // اسم المشروع المرتبط
  sourceEntityType?: 'worker' | 'employee' | 'supplier' | 'external'; // نوع الطرف المرتبط المرحل منه
  sourceEntityId?: string; // معرف السجل الأصلي (العامل أو المورد أو الموظف)
  startDate: string;
  dueDate?: string;
  status: 'active' | 'partially_paid' | 'settled'; // 'active' = غير مسدد | 'partially_paid' = مسدد جزئياً | 'settled' = مسدد بالكامل
  notes?: string;
  phone?: string;
  entries?: GeneralDebtEntry[]; // دفعات الدين المتعددة (استدانات إضافية لنفس الشخص)
  payments: GeneralDebtPayment[];
  createdBy?: string;
  updatedBy?: string;
  createdAt?: string;
  updatedAt?: string;
}

// ==========================================
// ⭐ نماذج بيانات تقييم الأداء (Performance Evaluations)
// للموظفين، العمال، والموردين
// ==========================================

export type EvaluationCategory = 'employee' | 'worker' | 'supplier';

export type PerformanceLevel = 'excellent' | 'very_good' | 'good' | 'poor' | 'very_poor';

export type RecommendationChoice = 'strongly_agree' | 'agree' | 'neutral' | 'disagree' | 'strongly_disagree';

export interface PerformanceEvaluation {
  id: string;
  category: EvaluationCategory; // 'employee' | 'worker' | 'supplier'
  entityId: string;             // معرف الموظف أو العامل أو المورد
  entityName: string;           // اسم الموظف أو العامل أو المورد
  professionOrType?: string;    // مهنة الموظف/العامل أو نوع المواد للمورد
  projectId?: string;           // معرف المشروع المرتبط (اختياري - إن ترك فارغاً فهو تقييم عام للشركة)
  projectName?: string;         // اسم المشروع المرتبط
  date: string;                 // تاريخ التقييم YYYY-MM-DD
  period?: string;              // فترة التقييم (اختياري مثل: الربع الأول 2026، شهر يناير 2026...)
  rating: number;               // درجة التقييم (من 1 إلى 5 نجوم)
  performanceLevel: PerformanceLevel; // مستوى الأداء تلقائياً (5=ممتاز، 4=جيد جداً، 3=جيد، 2=ضعيف، 1=ضعيف جداً)
  criteria: Record<string, number>;  // درجات معايير التقييم التفصيلية (1 إلى 5)
  recommendation?: RecommendationChoice; // إجابة التوصية (موافق جداً / موافق / لا اعلم / لا اوافق / لا اوافق جداً)
  strengths?: string;           // نقاط القوة / إيجابيات
  weaknesses?: string;          // نقاط الضعف / سلبيات
  notes?: string;               // ملاحظات أخرى
  evaluatorName?: string;       // اسم المشرف / المُقيِّم
  evaluatorTitle?: string;      // صفة / مسمى المشرف المُقيِّم (مثلاً: مهندس ومشرف ميداني، مشرف موقع...)
  evaluatorId?: string;         // معرف الموظف المشرف إن وجد
  createdBy?: string;           // اسم المقيّم أو المسؤول
  createdAt?: string;           // تاريخ ووقت الإنشاء
  updatedAt?: string;           // تاريخ ووقت التعديل
}

// تفاصيل معايير الموظفين
export const EMPLOYEE_CRITERIA = [
  { key: 'punctuality', label: 'الالتزام بالمواعيد' },
  { key: 'workQuality', label: 'جودة العمل' },
  { key: 'productivity', label: 'الإنتاجية' },
  { key: 'cooperation', label: 'التعاون' },
  { key: 'responsibility', label: 'تحمل المسؤولية' },
  { key: 'responsiveness', label: 'سرعة الاستجابة' },
  { key: 'interpersonal', label: 'التعامل مع الآخرين' },
  { key: 'compliance', label: 'الالتزام بالتعليمات' },
  { key: 'toolsPreservation', label: 'المحافظة على أدوات ومعدات العمل' },
] as const;

// تفاصيل معايير العمال
export const WORKER_CRITERIA = [
  { key: 'executionQuality', label: 'جودة التنفيذ' },
  { key: 'punctuality', label: 'الالتزام بالمواعيد' },
  { key: 'productivity', label: 'الإنتاجية' },
  { key: 'attendanceDiscipline', label: 'الحضور والانضباط' },
  { key: 'occupationalSafety', label: 'السلامة المهنية' },
  { key: 'compliance', label: 'الالتزام بالتعليمات' },
  { key: 'interpersonal', label: 'التعامل مع الآخرين' },
  { key: 'responsiveness', label: 'سرعة الاستجابة' },
  { key: 'toolsPreservation', label: 'المحافظة على أدوات ومعدات العمل' },
] as const;

// تفاصيل معايير الموردين
export const SUPPLIER_CRITERIA = [
  { key: 'materialQuality', label: 'جودة المواد' },
  { key: 'specsCompliance', label: 'الالتزام بالمواصفات' },
  { key: 'pricing', label: 'الأسعار' },
  { key: 'deliveryPunctuality', label: 'الالتزام بمواعيد التوريد' },
  { key: 'responsiveness', label: 'سرعة الاستجابة' },
] as const;

// دالة لمعرفة المسمى العربي للمعيار
export function getCriterionLabel(category: EvaluationCategory, key: string): string {
  const list: readonly { key: string; label: string }[] = 
    category === 'employee' ? EMPLOYEE_CRITERIA : 
    category === 'worker' ? WORKER_CRITERIA : 
    SUPPLIER_CRITERIA;
  const found = list.find(c => c.key === key);
  return found ? found.label : key;
}

// خيارات إجابة التوصية
export const RECOMMENDATION_CHOICES: { 
  key: RecommendationChoice; 
  value: RecommendationChoice;
  label: string; 
  icon: string;
  bg: string; 
  text: string; 
  border: string;
  badgeClass: string;
  activeBg: string;
  activeText: string;
  activeBorder: string;
}[] = [
  { 
    key: 'strongly_agree', 
    value: 'strongly_agree',
    label: 'موافق جداً', 
    icon: '🌟',
    bg: 'bg-emerald-50', 
    text: 'text-emerald-800', 
    border: 'border-emerald-300', 
    badgeClass: 'bg-emerald-100 text-emerald-900 border-emerald-300',
    activeBg: 'bg-emerald-600',
    activeText: 'text-white',
    activeBorder: 'border-emerald-600'
  },
  { 
    key: 'agree', 
    value: 'agree',
    label: 'موافق', 
    icon: '👍',
    bg: 'bg-teal-50', 
    text: 'text-teal-800', 
    border: 'border-teal-300', 
    badgeClass: 'bg-teal-100 text-teal-900 border-teal-300',
    activeBg: 'bg-teal-600',
    activeText: 'text-white',
    activeBorder: 'border-teal-600'
  },
  { 
    key: 'neutral', 
    value: 'neutral',
    label: 'لا أعلم', 
    icon: '🤷‍♂️',
    bg: 'bg-slate-100', 
    text: 'text-slate-700', 
    border: 'border-slate-300', 
    badgeClass: 'bg-slate-200 text-slate-800 border-slate-300',
    activeBg: 'bg-slate-700',
    activeText: 'text-white',
    activeBorder: 'border-slate-700'
  },
  { 
    key: 'disagree', 
    value: 'disagree',
    label: 'لا أوافق', 
    icon: '👎',
    bg: 'bg-orange-50', 
    text: 'text-orange-800', 
    border: 'border-orange-300', 
    badgeClass: 'bg-orange-100 text-orange-900 border-orange-300',
    activeBg: 'bg-orange-600',
    activeText: 'text-white',
    activeBorder: 'border-orange-600'
  },
  { 
    key: 'strongly_disagree', 
    value: 'strongly_disagree',
    label: 'لا أوافق جداً', 
    icon: '🚫',
    bg: 'bg-rose-50', 
    text: 'text-rose-800', 
    border: 'border-rose-300', 
    badgeClass: 'bg-rose-100 text-rose-900 border-rose-300',
    activeBg: 'bg-rose-600',
    activeText: 'text-white',
    activeBorder: 'border-rose-600'
  },
];

export function getRecommendationQuestion(category: EvaluationCategory): string {
  switch (category) {
    case 'employee':
      return 'هل توصي بإعادة توظيفه / استمراره بالعمل؟';
    case 'worker':
      return 'هل توصي باستدعائه للعمل في مشاريع أخرى؟';
    case 'supplier':
      return 'هل توصي بالتعامل معه مرة أخرى / أو استمرار التعامل معه؟';
    default:
      return 'هل توصي بالاستمرار والتعامل معه مستقبلاً؟';
  }
}

export function getRecommendationLabel(choice?: RecommendationChoice): string {
  if (!choice) return '-';
  const found = RECOMMENDATION_CHOICES.find(c => c.key === choice);
  return found ? found.label : choice;
}

// دالة مساعدة لتحديد مستوى الأداء وبيانات التنسيق والنجوم
export function getPerformanceLevelInfo(rating: number): {
  level: PerformanceLevel;
  label: string;
  color: string;
  badgeBg: string;
  badgeBorder: string;
  stars: number;
} {
  const rounded = Math.round(rating * 10) / 10;
  if (rounded >= 4.5) {
    return {
      level: 'excellent',
      label: 'ممتاز',
      color: 'text-emerald-700',
      badgeBg: 'bg-emerald-50 text-emerald-700',
      badgeBorder: 'border-emerald-200',
      stars: 5
    };
  } else if (rounded >= 3.5) {
    return {
      level: 'very_good',
      label: 'جيد جداً',
      color: 'text-sky-700',
      badgeBg: 'bg-sky-50 text-sky-700',
      badgeBorder: 'border-sky-200',
      stars: 4
    };
  } else if (rounded >= 2.5) {
    return {
      level: 'good',
      label: 'جيد',
      color: 'text-amber-700',
      badgeBg: 'bg-amber-50 text-amber-700',
      badgeBorder: 'border-amber-200',
      stars: 3
    };
  } else if (rounded >= 1.5) {
    return {
      level: 'poor',
      label: 'ضعيف',
      color: 'text-orange-700',
      badgeBg: 'bg-orange-50 text-orange-700',
      badgeBorder: 'border-orange-200',
      stars: 2
    };
  } else {
    return {
      level: 'very_poor',
      label: 'ضعيف جداً',
      color: 'text-rose-700',
      badgeBg: 'bg-rose-50 text-rose-700',
      badgeBorder: 'border-rose-200',
      stars: 1
    };
  }
}

// ==========================================
// مواد وأصول الشركة (Company Assets & Materials)
// ==========================================

export type AssetCategory = 
  | 'heavy_machinery'    // معدات وآليات ثقيلة وخفيفة
  | 'tools_equipment'    // عدد وأدوات ومستلزمات عمل
  | 'materials_stock'    // مواد بناء ومخزون استراتيجي
  | 'office_tech'        // أصول مكتبية وتقنية وهندسية
  | 'vehicles'           // سيارات ومركبات ونقل
  | 'other';             // أخرى

export type AssetCondition = 
  | 'new'           // جديد ممتاز
  | 'very_good'      // بحالة ممتازة / جيد جداً
  | 'good'          // يعمل بحالة جيدة
  | 'needs_repair'  // يحتاج صيانة أو إصلاح
  | 'damaged'       // تالف / خارج الخدمة
  | 'sold';         // تم التصرف به / مباع

export interface CompanyAssetMovement {
  id: string;
  date: string;
  type: 'transfer' | 'custody_change' | 'maintenance' | 'status_change';
  fromLocation?: string;
  toLocation?: string;
  fromCustody?: string;
  toCustody?: string;
  custodianName?: string;
  conditionAfter?: AssetCondition;
  cost?: number;
  currency?: 'YER' | 'SAR' | 'USD';
  description: string;
  notes?: string;
  createdBy?: string;
  createdAt: string;
}

export interface CompanyAsset {
  id: string;
  name: string;                                 // اسم الأصل / المادة
  category: AssetCategory;                      // فئة الأصل
  purchaseDate: string;                         // تاريخ الشراء / التملك
  quantity: number;                             // الكمية
  unit: string;                                 // الوحدة (عدد، طن، متر، طقم...)
  purchasePrice: number;                        // إجمالي سعر الشراء / التكلفة
  currency: 'YER' | 'SAR' | 'USD';              // العملة
  supplierName?: string;                        // المورد / جهة الشراء
  currentLocation: string;                      // الموقع / مكان التواجد (مخزن الشركة أو اسم المشروع)
  projectId?: string;                           // معرف المشروع إذا كان مخصصاً لمشروع معين
  condition: AssetCondition;                    // الحالة التشغيلية
  custodyPerson?: string;                       // الشخص المستلم / العهدة المسؤول عنها
  custodianName?: string;                       // اسم المستلم / أمين العهدة
  serialNumber?: string;                        // الرقم التسلسلي / كود الأصل
  invoiceNumber?: string;                       // رقم الفاتورة / السند
  notes?: string;                               // مواصفات وملاحظات إضافية
  movements?: CompanyAssetMovement[];           // سجل الحركات والتحويلات والصيانة
  sourceExpenseId?: string;                     // معرف النفقة المصدر إذا تمت الإضافة من النفقات اليومية
  sourceProjectId?: string;                     // معرف المشروع المصدر للنفقة
  createdBy?: string;                           // من أضاف الأصل
  createdAt: string;
  updatedAt: string;
}

export const ASSET_CATEGORIES: { 
  key: AssetCategory; 
  label: string; 
  iconName: string;
  badgeBg: string;
  badgeText: string;
  badgeBorder: string;
}[] = [
  { key: 'heavy_machinery', label: 'معدات وآليات ثقيلة وخفيفة', iconName: 'Tractor', badgeBg: 'bg-amber-50', badgeText: 'text-amber-800', badgeBorder: 'border-amber-200' },
  { key: 'tools_equipment', label: 'عدد وأدوات ومستلزمات', iconName: 'Wrench', badgeBg: 'bg-indigo-50', badgeText: 'text-indigo-800', badgeBorder: 'border-indigo-200' },
  { key: 'materials_stock', label: 'مواد بناء ومخزون', iconName: 'Boxes', badgeBg: 'bg-emerald-50', badgeText: 'text-emerald-800', badgeBorder: 'border-emerald-200' },
  { key: 'office_tech', label: 'أصول إدارية وهندسية وتقنية', iconName: 'Monitor', badgeBg: 'bg-sky-50', badgeText: 'text-sky-800', badgeBorder: 'border-sky-200' },
  { key: 'vehicles', label: 'سيارات ومركبات ونقل', iconName: 'Truck', badgeBg: 'bg-blue-50', badgeText: 'text-blue-800', badgeBorder: 'border-blue-200' },
  { key: 'other', label: 'أصول ومواد أخرى', iconName: 'Package', badgeBg: 'bg-slate-50', badgeText: 'text-slate-800', badgeBorder: 'border-slate-200' },
];

export const ASSET_CONDITIONS: {
  key: AssetCondition;
  label: string;
  badgeBg: string;
  badgeText: string;
  badgeBorder: string;
  dotColor: string;
}[] = [
  { key: 'new', label: 'جديد ممتاز', badgeBg: 'bg-emerald-50', badgeText: 'text-emerald-800', badgeBorder: 'border-emerald-300', dotColor: 'bg-emerald-500' },
  { key: 'very_good', label: 'ممتاز / يعمل بكفاءة', badgeBg: 'bg-teal-50', badgeText: 'text-teal-800', badgeBorder: 'border-teal-300', dotColor: 'bg-teal-500' },
  { key: 'good', label: 'جيد / قيد الاستخدام', badgeBg: 'bg-sky-50', badgeText: 'text-sky-800', badgeBorder: 'border-sky-300', dotColor: 'bg-sky-500' },
  { key: 'needs_repair', label: 'يحتاج صيانة / متوقف', badgeBg: 'bg-amber-50', badgeText: 'text-amber-800', badgeBorder: 'border-amber-300', dotColor: 'bg-amber-500' },
  { key: 'damaged', label: 'تالف / خارج الخدمة', badgeBg: 'bg-rose-50', badgeText: 'text-rose-800', badgeBorder: 'border-rose-300', dotColor: 'bg-rose-500' },
  { key: 'sold', label: 'تم البيع / التصرف به', badgeBg: 'bg-slate-100', badgeText: 'text-slate-700', badgeBorder: 'border-slate-300', dotColor: 'bg-slate-500' },
];

export function getAssetCategoryInfo(cat: AssetCategory) {
  return ASSET_CATEGORIES.find(c => c.key === cat) || ASSET_CATEGORIES[5];
}

export function getAssetConditionInfo(cond: AssetCondition) {
  return ASSET_CONDITIONS.find(c => c.key === cond) || ASSET_CONDITIONS[1];
}


