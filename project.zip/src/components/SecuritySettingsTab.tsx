/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, 
  ShieldAlert, 
  Lock, 
  Unlock, 
  Fingerprint, 
  KeyRound, 
  User, 
  CheckCircle2, 
  AlertCircle, 
  Eye, 
  EyeOff, 
  Clock, 
  HelpCircle,
  RefreshCw
} from 'lucide-react';
import { 
  SecuritySettings, 
  getSecuritySettings, 
  saveSecuritySettings, 
  hashString, 
  generateSalt, 
  isBiometricsSupported, 
  registerBiometricsCredential,
  setAppUnlockedSession
} from '../utils/securityManager';

interface SecuritySettingsTabProps {
  onLockAppNow?: () => void;
}

export default function SecuritySettingsTab({
  onLockAppNow
}: SecuritySettingsTabProps) {
  const [settings, setSettings] = useState<SecuritySettings | null>(() => getSecuritySettings());
  
  // Local form state
  const [isEnabled, setIsEnabled] = useState(settings?.enabled ?? false);
  const [username, setUsername] = useState(settings?.username || 'مدير النظام');
  const [isBiometricsEnabled, setIsBiometricsEnabled] = useState(settings?.biometricsEnabled ?? true);
  const [autoLockInterval, setAutoLockInterval] = useState<number>(settings?.autoLockIntervalMinutes ?? 0);
  const [securityQuestion, setSecurityQuestion] = useState(settings?.securityQuestion || 'ما هو اسم المدينة أو المشروع المفضل؟');
  const [securityAnswer, setSecurityAnswer] = useState('');

  // Password change fields
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');
  const [showPasswords, setShowPasswords] = useState(false);

  // Status feedback
  const [isDeviceBiometricSupported, setIsDeviceBiometricSupported] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [statusMessage, setStatusMessage] = useState<{ text: string; type: 'success' | 'error' | 'info' } | null>(null);

  useEffect(() => {
    isBiometricsSupported().then(supported => {
      setIsDeviceBiometricSupported(supported);
    });
  }, []);

  // Handler: Register/Test Biometrics on device
  const handleRegisterBiometrics = async () => {
    setIsProcessing(true);
    setStatusMessage(null);
    try {
      const res = await registerBiometricsCredential(username);
      if (res.success && res.credentialId) {
        setIsBiometricsEnabled(true);
        if (settings) {
          const updated: SecuritySettings = {
            ...settings,
            biometricsEnabled: true,
            biometricCredentialId: res.credentialId
          };
          saveSecuritySettings(updated);
          setSettings(updated);
        }
        setStatusMessage({
          text: '✅ تم تسجيل واختبار البصمة بنجاح! يمكنك الآن استخدامها لفتح التطبيق.',
          type: 'success'
        });
      } else {
        setStatusMessage({
          text: `⚠️ ${res.error || 'تعذر تسجيل البصمة'}`,
          type: 'error'
        });
      }
    } catch {
      setStatusMessage({ text: '⚠️ حدث خطأ أثناء الاتصال بمستشعر البصمة.', type: 'error' });
    } finally {
      setIsProcessing(false);
    }
  };

  // Handler: Save Security Settings
  const handleSaveSecurity = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);
    setStatusMessage(null);

    try {
      if (!username.trim()) {
        setStatusMessage({ text: '⚠️ يرجى كتابة اسم المستخدم.', type: 'error' });
        setIsProcessing(false);
        return;
      }

      let passwordHash = settings?.passwordHash || '';
      let passwordSalt = settings?.passwordSalt || '';

      // If user wants to set or change password
      if (newPassword) {
        if (newPassword.length < 4) {
          setStatusMessage({ text: '⚠️ كلمة المرور الجديدة يجب أن تكون 4 خانات على الأقل.', type: 'error' });
          setIsProcessing(false);
          return;
        }
        if (newPassword !== confirmNewPassword) {
          setStatusMessage({ text: '⚠️ كلمتا المرور غير متطابقتين.', type: 'error' });
          setIsProcessing(false);
          return;
        }

        // If existing settings already had a password, verify current password
        if (settings?.passwordHash) {
          if (!currentPassword) {
            setStatusMessage({ text: '⚠️ يرجى إدخال كلمة المرور الحالية لتأكيد التغيير.', type: 'error' });
            setIsProcessing(false);
            return;
          }
          const currentHash = await hashString(currentPassword, settings.passwordSalt);
          if (currentHash !== settings.passwordHash) {
            setStatusMessage({ text: '⚠️ كلمة المرور الحالية غير صحيحة.', type: 'error' });
            setIsProcessing(false);
            return;
          }
        }

        passwordSalt = generateSalt();
        passwordHash = await hashString(newPassword, passwordSalt);
      } else if (!settings?.passwordHash && isEnabled) {
        setStatusMessage({ text: '⚠️ يرجى تعيين كلمة مرور لتفعيل حماية التطبيق.', type: 'error' });
        setIsProcessing(false);
        return;
      }

      // Security Answer
      let answerHash = settings?.securityAnswerHash;
      let answerSalt = settings?.securityAnswerSalt;
      if (securityAnswer.trim()) {
        answerSalt = generateSalt();
        answerHash = await hashString(securityAnswer.trim().toLowerCase(), answerSalt);
      }

      const updatedSettings: SecuritySettings = {
        enabled: isEnabled,
        username: username.trim(),
        passwordHash,
        passwordSalt,
        biometricsEnabled: isBiometricsEnabled,
        biometricCredentialId: settings?.biometricCredentialId,
        autoLockIntervalMinutes: autoLockInterval,
        securityQuestion,
        securityAnswerHash: answerHash || settings?.securityAnswerHash,
        securityAnswerSalt: answerSalt || settings?.securityAnswerSalt
      };

      saveSecuritySettings(updatedSettings);
      setSettings(updatedSettings);
      setCurrentPassword('');
      setNewPassword('');
      setConfirmNewPassword('');
      setSecurityAnswer('');
      setStatusMessage({ text: '✅ تم حفظ إعدادات الأمان وقفل التطبيق بنجاح.', type: 'success' });
    } catch {
      setStatusMessage({ text: '⚠️ حدث خطأ أثناء حفظ الإعدادات.', type: 'error' });
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="space-y-4 animate-fade-in text-right dir-rtl">
      {/* Overview Banner */}
      <div className={`p-3.5 rounded-2xl border flex items-center justify-between gap-3 ${
        settings?.enabled
          ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-900'
          : 'bg-amber-500/10 border-amber-500/30 text-amber-900'
      }`}>
        <div className="flex items-center gap-2.5">
          <div className={`p-2 rounded-xl text-white ${
            settings?.enabled ? 'bg-emerald-600' : 'bg-amber-600'
          }`}>
            {settings?.enabled ? <ShieldCheck size={20} /> : <ShieldAlert size={20} />}
          </div>
          <div>
            <h4 className="font-black text-sm">
              حالة الحماية: {settings?.enabled ? 'قفل التطبيق مفعّل 🔒' : 'قفل التطبيق غير مفعّل 🔓'}
            </h4>
            <p className="text-xs opacity-80">
              {settings?.enabled 
                ? 'يتم طلب اسم المستخدم أو البصمة البيومترية عند فتح التطبيق.' 
                : 'يمكن لأي شخص فتح التطبيق ومطالعة البيانات دون قفل.'}
            </p>
          </div>
        </div>

        {/* Lock Now Action */}
        {settings?.enabled && onLockAppNow && (
          <button
            type="button"
            onClick={onLockAppNow}
            className="px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-amber-300 hover:text-white font-extrabold text-xs flex items-center gap-1.5 cursor-pointer shadow-xs transition-colors shrink-0"
            title="قفل التطبيق فوراً والعودة لشاشة الدخول"
            id="lock-app-now-btn"
          >
            <Lock size={14} />
            <span>قفل التطبيق الآن</span>
          </button>
        )}
      </div>

      {statusMessage && (
        <div className={`p-3 rounded-xl border text-xs font-bold flex items-center gap-2 ${
          statusMessage.type === 'success'
            ? 'bg-emerald-50 border-emerald-300 text-emerald-800'
            : statusMessage.type === 'error'
            ? 'bg-rose-50 border-rose-300 text-rose-800'
            : 'bg-sky-50 border-sky-300 text-sky-800'
        }`}>
          {statusMessage.type === 'success' ? (
            <CheckCircle2 size={16} className="text-emerald-600 shrink-0" />
          ) : (
            <AlertCircle size={16} className="text-rose-600 shrink-0" />
          )}
          <span>{statusMessage.text}</span>
        </div>
      )}

      {/* Main Settings Form */}
      <form onSubmit={handleSaveSecurity} className="space-y-4">
        
        {/* 1. Toggle App Lock */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-2xs space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Lock size={18} className="text-amber-500" />
              <div>
                <label htmlFor="toggle-app-lock" className="font-extrabold text-sm text-slate-800 block cursor-pointer">
                  تفعيل شاشة القفل عند فتح التطبيق
                </label>
                <span className="text-[11px] text-slate-500 block">
                  طلب تسجيل الدخول عند تشغيل أو فتح التطبيق لحماية الخصوصية
                </span>
              </div>
            </div>
            <input
              id="toggle-app-lock"
              type="checkbox"
              checked={isEnabled}
              onChange={(e) => setIsEnabled(e.target.checked)}
              className="w-5 h-5 accent-amber-500 cursor-pointer"
            />
          </div>
        </div>

        {/* 2. Username */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-2xs space-y-2">
          <label className="text-xs font-black text-slate-700 block flex items-center gap-1.5">
            <User size={15} className="text-sky-600" />
            اسم المستخدم الرئيسي
          </label>
          <input
            type="text"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            placeholder="مثال: مدير النظام"
            className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs text-slate-800 font-bold focus:border-amber-400 focus:bg-white outline-none"
            required
          />
        </div>

        {/* 3. Biometric Fingerprint (فتح بالبصمة) */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-2xs space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="p-2 rounded-xl bg-amber-500/10 text-amber-600">
                <Fingerprint size={20} />
              </div>
              <div>
                <span className="font-extrabold text-sm text-slate-800 block">
                  فتح القفل بالبصمة البيومترية (الهاتف)
                </span>
                <span className="text-[11px] text-slate-500 block">
                  استخدام بصمة الإصبع أو بصمة الوجه المدمجة بهاتفك للدخول السريع
                </span>
              </div>
            </div>
            {isDeviceBiometricSupported && (
              <input
                type="checkbox"
                checked={isBiometricsEnabled}
                onChange={(e) => setIsBiometricsEnabled(e.target.checked)}
                className="w-5 h-5 accent-amber-500 cursor-pointer"
              />
            )}
          </div>

          {isDeviceBiometricSupported ? (
            <div className="pt-1 flex flex-col sm:flex-row items-center gap-2">
              <button
                type="button"
                onClick={handleRegisterBiometrics}
                disabled={isProcessing}
                className="w-full sm:w-auto py-2 px-4 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 text-amber-900 border border-amber-300 font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer transition-colors shadow-2xs"
                id="test-biometric-settings-btn"
              >
                <Fingerprint size={16} className="text-amber-600" />
                <span>تسجيل / إعادة اختبار البصمة على هذا الجهاز</span>
              </button>
              {settings?.biometricCredentialId && (
                <span className="text-[11px] text-emerald-700 font-bold flex items-center gap-1">
                  <CheckCircle2 size={13} className="text-emerald-600" />
                  البصمة مسجلة ونشطة على هذا الجهاز
                </span>
              )}
            </div>
          ) : (
            <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 text-[11px] text-slate-500">
              ℹ️ لم يتم اكتشاف مستشعر بصمة نشط في هذا المتصفح. عند استخدام التطبيق من تطبيق الهاتف أو متصفح الهاتف ستتمكن من تسجيل واستخدام البصمة.
            </div>
          )}
        </div>

        {/* 4. Password Management */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-2xs space-y-3">
          <div className="flex items-center justify-between border-b border-slate-100 pb-2">
            <span className="text-xs font-black text-slate-700 flex items-center gap-1.5">
              <KeyRound size={15} className="text-amber-600" />
              {settings?.passwordHash ? 'تغيير كلمة المرور' : 'تعيين كلمة المرور الرئيسية'}
            </span>
            <button
              type="button"
              onClick={() => setShowPasswords(!showPasswords)}
              className="text-[11px] text-slate-400 hover:text-slate-600 flex items-center gap-1 cursor-pointer"
            >
              {showPasswords ? <EyeOff size={14} /> : <Eye size={14} />}
              <span>{showPasswords ? 'إخفاء الرموز' : 'إظهار الرموز'}</span>
            </button>
          </div>

          {settings?.passwordHash && (
            <div>
              <label className="text-[11px] font-bold text-slate-600 block mb-1">
                كلمة المرور الحالية (مطلوبة لتغيير الرمز)
              </label>
              <input
                type={showPasswords ? 'text' : 'password'}
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                placeholder="أدخل كلمة المرور الحالية"
                dir="ltr"
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-800 text-right font-mono outline-none focus:border-amber-400"
              />
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            <div>
              <label className="text-[11px] font-bold text-slate-600 block mb-1">
                {settings?.passwordHash ? 'كلمة المرور الجديدة' : 'كلمة المرور'}
              </label>
              <input
                type={showPasswords ? 'text' : 'password'}
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="4 خانات على الأقل"
                dir="ltr"
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-800 text-right font-mono outline-none focus:border-amber-400"
              />
            </div>
            <div>
              <label className="text-[11px] font-bold text-slate-600 block mb-1">
                تأكيد كلمة المرور الجديدة
              </label>
              <input
                type={showPasswords ? 'text' : 'password'}
                value={confirmNewPassword}
                onChange={(e) => setConfirmNewPassword(e.target.value)}
                placeholder="أعد إدخال الرمز"
                dir="ltr"
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-800 text-right font-mono outline-none focus:border-amber-400"
              />
            </div>
          </div>
        </div>

        {/* 5. Auto Lock Interval */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-2xs space-y-2">
          <label className="text-xs font-black text-slate-700 block flex items-center gap-1.5">
            <Clock size={15} className="text-sky-600" />
            مهلة القفل التلقائي
          </label>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {[
              { id: 0, label: 'فوراً عند تصغير التطبيق أو مغادرته' },
              { id: 1, label: 'بعد دقيقة واحدة من عدم الاستخدام' },
              { id: 5, label: 'بعد 5 دقائق من الخمول' },
              { id: -1, label: 'فقط عند إعادة تشغيل/تحديث التطبيق' },
            ].map(item => (
              <label 
                key={item.id} 
                className={`p-2.5 rounded-xl border flex items-center gap-2 cursor-pointer transition-all ${
                  autoLockInterval === item.id 
                    ? 'bg-amber-50 border-amber-300 text-amber-900 font-bold' 
                    : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                <input
                  type="radio"
                  name="autoLockInterval"
                  value={item.id}
                  checked={autoLockInterval === item.id}
                  onChange={() => setAutoLockInterval(item.id)}
                  className="accent-amber-500"
                />
                <span className="text-[11px]">{item.label}</span>
              </label>
            ))}
          </div>
        </div>

        {/* 6. Security Recovery Question */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-2xs space-y-2">
          <label className="text-xs font-black text-slate-700 block flex items-center gap-1.5">
            <HelpCircle size={15} className="text-amber-600" />
            سؤال الأمان لاستعادة كلمة المرور
          </label>
          <input
            type="text"
            value={securityQuestion}
            onChange={(e) => setSecurityQuestion(e.target.value)}
            className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-800 outline-none"
            placeholder="مثال: ما هو اسم المدينة أو المشروع المفضل؟"
          />
          <input
            type="text"
            value={securityAnswer}
            onChange={(e) => setSecurityAnswer(e.target.value)}
            className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-800 outline-none focus:border-amber-400"
            placeholder={settings?.securityAnswerHash ? 'اكتب إجابة جديدة إذا أردت تحديثها' : 'إجابة سؤال الأمان (احفظها جيداً)'}
          />
        </div>

        {/* Submit */}
        <div className="pt-2">
          <button
            type="submit"
            disabled={isProcessing}
            className="w-full py-3 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs sm:text-sm flex items-center justify-center gap-2 cursor-pointer shadow-md transition-colors active:scale-95"
          >
            {isProcessing ? (
              <>
                <RefreshCw size={16} className="animate-spin" />
                <span>جاري الحفظ...</span>
              </>
            ) : (
              <>
                <ShieldCheck size={18} />
                <span>حفظ وتطبيق إعدادات الأمان والقفل</span>
              </>
            )}
          </button>
        </div>

      </form>
    </div>
  );
}
