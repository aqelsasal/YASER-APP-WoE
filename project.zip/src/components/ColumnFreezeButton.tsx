/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Pin } from 'lucide-react';
import { isColumnFrozen, toggleColumnFreeze, applyTableFreeze } from '../utils/tableColumnFreeze';

interface ColumnFreezeButtonProps {
  columnTitle?: string;
  className?: string;
  title?: string;
}

/**
 * ColumnFreezeButton:
 * Renders an interactive Freeze / Pin button in table headers.
 * Clicking freezes the column horizontally so it stays pinned in position
 * while the user scrolls left across other table columns.
 */
export const ColumnFreezeButton: React.FC<ColumnFreezeButtonProps> = ({
  columnTitle,
  className = '',
  title
}) => {
  const buttonRef = useRef<HTMLButtonElement>(null);
  const [isFrozen, setIsFrozen] = useState(false);

  // Sync state with DOM on mount and on freeze change events
  const checkFrozenState = useCallback(() => {
    if (!buttonRef.current) return;
    const thElement = buttonRef.current.closest('th');
    if (!thElement) return;
    const table = thElement.closest('table');
    if (!table) return;

    const ths = Array.from(table.querySelectorAll('thead tr:first-child > th'));
    const colIdx = ths.indexOf(thElement);
    if (colIdx !== -1) {
      const frozen = isColumnFrozen(table, colIdx);
      setIsFrozen(frozen);
    }
  }, []);

  useEffect(() => {
    checkFrozenState();

    const handleFreezeChange = (e: Event) => {
      const customEvent = e as CustomEvent;
      if (!buttonRef.current) return;
      const thElement = buttonRef.current.closest('th');
      const table = thElement?.closest('table');

      if (customEvent.detail?.table === table) {
        checkFrozenState();
      }
    };

    window.addEventListener('table-freeze-change', handleFreezeChange);
    return () => {
      window.removeEventListener('table-freeze-change', handleFreezeChange);
    };
  }, [checkFrozenState]);

  // Initial table layout application on mount
  useEffect(() => {
    const timer = setTimeout(() => {
      if (!buttonRef.current) return;
      const thElement = buttonRef.current.closest('th');
      const table = thElement?.closest('table');
      if (table) {
        applyTableFreeze(table);
      }
    }, 50);
    return () => clearTimeout(timer);
  }, []);

  const handleClick = (e: React.MouseEvent<HTMLButtonElement>) => {
    e.preventDefault();
    e.stopPropagation();

    if (!buttonRef.current) return;
    const thElement = buttonRef.current.closest('th');
    if (!thElement) return;
    const table = thElement.closest('table');
    if (!table) return;

    const ths = Array.from(table.querySelectorAll('thead tr:first-child > th'));
    const colIdx = ths.indexOf(thElement);
    if (colIdx === -1) return;

    const newFrozen = toggleColumnFreeze(table, colIdx);
    setIsFrozen(newFrozen);
  };

  const buttonTitle = title || (isFrozen
    ? `إلغاء تثبيت وتجميد عمود ${columnTitle ? `"${columnTitle}"` : ''}`
    : `تثبيت وتجميد عمود ${columnTitle ? `"${columnTitle}"` : ''} لمنع اختفائه أثناء التمرير لليسار`);

  return (
    <button
      ref={buttonRef}
      type="button"
      onClick={handleClick}
      title={buttonTitle}
      className={`p-1 rounded-md transition-all flex items-center justify-center cursor-pointer select-none text-[11px] shrink-0 ${
        isFrozen
          ? 'bg-amber-100 text-amber-700 dark:bg-amber-950/70 dark:text-amber-300 font-bold ring-1 ring-amber-400/50 shadow-xs'
          : 'text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 dark:hover:bg-slate-700/60 dark:text-slate-400'
      } ${className}`}
    >
      <Pin 
        size={11} 
        className={`transition-transform duration-200 ${
          isFrozen ? 'fill-current -rotate-45' : 'hover:scale-110'
        }`} 
      />
    </button>
  );
};

export default ColumnFreezeButton;
