/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useMemo, useEffect, Component, ErrorInfo, ReactNode } from 'react';
import { 
  X, 
  ClipboardPaste, 
  Upload, 
  Sparkles, 
  Trash2, 
  Plus, 
  CheckCircle2, 
  AlertCircle, 
  FileText, 
  Check, 
  RotateCcw,
  HelpCircle,
  ShieldAlert,
  Smartphone,
  ChevronLeft,
  ChevronRight,
  ArrowUp,
  ArrowDown
} from 'lucide-react';
import { Worker, Supplier, Employee, Expense, formatCurrency, getTodayDateString } from '../types';
import { useBodyScrollLock } from '../utils/modalScrollLock';
import { parseNotesToExpenses, ParsedExpenseItem } from '../utils/notesExpenseParser';
import { PostingAccountSelect } from './PostingAccountSelect';
import { ColumnResizeHandle } from './ColumnResizeHandle';
import { ColumnFreezeButton } from './ColumnFreezeButton';

// Internal error boundary to prevent any modal crash from bubbling to the global screen
interface ModalBoundaryProps {
  children: ReactNode;
  isOpen?: boolean;
  onClose: () => void;
}

interface ModalBoundaryState {
  hasError: boolean;
  errorMessage: string;
}

class NotesModalErrorBoundary extends Component<ModalBoundaryProps, ModalBoundaryState> {
  constructor(props: ModalBoundaryProps) {
    super(props);
    this.state = { hasError: false, errorMessage: '' };
  }

  static getDerivedStateFromError(error: Error): ModalBoundaryState {
    return { hasError: true, errorMessage: error?.message || 'خطأ غير متوقع' };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('[NotesModalErrorBoundary] Caught error:', error, errorInfo);
  }

  componentDidUpdate(prevProps: ModalBoundaryProps) {
    // Automatically reset error state whenever modal closes or changes open state
    if (prevProps.isOpen !== this.props.isOpen) {
      if (!this.props.isOpen || this.state.hasError) {
        this.setState({ hasError: false, errorMessage: '' });
      }
    }
  }

  render() {
    // If modal is closed, do not render anything even if hasError
    if (!this.props.isOpen) {
      return null;
    }

    if (this.state.hasError) {
      return (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs text-right dir-rtl" dir="rtl">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full shadow-2xl border border-slate-200 text-center">
            <div className="w-14 h-14 bg-rose-50 text-rose-600 rounded-2xl flex items-center justify-center mx-auto mb-4 border border-rose-200">
              <ShieldAlert size={28} />
            </div>
            <h3 className="font-black text-slate-800 text-base mb-2">تعذر تحميل نافذة استدعاء الملاحظات</h3>
            <p className="text-xs text-slate-600 mb-5 leading-relaxed">
              حدث تنبيه برمجي بسيط أثناء معالجة بيانات الملاحظات. جميع سجلاتك المحاسبية والمالية محفوظة بالكامل ولم تتأثر مطلقاً.
            </p>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => {
                  this.setState({ hasError: false, errorMessage: '' });
                }}
                className="flex-1 py-2.5 px-4 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-all cursor-pointer shadow-xs"
              >
                إعادة المحاولة
              </button>
              <button
                type="button"
                onClick={() => {
                  this.setState({ hasError: false, errorMessage: '' });
                  this.props.onClose();
                }}
                className="py-2.5 px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition-all cursor-pointer border border-slate-200"
              >
                إلغاء وإغلاق
              </button>
            </div>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

interface NotesExpenseImportModalProps {
  isOpen: boolean;
  onClose: () => void;
  onImportExpenses: (expenses: Omit<Expense, 'id'>[]) => void;
  workers?: Worker[];
  suppliers?: Supplier[];
  employees?: Employee[];
  defaultCurrency?: string;
  availableCategories?: string[];
  sharedRole?: string;
  onAddWorker?: (worker: Omit<Worker, 'id' | 'ledger'>) => Worker | void;
  onAddEmployee?: (employee: Omit<Employee, 'id' | 'ledger'>) => Employee | void;
  onAddSupplier?: (supplier: Omit<Supplier, 'id' | 'ledger'>) => Supplier | void;
}

const SAMPLE_NOTES_TEXT = `شراء 20 كيس اسمنت 90,000
ديزل للمولد 25000
10-10-2026 غداء العمال والمهندسين 14500
شراء مسامير وخشب 12000
حساب المعلم سالم 35000
سداد دفعة للمورد شركة البركة 100000
أمس: بترول سيارة الموقع 18000
فاتورة كروت وشحن رصيد 5000`;

const NotesExpenseImportModalContent: React.FC<NotesExpenseImportModalProps> = ({
  isOpen,
  onClose,
  onImportExpenses,
  workers = [],
  suppliers = [],
  employees = [],
  defaultCurrency = 'ريال يمني',
  availableCategories = [],
  sharedRole = 'admin',
  onAddWorker,
  onAddEmployee,
  onAddSupplier
}) => {
  useBodyScrollLock(isOpen);

  // Safe data filtering with 100% defensive guards
  const safeWorkers = useMemo(() => {
    return Array.isArray(workers) ? workers.filter(w => Boolean(w && w.id && w.name)) : [];
  }, [workers]);

  const safeSuppliers = useMemo(() => {
    return Array.isArray(suppliers) ? suppliers.filter(s => Boolean(s && s.id && s.name)) : [];
  }, [suppliers]);

  const safeEmployees = useMemo(() => {
    return Array.isArray(employees) ? employees.filter(e => Boolean(e && e.id && e.name)) : [];
  }, [employees]);

  // Categories strictly from the "الفئة" in the Add Expense modal per user instruction
  const safeCategories = useMemo(() => {
    if (Array.isArray(availableCategories) && availableCategories.length > 0) {
      const cleaned = availableCategories
        .filter(c => typeof c === 'string' && c.trim().length > 0)
        .map(c => c.trim());
      if (cleaned.length > 0) {
        return Array.from(new Set(cleaned));
      }
    }
    return [
      'مواد استهلاكية',
      'مواد غذائية',
      'مواد بناء وكهرباء',
      'اصول مضافة',
      'مرتبات وموظفين',
      'أجور وعمالة',
      'أخرى'
    ];
  }, [availableCategories]);

  // Combined posting accounts list for easy selection in review table
  const postingAccounts = useMemo(() => {
    const list: { key: string; type: 'worker' | 'supplier' | 'employee' | 'none'; id: string; name: string; label: string }[] = [
      { key: 'none', type: 'none', id: '', name: '', label: 'بدون ترحيل (مصروف عام)' }
    ];

    safeWorkers.forEach(w => {
      list.push({ key: `worker:${w.id}`, type: 'worker', id: String(w.id), name: String(w.name), label: `عامل: ${w.name}` });
    });

    safeSuppliers.forEach(s => {
      list.push({ key: `supplier:${s.id}`, type: 'supplier', id: String(s.id), name: String(s.name), label: `مورد: ${s.name}` });
    });

    safeEmployees.forEach(em => {
      list.push({ key: `employee:${em.id}`, type: 'employee', id: String(em.id), name: String(em.name), label: `موظف: ${em.name}` });
    });

    return list;
  }, [safeWorkers, safeSuppliers, safeEmployees]);

  const [rawText, setRawText] = useState('');
  const [defaultDate, setDefaultDate] = useState(getTodayDateString());
  const [parsedItems, setParsedItems] = useState<ParsedExpenseItem[]>([]);
  const [hasParsed, setHasParsed] = useState(false);
  const [notification, setNotification] = useState<{ type: 'success' | 'error' | 'info'; message: string } | null>(null);
  const [postToLedgers, setPostToLedgers] = useState(true);
  const [autoNotesEnabled, setAutoNotesEnabled] = useState(true);
  const [showHelp, setShowHelp] = useState(false);
  const [showPermissionPrompt, setShowPermissionPrompt] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const tableScrollRef = useRef<HTMLDivElement>(null);

  // Toggle auto notes on/off and sync with currently parsed items
  const handleToggleAutoNotes = (enabled: boolean) => {
    setAutoNotesEnabled(enabled);
    setParsedItems(prev => prev.map(item => ({
      ...item,
      notes: enabled ? (item.notes || `مستورد من الملاحظات (${item.originalLine})`) : ''
    })));
  };

  // Reset or initialize state when opening
  useEffect(() => {
    if (isOpen) {
      setDefaultDate(getTodayDateString());
      setShowPermissionPrompt(false);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  // Notification helper
  const notify = (type: 'success' | 'error' | 'info', message: string) => {
    setNotification({ type, message });
    setTimeout(() => {
      setNotification(prev => (prev?.message === message ? null : prev));
    }, 4500);
  };

  // Run parser: Always adopts defaultCurrency per user specification
  const runParse = (textToParse: string = rawText) => {
    const cleanInput = (textToParse || '').trim();
    if (!cleanInput) {
      notify('error', 'يرجى كتابة أو لصق نص الملاحظات أولاً!');
      return;
    }

    try {
      const items = parseNotesToExpenses(cleanInput, {
        defaultDate,
        defaultCurrency,
        workers: safeWorkers,
        suppliers: safeSuppliers,
        employees: safeEmployees,
        availableCategories: safeCategories,
        autoNotes: autoNotesEnabled
      });

      if (!items || items.length === 0) {
        notify('error', 'لم يتم العثور على أية مبالغ أو نفقات واضحة في النص. تأكد من احتواء الأسطر على أرقام للمبالغ.');
        setParsedItems([]);
        setHasParsed(true);
        return;
      }

      setParsedItems(items);
      setHasParsed(true);
      notify('success', `تم التعرف بنجاح على ${items.length} نفقة واعتمدت بالعملة (${defaultCurrency})!`);
    } catch (err) {
      console.error('Error running notes parser:', err);
      notify('error', 'حدث خطأ أثناء قراءة النص، يرجى التأكد من سلامة الأسطر.');
    }
  };

  // Read clipboard with explicit permission handling for Android & Web
  const handlePasteFromClipboard = async () => {
    try {
      if (!navigator?.clipboard?.readText) {
        setShowPermissionPrompt(true);
        return;
      }

      if (navigator.permissions && navigator.permissions.query) {
        try {
          const permResult = await navigator.permissions.query({ name: 'clipboard-read' as any });
          if (permResult.state === 'denied') {
            setShowPermissionPrompt(true);
            return;
          }
        } catch {
          // Continue to readText on Android WebViews that don't support permission query
        }
      }

      const text = await navigator.clipboard.readText();
      if (!text || !text.trim()) {
        notify('info', 'الحافظة في هاتفك فارغة حالياً. قم بنسخ نص الملاحظات من تطبيق الملاحظات أولاً.');
        return;
      }

      setRawText(text);
      setShowPermissionPrompt(false);
      notify('success', 'تم قراءة النص من حافظة الهاتف بنجاح!');
      runParse(text);
    } catch (err: any) {
      console.warn('Clipboard read permission/access issue:', err);
      setShowPermissionPrompt(true);
    }
  };

  // Manual fallback focus for Android users
  const handleFocusTextareaForPaste = () => {
    setShowPermissionPrompt(false);
    if (textareaRef.current) {
      textareaRef.current.focus();
      textareaRef.current.select();
    }
    notify('info', 'اضغط مطولاً داخل الصندوق ثم اختر (لصق Paste) من لوحة مفاتيح هاتفك.');
  };

  // File upload reader (.txt, .notes, etc.)
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      if (text) {
        setRawText(text);
        runParse(text);
        notify('success', `تم تحميل وقراءة ملف "${file.name}" بنجاح!`);
      }
    };
    reader.onerror = () => {
      notify('error', 'تعذر قراءة الملف المحدد. يرجى التأكد من أنه ملف نصي سليم.');
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  // Insert sample notes
  const handleLoadSample = () => {
    setRawText(SAMPLE_NOTES_TEXT);
    runParse(SAMPLE_NOTES_TEXT);
  };

  // Selection toggles
  const handleToggleSelectAll = (checked: boolean) => {
    setParsedItems(prev => prev.map(item => ({ ...item, selected: checked })));
  };

  const handleToggleSelectItem = (id: string) => {
    setParsedItems(prev => prev.map(item => item.id === id ? { ...item, selected: !item.selected } : item));
  };

  // Row update handlers
  const handleUpdateItem = (id: string, updates: Partial<ParsedExpenseItem>) => {
    setParsedItems(prev => prev.map(item => {
      if (item.id === id) {
        const updated = { ...item, ...updates };
        if (updates.category) {
          updated.categories = [updates.category];
        }
        return updated;
      }
      return item;
    }));
  };

  const handleDeleteItem = (id: string) => {
    setParsedItems(prev => prev.filter(item => item.id !== id));
  };

  const handleAddNewItem = () => {
    const newItem: ParsedExpenseItem = {
      id: `man_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      originalLine: 'بند يدوي',
      date: defaultDate,
      description: 'نفقة جديدة',
      amount: 1000,
      currency: defaultCurrency,
      category: safeCategories[0] || 'أخرى',
      categories: [safeCategories[0] || 'أخرى'],
      notes: autoNotesEnabled ? 'مضاف يدوياً' : '',
      recipientType: 'none',
      recipientId: '',
      recipientName: '',
      expenseType: 'direct', // Default is direct per user requirement!
      confidence: 'high',
      selected: true
    };
    setParsedItems(prev => [newItem, ...prev]);
  };

  // Smooth scroll controls for the review table
  const scrollTable = (direction: 'left' | 'right' | 'up' | 'down') => {
    if (!tableScrollRef.current) return;
    const scrollAmount = 220;
    if (direction === 'left') {
      tableScrollRef.current.scrollBy({ left: -scrollAmount, behavior: 'smooth' });
    } else if (direction === 'right') {
      tableScrollRef.current.scrollBy({ left: scrollAmount, behavior: 'smooth' });
    } else if (direction === 'up') {
      tableScrollRef.current.scrollBy({ top: -scrollAmount, behavior: 'smooth' });
    } else if (direction === 'down') {
      tableScrollRef.current.scrollBy({ top: scrollAmount, behavior: 'smooth' });
    }
  };

  // Calculate totals (all in defaultCurrency)
  const selectedItems = useMemo(() => {
    return parsedItems.filter(i => i.selected && i.amount > 0 && i.description.trim());
  }, [parsedItems]);

  const totalSum = useMemo(() => {
    return selectedItems.reduce((acc, curr) => acc + (Number(curr.amount) || 0), 0);
  }, [selectedItems]);

  // Submit and Import
  const handleConfirmImport = () => {
    if (selectedItems.length === 0) {
      notify('error', 'يرجى تحديد نفقة واحدة على الأقل للاستيراد!');
      return;
    }

    const expensesToAdd: Omit<Expense, 'id'>[] = selectedItems.map(item => ({
      date: item.date || defaultDate,
      amount: item.amount,
      description: item.description.trim(),
      expenseType: item.expenseType || 'direct', // Default: Direct
      categories: item.categories && item.categories.length > 0 ? item.categories : [item.category || safeCategories[0] || 'أخرى'],
      notes: autoNotesEnabled ? (item.notes || '') : '',
      recipientId: postToLedgers ? item.recipientId : '',
      recipientType: postToLedgers ? item.recipientType : 'none',
      recipientName: postToLedgers ? item.recipientName : '',
      currency: defaultCurrency,
      recordedDate: getTodayDateString()
    }));

    onImportExpenses(expensesToAdd);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center sm:p-4 bg-slate-950/75 backdrop-blur-xs animate-fade-in text-right dir-rtl" dir="rtl">
      <div 
        className="bg-white rounded-t-3xl sm:rounded-3xl shadow-2xl border border-slate-100 w-full max-w-5xl max-h-[94vh] sm:max-h-[90vh] flex flex-col overflow-hidden text-right"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header - Android Styled Header */}
        <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between bg-gradient-to-r from-emerald-50/80 via-teal-50/40 to-white">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-emerald-600 text-white flex items-center justify-center shadow-md shadow-emerald-600/20 shrink-0">
              <ClipboardPaste size={22} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-black text-slate-800 text-base sm:text-lg">
                  استدعاء النفقات من ملاحظات الهاتف
                </h3>
                <span className="text-[11px] font-extrabold text-emerald-800 bg-emerald-100/90 px-2.5 py-0.5 rounded-full border border-emerald-200">
                  {defaultCurrency}
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                استخرج بنود المصاريف والمبالغ تلقائياً من نصوص الهاتف واعتمدها بعملة المشروع ({defaultCurrency})
              </p>
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => setShowHelp(prev => !prev)}
              className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
              title="دليل كتابة الملاحظات"
            >
              <HelpCircle size={20} />
            </button>
            <button
              type="button"
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
              title="إغلاق"
            >
              <X size={20} />
            </button>
          </div>
        </div>

        {/* Permission Prompt Banner if Android Clipboard requires permission */}
        {showPermissionPrompt && (
          <div className="mx-4 sm:mx-6 mt-3 p-4 bg-amber-50/90 border border-amber-300 rounded-2xl text-xs text-amber-950 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-xs">
            <div className="flex items-start gap-3">
              <div className="p-2 bg-amber-200/80 rounded-xl text-amber-800 shrink-0">
                <Smartphone size={20} />
              </div>
              <div>
                <h4 className="font-black text-amber-900 text-xs sm:text-sm">طلب إذن قراءة الحافظة في الهاتف</h4>
                <p className="text-[11px] text-amber-800/90 mt-0.5 leading-relaxed">
                  يتطلب نظام أندرويد منح المتصفح صلاحية قراءة الحافظة لقراءة النص المنسوخ تلقائياً، أو يمكنك اللصق اليدوي مباشرة داخل الصندوق.
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2 w-full sm:w-auto shrink-0">
              <button
                type="button"
                onClick={handlePasteFromClipboard}
                className="flex-1 sm:flex-none py-2 px-3.5 bg-amber-600 hover:bg-amber-700 active:scale-95 text-white font-bold text-xs rounded-xl transition-all cursor-pointer shadow-xs"
              >
                منح الإذن والمحاولة ثانية
              </button>
              <button
                type="button"
                onClick={handleFocusTextareaForPaste}
                className="flex-1 sm:flex-none py-2 px-3 bg-white hover:bg-amber-100 text-amber-900 font-bold text-xs rounded-xl border border-amber-300 transition-colors cursor-pointer"
              >
                اللصق اليدوي بالمربع
              </button>
            </div>
          </div>
        )}

        {/* Notification Toast inside Modal */}
        {notification && (
          <div className={`mx-4 sm:mx-6 mt-3 p-3 rounded-xl text-xs font-bold flex items-center gap-2 transition-all ${
            notification.type === 'success' ? 'bg-emerald-50 text-emerald-800 border border-emerald-200' :
            notification.type === 'error' ? 'bg-rose-50 text-rose-800 border border-rose-200' :
            'bg-sky-50 text-sky-800 border border-sky-200'
          }`}>
            {notification.type === 'success' ? <CheckCircle2 size={16} className="shrink-0 text-emerald-600" /> :
             notification.type === 'error' ? <AlertCircle size={16} className="shrink-0 text-rose-600" /> :
             <Sparkles size={16} className="shrink-0 text-sky-600" />}
            <span>{notification.message}</span>
          </div>
        )}

        {/* Help banner when toggled */}
        {showHelp && (
          <div className="mx-4 sm:mx-6 mt-3 p-3.5 bg-sky-50/90 border border-sky-200 rounded-2xl text-xs text-sky-950 leading-relaxed">
            <div className="font-extrabold flex items-center gap-1.5 mb-1 text-sky-900">
              <Sparkles size={14} />
              <span>كيف يتعرف التطبيق على الملاحظات؟</span>
            </div>
            <p className="text-sky-900/90">
              اكتب كل نفقة في سطر مستقل بالهاتف، مثل: <code>شراء 20 كيس اسمنت 90000</code> أو <code>ديزل للمولد 25000</code>. يقوم التطبيق تلقائياً بعزل الأرقام والمبالغ، تحديد التواريخ، ربط أسماء العمال والموردين، وتوحيد جميع المبالغ بالعملة الافتراضية للمشروع (<b>{defaultCurrency}</b>).
            </p>
          </div>
        )}

        {/* Modal Scrollable Body */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-4 flex-1 text-right overscroll-contain">
          
          {/* Top Quick Actions Bar */}
          <div className="flex flex-wrap items-center justify-between gap-2.5 pb-2 border-b border-slate-100">
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={handlePasteFromClipboard}
                className="py-2.5 px-4 bg-emerald-600 hover:bg-emerald-700 active:scale-98 text-white font-extrabold text-xs rounded-xl shadow-xs transition-all flex items-center gap-2 cursor-pointer"
              >
                <ClipboardPaste size={16} />
                <span>لصق من حافظة الهاتف</span>
              </button>

              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="py-2.5 px-3.5 bg-slate-100 hover:bg-slate-200 active:scale-98 text-slate-700 font-bold text-xs rounded-xl transition-all flex items-center gap-2 cursor-pointer border border-slate-200"
              >
                <Upload size={16} />
                <span>رفع ملف نصي (.txt)</span>
              </button>
              <input 
                ref={fileInputRef} 
                type="file" 
                accept=".txt,.notes,.csv,.log" 
                onChange={handleFileUpload} 
                className="hidden" 
              />

              <button
                type="button"
                onClick={handleLoadSample}
                className="py-2.5 px-3 bg-purple-50 hover:bg-purple-100 text-purple-700 font-bold text-xs rounded-xl transition-all flex items-center gap-1.5 cursor-pointer border border-purple-200"
              >
                <Sparkles size={14} />
                <span>نموذج تجريبي</span>
              </button>
            </div>

            {/* Default Date configuration & Options */}
            <div className="flex flex-wrap items-center gap-2 shrink-0">
              <label 
                className="flex items-center gap-1.5 bg-slate-50 hover:bg-slate-100 px-3 py-1.5 rounded-xl border border-slate-200 cursor-pointer select-none transition-colors"
                title="تحديد إذا ما كان يتم تسجيل نص الملاحظة الأصلية تلقائياً في خانة الملاحظات للنفقة"
              >
                <input
                  type="checkbox"
                  checked={autoNotesEnabled}
                  onChange={(e) => handleToggleAutoNotes(e.target.checked)}
                  className="rounded text-emerald-600 focus:ring-0 cursor-pointer"
                />
                <span className="text-[11px] font-bold text-slate-700">إضافة الملاحظات التلقائية</span>
              </label>

              <div className="flex items-center gap-1.5 bg-slate-50 px-3 py-1.5 rounded-xl border border-slate-200">
                <span className="text-[11px] font-bold text-slate-500">التاريخ الافتراضي:</span>
                <input
                  type="date"
                  value={defaultDate}
                  onChange={(e) => setDefaultDate(e.target.value)}
                  className="bg-transparent border-none text-xs font-bold text-slate-800 focus:outline-hidden"
                />
              </div>

              <div className="flex items-center gap-1.5 bg-emerald-50 px-3 py-1.5 rounded-xl border border-emerald-200">
                <span className="text-[11px] font-bold text-emerald-800">العملة المعتمدة:</span>
                <span className="text-xs font-black text-emerald-950">{defaultCurrency}</span>
              </div>
            </div>
          </div>

          {/* Notes Text Input Box */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs font-bold text-slate-700">
              <label className="flex items-center gap-1.5">
                <FileText size={15} className="text-emerald-600" />
                <span>صندوق نص الملاحظات (كل سطر نفقة مستقلة):</span>
              </label>
              {rawText && (
                <button
                  type="button"
                  onClick={() => {
                    setRawText('');
                    setParsedItems([]);
                    setHasParsed(false);
                  }}
                  className="text-slate-400 hover:text-rose-600 text-[11px] flex items-center gap-1 cursor-pointer"
                >
                  <RotateCcw size={12} />
                  <span>مسح النص</span>
                </button>
              )}
            </div>

            <textarea
              ref={textareaRef}
              value={rawText}
              onChange={(e) => setRawText(e.target.value)}
              placeholder={`اكتب أو الصق هنا نص الملاحظات مباشرة من هاتفك...
مثال:
شراء 20 كيس اسمنت 90000
ديزل للمولد 25000
10-10-2026 غداء العمال 14500
حساب المعلم سالم 35000`}
              rows={4}
              className="w-full p-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-slate-800 text-xs sm:text-sm font-medium focus:outline-hidden focus:border-emerald-500 focus:bg-white transition-all resize-y leading-relaxed"
            />

            <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
              <span className="text-[11px] text-slate-400">
                {rawText ? `عدد الأسطر المدخلة: ${rawText.split('\n').filter(Boolean).length} سطر` : 'الصق النص من تطبيق الملاحظات ثم اضغط الزر الأخضر بالأسفل'}
              </span>

              <button
                type="button"
                onClick={() => runParse()}
                disabled={!rawText.trim()}
                className="py-2.5 px-5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 disabled:opacity-50 text-white font-extrabold text-xs sm:text-sm rounded-xl shadow-md shadow-emerald-600/20 transition-all flex items-center gap-2 cursor-pointer active:scale-98"
              >
                <Sparkles size={16} />
                <span>تحليل واستخراج النفقات الآن</span>
              </button>
            </div>
          </div>

          {/* Staging / Review Table Section */}
          {hasParsed && (
            <div className="space-y-3 pt-3 border-t border-slate-100 animate-fade-in">
              
              {/* Review Header Bar & Navigation Controller */}
              <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-50 p-3 rounded-2xl border border-slate-200/80">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
                  <h4 className="font-extrabold text-slate-800 text-xs sm:text-sm">
                    النفقات المستخرجة للمراجعة ({parsedItems.length} بند)
                  </h4>
                  <span className="text-[11px] text-slate-500">
                    (المحدد للاستيراد: {selectedItems.length})
                  </span>
                </div>

                <div className="flex flex-wrap items-center gap-1.5 sm:gap-2">
                  {/* Smooth horizontal & vertical navigation buttons */}
                  <div className="flex items-center bg-white border border-slate-200 rounded-xl p-0.5 shadow-2xs">
                    <button
                      type="button"
                      onClick={() => scrollTable('right')}
                      className="p-1.5 text-slate-500 hover:text-emerald-700 hover:bg-emerald-50 rounded-lg transition-colors cursor-pointer"
                      title="تمرير لليمين"
                    >
                      <ChevronRight size={15} />
                    </button>
                    <button
                      type="button"
                      onClick={() => scrollTable('left')}
                      className="p-1.5 text-slate-500 hover:text-emerald-700 hover:bg-emerald-50 rounded-lg transition-colors cursor-pointer"
                      title="تمرير لليسار"
                    >
                      <ChevronLeft size={15} />
                    </button>
                    <div className="w-px h-4 bg-slate-200 mx-0.5" />
                    <button
                      type="button"
                      onClick={() => scrollTable('up')}
                      className="p-1.5 text-slate-500 hover:text-emerald-700 hover:bg-emerald-50 rounded-lg transition-colors cursor-pointer"
                      title="تمرير لأعلى"
                    >
                      <ArrowUp size={14} />
                    </button>
                    <button
                      type="button"
                      onClick={() => scrollTable('down')}
                      className="p-1.5 text-slate-500 hover:text-emerald-700 hover:bg-emerald-50 rounded-lg transition-colors cursor-pointer"
                      title="تمرير لأسفل"
                    >
                      <ArrowDown size={14} />
                    </button>
                  </div>

                  <button
                    type="button"
                    onClick={handleAddNewItem}
                    className="py-1.5 px-3 bg-white hover:bg-slate-100 text-slate-700 font-bold text-xs rounded-xl border border-slate-200 transition-colors flex items-center gap-1 cursor-pointer shadow-2xs"
                  >
                    <Plus size={14} className="text-emerald-600" />
                    <span>إضافة بند يدوي</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleToggleSelectAll(parsedItems.some(i => !i.selected))}
                    className="py-1.5 px-3 bg-white hover:bg-slate-100 text-slate-700 font-bold text-xs rounded-xl border border-slate-200 transition-colors cursor-pointer shadow-2xs"
                  >
                    {parsedItems.every(i => i.selected) ? 'إلغاء تحديد الكل' : 'تحديد الكل'}
                  </button>
                </div>
              </div>

              {/* Helper indicator banner for smooth scrolling */}
              <div className="flex items-center justify-between px-2 text-[11px] text-slate-500 font-medium">
                <span>💡 يمكنك التمرير أفقياً وعمودياً (أعلى/أسفل ويمين/يسار) لاستعراض وتعديل كافة الحقول.</span>
                <span className="text-emerald-700 font-bold bg-emerald-50 border border-emerald-200/60 px-2 py-0.5 rounded-md text-[10px]">
                  تمرير سلس ⬌ ⬍
                </span>
              </div>

              {parsedItems.length === 0 ? (
                <div className="text-center py-8 text-slate-400 bg-slate-50 rounded-2xl border border-dashed border-slate-200">
                  <AlertCircle size={32} className="mx-auto text-amber-500 mb-2" />
                  <p className="text-xs font-bold text-slate-600">لم يتم استخراج أي بنود من النص الحالي</p>
                  <p className="text-[11px] text-slate-400 mt-1">تأكد من احتواء الأسطر على أرقام المبالغ، أو قم بإضافة بند يدوي من الزر بالأعلى.</p>
                </div>
              ) : (
                <div 
                  ref={tableScrollRef}
                  className="overflow-x-auto overflow-y-auto max-h-[380px] border border-slate-200/90 rounded-2xl bg-white shadow-xs scroll-smooth"
                  style={{
                    WebkitOverflowScrolling: 'touch',
                    overscrollBehavior: 'contain',
                    touchAction: 'pan-x pan-y',
                    scrollbarWidth: 'thin'
                  }}
                >
                  <table data-table-id="notes-import-preview-table" className="w-full text-right text-xs divide-y divide-slate-100 border-separate border-spacing-0 resizable-data-table">
                    <thead className="bg-slate-100/95 backdrop-blur-xs text-slate-700 font-extrabold sticky top-0 z-20 shadow-xs select-none">
                      <tr>
                        <th className="p-3 w-12 text-center bg-slate-100">
                          <input
                            type="checkbox"
                            checked={parsedItems.length > 0 && parsedItems.every(i => i.selected)}
                            onChange={(e) => handleToggleSelectAll(e.target.checked)}
                            className="rounded text-emerald-600 focus:ring-0 cursor-pointer"
                          />
                        </th>
                        <th className="p-3 bg-slate-100 relative break-words whitespace-normal">
                          <div className="flex items-center justify-between gap-1">
                            <span>التاريخ</span>
                            <ColumnFreezeButton columnTitle="التاريخ" />
                          </div>
                          <ColumnResizeHandle />
                        </th>
                        <th className="p-3 bg-slate-100 relative break-words whitespace-normal">
                          <div className="flex items-center justify-between gap-1">
                            <span>البيان / الوصف</span>
                            <ColumnFreezeButton columnTitle="البيان / الوصف" />
                          </div>
                          <ColumnResizeHandle />
                        </th>
                        <th className="p-3 bg-slate-100 relative break-words whitespace-normal">
                          <div className="flex items-center justify-between gap-1">
                            <span>المبلغ ({defaultCurrency})</span>
                            <ColumnFreezeButton columnTitle={`المبلغ (${defaultCurrency})`} />
                          </div>
                          <ColumnResizeHandle />
                        </th>
                        <th className="p-3 bg-slate-100 relative break-words whitespace-normal">
                          <div className="flex items-center justify-between gap-1">
                            <span>نوع النفقة (مباشرة / غير مباشرة)</span>
                            <ColumnFreezeButton columnTitle="نوع النفقة" />
                          </div>
                          <ColumnResizeHandle />
                        </th>
                        <th className="p-3 bg-slate-100 relative break-words whitespace-normal">
                          <div className="flex items-center justify-between gap-1">
                            <span>التصنيف</span>
                            <ColumnFreezeButton columnTitle="التصنيف" />
                          </div>
                          <ColumnResizeHandle />
                        </th>
                        <th className="p-3 bg-slate-100 relative break-words whitespace-normal">
                          <div className="flex items-center justify-between gap-1">
                            <span>ترحيل الحساب (اختياري)</span>
                            <ColumnFreezeButton columnTitle="ترحيل الحساب" />
                          </div>
                          <ColumnResizeHandle />
                        </th>
                        <th className="p-3 bg-slate-100 relative break-words whitespace-normal min-w-[160px]">
                          <div className="flex items-center justify-between gap-1">
                            <span>الملاحظات</span>
                            <ColumnFreezeButton columnTitle="الملاحظات" />
                          </div>
                          <ColumnResizeHandle />
                        </th>
                        <th className="p-3 w-12 text-center bg-slate-100 relative break-words whitespace-normal">
                          <div className="flex items-center justify-center gap-1">
                            <span>حذف</span>
                            <ColumnFreezeButton columnTitle="حذف" />
                          </div>
                          <ColumnResizeHandle />
                        </th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 bg-white">
                      {parsedItems.map((item) => (
                        <tr 
                          key={item.id} 
                          className={`hover:bg-emerald-50/30 transition-colors ${!item.selected ? 'opacity-40 bg-slate-50/40' : ''}`}
                        >
                          <td className="p-2.5 text-center">
                            <input
                              type="checkbox"
                              checked={item.selected}
                              onChange={() => handleToggleSelectItem(item.id)}
                              className="rounded text-emerald-600 focus:ring-0 cursor-pointer"
                            />
                          </td>
                          <td className="p-2.5">
                            <input
                              type="date"
                              value={item.date}
                              onChange={(e) => handleUpdateItem(item.id, { date: e.target.value })}
                              className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-semibold text-slate-800 focus:bg-white focus:border-emerald-500"
                            />
                          </td>
                          <td className="p-2.5">
                            <input
                              type="text"
                              value={item.description}
                              onChange={(e) => handleUpdateItem(item.id, { description: e.target.value })}
                              placeholder="البيان"
                              className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-semibold text-slate-800 focus:bg-white focus:border-emerald-500"
                            />
                          </td>
                          <td className="p-2.5">
                            <input
                              type="number"
                              min="0"
                              value={item.amount || ''}
                              onChange={(e) => handleUpdateItem(item.id, { amount: parseFloat(e.target.value) || 0 })}
                              className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-black text-slate-900 focus:bg-white focus:border-emerald-500 text-left dir-ltr"
                            />
                          </td>
                          {/* Expense Type: Direct vs Indirect with Direct as Default */}
                          <td className="p-2.5">
                            <select
                              value={item.expenseType || 'direct'}
                              onChange={(e) => handleUpdateItem(item.id, { expenseType: e.target.value as 'direct' | 'indirect' })}
                              className={`w-full p-2 border rounded-lg text-xs font-bold focus:bg-white cursor-pointer transition-colors ${
                                item.expenseType === 'indirect'
                                  ? 'bg-amber-50/80 border-amber-300 text-amber-900'
                                  : 'bg-emerald-50/80 border-emerald-300 text-emerald-900'
                              }`}
                            >
                              <option value="direct">نفقات مباشرة (افتراضي)</option>
                              <option value="indirect">نفقات غير مباشرة</option>
                            </select>
                          </td>
                          {/* Category: Strictly from availableCategories defined in Add Expense */}
                          <td className="p-2.5">
                            <select
                              value={item.category}
                              onChange={(e) => handleUpdateItem(item.id, { category: e.target.value })}
                              className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-bold text-slate-800 focus:bg-white cursor-pointer"
                            >
                              {safeCategories.map(c => (
                                <option key={c} value={c}>{c}</option>
                              ))}
                            </select>
                          </td>
                          {/* Posting Account */}
                          <td className="p-2.5 min-w-[200px]">
                            <PostingAccountSelect
                              value={item.recipientType !== 'none' ? `${item.recipientType}:${item.recipientId}` : ''}
                              onChange={(val) => {
                                if (!val || val === 'none') {
                                  handleUpdateItem(item.id, { recipientType: 'none', recipientId: '', recipientName: '' });
                                } else {
                                  const [type, id] = val.split(':') as ['worker' | 'supplier' | 'employee', string];
                                  let name = '';
                                  let autoCategoryUpdates: Partial<ParsedExpenseItem> = {};
                                  if (type === 'worker') {
                                    const w = safeWorkers.find(x => x.id === id);
                                    if (w) name = w.name;
                                    const wrkCat = safeCategories.find(c => c === 'أجور وعمالة') || 'أجور وعمالة';
                                    autoCategoryUpdates = { category: wrkCat, categories: [wrkCat] };
                                  } else if (type === 'employee') {
                                    const em = safeEmployees.find(x => x.id === id);
                                    if (em) name = em.name;
                                    const empCat = safeCategories.find(c => c === 'مرتبات وموظفين') || 'مرتبات وموظفين';
                                    autoCategoryUpdates = { category: empCat, categories: [empCat] };
                                  } else if (type === 'supplier') {
                                    const s = safeSuppliers.find(x => x.id === id);
                                    if (s) name = s.name;
                                  }
                                  handleUpdateItem(item.id, {
                                    recipientType: type,
                                    recipientId: id,
                                    recipientName: name,
                                    ...autoCategoryUpdates
                                  });
                                }
                              }}
                              workers={safeWorkers}
                              employees={safeEmployees}
                              suppliers={safeSuppliers}
                              currency={defaultCurrency}
                              sharedRole={sharedRole}
                              onAddWorker={onAddWorker}
                              onAddEmployee={onAddEmployee}
                              onAddSupplier={onAddSupplier}
                              compact={true}
                            />
                          </td>
                          {/* Notes */}
                          <td className="p-2.5 min-w-[160px]">
                            <input
                              type="text"
                              value={item.notes || ''}
                              onChange={(e) => handleUpdateItem(item.id, { notes: e.target.value })}
                              placeholder={autoNotesEnabled ? 'ملاحظات اختيارية...' : 'بدون ملاحظات'}
                              className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-medium text-slate-700 focus:bg-white focus:border-emerald-500"
                            />
                          </td>
                          <td className="p-2.5 text-center">
                            <button
                              type="button"
                              onClick={() => handleDeleteItem(item.id)}
                              className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                              title="حذف هذا البند"
                            >
                              <Trash2 size={16} />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}

              {/* Summary Bar in Default Currency */}
              {selectedItems.length > 0 && (
                <div className="bg-emerald-50/80 border border-emerald-200 p-3.5 rounded-2xl flex flex-wrap items-center justify-between gap-3 text-xs">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 size={17} className="text-emerald-700" />
                    <span className="font-extrabold text-emerald-950">
                      إجمالي العمليات المحددة للاستيراد ({selectedItems.length} عملية):
                    </span>
                  </div>
                  <div className="flex items-center gap-2 font-black text-emerald-900 text-sm">
                    <span className="bg-white/90 px-3 py-1 rounded-xl border border-emerald-300 shadow-xs">
                      {formatCurrency(totalSum, defaultCurrency)}
                    </span>
                  </div>
                </div>
              )}

              {/* Import Options: Auto Notes & Post to Ledgers */}
              <div className="pt-2 flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-t border-slate-100">
                <label className="flex items-center gap-2 cursor-pointer text-xs font-bold text-slate-700 select-none">
                  <input
                    type="checkbox"
                    checked={autoNotesEnabled}
                    onChange={(e) => handleToggleAutoNotes(e.target.checked)}
                    className="rounded text-emerald-600 focus:ring-0 cursor-pointer"
                  />
                  <span>إضافة الملاحظات التلقائية (تسجيل نص السطر في حقل الملاحظات)</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer text-xs font-bold text-slate-700 select-none">
                  <input
                    type="checkbox"
                    checked={postToLedgers}
                    onChange={(e) => setPostToLedgers(e.target.checked)}
                    className="rounded text-emerald-600 focus:ring-0 cursor-pointer"
                  />
                  <span>ترحيل النفقات المرتبطة بحسابات عمال أو موردين إلى كشوفات حساباتهم فور الاستيراد</span>
                </label>
              </div>

            </div>
          )}

        </div>

        {/* Modal Footer Actions - Android-friendly tap targets */}
        <div className="p-4 sm:p-5 border-t border-slate-100 bg-slate-50 flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={onClose}
            className="py-3 px-6 bg-white hover:bg-slate-100 active:scale-98 text-slate-700 font-extrabold text-xs sm:text-sm rounded-xl border border-slate-200 transition-colors cursor-pointer shadow-2xs"
          >
            إلغاء / إغلاق
          </button>

          <div className="flex items-center gap-2">
            {hasParsed && (
              <button
                type="button"
                onClick={handleConfirmImport}
                disabled={selectedItems.length === 0}
                className="py-3 px-6 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 disabled:opacity-50 text-white font-black text-xs sm:text-sm rounded-xl shadow-md shadow-emerald-600/20 transition-all flex items-center gap-2 cursor-pointer active:scale-98"
              >
                <Check size={18} />
                <span>
                  تأكيد واستيراد ({selectedItems.length}) نفقة إلى السجل
                </span>
              </button>
            )}
          </div>
        </div>

      </div>
    </div>
  );
};

export const NotesExpenseImportModal: React.FC<NotesExpenseImportModalProps> = (props) => {
  return (
    <NotesModalErrorBoundary isOpen={props.isOpen} onClose={props.onClose}>
      <NotesExpenseImportModalContent {...props} />
    </NotesModalErrorBoundary>
  );
};

export default NotesExpenseImportModal;
