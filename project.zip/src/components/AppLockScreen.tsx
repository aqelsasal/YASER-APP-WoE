/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { 
  Lock, 
  Unlock, 
  Fingerprint, 
  ShieldCheck, 
  KeyRound, 
  Eye, 
  EyeOff, 
  AlertCircle, 
  CheckCircle2, 
  User, 
  Building2, 
  HelpCircle,
  RefreshCw,
  Sparkles,
  ArrowRight,
  Smartphone,
  ExternalLink,
  X,
  LogOut,
  Settings
} from 'lucide-react';
import { 
  SecuritySettings, 
  getSecuritySettings, 
  saveSecuritySettings, 
  hashString, 
  generateSalt, 
  isBiometricsSupported, 
  verifyBiometricsUnlock, 
  registerBiometricsCredential,
  setAppUnlockedSession,
  openPhoneBiometricSettings
} from '../utils/securityManager';

interface AppLockScreenProps {
  onUnlockSuccess: () => void;
  onExitApp?: () => void;
  onClose?: () => void;
  companyLogo: string;
  companyName: string;
}

export default function AppLockScreen({
  onUnlockSuccess,
  onExitApp,
  onClose,
  companyLogo,
  companyName
}: AppLockScreenProps) {
  const [settings, setSettings] = useState<SecuritySettings | null>(() => getSecuritySettings());
  
  // Modes: 'unlock' | 'setup' | 'recovery'
  const [mode, setMode] = useState<'unlock' | 'setup' | 'recovery'>(() => {
    const s = getSecuritySettings();
    return s && s.enabled ? 'unlock' : 'setup';
  });

  // Unlock state
  const [inputPassword, setInputPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isVerifying, setIsVerifying] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [showOpenSettingsBtn, setShowOpenSettingsBtn] = useState(false);
  const [isBiometricAvailable, setIsBiometricAvailable] = useState(false);
  const [shakeKey, setShakeKey] = useState(0);

  // Setup Wizard state
  const [setupUsername, setSetupUsername] = useState('مدير النظام');
  const [setupPassword, setSetupPassword] = useState('');
  const [setupPasswordConfirm, setSetupPasswordConfirm] = useState('');
  const [setupEnableBiometrics, setSetupEnableBiometrics] = useState(true);
  const [setupBiometricRegistered, setSetupBiometricRegistered] = useState(false);
  const [setupCredentialId, setSetupCredentialId] = useState<string | undefined>(undefined);
  const [setupSecurityQuestion, setSetupSecurityQuestion] = useState('ما هو اسم المدينة أو المشروع المفضل؟');
  const [setupSecurityAnswer, setSetupSecurityAnswer] = useState('');
  const [setupSuccessNotice, setSetupSuccessNotice] = useState<string | null>(null);

  // Recovery state
  const [recoveryAnswerInput, setRecoveryAnswerInput] = useState('');
  const [newPasswordInput, setNewPasswordInput] = useState('');
  const [newPasswordConfirmInput, setNewPasswordConfirmInput] = useState('');
  const [recoveryError, setRecoveryError] = useState<string | null>(null);

  const passwordInputRef = useRef<HTMLInputElement>(null);
  const isRunningInIframe = typeof window !== 'undefined' && window.self !== window.top;

  // Check device biometrics support
  useEffect(() => {
    isBiometricsSupported().then(supported => {
      setIsBiometricAvailable(supported);
    });
  }, []);

  // Focus password field on unlock mode
  useEffect(() => {
    if (mode === 'unlock') {
      const timer = setTimeout(() => {
        passwordInputRef.current?.focus();
      }, 300);
      return () => clearTimeout(timer);
    }
  }, [mode]);

  // Handler: Cancel & Exit the App entirely (لا يمكن الدخول للتطبيق مالم يدخل البصمة أو كلمة السر)
  const handleExitAppAction = () => {
    if (onExitApp) {
      onExitApp();
    } else if (onClose) {
      onClose();
    }
    setTimeout(() => {
      setErrorMessage('تم قفل التطبيق لحماية البيانات. للخروج يرجى إغلاق علامة تبويب المتصفح أو التطبيق.');
    }, 350);
  };

  // Handler: Unlock with Biometrics (Samsung / Android Fingerprint / Face ID)
  const handleBiometricUnlock = async () => {
    if (!settings) return;
    setIsVerifying(true);
    setErrorMessage(null);
    setShowOpenSettingsBtn(false);

    try {
      // 1. If biometric credential is not registered yet on this device/domain, register and unlock
      if (!settings.biometricCredentialId) {
        const regRes = await registerBiometricsCredential(settings.username);
        if (regRes.success && regRes.credentialId) {
          const updated: SecuritySettings = {
            ...settings,
            biometricsEnabled: true,
            biometricCredentialId: regRes.credentialId
          };
          saveSecuritySettings(updated);
          setSettings(updated);
          setAppUnlockedSession(true);
          onUnlockSuccess();
          return;
        } else {
          setErrorMessage(regRes.error || 'تعذر تشغيل مستشعر البصمة على الهاتف.');
          if (regRes.needEnrollment || regRes.error?.includes('إعدادات الهاتف')) {
            setShowOpenSettingsBtn(true);
          }
          setShakeKey(prev => prev + 1);
          return;
        }
      }

      // 2. Try verifying existing credential
      const res = await verifyBiometricsUnlock(settings.biometricCredentialId);
      if (res.success) {
        setAppUnlockedSession(true);
        onUnlockSuccess();
      } else {
        if (res.needEnrollment || res.error?.includes('إعدادات الهاتف')) {
          setShowOpenSettingsBtn(true);
        }

        // If stored credential was from another domain/URL or was reset, attempt re-registration
        if (res.error?.includes('لم يتم التعرف') || res.error?.includes('تجديد') || res.error?.includes('InvalidStateError')) {
          const regRes = await registerBiometricsCredential(settings.username);
          if (regRes.success && regRes.credentialId) {
            const updated: SecuritySettings = {
              ...settings,
              biometricsEnabled: true,
              biometricCredentialId: regRes.credentialId
            };
            saveSecuritySettings(updated);
            setSettings(updated);
            setAppUnlockedSession(true);
            onUnlockSuccess();
            return;
          }
        }

        if (res.error && !res.error.includes('إلغاء')) {
          setErrorMessage(res.error);
          setShakeKey(prev => prev + 1);
        }
      }
    } catch (err: any) {
      console.warn('Biometric unlock exception:', err);
      setErrorMessage('تعذر الاتصال بمستشعر بصمة الهاتف.');
    } finally {
      setIsVerifying(false);
    }
  };

  // Handler: Unlock with Password
  const handlePasswordSubmit = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!settings) return;
    if (!inputPassword) {
      setErrorMessage('يرجى إدخال كلمة المرور.');
      setShakeKey(prev => prev + 1);
      return;
    }

    setIsVerifying(true);
    setErrorMessage(null);

    try {
      const hash = await hashString(inputPassword, settings.passwordSalt);
      if (hash === settings.passwordHash) {
        setAppUnlockedSession(true);
        onUnlockSuccess();
      } else {
        setErrorMessage('كلمة المرور غير صحيحة، يرجى المحاولة مجدداً.');
        setShakeKey(prev => prev + 1);
        setInputPassword('');
        passwordInputRef.current?.focus();
      }
    } catch {
      setErrorMessage('حدث خطأ أثناء التحقق.');
    } finally {
      setIsVerifying(false);
    }
  };

  // Handler: Register Biometrics during Setup Wizard
  const handleTestAndRegisterBiometric = async () => {
    setIsVerifying(true);
    setErrorMessage(null);
    setShowOpenSettingsBtn(false);
    try {
      const res = await registerBiometricsCredential(setupUsername);
      if (res.success && res.credentialId) {
        setSetupCredentialId(res.credentialId);
        setSetupBiometricRegistered(true);
        setSetupEnableBiometrics(true);
        setSetupSuccessNotice('تم تسجيل البصمة بنجاح على هذا الجهاز! يمكنك استخدامها فوراً لفتح التطبيق.');
      } else {
        setErrorMessage(res.error || 'فشل تسجيل البصمة.');
        if (res.needEnrollment || res.error?.includes('إعدادات الهاتف')) {
          setShowOpenSettingsBtn(true);
        }
      }
    } catch (err: any) {
      setErrorMessage('حدث خطأ أثناء تسجيل البصمة.');
    } finally {
      setIsVerifying(false);
    }
  };

  // Handler: Save Setup Wizard
  const handleSaveInitialSetup = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!setupUsername.trim()) {
      setErrorMessage('يرجى كتابة اسم المستخدم.');
      return;
    }
    if (!setupPassword) {
      setErrorMessage('يرجى تعيين كلمة مرور قوية.');
      return;
    }
    if (setupPassword.length < 4) {
      setErrorMessage('يجب أن تتكون كلمة المرور من 4 خانات على الأقل.');
      return;
    }
    if (setupPassword !== setupPasswordConfirm) {
      setErrorMessage('كلمتا المرور غير متطابقتين.');
      return;
    }
    if (!setupSecurityAnswer.trim()) {
      setErrorMessage('يرجى كتابة إجابة سؤال الأمان لاستعادة الحساب في حال نسيان كلمة المرور.');
      return;
    }

    setIsVerifying(true);
    try {
      const passwordSalt = generateSalt();
      const passwordHash = await hashString(setupPassword, passwordSalt);

      const answerSalt = generateSalt();
      const securityAnswerHash = await hashString(setupSecurityAnswer.trim().toLowerCase(), answerSalt);

      const newSettings: SecuritySettings = {
        enabled: true,
        username: setupUsername.trim(),
        passwordHash,
        passwordSalt,
        biometricsEnabled: setupEnableBiometrics,
        biometricCredentialId: setupCredentialId,
        autoLockIntervalMinutes: 0, // Immediately on blur/reload
        securityQuestion: setupSecurityQuestion,
        securityAnswerHash,
        securityAnswerSalt: answerSalt
      };

      saveSecuritySettings(newSettings);
      setSettings(newSettings);
      setAppUnlockedSession(true);
      onUnlockSuccess();
    } catch {
      setErrorMessage('فشل حفظ إعدادات الأمان.');
    } finally {
      setIsVerifying(false);
    }
  };

  // Handler: Verify Recovery & Reset Password
  const handleRecoverPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!settings) return;
    setRecoveryError(null);

    if (!recoveryAnswerInput.trim()) {
      setRecoveryError('يرجى كتابة إجابة سؤال الأمان.');
      return;
    }
    if (!newPasswordInput || newPasswordInput.length < 4) {
      setRecoveryError('كلمة المرور الجديدة يجب أن تكون 4 خانات على الأقل.');
      return;
    }
    if (newPasswordInput !== newPasswordConfirmInput) {
      setRecoveryError('كلمتا المرور غير متطابقتين.');
      return;
    }

    try {
      const answerHash = await hashString(
        recoveryAnswerInput.trim().toLowerCase(), 
        settings.securityAnswerSalt || ''
      );

      if (answerHash !== settings.securityAnswerHash) {
        setRecoveryError('إجابة سؤال الأمان غير صحيحة.');
        return;
      }

      // Answer is correct! Update password
      const newSalt = generateSalt();
      const newHash = await hashString(newPasswordInput, newSalt);

      const updatedSettings: SecuritySettings = {
        ...settings,
        passwordHash: newHash,
        passwordSalt: newSalt
      };

      saveSecuritySettings(updatedSettings);
      setSettings(updatedSettings);
      setAppUnlockedSession(true);
      onUnlockSuccess();
    } catch {
      setRecoveryError('حدث خطأ أثناء التحقق من إجابة الأمان.');
    }
  };

  return (
    <div 
      className="fixed inset-0 z-[9999] bg-slate-950 flex flex-col items-center justify-center p-4 overflow-y-auto dir-rtl text-right select-none app-mobile-safe-header"
      style={{
        backgroundImage: 'radial-gradient(ellipse at top, #1e293b 0%, #090d16 100%)'
      }}
    >
      {/* Background Glow Accents */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-10 right-1/4 w-72 h-72 bg-sky-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Main Lock Container */}
      <div 
        key={shakeKey}
        className={`relative z-10 w-full max-w-md bg-slate-900/90 border border-slate-700/80 rounded-3xl p-6 sm:p-8 shadow-2xl backdrop-blur-md flex flex-col items-center transition-all ${
          errorMessage ? 'animate-shake' : ''
        }`}
      >
        {/* Company Header */}
        <div className="flex flex-col items-center text-center mb-6">
          <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-white p-1.5 shadow-lg border border-slate-700 flex items-center justify-center mb-3">
            <img src={companyLogo} alt="شعار الشركة" className="w-full h-full object-contain" />
          </div>
          <h1 className="text-base sm:text-lg font-black text-white tracking-tight leading-snug">
            {companyName}
          </h1>
          <p className="text-xs text-amber-400 font-bold mt-0.5 flex items-center gap-1.5 justify-center">
            <ShieldCheck size={15} />
            نظام الحماية وقفل التطبيق
          </p>
        </div>

        {/* ========================================================================= */}
        {/* CASE 1: UNLOCK SCREEN (شاشة فتح القفل المعتادة)                            */}
        {/* ========================================================================= */}
        {mode === 'unlock' && settings && (
          <div className="w-full space-y-4">
            {/* User Badge */}
            <div className="flex items-center justify-between bg-slate-800/80 border border-slate-700/60 rounded-2xl py-2 px-3.5 text-xs font-bold text-slate-200">
              <div className="flex items-center gap-2">
                <User size={15} className="text-amber-400" />
                <span>المستخدم:</span>
                <span className="text-white font-extrabold">{settings.username}</span>
              </div>
              <span className="text-[10px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-2 py-0.5 rounded-full font-bold">
                حساب مؤمّن 🔒
              </span>
            </div>

            {/* Password Form */}
            <form onSubmit={handlePasswordSubmit} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  كلمة المرور الرئيسية
                </label>
                <div className="relative">
                  <input
                    ref={passwordInputRef}
                    type={showPassword ? 'text' : 'password'}
                    value={inputPassword}
                    onChange={(e) => setInputPassword(e.target.value)}
                    placeholder="••••••••"
                    dir="ltr"
                    className="w-full bg-slate-950 border border-slate-700 focus:border-amber-400 focus:ring-2 focus:ring-amber-400/20 rounded-xl py-3 px-4 text-center font-mono text-base text-white tracking-widest outline-none transition-all placeholder:text-slate-600"
                    autoComplete="current-password"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white transition-colors cursor-pointer p-1"
                    title={showPassword ? 'إخفاء كلمة المرور' : 'إظهار كلمة المرور'}
                  >
                    {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                  </button>
                </div>
              </div>

              {/* Error Message */}
              {errorMessage && (
                <div className="flex flex-col gap-2 p-2.5 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs font-bold animate-fade-in">
                  <div className="flex items-center gap-2">
                    <AlertCircle size={16} className="shrink-0 text-rose-400" />
                    <span>{errorMessage}</span>
                  </div>
                  {showOpenSettingsBtn && (
                    <button
                      type="button"
                      onClick={() => openPhoneBiometricSettings()}
                      className="mt-1 px-3 py-2 bg-amber-500/20 hover:bg-amber-500/30 text-amber-200 border border-amber-500/40 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xs"
                    >
                      <Settings size={14} className="text-amber-400" />
                      <span>فتح إعدادات البصمة بهاتفك الآن</span>
                    </button>
                  )}
                </div>
              )}

              {/* Submit Unlock Button */}
              <button
                type="submit"
                disabled={isVerifying || !inputPassword}
                className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black text-sm flex items-center justify-center gap-2 transition-all cursor-pointer shadow-lg shadow-amber-500/20 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed"
                id="password-unlock-submit-btn"
              >
                {isVerifying && !settings.biometricsEnabled ? (
                  <>
                    <RefreshCw size={18} className="animate-spin" />
                    <span>جاري التحقق...</span>
                  </>
                ) : (
                  <>
                    <Unlock size={18} />
                    <span>فتح التطبيق بكلمة المرور</span>
                  </>
                )}
              </button>
            </form>

            {/* Divider if Biometrics is present */}
            {settings.biometricsEnabled && (
              <div className="relative flex py-1 items-center">
                <div className="flex-grow border-t border-slate-800"></div>
                <span className="shrink-0 mx-3 text-[11px] text-slate-500 font-bold">أو الدخول المباشر بالبصمة</span>
                <div className="flex-grow border-t border-slate-800"></div>
              </div>
            )}

            {/* 📱 ERGONOMIC BIOMETRIC SENSOR ZONE AT BOTTOM (Optimized for Galaxy S22 Ultra & Android In-Display Scanners) */}
            {settings.biometricsEnabled && (
              <div className="w-full bg-slate-950/70 border border-amber-500/30 rounded-2xl p-4 flex flex-col items-center justify-center space-y-2.5 shadow-inner">
                
                {/* Visual phone guidance */}
                <div className="flex items-center gap-1.5 text-[11px] font-bold text-amber-300/90 text-center">
                  <Smartphone size={14} className="text-amber-400 shrink-0" />
                  <span>مستشعر هاتف Samsung Galaxy أسفل الشاشة</span>
                </div>

                {/* Tactile Lower Fingerprint Trigger Button */}
                <button
                  type="button"
                  onClick={handleBiometricUnlock}
                  disabled={isVerifying}
                  className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-b from-amber-500/25 via-amber-600/15 to-transparent border-2 border-amber-400/80 hover:border-amber-300 text-amber-200 hover:text-white transition-all cursor-pointer shadow-lg shadow-amber-500/20 active:scale-95 disabled:opacity-50 flex items-center justify-center gap-3 group relative overflow-hidden"
                  id="biometric-unlock-main-btn"
                >
                  <div className="relative">
                    <Fingerprint size={28} className="stroke-[2.2] group-hover:scale-115 transition-transform text-amber-400" />
                    {isVerifying ? (
                      <span className="absolute -inset-1 rounded-full border-2 border-amber-300 animate-spin pointer-events-none" />
                    ) : (
                      <span className="absolute -inset-1 rounded-full border border-amber-400/40 animate-ping pointer-events-none" />
                    )}
                  </div>
                  
                  <div className="text-right flex flex-col">
                    <span className="text-xs sm:text-sm font-black text-white group-hover:text-amber-200 transition-colors">
                      {isVerifying ? 'جاري تفعيل قارئ البصمة...' : 'اضغط هنا لتفعيل مستشعر بصمة الهاتف'}
                    </span>
                    <span className="text-[10px] text-amber-300/70 font-semibold">
                      {isVerifying ? 'ضع إصبعك على المستشعر المضيء أسفل الشاشة' : 'سيطلب الهاتف لمس مستشعر البصمة أسفل الشاشة'}
                    </span>
                  </div>
                </button>

                <p className="text-[10.5px] text-slate-400 text-center leading-relaxed px-1">
                  💡 <strong>ملاحظة لهاتفك:</strong> اضغط الزر أعلاه ليقوم نظام أندرويد بإضاءة حساس البصمة الفعلي في أسفل الشاشة للمس إصبعك مباشرة.
                </p>

                {isRunningInIframe && (
                  <button
                    type="button"
                    onClick={() => window.open(window.location.href, '_blank')}
                    className="w-full py-2 px-3 bg-amber-500/10 hover:bg-amber-500/20 border border-amber-400/30 rounded-xl text-amber-300 text-xs font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <ExternalLink size={14} />
                    <span>فتح التطبيق في شاشة كاملة لتشغيل مستشعر بصمة الهاتف مباشرة</span>
                  </button>
                )}
              </div>
            )}

            {/* Forgot Password Link */}
            {settings.securityQuestion && (
              <div className="text-center pt-1">
                <button
                  type="button"
                  onClick={() => {
                    setErrorMessage(null);
                    setMode('recovery');
                  }}
                  className="text-xs text-slate-400 hover:text-amber-300 transition-colors underline cursor-pointer"
                >
                  نسيت كلمة المرور؟ استعادة عبر سؤال الأمان
                </button>
              </div>
            )}

            {/* Single dedicated Exit / Cancel App Button */}
            {(onExitApp || onClose) && (
              <div className="pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={handleExitAppAction}
                  className="w-full py-2.5 px-4 rounded-xl bg-slate-800/80 hover:bg-rose-950/40 text-slate-400 hover:text-rose-300 font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer border border-slate-700/60 hover:border-rose-700/60 shadow-sm active:scale-98"
                  id="unlock-exit-app-btn"
                  title="إلغاء وإغلاق التطبيق نهائياً"
                >
                  <LogOut size={15} className="rotate-180 text-rose-400" />
                  <span>إلغاء وإغلاق التطبيق</span>
                </button>
              </div>
            )}
          </div>
        )}

        {/* ========================================================================= */}
        {/* CASE 2: INITIAL SETUP WIZARD (إعداد الحماية لأول مرة)                     */}
        {/* ========================================================================= */}
        {mode === 'setup' && (
          <div className="w-full space-y-4">
            <div className="bg-amber-500/10 border border-amber-400/30 rounded-2xl p-3 text-center">
              <span className="text-xs font-black text-amber-300 block mb-0.5">
                تأمين التطبيق لأول مرة 🔐
              </span>
              <p className="text-[11px] text-slate-300 leading-relaxed">
                حدد اسم المستخدم وكلمة المرور لحماية كافة سجلات ومشاريع الشركة، مع إمكانية ربط بصمة هاتفك لتسجيل الدخول السريع.
              </p>
            </div>

            <form onSubmit={handleSaveInitialSetup} className="space-y-3.5">
              {/* Username */}
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  اسم المستخدم الرئيسي
                </label>
                <div className="relative">
                  <User size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="text"
                    value={setupUsername}
                    onChange={(e) => setSetupUsername(e.target.value)}
                    placeholder="مثال: مدير النظام أو اسمك"
                    className="w-full bg-slate-950 border border-slate-700 focus:border-amber-400 rounded-xl py-2.5 pr-10 pl-3 text-sm text-white outline-none"
                    required
                  />
                </div>
              </div>

              {/* Password */}
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  كلمة المرور الجديدة
                </label>
                <div className="relative">
                  <KeyRound size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={setupPassword}
                    onChange={(e) => setSetupPassword(e.target.value)}
                    placeholder="كلمة مرور من 4 خانات فأكثر"
                    dir="ltr"
                    className="w-full bg-slate-950 border border-slate-700 focus:border-amber-400 rounded-xl py-2.5 pr-10 pl-10 text-sm text-white text-right outline-none font-mono"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white p-1"
                  >
                    {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                </div>
              </div>

              {/* Password Confirm */}
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  تأكيد كلمة المرور
                </label>
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={setupPasswordConfirm}
                  onChange={(e) => setSetupPasswordConfirm(e.target.value)}
                  placeholder="أعد إدخال كلمة المرور"
                  dir="ltr"
                  className="w-full bg-slate-950 border border-slate-700 focus:border-amber-400 rounded-xl py-2.5 px-3 text-sm text-white text-right outline-none font-mono"
                  required
                />
              </div>

              {/* Biometrics Setup Box */}
              {isBiometricAvailable ? (
                <div className="p-3 bg-slate-800/80 border border-slate-700 rounded-xl space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-white flex items-center gap-1.5">
                      <Fingerprint size={16} className="text-amber-400" />
                      فتح القفل بالبصمة (الهاتف)
                    </span>
                    <input
                      type="checkbox"
                      id="enable-biometrics-checkbox"
                      checked={setupEnableBiometrics}
                      onChange={(e) => setSetupEnableBiometrics(e.target.checked)}
                      className="w-4 h-4 accent-amber-500 cursor-pointer"
                    />
                  </div>
                  <p className="text-[10.5px] text-slate-400 leading-normal">
                    يتيح لك فتح التطبيق مباشرة ببصمة الإصبع أو بصمة الوجه دون كتابة الرمز في كل مرة.
                  </p>
                  {setupEnableBiometrics && (
                    <button
                      type="button"
                      onClick={handleTestAndRegisterBiometric}
                      disabled={isVerifying}
                      className={`w-full py-2 px-3 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer transition-all border ${
                        setupBiometricRegistered
                          ? 'bg-emerald-500/20 text-emerald-300 border-emerald-400/40'
                          : 'bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border-amber-400/40'
                      }`}
                    >
                      {setupBiometricRegistered ? (
                        <>
                          <CheckCircle2 size={15} />
                          <span>تم تسجيل البصمة بنجاح على هذا الهاتف</span>
                        </>
                      ) : (
                        <>
                          <Fingerprint size={15} />
                          <span>انقر لتسجيل واختبار بصمتك الآن</span>
                        </>
                      )}
                    </button>
                  )}
                </div>
              ) : (
                <div className="p-2.5 bg-slate-800/50 border border-slate-700 rounded-xl text-[11px] text-slate-400">
                  مستشعر البصمة البيومترية غير متاح في هذا المتصفح حالياً، وسيتم الاعتماد على كلمة المرور الرئيسية.
                </div>
              )}

              {/* Security Question for Password Recovery */}
              <div className="pt-1">
                <label className="block text-xs font-bold text-slate-300 mb-1 flex items-center gap-1">
                  <HelpCircle size={14} className="text-amber-400" />
                  سؤال الأمان لاستعادة الحساب (في حال نسيان الرمز)
                </label>
                <input
                  type="text"
                  value={setupSecurityQuestion}
                  onChange={(e) => setSetupSecurityQuestion(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl py-2 px-3 text-xs text-white outline-none mb-1.5"
                  required
                />
                <input
                  type="text"
                  value={setupSecurityAnswer}
                  onChange={(e) => setSetupSecurityAnswer(e.target.value)}
                  placeholder="إجابة سؤال الأمان (احفظها جيداً)"
                  className="w-full bg-slate-950 border border-slate-700 focus:border-amber-400 rounded-xl py-2 px-3 text-xs text-white outline-none"
                  required
                />
              </div>

              {/* Messages */}
              {errorMessage && (
                <div className="flex flex-col gap-2 p-2.5 rounded-xl bg-rose-500/20 border border-rose-500/40 text-rose-300 text-xs font-bold">
                  <div className="flex items-center gap-2">
                    <AlertCircle size={15} className="shrink-0 text-rose-400" />
                    <span>{errorMessage}</span>
                  </div>
                  {showOpenSettingsBtn && (
                    <button
                      type="button"
                      onClick={() => openPhoneBiometricSettings()}
                      className="mt-1 px-3 py-1.5 bg-amber-500/20 hover:bg-amber-500/30 text-amber-200 border border-amber-500/40 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xs"
                    >
                      <Settings size={13} className="text-amber-400" />
                      <span>فتح إعدادات البصمة بهاتفك الآن</span>
                    </button>
                  )}
                </div>
              )}
              {setupSuccessNotice && (
                <div className="p-2 rounded-lg bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-bold">
                  {setupSuccessNotice}
                </div>
              )}

              {/* Submit Setup */}
              <div className="flex flex-col sm:flex-row items-stretch gap-2 pt-1">
                <button
                  type="submit"
                  disabled={isVerifying}
                  className="flex-1 py-3 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-sm flex items-center justify-center gap-2 transition-all cursor-pointer shadow-lg shadow-amber-500/25 active:scale-95"
                >
                  <ShieldCheck size={18} />
                  <span>حفظ وتفعيل الحماية الآن</span>
                </button>
                {onClose && (
                  <button
                    type="button"
                    onClick={onClose}
                    className="py-3 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white font-bold text-xs transition-colors cursor-pointer border border-slate-700 flex items-center justify-center gap-1.5"
                  >
                    <X size={15} />
                    <span>إلغاء / إغلاق</span>
                  </button>
                )}
              </div>
            </form>
          </div>
        )}

        {/* ========================================================================= */}
        {/* CASE 3: PASSWORD RECOVERY (استعادة الحساب عبر سؤال الأمان)                 */}
        {/* ========================================================================= */}
        {mode === 'recovery' && settings && (
          <div className="w-full space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <h3 className="text-xs font-bold text-amber-300 flex items-center gap-1.5">
                <HelpCircle size={16} />
                استعادة كلمة المرور
              </h3>
              <button
                type="button"
                onClick={() => setMode('unlock')}
                className="text-xs text-slate-400 hover:text-white flex items-center gap-1"
              >
                <span>رجوع</span>
                <ArrowRight size={14} />
              </button>
            </div>

            <form onSubmit={handleRecoverPassword} className="space-y-3">
              <div className="p-3 bg-slate-800/80 border border-slate-700 rounded-xl">
                <span className="text-[11px] text-slate-400 block mb-1">سؤال الأمان المسجل:</span>
                <span className="text-xs font-bold text-white block">{settings.securityQuestion}</span>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">إجابة سؤال الأمان</label>
                <input
                  type="text"
                  value={recoveryAnswerInput}
                  onChange={(e) => setRecoveryAnswerInput(e.target.value)}
                  placeholder="اكتب الإجابة التي سجلتها عند الإعداد"
                  className="w-full bg-slate-950 border border-slate-700 focus:border-amber-400 rounded-xl py-2 px-3 text-xs text-white outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">كلمة المرور الجديدة</label>
                <input
                  type="password"
                  value={newPasswordInput}
                  onChange={(e) => setNewPasswordInput(e.target.value)}
                  placeholder="كلمة مرور جديدة (4 خانات فأكثر)"
                  dir="ltr"
                  className="w-full bg-slate-950 border border-slate-700 focus:border-amber-400 rounded-xl py-2 px-3 text-xs text-white text-right outline-none font-mono"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">تأكيد كلمة المرور الجديدة</label>
                <input
                  type="password"
                  value={newPasswordConfirmInput}
                  onChange={(e) => setNewPasswordConfirmInput(e.target.value)}
                  placeholder="أعد إدخال كلمة المرور"
                  dir="ltr"
                  className="w-full bg-slate-950 border border-slate-700 focus:border-amber-400 rounded-xl py-2 px-3 text-xs text-white text-right outline-none font-mono"
                  required
                />
              </div>

              {recoveryError && (
                <div className="p-2 rounded-lg bg-rose-500/20 border border-rose-500/40 text-rose-300 text-xs font-bold">
                  {recoveryError}
                </div>
              )}

              <div className="flex flex-col sm:flex-row items-stretch gap-2 pt-1">
                <button
                  type="submit"
                  className="flex-1 py-2.5 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs flex items-center justify-center gap-1.5 cursor-pointer shadow-md"
                >
                  <CheckCircle2 size={16} />
                  <span>تعيين كلمة المرور الجديدة وفتح التطبيق</span>
                </button>
                {onClose && (
                  <button
                    type="button"
                    onClick={onClose}
                    className="py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white font-bold text-xs cursor-pointer border border-slate-700 text-center flex items-center justify-center gap-1.5"
                  >
                    <X size={15} />
                    <span>إلغاء / إغلاق</span>
                  </button>
                )}
              </div>
            </form>
          </div>
        )}

      </div>

      {/* Footer System Info */}
      <div className="relative z-10 text-center mt-4 space-y-2 text-[11px] text-slate-500">
        <div>
          <span>تطبيق الإدارة المالية والحسابات والمشاريع • ورلد أوف إيليتس</span>
        </div>
      </div>
    </div>
  );
}
