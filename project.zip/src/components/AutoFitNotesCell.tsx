/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';

interface AutoFitNotesCellProps {
  notes?: string | null;
  className?: string;
  emptyPlaceholder?: string;
  titlePrefix?: string;
}

/**
 * AutoFitNotesCell:
 * Fixed 8px font-size notes cell with smooth single-line truncation.
 * Completely eliminates dynamic resizing to avoid any flicker/vibration.
 * Clicking the note opens an elegant tooltip modal with the full note content.
 */
export const AutoFitNotesCell: React.FC<AutoFitNotesCellProps> = ({
  notes,
  className = '',
  emptyPlaceholder = '-',
  titlePrefix = 'الملاحظات'
}) => {
  const [showTooltip, setShowTooltip] = useState(false);

  const cleanNotes = (notes || '').trim();

  // Close tooltip on Escape key
  useEffect(() => {
    if (!showTooltip) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setShowTooltip(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [showTooltip]);

  if (!cleanNotes) {
    return (
      <span className="text-slate-300 select-none text-[8px] leading-tight">
        {emptyPlaceholder}
      </span>
    );
  }

  return (
    <div className="relative inline-block w-full max-w-full my-0 py-0 select-text">
      {/* 8px Static font note with truncation (no flicker, no dynamic loops) */}
      <div
        title={`${titlePrefix} (انقر للعرض كاملاً): ${cleanNotes}`}
        onClick={(e) => {
          e.stopPropagation();
          setShowTooltip(!showTooltip);
        }}
        style={{
          fontSize: '8px',
          lineHeight: '1.2',
          maxHeight: '18px'
        }}
        className={`col-notes-cell text-slate-500 hover:text-rose-600 font-normal truncate block cursor-pointer transition-colors my-0 py-0 ${className}`}
      >
        {cleanNotes}
      </div>

      {/* Tooltip Popup on Click showing the complete note */}
      {showTooltip && (
        <>
          {/* Backdrop to close tooltip */}
          <div
            className="fixed inset-0 z-50 bg-black/20 backdrop-blur-[1px]"
            onClick={(e) => {
              e.stopPropagation();
              setShowTooltip(false);
            }}
          />

          {/* Tooltip Card */}
          <div
            onClick={(e) => e.stopPropagation()}
            className="absolute z-50 bottom-full right-0 mb-1.5 w-64 sm:w-80 p-3 bg-slate-900 text-white rounded-xl shadow-2xl border border-slate-700 animate-scale-up text-right dir-rtl"
            style={{
              filter: 'drop-shadow(0 10px 20px rgba(0,0,0,0.3))'
            }}
          >
            {/* Header */}
            <div className="flex items-center justify-between border-b border-slate-700/80 pb-1.5 mb-2 text-[11px] text-slate-300 font-bold">
              <span className="flex items-center gap-1.5 text-rose-300">
                <span>📝</span>
                <span>{titlePrefix}</span>
              </span>
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  setShowTooltip(false);
                }}
                className="text-slate-400 hover:text-white px-1.5 py-0.5 rounded hover:bg-slate-800 text-xs transition-colors cursor-pointer"
                title="إغلاق"
              >
                ✕
              </button>
            </div>

            {/* Note Full Text */}
            <p className="whitespace-pre-wrap break-words text-slate-100 text-xs leading-relaxed max-h-60 overflow-y-auto select-text font-normal">
              {cleanNotes}
            </p>
          </div>
        </>
      )}
    </div>
  );
};

export default AutoFitNotesCell;
