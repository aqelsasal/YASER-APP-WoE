import React, { useState, useRef, useEffect } from 'react';
import { Calculator as CalcIcon, X, Check, ArrowLeft } from 'lucide-react';
import { tafqeet } from '../utils/tafqeet';
import { useBodyScrollLock } from '../utils/modalScrollLock';

interface CalculatorProps {
  onApply: (value: number) => void;
  className?: string;
  buttonTitle?: string;
}

/**
 * Format raw number string with thousand commas (e.g., 1000000 -> 1,000,000 or 1000.5 -> 1,000.5)
 */
export const formatDisplayNumber = (val: string): string => {
  if (!val) return '0';
  if (val === 'Error') return 'Error';

  const isNegative = val.startsWith('-');
  const cleanVal = isNegative ? val.slice(1) : val;

  const parts = cleanVal.split('.');
  const integerPart = parts[0] ? parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',') : '0';
  const hasDecimal = parts.length > 1;
  const decimalPart = hasDecimal ? '.' + parts.slice(1).join('') : '';

  return (isNegative ? '-' : '') + integerPart + decimalPart;
};

/**
 * Format math equation string to format individual numbers with commas
 */
export const formatEquation = (eq: string): string => {
  if (!eq) return '';
  return eq.replace(/\b\d+(\.\d+)?\b/g, (match) => {
    const parts = match.split('.');
    const intPart = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    return parts.length > 1 ? `${intPart}.${parts[1]}` : intPart;
  });
};

export default function Calculator({ onApply, className = '', buttonTitle = 'الآلة الحاسبة' }: CalculatorProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [display, setDisplay] = useState('');
  const [equation, setEquation] = useState('');
  const [error, setError] = useState(false);
  const popoverRef = useRef<HTMLDivElement>(null);

  // Lock body scroll when calculator popup is open
  useBodyScrollLock(isOpen);

  // Close when clicking outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (popoverRef.current && !popoverRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }
    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen]);

  // Handle keyboard events when open
  useEffect(() => {
    function handleKeyDown(e: KeyboardEvent) {
      if (!isOpen) return;

      const key = e.key;
      if (/[0-9]/.test(key)) {
        handleDigit(key);
      } else if (['+', '-', '*', '/'].includes(key)) {
        handleOperator(key);
      } else if (key === '.' || key === ',') {
        handleDigit('.');
      } else if (key === 'Enter' || key === '=') {
        e.preventDefault();
        handleCalculate();
      } else if (key === 'Backspace') {
        handleDelete();
      } else if (key === 'Escape') {
        setIsOpen(false);
      }
    }

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen, display, equation]);

  const handleDigit = (digit: string) => {
    setError(false);
    if (display === 'Error') {
      setDisplay(digit === '.' ? '0.' : digit);
      return;
    }
    if (digit === '.') {
      if (display.includes('.')) return; // prevent multiple decimal points
      if (!display) {
        setDisplay('0.');
        return;
      }
    }
    if (display === '0' && digit !== '.') {
      setDisplay(digit);
      return;
    }
    setDisplay(prev => prev + digit);
  };

  const handleZeros = (zeros: '00' | '000') => {
    setError(false);
    if (display === 'Error') {
      setDisplay('0');
      return;
    }
    if (!display || display === '0') {
      setDisplay('0');
      return;
    }
    setDisplay(prev => prev + zeros);
  };

  const handleOperator = (op: string) => {
    setError(false);
    if (display === 'Error') return;

    let currentVal = display.trim();
    if (currentVal === '' && equation !== '') {
      // If we just want to change the last operator
      const lastChar = equation.trim().slice(-1);
      if (['+', '-', '*', '/'].includes(lastChar)) {
        setEquation(prev => prev.trim().slice(0, -1) + ' ' + op + ' ');
        return;
      }
    }

    if (currentVal === '') {
      currentVal = '0';
    }

    setEquation(prev => prev + currentVal + ' ' + op + ' ');
    setDisplay('');
  };

  const handleClear = () => {
    setDisplay('');
    setEquation('');
    setError(false);
  };

  const handleDelete = () => {
    setError(false);
    if (display === 'Error') {
      setDisplay('');
      return;
    }
    setDisplay(prev => prev.slice(0, -1));
  };

  const evaluateSafely = (expr: string): number => {
    // Sanitize the expression to allow only numbers, basic math operators and dots
    const sanitized = expr.replace(/[^0-9+\-*/(). ]/g, '');
    try {
      // Using Function constructor on sanitized expression for safe simple math evaluation
      const result = new Function(`return (${sanitized})`)();
      if (typeof result === 'number' && !isNaN(result) && isFinite(result)) {
        return Number(result.toFixed(4)); // limit decimal places
      }
      throw new Error('Invalid math');
    } catch (err) {
      throw new Error('Calc error');
    }
  };

  const handleCalculate = () => {
    if (display === 'Error') return;
    
    const fullExpr = equation + (display || '0');
    if (!fullExpr.trim()) return;

    try {
      const result = evaluateSafely(fullExpr);
      setDisplay(String(result));
      setEquation('');
      setError(false);
    } catch (err) {
      setDisplay('Error');
      setError(true);
    }
  };

  const handleApplyResult = () => {
    let finalExpr = equation + (display || '0');
    if (display === 'Error') return;
    
    try {
      const result = evaluateSafely(finalExpr);
      onApply(result);
      setIsOpen(false);
    } catch (err) {
      setError(true);
      setDisplay('Error');
    }
  };

  const tafqeetText = tafqeet(display);

  return (
    <div className={`relative inline-block ${className}`} ref={popoverRef}>
      <button
        type="button"
        onClick={() => {
          setIsOpen(!isOpen);
          if (!isOpen) {
            handleClear();
          }
        }}
        title={buttonTitle}
        className="p-2 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-lg border border-slate-200 transition-all flex items-center justify-center cursor-pointer shadow-2xs hover:shadow-xs active:scale-95"
        id="calculator-toggle-btn"
      >
        <CalcIcon size={16} />
      </button>

      {isOpen && (
        <div 
          className="fixed inset-0 z-[100] bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto dir-rtl overscroll-contain animate-fade-in"
          onTouchMove={(e) => {
            if (e.target === e.currentTarget) e.preventDefault();
          }}
          onClick={() => setIsOpen(false)}
        >
          <div 
            ref={popoverRef}
            onClick={(e) => e.stopPropagation()}
            className="relative bg-white border border-slate-200/90 shadow-2xl rounded-2xl sm:rounded-3xl p-3.5 sm:p-4 w-[315px] sm:w-[335px] max-w-[95vw] animate-scale-up text-right select-none my-auto overscroll-contain flex flex-col shrink-0"
            dir="rtl"
          >
            {/* Header */}
            <div className="flex items-center justify-between border-b border-slate-100 pb-2.5 mb-2.5">
              <div className="flex items-center gap-2">
                <div className="p-1.5 bg-sky-50 text-sky-600 rounded-lg border border-sky-100">
                  <CalcIcon size={16} />
                </div>
                <div>
                  <h4 className="text-xs sm:text-sm font-extrabold text-slate-800 leading-tight">
                    الحاسبة الذكية
                  </h4>
                  <span className="text-[10px] text-slate-400 font-medium">
                    فاصلة الآلاف • أصفار سريعة
                  </span>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsOpen(false)}
                className="text-slate-400 hover:text-slate-600 hover:bg-slate-100 cursor-pointer p-1.5 rounded-lg transition-colors"
                title="إغلاق"
              >
                <X size={16} />
              </button>
            </div>

            {/* Screen Display - Enhanced with comma formatting & larger font */}
            <div className="bg-gradient-to-b from-slate-50 to-slate-100/70 border border-slate-200/80 rounded-xl sm:rounded-2xl p-2.5 sm:p-3 mb-2.5 font-mono relative min-h-[94px] flex flex-col justify-between shrink-0 shadow-inner">
              {/* Equation row */}
              <div 
                className="text-xs font-mono text-slate-400 h-[16px] truncate text-right leading-none tracking-wide"
                dir="ltr"
              >
                {formatEquation(equation) || <span className="opacity-0">-</span>}
              </div>

              {/* Number display row formatted with commas (,) for thousands and millions */}
              <div 
                className="text-xl sm:text-2xl font-black text-slate-800 break-all truncate text-right font-mono tracking-wider leading-none my-1"
                title={display || '0'}
                dir="ltr"
              >
                {formatDisplayNumber(display)}
              </div>

              {/* Tafqeet words row - Fixed reserved slot to prevent vertical shifts */}
              <div className="h-[24px] flex items-center justify-end overflow-hidden" dir="rtl">
                {tafqeetText ? (
                  <div 
                    className="text-[11px] font-bold text-amber-900 bg-amber-50/95 border border-amber-200/70 px-2 py-0.5 rounded-md text-right truncate max-w-full leading-tight animate-fade-in shadow-2xs"
                    title={tafqeetText}
                  >
                    {tafqeetText}
                  </div>
                ) : (
                  <div className="h-[24px] invisible select-none text-[10px]">
                    -
                  </div>
                )}
              </div>
            </div>

            {/* Pad Buttons Grid - Enlarged font sizes, touch targets & dedicated 00, 000 buttons */}
            <div className="grid grid-cols-4 gap-1.5 sm:gap-2 shrink-0">
              {/* Row 1: C, Backspace, Divide, Multiply */}
              <button
                type="button"
                onClick={handleClear}
                className="h-11 sm:h-12 bg-rose-50 hover:bg-rose-100 active:bg-rose-200 text-rose-600 rounded-xl transition-all cursor-pointer flex items-center justify-center font-extrabold text-sm sm:text-base active:scale-95 shadow-2xs border border-rose-100"
                title="مسح الكل (C)"
              >
                C
              </button>
              <button
                type="button"
                onClick={handleDelete}
                className="h-11 sm:h-12 bg-slate-100 hover:bg-slate-200 active:bg-slate-300 text-slate-700 rounded-xl transition-all cursor-pointer flex items-center justify-center active:scale-95 shadow-2xs border border-slate-200/60"
                title="حذف آخر رقم (⌫)"
              >
                <ArrowLeft size={18} />
              </button>
              <button
                type="button"
                onClick={() => handleOperator('/')}
                className="h-11 sm:h-12 bg-sky-50 hover:bg-sky-100 active:bg-sky-200 text-sky-700 rounded-xl transition-all cursor-pointer flex items-center justify-center font-bold font-mono text-xl sm:text-2xl active:scale-95 shadow-2xs border border-sky-100"
                title="قسمة (÷)"
              >
                ÷
              </button>
              <button
                type="button"
                onClick={() => handleOperator('*')}
                className="h-11 sm:h-12 bg-sky-50 hover:bg-sky-100 active:bg-sky-200 text-sky-700 rounded-xl transition-all cursor-pointer flex items-center justify-center font-bold font-mono text-xl sm:text-2xl active:scale-95 shadow-2xs border border-sky-100"
                title="ضرب (×)"
              >
                ×
              </button>

              {/* Row 2: 7, 8, 9, Minus */}
              <button
                type="button"
                onClick={() => handleDigit('7')}
                className="h-11 sm:h-12 bg-slate-50 hover:bg-slate-100 active:bg-slate-200 text-slate-800 rounded-xl transition-all cursor-pointer flex items-center justify-center font-bold text-base sm:text-lg active:scale-95 shadow-2xs border border-slate-200/60"
              >
                7
              </button>
              <button
                type="button"
                onClick={() => handleDigit('8')}
                className="h-11 sm:h-12 bg-slate-50 hover:bg-slate-100 active:bg-slate-200 text-slate-800 rounded-xl transition-all cursor-pointer flex items-center justify-center font-bold text-base sm:text-lg active:scale-95 shadow-2xs border border-slate-200/60"
              >
                8
              </button>
              <button
                type="button"
                onClick={() => handleDigit('9')}
                className="h-11 sm:h-12 bg-slate-50 hover:bg-slate-100 active:bg-slate-200 text-slate-800 rounded-xl transition-all cursor-pointer flex items-center justify-center font-bold text-base sm:text-lg active:scale-95 shadow-2xs border border-slate-200/60"
              >
                9
              </button>
              <button
                type="button"
                onClick={() => handleOperator('-')}
                className="h-11 sm:h-12 bg-sky-50 hover:bg-sky-100 active:bg-sky-200 text-sky-700 rounded-xl transition-all cursor-pointer flex items-center justify-center font-bold font-mono text-xl sm:text-2xl active:scale-95 shadow-2xs border border-sky-100"
                title="طرح (-)"
              >
                -
              </button>

              {/* Row 3: 4, 5, 6, Plus */}
              <button
                type="button"
                onClick={() => handleDigit('4')}
                className="h-11 sm:h-12 bg-slate-50 hover:bg-slate-100 active:bg-slate-200 text-slate-800 rounded-xl transition-all cursor-pointer flex items-center justify-center font-bold text-base sm:text-lg active:scale-95 shadow-2xs border border-slate-200/60"
              >
                4
              </button>
              <button
                type="button"
                onClick={() => handleDigit('5')}
                className="h-11 sm:h-12 bg-slate-50 hover:bg-slate-100 active:bg-slate-200 text-slate-800 rounded-xl transition-all cursor-pointer flex items-center justify-center font-bold text-base sm:text-lg active:scale-95 shadow-2xs border border-slate-200/60"
              >
                5
              </button>
              <button
                type="button"
                onClick={() => handleDigit('6')}
                className="h-11 sm:h-12 bg-slate-50 hover:bg-slate-100 active:bg-slate-200 text-slate-800 rounded-xl transition-all cursor-pointer flex items-center justify-center font-bold text-base sm:text-lg active:scale-95 shadow-2xs border border-slate-200/60"
              >
                6
              </button>
              <button
                type="button"
                onClick={() => handleOperator('+')}
                className="h-11 sm:h-12 bg-sky-50 hover:bg-sky-100 active:bg-sky-200 text-sky-700 rounded-xl transition-all cursor-pointer flex items-center justify-center font-bold font-mono text-xl sm:text-2xl active:scale-95 shadow-2xs border border-sky-100"
                title="جمع (+)"
              >
                +
              </button>

              {/* Row 4: 1, 2, 3, Decimal Point */}
              <button
                type="button"
                onClick={() => handleDigit('1')}
                className="h-11 sm:h-12 bg-slate-50 hover:bg-slate-100 active:bg-slate-200 text-slate-800 rounded-xl transition-all cursor-pointer flex items-center justify-center font-bold text-base sm:text-lg active:scale-95 shadow-2xs border border-slate-200/60"
              >
                1
              </button>
              <button
                type="button"
                onClick={() => handleDigit('2')}
                className="h-11 sm:h-12 bg-slate-50 hover:bg-slate-100 active:bg-slate-200 text-slate-800 rounded-xl transition-all cursor-pointer flex items-center justify-center font-bold text-base sm:text-lg active:scale-95 shadow-2xs border border-slate-200/60"
              >
                2
              </button>
              <button
                type="button"
                onClick={() => handleDigit('3')}
                className="h-11 sm:h-12 bg-slate-50 hover:bg-slate-100 active:bg-slate-200 text-slate-800 rounded-xl transition-all cursor-pointer flex items-center justify-center font-bold text-base sm:text-lg active:scale-95 shadow-2xs border border-slate-200/60"
              >
                3
              </button>
              <button
                type="button"
                onClick={() => handleDigit('.')}
                className="h-11 sm:h-12 bg-slate-100 hover:bg-slate-200 active:bg-slate-300 text-slate-800 rounded-xl transition-all cursor-pointer flex items-center justify-center font-black font-mono text-xl sm:text-2xl active:scale-95 shadow-2xs border border-slate-200/60"
                title="فاصلة عشرية (.)"
              >
                .
              </button>

              {/* Row 5: 0, 00, 000, Equals */}
              <button
                type="button"
                onClick={() => handleDigit('0')}
                className="h-11 sm:h-12 bg-slate-50 hover:bg-slate-100 active:bg-slate-200 text-slate-800 rounded-xl transition-all cursor-pointer flex items-center justify-center font-bold text-base sm:text-lg active:scale-95 shadow-2xs border border-slate-200/60"
              >
                0
              </button>
              <button
                type="button"
                onClick={() => handleZeros('00')}
                className="h-11 sm:h-12 bg-slate-100 hover:bg-slate-200 active:bg-slate-300 text-slate-800 rounded-xl transition-all cursor-pointer flex items-center justify-center font-black font-mono text-sm sm:text-base tracking-tight active:scale-95 shadow-2xs border border-slate-200/60"
                title="إدخال صفرين (00)"
              >
                00
              </button>
              <button
                type="button"
                onClick={() => handleZeros('000')}
                className="h-11 sm:h-12 bg-slate-100 hover:bg-slate-200 active:bg-slate-300 text-slate-800 rounded-xl transition-all cursor-pointer flex items-center justify-center font-black font-mono text-xs sm:text-sm tracking-tighter active:scale-95 shadow-2xs border border-slate-200/60"
                title="إدخال ثلاثة أصفار (000)"
              >
                000
              </button>
              <button
                type="button"
                onClick={handleCalculate}
                className="h-11 sm:h-12 bg-gradient-to-r from-sky-600 to-sky-700 hover:from-sky-700 hover:to-sky-800 active:from-sky-800 active:to-sky-900 text-white rounded-xl transition-all cursor-pointer flex items-center justify-center font-black font-mono text-xl sm:text-2xl active:scale-95 shadow-md shadow-sky-600/25"
                title="حساب النتيجة (=)"
              >
                =
              </button>
            </div>

            {/* Actions: Cancel/Close and Apply Value */}
            <div className="flex items-center gap-2 mt-3 shrink-0 pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setIsOpen(false)}
                className="flex-1 bg-slate-100 hover:bg-slate-200 text-slate-700 py-2.5 px-3 rounded-xl font-bold text-xs sm:text-sm transition-colors cursor-pointer text-center"
              >
                إلغاء / إغلاق
              </button>
              <button
                type="button"
                onClick={handleApplyResult}
                disabled={error || (!display && !equation)}
                className="flex-1 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white py-2.5 px-3 rounded-xl font-bold text-xs sm:text-sm flex items-center justify-center gap-1.5 transition-colors cursor-pointer shadow-xs hover:shadow-md"
              >
                <Check size={16} />
                <span>تطبيق المبلغ</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
