/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Phone, 
  Plus, 
  Trash2, 
  BookUser, 
  Loader2
} from 'lucide-react';
import { pickContactDirectly, cleanPhoneNumber } from '../services/contactPickerService';

// Re-export cleanPhoneNumber for external consumers
export { cleanPhoneNumber };

interface PhoneNumbersInputProps {
  phoneNumbers: string[];
  onChange: (phones: string[]) => void;
  disabled?: boolean;
  label?: string;
  helperText?: string;
}

export default function PhoneNumbersInput({
  phoneNumbers,
  onChange,
  disabled = false,
  label = 'رقم الهاتف (9 أرقام)',
  helperText = 'إدخال رقم مكون من 9 أرقام مع إمكانية إضافة أرقام أخرى'
}: PhoneNumbersInputProps) {
  // Ensure at least one element exists for rendering
  const phonesList = phoneNumbers && phoneNumbers.length > 0 ? phoneNumbers : [''];

  const [pickingSlotIndex, setPickingSlotIndex] = useState<number | null>(null);

  const handlePhoneChange = (index: number, rawVal: string) => {
    // Only allow digits and max 9 characters
    const digitsOnly = cleanPhoneNumber(rawVal);
    const updated = [...phonesList];
    updated[index] = digitsOnly;
    onChange(updated);
  };

  /**
   * Directly opens the Android native Phone Contacts screen to select a contact number.
   * Transfers immediately to device contacts without showing any intermediate in-app modal.
   */
  const handleOpenNativeContacts = async (targetIndex: number) => {
    if (disabled || pickingSlotIndex !== null) return;
    setPickingSlotIndex(targetIndex);

    try {
      const result = await pickContactDirectly();

      if (result.success && ((result.phoneNumbers && result.phoneNumbers.length > 0) || result.phoneNumber)) {
        const incomingNumbers = (result.phoneNumbers && result.phoneNumbers.length > 0) 
          ? result.phoneNumbers 
          : [result.phoneNumber!];

        const firstNumber = cleanPhoneNumber(incomingNumbers[0]) || incomingNumbers[0];
        const updated = [...phonesList];

        // Set the primary number into the targeted slot
        if (targetIndex < updated.length) {
          updated[targetIndex] = firstNumber;
        } else {
          updated.push(firstNumber);
        }

        // Import all additional numbers from this contact into subsequent slots
        for (let i = 1; i < incomingNumbers.length; i++) {
          const nextNum = cleanPhoneNumber(incomingNumbers[i]) || incomingNumbers[i];
          if (nextNum && !updated.includes(nextNum)) {
            // If there's an empty slot after targetIndex, fill it; otherwise append a new slot
            const emptyIdx = updated.findIndex((p, idx) => idx > targetIndex && p.trim() === '');
            if (emptyIdx !== -1) {
              updated[emptyIdx] = nextNum;
            } else {
              updated.push(nextNum);
            }
          }
        }

        onChange(updated);

        // Display instant confirmation toast indicating single or multiple numbers imported
        const contactLabel = result.contactName ? ` (${result.contactName})` : '';
        if (typeof window !== 'undefined' && (window as any).showToast) {
          if (incomingNumbers.length > 1) {
            (window as any).showToast(`✅ تم استيراد كافة أرقام جهة الاتصال (${incomingNumbers.length} أرقام)${contactLabel}`);
          } else {
            (window as any).showToast(`✅ تم اختيار الرقم: ${firstNumber}${contactLabel}`);
          }
        }
      } else if (!result.cancelled && result.message) {
        if (typeof window !== 'undefined' && (window as any).showToast) {
          (window as any).showToast(`⚠️ ${result.message}`);
        }
      }
    } catch (err: any) {
      console.warn('Direct contacts picker error:', err);
      if (typeof window !== 'undefined' && (window as any).showToast) {
        (window as any).showToast('⚠️ تعذر فتح جهات اتصال الهاتف.');
      }
    } finally {
      setPickingSlotIndex(null);
    }
  };

  const handleAddPhone = () => {
    onChange([...phonesList, '']);
  };

  const handleRemovePhone = (index: number) => {
    if (phonesList.length === 1) {
      onChange(['']);
    } else {
      const updated = phonesList.filter((_, i) => i !== index);
      onChange(updated);
    }
  };

  return (
    <div className="space-y-2 dir-rtl text-right">
      <div className="flex items-center justify-between">
        <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
          <Phone size={14} className="text-emerald-600" />
          <span>{label}</span>
        </label>
        {helperText && (
          <span className="text-[10px] text-slate-400 font-normal">{helperText}</span>
        )}
      </div>

      <div className="space-y-2">
        {phonesList.map((phone, idx) => {
          const isInvalid = phone.length > 0 && phone.length < 9;
          const isPickingThis = pickingSlotIndex === idx;

          return (
            <div key={idx} className="space-y-1">
              <div className="flex items-center gap-2">
                <div className="relative flex-1">
                  <input
                    type="tel"
                    inputMode="numeric"
                    maxLength={9}
                    value={phone}
                    onChange={(e) => handlePhoneChange(idx, e.target.value)}
                    disabled={disabled}
                    placeholder={idx === 0 ? "مثال: 771234567" : "رقم آخر: 731234567"}
                    className={`w-full pl-12 pr-3 py-2 bg-slate-50 border ${
                      isInvalid ? 'border-rose-400 bg-rose-50/30' : 'border-slate-200 focus:border-emerald-500'
                    } rounded-xl text-xs font-mono font-bold text-slate-800 focus:outline-hidden transition-all dir-ltr text-right`}
                  />
                  <span className={`absolute left-2.5 top-1/2 -translate-y-1/2 text-[10px] font-mono px-1.5 py-0.5 rounded-md ${
                    phone.length === 9 
                      ? 'bg-emerald-100 text-emerald-700 font-bold' 
                      : isInvalid 
                      ? 'bg-rose-100 text-rose-700 font-bold' 
                      : 'bg-slate-200 text-slate-500'
                  }`}>
                    {phone.length}/9
                  </span>
                </div>

                {!disabled && (
                  <button
                    type="button"
                    onClick={() => handleOpenNativeContacts(idx)}
                    disabled={isPickingThis}
                    className="p-2 bg-slate-100 hover:bg-emerald-50 active:scale-95 text-slate-700 hover:text-emerald-700 border border-slate-200 hover:border-emerald-300 rounded-xl transition-all cursor-pointer shrink-0 flex items-center gap-1.5 text-xs font-bold shadow-2xs disabled:opacity-60"
                    title="الانتقال مباشرة إلى جهات اتصال الهاتف لاختيار رقم"
                  >
                    {isPickingThis ? (
                      <Loader2 size={16} className="text-emerald-600 animate-spin shrink-0" />
                    ) : (
                      <BookUser size={16} className="text-emerald-600 shrink-0" />
                    )}
                    <span className="inline text-[11px] font-bold">
                      {isPickingThis ? 'جاري الفتح...' : 'جهات الاتصال'}
                    </span>
                  </button>
                )}

                {phonesList.length > 1 && !disabled && (
                  <button
                    type="button"
                    onClick={() => handleRemovePhone(idx)}
                    className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition-colors cursor-pointer shrink-0"
                    title="حذف هذا الرقم"
                  >
                    <Trash2 size={16} />
                  </button>
                )}
              </div>
              {isInvalid && (
                <p className="text-[10px] text-rose-600 font-medium pr-1">
                  * رقم الهاتف يجب أن يتكون من 9 أرقام
                </p>
              )}
            </div>
          );
        })}
      </div>

      {!disabled && (
        <button
          type="button"
          onClick={handleAddPhone}
          className="mt-1 px-3 py-1.5 text-xs font-bold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200/60 rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer"
        >
          <Plus size={14} />
          <span>إضافة رقم آخر</span>
        </button>
      )}
    </div>
  );
}

export function PhoneNumbersDisplay({ phoneNumbers, className = '' }: { phoneNumbers?: string[]; className?: string }) {
  if (!phoneNumbers || phoneNumbers.length === 0) {
    return null;
  }
  const validPhones = phoneNumbers.filter(p => p && p.trim().length > 0);
  if (validPhones.length === 0) return null;

  return (
    <div className={`flex flex-wrap items-center gap-1.5 ${className}`}>
      {validPhones.map((phone, i) => (
        <a
          key={i}
          href={`tel:${phone}`}
          onClick={(e) => e.stopPropagation()}
          className="inline-flex items-center gap-1 px-2.5 py-1 bg-slate-100 hover:bg-emerald-50 text-slate-700 hover:text-emerald-700 border border-slate-200/80 hover:border-emerald-300 rounded-lg text-xs font-mono font-bold transition-colors dir-ltr shadow-2xs"
          title="انقر للاتصال"
        >
          <Phone size={12} className="text-emerald-600 shrink-0" />
          <span>{phone}</span>
        </a>
      ))}
    </div>
  );
}
