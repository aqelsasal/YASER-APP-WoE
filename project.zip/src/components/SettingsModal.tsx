import React, { useState, useEffect, useRef } from 'react';
import { 
  Settings, 
  X, 
  Building2, 
  DollarSign, 
  Sliders, 
  Palette, 
  Database, 
  Check, 
  RefreshCw, 
  AlertTriangle, 
  User, 
  Phone, 
  MapPin, 
  Calculator, 
  Calendar,
  Eye,
  ShieldAlert,
  ArrowRight,
  FileText,
  Sun,
  Moon,
  Globe,
  PenTool,
  CheckSquare,
  Download,
  KeyRound,
  Image as ImageIcon,
  ChevronLeft,
  ChevronRight,
  Smartphone,
  ShieldCheck,
  Fingerprint,
  Upload,
  RotateCcw,
  Sparkles,
  PanelBottom,
  Plus,
  Trash2
} from 'lucide-react';
import { useBodyScrollLock } from '../utils/modalScrollLock';
import LocalStorageBackupModal from './LocalStorageBackupModal';
import CompanyLogoUploader from './CompanyLogoUploader';
import FontSizeSlider from './FontSizeSlider';
import SecuritySettingsTab from './SecuritySettingsTab';
import ReportFieldStyleEditor from './ReportFieldStyleEditor';
import { 
  getHeaderFooterConfig, 
  saveHeaderFooterConfig, 
  resetHeaderFooterConfig, 
  ReportHeaderFooterConfig,
  renderHeaderRightHtml,
  renderFooterHtml,
  SignatureSlot,
  DEFAULT_SIGNATURE_SLOTS,
  getSignatureSlots,
  saveSignatureSlots,
  renderSignatureBlocksHtml
} from '../utils/reportHeaderFooterConfig';
import { getSavedFontStep, applyFontStep } from '../utils/fontSizeManager';
import { COMPANY_LOGO_BASE64 } from '../companyLogo';
import { useLanguage } from '../i18n/LanguageContext';
import { formatDateArabic, setActiveDateFormat } from '../types';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  currency: string;
  onCurrencyChange: (newCurrency: string) => void;
  companyName: string;
  onCompanyNameChange: (name: string) => void;
  companyAddress: string;
  onCompanyAddressChange: (address: string) => void;
  companyPhone: string;
  onCompanyPhoneChange: (phone: string) => void;
  userName: string;
  onUserNameChange: (name: string) => void;
  companyLogo?: string;
  onCompanyLogoChange?: (newLogo: string) => void;
  onOpenBackupModal?: () => void;
  onResetAllData?: () => void;
  sharedRole?: string;
  onRestoreOwnerRole?: () => void;
  onOpenAndroidInstall?: () => void;
  theme?: 'light' | 'dark';
  onThemeChange?: (newTheme: 'light' | 'dark') => void;
  fontStep?: number;
  onFontStepChange?: (step: number) => void;
  onLockApp?: () => void;
  onDateFormatChange?: (newFormat: string) => void;
}

export default function SettingsModal({
  isOpen,
  onClose,
  currency,
  onCurrencyChange,
  companyName,
  onCompanyNameChange,
  companyAddress,
  onCompanyAddressChange,
  companyPhone,
  onCompanyPhoneChange,
  userName,
  onUserNameChange,
  companyLogo = COMPANY_LOGO_BASE64,
  onCompanyLogoChange,
  onOpenBackupModal,
  onResetAllData,
  sharedRole = 'owner',
  onRestoreOwnerRole,
  onOpenAndroidInstall,
  theme: externalTheme,
  onThemeChange,
  fontStep,
  onFontStepChange,
  onLockApp,
  onDateFormatChange
}: SettingsModalProps) {
  // Navigation sections order for modal swipe navigation
  const SETTINGS_SECTIONS = [
    { id: 'display', title: 'المظهر وحجم الخط واللغة' },
    { id: 'security', title: 'الأمان وقفل التطبيق' },
    { id: 'general', title: 'البيانات والشركة والترويسة' },
    { id: 'financial', title: 'الافتراضيات المالية' },
    { id: 'reports', title: 'الترويسة والتقارير' },
    { id: 'data', title: 'إدارة البيانات والنسخ' },
  ] as const;

  type SettingsSectionId = typeof SETTINGS_SECTIONS[number]['id'];

  const [activeSection, setActiveSection] = useState<SettingsSectionId>('display');

  const currentSectionIndex = SETTINGS_SECTIONS.findIndex(s => s.id === activeSection);

  const goToNextSection = () => {
    if (currentSectionIndex < SETTINGS_SECTIONS.length - 1) {
      setActiveSection(SETTINGS_SECTIONS[currentSectionIndex + 1].id);
    }
  };

  const goToPrevSection = () => {
    if (currentSectionIndex > 0) {
      setActiveSection(SETTINGS_SECTIONS[currentSectionIndex - 1].id);
    }
  };

  // 📱 Mobile Swipe & Desktop Drag Gesture Handlers
  const touchStartXRef = useRef<number>(0);
  const touchStartYRef = useRef<number>(0);
  const touchStartTimeRef = useRef<number>(0);
  const isTouchCandidateRef = useRef<boolean>(false);
  const isTouchIgnoredRef = useRef<boolean>(false);

  const handleModalTouchStart = (e: React.TouchEvent) => {
    const touch = e.touches[0];
    touchStartXRef.current = touch.clientX;
    touchStartYRef.current = touch.clientY;
    touchStartTimeRef.current = Date.now();
    isTouchCandidateRef.current = true;

    const target = e.target as HTMLElement | null;
    // Don't hijack range sliders, color pickers, or the top tabs bar track, or preview containers
    if (
      target?.closest('input[type="range"]') || 
      target?.closest('input[type="color"]') || 
      target?.closest('.modal-scroll-tabs') ||
      target?.closest('[data-no-swipe="true"]') ||
      target?.closest('[data-report-preview="true"]')
    ) {
      isTouchIgnoredRef.current = true;
    } else {
      isTouchIgnoredRef.current = false;
    }
  };

  const handleModalTouchEnd = (e: React.TouchEvent) => {
    if (!isTouchCandidateRef.current || isTouchIgnoredRef.current) {
      isTouchCandidateRef.current = false;
      isTouchIgnoredRef.current = false;
      return;
    }
    isTouchCandidateRef.current = false;

    const touch = e.changedTouches[0];
    const deltaX = touch.clientX - touchStartXRef.current;
    const deltaY = touch.clientY - touchStartYRef.current;
    const absX = Math.abs(deltaX);
    const absY = Math.abs(deltaY);

    // Dominant horizontal movement (greater than vertical and exceeds threshold)
    if (absX >= 40 && absX > absY * 1.15) {
      // Inverted direction per user preference:
      // Swiping to the right (finger moves right, deltaX > 0) advances to the NEXT section
      // Swiping to the left (finger moves left, deltaX < 0) moves back to the PREVIOUS section
      if (deltaX > 0) {
        goToNextSection();
      } else {
        goToPrevSection();
      }
    }
  };

  // Mouse Drag navigation for desktop / mouse interactions
  const mouseStartXRef = useRef<number>(0);
  const mouseStartYRef = useRef<number>(0);
  const isMouseDragRef = useRef<boolean>(false);

  const handleModalMouseDown = (e: React.MouseEvent) => {
    if (e.button !== 0) return;
    const target = e.target as HTMLElement | null;
    if (
      target?.closest('input') ||
      target?.closest('textarea') ||
      target?.closest('select') ||
      target?.closest('button') ||
      target?.closest('a') ||
      target?.closest('.modal-scroll-tabs') ||
      target?.closest('[data-no-swipe="true"]') ||
      target?.closest('[data-report-preview="true"]')
    ) {
      isMouseDragRef.current = false;
      return;
    }
    isMouseDragRef.current = true;
    mouseStartXRef.current = e.clientX;
    mouseStartYRef.current = e.clientY;
  };

  const handleModalMouseUp = (e: React.MouseEvent) => {
    if (!isMouseDragRef.current) return;
    isMouseDragRef.current = false;

    const deltaX = e.clientX - mouseStartXRef.current;
    const deltaY = e.clientY - mouseStartYRef.current;
    const absX = Math.abs(deltaX);
    const absY = Math.abs(deltaY);

    if (absX >= 45 && absX > absY * 1.15) {
      if (deltaX > 0) {
        goToNextSection();
      } else {
        goToPrevSection();
      }
    }
  };

  // Font Scale Step State
  const [currentFontStep, setCurrentFontStep] = useState<number>(() => {
    return fontStep !== undefined ? fontStep : getSavedFontStep();
  });

  useEffect(() => {
    if (fontStep !== undefined) {
      setCurrentFontStep(fontStep);
    }
  }, [fontStep]);

  const handleFontStepChange = (newStep: number) => {
    setCurrentFontStep(newStep);
    applyFontStep(newStep);
    if (onFontStepChange) {
      onFontStepChange(newStep);
    }
  };

  // References for tabs horizontal navigation
  const tabsContainerRef = useRef<HTMLDivElement>(null);
  const tabButtonRefs = useRef<{ [key: string]: HTMLButtonElement | null }>({});
  const isMouseDownRef = useRef(false);
  const startMouseXRef = useRef(0);
  const scrollLeftStartRef = useRef(0);

  // Local state for settings form
  const [tempCompanyName, setTempCompanyName] = useState(companyName);
  const [tempCompanyAddress, setTempCompanyAddress] = useState(companyAddress);
  const [tempCompanyPhone, setTempCompanyPhone] = useState(companyPhone);
  const [tempUserName, setTempUserName] = useState(userName);
  const [tempCurrency, setTempCurrency] = useState(currency);
  const [tempCompanyLogo, setTempCompanyLogo] = useState(companyLogo);

  // Official Report Header & Footer detailed configuration & sub-tab
  const [headerFooterConfig, setHeaderFooterConfig] = useState<ReportHeaderFooterConfig>(() => getHeaderFooterConfig());
  const [companySubTab, setCompanySubTab] = useState<'header' | 'footer' | 'preview'>('header');
  const logoFileInputRef = useRef<HTMLInputElement | null>(null);
  const [logoFeedback, setLogoFeedback] = useState<{ message: string; isError?: boolean } | null>(null);

  const handleLogoFileUpload = (file: File) => {
    setLogoFeedback(null);
    if (!file.type.startsWith('image/')) {
      setLogoFeedback({ message: 'يرجى اختيار ملف صورة صالح (PNG, JPG, SVG, WebP)', isError: true });
      return;
    }
    if (file.size > 8 * 1024 * 1024) {
      setLogoFeedback({ message: 'حجم الصورة كبير جداً (أقصى حد 8 ميجابايت)', isError: true });
      return;
    }
    const reader = new FileReader();
    reader.onload = (e) => {
      const result = e.target?.result as string;
      if (result) {
        setTempCompanyLogo(result);
        localStorage.setItem('site_company_custom_logo', result);
        if (onCompanyLogoChange) {
          onCompanyLogoChange(result);
        }
        // Auto sync to server to adopt as system default
        fetch('/api/set-default-logo', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ logoBase64: result })
        }).catch(() => {});

        setLogoFeedback({ message: 'تم تحميل وتعيين الشعار بنجاح وتطبيقه على كافة أجزاء النظام والتقارير!' });
        setTimeout(() => setLogoFeedback(null), 3500);
      }
    };
    reader.onerror = () => {
      setLogoFeedback({ message: 'فشل في قراءة ملف الصورة، يرجى المحاولة مرة أخرى', isError: true });
    };
    reader.readAsDataURL(file);
  };

  const handleAdoptAsDefaultLogo = async () => {
    const logoToAdopt = tempCompanyLogo || localStorage.getItem('site_company_custom_logo') || companyLogo;
    if (!logoToAdopt) return;
    try {
      const res = await fetch('/api/set-default-logo', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ logoBase64: logoToAdopt })
      });
      const data = await res.json();
      if (res.ok) {
        localStorage.setItem('site_company_custom_logo', logoToAdopt);
        setLogoFeedback({ message: '⭐ تم اعتماد هذا الشعار كشعار افتراضي رسمي ودائم للنظام بنجاح!' });
        if (typeof window !== 'undefined' && (window as any).showToast) {
          (window as any).showToast('⭐ تم اعتماد وتثبيت هذا الشعار كشعار افتراضي دائم للنظام!');
        }
      } else {
        setLogoFeedback({ message: data.error || 'حدث خطأ أثناء اعتماد الشعار', isError: true });
      }
    } catch (err: any) {
      setLogoFeedback({ message: 'تعذر الاتصال بالخادم لاعتماد الشعار', isError: true });
    }
    setTimeout(() => setLogoFeedback(null), 4000);
  };

  const handleResetCompanyLogo = () => {
    setTempCompanyLogo(COMPANY_LOGO_BASE64);
    localStorage.removeItem('site_company_custom_logo');
    if (onCompanyLogoChange) {
      onCompanyLogoChange(COMPANY_LOGO_BASE64);
    }
    setLogoFeedback({ message: 'تمت استعادة الشعار الافتراضي بنجاح!' });
    setTimeout(() => setLogoFeedback(null), 3000);
  };

  const handleResetHeaderFooterDefaults = () => {
    const defs = resetHeaderFooterConfig();
    setHeaderFooterConfig(defs);
    setTempCompanyName(defs.headerRight.companyNameAr.text);
    setTempCompanyAddress(defs.footer.address.text);
    setTempCompanyPhone(defs.footer.mobiles.text);
    setLogoFeedback({ message: 'تمت استعادة كافة نصوص وتنسيقات الترويسة والتذييل للافتراضيات بنجاح!' });
    setTimeout(() => setLogoFeedback(null), 3500);
  };

  // Additional customizable preference settings
  const [dateFormat, setDateFormat] = useState<string>(() => localStorage.getItem('site_date_format') || 'YYYY-MM-DD');
  const [decimals, setDecimals] = useState<string>(() => localStorage.getItem('site_currency_decimals') || '0');
  const [defaultWorkerWage, setDefaultWorkerWage] = useState<string>(() => localStorage.getItem('site_default_worker_wage') || '10000');
  const [defaultEmployeeSalary, setDefaultEmployeeSalary] = useState<string>(() => localStorage.getItem('site_default_employee_salary') || '150000');
  const [defaultTaxRate, setDefaultTaxRate] = useState<string>(() => localStorage.getItem('site_default_tax_rate') || '0');
  const [compactMode, setCompactMode] = useState<boolean>(() => localStorage.getItem('site_compact_mode') === 'true');

  // Reports & Header/Footer preferences
  const [showReportHeader, setShowReportHeader] = useState<boolean>(() => localStorage.getItem('site_show_report_header') !== 'false');
  const [reportFooterNotes, setReportFooterNotes] = useState<string>(() => localStorage.getItem('site_report_footer_notes') || '');
  const [showSignatureBlocks, setShowSignatureBlocks] = useState<boolean>(() => localStorage.getItem('site_show_signature_blocks') === 'true');
  const [showDesignerAttribution, setShowDesignerAttribution] = useState<boolean>(() => localStorage.getItem('site_show_designer_attribution') !== 'false');
  const [signatureSlots, setSignatureSlots] = useState<SignatureSlot[]>(() => getSignatureSlots());
  const [reportPreviewTab, setReportPreviewTab] = useState<'all' | 'header' | 'signatures' | 'notes' | 'attribution'>('all');
  const [isReportPreviewExpanded, setIsReportPreviewExpanded] = useState<boolean>(true);

  // List of preview subtabs in order for horizontal swipe navigation
  const REPORT_PREVIEW_TABS = ['all', 'header', 'signatures', 'notes', 'attribution'] as const;
  type ReportPreviewTabId = typeof REPORT_PREVIEW_TABS[number];

  const previewTabButtonRefs = useRef<{ [key: string]: HTMLButtonElement | null }>({});

  // Auto-scroll the active preview tab button into view whenever reportPreviewTab changes
  useEffect(() => {
    if (previewTabButtonRefs.current[reportPreviewTab]) {
      previewTabButtonRefs.current[reportPreviewTab]?.scrollIntoView({
        behavior: 'smooth',
        block: 'nearest',
        inline: 'center'
      });
    }
  }, [reportPreviewTab]);

  const goToNextPreviewTab = () => {
    setReportPreviewTab(prev => {
      const idx = REPORT_PREVIEW_TABS.indexOf(prev as ReportPreviewTabId);
      return REPORT_PREVIEW_TABS[(idx + 1) % REPORT_PREVIEW_TABS.length];
    });
  };

  const goToPrevPreviewTab = () => {
    setReportPreviewTab(prev => {
      const idx = REPORT_PREVIEW_TABS.indexOf(prev as ReportPreviewTabId);
      return REPORT_PREVIEW_TABS[(idx - 1 + REPORT_PREVIEW_TABS.length) % REPORT_PREVIEW_TABS.length];
    });
  };

  // 📱 Mobile Swipe & Drag Gesture Handlers specific to the Report Preview Frame
  const previewTouchStartXRef = useRef<number>(0);
  const previewTouchStartYRef = useRef<number>(0);
  const isPreviewTouchCandidateRef = useRef<boolean>(false);

  const handlePreviewTouchStart = (e: React.TouchEvent) => {
    e.stopPropagation();
    const touch = e.touches[0];
    previewTouchStartXRef.current = touch.clientX;
    previewTouchStartYRef.current = touch.clientY;
    isPreviewTouchCandidateRef.current = true;
  };

  const handlePreviewTouchEnd = (e: React.TouchEvent) => {
    e.stopPropagation();
    if (!isPreviewTouchCandidateRef.current) return;
    isPreviewTouchCandidateRef.current = false;

    const touch = e.changedTouches[0];
    const deltaX = touch.clientX - previewTouchStartXRef.current;
    const deltaY = touch.clientY - previewTouchStartYRef.current;
    const absX = Math.abs(deltaX);
    const absY = Math.abs(deltaY);

    // Dominant horizontal movement (greater than vertical and exceeds threshold)
    if (absX >= 35 && absX > absY * 1.1) {
      if (deltaX > 0) {
        goToNextPreviewTab();
      } else {
        goToPrevPreviewTab();
      }
    }
  };

  const previewMouseStartXRef = useRef<number>(0);
  const previewMouseStartYRef = useRef<number>(0);
  const isPreviewMouseDragRef = useRef<boolean>(false);

  const handlePreviewMouseDown = (e: React.MouseEvent) => {
    if (e.button !== 0) return;
    const target = e.target as HTMLElement | null;
    if (target?.closest('input') || target?.closest('textarea') || target?.closest('select') || target?.closest('a')) {
      isPreviewMouseDragRef.current = false;
      return;
    }
    e.stopPropagation();
    isPreviewMouseDragRef.current = true;
    previewMouseStartXRef.current = e.clientX;
    previewMouseStartYRef.current = e.clientY;
  };

  const handlePreviewMouseUp = (e: React.MouseEvent) => {
    if (!isPreviewMouseDragRef.current) return;
    isPreviewMouseDragRef.current = false;
    e.stopPropagation();

    const deltaX = e.clientX - previewMouseStartXRef.current;
    const deltaY = e.clientY - previewMouseStartYRef.current;
    const absX = Math.abs(deltaX);
    const absY = Math.abs(deltaY);

    if (absX >= 40 && absX > absY * 1.1) {
      if (deltaX > 0) {
        goToNextPreviewTab();
      } else {
        goToPrevPreviewTab();
      }
    }
  };

  // Appearance & Theme preferences
  const { language: currentGlobalLang, setLanguage: setGlobalLanguage } = useLanguage();
  const [theme, setTheme] = useState<'light' | 'dark'>(() => (localStorage.getItem('site_theme') as 'light' | 'dark') || externalTheme || 'light');
  const [language, setLanguage] = useState<'ar' | 'en'>(() => (localStorage.getItem('site_language') as 'ar' | 'en') || currentGlobalLang || 'ar');

  // Handle Instant Language Change with Live Preview
  const handleSelectLanguage = (newLang: 'ar' | 'en') => {
    setLanguage(newLang);
    setGlobalLanguage(newLang);
  };

  // Handle Instant Theme Change with Live Preview
  const handleSelectTheme = (newTheme: 'light' | 'dark') => {
    setTheme(newTheme);
    if (newTheme === 'dark') {
      document.documentElement.classList.add('dark');
      document.body.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
      document.body.classList.remove('dark');
    }
    if (onThemeChange) {
      onThemeChange(newTheme);
    }
  };

  // Confirm Reset modal state
  const [showConfirmReset, setShowConfirmReset] = useState(false);
  const [resetConfirmText, setResetConfirmText] = useState('');
  const [isLocalStorageBackupModalOpen, setIsLocalStorageBackupModalOpen] = useState(false);

  // Toast feedback state
  const [savedSuccess, setSavedSuccess] = useState(false);

  // Lock background scroll when settings modal is open
  useBodyScrollLock(isOpen || isLocalStorageBackupModalOpen);

  // Auto-scroll the active tab into view whenever it changes or modal opens
  useEffect(() => {
    if (isOpen && tabButtonRefs.current[activeSection]) {
      const activeBtn = tabButtonRefs.current[activeSection];
      activeBtn?.scrollIntoView({
        behavior: 'smooth',
        block: 'nearest',
        inline: 'center'
      });
    }
  }, [activeSection, isOpen]);

  useEffect(() => {
    if (isOpen) {
      setActiveSection('display');
      const loadedHdrFtr = getHeaderFooterConfig();
      setHeaderFooterConfig(loadedHdrFtr);
      setCompanySubTab('header');
      setTempCompanyName(loadedHdrFtr.headerRight?.companyNameAr?.text || companyName);
      setTempCompanyAddress(loadedHdrFtr.footer?.address?.text || companyAddress);
      setTempCompanyPhone(loadedHdrFtr.footer?.mobiles?.text || companyPhone);
      setTempUserName(userName);
      setTempCurrency(currency);
      setTempCompanyLogo(companyLogo || localStorage.getItem('site_company_custom_logo') || COMPANY_LOGO_BASE64);
      setDateFormat(localStorage.getItem('site_date_format') || 'YYYY-MM-DD');
      setDecimals(localStorage.getItem('site_currency_decimals') || '0');
      setDefaultWorkerWage(localStorage.getItem('site_default_worker_wage') || '10000');
      setDefaultEmployeeSalary(localStorage.getItem('site_default_employee_salary') || '150000');
      setDefaultTaxRate(localStorage.getItem('site_default_tax_rate') || '0');
      setCompactMode(localStorage.getItem('site_compact_mode') === 'true');
      setShowReportHeader(localStorage.getItem('site_show_report_header') !== 'false');
      setReportFooterNotes(localStorage.getItem('site_report_footer_notes') || '');
      setShowSignatureBlocks(localStorage.getItem('site_show_signature_blocks') === 'true');
      setShowDesignerAttribution(localStorage.getItem('site_show_designer_attribution') !== 'false');
      setSignatureSlots(getSignatureSlots());
      setReportPreviewTab('all');
      setTheme((localStorage.getItem('site_theme') as 'light' | 'dark') || 'light');
      setLanguage((localStorage.getItem('site_language') as 'ar' | 'en') || 'ar');
    }
  }, [isOpen, companyName, companyAddress, companyPhone, userName, currency, companyLogo]);

  // Tab horizontal scroll handlers
  const handleScrollTabs = (direction: 'left' | 'right') => {
    if (tabsContainerRef.current) {
      const offset = direction === 'left' ? -160 : 160;
      tabsContainerRef.current.scrollBy({ left: offset, behavior: 'smooth' });
    }
  };

  // Mouse drag-to-scroll listeners for tabs
  const onMouseDownTabs = (e: React.MouseEvent) => {
    if (!tabsContainerRef.current) return;
    isMouseDownRef.current = true;
    startMouseXRef.current = e.pageX - tabsContainerRef.current.offsetLeft;
    scrollLeftStartRef.current = tabsContainerRef.current.scrollLeft;
  };

  const onMouseLeaveTabs = () => {
    isMouseDownRef.current = false;
  };

  const onMouseUpTabs = () => {
    isMouseDownRef.current = false;
  };

  const onMouseMoveTabs = (e: React.MouseEvent) => {
    if (!isMouseDownRef.current || !tabsContainerRef.current) return;
    e.preventDefault();
    const currentX = e.pageX - tabsContainerRef.current.offsetLeft;
    const walk = (currentX - startMouseXRef.current) * 1.5;
    tabsContainerRef.current.scrollLeft = scrollLeftStartRef.current - walk;
  };

  if (!isOpen) return null;

  const handleSaveAllSettings = () => {
    // 0. Save Header & Footer configuration
    saveHeaderFooterConfig(headerFooterConfig);

    const activeCompName = headerFooterConfig.headerRight.companyNameAr.text || tempCompanyName;
    const activeAddress = headerFooterConfig.footer.address.text || tempCompanyAddress;
    const activePhone = headerFooterConfig.footer.mobiles.text || tempCompanyPhone;

    // 1. Update Parent State & localStorage
    onCompanyNameChange(activeCompName);
    localStorage.setItem('site_company_name', activeCompName);

    onCompanyAddressChange(activeAddress);
    localStorage.setItem('site_company_address', activeAddress);

    onCompanyPhoneChange(activePhone);
    localStorage.setItem('site_company_phone', activePhone);

    onUserNameChange(tempUserName);
    localStorage.setItem('site_user_name', tempUserName);

    onCurrencyChange(tempCurrency);
    localStorage.setItem('site_currency', tempCurrency);

    // Update Company Logo
    if (onCompanyLogoChange) {
      onCompanyLogoChange(tempCompanyLogo);
    }
    if (tempCompanyLogo && tempCompanyLogo !== COMPANY_LOGO_BASE64) {
      localStorage.setItem('site_company_custom_logo', tempCompanyLogo);
      if (tempCompanyLogo.startsWith('data:image')) {
        fetch('/api/set-default-logo', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ logoBase64: tempCompanyLogo })
        }).catch(() => {});
      }
    } else {
      localStorage.removeItem('site_company_custom_logo');
    }

    // 2. Additional preferences
    localStorage.setItem('site_date_format', dateFormat);
    setActiveDateFormat(dateFormat);
    if (onDateFormatChange) {
      onDateFormatChange(dateFormat);
    }
    localStorage.setItem('site_currency_decimals', decimals);
    localStorage.setItem('site_default_worker_wage', defaultWorkerWage);
    localStorage.setItem('site_default_employee_salary', defaultEmployeeSalary);
    localStorage.setItem('site_default_tax_rate', defaultTaxRate);
    localStorage.setItem('site_compact_mode', compactMode ? 'true' : 'false');

    // 3. Reports & Header/Footer preferences
    localStorage.setItem('site_show_report_header', showReportHeader ? 'true' : 'false');
    localStorage.setItem('site_report_footer_notes', reportFooterNotes);
    localStorage.setItem('site_show_signature_blocks', showSignatureBlocks ? 'true' : 'false');
    localStorage.setItem('site_show_designer_attribution', showDesignerAttribution ? 'true' : 'false');
    saveSignatureSlots(signatureSlots);

    // 4. Appearance & Language
    localStorage.setItem('site_theme', theme);
    localStorage.setItem('site_language', language);
    setGlobalLanguage(language);

    // Apply Theme directly
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }

    // Apply Language & Direction directly
    document.documentElement.lang = language;
    document.documentElement.dir = language === 'en' ? 'ltr' : 'rtl';

    setSavedSuccess(true);
    setTimeout(() => {
      setSavedSuccess(false);
      onClose();
      if ((window as any).showToast) {
        (window as any).showToast(
          language === 'en'
            ? '⚙️ App settings & preferences saved successfully!'
            : '⚙️ تم حفظ إعدادات وتفضيلات التطبيق والتقارير بنجاح!'
        );
      }
    }, 600);
  };

  const handleExecuteDataReset = () => {
    if (resetConfirmText.trim().toUpperCase() !== 'مسح' && resetConfirmText.trim().toUpperCase() !== 'RESET') {
      alert('يرجى كتابة كلمة "مسح" أو "RESET" لتأكيد المسح النهائي');
      return;
    }
    if (onResetAllData) {
      onResetAllData();
      setShowConfirmReset(false);
      onClose();
    }
  };

  return (
    <div 
      className="fixed inset-0 z-[120] flex items-center justify-center p-2.5 sm:p-4 bg-slate-900/80 backdrop-blur-xs animate-fade-in dir-rtl text-right overscroll-contain"
    >
      <div 
        className="bg-white rounded-2xl border border-slate-200/90 shadow-2xl w-full max-w-3xl h-[92vh] max-h-[850px] flex flex-col overflow-hidden animate-scale-up overscroll-contain"
        onClick={(e) => e.stopPropagation()}
        onTouchStart={handleModalTouchStart}
        onTouchEnd={handleModalTouchEnd}
        onMouseDown={handleModalMouseDown}
        onMouseUp={handleModalMouseUp}
      >
        
        {/* Header Modal Bar */}
        <div className="bg-slate-900 text-white p-3.5 sm:p-4 flex items-center justify-between border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-amber-500/20 text-amber-400 rounded-xl border border-amber-400/30 shrink-0">
              <Settings size={20} className="animate-spin-slow" />
            </div>
            <div>
              <h2 className="font-extrabold text-sm sm:text-base text-white">إعدادات وضبط التطبيق العامة</h2>
              <p className="text-[11px] text-slate-400 font-medium line-clamp-1">تخصيص البيانات المباشرة، افتراضيات النظام، وخيارات العرض</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition-colors cursor-pointer shrink-0"
            title="إغلاق النافذة"
          >
            <X size={20} />
          </button>
        </div>

        {/* Navigation Tabs Bar inside Modal with dedicated Arrow Buttons and Drag/Swipe Support */}
        <div className="bg-slate-100/95 border-b border-slate-200 shrink-0 flex items-center px-1 py-1 gap-1 relative shadow-2xs">
          
          {/* Scroll Right Button (in RTL, points to beginning tabs) */}
          <button
            type="button"
            onClick={() => handleScrollTabs('right')}
            title="تمرير التبويبات لليمين"
            className="p-1.5 text-slate-500 hover:text-slate-900 hover:bg-white bg-slate-200/60 rounded-lg transition-colors cursor-pointer shrink-0 shadow-2xs flex items-center justify-center"
          >
            <ChevronRight size={16} />
          </button>

          {/* Scrollable Tabs Track */}
          <div 
            ref={tabsContainerRef}
            onMouseDown={onMouseDownTabs}
            onMouseLeave={onMouseLeaveTabs}
            onMouseUp={onMouseUpTabs}
            onMouseMove={onMouseMoveTabs}
            data-scrollable-x="true"
            className="modal-scroll-tabs flex-1 flex items-center gap-1.5 overflow-x-auto touch-pan-x cursor-grab active:cursor-grabbing select-none py-1 px-1 scrollbar-thin"
            style={{ WebkitOverflowScrolling: 'touch' }}
          >
            <button
              ref={(el) => { tabButtonRefs.current['display'] = el; }}
              onClick={() => setActiveSection('display')}
              className={`py-2 px-3 sm:px-4 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer whitespace-nowrap shrink-0 ${
                activeSection === 'display'
                  ? 'bg-white text-slate-900 shadow-sm border border-slate-200/90 ring-1 ring-slate-900/5'
                  : 'text-slate-600 hover:bg-slate-200/70'
              }`}
            >
              <Palette size={15} className={activeSection === 'display' ? 'text-indigo-600' : 'text-slate-400'} />
              <span>المظهر وحجم الخط واللغة</span>
            </button>

            <button
              ref={(el) => { tabButtonRefs.current['security'] = el; }}
              onClick={() => setActiveSection('security')}
              className={`py-2 px-3 sm:px-4 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer whitespace-nowrap shrink-0 ${
                activeSection === 'security'
                  ? 'bg-white text-slate-900 shadow-sm border border-slate-200/90 ring-1 ring-slate-900/5'
                  : 'text-slate-600 hover:bg-slate-200/70'
              }`}
              id="settings-tab-security-btn"
            >
              <ShieldCheck size={15} className={activeSection === 'security' ? 'text-amber-500' : 'text-slate-400'} />
              <span>الأمان وقفل التطبيق</span>
            </button>

            <button
              ref={(el) => { tabButtonRefs.current['general'] = el; }}
              onClick={() => setActiveSection('general')}
              className={`py-2 px-3 sm:px-4 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer whitespace-nowrap shrink-0 ${
                activeSection === 'general'
                  ? 'bg-white text-slate-900 shadow-sm border border-slate-200/90 ring-1 ring-slate-900/5'
                  : 'text-slate-600 hover:bg-slate-200/70'
              }`}
            >
              <Building2 size={15} className={activeSection === 'general' ? 'text-sky-600' : 'text-slate-400'} />
              <span>البيانات والشركة والترويسة</span>
            </button>

            <button
              ref={(el) => { tabButtonRefs.current['financial'] = el; }}
              onClick={() => setActiveSection('financial')}
              className={`py-2 px-3 sm:px-4 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer whitespace-nowrap shrink-0 ${
                activeSection === 'financial'
                  ? 'bg-white text-slate-900 shadow-sm border border-slate-200/90 ring-1 ring-slate-900/5'
                  : 'text-slate-600 hover:bg-slate-200/70'
              }`}
            >
              <DollarSign size={15} className={activeSection === 'financial' ? 'text-emerald-600' : 'text-slate-400'} />
              <span>الافتراضيات المالية</span>
            </button>

            <button
              ref={(el) => { tabButtonRefs.current['reports'] = el; }}
              onClick={() => setActiveSection('reports')}
              className={`py-2 px-3 sm:px-4 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer whitespace-nowrap shrink-0 ${
                activeSection === 'reports'
                  ? 'bg-white text-slate-900 shadow-sm border border-slate-200/90 ring-1 ring-slate-900/5'
                  : 'text-slate-600 hover:bg-slate-200/70'
              }`}
            >
              <FileText size={15} className={activeSection === 'reports' ? 'text-amber-600' : 'text-slate-400'} />
              <span>الترويسة والتقارير</span>
            </button>

            <button
              ref={(el) => { tabButtonRefs.current['data'] = el; }}
              onClick={() => setActiveSection('data')}
              className={`py-2 px-3 sm:px-4 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer whitespace-nowrap shrink-0 ${
                activeSection === 'data'
                  ? 'bg-white text-slate-900 shadow-sm border border-slate-200/90 ring-1 ring-slate-900/5'
                  : 'text-slate-600 hover:bg-slate-200/70'
              }`}
            >
              <Database size={15} className={activeSection === 'data' ? 'text-rose-600' : 'text-slate-400'} />
              <span>إدارة البيانات والنسخ</span>
            </button>
          </div>

          {/* Scroll Left Button (in RTL, points to forward/later tabs) */}
          <button
            type="button"
            onClick={() => handleScrollTabs('left')}
            title="تمرير التبويبات لليسار"
            className="p-1.5 text-slate-500 hover:text-slate-900 hover:bg-white bg-slate-200/60 rounded-lg transition-colors cursor-pointer shrink-0 shadow-2xs flex items-center justify-center"
          >
            <ChevronLeft size={16} />
          </button>
        </div>

        {/* 📱 Swipe Guidance & Section Pagination Sub-bar */}
        <div className="bg-slate-50/95 border-b border-slate-200/80 px-2.5 sm:px-4 py-1.5 flex items-center justify-between text-[11px] select-none shrink-0" data-no-swipe="true">
          <button
            type="button"
            onClick={goToPrevSection}
            disabled={currentSectionIndex === 0}
            className={`py-1 px-2.5 rounded-lg flex items-center gap-1 font-bold text-xs transition-all cursor-pointer ${
              currentSectionIndex === 0
                ? 'opacity-30 cursor-not-allowed text-slate-400'
                : 'text-slate-700 bg-white hover:bg-slate-200 hover:text-slate-900 shadow-2xs active:scale-95'
            }`}
            title="القسم السابق (أو اسحب الشاشة لليسار ⬅)"
          >
            <ChevronRight size={14} />
            <span className="hidden sm:inline">السابق</span>
          </button>

          {/* Dots Indicator & Swipe Hint */}
          <div className="flex items-center gap-2">
            <span className="text-[10px] text-slate-500 font-semibold hidden sm:inline">
              👆 اسحب الشاشة للتنقل بين النوافذ:
            </span>
            <div className="flex items-center gap-1.5">
              {SETTINGS_SECTIONS.map((sec, idx) => (
                <button
                  key={sec.id}
                  type="button"
                  onClick={() => setActiveSection(sec.id)}
                  title={`${sec.title} (${idx + 1}/${SETTINGS_SECTIONS.length})`}
                  className={`transition-all rounded-full cursor-pointer ${
                    activeSection === sec.id
                      ? 'w-5 h-2 bg-slate-900 shadow-xs'
                      : 'w-2 h-2 bg-slate-300 hover:bg-slate-400'
                  }`}
                />
              ))}
            </div>
            <span className="text-[10px] font-black text-slate-700 bg-slate-200/80 px-2 py-0.5 rounded-md">
              {currentSectionIndex + 1} / {SETTINGS_SECTIONS.length}
            </span>
          </div>

          <button
            type="button"
            onClick={goToNextSection}
            disabled={currentSectionIndex === SETTINGS_SECTIONS.length - 1}
            className={`py-1 px-2.5 rounded-lg flex items-center gap-1 font-bold text-xs transition-all cursor-pointer ${
              currentSectionIndex === SETTINGS_SECTIONS.length - 1
                ? 'opacity-30 cursor-not-allowed text-slate-400'
                : 'text-slate-700 bg-white hover:bg-slate-200 hover:text-slate-900 shadow-2xs active:scale-95'
            }`}
            title="القسم التالي (أو اسحب الشاشة لليمين ➡)"
          >
            <span className="hidden sm:inline">التالي</span>
            <ChevronLeft size={14} />
          </button>
        </div>

        {/* Modal Body Content (Scrollable Vertically with smooth touch & scrollbar and Full Swipe Navigation) */}
        <div 
          data-scrollable-y="true"
          onTouchStart={handleModalTouchStart}
          onTouchEnd={handleModalTouchEnd}
          onMouseDown={handleModalMouseDown}
          onMouseUp={handleModalMouseUp}
          className="modal-scroll-area p-4 sm:p-5 overflow-y-auto touch-pan-y overscroll-contain space-y-4 flex-1 scrollbar-thin"
          style={{ WebkitOverflowScrolling: 'touch' }}
        >
          
          {/* 🏢 SECTION 1: GENERAL & COMPANY INFO AND HEADER/FOOTER */}
          {activeSection === 'general' && (
            <div className="space-y-4 animate-fade-in">
              <div className="bg-sky-50/60 p-3 rounded-xl border border-sky-200/60 flex items-center gap-2.5 text-xs text-sky-900">
                <Building2 size={16} className="text-sky-600 shrink-0" />
                <p className="font-semibold">تخصيص بيانات المؤسسة والشركة، الترويسة الرسمية، والشعار المعتمد المطبوع على كافة السندات والتقارير.</p>
              </div>

              {/* 🖼️ 1. LOGO PREVIEW & UPLOAD SECTION AT TOP OF TAB */}
              <div className="p-4 bg-gradient-to-b from-slate-50 to-white border border-slate-200 rounded-2xl shadow-2xs space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <ImageIcon size={16} className="text-[#E85D25]" />
                    <span className="text-xs font-black text-slate-800">معاينة الشعار الرسمي المعتمد في التقارير</span>
                  </div>
                  {tempCompanyLogo && tempCompanyLogo !== COMPANY_LOGO_BASE64 ? (
                    <span className="text-[10px] font-bold bg-amber-100 text-amber-800 border border-amber-300 px-2 py-0.5 rounded-full flex items-center gap-1">
                      <Sparkles size={11} />
                      شعار مخصص محفوظ
                    </span>
                  ) : (
                    <span className="text-[10px] font-bold bg-slate-100 text-slate-600 px-2 py-0.5 rounded-full">
                      الشعار الافتراضي للنظام
                    </span>
                  )}
                </div>

                {/* Centered Logo Preview Box */}
                <div className="flex items-center justify-center p-3 bg-white rounded-xl border border-dashed border-slate-300 min-h-[90px] shadow-2xs">
                  <div className="max-w-[220px] max-h-[85px] flex items-center justify-center">
                    <img
                      src={tempCompanyLogo || COMPANY_LOGO_BASE64}
                      alt="شعار الشركة"
                      className="max-h-[80px] max-w-[210px] object-contain transition-transform hover:scale-105"
                    />
                  </div>
                </div>

                {/* Feedback message banner if any */}
                {logoFeedback && (
                  <div className={`p-2 rounded-lg text-xs font-bold text-center ${
                    logoFeedback.isError ? 'bg-rose-50 text-rose-700 border border-rose-200' : 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                  }`}>
                    {logoFeedback.message}
                  </div>
                )}

                {/* Buttons underneath to change/upload logo image or restore default */}
                <div className="flex flex-wrap items-center justify-center gap-2 pt-1">
                  <input
                    type="file"
                    ref={logoFileInputRef}
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) handleLogoFileUpload(file);
                    }}
                    accept="image/*"
                    className="hidden"
                  />
                  <button
                    type="button"
                    onClick={() => logoFileInputRef.current?.click()}
                    className="px-4 py-2 bg-[#002B49] hover:bg-[#003b66] text-white text-xs font-bold rounded-xl shadow-xs transition-all flex items-center gap-1.5 cursor-pointer hover:shadow-sm"
                  >
                    <Upload size={14} />
                    <span>تغيير / تحميل صورة الشعار</span>
                  </button>

                  {tempCompanyLogo && (
                    <button
                      type="button"
                      onClick={handleAdoptAsDefaultLogo}
                      className="px-3.5 py-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white text-xs font-bold rounded-xl shadow-xs transition-all flex items-center gap-1.5 cursor-pointer hover:shadow-sm"
                      title="اعتماد هذا الشعار كشعار افتراضي رسمي ودائم للنظام في ملفات الكود"
                    >
                      <Sparkles size={14} className="text-amber-100" />
                      <span>اعتماد كشعار افتراضي دائم للنظام</span>
                    </button>
                  )}

                  {tempCompanyLogo && tempCompanyLogo !== COMPANY_LOGO_BASE64 && (
                    <button
                      type="button"
                      onClick={handleResetCompanyLogo}
                      className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl border border-slate-200 transition-all flex items-center gap-1.5 cursor-pointer"
                    >
                      <RotateCcw size={13} />
                      <span>استعادة الشعار الافتراضي</span>
                    </button>
                  )}
                </div>
              </div>

              {/* 📑 2. SUB-TABS: HEADER RIGHT DATA / FOOTER DATA / LIVE PREVIEW */}
              <div className="bg-slate-100 p-1 rounded-xl flex items-center gap-1 border border-slate-200/80">
                <button
                  type="button"
                  onClick={() => setCompanySubTab('header')}
                  className={`flex-1 py-2 px-2.5 rounded-lg text-xs font-black transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                    companySubTab === 'header'
                      ? 'bg-white text-slate-900 shadow-xs border border-slate-200'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <FileText size={14} className={companySubTab === 'header' ? 'text-sky-600' : 'text-slate-400'} />
                  <span>بيانات رأس الصفحة (الجانب الأيمن)</span>
                </button>

                <button
                  type="button"
                  onClick={() => setCompanySubTab('footer')}
                  className={`flex-1 py-2 px-2.5 rounded-lg text-xs font-black transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                    companySubTab === 'footer'
                      ? 'bg-white text-slate-900 shadow-xs border border-slate-200'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <PanelBottom size={14} className={companySubTab === 'footer' ? 'text-amber-600' : 'text-slate-400'} />
                  <span>تذييل الصفحة (الفوتر)</span>
                </button>

                <button
                  type="button"
                  onClick={() => setCompanySubTab('preview')}
                  className={`py-2 px-3 rounded-lg text-xs font-black transition-all flex items-center justify-center gap-1.5 cursor-pointer shrink-0 ${
                    companySubTab === 'preview'
                      ? 'bg-white text-slate-900 shadow-xs border border-slate-200'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <Eye size={14} className={companySubTab === 'preview' ? 'text-emerald-600' : 'text-slate-400'} />
                  <span>معاينة حية</span>
                </button>
              </div>

              {/* 📑 SUB-TAB 1: HEADER RIGHT DATA */}
              {companySubTab === 'header' && (
                <div className="space-y-3 animate-fade-in">
                  <div className="bg-sky-50/70 p-2.5 rounded-xl border border-sky-200/60 text-xs text-sky-900">
                    <p className="font-semibold">
                      البيانات في هذه الخانات تظهر في ترويسة/رأس صفحة التقارير المستخرجة كل نص أسفل بعض. النصوص الحالية هي الافتراضية، ويمكنك تخصيص كل خانة وخطها والمحاذاة واللون بشكل مستقل.
                    </p>
                  </div>

                  {/* 1. اسم الشركة بالعربي */}
                  <ReportFieldStyleEditor
                    label="1. اسم الشركة بالعربي"
                    subLabel="السطر الأول"
                    fieldKey="companyNameAr"
                    text={headerFooterConfig.headerRight.companyNameAr.text}
                    onTextChange={(newText) => {
                      setHeaderFooterConfig({
                        ...headerFooterConfig,
                        headerRight: {
                          ...headerFooterConfig.headerRight,
                          companyNameAr: {
                            ...headerFooterConfig.headerRight.companyNameAr,
                            text: newText,
                          },
                        },
                      });
                      setTempCompanyName(newText);
                    }}
                    style={headerFooterConfig.headerRight.companyNameAr.style}
                    onStyleChange={(newStyle) => {
                      setHeaderFooterConfig({
                        ...headerFooterConfig,
                        headerRight: {
                          ...headerFooterConfig.headerRight,
                          companyNameAr: {
                            ...headerFooterConfig.headerRight.companyNameAr,
                            style: newStyle,
                          },
                        },
                      });
                    }}
                    placeholder="مثال: ورلد أوف إيليتس للتجارة والمقاولات"
                  />

                  {/* 2. اسم الشركة بالإنجليزي */}
                  <ReportFieldStyleEditor
                    label="2. اسم الشركة بالإنجليزي"
                    subLabel="السطر الثاني"
                    fieldKey="companyNameEn"
                    text={headerFooterConfig.headerRight.companyNameEn.text}
                    onTextChange={(newText) => {
                      setHeaderFooterConfig({
                        ...headerFooterConfig,
                        headerRight: {
                          ...headerFooterConfig.headerRight,
                          companyNameEn: {
                            ...headerFooterConfig.headerRight.companyNameEn,
                            text: newText,
                          },
                        },
                      });
                    }}
                    style={headerFooterConfig.headerRight.companyNameEn.style}
                    onStyleChange={(newStyle) => {
                      setHeaderFooterConfig({
                        ...headerFooterConfig,
                        headerRight: {
                          ...headerFooterConfig.headerRight,
                          companyNameEn: {
                            ...headerFooterConfig.headerRight.companyNameEn,
                            style: newStyle,
                          },
                        },
                      });
                    }}
                    placeholder="Example: World of Elites for Trading & Contracting"
                  />

                  {/* 3. الإدارة العامة */}
                  <ReportFieldStyleEditor
                    label="3. الإدارة العامة"
                    subLabel="السطر الثالث"
                    fieldKey="generalDept"
                    text={headerFooterConfig.headerRight.generalDept.text}
                    onTextChange={(newText) => {
                      setHeaderFooterConfig({
                        ...headerFooterConfig,
                        headerRight: {
                          ...headerFooterConfig.headerRight,
                          generalDept: {
                            ...headerFooterConfig.headerRight.generalDept,
                            text: newText,
                          },
                        },
                      });
                    }}
                    style={headerFooterConfig.headerRight.generalDept.style}
                    onStyleChange={(newStyle) => {
                      setHeaderFooterConfig({
                        ...headerFooterConfig,
                        headerRight: {
                          ...headerFooterConfig.headerRight,
                          generalDept: {
                            ...headerFooterConfig.headerRight.generalDept,
                            style: newStyle,
                          },
                        },
                      });
                    }}
                    placeholder="مثال: الإدارة المالية والتنفيذية للمشاريع"
                  />

                  {/* 4. الإدارة الفرعية */}
                  <ReportFieldStyleEditor
                    label="4. الإدارة الفرعية"
                    subLabel="السطر الرابع"
                    fieldKey="subDept"
                    text={headerFooterConfig.headerRight.subDept.text}
                    onTextChange={(newText) => {
                      setHeaderFooterConfig({
                        ...headerFooterConfig,
                        headerRight: {
                          ...headerFooterConfig.headerRight,
                          subDept: {
                            ...headerFooterConfig.headerRight.subDept,
                            text: newText,
                          },
                        },
                      });
                    }}
                    style={headerFooterConfig.headerRight.subDept.style}
                    onStyleChange={(newStyle) => {
                      setHeaderFooterConfig({
                        ...headerFooterConfig,
                        headerRight: {
                          ...headerFooterConfig.headerRight,
                          subDept: {
                            ...headerFooterConfig.headerRight.subDept,
                            style: newStyle,
                          },
                        },
                      });
                    }}
                    placeholder="مثال: قسم الحسابات والرقابة المالية"
                  />

                  {/* 5. أخرى */}
                  <ReportFieldStyleEditor
                    label="5. سطر إضافي (أخرى)"
                    subLabel="السطر الخامس - اختياري"
                    fieldKey="extra"
                    text={headerFooterConfig.headerRight.extra.text}
                    onTextChange={(newText) => {
                      setHeaderFooterConfig({
                        ...headerFooterConfig,
                        headerRight: {
                          ...headerFooterConfig.headerRight,
                          extra: {
                            ...headerFooterConfig.headerRight.extra,
                            text: newText,
                          },
                        },
                      });
                    }}
                    style={headerFooterConfig.headerRight.extra.style}
                    onStyleChange={(newStyle) => {
                      setHeaderFooterConfig({
                        ...headerFooterConfig,
                        headerRight: {
                          ...headerFooterConfig.headerRight,
                          extra: {
                            ...headerFooterConfig.headerRight.extra,
                            style: newStyle,
                          },
                        },
                      });
                    }}
                    placeholder="مثال: وحدة التدقيق والتقارير التنفيذية (أو اتركه فارغاً)"
                  />
                </div>
              )}

              {/* 📑 SUB-TAB 2: FOOTER DATA */}
              {companySubTab === 'footer' && (
                <div className="space-y-3 animate-fade-in">
                  <div className="bg-amber-50/70 p-2.5 rounded-xl border border-amber-200/60 text-xs text-amber-900">
                    <p className="font-semibold">
                      تبقى البيانات الافتراضية لتذييل الصفحة كما هي مع إمكانية تعديلها بالأيقونات البرتقالية الدائرية المعتمدة، مع إمكانية تغيير الأيقونة وضبط نوع ولون وحجم ومحاذاة الخط لكل خانة على حدة.
                    </p>
                  </div>

                  {/* 1. العنوان */}
                  <ReportFieldStyleEditor
                    label="1. العنوان والفرع الرئيسي"
                    subLabel="الجهة اليمنى - السطر الأول"
                    fieldKey="address"
                    icon={headerFooterConfig.footer.address.icon}
                    onIconChange={(newIcon) => {
                      setHeaderFooterConfig({
                        ...headerFooterConfig,
                        footer: {
                          ...headerFooterConfig.footer,
                          address: {
                            ...headerFooterConfig.footer.address,
                            icon: newIcon,
                          },
                        },
                      });
                    }}
                    text={headerFooterConfig.footer.address.text}
                    onTextChange={(newText) => {
                      setHeaderFooterConfig({
                        ...headerFooterConfig,
                        footer: {
                          ...headerFooterConfig.footer,
                          address: {
                            ...headerFooterConfig.footer.address,
                            text: newText,
                          },
                        },
                      });
                      setTempCompanyAddress(newText);
                    }}
                    style={headerFooterConfig.footer.address.style}
                    onStyleChange={(newStyle) => {
                      setHeaderFooterConfig({
                        ...headerFooterConfig,
                        footer: {
                          ...headerFooterConfig.footer,
                          address: {
                            ...headerFooterConfig.footer.address,
                            style: newStyle,
                          },
                        },
                      });
                    }}
                    placeholder="مثال: صنعاء - بيت بوس - شارع الخمسين"
                  />

                  {/* 2. البريد الإلكتروني */}
                  <ReportFieldStyleEditor
                    label="2. البريد الإلكتروني"
                    subLabel="الجهة اليمنى - السطر الثاني"
                    fieldKey="email"
                    icon={headerFooterConfig.footer.email.icon}
                    onIconChange={(newIcon) => {
                      setHeaderFooterConfig({
                        ...headerFooterConfig,
                        footer: {
                          ...headerFooterConfig.footer,
                          email: {
                            ...headerFooterConfig.footer.email,
                            icon: newIcon,
                          },
                        },
                      });
                    }}
                    text={headerFooterConfig.footer.email.text}
                    onTextChange={(newText) => {
                      setHeaderFooterConfig({
                        ...headerFooterConfig,
                        footer: {
                          ...headerFooterConfig.footer,
                          email: {
                            ...headerFooterConfig.footer.email,
                            text: newText,
                          },
                        },
                      });
                    }}
                    style={headerFooterConfig.footer.email.style}
                    onStyleChange={(newStyle) => {
                      setHeaderFooterConfig({
                        ...headerFooterConfig,
                        footer: {
                          ...headerFooterConfig.footer,
                          email: {
                            ...headerFooterConfig.footer.email,
                            style: newStyle,
                          },
                        },
                      });
                    }}
                    placeholder="مثال: Info@WorldofElites.com"
                  />

                  {/* 3. الموقع الإلكتروني */}
                  <ReportFieldStyleEditor
                    label="3. الموقع الإلكتروني"
                    subLabel="الجهة اليمنى - السطر الثاني (بجانب البريد)"
                    fieldKey="website"
                    icon={headerFooterConfig.footer.website.icon}
                    onIconChange={(newIcon) => {
                      setHeaderFooterConfig({
                        ...headerFooterConfig,
                        footer: {
                          ...headerFooterConfig.footer,
                          website: {
                            ...headerFooterConfig.footer.website,
                            icon: newIcon,
                          },
                        },
                      });
                    }}
                    text={headerFooterConfig.footer.website.text}
                    onTextChange={(newText) => {
                      setHeaderFooterConfig({
                        ...headerFooterConfig,
                        footer: {
                          ...headerFooterConfig.footer,
                          website: {
                            ...headerFooterConfig.footer.website,
                            text: newText,
                          },
                        },
                      });
                    }}
                    style={headerFooterConfig.footer.website.style}
                    onStyleChange={(newStyle) => {
                      setHeaderFooterConfig({
                        ...headerFooterConfig,
                        footer: {
                          ...headerFooterConfig.footer,
                          website: {
                            ...headerFooterConfig.footer.website,
                            style: newStyle,
                          },
                        },
                      });
                    }}
                    placeholder="مثال: www.WorldofElites.com"
                  />

                  {/* 4. أرقام التواصل */}
                  <ReportFieldStyleEditor
                    label="4. أرقام التواصل (الجوال / الموبايل)"
                    subLabel="الجهة اليسرى - السطر الأول"
                    fieldKey="mobiles"
                    icon={headerFooterConfig.footer.mobiles.icon}
                    onIconChange={(newIcon) => {
                      setHeaderFooterConfig({
                        ...headerFooterConfig,
                        footer: {
                          ...headerFooterConfig.footer,
                          mobiles: {
                            ...headerFooterConfig.footer.mobiles,
                            icon: newIcon,
                          },
                        },
                      });
                    }}
                    text={headerFooterConfig.footer.mobiles.text}
                    onTextChange={(newText) => {
                      setHeaderFooterConfig({
                        ...headerFooterConfig,
                        footer: {
                          ...headerFooterConfig.footer,
                          mobiles: {
                            ...headerFooterConfig.footer.mobiles,
                            text: newText,
                          },
                        },
                      });
                      setTempCompanyPhone(newText);
                    }}
                    style={headerFooterConfig.footer.mobiles.style}
                    onStyleChange={(newStyle) => {
                      setHeaderFooterConfig({
                        ...headerFooterConfig,
                        footer: {
                          ...headerFooterConfig.footer,
                          mobiles: {
                            ...headerFooterConfig.footer.mobiles,
                            style: newStyle,
                          },
                        },
                      });
                    }}
                    placeholder="مثال: +967 782 222 877 | +967 779 992 996"
                  />

                  {/* 5. أرقام أخرى */}
                  <ReportFieldStyleEditor
                    label="5. أرقام أخرى (الهاتف الثابت / البديل)"
                    subLabel="الجهة اليسرى - السطر الثاني"
                    fieldKey="phones"
                    icon={headerFooterConfig.footer.phones.icon}
                    onIconChange={(newIcon) => {
                      setHeaderFooterConfig({
                        ...headerFooterConfig,
                        footer: {
                          ...headerFooterConfig.footer,
                          phones: {
                            ...headerFooterConfig.footer.phones,
                            icon: newIcon,
                          },
                        },
                      });
                    }}
                    text={headerFooterConfig.footer.phones.text}
                    onTextChange={(newText) => {
                      setHeaderFooterConfig({
                        ...headerFooterConfig,
                        footer: {
                          ...headerFooterConfig.footer,
                          phones: {
                            ...headerFooterConfig.footer.phones,
                            text: newText,
                          },
                        },
                      });
                    }}
                    style={headerFooterConfig.footer.phones.style}
                    onStyleChange={(newStyle) => {
                      setHeaderFooterConfig({
                        ...headerFooterConfig,
                        footer: {
                          ...headerFooterConfig.footer,
                          phones: {
                            ...headerFooterConfig.footer.phones,
                            style: newStyle,
                          },
                        },
                      });
                    }}
                    placeholder="مثال: +967 101915558 | +967 1-699888"
                  />
                </div>
              )}

              {/* 📑 SUB-TAB 3: COMPLETE LIVE PREVIEW */}
              {companySubTab === 'preview' && (
                <div className="space-y-3 animate-fade-in">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black text-slate-800">معاينة الترويسة والتذييل بالتقارير المطبوعة</span>
                    <button
                      type="button"
                      onClick={handleResetHeaderFooterDefaults}
                      className="px-2.5 py-1 text-[11px] font-bold text-rose-700 bg-rose-50 hover:bg-rose-100 border border-rose-200 rounded-lg flex items-center gap-1 cursor-pointer"
                    >
                      <RotateCcw size={12} />
                      <span>استعادة الافتراضيات</span>
                    </button>
                  </div>

                  {/* Live Mini Sheet Preview */}
                  <div data-no-swipe="true" className="p-4 bg-white border border-slate-300 rounded-xl shadow-xs space-y-4">
                    {/* Header Preview */}
                    <div className="pb-3 border-b-2 border-[#002B49] flex justify-between items-center gap-3" dir="rtl">
                      <div className="flex-1.35 text-right" dangerouslySetInnerHTML={{ __html: renderHeaderRightHtml(headerFooterConfig) }} />
                      <div className="text-center flex flex-col items-center flex-1">
                        <div className="w-16 h-11 rounded-lg overflow-hidden border border-slate-300 shadow-2xs mb-1 bg-white flex items-center justify-center p-1">
                          <img src={tempCompanyLogo || COMPANY_LOGO_BASE64} className="max-w-full max-h-full object-contain" alt="شعار الشركة" />
                        </div>
                        <div className="font-extrabold text-xs text-[#002B49]">تقرير كشف الحساب المالي الرسمي</div>
                        <span className="text-[9px] text-slate-500 font-bold">الإدارة المالية والتنفيذية للمشاريع</span>
                      </div>
                      <div className="text-left flex-1" dir="rtl">
                        <div className="font-bold text-[10px] text-[#002B49]">الحسابات وإدارة المشاريع</div>
                        <div className="text-[9.5px] text-[#E85D25] font-bold mt-0.5">المشروع: مشروع تجريبي للعرض</div>
                        <div className="text-[9px] text-slate-500 mt-0.5">تاريخ الاستخراج: {new Date().toLocaleDateString('ar-EG-u-nu-latn')}</div>
                        <div className="text-[9px] text-emerald-600 font-bold mt-0.5">الحالة: كشف معتمد داخلياً</div>
                      </div>
                    </div>

                    {/* Placeholder Document Body */}
                    <div className="p-3 bg-slate-50 border border-dashed border-slate-200 rounded-lg text-center text-xs text-slate-400">
                      [ محتوى التقرير وجدول الحسابات والبيانات المالية يظهر هنا ]
                    </div>

                    {/* Footer Preview */}
                    <div className="pt-2 border-t-2 border-[#002B49]" dir="rtl" dangerouslySetInnerHTML={{ __html: renderFooterHtml(headerFooterConfig) }} />
                  </div>
                </div>
              )}

              {/* 📲 Quick Android App Install Banner */}
              {onOpenAndroidInstall && (
                <div className="p-3.5 bg-emerald-50 border border-emerald-200 rounded-2xl flex items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0 shadow-xs">
                      <Smartphone size={20} />
                    </div>
                    <div>
                      <div className="text-xs font-black text-emerald-950 flex items-center gap-1.5">
                        <span>تثبيت التطبيق على هاتف أندرويد (APK)</span>
                        <span className="text-[10px] bg-emerald-200 text-emerald-900 px-1.5 py-0.5 rounded-md font-bold">يعمل بدون نت 100%</span>
                      </div>
                      <p className="text-[11px] text-emerald-700 font-medium mt-0.5">
                        تحميل وتثبيت التطبيق كبرنامج مستقل على شاشة هاتفك مع حفظ البيانات محلياً
                      </p>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      onOpenAndroidInstall();
                      onClose();
                    }}
                    className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs rounded-xl shadow-xs transition-all flex items-center gap-1.5 shrink-0 cursor-pointer"
                  >
                    <Smartphone size={14} />
                    <span>تثبيت الآن 📲</span>
                  </button>
                </div>
              )}

              {/* User Financial Name */}
              <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-2xl space-y-1.5">
                <label className="block text-xs font-bold text-slate-700 flex items-center gap-1.5">
                  <User size={14} className="text-amber-600" />
                  <span>اسم المستخدم المالي المسؤول (المعتمد بالسندات)</span>
                </label>
                <input
                  type="text"
                  value={tempUserName}
                  onChange={(e) => setTempUserName(e.target.value)}
                  placeholder="مثال: المهندس/ أحمد علي"
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs sm:text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 transition-all"
                />
              </div>

              {/* Account Role Status & Quick Restore to Owner */}
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-slate-600">نوع الحساب والصلاحية:</span>
                    <span className={`px-2.5 py-0.5 rounded-full text-xs font-black border ${
                      sharedRole === 'owner' || !sharedRole 
                        ? 'bg-emerald-50 text-emerald-700 border-emerald-300' 
                        : 'bg-amber-50 text-amber-700 border-amber-300'
                    }`}>
                      {sharedRole === 'owner' || !sharedRole ? 'المالك الرئيسي للنظام 👑' : `مستخدم مشارك (${sharedRole}) 👤`}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 font-medium">
                    {sharedRole === 'owner' || !sharedRole 
                      ? 'أنت مسجل كمالك رئيسي للنظام وتملك كامل الصلاحيات لإدارة المشاريع ومشاركتها سحابياً.' 
                      : 'أنت مسجل حالياً كضيف/مشارك في هذا المشروع.'}
                  </p>
                </div>

                {sharedRole && sharedRole !== 'owner' && onRestoreOwnerRole && (
                  <button
                    type="button"
                    onClick={() => {
                      onRestoreOwnerRole();
                      onClose();
                    }}
                    className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white font-black text-xs rounded-xl shadow-md transition-all cursor-pointer whitespace-nowrap shrink-0 flex items-center justify-center gap-2"
                  >
                    <span>👑</span>
                    <span>استعادة صلاحية المالك (المهندس/ياسر عقيل)</span>
                  </button>
                )}
              </div>
            </div>
          )}

          {/* 💵 SECTION 2: FINANCIAL DEFAULTS */}
          {activeSection === 'financial' && (
            <div className="space-y-4 animate-fade-in">
              <div className="bg-emerald-50/60 p-3 rounded-xl border border-emerald-200/60 flex items-center gap-2.5 text-xs text-emerald-900">
                <DollarSign size={16} className="text-emerald-600 shrink-0" />
                <p className="font-semibold">تحديد افتراضيات المبالغ المعتمدة والعملات لسرعة إدخال بيانات العمال والمصروفات المستقبليّة.</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                
                {/* Default Currency Selection */}
                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-slate-700 flex items-center gap-1.5">
                    <DollarSign size={14} className="text-emerald-600" />
                    <span>العملة المعتمدة الافتراضية</span>
                  </label>
                  <select
                    value={tempCurrency}
                    onChange={(e) => setTempCurrency(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-bold focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all cursor-pointer"
                  >
                    <option value="YER">YER - ريال يمني ($)</option>
                    <option value="SAR">SAR - ريال سعودي (ر.س)</option>
                    <option value="USD">USD - دولار أمريكي ($)</option>
                    <option value="AED">AED - درهم إماراتي (د.إ)</option>
                    <option value="EGP">EGP - جنيه مصري (ج.م)</option>
                    <option value="IQD">IQD - دينار عراقي (د.ع)</option>
                    <option value="KWD">KWD - دينار كويتي (د.ك)</option>
                    <option value="OMR">OMR - ريال عماني (ر.ع)</option>
                  </select>
                </div>

                {/* Default Worker Wage */}
                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-slate-700 flex items-center gap-1.5">
                    <Calculator size={14} className="text-sky-600" />
                    <span>الأجر اليومي الافتراضي للعمال الجدد</span>
                  </label>
                  <input
                    type="number"
                    value={defaultWorkerWage}
                    onChange={(e) => setDefaultWorkerWage(e.target.value)}
                    placeholder="10000"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 transition-all"
                  />
                </div>

                {/* Default Employee Salary */}
                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-slate-700 flex items-center gap-1.5">
                    <Calculator size={14} className="text-indigo-600" />
                    <span>راتب الموظف اليومي/الشهر الافتراضي</span>
                  </label>
                  <input
                    type="number"
                    value={defaultEmployeeSalary}
                    onChange={(e) => setDefaultEmployeeSalary(e.target.value)}
                    placeholder="150000"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all"
                  />
                </div>

                {/* Currency Decimals */}
                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-slate-700 flex items-center gap-1.5">
                    <Sliders size={14} className="text-amber-600" />
                    <span>تنسيق الخانات العشرية للمبالغ</span>
                  </label>
                  <select
                    value={decimals}
                    onChange={(e) => setDecimals(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-bold focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 transition-all cursor-pointer"
                  >
                    <option value="0">بدون خانات عشرية (أرقام صحيحة - 1,000)</option>
                    <option value="2">خانة عشرية واحدة/اثنتين (1,000.00)</option>
                  </select>
                </div>

              </div>
            </div>
          )}

          {/* 📄 SECTION 3: REPORTS & HEADER/FOOTER PREFERENCES */}
          {activeSection === 'reports' && (
            <div className="space-y-4 animate-fade-in">
              <div className="bg-amber-50/70 p-3 rounded-xl border border-amber-200/70 flex items-center gap-2.5 text-xs text-amber-950">
                <FileText size={18} className="text-amber-600 shrink-0" />
                <p className="font-semibold">تخصيص ترويسة وتذييل التقارير الرسمية، التوقيعات، وملاحظات سندات الصرف بالشكل المطلوب مع إمكانية المعاينة الحية الفورية.</p>
              </div>

              {/* 🔍 LIVE REPORT & OPTIONS MINI-PREVIEW (تبويب المعاينة الحية للبيانات وشكل التقرير) */}
              <div 
                data-report-preview="true"
                data-no-swipe="true"
                onTouchStart={handlePreviewTouchStart}
                onTouchEnd={handlePreviewTouchEnd}
                onMouseDown={handlePreviewMouseDown}
                onMouseUp={handlePreviewMouseUp}
                className="bg-slate-900 text-white rounded-2xl p-3 sm:p-4 border border-slate-800 shadow-md space-y-3 touch-pan-y"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-2.5">
                  <div className="flex items-center gap-2">
                    <div className="p-1.5 bg-amber-500/20 text-amber-400 rounded-lg shrink-0">
                      <Sparkles size={16} />
                    </div>
                    <div>
                      <h4 className="font-extrabold text-xs text-white flex items-center gap-2">
                        <span>معاينة حية لشكل التقرير والبيانات المدخلة</span>
                        <span className="text-[10px] font-normal text-amber-300 bg-amber-500/20 px-2 py-0.5 rounded-full">
                          تحديث فوري
                        </span>
                      </h4>
                      <p className="text-[10px] text-slate-400 font-medium">
                        اسحب لليمين واليسار داخل المعاينة للتنقل السريع بين التبويبات دون الخروج من نافذة الإعدادات
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 self-start sm:self-auto">
                    {/* Quick Prev/Next Arrow buttons for Preview tabs */}
                    {isReportPreviewExpanded && (
                      <div className="flex items-center bg-slate-800 rounded-lg p-0.5 border border-slate-700">
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            goToPrevPreviewTab();
                          }}
                          title="التبويب السابق (أو اسحب لليسار)"
                          className="p-1 text-slate-400 hover:text-white hover:bg-slate-700 rounded transition-colors cursor-pointer"
                        >
                          <ChevronRight size={14} />
                        </button>
                        <span className="text-[10px] text-slate-400 px-1 font-mono font-bold">
                          {REPORT_PREVIEW_TABS.indexOf(reportPreviewTab) + 1}/{REPORT_PREVIEW_TABS.length}
                        </span>
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            goToNextPreviewTab();
                          }}
                          title="التبويب التالي (أو اسحب لليمين)"
                          className="p-1 text-slate-400 hover:text-white hover:bg-slate-700 rounded transition-colors cursor-pointer"
                        >
                          <ChevronLeft size={14} />
                        </button>
                      </div>
                    )}

                    {/* Toggle Expand/Collapse */}
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setIsReportPreviewExpanded(!isReportPreviewExpanded);
                      }}
                      className="text-[11px] text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 px-2.5 py-1 rounded-lg border border-slate-700 flex items-center gap-1 cursor-pointer"
                    >
                      <Eye size={13} />
                      <span>{isReportPreviewExpanded ? 'طي المعاينة' : 'عرض المعاينة'}</span>
                    </button>
                  </div>
                </div>

                {isReportPreviewExpanded && (
                  <div className="space-y-3 animate-fade-in">
                    {/* Sub-tabs for each option */}
                    <div 
                      data-report-preview="true"
                      data-no-swipe="true"
                      className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-thin select-none"
                    >
                      <button
                        ref={(el) => { previewTabButtonRefs.current['all'] = el; }}
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setReportPreviewTab('all');
                        }}
                        className={`py-1.5 px-3 rounded-lg text-xs font-bold transition-all whitespace-nowrap cursor-pointer flex items-center gap-1.5 ${
                          reportPreviewTab === 'all'
                            ? 'bg-amber-500 text-slate-950 shadow-sm font-black'
                            : 'bg-slate-800/90 text-slate-300 hover:bg-slate-800'
                        }`}
                      >
                        <FileText size={13} />
                        <span>📑 شكل التقرير كاملاً</span>
                      </button>

                      <button
                        ref={(el) => { previewTabButtonRefs.current['header'] = el; }}
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setReportPreviewTab('header');
                        }}
                        className={`py-1.5 px-3 rounded-lg text-xs font-bold transition-all whitespace-nowrap cursor-pointer flex items-center gap-1.5 ${
                          reportPreviewTab === 'header'
                            ? 'bg-sky-500 text-white shadow-sm font-black'
                            : 'bg-slate-800/90 text-slate-300 hover:bg-slate-800'
                        }`}
                      >
                        <span>🏷️ الترويسة والشعار</span>
                        <span className={`w-2 h-2 rounded-full ${showReportHeader ? 'bg-emerald-400' : 'bg-slate-500'}`} />
                      </button>

                      <button
                        ref={(el) => { previewTabButtonRefs.current['signatures'] = el; }}
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setReportPreviewTab('signatures');
                        }}
                        className={`py-1.5 px-3 rounded-lg text-xs font-bold transition-all whitespace-nowrap cursor-pointer flex items-center gap-1.5 ${
                          reportPreviewTab === 'signatures'
                            ? 'bg-emerald-500 text-white shadow-sm font-black'
                            : 'bg-slate-800/90 text-slate-300 hover:bg-slate-800'
                        }`}
                      >
                        <span>✍️ خانات التوقيع ({signatureSlots.filter(s => s.enabled !== false).length})</span>
                        <span className={`w-2 h-2 rounded-full ${showSignatureBlocks && signatureSlots.some(s => s.enabled !== false) ? 'bg-emerald-400' : 'bg-slate-500'}`} />
                      </button>

                      <button
                        ref={(el) => { previewTabButtonRefs.current['notes'] = el; }}
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setReportPreviewTab('notes');
                        }}
                        className={`py-1.5 px-3 rounded-lg text-xs font-bold transition-all whitespace-nowrap cursor-pointer flex items-center gap-1.5 ${
                          reportPreviewTab === 'notes'
                            ? 'bg-amber-600 text-white shadow-sm font-black'
                            : 'bg-slate-800/90 text-slate-300 hover:bg-slate-800'
                        }`}
                      >
                        <span>📝 الملاحظات والتذييل</span>
                        <span className={`w-2 h-2 rounded-full ${reportFooterNotes.trim() ? 'bg-emerald-400' : 'bg-slate-500'}`} />
                      </button>

                      <button
                        ref={(el) => { previewTabButtonRefs.current['attribution'] = el; }}
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setReportPreviewTab('attribution');
                        }}
                        className={`py-1.5 px-3 rounded-lg text-xs font-bold transition-all whitespace-nowrap cursor-pointer flex items-center gap-1.5 ${
                          reportPreviewTab === 'attribution'
                            ? 'bg-indigo-500 text-white shadow-sm font-black'
                            : 'bg-slate-800/90 text-slate-300 hover:bg-slate-800'
                        }`}
                      >
                        <span>💼 توقيع المصمم والنظام</span>
                        <span className={`w-2 h-2 rounded-full ${showDesignerAttribution ? 'bg-emerald-400' : 'bg-slate-500'}`} />
                      </button>
                    </div>

                    {/* Render Document Preview Box */}
                    <div 
                      data-report-preview="true"
                      data-no-swipe="true"
                      className="bg-white text-slate-900 rounded-xl p-3 sm:p-4 border border-slate-200/90 shadow-inner max-h-[380px] overflow-y-auto font-sans text-xs dir-rtl select-text touch-pan-y"
                    >
                      {/* TAB 1: ALL / FULL DOCUMENT */}
                      {reportPreviewTab === 'all' && (
                        <div className="space-y-4">
                          {/* Header Preview */}
                          {showReportHeader ? (
                            <div className="flex justify-between items-center border-b-2 border-[#002B49] pb-3">
                              <div 
                                className="flex-1.35 text-right" 
                                dangerouslySetInnerHTML={{ __html: renderHeaderRightHtml(headerFooterConfig) }} 
                              />
                              <div className="text-center flex flex-col items-center flex-1">
                                <div className="w-14 h-11 border rounded-lg bg-white p-1 flex items-center justify-center mb-1">
                                  <img src={tempCompanyLogo} alt="شعار" className="max-h-full max-w-full object-contain" />
                                </div>
                                <span className="font-black text-xs text-[#002B49]">كشف حساب مصروفات المشروع</span>
                                <span className="text-[9px] text-slate-500 font-bold">نموذج تقرير رسمي معتمد</span>
                              </div>
                              <div className="text-left flex-1" style={{ direction: 'ltr' }}>
                                <span className="font-bold text-[10px] text-slate-800 block">Project: {tempCompanyName}</span>
                                <span className="text-[9px] text-slate-500 block">Date: {new Date().toLocaleDateString('ar-EG-u-nu-latn')}</span>
                                <span className="text-[9px] text-emerald-600 font-bold block">Status: Verified Document</span>
                              </div>
                            </div>
                          ) : (
                            <div className="p-2.5 bg-slate-100 rounded-lg text-center text-slate-500 text-[11px] font-bold border border-dashed border-slate-300">
                              ⚠️ الترويسة العلوية معطلة حالياً (لن تظهر في التقارير)
                            </div>
                          )}

                          {/* Dummy Table Body representing the report contents */}
                          <div className="border border-slate-200 rounded-lg overflow-hidden text-[10.5px]">
                            <div className="bg-slate-100 p-1.5 font-black text-slate-700 flex justify-between border-b border-slate-200">
                              <span>بيان الحساب / البند</span>
                              <span>المبلغ</span>
                            </div>
                            <div className="p-1.5 flex justify-between border-b border-slate-100 text-slate-600">
                              <span>أجور عمال وبناء - المرحلة الأولى</span>
                              <span className="font-bold">45,000 {tempCurrency}</span>
                            </div>
                            <div className="p-1.5 flex justify-between text-slate-600">
                              <span>توريد مواد إنشائية وحديد تسليح</span>
                              <span className="font-bold">120,000 {tempCurrency}</span>
                            </div>
                          </div>

                          {/* Notes if entered */}
                          {reportFooterNotes.trim() && (
                            <div className="p-2.5 bg-amber-50/70 border border-amber-200 rounded-lg text-[10.5px] text-amber-950">
                              <span className="font-bold block mb-0.5">📌 الملاحظات الختامية والشروط:</span>
                              <p className="whitespace-pre-wrap">{reportFooterNotes}</p>
                            </div>
                          )}

                          {/* Signatures preview */}
                          {showSignatureBlocks ? (
                            signatureSlots.some(s => s.enabled !== false && (s.role?.trim() || s.name?.trim())) ? (
                              <div dangerouslySetInnerHTML={{ __html: renderSignatureBlocksHtml(signatureSlots) }} />
                            ) : (
                              <div className="p-2.5 bg-amber-50 rounded-lg text-center text-amber-800 text-[11px] font-bold border border-dashed border-amber-300">
                                ⚠️ خانات التوقيع مفعلة ولكن لم يتم تفعيل أي شخص للتوقيع حالياً (قم بتفعيل شخص واحد على الأقل أدناه).
                              </div>
                            )
                          ) : (
                            <div className="p-2 bg-slate-100 rounded-lg text-center text-slate-500 text-[11px] font-bold border border-dashed border-slate-300">
                              ⚠️ خانات التوقيع معطلة حالياً (لن تظهر في أسفل التقارير)
                            </div>
                          )}

                          {/* Official Footer Contact Details */}
                          <div className="border-t-2 border-[#002B49] pt-2" dangerouslySetInnerHTML={{ __html: renderFooterHtml(headerFooterConfig) }} />

                          {/* Attribution */}
                          {showDesignerAttribution ? (
                            <div className="text-center text-[9.5px] text-slate-400 border-t border-slate-100 pt-1.5">
                              تم توليد هذا التقرير تلقائياً بواسطة تطبيق الحسابات وادارة المشاريع - {tempCompanyName} | توقيع المهندس/المصمم ومطور النظام المعتمد
                            </div>
                          ) : null}
                        </div>
                      )}

                      {/* TAB 2: HEADER ONLY */}
                      {reportPreviewTab === 'header' && (
                        <div className="space-y-3">
                          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                            <span className="font-extrabold text-xs text-sky-950">معاينة الترويسة العلوية الرسمية وشعار الشركة:</span>
                            <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${showReportHeader ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'}`}>
                              {showReportHeader ? 'مُفعّلة في التقرير' : 'مُعطّلة'}
                            </span>
                          </div>
                          {showReportHeader ? (
                            <div className="border border-slate-200 rounded-xl p-3 bg-white">
                              <div className="flex justify-between items-center border-b-2 border-[#002B49] pb-3">
                                <div className="flex-1.35 text-right" dangerouslySetInnerHTML={{ __html: renderHeaderRightHtml(headerFooterConfig) }} />
                                <div className="text-center flex flex-col items-center flex-1">
                                  <div className="w-16 h-12 border rounded-lg bg-white p-1 flex items-center justify-center mb-1">
                                    <img src={tempCompanyLogo} alt="شعار الشركة" className="max-h-full max-w-full object-contain" />
                                  </div>
                                  <span className="font-black text-xs text-[#002B49]">عنوان التقرير المستخرج</span>
                                  <span className="text-[10px] text-slate-500 font-bold">الإدارة المالية والتنفيذية</span>
                                </div>
                                <div className="text-left flex-1" style={{ direction: 'ltr' }}>
                                  <span className="font-bold text-[10px] text-slate-800 block">Project: {tempCompanyName}</span>
                                  <span className="text-[9.5px] text-slate-500 block">Date: {new Date().toLocaleDateString('ar-EG-u-nu-latn')}</span>
                                  <span className="text-[9.5px] text-emerald-600 font-bold block">Status: Verified Document</span>
                                </div>
                              </div>
                            </div>
                          ) : (
                            <div className="p-4 bg-slate-50 border border-dashed border-slate-300 rounded-xl text-center text-slate-600 text-xs font-bold">
                              الترويسة غير مفعلة حالياً. يمكنك تفعيلها بالضغط على المفتاح في خيار الترويسة أدناه.
                            </div>
                          )}
                        </div>
                      )}

                      {/* TAB 3: SIGNATURES ONLY */}
                      {reportPreviewTab === 'signatures' && (
                        <div className="space-y-3">
                          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                            <div className="flex items-center gap-2">
                              <span className="font-extrabold text-xs text-emerald-950">معاينة خانات التوقيع المعتمدة بالتقرير:</span>
                              <span className="text-[10px] font-bold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full">
                                {signatureSlots.filter(s => s.enabled !== false).length} من {signatureSlots.length} محدد
                              </span>
                            </div>
                            <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${showSignatureBlocks ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'}`}>
                              {showSignatureBlocks ? 'مُفعّلة في التقرير' : 'مُعطّلة بالكامل'}
                            </span>
                          </div>
                          {showSignatureBlocks ? (
                            signatureSlots.some(s => s.enabled !== false && (s.role?.trim() || s.name?.trim())) ? (
                              <div className="border border-emerald-100 rounded-xl p-3 bg-white">
                                <p className="text-[11px] text-slate-500 mb-2 font-medium">
                                  هذا هو الشكل النهائي للأشخاص المحددين فقط في أسفل الصفحة الأخيرة من التقرير:
                                </p>
                                <div dangerouslySetInnerHTML={{ __html: renderSignatureBlocksHtml(signatureSlots) }} />
                              </div>
                            ) : (
                              <div className="p-4 bg-amber-50 border border-dashed border-amber-300 rounded-xl text-center text-amber-900 text-xs font-bold space-y-1">
                                <p>⚠️ لم يتم تفعيل أي شخص للتوقيع حالياً!</p>
                                <p className="text-[11px] text-amber-700 font-normal">قم بتفعيل زر التفعيل (مُفعّل) لأي من الأشخاص المخولين بالأسفل ليظهر توقيعه في التقرير.</p>
                              </div>
                            )
                          ) : (
                            <div className="p-4 bg-slate-50 border border-dashed border-slate-300 rounded-xl text-center text-slate-600 text-xs font-bold">
                              خانات التوقيع معطلة حالياً. فعّل خيار "إظهار خانات التوقيع الرسمية" لتظهر في أسفل الصفحة الأخيرة.
                            </div>
                          )}
                        </div>
                      )}

                      {/* TAB 4: NOTES & FOOTER */}
                      {reportPreviewTab === 'notes' && (
                        <div className="space-y-3">
                          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                            <span className="font-extrabold text-xs text-amber-950">معاينة الملاحظات والتذييل الرسمي:</span>
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-800">
                              {reportFooterNotes.trim() ? 'تحتوي على نصوص' : 'فارغة'}
                            </span>
                          </div>

                          {reportFooterNotes.trim() ? (
                            <div className="p-3 bg-amber-50/70 border border-amber-200 rounded-xl text-xs text-amber-950">
                              <span className="font-bold block mb-1">📌 الملاحظات الختامية والشروط:</span>
                              <p className="whitespace-pre-wrap">{reportFooterNotes}</p>
                            </div>
                          ) : (
                            <div className="p-3 bg-slate-50 border border-dashed border-slate-200 rounded-xl text-center text-slate-400 text-xs">
                              لم يتم إدخال ملاحظات ختامية بعد. يمكنك كتابة الشروط في خانة التذييل أدناه.
                            </div>
                          )}

                          <div className="pt-2 border-t border-slate-200">
                            <span className="text-[11px] font-bold text-slate-600 block mb-1">تذييل بيانات التواصل للشركة:</span>
                            <div className="border-t-2 border-[#002B49] pt-2" dangerouslySetInnerHTML={{ __html: renderFooterHtml(headerFooterConfig) }} />
                          </div>
                        </div>
                      )}

                      {/* TAB 5: ATTRIBUTION */}
                      {reportPreviewTab === 'attribution' && (
                        <div className="space-y-3">
                          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                            <span className="font-extrabold text-xs text-indigo-950">معاينة توقيع المصمم وبيانات النظام:</span>
                            <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${showDesignerAttribution ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'}`}>
                              {showDesignerAttribution ? 'مُفعّل في التقرير' : 'مُعطّل'}
                            </span>
                          </div>

                          {showDesignerAttribution ? (
                            <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl text-center">
                              <p className="text-xs text-slate-600 font-bold">
                                تم توليد هذا التقرير تلقائياً بواسطة تطبيق الحسابات وادارة المشاريع - {tempCompanyName} | توقيع المهندس/المصمم ومطور النظام المعتمد | تاريخ الطباعة: {new Date().toLocaleDateString('ar-EG-u-nu-latn')}
                              </p>
                            </div>
                          ) : (
                            <div className="p-3 bg-slate-50 border border-dashed border-slate-300 rounded-xl text-center text-slate-500 text-xs">
                              توقيع المصمم معطل. سيظهر بدلاً عنه فقط اسم المؤسسة وتاريخ الاستخراج.
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>

              {/* MAIN OPTIONS LIST (خيارات الترويسة والتقارير) */}
              <div className="space-y-3.5">
                
                {/* 1. Report Header Toggle */}
                <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200/80 flex items-center justify-between gap-3">
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-1.5 font-black text-xs text-slate-900">
                      <FileText size={15} className="text-sky-600" />
                      <span>إظهار الترويسة الرسمية وشعار الشركة في التقارير (Header)</span>
                    </div>
                    <p className="text-[11px] text-slate-500 font-medium">
                      عرض اسم المؤسسة وشعارها وبيانات الماليّة في أعلى التقارير المطبوعة وسندات الصرف. عند الإيقاف تُطبّع البيانات بدون ترويسة.
                    </p>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={() => {
                        setReportPreviewTab('header');
                        setIsReportPreviewExpanded(true);
                      }}
                      title="معاينة الترويسة"
                      className="p-1.5 text-slate-500 hover:text-sky-600 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
                    >
                      <Eye size={16} />
                    </button>
                    <button
                      type="button"
                      onClick={() => setShowReportHeader(!showReportHeader)}
                      className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors cursor-pointer shrink-0 ${
                        showReportHeader ? 'bg-sky-600' : 'bg-slate-300'
                      }`}
                    >
                      <span
                        className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                          showReportHeader ? '-translate-x-6' : '-translate-x-1'
                        }`}
                      />
                    </button>
                  </div>
                </div>

                {/* 2. Signature Blocks Toggle & Dynamic Configurable Slots */}
                <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200/80 space-y-3">
                  <div className="flex items-center justify-between gap-3">
                    <div className="space-y-0.5">
                      <div className="flex items-center gap-1.5 font-black text-xs text-slate-900">
                        <PenTool size={15} className="text-emerald-600" />
                        <span>إظهار خانات التوقيع الرسمية في أسفل التقارير (Signature Blocks)</span>
                      </div>
                      <p className="text-[11px] text-slate-500 font-medium">
                        تحديد وتخصيص الأشخاص المخولين بالتوقيع لتوثيق وتصديق كافة الكشوفات والتقارير المستخرجة في أسفل الصفحة الأخيرة.
                      </p>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        type="button"
                        onClick={() => {
                          setReportPreviewTab('signatures');
                          setIsReportPreviewExpanded(true);
                        }}
                        title="معاينة خانات التوقيع"
                        className="p-1.5 text-slate-500 hover:text-emerald-600 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
                      >
                        <Eye size={16} />
                      </button>
                      <button
                        type="button"
                        onClick={() => setShowSignatureBlocks(!showSignatureBlocks)}
                        className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors cursor-pointer shrink-0 ${
                          showSignatureBlocks ? 'bg-emerald-600' : 'bg-slate-300'
                        }`}
                      >
                        <span
                          className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                            showSignatureBlocks ? '-translate-x-6' : '-translate-x-1'
                          }`}
                        />
                      </button>
                    </div>
                  </div>

                  {/* Signatory Slots Customization & Dynamic Slots */}
                  {showSignatureBlocks && (
                    <div className="pt-3 border-t border-slate-200/90 space-y-3 animate-fade-in">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                        <div className="space-y-0.5">
                          <span className="font-extrabold text-xs text-emerald-950 flex items-center gap-1.5">
                            <CheckSquare size={14} className="text-emerald-600" />
                            <span>الأشخاص المخولون بالتوقيع (تظهر في أسفل الصفحة الأخيرة):</span>
                          </span>
                          <p className="text-[10.5px] text-slate-500 font-medium">
                            قم بتفعيل الأشخاص المراد ظهورهم في التقرير (شخص واحد أو أكثر)، وسيظهر فقط من تم تفعيله.
                          </p>
                        </div>

                        <button
                          type="button"
                          onClick={() => {
                            setSignatureSlots(prev => [
                              ...prev,
                              {
                                id: 'sig-' + Date.now().toString(),
                                role: '',
                                name: '',
                                enabled: true
                              }
                            ]);
                          }}
                          className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white font-bold text-xs rounded-xl shadow-xs transition-all flex items-center justify-center gap-1.5 shrink-0 cursor-pointer"
                        >
                          <Plus size={14} />
                          <span>إضافة توقيع جديد</span>
                        </button>
                      </div>

                      {/* Grid of Signatory Slots */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                        {signatureSlots.map((slot, index) => {
                          const isSlotEnabled = slot.enabled !== false;
                          return (
                            <div 
                              key={slot.id || index} 
                              className={`p-3 rounded-xl border transition-all duration-200 space-y-2.5 relative ${
                                isSlotEnabled 
                                  ? 'bg-white border-emerald-300 shadow-2xs ring-1 ring-emerald-500/10' 
                                  : 'bg-slate-100/80 border-slate-200 opacity-75'
                              }`}
                            >
                              {/* Header with Title, Status Toggle & Delete Button */}
                              <div className="flex items-center justify-between border-b pb-2 gap-2 border-slate-100">
                                <div className="flex items-center gap-1.5 min-w-0">
                                  <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-mono font-bold shrink-0 ${
                                    isSlotEnabled ? 'bg-emerald-600 text-white' : 'bg-slate-400 text-white'
                                  }`}>
                                    {index + 1}
                                  </span>
                                  <span className="font-black text-xs text-slate-800 truncate">
                                    {slot.role.trim() || `توقيع شخص مخول #${index + 1}`}
                                  </span>
                                </div>

                                <div className="flex items-center gap-1.5 shrink-0">
                                  {/* Enable/Disable Toggle Button */}
                                  <button
                                    type="button"
                                    onClick={() => {
                                      setSignatureSlots(prev => {
                                        const updated = [...prev];
                                        updated[index] = { ...updated[index], enabled: !isSlotEnabled };
                                        return updated;
                                      });
                                    }}
                                    title={isSlotEnabled ? 'تعطيل هذا التوقيع من التقرير' : 'تفعيل هذا التوقيع في التقرير'}
                                    className={`px-2 py-1 rounded-lg text-[10.5px] font-black transition-all flex items-center gap-1 cursor-pointer border ${
                                      isSlotEnabled
                                        ? 'bg-emerald-50 text-emerald-700 border-emerald-300 hover:bg-emerald-100'
                                        : 'bg-slate-200 text-slate-600 border-slate-300 hover:bg-slate-300'
                                    }`}
                                  >
                                    <span className={`w-2 h-2 rounded-full ${isSlotEnabled ? 'bg-emerald-500 animate-pulse' : 'bg-slate-400'}`} />
                                    <span>{isSlotEnabled ? 'مُفعّل بالتقرير' : 'مُعطّل'}</span>
                                  </button>

                                  {/* Delete Button (if more than 1 slot) */}
                                  {signatureSlots.length > 1 && (
                                    <button
                                      type="button"
                                      onClick={() => {
                                        setSignatureSlots(prev => prev.filter((_, i) => i !== index));
                                      }}
                                      title="حذف خانة التوقيع هذه"
                                      className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                                    >
                                      <Trash2 size={14} />
                                    </button>
                                  )}
                                </div>
                              </div>

                              {/* Role input */}
                              <div className="space-y-1">
                                <label className="block text-[10.5px] font-bold text-slate-700">
                                  الصفة / الوظيفة المخولة بالتوقيع:
                                </label>
                                <input
                                  type="text"
                                  value={slot.role}
                                  onChange={(e) => {
                                    const updated = [...signatureSlots];
                                    updated[index] = { ...updated[index], role: e.target.value };
                                    setSignatureSlots(updated);
                                  }}
                                  placeholder={`مثال: ${DEFAULT_SIGNATURE_SLOTS[index]?.role || 'توقيع معتمد'}`}
                                  className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all"
                                />
                              </div>

                              {/* Name input */}
                              <div className="space-y-1">
                                <label className="block text-[10.5px] font-bold text-slate-700">
                                  اسم الشخص المخول بالتوقيع (اختياري):
                                </label>
                                <input
                                  type="text"
                                  value={slot.name}
                                  onChange={(e) => {
                                    const updated = [...signatureSlots];
                                    updated[index] = { ...updated[index], name: e.target.value };
                                    setSignatureSlots(updated);
                                  }}
                                  placeholder="مثال: أ. أحمد محمد / م. علي سالم"
                                  className="w-full px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg text-xs font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all"
                                />
                              </div>
                            </div>
                          );
                        })}
                      </div>

                      {/* Quick Actions Footer below the cards: Reset to standard 4 slots / Add another slot */}
                      <div className="pt-2 flex flex-wrap items-center justify-between gap-2 border-t border-slate-200/60">
                        <div className="text-[11px] text-slate-600 font-semibold flex items-center gap-1.5">
                          <span className="w-2 h-2 rounded-full bg-emerald-500" />
                          <span>
                            عدد التوقيعات المحددة حالياً للظهور بالتقرير:{' '}
                            <strong className="text-emerald-700 font-black">
                              {signatureSlots.filter(s => s.enabled !== false).length}
                            </strong>{' '}
                            من إجمالي {signatureSlots.length}
                          </span>
                        </div>

                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => setSignatureSlots(DEFAULT_SIGNATURE_SLOTS)}
                            className="px-2.5 py-1 text-[11px] font-bold text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-lg border border-slate-200 transition-all cursor-pointer flex items-center gap-1"
                          >
                            <RotateCcw size={12} />
                            <span>استعادة الـ 4 الافتراضية</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => {
                              setSignatureSlots(prev => [
                                ...prev,
                                {
                                  id: 'sig-' + Date.now().toString(),
                                  role: '',
                                  name: '',
                                  enabled: true
                                }
                              ]);
                            }}
                            className="px-3 py-1 text-[11px] font-bold text-emerald-800 bg-emerald-100 hover:bg-emerald-200 rounded-lg border border-emerald-300 transition-all cursor-pointer flex items-center gap-1"
                          >
                            <Plus size={13} />
                            <span>+ إضافة توقيع إضافي</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                {/* 3. Designer/Engineer Signature Toggle */}
                <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200/80 flex items-center justify-between gap-3">
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-1.5 font-black text-xs text-slate-900">
                      <CheckSquare size={15} className="text-indigo-600" />
                      <span>إظهار توقيع المهندس/المصمم وبيانات النظام (Designer Attribution)</span>
                    </div>
                    <p className="text-[11px] text-slate-500 font-medium">
                      عرض أو إخفاء توقيع مسؤول تصميم وإعداد النظام وبيانات الاعتماد في تذييل التقرير والشاشات.
                    </p>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={() => {
                        setReportPreviewTab('attribution');
                        setIsReportPreviewExpanded(true);
                      }}
                      title="معاينة توقيع المصمم"
                      className="p-1.5 text-slate-500 hover:text-indigo-600 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
                    >
                      <Eye size={16} />
                    </button>
                    <button
                      type="button"
                      onClick={() => setShowDesignerAttribution(!showDesignerAttribution)}
                      className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors cursor-pointer shrink-0 ${
                        showDesignerAttribution ? 'bg-indigo-600' : 'bg-slate-300'
                      }`}
                    >
                      <span
                        className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                          showDesignerAttribution ? '-translate-x-6' : '-translate-x-1'
                        }`}
                      />
                    </button>
                  </div>
                </div>

                {/* 4. Footer Custom Notes / Terms & Conditions Textarea */}
                <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200/80 space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="block font-black text-xs text-slate-900 flex items-center gap-1.5">
                      <FileText size={15} className="text-amber-600" />
                      <span>تذييل التقارير والنصوص الثابتة (Report Footer Notes & Terms)</span>
                    </label>
                    <button
                      type="button"
                      onClick={() => {
                        setReportPreviewTab('notes');
                        setIsReportPreviewExpanded(true);
                      }}
                      title="معاينة الملاحظات والتذييل"
                      className="p-1 text-slate-500 hover:text-amber-600 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer flex items-center gap-1 text-[11px] font-bold"
                    >
                      <Eye size={14} />
                      <span>معاينة التذييل</span>
                    </button>
                  </div>
                  <p className="text-[11px] text-slate-500 font-medium">
                    أدخل أي ملاحظات ختامية أو شروط وأحكام أو تعليمات صرف ترغب بظهورها تلقائياً في تذييل كل تقرير وسند.
                  </p>
                  <textarea
                    value={reportFooterNotes}
                    onChange={(e) => setReportFooterNotes(e.target.value)}
                    placeholder="مثال: يرجى الاحتفاظ بهذا السند، المستند معتمد رسمياً من الإدارة المالية، الشروط والأحكام..."
                    rows={3}
                    className="w-full p-2.5 bg-white border border-slate-300 rounded-xl text-xs font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 transition-all resize-y"
                  />
                </div>

              </div>
            </div>
          )}

          {/* 🎨 SECTION 4: DISPLAY, THEME & LANGUAGE */}
          {activeSection === 'display' && (
            <div className="space-y-4 animate-fade-in">
              <div className="bg-indigo-50/60 p-3 rounded-xl border border-indigo-200/60 flex items-center gap-2.5 text-xs text-indigo-900">
                <Palette size={16} className="text-indigo-600 shrink-0" />
                <p className="font-semibold">تعديل مظهر التطبيق (الوضع الفاتح / الوضع الداكن)، لغة الواجهة، وتنسيق العرض.</p>
              </div>

              <div className="space-y-3.5">
                
                {/* 1. Theme Selection (Light / Dark) */}
                <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200/80 space-y-2.5">
                  <div>
                    <span className="block font-extrabold text-xs text-slate-800 flex items-center gap-1.5">
                      <Palette size={15} className="text-indigo-600" />
                      <span>مظهر الواجهة (Theme)</span>
                    </span>
                    <span className="text-[11px] text-slate-500">اختر النمط البصري المناسب للاستخدام في النهار أو الليل</span>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <button
                      type="button"
                      onClick={() => handleSelectTheme('light')}
                      className={`p-3 rounded-xl border flex items-center justify-center gap-2 text-xs font-bold transition-all cursor-pointer ${
                        theme === 'light'
                          ? 'bg-amber-500 text-slate-950 border-amber-500 shadow-md font-black ring-2 ring-amber-400/40'
                          : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      <Sun size={17} className={theme === 'light' ? 'text-slate-950 animate-spin-slow' : 'text-amber-500'} />
                      <span>☀️ الوضع الفاتح (Light Mode)</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => handleSelectTheme('dark')}
                      className={`p-3 rounded-xl border flex items-center justify-center gap-2 text-xs font-bold transition-all cursor-pointer ${
                        theme === 'dark'
                          ? 'bg-slate-950 text-amber-400 border-amber-400/60 shadow-md font-black ring-2 ring-amber-400/30'
                          : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      <Moon size={17} className={theme === 'dark' ? 'text-amber-400' : 'text-slate-600'} />
                      <span>🌙 الوضع الداكن (Dark Mode)</span>
                    </button>
                  </div>
                </div>

                {/* 🔤 2. Full Application Font Size Adjustment (تكبير وتصغير خطوط التطبيق كاملة) */}
                <FontSizeSlider
                  currentStep={currentFontStep}
                  onStepChange={handleFontStepChange}
                />

                {/* 3. Interface Language Selection (Arabic / English) */}
                <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200/80 space-y-2.5">
                  <div>
                    <span className="block font-extrabold text-xs text-slate-800 flex items-center gap-1.5">
                      <Globe size={15} className="text-sky-600" />
                      <span>لغة الواجهة (Interface Language)</span>
                    </span>
                    <span className="text-[11px] text-slate-500">دعم التبديل المباشر للغة واتجاه النصوص</span>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <button
                      type="button"
                      onClick={() => handleSelectLanguage('ar')}
                      className={`p-3 rounded-xl border flex items-center justify-center gap-2 text-xs font-bold transition-all cursor-pointer ${
                        language === 'ar'
                          ? 'bg-sky-600 text-white border-sky-600 shadow-sm font-black'
                          : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      <span>🇸🇦 العربية (Arabic - RTL)</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => handleSelectLanguage('en')}
                      className={`p-3 rounded-xl border flex items-center justify-center gap-2 text-xs font-bold transition-all cursor-pointer ${
                        language === 'en'
                          ? 'bg-sky-600 text-white border-sky-600 shadow-sm font-black'
                          : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      <span>🇬🇧 English (الإنجليزية - LTR)</span>
                    </button>
                  </div>
                </div>

                {/* Date Format Option */}
                <div className="p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200/80 dark:border-slate-700/80 space-y-2.5">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div>
                      <span className="block font-extrabold text-xs text-slate-800 dark:text-slate-100">تنسيق عرض التواريخ</span>
                      <span className="text-[11px] text-slate-500 dark:text-slate-400">اختر طريقة عرض تاريخ السندات والكشوفات والتقارير في كامل التطبيق</span>
                    </div>
                    <select
                      value={dateFormat}
                      onChange={(e) => setDateFormat(e.target.value)}
                      className="w-full sm:w-auto px-3 py-2 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl text-xs font-bold cursor-pointer focus:outline-none focus:ring-2 focus:ring-amber-500/30 text-slate-800 dark:text-slate-100 shadow-2xs"
                    >
                      <optgroup label="تنسيقات نصية (عرض الشهر كتابة):">
                        <option value="D-MMMM_AR-YYYY">اليوم - اسم الشهر بالعربي - السنة (1-يناير-2026)</option>
                        <option value="DD-MMMM_AR-YYYY">يوم بخانتين - الشهر بالعربي - السنة (01-يناير-2026)</option>
                        <option value="D-MMM_EN-YYYY">اليوم - الشهر المختصر بالإنجليزي - السنة (1-Jan-2026)</option>
                        <option value="DD-MMM_EN-YYYY">يوم بخانتين - الشهر المختصر بالإنجليزي - السنة (01-Jan-2026)</option>
                        <option value="D-MMMM_EN-YYYY">اليوم - الشهر الكامل بالإنجليزي - السنة (1-January-2026)</option>
                        <option value="DD-MMMM_EN-YYYY">يوم بخانتين - الشهر الكامل بالإنجليزي - السنة (01-January-2026)</option>
                      </optgroup>
                      <optgroup label="تنسيقات رقمية (بترتيب: اليوم، الشهر، السنة):">
                        <option value="DD/MM/YYYY">اليوم / الشهر / السنة (10/08/2026)</option>
                        <option value="DD-MM-YYYY">اليوم - الشهر - السنة (10-08-2026)</option>
                        <option value="D/M/YYYY">اليوم / الشهر / السنة بدون أصفار (1/8/2026)</option>
                        <option value="D-M-YYYY">اليوم - الشهر - السنة بدون أصفار (1-8-2026)</option>
                      </optgroup>
                      <optgroup label="تنسيقات رقمية (السنة أولاً):">
                        <option value="YYYY-MM-DD">السنة - الشهر - اليوم (2026-08-10)</option>
                        <option value="YYYY/MM/DD">السنة / الشهر / اليوم (2026/08/10)</option>
                      </optgroup>
                    </select>
                  </div>

                  {/* Live Date Preview */}
                  <div className="pt-2 border-t border-slate-200/60 dark:border-slate-700/60 flex items-center justify-between text-xs font-bold text-slate-700 dark:text-slate-300 bg-white/70 dark:bg-slate-900/60 px-3 py-1.5 rounded-lg border border-slate-100 dark:border-slate-800">
                    <span className="text-slate-500 text-[11px]">معاينة التاريخ بالتنسيق المحدد:</span>
                    <span className="font-mono text-amber-600 dark:text-amber-400 font-extrabold text-xs">
                      {formatDateArabic(new Date().toISOString().split('T')[0], dateFormat)}
                    </span>
                  </div>
                </div>

                {/* Compact Density Mode Toggle */}
                <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200/80 flex items-center justify-between gap-2">
                  <div>
                    <span className="block font-extrabold text-xs text-slate-800">وضع العرض المدمج (Compact View)</span>
                    <span className="text-[11px] text-slate-500 font-medium">تقليل الهوامش والمسافات لعرض أقصى قدر من البيانات للشاشات الصغيرة</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setCompactMode(!compactMode)}
                    className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors cursor-pointer shrink-0 ${
                      compactMode ? 'bg-sky-600' : 'bg-slate-300'
                    }`}
                  >
                    <span
                      className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                        compactMode ? '-translate-x-6' : '-translate-x-1'
                      }`}
                    />
                  </button>
                </div>

              </div>
            </div>
          )}

          {/* 🔐 SECTION: APP SECURITY & LOCK */}
          {activeSection === 'security' && (
            <SecuritySettingsTab 
              onLockAppNow={() => {
                onClose();
                if (onLockApp) {
                  onLockApp();
                }
              }} 
            />
          )}

          {/* 💾 SECTION 4: DATA & BACKUP MANAGEMENT */}
          {activeSection === 'data' && (
            <div className="space-y-4 animate-fade-in">
              <div className="bg-rose-50/60 p-3 rounded-xl border border-rose-200/60 flex items-center gap-2.5 text-xs text-rose-900">
                <Database size={16} className="text-rose-600 shrink-0" />
                <p className="font-semibold">خيارات التصدير الشامل والاستعادة وإعادة التهيئة بأمان.</p>
              </div>

              <div className="space-y-3">
                {/* Emergency LocalStorage Backup */}
                <div className="p-3.5 bg-sky-50 rounded-xl border border-sky-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="space-y-0.5">
                    <span className="block font-black text-xs text-sky-950 flex items-center gap-1.5">
                      <KeyRound size={14} className="text-sky-600" />
                      <span>نسخة احتياطية للبيانات (Local Storage)</span>
                    </span>
                    <span className="text-[11px] text-sky-800 font-medium leading-tight">
                      قراءة جميع المفاتيح والقيم الحالية المخزنة في جهازك وتصديرها كملف JSON لإنقاذها بأمان (قراءة فقط بدون تعديل).
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setIsLocalStorageBackupModalOpen(true)}
                    className="py-2 px-3.5 bg-sky-600 hover:bg-sky-700 text-white rounded-lg text-xs font-bold transition-all shrink-0 cursor-pointer flex items-center justify-center gap-1.5 shadow-2xs"
                  >
                    <Download size={14} />
                    <span>نسخة احتياطية للبيانات</span>
                  </button>
                </div>

                {/* Backup & Restore shortcut */}
                {onOpenBackupModal && (
                  <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200/80 flex items-center justify-between gap-3">
                    <div>
                      <span className="block font-black text-xs text-slate-900">مركز النسخ الاحتياطي والاستعادة</span>
                      <span className="text-[11px] text-slate-500 font-medium">تصدير قاعدة البيانات كاملة بصيغة JSON أو استعادتها بضغطة زر</span>
                    </div>
                    <button
                      onClick={() => {
                        onClose();
                        onOpenBackupModal();
                      }}
                      className="py-1.5 px-3 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-bold transition-all shrink-0 cursor-pointer flex items-center gap-1.5 shadow-2xs"
                    >
                      <Database size={14} />
                      <span>فتح نافذة النسخ</span>
                    </button>
                  </div>
                )}

                {/* Reset Data Danger Zone */}
                {onResetAllData && (
                  <div className="p-3.5 bg-rose-50/80 rounded-xl border border-rose-200/90 space-y-2">
                    <div className="flex items-center gap-2 text-rose-700">
                      <ShieldAlert size={18} className="shrink-0" />
                      <span className="font-black text-xs">منطقة المسح الشامل وإعادة التهيئة (Danger Zone)</span>
                    </div>
                    <p className="text-[11px] text-rose-900 font-medium leading-relaxed">
                      تؤدي هذه العملية إلى مسح كافة البيانات المخزنة محلياً (المشاريع، المصاريف، العمال، الموردين) وإعادة التطبيق للحالة الأولية.
                    </p>
                    <button
                      onClick={() => setShowConfirmReset(true)}
                      className="py-1.5 px-3 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 shadow-2xs"
                    >
                      <AlertTriangle size={14} />
                      <span>إعادة ضبط وإعادة تهيئة كافة البيانات</span>
                    </button>
                  </div>
                )}
              </div>
            </div>
          )}

        </div>

        {/* Footer Actions */}
        <div className="bg-slate-50 p-3.5 sm:p-4 border-t border-slate-200 flex items-center justify-between gap-3 shrink-0">
          <button
            onClick={onClose}
            className="py-2 px-4 bg-white hover:bg-slate-100 text-slate-700 rounded-xl text-xs font-bold border border-slate-200 transition-colors cursor-pointer"
          >
            إلغاء / إغلاق
          </button>

          <button
            onClick={handleSaveAllSettings}
            className="py-2 px-6 bg-amber-500 hover:bg-amber-600 text-slate-950 font-black text-xs sm:text-sm rounded-xl transition-all shadow-md flex items-center gap-1.5 cursor-pointer active:scale-95"
          >
            {savedSuccess ? (
              <>
                <Check size={16} />
                <span>تم الحفظ!</span>
              </>
            ) : (
              <>
                <Check size={16} />
                <span>حفظ وتطبيق الإعدادات</span>
              </>
            )}
          </button>
        </div>

      </div>

      {/* Double Confirmation Modal for Resetting All Data */}
      {showConfirmReset && (
        <div 
          className="fixed inset-0 z-[130] bg-slate-950/85 backdrop-blur-xs flex items-center justify-center p-4 animate-fade-in overscroll-contain"
          onTouchMove={(e) => {
            if (e.target === e.currentTarget) e.preventDefault();
          }}
        >
          <div 
            className="bg-white rounded-2xl border border-rose-200 shadow-2xl p-5 max-w-md w-full space-y-4 text-right dir-rtl animate-scale-up overscroll-contain"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="w-12 h-12 bg-rose-100 text-rose-600 rounded-2xl flex items-center justify-center mx-auto shadow-2xs">
              <AlertTriangle size={26} />
            </div>

            <div className="text-center space-y-1">
              <h3 className="font-black text-base text-slate-900">هل أنت متأكد من مسح كافة البيانات؟</h3>
              <p className="text-xs text-slate-500 font-semibold leading-relaxed">
                سيتم حذف كافة المصاريف والعمال والموردين والمشاريع نهائياً من الذاكرة المحلية. لا يمكن التراجع عن هذا الإجراء إلا بوجود نسخة احتياطية.
              </p>
            </div>

            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-slate-700">
                اكتب كلمة <span className="text-rose-600 font-black">مسح</span> لتأكيد العملية:
              </label>
              <input
                type="text"
                value={resetConfirmText}
                onChange={(e) => setResetConfirmText(e.target.value)}
                placeholder="اكتب مسح هنا"
                className="w-full px-3 py-2 bg-rose-50/50 border border-rose-200 rounded-xl text-center font-black text-xs text-rose-900 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
              />
            </div>

            <div className="flex items-center gap-2 pt-2">
              <button
                onClick={() => setShowConfirmReset(false)}
                className="flex-1 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition-colors cursor-pointer"
              >
                إلغاء وتراجع
              </button>
              <button
                onClick={handleExecuteDataReset}
                className="flex-1 py-2 bg-rose-600 hover:bg-rose-700 text-white text-xs font-black rounded-xl transition-colors shadow-xs cursor-pointer"
              >
                مسح نهائي الآن
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Emergency LocalStorage Backup Modal */}
      <LocalStorageBackupModal
        isOpen={isLocalStorageBackupModalOpen}
        onClose={() => setIsLocalStorageBackupModalOpen(false)}
      />

    </div>
  );
}
