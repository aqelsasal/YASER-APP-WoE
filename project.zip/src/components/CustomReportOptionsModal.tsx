/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  X, 
  Printer, 
  FileSpreadsheet, 
  FileText, 
  CheckCircle2, 
  Layers, 
  Sparkles,
  ArrowRight
} from 'lucide-react';
import { useBodyScrollLock } from '../utils/modalScrollLock';

export type ReportFormatType = 'detailed' | 'condensed' | 'summary';
export type SupplierReportType = ReportFormatType;

interface SummaryMetric {
  label: string;
  value: string | number;
}

interface CustomReportOptionsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: (reportType: ReportFormatType) => void;
  title?: string;
  subtitle?: string;
  targetName?: string;
  targetLabel?: string;
  detailedTitle?: string;
  detailedDescription?: string;
  condensedTitle?: string;
  condensedDescription?: string;
  metrics?: SummaryMetric[];
}

export default function CustomReportOptionsModal({
  isOpen,
  onClose,
  onConfirm,
  title = 'خيارات طباعة تقرير مخصص',
  subtitle = 'يرجى اختيار شكل ونطاق التقرير المطلوب استخراجه وطباعته (PDF)',
  targetName,
  targetLabel = 'الحساب المستهدف',
  detailedTitle = 'تقرير شامل وتفصيلي (كافة البيانات والعمليات الحسابية)',
  detailedDescription = 'يحتوي على كافة سجلات النافذة، كشوفات الحركات التفصيلية، فواتير البنود، الحسابات والتواريخ بالكامل مع كشوفات العمليات الحسابية.',
  condensedTitle = 'تقرير مختصر وموجز (ملخص تنفيذي إحصائي)',
  condensedDescription = 'جدول ملخص للأرصدة والإجماليات حسب الفئات والعملات والمؤشرات الإحصائية العامة دون سرد الحركات التفصيلية اليومية.',
  metrics = []
}: CustomReportOptionsModalProps) {
  const [selectedType, setSelectedType] = useState<ReportFormatType>('detailed');

  // Lock body scroll when modal is open
  useBodyScrollLock(isOpen);

  if (!isOpen) return null;

  const handlePrint = (typeToUse?: ReportFormatType) => {
    const finalType = typeToUse || selectedType;
    onConfirm(finalType);
    onClose();
  };

  return (
    <div 
      className="fixed inset-0 z-[160] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-fade-in dir-rtl"
      onClick={onClose}
    >
      <div 
        className="bg-white rounded-2xl shadow-2xl max-w-lg w-full overflow-hidden border border-slate-200/80 transform transition-all animate-scale-in text-right"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="bg-gradient-to-r from-purple-700 via-indigo-700 to-indigo-800 text-white p-5 relative">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-white/10 backdrop-blur-md rounded-xl border border-white/20 shadow-xs">
                <Printer size={22} className="text-purple-200" />
              </div>
              <div>
                <h3 className="text-base font-extrabold text-white flex items-center gap-2">
                  <span>{title}</span>
                  <span className="text-[10px] font-bold bg-white/20 text-purple-100 px-2 py-0.5 rounded-full border border-white/20">
                    تقرير مخصص
                  </span>
                </h3>
                <p className="text-xs text-purple-200 mt-0.5 font-medium leading-relaxed">
                  {subtitle}
                </p>
              </div>
            </div>
            <button 
              type="button"
              onClick={onClose}
              className="p-1.5 text-white/80 hover:text-white hover:bg-white/15 rounded-lg transition-colors cursor-pointer"
              title="إغلاق"
            >
              <X size={18} />
            </button>
          </div>

          {targetName && (
            <div className="mt-3 pt-3 border-t border-white/15 flex items-center justify-between text-xs">
              <div className="flex items-center gap-1.5 text-white/95">
                <span className="text-purple-200">{targetLabel}:</span>
                <span className="font-extrabold text-white underline decoration-purple-300 underline-offset-4">
                  {targetName}
                </span>
              </div>
            </div>
          )}

          {metrics && metrics.length > 0 && (
            <div className="mt-3 pt-2.5 border-t border-white/15 flex flex-wrap gap-2 text-[11px]">
              {metrics.map((m, idx) => (
                <div key={idx} className="bg-white/15 px-2.5 py-0.5 rounded-lg font-bold text-purple-100 border border-white/10">
                  <span className="text-purple-200 ml-1">{m.label}:</span>
                  <span>{m.value}</span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Content Body */}
        <div className="p-5 space-y-4">
          <div className="text-xs font-bold text-slate-700">
            حدد نوع وهيئة التقرير المخصص للطباعة:
          </div>

          {/* Option 1: Detailed / Comprehensive Report */}
          <div 
            onClick={() => setSelectedType('detailed')}
            className={`relative p-4 rounded-xl border-2 transition-all cursor-pointer text-right flex flex-col gap-2 ${
              selectedType === 'detailed'
                ? 'border-purple-600 bg-purple-50/70 shadow-xs'
                : 'border-slate-200 hover:border-purple-300 hover:bg-slate-50/70 bg-white'
            }`}
          >
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-start gap-3">
                <div className={`p-2 rounded-xl shrink-0 mt-0.5 ${
                  selectedType === 'detailed'
                    ? 'bg-purple-600 text-white'
                    : 'bg-slate-100 text-slate-600'
                }`}>
                  <FileSpreadsheet size={18} />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="text-sm font-extrabold text-slate-900">
                      {detailedTitle}
                    </h4>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-purple-100 text-purple-800 border border-purple-200">
                      موصى به
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                    {detailedDescription}
                  </p>
                </div>
              </div>

              <div className="shrink-0 mt-1">
                <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center transition-all ${
                  selectedType === 'detailed'
                    ? 'border-purple-600 bg-purple-600 text-white'
                    : 'border-slate-300 bg-white'
                }`}>
                  {selectedType === 'detailed' && <CheckCircle2 size={13} className="text-white" />}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2 text-[11px] text-purple-700 font-bold bg-white/80 p-2 rounded-lg border border-purple-200/60 mt-1">
              <Layers size={13} className="shrink-0" />
              <span>يشمل: كشوفات الحسابات الفردية، تفاصيل الفواتير، وحركات المدين والدائن الكاملة.</span>
            </div>
          </div>

          {/* Option 2: Condensed / Summary Report */}
          <div 
            onClick={() => setSelectedType('condensed')}
            className={`relative p-4 rounded-xl border-2 transition-all cursor-pointer text-right flex flex-col gap-2 ${
              selectedType === 'condensed'
                ? 'border-indigo-600 bg-indigo-50/70 shadow-xs'
                : 'border-slate-200 hover:border-indigo-300 hover:bg-slate-50/70 bg-white'
            }`}
          >
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-start gap-3">
                <div className={`p-2 rounded-xl shrink-0 mt-0.5 ${
                  selectedType === 'condensed'
                    ? 'bg-indigo-600 text-white'
                    : 'bg-slate-100 text-slate-600'
                }`}>
                  <FileText size={18} />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="text-sm font-extrabold text-slate-900">
                      {condensedTitle}
                    </h4>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-indigo-100 text-indigo-800 border border-indigo-200">
                      موجز ومكثف
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                    {condensedDescription}
                  </p>
                </div>
              </div>

              <div className="shrink-0 mt-1">
                <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center transition-all ${
                  selectedType === 'condensed'
                    ? 'border-indigo-600 bg-indigo-600 text-white'
                    : 'border-slate-300 bg-white'
                }`}>
                  {selectedType === 'condensed' && <CheckCircle2 size={13} className="text-white" />}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2 text-[11px] text-indigo-700 font-bold bg-white/80 p-2 rounded-lg border border-indigo-200/60 mt-1">
              <Sparkles size={13} className="shrink-0" />
              <span>يشمل: جدول إجمالي ملخص للأرصدة وصافي الحسابات والإحصائيات العامة دون تفاصيل الحركات.</span>
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 bg-slate-50 border-t border-slate-200/80 flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2.5 rounded-xl border border-slate-300 text-slate-700 hover:bg-slate-100 text-xs font-bold transition-all cursor-pointer"
          >
            إلغاء / إغلاق
          </button>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => handlePrint()}
              className="py-2.5 px-5 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white rounded-xl font-black text-xs shadow-md shadow-indigo-600/20 active:scale-98 transition-all flex items-center gap-2 cursor-pointer"
            >
              <Printer size={15} />
              <span>
                طباعة وتصدير {selectedType === 'detailed' ? 'التقرير الشامل' : 'التقرير المختصر'} (PDF)
              </span>
              <ArrowRight size={14} className="rotate-180" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
