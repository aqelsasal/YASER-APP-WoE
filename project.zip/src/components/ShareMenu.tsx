/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Share2, 
  MessageSquare, 
  Copy, 
  Check, 
  ExternalLink, 
  Smartphone,
  X,
  FileSpreadsheet,
  FileText,
  ArrowRight,
  Loader2,
  ListOrdered,
  PieChart
} from 'lucide-react';
import { useBodyScrollLock } from '../utils/modalScrollLock';

interface ShareMenuProps {
  title: string;
  textToShare: string;
  buttonLabel?: string;
  className?: string;
  variant?: 'button' | 'icon' | 'outline' | 'mini';
  onExportExcel?: () => void;
  onExportPDF?: () => void;
  onSharePDF?: (format: 'detailed' | 'summary', method: 'whatsapp' | 'system') => Promise<void> | void;
  isOpen?: boolean;
  onClose?: () => void;
}

export default function ShareMenu({
  title,
  textToShare,
  buttonLabel = 'مشاركة',
  className = '',
  variant = 'button',
  onExportExcel,
  onExportPDF,
  onSharePDF,
  isOpen: externalIsOpen,
  onClose
}: ShareMenuProps) {
  const [internalIsOpen, setInternalIsOpen] = useState(false);
  const [copied, setCopied] = useState(false);
  const [step, setStep] = useState<'main' | 'choose_format'>('main');
  const [selectedMethod, setSelectedMethod] = useState<'whatsapp' | 'system'>('whatsapp');
  const [isSharingLoading, setIsSharingLoading] = useState(false);
  const [loadingText, setLoadingText] = useState('');

  const isModalOpen = externalIsOpen !== undefined ? externalIsOpen : internalIsOpen;

  // Lock body scroll when share menu is open
  useBodyScrollLock(isModalOpen);

  const closeMenu = () => {
    if (onClose) onClose();
    setInternalIsOpen(false);
    setStep('main');
    setIsSharingLoading(false);
  };

  const toggleMenu = () => {
    if (isModalOpen) {
      closeMenu();
    } else {
      setStep('main');
      setInternalIsOpen(true);
    }
  };

  // Clean formatted text for sharing
  const getShareText = () => textToShare.trim();

  // Native share (Bluetooth, WhatsApp, AirDrop, etc. via OS)
  const handleSystemShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: title,
          text: getShareText(),
        });
        closeMenu();
      } catch (err) {
        console.warn('System share error or cancelled:', err);
      }
    } else {
      handleCopyToClipboard();
    }
  };

  // WhatsApp direct text share
  const handleWhatsAppTextShare = () => {
    const encodedText = encodeURIComponent(getShareText());
    const whatsappUrl = `https://api.whatsapp.com/send?text=${encodedText}`;
    window.open(whatsappUrl, '_blank');
    closeMenu();
  };

  // WhatsApp Excel (.xlsx) file share
  const handleWhatsAppExcelShare = () => {
    closeMenu();
    if (onExportExcel) {
      onExportExcel();
    }
  };

  // Initiate PDF share by showing format selection (Detailed or Summary)
  const handleStartPDFShare = (method: 'whatsapp' | 'system') => {
    setSelectedMethod(method);
    setStep('choose_format');
  };

  // Direct execution of PDF share after choosing format (Detailed vs Summary)
  const handleExecutePDFShare = async (format: 'detailed' | 'summary') => {
    setIsSharingLoading(true);
    setLoadingText(selectedMethod === 'whatsapp' ? 'جاري تجهيز مستند PDF وفتح تطبيق الواتساب...' : 'جاري تجهيز مستند PDF وفتح نافذة المشاركة بالهاتف...');

    try {
      if (onSharePDF) {
        await onSharePDF(format, selectedMethod);
        // Automatically close menu once share intent is initiated
        setTimeout(() => {
          closeMenu();
        }, 800);
      } else if (onExportPDF) {
        closeMenu();
        onExportPDF();
      }
    } catch (err) {
      console.error('Error sharing PDF directly:', err);
      setIsSharingLoading(false);
    }
  };

  // Copy to Clipboard
  const handleCopyToClipboard = () => {
    navigator.clipboard.writeText(getShareText());
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  // Determine button styles based on variant
  const getButtonStyles = () => {
    if (variant === 'icon') {
      return 'p-2 hover:bg-slate-100 text-slate-500 hover:text-slate-700 rounded-xl transition-colors cursor-pointer border border-slate-200/60 bg-white';
    }
    if (variant === 'mini') {
      return 'p-1 hover:bg-slate-50 text-slate-400 hover:text-slate-600 rounded-md transition-colors cursor-pointer';
    }
    if (variant === 'outline') {
      return 'h-10 px-3.5 bg-white hover:bg-slate-50 text-slate-800 font-bold text-xs border border-slate-200/90 rounded-xl shadow-xs hover:shadow-md hover:-translate-y-0.5 transition-all duration-200 flex items-center gap-2 cursor-pointer shrink-0';
    }
    return 'h-10 px-3.5 bg-violet-600 hover:bg-violet-700 text-white font-bold text-xs rounded-xl shadow-xs hover:shadow-md hover:-translate-y-0.5 transition-all duration-200 flex items-center gap-2 cursor-pointer shrink-0';
  };

  const isWebShareSupported = typeof navigator !== 'undefined' && !!navigator.share;

  return (
    <div className="relative inline-block text-right dir-rtl">
      {/* Trigger Button (if not controlled externally or if explicitly rendered) */}
      {externalIsOpen === undefined && (
        <button
          onClick={toggleMenu}
          className={`${getButtonStyles()} ${className}`}
          title="مشاركة البيانات"
          id={`share-btn-${title.replace(/\s+/g, '-')}`}
        >
          <Share2 size={variant === 'mini' ? 14 : 16} className={variant === 'outline' ? 'text-indigo-600 shrink-0' : 'shrink-0'} />
          {variant !== 'icon' && variant !== 'mini' && <span>{buttonLabel}</span>}
        </button>
      )}

      {/* Share Modal/Dropdown */}
      {isModalOpen && (
        <div 
          className="fixed inset-0 z-[100] bg-slate-900/40 backdrop-blur-2xs flex items-center justify-center p-4 overflow-y-auto dir-rtl text-right overscroll-contain"
          onTouchMove={(e) => {
            if (e.target === e.currentTarget) e.preventDefault();
          }}
          onClick={closeMenu}
        >
          {/* Dialog popup */}
          <div 
            onClick={(e) => e.stopPropagation()}
            className="relative w-96 max-w-[95vw] bg-white rounded-2xl border border-slate-200/90 shadow-2xl p-4 space-y-3.5 animate-scale-up text-right my-auto overscroll-contain"
          >
            {/* Loading Overlay */}
            {isSharingLoading && (
              <div className="absolute inset-0 z-20 bg-white/90 backdrop-blur-2xs rounded-2xl flex flex-col items-center justify-center p-6 text-center space-y-3">
                <Loader2 size={36} className="animate-spin text-rose-600" />
                <p className="font-extrabold text-sm text-slate-800">{loadingText}</p>
                <span className="text-[11px] text-slate-500">يتم إعداد مستند الـ PDF باللغة العربية مع تكرار الترويسة والتذييل...</span>
              </div>
            )}

            {/* STEP 1: Main Sharing Methods */}
            {step === 'main' && (
              <>
                <div className="flex items-center justify-between border-b border-slate-100 pb-2.5">
                  <span className="font-extrabold text-slate-800 text-xs flex items-center gap-1.5">
                    <Share2 size={15} className="text-violet-600" />
                    خيارات مشاركة التقرير المالي
                  </span>
                  <button 
                    onClick={closeMenu}
                    className="text-slate-400 hover:text-slate-600 cursor-pointer p-1 rounded-lg"
                    title="إغلاق"
                  >
                    <X size={16} />
                  </button>
                </div>

                <p className="text-[11.5px] text-slate-600 leading-relaxed font-medium">
                  اختر طريقة المشاركة المطلوبة (مستند PDF رسمي، كشف إكسل، أو ملخص نصي مباشر):
                </p>

                <div className="space-y-2 pt-0.5">
                  {/* WhatsApp PDF Document Share */}
                  <button
                    onClick={() => handleStartPDFShare('whatsapp')}
                    className="w-full flex items-center gap-3 px-3.5 py-2.5 bg-rose-50/90 hover:bg-rose-100/90 text-rose-900 rounded-xl text-xs font-bold transition-all text-right cursor-pointer border border-rose-200/70 shadow-2xs group"
                  >
                    <div className="p-2 bg-rose-500 text-white rounded-lg shrink-0 shadow-xs group-hover:scale-105 transition-transform">
                      <FileText size={16} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <span className="block text-rose-950 font-extrabold text-[12px]">مشاركة تقرير PDF عبر الواتساب</span>
                        <span className="text-[10px] bg-rose-200/80 text-rose-800 px-1.5 py-0.5 rounded-md font-bold">مستند رسمي 📄</span>
                      </div>
                      <span className="text-[10.5px] text-rose-700 block font-normal truncate mt-0.5">مشاركة مباشرة (مفصل أو مختصر) كمستند PDF</span>
                    </div>
                  </button>

                  {/* Native Phone Share for PDF */}
                  <button
                    onClick={() => handleStartPDFShare('system')}
                    className="w-full flex items-center gap-3 px-3.5 py-2.5 bg-violet-50/90 hover:bg-violet-100/90 text-violet-900 rounded-xl text-xs font-bold transition-all text-right cursor-pointer border border-violet-200/70 shadow-2xs group"
                  >
                    <div className="p-2 bg-violet-600 text-white rounded-lg shrink-0 shadow-xs group-hover:scale-105 transition-transform">
                      <Smartphone size={16} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <span className="block text-violet-950 font-extrabold text-[12px]">مشاركة PDF عبر تطبيقات الجوال</span>
                        <span className="text-[10px] bg-violet-200/80 text-violet-800 px-1.5 py-0.5 rounded-md font-bold">بلوتوث وطباعة 📱</span>
                      </div>
                      <span className="text-[10.5px] text-violet-700 block font-normal truncate mt-0.5">فتح نافذة مشاركة الهاتف الرسمية أو الطباعة</span>
                    </div>
                  </button>

                  {/* WhatsApp Excel (.xlsx) Share */}
                  {onExportExcel && (
                    <button
                      onClick={handleWhatsAppExcelShare}
                      className="w-full flex items-center gap-3 px-3.5 py-2.5 bg-emerald-50/90 hover:bg-emerald-100/90 text-emerald-900 rounded-xl text-xs font-bold transition-all text-right cursor-pointer border border-emerald-200/70 shadow-2xs group"
                    >
                      <div className="p-2 bg-emerald-600 text-white rounded-lg shrink-0 shadow-xs group-hover:scale-105 transition-transform">
                        <FileSpreadsheet size={16} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <span className="block text-emerald-950 font-extrabold text-[12px]">مشاركة إكسل (.xlsx) عبر الواتساب</span>
                          <span className="text-[10px] bg-emerald-200/80 text-emerald-800 px-1.5 py-0.5 rounded-md font-bold">ملف Excel 📊</span>
                        </div>
                        <span className="text-[10.5px] text-emerald-700 block font-normal truncate mt-0.5">توليد جدول إكسل متكامل ومشاركته عبر واتساب</span>
                      </div>
                      <ExternalLink size={12} className="text-emerald-600 opacity-60 shrink-0" />
                    </button>
                  )}

                  {/* WhatsApp Direct Text Share */}
                  <button
                    onClick={handleWhatsAppTextShare}
                    className="w-full flex items-center gap-3 px-3.5 py-2 bg-slate-50 hover:bg-slate-100/80 text-slate-800 rounded-xl text-xs font-bold transition-colors text-right cursor-pointer border border-slate-200/70"
                  >
                    <div className="p-1.5 bg-emerald-600 text-white rounded-lg shrink-0">
                      <MessageSquare size={14} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <span className="block text-slate-900 font-bold text-[11.5px]">مشاركة نصية مباشرة عبر الواتساب</span>
                      <span className="text-[10px] text-slate-500 block font-normal truncate">إرسال نص التقرير والمجاميع في رسالة</span>
                    </div>
                    <ExternalLink size={12} className="text-slate-400 opacity-60 shrink-0" />
                  </button>

                  {/* OS Native Share for Text */}
                  {isWebShareSupported && (
                    <button
                      onClick={handleSystemShare}
                      className="w-full flex items-center gap-3 px-3.5 py-2 bg-slate-50 hover:bg-slate-100 text-slate-800 rounded-xl text-xs font-bold transition-colors text-right cursor-pointer border border-slate-200/60"
                    >
                      <Smartphone size={14} className="text-slate-600 shrink-0" />
                      <span className="flex-1 text-[11.5px]">مشاركة النص عبر تطبيقات أخرى بالجوال</span>
                    </button>
                  )}

                  {/* Copy Option */}
                  <button
                    onClick={handleCopyToClipboard}
                    className="w-full flex items-center justify-between px-3.5 py-2 hover:bg-slate-50 text-slate-700 rounded-xl text-xs font-bold transition-colors text-right cursor-pointer border border-slate-100"
                  >
                    <div className="flex items-center gap-2">
                      <Copy size={14} className="text-slate-500" />
                      <span className="text-[11.5px]">نسخ النص كاملاً للحافظة</span>
                    </div>
                    {copied ? (
                      <span className="text-emerald-600 flex items-center gap-1 text-[10px] font-bold">
                        <Check size={12} /> تم النسخ!
                      </span>
                    ) : (
                      <span className="text-[10px] text-slate-400">نسخ</span>
                    )}
                  </button>
                  {/* Cancel / Close Action */}
                  <div className="pt-2 border-t border-slate-100 flex items-center justify-end">
                    <button
                      type="button"
                      onClick={closeMenu}
                      className="w-full py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition-colors cursor-pointer text-center"
                    >
                      إلغاء / إغلاق
                    </button>
                  </div>
                </div>
              </>
            )}

            {/* STEP 2: Choose Report Type (Detailed or Summary) for Direct Share */}
            {step === 'choose_format' && (
              <div className="space-y-3 animate-fade-in">
                <div className="flex items-center justify-between border-b border-slate-100 pb-2.5">
                  <button
                    onClick={() => setStep('main')}
                    className="flex items-center gap-1 text-xs font-extrabold text-sky-700 hover:text-sky-800 cursor-pointer"
                  >
                    <ArrowRight size={14} />
                    <span>الرجوع لطرق المشاركة</span>
                  </button>
                  <button 
                    onClick={closeMenu}
                    className="text-slate-400 hover:text-slate-600 cursor-pointer p-1 rounded-lg"
                    title="إغلاق"
                  >
                    <X size={16} />
                  </button>
                </div>

                <div className="space-y-1">
                  <h4 className="font-extrabold text-xs text-slate-800">
                    اختر نوع تقرير الـ PDF المطلوب مشاركته مباشرة:
                  </h4>
                  <p className="text-[11px] text-slate-500">
                    سيتم توليد المستند بالترويسة والتذييل الرسميين وتمريره فوراً عبر {selectedMethod === 'whatsapp' ? 'الواتساب 💬' : 'نافذة المشاركة بالجوال 📱'}:
                  </p>
                </div>

                <div className="space-y-2.5 pt-1">
                  {/* Format 1: Detailed Report */}
                  <button
                    onClick={() => handleExecutePDFShare('detailed')}
                    className="w-full flex items-start gap-3 p-3 bg-gradient-to-r from-sky-50 to-blue-50/60 hover:from-sky-100 hover:to-blue-100 text-sky-950 rounded-xl text-xs font-bold transition-all text-right cursor-pointer border border-sky-200/80 shadow-2xs group"
                  >
                    <div className="p-2.5 bg-sky-600 text-white rounded-xl shrink-0 shadow-xs group-hover:scale-105 transition-transform mt-0.5">
                      <ListOrdered size={18} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-black text-[13px] text-sky-950">📋 تقرير مفصل (شامل)</span>
                        <span className="text-[10px] bg-sky-200 text-sky-800 px-2 py-0.5 rounded-full font-extrabold">تفصيلي</span>
                      </div>
                      <p className="text-[11px] text-sky-800 leading-relaxed font-normal">
                        يتضمن كافة الجداول والبيانات المسجلة، تفاصيل كل عملية وتاريخها، الملاحظات والمجاميع بدقة كاملة.
                      </p>
                    </div>
                  </button>

                  {/* Format 2: Summary / Executive Report */}
                  <button
                    onClick={() => handleExecutePDFShare('summary')}
                    className="w-full flex items-start gap-3 p-3 bg-gradient-to-r from-indigo-50 to-violet-50/60 hover:from-indigo-100 hover:to-violet-100 text-indigo-950 rounded-xl text-xs font-bold transition-all text-right cursor-pointer border border-indigo-200/80 shadow-2xs group"
                  >
                    <div className="p-2.5 bg-indigo-600 text-white rounded-xl shrink-0 shadow-xs group-hover:scale-105 transition-transform mt-0.5">
                      <PieChart size={18} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-black text-[13px] text-indigo-950">📊 تقرير تنفيذي مختصر (موجز)</span>
                        <span className="text-[10px] bg-indigo-200 text-indigo-800 px-2 py-0.5 rounded-full font-extrabold">ملخص ومجاميع</span>
                      </div>
                      <p className="text-[11px] text-indigo-800 leading-relaxed font-normal">
                        ملخص تنفيذي يركز على إجمالي الأرصدة، المجاميع العامة، والرسوم البيانية بدون تفاصيل العمليات الفرعية.
                      </p>
                    </div>
                  </button>

                  {/* Cancel / Close Action */}
                  <div className="pt-2 border-t border-slate-100 flex items-center justify-end">
                    <button
                      type="button"
                      onClick={closeMenu}
                      className="w-full py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition-colors cursor-pointer text-center"
                    >
                      إلغاء / إغلاق
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
