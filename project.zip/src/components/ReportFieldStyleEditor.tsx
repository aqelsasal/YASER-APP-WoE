/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Interactive Field Editor with Typography, Formatting, Alignment, Direction, and Icon Controls
 */

import React, { useState } from 'react';
import { 
  Bold, 
  Italic, 
  Underline, 
  AlignRight, 
  AlignCenter, 
  AlignLeft, 
  ArrowLeftRight, 
  Type, 
  Palette, 
  Sliders, 
  ChevronDown, 
  ChevronUp, 
  Sparkles,
  MapPin,
  Building,
  Navigation,
  Home,
  Mail,
  AtSign,
  Send,
  Globe,
  Link,
  ExternalLink,
  Smartphone,
  Phone,
  PhoneCall,
  MessageSquare,
  Hash,
  FileText
} from 'lucide-react';
import { 
  FieldTypography, 
  AVAILABLE_FONT_FAMILIES, 
  AVAILABLE_FOOTER_ICONS, 
  typographyToReactStyle 
} from '../utils/reportHeaderFooterConfig';

interface ReportFieldStyleEditorProps {
  label: string;
  subLabel?: string;
  fieldKey: string;
  text: string;
  onTextChange: (newText: string) => void;
  style: FieldTypography;
  onStyleChange: (newStyle: FieldTypography) => void;
  icon?: string;
  onIconChange?: (newIcon: string) => void;
  placeholder?: string;
  isRtlDefault?: boolean;
}

const PRESET_COLORS = [
  { hex: '#002B49', label: 'كحلي داكن (الرسمي)' },
  { hex: '#E85D25', label: 'برتقالي الهوية' },
  { hex: '#1e293b', label: 'رمادي داكن' },
  { hex: '#334155', label: 'رمادي نصوص' },
  { hex: '#64748b', label: 'رمادي فرعي' },
  { hex: '#16a34a', label: 'أخضر مالي' },
  { hex: '#2563eb', label: 'أزرق ملكي' },
  { hex: '#000000', label: 'أسود خالص' },
];

export default function ReportFieldStyleEditor({
  label,
  subLabel,
  fieldKey,
  text,
  onTextChange,
  style,
  onStyleChange,
  icon,
  onIconChange,
  placeholder = '',
}: ReportFieldStyleEditorProps) {
  const [isExpanded, setIsExpanded] = useState(false);
  const [showIconPicker, setShowIconPicker] = useState(false);

  const updateProp = <K extends keyof FieldTypography>(key: K, value: FieldTypography[K]) => {
    onStyleChange({
      ...style,
      [key]: value,
    });
  };

  const renderLucideIcon = (iconId: string, size = 13) => {
    switch (iconId) {
      case 'building': return <Building size={size} />;
      case 'navigation': return <Navigation size={size} />;
      case 'home': return <Home size={size} />;
      case 'mail': return <Mail size={size} />;
      case 'at-sign': return <AtSign size={size} />;
      case 'send': return <Send size={size} />;
      case 'globe': return <Globe size={size} />;
      case 'link': return <Link size={size} />;
      case 'external-link': return <ExternalLink size={size} />;
      case 'smartphone': return <Smartphone size={size} />;
      case 'phone': return <Phone size={size} />;
      case 'phone-call': return <PhoneCall size={size} />;
      case 'message-square': return <MessageSquare size={size} />;
      case 'hash': return <Hash size={size} />;
      case 'file-text': return <FileText size={size} />;
      case 'map-pin':
      default:
        return <MapPin size={size} />;
    }
  };

  return (
    <div className="p-3 bg-white border border-slate-200/90 hover:border-sky-300 rounded-xl shadow-2xs transition-all space-y-2.5">
      {/* Field Header & Quick Controls */}
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          {icon !== undefined && (
            <div className="relative">
              <button
                type="button"
                onClick={() => setShowIconPicker(!showIconPicker)}
                title="تعديل الأيقونة"
                className="w-7 h-7 rounded-full bg-[#E85D25] text-white flex items-center justify-center hover:scale-105 transition-transform shadow-xs cursor-pointer"
              >
                {renderLucideIcon(icon)}
              </button>

              {/* Icon Picker Popover */}
              {showIconPicker && (
                <div 
                  className="absolute z-50 top-9 right-0 w-64 bg-white border border-slate-300 rounded-xl shadow-xl p-2.5 space-y-2 text-right"
                  onClick={(e) => e.stopPropagation()}
                >
                  <div className="text-[11px] font-black text-slate-700 border-b pb-1.5 flex items-center justify-between">
                    <span>اختر أيقونة الخانة:</span>
                    <button
                      type="button"
                      onClick={() => setShowIconPicker(false)}
                      className="text-slate-400 hover:text-slate-600 text-xs px-1"
                    >
                      ✕
                    </button>
                  </div>
                  <div className="grid grid-cols-4 gap-1.5 max-h-48 overflow-y-auto p-0.5">
                    {AVAILABLE_FOOTER_ICONS.map((ic) => (
                      <button
                        key={ic.id}
                        type="button"
                        onClick={() => {
                          if (onIconChange) onIconChange(ic.id);
                          setShowIconPicker(false);
                        }}
                        title={ic.name}
                        className={`flex flex-col items-center justify-center p-2 rounded-lg text-xs gap-1 transition-all ${
                          icon === ic.id 
                            ? 'bg-amber-100 border border-amber-400 text-amber-900 font-bold' 
                            : 'hover:bg-slate-100 text-slate-700'
                        }`}
                      >
                        <div className="w-6 h-6 rounded-full bg-[#E85D25] text-white flex items-center justify-center">
                          {renderLucideIcon(ic.id, 12)}
                        </div>
                        <span className="text-[9px] truncate max-w-full">{ic.name.split(' ')[0]}</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          <div>
            <span className="text-xs font-bold text-slate-800">{label}</span>
            {subLabel && <span className="text-[10px] text-slate-400 mr-1.5 font-medium">({subLabel})</span>}
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          {/* Quick Font Size Indicator */}
          <span className="text-[10px] font-bold text-slate-500 bg-slate-100 px-1.5 py-0.5 rounded">
            {style.fontSize}px
          </span>

          {/* Quick Color Dot */}
          <span 
            className="w-3.5 h-3.5 rounded-full border border-slate-300"
            style={{ backgroundColor: style.color }}
            title={`لون الخط: ${style.color}`}
          />

          {/* Toggle Full Typography Toolbar */}
          <button
            type="button"
            onClick={() => setIsExpanded(!isExpanded)}
            className={`px-2 py-1 text-[11px] font-bold rounded-lg border flex items-center gap-1 transition-all cursor-pointer ${
              isExpanded 
                ? 'bg-sky-50 border-sky-300 text-sky-800' 
                : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
            }`}
          >
            <Sliders size={11} />
            <span>تنسيق الخط</span>
            {isExpanded ? <ChevronUp size={11} /> : <ChevronDown size={11} />}
          </button>
        </div>
      </div>

      {/* Main Text Input */}
      <div className="relative">
        <input
          type="text"
          value={text}
          onChange={(e) => onTextChange(e.target.value)}
          placeholder={placeholder}
          dir={style.dir}
          style={{
            textAlign: style.align,
            fontFamily: style.fontFamily,
          }}
          className="w-full px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-medium focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 transition-all"
        />
      </div>

      {/* Expanded Typography & Styling Panel */}
      {isExpanded && (
        <div className="pt-2.5 border-t border-slate-100 space-y-2.5 text-xs bg-slate-50/70 p-2.5 rounded-lg">
          {/* Row 1: Font Family & Font Size */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {/* Font Family */}
            <div className="space-y-1">
              <label className="text-[11px] font-bold text-slate-600 flex items-center gap-1">
                <Type size={11} className="text-sky-600" />
                <span>نوع الخط:</span>
              </label>
              <select
                value={style.fontFamily}
                onChange={(e) => updateProp('fontFamily', e.target.value)}
                className="w-full px-2 py-1 bg-white border border-slate-200 rounded-md text-[11px] font-semibold text-slate-700 focus:outline-none focus:border-sky-500"
              >
                {AVAILABLE_FONT_FAMILIES.map((f) => (
                  <option key={f.id} value={f.id}>
                    {f.name}
                  </option>
                ))}
              </select>
            </div>

            {/* Font Size */}
            <div className="space-y-1">
              <label className="text-[11px] font-bold text-slate-600 flex items-center justify-between">
                <span>حجم الخط:</span>
                <span className="font-mono text-sky-700 font-black">{style.fontSize}px</span>
              </label>
              <div className="flex items-center gap-1.5 bg-white border border-slate-200 rounded-md p-0.5">
                <button
                  type="button"
                  onClick={() => updateProp('fontSize', Math.max(9, style.fontSize - 0.5))}
                  className="px-2 py-0.5 bg-slate-100 hover:bg-slate-200 rounded text-slate-700 font-black text-xs cursor-pointer"
                  title="تصغير الخط"
                >
                  -
                </button>
                <input
                  type="range"
                  min="9"
                  max="26"
                  step="0.5"
                  value={style.fontSize}
                  onChange={(e) => updateProp('fontSize', parseFloat(e.target.value))}
                  className="w-full accent-sky-600 cursor-pointer h-1.5"
                />
                <button
                  type="button"
                  onClick={() => updateProp('fontSize', Math.min(26, style.fontSize + 0.5))}
                  className="px-2 py-0.5 bg-slate-100 hover:bg-slate-200 rounded text-slate-700 font-black text-xs cursor-pointer"
                  title="تكبير الخط"
                >
                  +
                </button>
              </div>
            </div>
          </div>

          {/* Row 2: Color Picker & Preset Palettes */}
          <div className="space-y-1">
            <label className="text-[11px] font-bold text-slate-600 flex items-center gap-1">
              <Palette size={11} className="text-amber-600" />
              <span>لون الخط:</span>
            </label>
            <div className="flex items-center flex-wrap gap-1.5">
              {/* Native Color Picker */}
              <label className="flex items-center gap-1 px-1.5 py-0.5 bg-white border border-slate-200 rounded-md cursor-pointer hover:border-slate-300">
                <input
                  type="color"
                  value={style.color}
                  onChange={(e) => updateProp('color', e.target.value)}
                  className="w-5 h-5 rounded cursor-pointer border-none p-0 bg-transparent"
                />
                <span className="text-[10px] font-mono font-bold text-slate-600">{style.color}</span>
              </label>

              {/* Color Presets */}
              {PRESET_COLORS.map((c) => (
                <button
                  key={c.hex}
                  type="button"
                  onClick={() => updateProp('color', c.hex)}
                  title={c.label}
                  className={`w-5 h-5 rounded-md border transition-transform cursor-pointer ${
                    style.color.toLowerCase() === c.hex.toLowerCase() 
                      ? 'scale-115 ring-2 ring-sky-500 border-white' 
                      : 'border-slate-300 hover:scale-110'
                  }`}
                  style={{ backgroundColor: c.hex }}
                />
              ))}
            </div>
          </div>

          {/* Row 3: Bold / Italic / Underline + Alignment + Text Direction */}
          <div className="flex flex-wrap items-center justify-between gap-2 pt-1 border-t border-slate-200/60">
            {/* Style Toggles: Bold, Italic, Underline */}
            <div className="flex items-center gap-1 bg-white border border-slate-200 rounded-md p-0.5">
              <button
                type="button"
                onClick={() => updateProp('bold', !style.bold)}
                className={`p-1 rounded text-xs transition-colors cursor-pointer ${
                  style.bold ? 'bg-sky-600 text-white font-black' : 'text-slate-600 hover:bg-slate-100'
                }`}
                title="عريض (Bold)"
              >
                <Bold size={13} />
              </button>
              <button
                type="button"
                onClick={() => updateProp('italic', !style.italic)}
                className={`p-1 rounded text-xs transition-colors cursor-pointer ${
                  style.italic ? 'bg-sky-600 text-white' : 'text-slate-600 hover:bg-slate-100'
                }`}
                title="مائل (Italic)"
              >
                <Italic size={13} />
              </button>
              <button
                type="button"
                onClick={() => updateProp('underline', !style.underline)}
                className={`p-1 rounded text-xs transition-colors cursor-pointer ${
                  style.underline ? 'bg-sky-600 text-white' : 'text-slate-600 hover:bg-slate-100'
                }`}
                title="تحته خط (Underline)"
              >
                <Underline size={13} />
              </button>
            </div>

            {/* Alignment: Right, Center, Left */}
            <div className="flex items-center gap-1 bg-white border border-slate-200 rounded-md p-0.5">
              <button
                type="button"
                onClick={() => updateProp('align', 'right')}
                className={`p-1 rounded text-xs transition-colors cursor-pointer ${
                  style.align === 'right' ? 'bg-sky-600 text-white' : 'text-slate-600 hover:bg-slate-100'
                }`}
                title="محاذاة لليمين"
              >
                <AlignRight size={13} />
              </button>
              <button
                type="button"
                onClick={() => updateProp('align', 'center')}
                className={`p-1 rounded text-xs transition-colors cursor-pointer ${
                  style.align === 'center' ? 'bg-sky-600 text-white' : 'text-slate-600 hover:bg-slate-100'
                }`}
                title="محاذاة للوسط"
              >
                <AlignCenter size={13} />
              </button>
              <button
                type="button"
                onClick={() => updateProp('align', 'left')}
                className={`p-1 rounded text-xs transition-colors cursor-pointer ${
                  style.align === 'left' ? 'bg-sky-600 text-white' : 'text-slate-600 hover:bg-slate-100'
                }`}
                title="محاذاة لليسار"
              >
                <AlignLeft size={13} />
              </button>
            </div>

            {/* Direction: RTL vs LTR */}
            <div className="flex items-center gap-1 bg-white border border-slate-200 rounded-md p-0.5">
              <button
                type="button"
                onClick={() => updateProp('dir', 'rtl')}
                className={`px-2 py-1 rounded text-[10px] font-black transition-colors cursor-pointer ${
                  style.dir === 'rtl' ? 'bg-sky-600 text-white' : 'text-slate-600 hover:bg-slate-100'
                }`}
                title="اتجاه من اليمين لليسار (عربي)"
              >
                RTL (يمين)
              </button>
              <button
                type="button"
                onClick={() => updateProp('dir', 'ltr')}
                className={`px-2 py-1 rounded text-[10px] font-black transition-colors cursor-pointer ${
                  style.dir === 'ltr' ? 'bg-sky-600 text-white' : 'text-slate-600 hover:bg-slate-100'
                }`}
                title="اتجاه من اليسار لليمين (إنجليزي / أرقام)"
              >
                LTR (يسار)
              </button>
            </div>
          </div>

          {/* Live Mini Preview */}
          <div className="pt-2 border-t border-slate-200/80">
            <span className="text-[10px] text-slate-400 block mb-1">معاينة مباشرة للخانة كما ستظهر في التقرير:</span>
            <div className="p-2 bg-white rounded border border-dashed border-slate-300 flex items-center gap-2 overflow-hidden">
              {icon !== undefined && (
                <span className="w-5 h-5 rounded-full bg-[#E85D25] text-white flex items-center justify-center shrink-0">
                  {renderLucideIcon(icon, 10)}
                </span>
              )}
              <div 
                className="w-full truncate"
                style={typographyToReactStyle(style)}
              >
                {text || placeholder || 'نص تجريبي للمعاينة'}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
