import React, { useState, useRef, useEffect } from 'react';
import { ChevronDown, Search, X, Check, HardHat, Briefcase, Truck, UserPlus } from 'lucide-react';
import { Worker, Employee, Supplier } from '../types';
import QuickAddAccountModal from './QuickAddAccountModal';

interface PostingAccountSelectProps {
  value: string;
  onChange: (value: string) => void;
  workers: Worker[];
  employees: Employee[];
  suppliers: Supplier[];
  disabled?: boolean;
  currency?: string;
  sharedRole?: string;
  onAddWorker?: (worker: Omit<Worker, 'id' | 'ledger'>) => Worker | void;
  onAddEmployee?: (employee: Omit<Employee, 'id' | 'ledger'>) => Employee | void;
  onAddSupplier?: (supplier: Omit<Supplier, 'id' | 'ledger'>) => Supplier | void;
  compact?: boolean;
}

export const PostingAccountSelect: React.FC<PostingAccountSelectProps> = ({
  value,
  onChange,
  workers,
  employees,
  suppliers,
  disabled = false,
  currency = 'YER',
  sharedRole = 'admin',
  onAddWorker,
  onAddEmployee,
  onAddSupplier,
  compact = false
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [quickAddType, setQuickAddType] = useState<'employee' | 'worker' | 'supplier' | null>(null);
  const [dropdownPosition, setDropdownPosition] = useState<{ top: number; right: number; width: number }>({ top: 0, right: 0, width: 320 });
  const containerRef = useRef<HTMLDivElement>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);

  const updateDropdownPos = () => {
    if (containerRef.current) {
      const rect = containerRef.current.getBoundingClientRect();
      const popupWidth = compact ? Math.min(340, window.innerWidth - 20) : Math.max(rect.width, 320);
      const fitsBelow = rect.bottom + 340 < window.innerHeight;
      const top = fitsBelow ? rect.bottom + 4 : Math.max(10, rect.top - 340);
      let right = window.innerWidth - rect.right;
      if (right + popupWidth > window.innerWidth) {
        right = Math.max(10, window.innerWidth - popupWidth - 10);
      }
      if (right < 10) right = 10;
      setDropdownPosition({ top, right, width: popupWidth });
    }
  };

  const handleToggleOpen = () => {
    if (!isOpen) {
      updateDropdownPos();
    }
    setIsOpen(!isOpen);
  };

  // Close when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      const target = event.target as Node;
      if (
        containerRef.current && !containerRef.current.contains(target) &&
        dropdownRef.current && !dropdownRef.current.contains(target)
      ) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Determine selected object details
  let selectedType: 'worker' | 'employee' | 'supplier' | 'none' = 'none';
  let selectedName = '';
  let selectedSub = '';

  if (value && value !== 'none') {
    const [type, id] = value.split(':');
    if (type === 'worker') {
      const w = workers.find(item => item.id === id);
      if (w) {
        selectedType = 'worker';
        selectedName = w.name;
        selectedSub = w.profession || 'عامل';
      }
    } else if (type === 'employee') {
      const emp = employees.find(item => item.id === id);
      if (emp) {
        selectedType = 'employee';
        selectedName = emp.name;
        selectedSub = emp.profession || 'موظف';
      }
    } else if (type === 'supplier') {
      const s = suppliers.find(item => item.id === id);
      if (s) {
        selectedType = 'supplier';
        selectedName = s.name;
        selectedSub = s.materialType || 'مورد';
      }
    }
  }

  // Filter items based on search
  const term = searchTerm.trim().toLowerCase();
  const filteredWorkers = workers.filter(w => 
    !term || w.name.toLowerCase().includes(term) || (w.profession && w.profession.toLowerCase().includes(term))
  );
  const filteredEmployees = employees.filter(e => 
    !term || e.name.toLowerCase().includes(term) || (e.profession && e.profession.toLowerCase().includes(term))
  );
  const filteredSuppliers = suppliers.filter(s => 
    !term || s.name.toLowerCase().includes(term) || (s.materialType && s.materialType.toLowerCase().includes(term))
  );

  const handleSelect = (newValue: string) => {
    onChange(newValue);
    setIsOpen(false);
    setSearchTerm('');
  };

  return (
    <div className="relative w-full text-right dir-rtl" ref={containerRef}>
      {/* Trigger Button */}
      <button
        type="button"
        disabled={disabled}
        onClick={handleToggleOpen}
        className={`w-full ${compact ? 'h-[22px] min-h-[22px] px-1.5 py-0 text-[10px] rounded leading-none' : 'h-[42px] px-3 text-xs rounded-xl'} bg-white border font-bold transition-all flex items-center justify-between gap-1 shadow-2xs cursor-pointer ${
          isOpen ? 'border-rose-500 ring-2 ring-rose-500/10' : 'border-slate-200 hover:border-slate-300'
        }`}
      >
        <div className="flex items-center gap-1 truncate text-right">
          {selectedType === 'worker' && (
            <span className={`inline-flex items-center gap-1 ${compact ? 'px-1 py-0 text-[9.5px] leading-tight' : 'px-2.5 py-1 text-xs'} rounded bg-sky-50 text-sky-800 font-extrabold border border-sky-200 truncate`}>
              <HardHat size={compact ? 10 : 14} className="text-sky-600 shrink-0" />
              <span className="truncate">{selectedName}</span>
              <span className="text-[9px] font-semibold text-sky-600 hidden sm:inline">({selectedSub})</span>
            </span>
          )}

          {selectedType === 'employee' && (
            <span className={`inline-flex items-center gap-1 ${compact ? 'px-1 py-0 text-[9.5px] leading-tight' : 'px-2.5 py-1 text-xs'} rounded bg-indigo-50 text-indigo-800 font-extrabold border border-indigo-200 truncate`}>
              <Briefcase size={compact ? 10 : 14} className="text-indigo-600 shrink-0" />
              <span className="truncate">{selectedName}</span>
              <span className="text-[9px] font-semibold text-indigo-600 hidden sm:inline">({selectedSub})</span>
            </span>
          )}

          {selectedType === 'supplier' && (
            <span className={`inline-flex items-center gap-1 ${compact ? 'px-1 py-0 text-[9.5px] leading-tight' : 'px-2.5 py-1 text-xs'} rounded bg-amber-50 text-amber-800 font-extrabold border border-amber-200 truncate`}>
              <Truck size={compact ? 10 : 14} className="text-amber-600 shrink-0" />
              <span className="truncate">{selectedName}</span>
              <span className="text-[9px] font-semibold text-amber-600 hidden sm:inline">({selectedSub})</span>
            </span>
          )}

          {selectedType === 'none' && (
            <span className="text-slate-500 font-medium truncate text-[10px]">{compact ? '-- بدون ترحيل --' : '-- مصروف عام (بدون ترحيل لحساب) --'}</span>
          )}
        </div>

        <div className="flex items-center gap-1 shrink-0 text-slate-400">
          {value && value !== 'none' && (
            <span
              onClick={(e) => {
                e.stopPropagation();
                handleSelect('');
              }}
              className="p-0.5 hover:text-rose-600 hover:bg-rose-50 rounded-full transition-colors cursor-pointer"
              title="إلغاء الترحيل"
            >
              <X size={compact ? 11 : 13} />
            </span>
          )}
          <ChevronDown size={compact ? 13 : 15} className={`transition-transform duration-200 ${isOpen ? 'rotate-180 text-rose-500' : ''}`} />
        </div>
      </button>

      {/* Popover Dropdown Panel (Positioned Fixed to avoid overflow clipping) */}
      {isOpen && (
        <div 
          ref={dropdownRef}
          style={{
            position: 'fixed',
            top: `${dropdownPosition.top}px`,
            right: `${dropdownPosition.right}px`,
            width: `${dropdownPosition.width}px`,
            zIndex: 9999
          }}
          className="bg-white border border-slate-200 rounded-2xl shadow-2xl overflow-hidden text-right animate-scale-up max-h-80 flex flex-col dir-rtl"
        >
          {/* Search Box */}
          <div className="p-2 border-b border-slate-100 bg-slate-50/80 sticky top-0 z-10">
            <div className="relative">
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="ابحث باسم العامل، الموظف، أو المورد..."
                className="w-full pl-3 pr-8 py-1.5 bg-white border border-slate-200 rounded-lg text-xs text-slate-700 focus:outline-hidden focus:border-rose-500"
              />
              <Search size={14} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
              {searchTerm && (
                <button
                  type="button"
                  onClick={() => setSearchTerm('')}
                  className="absolute left-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 cursor-pointer"
                >
                  <X size={13} />
                </button>
              )}
            </div>
          </div>

          {/* List Options */}
          <div className="overflow-y-auto p-1.5 space-y-2 text-xs">
            {/* General Expense Option */}
            <div
              onClick={() => handleSelect('')}
              className={`p-3 sm:p-3.5 rounded-xl border transition-colors cursor-pointer flex items-center justify-between min-h-[44px] ${
                !value || value === 'none'
                  ? 'bg-rose-50 border-rose-200 text-rose-800 font-bold'
                  : 'bg-slate-50/60 border-slate-100 hover:bg-slate-100 text-slate-600 font-medium'
              }`}
            >
              <span className="text-xs sm:text-sm">-- مصروف عام (بدون ترحيل لحساب) --</span>
              {(!value || value === 'none') && <Check size={16} className="text-rose-600 shrink-0" />}
            </div>

            {/* 1. Employees Group (الموظفين - أولاً) */}
            {(employees.length > 0 || onAddEmployee) && (filteredEmployees.length > 0 || !term || onAddEmployee) && (
              <div className="rounded-xl border border-indigo-100 bg-indigo-50/20 overflow-hidden">
                <div className="bg-gradient-to-r from-indigo-100 to-indigo-50/80 px-3 py-2 font-extrabold text-indigo-900 border-r-4 border-indigo-500 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-1.5">
                    <Briefcase size={15} className="text-indigo-600" />
                    <span className="text-xs sm:text-sm">مجموعة الموظفين</span>
                    <span className="text-[10px] font-normal text-indigo-700">(سيقيد سلفة/دفعة)</span>
                  </div>
                  <span className="bg-indigo-200/80 text-indigo-800 px-2 py-0.5 rounded-md text-[10px] font-bold">
                    {filteredEmployees.length}
                  </span>
                </div>

                <div className="p-1.5 space-y-1">
                  {filteredEmployees.length === 0 ? (
                    <div className="text-slate-400 text-[11px] p-2 text-center">
                      {term ? 'لا يوجد موظفين مطابقين للبحث' : 'لا يوجد موظفين مسجلين حالياً'}
                    </div>
                  ) : (
                    filteredEmployees.map(e => {
                      const valKey = `employee:${e.id}`;
                      const isSelected = value === valKey;
                      return (
                        <div
                          key={valKey}
                          onClick={() => handleSelect(valKey)}
                          className={`px-3 py-2.5 sm:py-3 rounded-xl border-r-3 transition-all cursor-pointer flex items-center justify-between text-xs sm:text-sm min-h-[44px] ${
                            isSelected
                              ? 'bg-indigo-100 text-indigo-950 border-indigo-600 font-extrabold shadow-2xs'
                              : 'bg-white hover:bg-indigo-50/80 text-slate-800 border-indigo-300 font-semibold'
                          }`}
                        >
                          <div className="flex items-center gap-2 truncate">
                            <span className="w-2 h-2 rounded-full bg-indigo-500 shrink-0"></span>
                            <span className="truncate font-bold">{e.name}</span>
                            <span className="text-[11px] text-slate-500 truncate">({e.profession || 'موظف'})</span>
                          </div>
                          {isSelected && <Check size={16} className="text-indigo-700 shrink-0" />}
                        </div>
                      );
                    })
                  )}

                  {/* زر + إضافة موظف جديد */}
                  {onAddEmployee && (
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setQuickAddType('employee');
                      }}
                      className="w-full py-2 px-3 mt-1.5 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-800 border border-dashed border-indigo-300 font-extrabold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer shadow-2xs active:scale-98"
                    >
                      <UserPlus size={14} className="text-indigo-600" />
                      <span>+ إضافة موظف جديد</span>
                    </button>
                  )}
                </div>
              </div>
            )}

            {/* 2. Workers Group (العمال - ثانياً) */}
            {(workers.length > 0 || onAddWorker) && (filteredWorkers.length > 0 || !term || onAddWorker) && (
              <div className="rounded-xl border border-sky-100 bg-sky-50/20 overflow-hidden">
                <div className="bg-gradient-to-r from-sky-100 to-sky-50/80 px-3 py-2 font-extrabold text-sky-900 border-r-4 border-sky-500 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-1.5">
                    <HardHat size={15} className="text-sky-600" />
                    <span className="text-xs sm:text-sm">مجموعة العُمَّال</span>
                    <span className="text-[10px] font-normal text-sky-700">(سيقيد سلفة/أجور)</span>
                  </div>
                  <span className="bg-sky-200/80 text-sky-800 px-2 py-0.5 rounded-md text-[10px] font-bold">
                    {filteredWorkers.length}
                  </span>
                </div>

                <div className="p-1.5 space-y-1">
                  {filteredWorkers.length === 0 ? (
                    <div className="text-slate-400 text-[11px] p-2 text-center">
                      {term ? 'لا يوجد عمال مطابقين للبحث' : 'لا يوجد عمال مسجلين حالياً'}
                    </div>
                  ) : (
                    filteredWorkers.map(w => {
                      const valKey = `worker:${w.id}`;
                      const isSelected = value === valKey;
                      return (
                        <div
                          key={valKey}
                          onClick={() => handleSelect(valKey)}
                          className={`px-3 py-2.5 sm:py-3 rounded-xl border-r-3 transition-all cursor-pointer flex items-center justify-between text-xs sm:text-sm min-h-[44px] ${
                            isSelected
                              ? 'bg-sky-100 text-sky-950 border-sky-600 font-extrabold shadow-2xs'
                              : 'bg-white hover:bg-sky-50/80 text-slate-800 border-sky-300 font-semibold'
                          }`}
                        >
                          <div className="flex items-center gap-2 truncate">
                            <span className="w-2 h-2 rounded-full bg-sky-500 shrink-0"></span>
                            <span className="truncate font-bold">{w.name}</span>
                            <span className="text-[11px] text-slate-500 truncate">({w.profession || 'عامل'})</span>
                          </div>
                          {isSelected && <Check size={16} className="text-sky-700 shrink-0" />}
                        </div>
                      );
                    })
                  )}

                  {/* زر + إضافة عامل جديد */}
                  {onAddWorker && (
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setQuickAddType('worker');
                      }}
                      className="w-full py-2 px-3 mt-1.5 rounded-xl bg-sky-50 hover:bg-sky-100 text-sky-800 border border-dashed border-sky-300 font-extrabold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer shadow-2xs active:scale-98"
                    >
                      <UserPlus size={14} className="text-sky-600" />
                      <span>+ إضافة عامل جديد</span>
                    </button>
                  )}
                </div>
              </div>
            )}

            {/* 3. Suppliers Group (الموردين - ثالثاً) */}
            {(suppliers.length > 0 || onAddSupplier) && (filteredSuppliers.length > 0 || !term || onAddSupplier) && (
              <div className="rounded-xl border border-amber-100 bg-amber-50/20 overflow-hidden">
                <div className="bg-gradient-to-r from-amber-100 to-amber-50/80 px-3 py-2 font-extrabold text-amber-900 border-r-4 border-amber-500 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-1.5">
                    <Truck size={15} className="text-amber-600" />
                    <span className="text-xs sm:text-sm">مجموعة الموردين</span>
                    <span className="text-[10px] font-normal text-amber-700">(سيقيد تسديد/مواد)</span>
                  </div>
                  <span className="bg-amber-200/80 text-amber-800 px-2 py-0.5 rounded-md text-[10px] font-bold">
                    {filteredSuppliers.length}
                  </span>
                </div>

                <div className="p-1.5 space-y-1">
                  {filteredSuppliers.length === 0 ? (
                    <div className="text-slate-400 text-[11px] p-2 text-center">
                      {term ? 'لا يوجد موردين مطابقين للبحث' : 'لا يوجد موردين مسجلين حالياً'}
                    </div>
                  ) : (
                    filteredSuppliers.map(s => {
                      const valKey = `supplier:${s.id}`;
                      const isSelected = value === valKey;
                      return (
                        <div
                          key={valKey}
                          onClick={() => handleSelect(valKey)}
                          className={`px-3 py-2.5 sm:py-3 rounded-xl border-r-3 transition-all cursor-pointer flex items-center justify-between text-xs sm:text-sm min-h-[44px] ${
                            isSelected
                              ? 'bg-amber-100 text-amber-950 border-amber-600 font-extrabold shadow-2xs'
                              : 'bg-white hover:bg-amber-50/80 text-slate-800 border-amber-300 font-semibold'
                          }`}
                        >
                          <div className="flex items-center gap-2 truncate">
                            <span className="w-2 h-2 rounded-full bg-amber-500 shrink-0"></span>
                            <span className="truncate font-bold">{s.name}</span>
                            <span className="text-[11px] text-slate-500 truncate">({s.materialType || 'مورد'})</span>
                          </div>
                          {isSelected && <Check size={16} className="text-amber-700 shrink-0" />}
                        </div>
                      );
                    })
                  )}

                  {/* زر + إضافة مورد جديد */}
                  {onAddSupplier && (
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setQuickAddType('supplier');
                      }}
                      className="w-full py-2 px-3 mt-1.5 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-800 border border-dashed border-amber-300 font-extrabold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer shadow-2xs active:scale-98"
                    >
                      <UserPlus size={14} className="text-amber-600" />
                      <span>+ إضافة مورد جديد</span>
                    </button>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Quick Add Modal */}
      {quickAddType && (
        <QuickAddAccountModal
          isOpen={quickAddType !== null}
          onClose={() => setQuickAddType(null)}
          type={quickAddType}
          currency={currency}
          sharedRole={sharedRole}
          onAddWorker={onAddWorker}
          onAddEmployee={onAddEmployee}
          onAddSupplier={onAddSupplier}
          onSuccessCreated={(newValueKey) => {
            onChange(newValueKey);
            setQuickAddType(null);
            setIsOpen(false);
          }}
        />
      )}
    </div>
  );
};
