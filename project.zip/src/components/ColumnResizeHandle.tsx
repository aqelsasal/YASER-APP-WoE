/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useCallback, useEffect, useRef, useState } from 'react';
import { applyTableFreeze } from '../utils/tableColumnFreeze';
import {
  saveTableColumnWidths,
  scheduleRestoreTableColumnWidths,
  resetTableColumnWidths
} from '../utils/tableColumnWidths';

interface ColumnResizeHandleProps {
  onResize?: (deltaPx: number) => void;
  onAutoFit?: () => void;
  minColumnWidth?: number;
  className?: string;
  title?: string;
}

/**
 * Measures the natural unwrapped width of an element's content without line wrapping.
 * Allows accurate AutoFit that can both EXPAND (if data is wider) and SHRINK (if data is smaller).
 */
const measureNaturalWidth = (element: HTMLElement): number => {
  if (!element) return 0;

  // Create an off-screen container that allows content to stretch to its full intrinsic width
  const container = document.createElement('div');
  container.style.position = 'fixed';
  container.style.left = '-99999px';
  container.style.top = '-99999px';
  container.style.visibility = 'hidden';
  container.style.pointerEvents = 'none';
  container.style.zIndex = '-9999';
  container.style.width = 'max-content';
  container.style.maxWidth = 'none';
  container.style.minWidth = '0';
  container.style.whiteSpace = 'nowrap';
  container.style.display = 'inline-flex';
  container.style.alignItems = 'center';
  container.style.boxSizing = 'border-box';

  // Inherit computed typography from element
  const style = window.getComputedStyle(element);
  container.style.fontFamily = style.fontFamily;
  container.style.fontSize = style.fontSize;
  container.style.fontWeight = style.fontWeight;
  container.style.letterSpacing = style.letterSpacing;
  container.style.direction = style.direction || 'rtl';

  // Clone the node
  const clone = element.cloneNode(true) as HTMLElement;
  clone.style.width = 'auto';
  clone.style.maxWidth = 'none';
  clone.style.minWidth = '0';
  clone.style.whiteSpace = 'nowrap';
  clone.style.display = 'inline-flex';
  clone.style.flexWrap = 'nowrap';

  // Remove fixed 100% constraints on children
  clone.querySelectorAll('*').forEach((child) => {
    const el = child as HTMLElement;
    el.style.maxWidth = 'none';
    el.style.whiteSpace = 'nowrap';
    if (el.style.width === '100%') {
      el.style.width = 'auto';
    }
  });

  container.appendChild(clone);
  document.body.appendChild(container);

  const rect = container.getBoundingClientRect();
  const measuredWidth = Math.ceil(rect.width);

  document.body.removeChild(container);
  return measuredWidth;
};

/**
 * ColumnResizeHandle:
 * Renders an interactive vertical drag handle with prominent two-headed arrows (السهمين ◀▶)
 * positioned at the dividing boundary of a table header (<th>).
 * 
 * Features:
 * - Prominent "السهمين" (two horizontal arrows ◀▶) badge visible on the column border.
 * - Robust Pointer Events API with setPointerCapture to ensure dragging NEVER fails or drops.
 * - Full left & right dragging allowing columns to shrink to minimum ratio or expand without limits.
 * - Double-click / double-tap AutoFit: both EXPANDS and SHRINKS/REDUCES the column width
 *   precisely according to the actual data length in the cells.
 * - When columns are expanded to fit content, row heights naturally return to the minimal compact height.
 */
export const ColumnResizeHandle: React.FC<ColumnResizeHandleProps> = ({
  onResize,
  onAutoFit,
  minColumnWidth = 24,
  className = '',
  title = 'اسحب السهمين يميناً ويساراً لتعديل العرض (يُحفظ تلقائياً) | انقر نقرتين للاحتواء التلقائي للبيانات | Alt + نقرتين للاستعادة الافتراضية'
}) => {
  const [isDragging, setIsDragging] = useState(false);
  const handleRef = useRef<HTMLDivElement>(null);
  const lastTapTimeRef = useRef<number>(0);
  const lastTapPosRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });

  // On mount: automatically restore saved column widths for this table from localStorage
  useEffect(() => {
    if (handleRef.current) {
      const thElement = handleRef.current.closest('th');
      const table = thElement?.closest('table');
      if (table) {
        scheduleRestoreTableColumnWidths(table);
      }
    }
  }, []);

  // Auto-fit function that both expands or shrinks column width to fit content
  const performAutoFit = useCallback((thElement: HTMLElement) => {
    const table = thElement.closest('table');
    if (!table) return;

    const ths = Array.from(table.querySelectorAll('thead tr:first-child > th')) as HTMLElement[];
    const columnIndex = ths.indexOf(thElement);
    if (columnIndex === -1) return;

    // Lock all current column widths and table layout
    table.style.tableLayout = 'fixed';
    ths.forEach((th) => {
      const curW = Math.round(th.getBoundingClientRect().width);
      th.style.width = `${curW}px`;
      th.style.minWidth = `${minColumnWidth}px`;
    });

    // 1. Measure natural width of the header (title text + filter icon + gap)
    let maxContentWidth = minColumnWidth;
    const headerNaturalWidth = measureNaturalWidth(thElement);
    maxContentWidth = Math.max(maxContentWidth, headerNaturalWidth);

    // 2. Measure natural width across body rows (sample up to 100 visible rows)
    const rows = Array.from(table.querySelectorAll('tbody tr')).slice(0, 100);
    const isNotesCol = thElement.textContent?.includes('ملاحظات') || Boolean(table.querySelector('tbody td .col-notes-cell'));

    rows.forEach((row) => {
      const cell = row.children[columnIndex] as HTMLElement;
      if (cell) {
        if (isNotesCol) {
          // For notes column: measure natural width, but cap if long to prevent over-stretching
          const text = (cell.textContent || '').trim();
          if (!text || text === '-') {
            maxContentWidth = Math.max(maxContentWidth, 30);
          } else {
            const rawW = measureNaturalWidth(cell);
            // Cap notes column auto-fit at 260px so font scales down nicely
            maxContentWidth = Math.max(maxContentWidth, Math.min(rawW, 260));
          }
        } else {
          const cellWidth = measureNaturalWidth(cell);
          maxContentWidth = Math.max(maxContentWidth, cellWidth);
        }
      }
    });

    // Add safe cell padding (6px each side + 2px border margin = 14px)
    const targetWidth = Math.min(Math.max(minColumnWidth, maxContentWidth + 14), 700);

    // Apply target width to this column (shrinks or expands as appropriate!)
    thElement.style.width = `${targetWidth}px`;
    thElement.style.minWidth = `${targetWidth}px`;

    // Recalculate total table width by summing all column widths
    const totalTableWidth = ths.reduce((sum, th) => {
      return sum + (th === thElement ? targetWidth : Math.round(th.getBoundingClientRect().width));
    }, 0);

    table.style.width = `${totalTableWidth}px`;
    table.style.minWidth = `${totalTableWidth}px`;

    // Reapply sticky freeze offsets for any pinned columns
    applyTableFreeze(table);

    // Permanently persist column widths and table width to localStorage
    saveTableColumnWidths(table);

    if (onAutoFit) {
      onAutoFit();
    }
  }, [minColumnWidth, onAutoFit]);

  const handlePointerDown = useCallback((e: React.PointerEvent<HTMLDivElement>) => {
    // Only primary mouse button or touch/pen
    if (e.button !== 0) return;

    e.preventDefault();
    e.stopPropagation();

    const handleEl = e.currentTarget;
    const thElement = handleEl.closest('th');
    if (!thElement) return;

    const table = thElement.closest('table');
    if (!table) return;

    // Detect double-click / rapid double-tap (< 350ms at same spot)
    const now = Date.now();
    const timeDiff = now - lastTapTimeRef.current;
    const distX = Math.abs(e.clientX - lastTapPosRef.current.x);
    const distY = Math.abs(e.clientY - lastTapPosRef.current.y);

    if (timeDiff < 350 && distX < 8 && distY < 8) {
      lastTapTimeRef.current = 0;
      if (e.altKey || e.shiftKey) {
        resetTableColumnWidths(table);
        return;
      }
      performAutoFit(thElement);
      return;
    }

    lastTapTimeRef.current = now;
    lastTapPosRef.current = { x: e.clientX, y: e.clientY };

    try {
      handleEl.setPointerCapture(e.pointerId);
    } catch {}

    // Get all top-level th headers in the table's first thead row
    const ths = Array.from(table.querySelectorAll('thead tr:first-child > th')) as HTMLElement[];
    const colIndex = ths.indexOf(thElement);
    if (colIndex === -1) return;

    // Measure and capture current widths of ALL columns
    const initialWidths = ths.map((th) => Math.round(th.getBoundingClientRect().width));
    const initialTableWidth = Math.round(table.getBoundingClientRect().width);

    // Lock in table layout and explicit pixel widths on ALL ths so resizing is smooth
    table.style.tableLayout = 'fixed';
    ths.forEach((th, idx) => {
      th.style.width = `${initialWidths[idx]}px`;
      th.style.minWidth = `${minColumnWidth}px`;
    });
    table.style.width = `${initialTableWidth}px`;
    table.style.minWidth = `${initialTableWidth}px`;

    const startX = e.clientX;
    const initialWidth = initialWidths[colIndex];

    // Determine layout direction (RTL or LTR)
    const isRTL = (document.documentElement.dir || document.body.dir || document.dir) === 'rtl' 
      || getComputedStyle(thElement).direction === 'rtl';

    setIsDragging(true);

    const onPointerMove = (moveEvt: PointerEvent) => {
      if (moveEvt.pointerId !== e.pointerId) return;

      const deltaX = moveEvt.clientX - startX;
      // In RTL layout:
      // Dragging LEFT (moveEvt.clientX < startX => deltaX < 0) pulls the column divider outward => EXPANDS column
      // Dragging RIGHT (moveEvt.clientX > startX => deltaX > 0) pushes divider inward => SHRINKS column
      const delta = isRTL ? -deltaX : deltaX;

      const newWidth = Math.max(minColumnWidth, Math.round(initialWidth + delta));
      const diff = newWidth - initialWidth;

      thElement.style.width = `${newWidth}px`;
      thElement.style.minWidth = `${newWidth}px`;

      const newTableW = Math.max(100, Math.round(initialTableWidth + diff));
      table.style.width = `${newTableW}px`;
      table.style.minWidth = `${newTableW}px`;

      // Update sticky offsets of frozen columns in real-time
      applyTableFreeze(table);

      if (onResize) {
        onResize(diff);
      }
    };

    const onPointerUp = (upEvt: PointerEvent) => {
      if (upEvt.pointerId !== e.pointerId) return;

      handleEl.removeEventListener('pointermove', onPointerMove);
      handleEl.removeEventListener('pointerup', onPointerUp);
      handleEl.removeEventListener('pointercancel', onPointerUp);

      try {
        handleEl.releasePointerCapture(e.pointerId);
      } catch {}

      document.body.style.cursor = '';
      document.body.style.userSelect = '';
      setIsDragging(false);

      // Final freeze offset sync
      applyTableFreeze(table);

      // Persist user-adjusted widths permanently!
      saveTableColumnWidths(table);
    };

    handleEl.addEventListener('pointermove', onPointerMove);
    handleEl.addEventListener('pointerup', onPointerUp);
    handleEl.addEventListener('pointercancel', onPointerUp);

    document.body.style.cursor = 'col-resize';
    document.body.style.userSelect = 'none';
  }, [minColumnWidth, onResize, performAutoFit]);

  // Double click auto-fits column to widest cell content (expands or shrinks)
  const handleDoubleClick = useCallback((e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();

    const thElement = (e.currentTarget as HTMLElement).closest('th');
    if (!thElement) return;
    const table = thElement.closest('table');

    // If Alt or Shift key is held, reset table to default responsive layout
    if (e.altKey || e.shiftKey) {
      resetTableColumnWidths(table);
      return;
    }

    performAutoFit(thElement);
  }, [performAutoFit]);

  return (
    <div
      ref={handleRef}
      onPointerDown={handlePointerDown}
      onDoubleClick={handleDoubleClick}
      title={title}
      className={`absolute top-0 bottom-0 left-0 w-8 sm:w-7 -translate-x-1/2 flex items-center justify-center cursor-col-resize select-none z-20 group touch-none ${className}`}
    >
      {/* Vertical divider guide line */}
      <div 
        className={`w-[1.5px] group-hover:w-[2px] h-full transition-all ${
          isDragging 
            ? 'w-[2px] bg-rose-500 shadow-xs' 
            : 'bg-slate-300/80 group-hover:bg-rose-400'
        }`} 
      />

      {/* Prominent, touch-friendly horizontal arrows badge (السهمين ◀▶) - enlarged for easier clicking & control */}
      <div 
        className={`absolute top-1/2 -translate-y-1/2 w-6 h-6 sm:w-6 sm:h-6 flex items-center justify-center pointer-events-none transition-all rounded-full p-0.5 shadow-xs border ${
          isDragging
            ? 'bg-rose-50 border-rose-500 text-rose-600 scale-125 shadow-md ring-2 ring-rose-200'
            : 'bg-white border-slate-300/95 text-slate-600 group-hover:border-rose-400 group-hover:text-rose-600 group-hover:scale-115 group-hover:bg-rose-50/95 group-hover:shadow-sm'
        }`}
      >
        {/* Enlarged horizontal arrows (السهمين ◀▶) */}
        <svg 
          viewBox="0 0 24 24" 
          width="16" 
          height="11" 
          fill="none" 
          stroke="currentColor" 
          strokeWidth="2.5" 
          strokeLinecap="round" 
          strokeLinejoin="round"
          className="shrink-0"
        >
          {/* Left Arrow ◀ */}
          <polyline points="6 16 2 12 6 8" />
          {/* Right Arrow ▶ */}
          <polyline points="18 8 22 12 18 16" />
          {/* Connecting Line */}
          <line x1="2.5" y1="12" x2="21.5" y2="12" />
        </svg>
      </div>
    </div>
  );
};

export default ColumnResizeHandle;
