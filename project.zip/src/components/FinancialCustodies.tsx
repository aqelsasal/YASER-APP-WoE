/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo, useRef } from 'react';
import { 
  WalletCards, 
  PlusCircle, 
  Search, 
  TrendingUp, 
  Coins, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  Edit, 
  Trash2, 
  Printer, 
  Share2, 
  Download, 
  FileSpreadsheet, 
  FileText, 
  Receipt, 
  UserCheck, 
  Check, 
  X, 
  ArrowRight, 
  ChevronDown, 
  Building2, 
  Phone, 
  Briefcase, 
  Sparkles, 
  ShieldCheck, 
  Ban, 
  CornerDownLeft, 
  Layers,
  Info
} from 'lucide-react';
import PageHeaderCard from './PageHeaderCard';
import OptionsMenu from './OptionsMenu';
import { AmountInWords } from './AmountInWords';
import { 
  CustodyItem, 
  CustodySettlement, 
  CustodyRecipientType, 
  CustodyStatus,
  Worker, 
  Employee, 
  Supplier, 
  ContractItem, 
  formatCurrency, 
  formatDateArabic, 
  getTodayDateString, 
  exportToXLSX,
  COMPANY_LOGO_BASE64 
} from '../types';
import { useBodyScrollLock } from '../utils/modalScrollLock';

interface FinancialCustodiesProps {
  custodies: CustodyItem[];
  onAddCustody: (custody: Omit<CustodyItem, 'id' | 'createdAt' | 'updatedAt' | 'settlements'>) => void;
  onUpdateCustody: (id: string, updates: Partial<CustodyItem>) => void;
  onDeleteCustody: (id: string) => void;
  onAddSettlement: (custodyId: string, settlement: Omit<CustodySettlement, 'id' | 'createdAt'>, alsoAddAsExpense?: boolean) => void;
  onUpdateSettlement?: (custodyId: string, settlementId: string, updatedData: Partial<CustodySettlement>) => void;
  onDeleteSettlement: (custodyId: string, settlementId: string) => void;
  onCloseCustody: (custodyId: string, returnSurplusAmount?: number, refundDeficitAmount?: number, notes?: string) => void;
  workers?: Worker[];
  employees?: Employee[];
  suppliers?: Supplier[];
  contractItems?: ContractItem[];
  currency: string;
  projectName: string;
  companyName: string;
  companyAddress?: string;
  companyPhone?: string;
  sharedRole?: string;
  currentUser?: string;
  setActiveTab?: (tab: string) => void;
}

export default function FinancialCustodies({
  custodies = [],
  onAddCustody,
  onUpdateCustody,
  onDeleteCustody,
  onAddSettlement,
  onUpdateSettlement,
  onDeleteSettlement,
  onCloseCustody,
  workers = [],
  employees = [],
  suppliers = [],
  contractItems = [],
  currency,
  projectName,
  companyName,
  companyAddress = '',
  companyPhone = '',
  sharedRole = 'admin',
  currentUser = 'المدير',
  setActiveTab
}: FinancialCustodiesProps) {
  // Filters State
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [typeFilter, setTypeFilter] = useState<string>('ALL');
  const [currencyFilter, setCurrencyFilter] = useState<string>('ALL');

  // Modals State
  const [isNewCustodyModalOpen, setIsNewCustodyModalOpen] = useState(false);
  const [editingCustody, setEditingCustody] = useState<CustodyItem | null>(null);
  const [viewingCustody, setViewingCustody] = useState<CustodyItem | null>(null);
  const [isAddSettlementModalOpen, setIsAddSettlementModalOpen] = useState(false);

  // Clearance confirmation modal
  const [clearanceActionCustody, setClearanceActionCustody] = useState<CustodyItem | null>(null);
  const [clearanceNotes, setClearanceNotes] = useState('');

  // Edit Settlement Form State
  const [editingSettlement, setEditingSettlement] = useState<{
    custodyId: string;
    settlement: CustodySettlement;
  } | null>(null);
  const [editSettlementDate, setEditSettlementDate] = useState(getTodayDateString());
  const [editSettlementInvoiceNumber, setEditSettlementInvoiceNumber] = useState('');
  const [editSettlementDescription, setEditSettlementDescription] = useState('');
  const [editSettlementAmount, setEditSettlementAmount] = useState('');
  const [editSettlementCategory, setEditSettlementCategory] = useState('مواد ومشتريات');
  const [editSettlementContractItemId, setEditSettlementContractItemId] = useState('');
  const [editSettlementNotes, setEditSettlementNotes] = useState('');

  useBodyScrollLock(
    isNewCustodyModalOpen || 
    Boolean(editingCustody) || 
    Boolean(viewingCustody) || 
    isAddSettlementModalOpen || 
    Boolean(clearanceActionCustody) ||
    Boolean(editingSettlement)
  );

  // New Custody Form State
  const [custodyNumber, setCustodyNumber] = useState('');
  const [custodyName, setCustodyName] = useState('');
  const [recipientType, setRecipientType] = useState<CustodyRecipientType>('employee');
  const [recipientId, setRecipientId] = useState('');
  const [recipientName, setRecipientName] = useState('');
  const [recipientPhone, setRecipientPhone] = useState('');
  const [recipientProfession, setRecipientProfession] = useState('');
  const [custodyAmount, setCustodyAmount] = useState('');
  const [custodyCurrency, setCustodyCurrency] = useState(currency || 'YER');
  const [custodyDate, setCustodyDate] = useState(getTodayDateString());
  const [custodyNotes, setCustodyNotes] = useState('');

  // Settlement Form State
  const [settlementDate, setSettlementDate] = useState(getTodayDateString());
  const [settlementInvoiceNumber, setSettlementInvoiceNumber] = useState('');
  const [settlementDescription, setSettlementDescription] = useState('');
  const [settlementAmount, setSettlementAmount] = useState('');
  const [settlementCategory, setSettlementCategory] = useState('مواد ومشتريات');
  const [settlementContractItemId, setSettlementContractItemId] = useState('');
  const [settlementNotes, setSettlementNotes] = useState('');
  const [alsoAddToDailyExpenses, setAlsoAddToDailyExpenses] = useState(true);

  // Calculate stats for a single custody
  const getCustodyStats = (custody: CustodyItem) => {
    const totalSettled = (custody.settlements || []).reduce((sum, s) => sum + (s.amount || 0), 0);
    const balance = custody.amount - totalSettled;
    const progressPercent = custody.amount > 0 ? Math.min(100, (totalSettled / custody.amount) * 100) : 0;
    
    // Status resolution
    let computedStatus: CustodyStatus = custody.status;
    if (custody.status !== 'closed') {
      if (totalSettled === 0) {
        computedStatus = 'open';
      } else if (totalSettled < custody.amount) {
        computedStatus = 'partially_cleared';
      } else {
        computedStatus = 'cleared';
      }
    }

    return {
      totalSettled,
      balance, // > 0 means recipient still holds cash, < 0 means recipient spent out-of-pocket (deficit)
      progressPercent,
      computedStatus,
      settlementsCount: custody.settlements ? custody.settlements.length : 0
    };
  };

  // Filtered custodies list
  const filteredCustodies = useMemo(() => {
    return custodies.filter(item => {
      // Search
      if (searchQuery.trim()) {
        const query = searchQuery.trim().toLowerCase();
        const matchNum = item.custodyNumber?.toLowerCase().includes(query);
        const matchName = item.custodyName?.toLowerCase().includes(query);
        const matchRecipient = item.recipientName?.toLowerCase().includes(query);
        const matchPhone = item.recipientPhone?.toLowerCase().includes(query);
        const matchNotes = item.notes?.toLowerCase().includes(query);
        const matchSettlement = item.settlements?.some(s => 
          s.description.toLowerCase().includes(query) || 
          s.invoiceNumber?.toLowerCase().includes(query)
        );
        if (!matchNum && !matchName && !matchRecipient && !matchPhone && !matchNotes && !matchSettlement) {
          return false;
        }
      }

      // Status
      if (statusFilter !== 'ALL') {
        const stats = getCustodyStats(item);
        if (statusFilter === 'closed' && item.status !== 'closed') return false;
        if (statusFilter === 'open' && stats.computedStatus !== 'open') return false;
        if (statusFilter === 'partially_cleared' && stats.computedStatus !== 'partially_cleared') return false;
        if (statusFilter === 'cleared' && stats.computedStatus !== 'cleared') return false;
      }

      // Recipient Type
      if (typeFilter !== 'ALL' && item.recipientType !== typeFilter) {
        return false;
      }

      // Currency
      if (currencyFilter !== 'ALL' && item.currency !== currencyFilter) {
        return false;
      }

      return true;
    }).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [custodies, searchQuery, statusFilter, typeFilter, currencyFilter]);

  // Overall KPIs
  const overallKPIs = useMemo(() => {
    const totalsByCurrency: Record<string, { issued: number; settled: number; remaining: number }> = {};
    let openCount = 0;
    let partialCount = 0;
    let clearedCount = 0;
    let closedCount = 0;

    custodies.forEach(c => {
      const cur = c.currency || currency || 'YER';
      if (!totalsByCurrency[cur]) {
        totalsByCurrency[cur] = { issued: 0, settled: 0, remaining: 0 };
      }

      const stats = getCustodyStats(c);
      totalsByCurrency[cur].issued += c.amount || 0;
      totalsByCurrency[cur].settled += stats.totalSettled;
      totalsByCurrency[cur].remaining += Math.max(0, stats.balance);

      if (c.status === 'closed') closedCount++;
      else if (stats.computedStatus === 'cleared') clearedCount++;
      else if (stats.computedStatus === 'partially_cleared') partialCount++;
      else openCount++;
    });

    const activeCur = currencyFilter !== 'ALL' ? currencyFilter : currency;
    const currentCurData = totalsByCurrency[activeCur] || { issued: 0, settled: 0, remaining: 0 };

    return {
      totalCustodiesCount: custodies.length,
      currentCurIssued: currentCurData.issued,
      currentCurSettled: currentCurData.settled,
      currentCurRemaining: currentCurData.remaining,
      totalsByCurrency,
      openCount,
      partialCount,
      clearedCount,
      closedCount
    };
  }, [custodies, currency, currencyFilter]);

  // Generate next custody number (e.g. CUST-001)
  const generateNextCustodyNumber = () => {
    const count = custodies.length + 1;
    return `CUST-${String(count).padStart(3, '0')}`;
  };

  // Open Add Modal
  const handleOpenAddModal = () => {
    setCustodyNumber(generateNextCustodyNumber());
    setCustodyName('');
    setRecipientType('employee');
    setRecipientId('');
    setRecipientName('');
    setRecipientPhone('');
    setRecipientProfession('');
    setCustodyAmount('');
    setCustodyCurrency(currency || 'YER');
    setCustodyDate(getTodayDateString());
    setCustodyNotes('');
    setEditingCustody(null);
    setIsNewCustodyModalOpen(true);
  };

  // Open Edit Modal
  const handleOpenEditModal = (item: CustodyItem) => {
    setCustodyNumber(item.custodyNumber);
    setCustodyName(item.custodyName);
    setRecipientType(item.recipientType);
    setRecipientId(item.recipientId || '');
    setRecipientName(item.recipientName);
    setRecipientPhone(item.recipientPhone || '');
    setRecipientProfession(item.recipientProfession || '');
    setCustodyAmount(String(item.amount));
    setCustodyCurrency(item.currency);
    setCustodyDate(item.date);
    setCustodyNotes(item.notes || '');
    setEditingCustody(item);
    setIsNewCustodyModalOpen(true);
  };

  // Recipient selector helper
  const handleSelectPredefinedRecipient = (type: CustodyRecipientType, id: string) => {
    setRecipientType(type);
    setRecipientId(id);

    if (type === 'employee') {
      const emp = employees.find(e => e.id === id);
      if (emp) {
        setRecipientName(emp.name);
        setRecipientPhone(emp.phoneNumbers?.[0] || '');
        setRecipientProfession(emp.profession || 'موظف');
      }
    } else if (type === 'worker') {
      const wrk = workers.find(w => w.id === id);
      if (wrk) {
        setRecipientName(wrk.name);
        setRecipientPhone(wrk.phoneNumbers?.[0] || '');
        setRecipientProfession(wrk.profession || 'عامل');
      }
    } else if (type === 'supplier') {
      const sup = suppliers.find(s => s.id === id);
      if (sup) {
        setRecipientName(sup.name);
        setRecipientPhone(sup.phoneNumbers?.[0] || '');
        setRecipientProfession(sup.materialType || 'مورد مواد');
      }
    }
  };

  // Save Custody (Add or Edit)
  const handleSubmitCustody = (e: React.FormEvent) => {
    e.preventDefault();
    const num = custodyAmount.replace(/,/g, '');
    const amountVal = parseFloat(num);
    if (isNaN(amountVal) || amountVal <= 0) {
      alert('يرجى إدخال مبلغ عهدة صالح أكبر من الصفر.');
      return;
    }
    if (!recipientName.trim()) {
      alert('يرجى تحديد أو كتابة اسم أمين العهدة المستلم.');
      return;
    }
    if (!custodyName.trim()) {
      alert('يرجى إدخال بيان أو غرض العهدة.');
      return;
    }

    if (editingCustody) {
      onUpdateCustody(editingCustody.id, {
        custodyNumber: custodyNumber.trim() || editingCustody.custodyNumber,
        custodyName: custodyName.trim(),
        recipientType,
        recipientId: recipientId || undefined,
        recipientName: recipientName.trim(),
        recipientPhone: recipientPhone.trim() || undefined,
        recipientProfession: recipientProfession.trim() || undefined,
        amount: amountVal,
        currency: custodyCurrency,
        date: custodyDate,
        notes: custodyNotes.trim() || undefined
      });
    } else {
      onAddCustody({
        custodyNumber: custodyNumber.trim() || generateNextCustodyNumber(),
        custodyName: custodyName.trim(),
        recipientType,
        recipientId: recipientId || undefined,
        recipientName: recipientName.trim(),
        recipientPhone: recipientPhone.trim() || undefined,
        recipientProfession: recipientProfession.trim() || undefined,
        amount: amountVal,
        currency: custodyCurrency,
        status: 'open',
        date: custodyDate,
        notes: custodyNotes.trim() || undefined
      });
    }

    setIsNewCustodyModalOpen(false);
    setEditingCustody(null);
  };

  // Open Add Settlement Modal
  const handleOpenAddSettlement = (custody: CustodyItem) => {
    setViewingCustody(custody);
    setSettlementDate(getTodayDateString());
    setSettlementInvoiceNumber('');
    setSettlementDescription('');
    setSettlementAmount('');
    setSettlementCategory('مواد ومشتريات');
    setSettlementContractItemId('');
    setSettlementNotes('');
    setAlsoAddToDailyExpenses(true);
    setIsAddSettlementModalOpen(true);
  };

  // Save Settlement Invoice
  const handleSubmitSettlement = (e: React.FormEvent) => {
    e.preventDefault();
    if (!viewingCustody) return;

    const num = settlementAmount.replace(/,/g, '');
    const amountVal = parseFloat(num);
    if (isNaN(amountVal) || amountVal <= 0) {
      alert('يرجى إدخال مبلغ نفقة صالح أكبر من الصفر.');
      return;
    }
    if (!settlementDescription.trim()) {
      alert('يرجى إدخال بيان وتوصيف الفاتورة/المصروف.');
      return;
    }

    const matchedContractItem = contractItems.find(c => c.id === settlementContractItemId);

    onAddSettlement(
      viewingCustody.id,
      {
        date: settlementDate,
        invoiceNumber: settlementInvoiceNumber.trim() || undefined,
        description: settlementDescription.trim(),
        amount: amountVal,
        currency: viewingCustody.currency,
        category: settlementCategory,
        contractItemId: settlementContractItemId || undefined,
        contractItemNumber: matchedContractItem ? matchedContractItem.itemNumber : undefined,
        notes: settlementNotes.trim() || undefined
      },
      alsoAddToDailyExpenses
    );

    setIsAddSettlementModalOpen(false);

    // Keep viewing updated custody in view modal
    const updated = custodies.find(c => c.id === viewingCustody.id);
    if (updated) {
      setViewingCustody(updated);
    }
  };

  // Open Edit Settlement Modal
  const handleOpenEditSettlement = (custodyId: string, settlement: CustodySettlement) => {
    setEditingSettlement({ custodyId, settlement });
    setEditSettlementDate(settlement.date);
    setEditSettlementInvoiceNumber(settlement.invoiceNumber || '');
    setEditSettlementDescription(settlement.description);
    setEditSettlementAmount(String(settlement.amount));
    setEditSettlementCategory(settlement.category || 'مواد ومشتريات');
    setEditSettlementContractItemId(settlement.contractItemId || '');
    setEditSettlementNotes(settlement.notes || '');
  };

  // Save Edit Settlement
  const handleSaveEditSettlement = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingSettlement) return;

    const num = editSettlementAmount.replace(/,/g, '');
    const amountVal = parseFloat(num);
    if (isNaN(amountVal) || amountVal <= 0) {
      alert('يرجى إدخال مبلغ نفقة صالح أكبر من الصفر.');
      return;
    }
    if (!editSettlementDescription.trim()) {
      alert('يرجى إدخال بيان وتوصيف الفاتورة/المصروف.');
      return;
    }

    const matchedContractItem = contractItems.find(c => c.id === editSettlementContractItemId);

    const updatedData: Partial<CustodySettlement> = {
      date: editSettlementDate,
      invoiceNumber: editSettlementInvoiceNumber.trim() || undefined,
      description: editSettlementDescription.trim(),
      amount: amountVal,
      category: editSettlementCategory,
      contractItemId: editSettlementContractItemId || undefined,
      contractItemNumber: matchedContractItem ? matchedContractItem.itemNumber : undefined,
      notes: editSettlementNotes.trim() || undefined
    };

    if (onUpdateSettlement) {
      onUpdateSettlement(editingSettlement.custodyId, editingSettlement.settlement.id, updatedData);
    }

    if (viewingCustody && viewingCustody.id === editingSettlement.custodyId) {
      setViewingCustody({
        ...viewingCustody,
        settlements: (viewingCustody.settlements || []).map(s => 
          s.id === editingSettlement.settlement.id ? { ...s, ...updatedData } : s
        )
      });
    }

    setEditingSettlement(null);
  };

  // Execute Final Clearance
  const handleConfirmClearance = () => {
    if (!clearanceActionCustody) return;
    const stats = getCustodyStats(clearanceActionCustody);

    let surplus = 0;
    let deficit = 0;

    if (stats.balance > 0) {
      surplus = stats.balance; // Return cash to safe
    } else if (stats.balance < 0) {
      deficit = Math.abs(stats.balance); // Refund money to custodian
    }

    onCloseCustody(clearanceActionCustody.id, surplus, deficit, clearanceNotes.trim());
    setClearanceActionCustody(null);
    setClearanceNotes('');

    // If modal was open, refresh view
    if (viewingCustody && viewingCustody.id === clearanceActionCustody.id) {
      const refreshed = custodies.find(c => c.id === clearanceActionCustody.id);
      if (refreshed) {
        setViewingCustody(refreshed);
      }
    }
  };

  // Export to Excel
  const handleExportExcel = () => {
    const headers = [
      'رقم العهدة',
      'تاريخ التسليم',
      'أمين العهدة',
      'نوع المستلم',
      'المهنة / الصفة',
      'رقم الهاتف',
      'الغرض من العهدة',
      'مبلغ العهدة الأصلي',
      'المصروف بالفواتير',
      'المتبقي بذمته',
      'نسبة التصفية',
      'العملة',
      'الحالة',
      'تاريخ الإخلاء',
      'ملاحظات'
    ];

    const rows = filteredCustodies.map(item => {
      const stats = getCustodyStats(item);
      const statusLabel = 
        item.status === 'closed' ? 'مغلقة ومخلاة' :
        stats.computedStatus === 'cleared' ? 'تمت التصفية بالكامل' :
        stats.computedStatus === 'partially_cleared' ? 'قيد التصفية' : 'مفتوحة لم تبدأ';

      return [
        item.custodyNumber,
        item.date,
        item.recipientName,
        item.recipientType === 'employee' ? 'موظف' : item.recipientType === 'worker' ? 'عامل' : item.recipientType === 'supplier' ? 'مورد' : 'أخرى',
        item.recipientProfession || '—',
        item.recipientPhone || '—',
        item.custodyName,
        item.amount,
        stats.totalSettled,
        stats.balance,
        `${stats.progressPercent.toFixed(1)}%`,
        item.currency,
        statusLabel,
        item.clearedAt || '—',
        item.notes || '—'
      ];
    });

    exportToXLSX(`تقرير_العهد_المالية_${projectName}`, headers, rows, 'العهد المالية');
  };

  // Print Printout for individual Custody Voucher / Clearance
  const handlePrintCustodyVoucher = (custody: CustodyItem) => {
    const stats = getCustodyStats(custody);
    const printWindow = window.open('', '_blank');
    if (!printWindow) {
      alert('يرجى السماح بالنوافذ المنبثقة للطباعة');
      return;
    }

    const html = `
      <!DOCTYPE html>
      <html dir="rtl" lang="ar">
      <head>
        <meta charset="utf-8">
        <title>سند تصفية وإخلاء عهدة مالية - ${custody.custodyNumber}</title>
        <style>
          body {
            font-family: 'Cairo', 'Segoe UI', Tahoma, sans-serif;
            margin: 0;
            padding: 24px;
            color: #1e293b;
            background: #fff;
            direction: rtl;
          }
          .header {
            border-bottom: 2px solid #0f172a;
            padding-bottom: 16px;
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
          }
          .header h1 { margin: 0 0 6px 0; font-size: 20px; color: #0f172a; }
          .header p { margin: 2px 0; font-size: 12px; color: #64748b; }
          .badge {
            background: #0f172a;
            color: #fff;
            padding: 4px 12px;
            border-radius: 6px;
            font-size: 13px;
            font-weight: bold;
          }
          .info-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 12px;
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            padding: 14px;
            margin-bottom: 20px;
            font-size: 13px;
          }
          .info-item { display: flex; justify-content: space-between; padding: 4px 0; }
          .info-label { font-weight: bold; color: #475569; }
          .info-value { font-weight: 800; color: #0f172a; }
          
          .kpi-row {
            display: grid;
            grid-template-columns: 1fr 1fr 1fr;
            gap: 12px;
            margin-bottom: 20px;
          }
          .kpi-card {
            background: #f1f5f9;
            border: 1px solid #cbd5e1;
            padding: 12px;
            border-radius: 8px;
            text-align: center;
          }
          .kpi-title { font-size: 11px; color: #475569; font-weight: bold; }
          .kpi-num { font-size: 18px; font-weight: 900; margin-top: 4px; color: #0f172a; }

          table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 24px;
            font-size: 12px;
          }
          th, td {
            border: 1px solid #cbd5e1;
            padding: 8px 10px;
            text-align: right;
          }
          th { background: #f8fafc; font-weight: bold; color: #334155; }
          .text-center { text-align: center; }
          .signatures {
            display: grid;
            grid-template-columns: 1fr 1fr 1fr;
            gap: 20px;
            margin-top: 40px;
            padding-top: 20px;
            border-top: 1px dashed #cbd5e1;
            text-align: center;
            font-size: 12px;
            font-weight: bold;
          }
          .sig-line {
            margin-top: 45px;
            border-bottom: 1px solid #94a3b8;
          }
          @media print {
            body { padding: 10px; }
            button { display: none; }
          }
        </style>
      </head>
      <body>
        <div class="header">
          <div>
            <h1>${companyName || 'إدارة المشاريع والمقاولات'}</h1>
            <p>مشروع: <strong>${projectName}</strong></p>
            <p>العنوان: ${companyAddress} | الهاتف: ${companyPhone}</p>
          </div>
          <div style="text-align: left;">
            <div class="badge">سند كشف وتصفية عهدة مالية</div>
            <p style="margin-top: 6px;">رقم السند: <strong>${custody.custodyNumber}</strong></p>
            <p>التاريخ: ${formatDateArabic(new Date().toISOString())}</p>
          </div>
        </div>

        <div class="info-grid">
          <div class="info-item">
            <span class="info-label">اسم أمين العهدة:</span>
            <span class="info-value">${custody.recipientName} (${custody.recipientProfession || 'أمين عهدة'})</span>
          </div>
          <div class="info-item">
            <span class="info-label">تاريخ تسليم العهدة:</span>
            <span class="info-value">${formatDateArabic(custody.date)}</span>
          </div>
          <div class="info-item">
            <span class="info-label">الغرض من العهدة:</span>
            <span class="info-value">${custody.custodyName}</span>
          </div>
          <div class="info-item">
            <span class="info-label">رقم الهاتف:</span>
            <span class="info-value">${custody.recipientPhone || '—'}</span>
          </div>
          <div class="info-item">
            <span class="info-label">حالة العهدة:</span>
            <span class="info-value">${custody.status === 'closed' ? 'مغلقة ومخلاة ذمتها' : stats.balance === 0 ? 'مصفاة بالكامل' : 'قيد التصفية'}</span>
          </div>
          <div class="info-item">
            <span class="info-label">المعتمد للإخلاء:</span>
            <span class="info-value">${custody.clearedBy || currentUser || 'الإدارة المالية'}</span>
          </div>
        </div>

        <div class="kpi-row">
          <div class="kpi-card" style="border-color: #38bdf8;">
            <div class="kpi-title">مبلغ العهدة الأصلي المسلم</div>
            <div class="kpi-num">${formatCurrency(custody.amount, custody.currency)}</div>
          </div>
          <div class="kpi-card" style="border-color: #34d399;">
            <div class="kpi-title">إجمالي المصروف المصفى بالفواتير</div>
            <div class="kpi-num">${formatCurrency(stats.totalSettled, custody.currency)}</div>
          </div>
          <div class="kpi-card" style="border-color: ${stats.balance >= 0 ? '#fbbf24' : '#f87171'};">
            <div class="kpi-title">${stats.balance >= 0 ? 'المتبقي بذمة أمين العهدة (فائض)' : 'المستحق لأمين العهدة (عجز)'}</div>
            <div class="kpi-num">${formatCurrency(Math.abs(stats.balance), custody.currency)}</div>
          </div>
        </div>

        <h3 style="font-size: 14px; margin-bottom: 8px;">جدول فواتير ومصروفات تصفية العهدة:</h3>
        <table>
          <thead>
            <tr>
              <th class="text-center" style="width: 40px;">م</th>
              <th class="text-center" style="width: 90px;">التاريخ</th>
              <th class="text-center" style="width: 80px;">رقم الفاتورة</th>
              <th>بيان وتوصيف النفقة / المشتريات</th>
              <th class="text-center" style="width: 90px;">التصنيف</th>
              <th class="text-center" style="width: 100px;">المبلغ (${custody.currency})</th>
              <th>ملاحظات</th>
            </tr>
          </thead>
          <tbody>
            ${(custody.settlements && custody.settlements.length > 0) ? custody.settlements.map((s, idx) => `
              <tr>
                <td class="text-center">${idx + 1}</td>
                <td class="text-center">${formatDateArabic(s.date)}</td>
                <td class="text-center">${s.invoiceNumber || 'بدون'}</td>
                <td><strong>${s.description}</strong></td>
                <td class="text-center">${s.category || 'نفقات عامة'}</td>
                <td class="text-center" style="font-weight: bold;">${formatCurrency(s.amount, custody.currency)}</td>
                <td>${s.notes || '—'}</td>
              </tr>
            `).join('') : `
              <tr>
                <td colspan="7" class="text-center" style="padding: 18px; color: #94a3b8;">لا توجد فواتير تصفية مسجلة حتى الآن</td>
              </tr>
            `}
          </tbody>
          <tfoot>
            <tr style="background: #f8fafc; font-weight: bold;">
              <td colspan="5" style="text-align: left; padding-left: 12px;">إجمالي المبالغ المنصرفة بموجب الفواتير:</td>
              <td class="text-center" style="color: #047857; font-size: 13px;">${formatCurrency(stats.totalSettled, custody.currency)}</td>
              <td></td>
            </tr>
            ${custody.returnedAmount ? `
              <tr style="background: #f0fdf4; font-weight: bold;">
                <td colspan="5" style="text-align: left; padding-left: 12px;">المبلغ الفائض المسترد والمورد للصندوق:</td>
                <td class="text-center" style="color: #15803d;">${formatCurrency(custody.returnedAmount, custody.currency)}</td>
                <td>تم التوريد وإخلاء الذمة</td>
              </tr>
            ` : ''}
            ${custody.refundedDeficit ? `
              <tr style="background: #fff1f2; font-weight: bold;">
                <td colspan="5" style="text-align: left; padding-left: 12px;">مبلغ العجز المصروف لأمين العهدة كتعويض:</td>
                <td class="text-center" style="color: #be123c;">${formatCurrency(custody.refundedDeficit, custody.currency)}</td>
                <td>تم الصرف والتعويض</td>
              </tr>
            ` : ''}
          </tfoot>
        </table>

        ${custody.notes ? `
          <div style="background: #f8fafc; border: 1px solid #e2e8f0; padding: 10px; border-radius: 6px; font-size: 12px; margin-bottom: 20px;">
            <strong>ملاحظات الإدارة:</strong> ${custody.notes}
          </div>
        ` : ''}

        <div class="signatures">
          <div>
            <p>أمين العهدة (المستلم)</p>
            <p style="color: #64748b; font-size: 11px;">${custody.recipientName}</p>
            <div class="sig-line"></div>
          </div>
          <div>
            <p>المحاسب المالي</p>
            <p style="color: #64748b; font-size: 11px;">${currentUser || 'محاسب المشروع'}</p>
            <div class="sig-line"></div>
          </div>
          <div>
            <p>اعتماد مدير المشروع</p>
            <p style="color: #64748b; font-size: 11px;">الإدارة الهندسية</p>
            <div class="sig-line"></div>
          </div>
        </div>

        <script>
          window.onload = function() {
            window.print();
          };
        </script>
      </body>
      </html>
    `;

    printWindow.document.open();
    printWindow.document.write(html);
    printWindow.document.close();
  };

  // WhatsApp share
  const handleShareWhatsApp = (custody: CustodyItem) => {
    const stats = getCustodyStats(custody);
    const balanceText = stats.balance > 0 
      ? `المتبقي بذمته (فائض): ${formatCurrency(stats.balance, custody.currency)}`
      : stats.balance < 0 
        ? `المستحق له (عجز مصروف): ${formatCurrency(Math.abs(stats.balance), custody.currency)}`
        : `العهدة مصفاة بالكامل (0)`;

    const text = 
`📋 *سند وتصفية عهدة مالية - ${projectName}*
🏢 *${companyName}*
🔢 رقم العهدة: ${custody.custodyNumber}
👤 أمين العهدة: ${custody.recipientName} (${custody.recipientProfession || 'أمين عهدة'})
📅 تاريخ التسليم: ${formatDateArabic(custody.date)}
🎯 الغرض: ${custody.custodyName}

💵 مبلغ العهدة الأصلي: ${formatCurrency(custody.amount, custody.currency)}
🧾 المنصرف بالفواتير: ${formatCurrency(stats.totalSettled, custody.currency)}
📊 نسبة التصفية: ${stats.progressPercent.toFixed(1)}%
⚖️ ${balanceText}
📌 الحالة: ${custody.status === 'closed' ? 'مغلقة ومخلاة رسمياً' : stats.balance === 0 ? 'مصفاة بانتظار الإغلاق' : 'قيد التصفية'}

*تم الاستخراج من نظام إدارة المشاريع والمقاولات*`;

    const encoded = encodeURIComponent(text);
    window.open(`https://api.whatsapp.com/send?text=${encoded}`, '_blank');
  };

  return (
    <div className="w-full space-y-4 sm:space-y-6 pb-20 animate-fade-in" id="financial-custodies-container">
      
      {/* 1. Page Header */}
      <PageHeaderCard
        title="إدارة العهد المالية وتصفية النفقات"
        description="تسليم العهد النقدية للعمال والموظفين والموردين لتغطية نثريات ومشتريات الموقع، وتتبع فواتير التصفية وإخلاء الذمة بدقة"
        icon={<WalletCards size={22} className="text-amber-400" />}
        badgeText={`مشروع: ${projectName}`}
        onBack={setActiveTab ? () => setActiveTab('dashboard') : undefined}
        backButtonLabel="الرجوع للرئيسية"
        primaryAction={
          sharedRole !== 'read' ? (
            <button
              type="button"
              onClick={handleOpenAddModal}
              className="px-3.5 sm:px-4 py-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-slate-950 font-black rounded-xl text-xs sm:text-sm transition-all flex items-center gap-1.5 shadow-md shadow-amber-500/20 cursor-pointer active:scale-95 whitespace-nowrap"
              title="تسليم وصرف عهدة مالية جديدة"
            >
              <PlusCircle size={16} className="text-slate-950" />
              <span>صرف عهدة جديدة</span>
            </button>
          ) : undefined
        }
        optionsMenu={
          <OptionsMenu
            onExportExcel={handleExportExcel}
            onExportPDF={() => {
              if (filteredCustodies.length > 0) {
                handlePrintCustodyVoucher(filteredCustodies[0]);
              } else {
                alert('لا توجد عهد مالية مسجلة للطباعة.');
              }
            }}
            pdfLabel="طباعة كشف العهد"
            shareTitle={`تقرير العهد المالية - مشروع: ${projectName}`}
          />
        }
        extraActions={
          <div className="hidden lg:flex items-center gap-1.5">
            <button
              type="button"
              onClick={handleExportExcel}
              className="px-2.5 py-1.5 bg-emerald-600/90 hover:bg-emerald-600 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-1 cursor-pointer whitespace-nowrap"
              title="تصدير سجل العهد إلى ملف Excel"
            >
              <Download size={13} />
              <span>Excel</span>
            </button>
          </div>
        }
      />

      {/* 2. Executive KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
        
        {/* KPI 1: Total Custodies Handed Out */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500">إجمالي العهد المسلمة</span>
            <div className="w-8 h-8 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center">
              <WalletCards size={16} />
            </div>
          </div>
          <div className="mt-2 text-xl font-black text-slate-900">
            {formatCurrency(overallKPIs.currentCurIssued, currencyFilter !== 'ALL' ? currencyFilter : currency)}
          </div>
          <div className="mt-1 text-[11px] text-slate-400">
            إجمالي {overallKPIs.totalCustodiesCount} عهدة نقدية مسلمة
          </div>
        </div>

        {/* KPI 2: Total Settled via Invoices */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500">إجمالي المصفى بالفواتير</span>
            <div className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <Receipt size={16} />
            </div>
          </div>
          <div className="mt-2 text-xl font-black text-emerald-700">
            {formatCurrency(overallKPIs.currentCurSettled, currencyFilter !== 'ALL' ? currencyFilter : currency)}
          </div>
          <div className="mt-1 text-[11px] text-slate-400">
            نفقات ومشتريات موثقة بسندات وفواتير
          </div>
        </div>

        {/* KPI 3: Remaining Balance with Custodians */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500">الرصيد المتبقي بذمة الأمناء</span>
            <div className="w-8 h-8 rounded-xl bg-sky-50 text-sky-600 flex items-center justify-center">
              <Coins size={16} />
            </div>
          </div>
          <div className="mt-2 text-xl font-black text-sky-700">
            {formatCurrency(overallKPIs.currentCurRemaining, currencyFilter !== 'ALL' ? currencyFilter : currency)}
          </div>
          <div className="mt-1 text-[11px] text-slate-400">
            مبالغ نقدية معلقة بانتظار استكمال التصفية
          </div>
        </div>

        {/* KPI 4: Status Breakdown */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500">حالات العهد</span>
            <div className="w-8 h-8 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
              <ShieldCheck size={16} />
            </div>
          </div>
          <div className="mt-2 flex items-center gap-2 flex-wrap text-xs">
            <span className="px-2 py-0.5 rounded-lg bg-emerald-50 text-emerald-700 border border-emerald-200 font-extrabold text-[11px]">
              {overallKPIs.closedCount + overallKPIs.clearedCount} مخلاة
            </span>
            <span className="px-2 py-0.5 rounded-lg bg-amber-50 text-amber-700 border border-amber-200 font-extrabold text-[11px]">
              {overallKPIs.partialCount} قيد التصفية
            </span>
            <span className="px-2 py-0.5 rounded-lg bg-sky-50 text-sky-700 border border-sky-200 font-extrabold text-[11px]">
              {overallKPIs.openCount} جديدة
            </span>
          </div>
          <div className="mt-1 text-[11px] text-slate-400">
            متابعة إخلاء الذمة والمطابقة الفورية
          </div>
        </div>

      </div>

      {/* 3. Search & Filter Bar */}
      <div className="bg-white p-3.5 rounded-2xl border border-slate-200/80 shadow-xs flex flex-wrap items-center justify-between gap-3">
        
        {/* Search Input */}
        <div className="relative flex-1 min-w-[220px]">
          <Search size={16} className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="بحث برقم العهدة، اسم أمين العهدة، الغرض، أو الفاتورة..."
            className="w-full pr-10 pl-3 py-2 bg-slate-50 hover:bg-slate-100/70 focus:bg-white border border-slate-200 rounded-xl text-xs sm:text-sm font-semibold text-slate-800 placeholder-slate-400 focus:outline-hidden focus:border-amber-500 transition-colors"
          />
        </div>

        {/* Filter by Status */}
        <div className="flex items-center gap-1.5 shrink-0">
          <span className="text-xs font-bold text-slate-500 hidden sm:inline">الحالة:</span>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 focus:outline-hidden focus:border-amber-500 cursor-pointer"
          >
            <option value="ALL">جميع الحالات</option>
            <option value="open">مفتوحة (جديدة)</option>
            <option value="partially_cleared">قيد التصفية</option>
            <option value="cleared">مصفاة بالكامل</option>
            <option value="closed">مغلقة ومخلاة رسمياً</option>
          </select>
        </div>

        {/* Filter by Recipient Type */}
        <div className="flex items-center gap-1.5 shrink-0">
          <span className="text-xs font-bold text-slate-500 hidden sm:inline">المستلم:</span>
          <select
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value)}
            className="px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 focus:outline-hidden focus:border-amber-500 cursor-pointer"
          >
            <option value="ALL">جميع الفئات</option>
            <option value="employee">موظف</option>
            <option value="worker">عامل</option>
            <option value="supplier">مورد</option>
            <option value="other">طرف آخر</option>
          </select>
        </div>

        {/* Filter by Currency */}
        <div className="flex items-center gap-1.5 shrink-0">
          <span className="text-xs font-bold text-slate-500 hidden sm:inline">العملة:</span>
          <select
            value={currencyFilter}
            onChange={(e) => setCurrencyFilter(e.target.value)}
            className="px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 focus:outline-hidden focus:border-amber-500 cursor-pointer"
          >
            <option value="ALL">جميع العملات</option>
            <option value="YER">ريال يمني (YER)</option>
            <option value="SAR">ريال سعودي (SAR)</option>
            <option value="USD">دولار أمريكي (USD)</option>
          </select>
        </div>

      </div>

      {/* 4. Custodies List */}
      {custodies.length === 0 ? (
        <div className="bg-white rounded-2xl border-2 border-dashed border-slate-200 p-10 text-center space-y-4">
          <div className="w-16 h-16 rounded-full bg-amber-50 text-amber-600 mx-auto flex items-center justify-center">
            <WalletCards size={32} />
          </div>
          <div className="max-w-md mx-auto">
            <h3 className="text-base font-bold text-slate-800">لا توجد عهد مالية مسجلة في هذا المشروع حتى الآن</h3>
            <p className="text-xs text-slate-500 mt-1 leading-relaxed">
              يمكنك صرف عهدة نقدية لأحد المهندسين أو المشرفين أو العمال لتغطية النثريات والمشتريات الطارئة للموقع، ثم تصفية فواتيرها وإخلاء الذمة بسهولة تامة.
            </p>
          </div>
          {sharedRole !== 'read' && (
            <button
              type="button"
              onClick={handleOpenAddModal}
              className="px-4 py-2.5 bg-amber-500 hover:bg-amber-600 text-slate-950 font-black rounded-xl text-xs transition-all inline-flex items-center gap-2 shadow-md cursor-pointer active:scale-95"
            >
              <PlusCircle size={16} />
              صرف أول عهدة مالية الآن
            </button>
          )}
        </div>
      ) : filteredCustodies.length === 0 ? (
        <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center text-slate-500 text-xs font-bold">
          لا توجد عهد مالية تطابق معايير البحث والفلترة المحددة.
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full min-w-full text-right border-collapse text-xs sm:text-sm">
              <thead>
                <tr className="bg-slate-50/90 text-slate-600 font-bold border-b border-slate-200 text-[11px] sm:text-xs select-none">
                  <th className="p-3 w-28 text-center">رقم العهدة</th>
                  <th className="p-3 w-28 text-center">التاريخ</th>
                  <th className="p-3">أمين العهدة (المستلم)</th>
                  <th className="p-3">الغرض والبيان</th>
                  <th className="p-3 w-32 text-center">مبلغ العهدة</th>
                  <th className="p-3 w-32 text-center">المصفى بالفواتير</th>
                  <th className="p-3 w-32 text-center">المتبقي بذمته</th>
                  <th className="p-3 w-28 text-center">نسبة التصفية</th>
                  <th className="p-3 w-28 text-center">الحالة</th>
                  <th className="p-3 w-36 text-center">إجراءات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                {filteredCustodies.map((item, idx) => {
                  const stats = getCustodyStats(item);

                  const recipientTypeLabel = 
                    item.recipientType === 'employee' ? 'موظف' :
                    item.recipientType === 'worker' ? 'عامل' :
                    item.recipientType === 'supplier' ? 'مورد' : 'طرف آخر';

                  const recipientTypeBadge = 
                    item.recipientType === 'employee' ? 'bg-sky-50 text-sky-700 border-sky-200' :
                    item.recipientType === 'worker' ? 'bg-amber-50 text-amber-800 border-amber-200' :
                    item.recipientType === 'supplier' ? 'bg-indigo-50 text-indigo-700 border-indigo-200' :
                    'bg-slate-100 text-slate-600 border-slate-200';

                  return (
                    <tr 
                      key={item.id}
                      className={`hover:bg-slate-50/80 transition-colors ${idx % 2 === 1 ? 'bg-slate-50/30' : 'bg-white'}`}
                    >
                      {/* Custody Number */}
                      <td className="p-3 text-center">
                        <span className="font-mono font-black text-amber-700 bg-amber-50 border border-amber-200/80 px-2 py-0.5 rounded-lg text-xs">
                          {item.custodyNumber}
                        </span>
                      </td>

                      {/* Date */}
                      <td className="p-3 text-center text-slate-500 font-semibold text-xs whitespace-nowrap">
                        {formatDateArabic(item.date)}
                      </td>

                      {/* Recipient */}
                      <td className="p-3">
                        <div className="font-bold text-slate-900 text-xs sm:text-sm flex items-center gap-1.5">
                          <span>{item.recipientName}</span>
                          <span className={`text-[10px] px-1.5 py-0.2 rounded border font-semibold ${recipientTypeBadge}`}>
                            {recipientTypeLabel}
                          </span>
                        </div>
                        <div className="text-[11px] text-slate-400 mt-0.5 flex items-center gap-2">
                          {item.recipientProfession && <span>{item.recipientProfession}</span>}
                          {item.recipientPhone && (
                            <span className="font-mono text-slate-400 text-[10px] dir-ltr inline-block">
                              {item.recipientPhone}
                            </span>
                          )}
                        </div>
                      </td>

                      {/* Purpose */}
                      <td className="p-3">
                        <div className="font-semibold text-slate-800 text-xs sm:text-sm line-clamp-1">
                          {item.custodyName}
                        </div>
                        {item.notes && (
                          <div className="text-[10px] text-slate-400 mt-0.5 line-clamp-1">
                            {item.notes}
                          </div>
                        )}
                        {stats.settlementsCount > 0 && (
                          <div className="text-[10px] text-emerald-600 font-bold mt-0.5 flex items-center gap-1">
                            <Receipt size={11} />
                            <span>{stats.settlementsCount} فاتورة تصفية مرفقة</span>
                          </div>
                        )}
                      </td>

                      {/* Amount */}
                      <td className="p-3 text-center font-bold text-slate-900 text-xs sm:text-sm whitespace-nowrap">
                        {formatCurrency(item.amount, item.currency)}
                      </td>

                      {/* Settled */}
                      <td className="p-3 text-center font-black text-emerald-700 text-xs sm:text-sm whitespace-nowrap">
                        {formatCurrency(stats.totalSettled, item.currency)}
                      </td>

                      {/* Balance */}
                      <td className="p-3 text-center whitespace-nowrap">
                        <span className={`font-black text-xs sm:text-sm ${
                          stats.balance > 0 
                            ? 'text-sky-700' 
                            : stats.balance < 0 
                              ? 'text-rose-600' 
                              : 'text-emerald-700'
                        }`}>
                          {stats.balance === 0 
                            ? '0 (تمت التصفية)' 
                            : formatCurrency(Math.abs(stats.balance), item.currency)}
                        </span>
                        {stats.balance < 0 && (
                          <span className="block text-[9px] text-rose-500 font-bold">عجز (دفع من جيبه)</span>
                        )}
                      </td>

                      {/* Progress */}
                      <td className="p-3 text-center">
                        <div className="text-xs font-bold text-slate-700">
                          {stats.progressPercent.toFixed(0)}%
                        </div>
                        <div className="w-16 mx-auto bg-slate-200 rounded-full h-1.5 mt-1 overflow-hidden">
                          <div 
                            className={`h-full transition-all duration-300 ${
                              stats.progressPercent >= 100 
                                ? 'bg-emerald-500' 
                                : stats.progressPercent > 50 
                                  ? 'bg-amber-500' 
                                  : 'bg-sky-500'
                            }`}
                            style={{ width: `${Math.min(stats.progressPercent, 100)}%` }}
                          />
                        </div>
                      </td>

                      {/* Status */}
                      <td className="p-3 text-center whitespace-nowrap">
                        {item.status === 'closed' ? (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-slate-100 text-slate-700 border border-slate-300">
                            <CheckCircle2 size={11} className="text-slate-600" />
                            مغلقة ومخلاة
                          </span>
                        ) : stats.computedStatus === 'cleared' ? (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-emerald-50 text-emerald-700 border border-emerald-300">
                            <CheckCircle2 size={11} className="text-emerald-600" />
                            مصفاة 100%
                          </span>
                        ) : stats.computedStatus === 'partially_cleared' ? (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-amber-50 text-amber-700 border border-amber-300">
                            <Clock size={11} className="text-amber-600" />
                            قيد التصفية
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-sky-50 text-sky-700 border border-sky-300">
                            <Clock size={11} className="text-sky-600" />
                            جديدة مفتوحة
                          </span>
                        )}
                      </td>

                      {/* Actions */}
                      <td className="p-3 text-center">
                        <div className="flex items-center justify-center gap-1">
                          
                          {/* Settle / View Button */}
                          <button
                            type="button"
                            onClick={() => setViewingCustody(item)}
                            className="px-2 py-1 bg-amber-500/15 hover:bg-amber-500 text-amber-800 hover:text-slate-950 rounded-lg text-xs font-bold transition-all flex items-center gap-1 cursor-pointer"
                            title="عرض كشف الفواتير وتصفية العهدة"
                          >
                            <Receipt size={13} />
                            <span>تصفية</span>
                          </button>

                          {/* Print Voucher */}
                          <button
                            type="button"
                            onClick={() => handlePrintCustodyVoucher(item)}
                            className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-600 hover:text-slate-900 transition-colors cursor-pointer"
                            title="طباعة سند كشف وتصفية العهدة"
                          >
                            <Printer size={13} />
                          </button>

                          {/* Share WhatsApp */}
                          <button
                            type="button"
                            onClick={() => handleShareWhatsApp(item)}
                            className="p-1.5 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-600 transition-colors cursor-pointer"
                            title="مشاركة تفاصيل العهدة عبر الواتساب"
                          >
                            <Share2 size={13} />
                          </button>

                          {/* Edit (if not closed) */}
                          {sharedRole !== 'read' && item.status !== 'closed' && (
                            <button
                              type="button"
                              onClick={() => handleOpenEditModal(item)}
                              className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-600 hover:text-slate-900 transition-colors cursor-pointer"
                              title="تعديل بيانات العهدة"
                            >
                              <Edit size={13} />
                            </button>
                          )}

                          {/* Delete */}
                          {sharedRole !== 'read' && (
                            <button
                              type="button"
                              onClick={() => {
                                if (window.confirm(`هل أنت متأكد من حذف العهدة المالية [${item.custodyNumber}] باسم (${item.recipientName}) وكافة فواتير تصفيتها؟`)) {
                                  onDeleteCustody(item.id);
                                }
                              }}
                              className="p-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-600 transition-colors cursor-pointer"
                              title="حذف العهدة"
                            >
                              <Trash2 size={13} />
                            </button>
                          )}

                        </div>
                      </td>

                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* =========================================================================
          MODAL 1: ADD / EDIT CUSTODY
          ========================================================================= */}
      {isNewCustodyModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/80 backdrop-blur-xs overflow-y-auto overscroll-contain">
          <div className="bg-white text-slate-900 rounded-2xl max-w-lg w-full shadow-2xl border border-slate-100 my-auto text-right dir-rtl animate-in fade-in zoom-in duration-150 max-h-[92vh] flex flex-col overflow-hidden">
            
            {/* Modal Header */}
            <div className="p-4 bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2">
                <WalletCards size={20} className="text-slate-950" />
                <h3 className="font-black text-sm sm:text-base">
                  {editingCustody ? `تعديل بيانات العهدة [${custodyNumber}]` : 'صرف وتسليم عهدة مالية جديدة'}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setIsNewCustodyModalOpen(false)}
                className="p-1 rounded-lg hover:bg-black/10 transition-colors cursor-pointer"
              >
                <X size={18} />
              </button>
            </div>

            {/* Modal Form */}
            <form onSubmit={handleSubmitCustody} className="p-4 sm:p-5 space-y-4 overflow-y-auto custom-scrollbar flex-1">
              
              {/* Custody Number & Date */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    رقم العهدة:
                  </label>
                  <input
                    type="text"
                    required
                    value={custodyNumber}
                    onChange={(e) => setCustodyNumber(e.target.value)}
                    placeholder="مثال: CUST-001"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono font-bold text-slate-800 focus:outline-hidden focus:border-amber-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    تاريخ التسليم:
                  </label>
                  <input
                    type="date"
                    required
                    value={custodyDate}
                    onChange={(e) => setCustodyDate(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-hidden focus:border-amber-500"
                  />
                </div>
              </div>

              {/* Recipient Type Tabs */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  فئة أمين العهدة (المستلم):
                </label>
                <div className="grid grid-cols-4 gap-1.5 bg-slate-100 p-1 rounded-xl">
                  {(['employee', 'worker', 'supplier', 'other'] as CustodyRecipientType[]).map((t) => (
                    <button
                      key={t}
                      type="button"
                      onClick={() => {
                        setRecipientType(t);
                        setRecipientId('');
                      }}
                      className={`py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer text-center ${
                        recipientType === t
                          ? 'bg-amber-500 text-slate-950 shadow-xs'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      {t === 'employee' ? 'موظف' : t === 'worker' ? 'عامل' : t === 'supplier' ? 'مورد' : 'آخر'}
                    </button>
                  ))}
                </div>
              </div>

              {/* Predefined selection if applicable */}
              {recipientType === 'employee' && employees.length > 0 && (
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    اختيار من قائمة الموظفين:
                  </label>
                  <select
                    value={recipientId}
                    onChange={(e) => handleSelectPredefinedRecipient('employee', e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-hidden focus:border-amber-500 cursor-pointer"
                  >
                    <option value="">-- اختر موظفاً أو اكتب اسماً يدوياً بالأسفل --</option>
                    {employees.map(e => (
                      <option key={e.id} value={e.id}>
                        {e.name} ({e.profession || 'موظف'})
                      </option>
                    ))}
                  </select>
                </div>
              )}

              {recipientType === 'worker' && workers.length > 0 && (
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    اختيار من قائمة العمال:
                  </label>
                  <select
                    value={recipientId}
                    onChange={(e) => handleSelectPredefinedRecipient('worker', e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-hidden focus:border-amber-500 cursor-pointer"
                  >
                    <option value="">-- اختر عاملاً أو اكتب اسماً يدوياً بالأسفل --</option>
                    {workers.map(w => (
                      <option key={w.id} value={w.id}>
                        {w.name} ({w.profession || 'عامل'})
                      </option>
                    ))}
                  </select>
                </div>
              )}

              {recipientType === 'supplier' && suppliers.length > 0 && (
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    اختيار من قائمة الموردين:
                  </label>
                  <select
                    value={recipientId}
                    onChange={(e) => handleSelectPredefinedRecipient('supplier', e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-hidden focus:border-amber-500 cursor-pointer"
                  >
                    <option value="">-- اختر مورداً أو اكتب اسماً يدوياً بالأسفل --</option>
                    {suppliers.map(s => (
                      <option key={s.id} value={s.id}>
                        {s.name} ({s.materialType || 'توريد'})
                      </option>
                    ))}
                  </select>
                </div>
              )}

              {/* Recipient Details */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    اسم أمين العهدة المستلم: *
                  </label>
                  <input
                    type="text"
                    required
                    value={recipientName}
                    onChange={(e) => setRecipientName(e.target.value)}
                    placeholder="مثال: المهندس المشرف أو المقاول"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-hidden focus:border-amber-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    الصفة / المهنة:
                  </label>
                  <input
                    type="text"
                    value={recipientProfession}
                    onChange={(e) => setRecipientProfession(e.target.value)}
                    placeholder="مثال: مهندس موقع، مشرف، نجار..."
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-hidden focus:border-amber-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  رقم الهاتف (اختياري):
                </label>
                <input
                  type="tel"
                  value={recipientPhone}
                  onChange={(e) => setRecipientPhone(e.target.value)}
                  placeholder="رقم الهاتف للمتابعة والتواصل"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-hidden focus:border-amber-500"
                />
              </div>

              {/* Custody Purpose / Name */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  عنوان أو غرض العهدة: *
                </label>
                <input
                  type="text"
                  required
                  value={custodyName}
                  onChange={(e) => setCustodyName(e.target.value)}
                  placeholder="مثال: عهدة نثريات الموقع وشراء محروقات وصيانة"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-hidden focus:border-amber-500"
                />
              </div>

              {/* Amount & Currency */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    مبلغ العهدة المسلم: *
                  </label>
                  <input
                    type="number"
                    step="any"
                    required
                    min="1"
                    value={custodyAmount}
                    onChange={(e) => setCustodyAmount(e.target.value)}
                    placeholder="أدخل المبلغ المسلم"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-black text-slate-900 focus:outline-hidden focus:border-amber-500"
                  />
                  {custodyAmount && parseFloat(custodyAmount) > 0 && (
                    <AmountInWords amount={parseFloat(custodyAmount)} currency={custodyCurrency} />
                  )}
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    العملة:
                  </label>
                  <select
                    value={custodyCurrency}
                    onChange={(e) => setCustodyCurrency(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-hidden focus:border-amber-500 cursor-pointer"
                  >
                    <option value="YER">ريال يمني (YER)</option>
                    <option value="SAR">ريال سعودي (SAR)</option>
                    <option value="USD">دولار أمريكي (USD)</option>
                  </select>
                </div>
              </div>

              {/* Notes */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  ملاحظات أو شروط إضافية:
                </label>
                <textarea
                  rows={2}
                  value={custodyNotes}
                  onChange={(e) => setCustodyNotes(e.target.value)}
                  placeholder="أي ملاحظات أو بنود تسليم خاصة..."
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-800 focus:outline-hidden focus:border-amber-500"
                />
              </div>

              {/* Actions */}
              <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsNewCustodyModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition-all cursor-pointer"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-amber-500 hover:bg-amber-600 text-slate-950 font-black rounded-xl text-xs transition-all shadow-md cursor-pointer active:scale-95"
                >
                  {editingCustody ? 'حفظ التعديلات' : 'تأكيد وصرف العهدة'}
                </button>
              </div>

            </form>

          </div>
        </div>
      )}

      {/* =========================================================================
          MODAL 2: VIEW CUSTODY SETTLEMENTS & CLEARANCE
          ========================================================================= */}
      {viewingCustody && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/80 backdrop-blur-xs overflow-y-auto overscroll-contain">
          <div className="bg-white text-slate-900 rounded-2xl max-w-3xl w-full shadow-2xl border border-slate-100 my-auto text-right dir-rtl animate-in fade-in zoom-in duration-150 max-h-[92vh] flex flex-col overflow-hidden">
            
            {/* Modal Header */}
            <div className="p-4 bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 text-white flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-amber-500 text-slate-950 flex items-center justify-center font-black">
                  <Receipt size={17} />
                </div>
                <div>
                  <h3 className="font-extrabold text-sm sm:text-base">
                    كشف حساب وتصفية العهدة [{viewingCustody.custodyNumber}]
                  </h3>
                  <p className="text-[11px] text-slate-300">
                    أمين العهدة: {viewingCustody.recipientName} - {viewingCustody.custodyName}
                  </p>
                </div>
              </div>
              
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => handlePrintCustodyVoucher(viewingCustody)}
                  className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-bold transition-all flex items-center gap-1 cursor-pointer"
                  title="طباعة سند كشف وتصفية العهدة"
                >
                  <Printer size={13} />
                  <span className="hidden sm:inline">طباعة</span>
                </button>
                <button
                  type="button"
                  onClick={() => setViewingCustody(null)}
                  className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition-colors cursor-pointer"
                >
                  <X size={18} />
                </button>
              </div>
            </div>

            {/* Modal Content */}
            <div className="p-4 sm:p-5 space-y-4 overflow-y-auto custom-scrollbar flex-1">
              
              {/* Custody Summary Card */}
              {(() => {
                const stats = getCustodyStats(viewingCustody);
                return (
                  <div className="bg-slate-50 rounded-2xl border border-slate-200 p-4 space-y-3">
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
                      
                      <div className="bg-white p-2.5 rounded-xl border border-slate-200">
                        <span className="text-[10px] text-slate-500 font-bold block">مبلغ العهدة الأصلي</span>
                        <span className="text-sm sm:text-base font-black text-slate-900 mt-0.5 block">
                          {formatCurrency(viewingCustody.amount, viewingCustody.currency)}
                        </span>
                      </div>

                      <div className="bg-white p-2.5 rounded-xl border border-slate-200">
                        <span className="text-[10px] text-slate-500 font-bold block">المصفى بالفواتير</span>
                        <span className="text-sm sm:text-base font-black text-emerald-700 mt-0.5 block">
                          {formatCurrency(stats.totalSettled, viewingCustody.currency)}
                        </span>
                      </div>

                      <div className="bg-white p-2.5 rounded-xl border border-slate-200">
                        <span className="text-[10px] text-slate-500 font-bold block">
                          {stats.balance >= 0 ? 'المتبقي بذمته (فائض)' : 'المستحق له (عجز)'}
                        </span>
                        <span className={`text-sm sm:text-base font-black mt-0.5 block ${
                          stats.balance > 0 ? 'text-sky-700' : stats.balance < 0 ? 'text-rose-600' : 'text-emerald-700'
                        }`}>
                          {stats.balance === 0 ? '0 (مطابقة تامة)' : formatCurrency(Math.abs(stats.balance), viewingCustody.currency)}
                        </span>
                      </div>

                      <div className="bg-white p-2.5 rounded-xl border border-slate-200">
                        <span className="text-[10px] text-slate-500 font-bold block">نسبة التصفية</span>
                        <span className="text-sm sm:text-base font-black text-slate-900 mt-0.5 block">
                          {stats.progressPercent.toFixed(1)}%
                        </span>
                      </div>

                    </div>

                    {/* Progress bar */}
                    <div className="w-full bg-slate-200 rounded-full h-2 overflow-hidden">
                      <div 
                        className={`h-full transition-all duration-300 ${
                          stats.progressPercent >= 100 ? 'bg-emerald-500' : stats.progressPercent > 50 ? 'bg-amber-500' : 'bg-sky-500'
                        }`}
                        style={{ width: `${Math.min(stats.progressPercent, 100)}%` }}
                      />
                    </div>

                    {/* Clearance Status Notice if closed */}
                    {viewingCustody.status === 'closed' && (
                      <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-900 flex items-center justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <CheckCircle2 size={16} className="text-emerald-600 shrink-0" />
                          <div>
                            <span className="font-black">تم إخلاء ذمة هذه العهدة وإغلاقها رسمياً</span>
                            {viewingCustody.clearedAt && (
                              <span className="text-[10px] text-emerald-700 block">
                                بتاريخ: {formatDateArabic(viewingCustody.clearedAt)}
                                {viewingCustody.clearedBy && ` بواسطة: ${viewingCustody.clearedBy}`}
                              </span>
                            )}
                          </div>
                        </div>
                        {viewingCustody.returnedAmount ? (
                          <span className="text-[11px] font-bold text-emerald-800 bg-white px-2 py-0.5 rounded-md border border-emerald-300">
                            تم استرداد فائض: {formatCurrency(viewingCustody.returnedAmount, viewingCustody.currency)}
                          </span>
                        ) : null}
                      </div>
                    )}

                  </div>
                );
              })()}

              {/* Settlements Section Header */}
              <div className="flex items-center justify-between gap-2 pt-2">
                <div className="flex items-center gap-2">
                  <h4 className="font-extrabold text-sm text-slate-900">
                    فواتير ومصروفات تصفية العهدة ({viewingCustody.settlements?.length || 0})
                  </h4>
                  <span className="text-xs text-slate-400">
                    كل فاتورة يتم إدراجها هنا تخصم من رصيد العهدة مباشرة
                  </span>
                </div>

                {sharedRole !== 'read' && viewingCustody.status !== 'closed' && (
                  <button
                    type="button"
                    onClick={() => handleOpenAddSettlement(viewingCustody)}
                    className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer shadow-xs active:scale-95"
                  >
                    <PlusCircle size={14} />
                    <span>إضافة فاتورة تصفية</span>
                  </button>
                )}
              </div>

              {/* Settlements Table */}
              {(!viewingCustody.settlements || viewingCustody.settlements.length === 0) ? (
                <div className="p-8 text-center bg-slate-50 border border-dashed border-slate-200 rounded-xl text-slate-400 text-xs">
                  لم يتم إضافة أي فواتير أو مستندات صرف لتصفية هذه العهدة بعد.
                  {sharedRole !== 'read' && viewingCustody.status !== 'closed' && (
                    <button
                      type="button"
                      onClick={() => handleOpenAddSettlement(viewingCustody)}
                      className="text-emerald-700 hover:underline font-bold mr-1 inline-flex items-center gap-1 cursor-pointer"
                    >
                      إضافة أول فاتورة الآن
                    </button>
                  )}
                </div>
              ) : (
                <div className="border border-slate-200 rounded-xl overflow-hidden">
                  <table className="w-full text-right text-xs">
                    <thead>
                      <tr className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200 text-[11px]">
                        <th className="p-2.5 text-center w-10">#</th>
                        <th className="p-2.5 text-center w-24">التاريخ</th>
                        <th className="p-2.5 text-center w-24">رقم الفاتورة</th>
                        <th className="p-2.5">بيان وتوصيف النفقة</th>
                        <th className="p-2.5 text-center w-28">التصنيف</th>
                        <th className="p-2.5 text-center w-28">المبلغ</th>
                        {sharedRole !== 'read' && viewingCustody.status !== 'closed' && (
                          <th className="p-2.5 text-center w-16">إجراء</th>
                        )}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                      {viewingCustody.settlements.map((st, idx) => (
                        <tr key={st.id} className="hover:bg-slate-50">
                          <td className="p-2.5 text-center text-slate-400 font-mono text-[10px]">
                            {idx + 1}
                          </td>
                          <td className="p-2.5 text-center text-slate-500 whitespace-nowrap">
                            {formatDateArabic(st.date)}
                          </td>
                          <td className="p-2.5 text-center font-mono font-bold text-slate-800 whitespace-nowrap">
                            {st.invoiceNumber || 'بدون'}
                          </td>
                          <td className="p-2.5">
                            <span className="font-bold text-slate-900 block">{st.description}</span>
                            {st.notes && <span className="text-[10px] text-slate-400 block">{st.notes}</span>}
                            {st.contractItemNumber && (
                              <span className="text-[10px] text-teal-700 bg-teal-50 px-1.5 py-0.2 rounded mt-0.5 inline-block">
                                بند عقد: [{st.contractItemNumber}]
                              </span>
                            )}
                          </td>
                          <td className="p-2.5 text-center">
                            <span className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 text-[10px] font-bold">
                              {st.category || 'عام'}
                            </span>
                          </td>
                          <td className="p-2.5 text-center font-black text-emerald-700 text-xs sm:text-sm whitespace-nowrap">
                            {formatCurrency(st.amount, viewingCustody.currency)}
                          </td>
                          {sharedRole !== 'read' && viewingCustody.status !== 'closed' && (
                            <td className="p-2.5 text-center">
                              <div className="flex items-center justify-center gap-1">
                                <button
                                  type="button"
                                  onClick={() => handleOpenEditSettlement(viewingCustody.id, st)}
                                  className="p-1 rounded text-amber-600 hover:bg-amber-50 transition-colors cursor-pointer"
                                  title="تعديل فاتورة التصفية"
                                >
                                  <Edit size={13} />
                                </button>
                                <button
                                  type="button"
                                  onClick={() => {
                                    if (window.confirm(`هل أنت متأكد من حذف فاتورة التصفية (${st.description}) بمبلغ ${formatCurrency(st.amount, viewingCustody.currency)}؟`)) {
                                      onDeleteSettlement(viewingCustody.id, st.id);
                                      // Refresh view modal
                                      const refreshed = custodies.find(c => c.id === viewingCustody.id);
                                      if (refreshed) {
                                        setViewingCustody({
                                          ...refreshed,
                                          settlements: refreshed.settlements.filter(s => s.id !== st.id)
                                        });
                                      }
                                    }
                                  }}
                                  className="p-1 rounded text-rose-500 hover:bg-rose-50 transition-colors cursor-pointer"
                                  title="حذف الفاتورة من التصفية"
                                >
                                  <Trash2 size={13} />
                                </button>
                              </div>
                            </td>
                          )}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}

              {/* Clearance / Closing Actions Box */}
              {sharedRole !== 'read' && viewingCustody.status !== 'closed' && (
                <div className="bg-amber-500/10 border border-amber-500/30 rounded-2xl p-4 space-y-3">
                  <div className="flex items-center gap-2">
                    <ShieldCheck size={18} className="text-amber-600" />
                    <h5 className="font-black text-xs sm:text-sm text-slate-900">
                      إجراءات التسوية النهائية وإخلاء الذمة
                    </h5>
                  </div>
                  
                  {(() => {
                    const stats = getCustodyStats(viewingCustody);
                    return (
                      <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
                        <div className="text-xs text-slate-600 leading-relaxed max-w-md">
                          {stats.balance > 0 ? (
                            <span>
                              يوجد فائض نقدي متبقي بعهدة المستلم قدره <strong>{formatCurrency(stats.balance, viewingCustody.currency)}</strong>. عند إخلاء العهدة سيتم توثيق توريد هذا الفائض للصندوق وإغلاق العهدة.
                            </span>
                          ) : stats.balance < 0 ? (
                            <span>
                              قام أمين العهدة بالصرف بزيادة عن العهدة بعجز قدره <strong>{formatCurrency(Math.abs(stats.balance), viewingCustody.currency)}</strong>. عند الإخلاء سيتم توثيق استحقاقه لهذا المبلغ كتعويض وإغلاق العهدة.
                            </span>
                          ) : (
                            <span>
                              العهدة مصفاة بالكامل (0). يمكنك الآن اعتماد إخلاء الذمة وإغلاق العهدة نهائياً.
                            </span>
                          )}
                        </div>

                        <button
                          type="button"
                          onClick={() => setClearanceActionCustody(viewingCustody)}
                          className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-amber-300 font-extrabold rounded-xl text-xs transition-all flex items-center gap-1.5 cursor-pointer shadow-md active:scale-95 shrink-0"
                        >
                          <ShieldCheck size={15} />
                          <span>إخلاء الذمة وإغلاق العهدة نهائياً</span>
                        </button>
                      </div>
                    );
                  })()}
                </div>
              )}

            </div>

            {/* Modal Footer */}
            <div className="p-3 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
              <button
                type="button"
                onClick={() => handleShareWhatsApp(viewingCustody)}
                className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer"
              >
                <Share2 size={13} />
                <span>مشاركة كشف التصفية بالواتساب</span>
              </button>

              <button
                type="button"
                onClick={() => setViewingCustody(null)}
                className="px-4 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-800 rounded-xl text-xs font-bold transition-all cursor-pointer"
              >
                إغلاق
              </button>
            </div>

          </div>
        </div>
      )}

      {/* =========================================================================
          MODAL 3: ADD SETTLEMENT INVOICE
          ========================================================================= */}
      {isAddSettlementModalOpen && viewingCustody && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-3 sm:p-4 bg-slate-900/80 backdrop-blur-xs overflow-y-auto overscroll-contain">
          <div className="bg-white text-slate-900 rounded-2xl max-w-md w-full shadow-2xl border border-slate-100 my-auto text-right dir-rtl animate-in fade-in zoom-in duration-150 max-h-[92vh] flex flex-col overflow-hidden">
            
            {/* Modal Header */}
            <div className="p-4 bg-gradient-to-r from-emerald-600 to-teal-700 text-white flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2">
                <Receipt size={18} className="text-emerald-200" />
                <h3 className="font-extrabold text-sm sm:text-base">
                  إضافة فاتورة تصفية للعهدة [{viewingCustody.custodyNumber}]
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setIsAddSettlementModalOpen(false)}
                className="p-1 rounded-lg hover:bg-black/10 transition-colors cursor-pointer"
              >
                <X size={18} />
              </button>
            </div>

            {/* Modal Form */}
            <form onSubmit={handleSubmitSettlement} className="p-4 sm:p-5 space-y-3.5 overflow-y-auto custom-scrollbar flex-1">
              
              {/* Date & Invoice Number */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    تاريخ الفاتورة: *
                  </label>
                  <input
                    type="date"
                    required
                    value={settlementDate}
                    onChange={(e) => setSettlementDate(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-hidden focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    رقم الفاتورة / السند:
                  </label>
                  <input
                    type="text"
                    value={settlementInvoiceNumber}
                    onChange={(e) => setSettlementInvoiceNumber(e.target.value)}
                    placeholder="مثال: 1042 أو INV-09"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono font-bold text-slate-800 focus:outline-hidden focus:border-emerald-500"
                  />
                </div>
              </div>

              {/* Description */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  بيان وتوصيف النفقة / المشتريات: *
                </label>
                <input
                  type="text"
                  required
                  value={settlementDescription}
                  onChange={(e) => setSettlementDescription(e.target.value)}
                  placeholder="مثال: شراء مسامير وأسلاك ربط وخشب طوارئ"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-hidden focus:border-emerald-500"
                />
              </div>

              {/* Amount & Category */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    المبلغ المصروف ({viewingCustody.currency}): *
                  </label>
                  <input
                    type="number"
                    step="any"
                    required
                    min="0.01"
                    value={settlementAmount}
                    onChange={(e) => setSettlementAmount(e.target.value)}
                    placeholder="أدخل المبلغ"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-black text-slate-900 focus:outline-hidden focus:border-emerald-500"
                  />
                  {settlementAmount && parseFloat(settlementAmount) > 0 && (
                    <AmountInWords amount={parseFloat(settlementAmount)} currency={viewingCustody.currency} />
                  )}
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    تصنيف النفقة:
                  </label>
                  <select
                    value={settlementCategory}
                    onChange={(e) => setSettlementCategory(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-hidden focus:border-emerald-500 cursor-pointer"
                  >
                    <option value="مواد ومشتريات">مواد ومشتريات موقع</option>
                    <option value="نثريات وضيافة">نثريات ومستلزمات</option>
                    <option value="محروقات ونقل">محروقات وبترول ونقل</option>
                    <option value="أجور وخدمات">أجور عمالة طارئة</option>
                    <option value="صيانة وقطع غيار">صيانة عدد ومعدات</option>
                    <option value="أخرى">أخرى</option>
                  </select>
                </div>
              </div>

              {/* BOQ Item Linking (Optional) */}
              {contractItems.length > 0 && (
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    ربط بجدول الكميات وبنود العقد (اختياري):
                  </label>
                  <select
                    value={settlementContractItemId}
                    onChange={(e) => setSettlementContractItemId(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-hidden focus:border-emerald-500 cursor-pointer"
                  >
                    <option value="">-- بدون ربط بجدول الكميات --</option>
                    {contractItems.map(c => (
                      <option key={c.id} value={c.id}>
                        [{c.itemNumber}] {c.name}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              {/* Checkbox to also add to Daily Expenses */}
              <div className="bg-slate-50 border border-slate-200 p-3 rounded-xl">
                <label className="flex items-start gap-2.5 cursor-pointer text-xs font-bold text-slate-800">
                  <input
                    type="checkbox"
                    checked={alsoAddToDailyExpenses}
                    onChange={(e) => setAlsoAddToDailyExpenses(e.target.checked)}
                    className="mt-0.5 rounded text-emerald-600 focus:ring-emerald-500 w-4 h-4 cursor-pointer"
                  />
                  <div>
                    <span>ترحيل هذه النفقة تلقائياً إلى سجل المصاريف اليومية للمشروع</span>
                    <span className="text-[10px] text-slate-400 block font-normal mt-0.5">
                      ستظهر النفقة في تقارير المصاريف موثقة باسم أمين العهدة دون ازدواجية حركة الصندوق.
                    </span>
                  </div>
                </label>
              </div>

              {/* Notes */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  ملاحظات:
                </label>
                <textarea
                  rows={2}
                  value={settlementNotes}
                  onChange={(e) => setSettlementNotes(e.target.value)}
                  placeholder="ملاحظات توثيقية إضافية..."
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-800 focus:outline-hidden focus:border-emerald-500"
                />
              </div>

              {/* Actions */}
              <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsAddSettlementModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition-all cursor-pointer"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-black rounded-xl text-xs transition-all shadow-md cursor-pointer active:scale-95"
                >
                  إدراج الفاتورة وتصفية المبلغ
                </button>
              </div>

            </form>

          </div>
        </div>
      )}

      {/* =========================================================================
          MODAL 3.5: EDIT SETTLEMENT INVOICE
          ========================================================================= */}
      {editingSettlement && (
        <div className="fixed inset-0 z-[65] flex items-center justify-center p-3 sm:p-4 bg-slate-900/80 backdrop-blur-xs overflow-y-auto overscroll-contain">
          <div className="bg-white text-slate-900 rounded-2xl max-w-md w-full shadow-2xl border border-slate-100 my-auto text-right dir-rtl animate-in fade-in zoom-in duration-150 max-h-[92vh] flex flex-col overflow-hidden">
            
            {/* Modal Header */}
            <div className="p-4 bg-gradient-to-r from-amber-600 to-orange-600 text-white flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2">
                <Edit size={18} className="text-amber-200" />
                <h3 className="font-extrabold text-sm sm:text-base">
                  تعديل فاتورة التصفية
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setEditingSettlement(null)}
                className="p-1 rounded-lg hover:bg-black/10 transition-colors cursor-pointer"
              >
                <X size={18} />
              </button>
            </div>

            {/* Modal Form */}
            <form onSubmit={handleSaveEditSettlement} className="p-4 sm:p-5 space-y-3.5 overflow-y-auto custom-scrollbar flex-1">
              
              {/* Date & Invoice Number */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    تاريخ الفاتورة: *
                  </label>
                  <input
                    type="date"
                    required
                    value={editSettlementDate}
                    onChange={(e) => setEditSettlementDate(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-hidden focus:border-amber-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    رقم الفاتورة / السند:
                  </label>
                  <input
                    type="text"
                    value={editSettlementInvoiceNumber}
                    onChange={(e) => setEditSettlementInvoiceNumber(e.target.value)}
                    placeholder="مثال: 1042 أو INV-09"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono font-bold text-slate-800 focus:outline-hidden focus:border-amber-500"
                  />
                </div>
              </div>

              {/* Description */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  بيان وتوصيف النفقة / المشتريات: *
                </label>
                <input
                  type="text"
                  required
                  value={editSettlementDescription}
                  onChange={(e) => setEditSettlementDescription(e.target.value)}
                  placeholder="مثال: شراء مسامير وأسلاك ربط وخشب طوارئ"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-hidden focus:border-amber-500"
                />
              </div>

              {/* Amount & Category */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    المبلغ المصروف ({currency}): *
                  </label>
                  <input
                    type="number"
                    step="any"
                    required
                    min="0.01"
                    value={editSettlementAmount}
                    onChange={(e) => setEditSettlementAmount(e.target.value)}
                    placeholder="أدخل المبلغ"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-black text-slate-900 focus:outline-hidden focus:border-amber-500"
                  />
                  {editSettlementAmount && parseFloat(editSettlementAmount) > 0 && (
                    <AmountInWords amount={parseFloat(editSettlementAmount)} currency={currency} />
                  )}
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    تصنيف النفقة:
                  </label>
                  <select
                    value={editSettlementCategory}
                    onChange={(e) => setEditSettlementCategory(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-hidden focus:border-amber-500 cursor-pointer"
                  >
                    <option value="مواد ومشتريات">مواد ومشتريات موقع</option>
                    <option value="نثريات وضيافة">نثريات ومستلزمات</option>
                    <option value="محروقات ونقل">محروقات وبترول ونقل</option>
                    <option value="أجور وخدمات">أجور عمالة طارئة</option>
                    <option value="صيانة وقطع غيار">صيانة عدد ومعدات</option>
                    <option value="أخرى">أخرى</option>
                  </select>
                </div>
              </div>

              {/* BOQ Item Linking (Optional) */}
              {contractItems.length > 0 && (
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    ربط بجدول الكميات وبنود العقد (اختياري):
                  </label>
                  <select
                    value={editSettlementContractItemId}
                    onChange={(e) => setEditSettlementContractItemId(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-hidden focus:border-amber-500 cursor-pointer"
                  >
                    <option value="">-- بدون ربط بجدول الكميات --</option>
                    {contractItems.map(c => (
                      <option key={c.id} value={c.id}>
                        [{c.itemNumber}] {c.name}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              {/* Sync Info Banner */}
              <div className="bg-amber-50 border border-amber-200 p-3 rounded-xl flex items-start gap-2 text-xs text-amber-800">
                <Info size={16} className="text-amber-600 shrink-0 mt-0.5" />
                <span>
                  يتم مزامنة أي تعديل في هذه الفاتورة تلقائياً مع الحركة المقابلة في سجل النفقات اليومية وحسابات المستفيدين إن وجدت.
                </span>
              </div>

              {/* Notes */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  ملاحظات:
                </label>
                <textarea
                  rows={2}
                  value={editSettlementNotes}
                  onChange={(e) => setEditSettlementNotes(e.target.value)}
                  placeholder="ملاحظات توثيقية إضافية..."
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-800 focus:outline-hidden focus:border-amber-500"
                />
              </div>

              {/* Actions */}
              <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setEditingSettlement(null)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition-all cursor-pointer"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-amber-600 hover:bg-amber-700 text-white font-black rounded-xl text-xs transition-all shadow-md cursor-pointer active:scale-95"
                >
                  حفظ التعديلات
                </button>
              </div>

            </form>

          </div>
        </div>
      )}

      {/* =========================================================================
          MODAL 4: CONFIRM FINAL CLEARANCE
          ========================================================================= */}
      {clearanceActionCustody && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center p-3 sm:p-4 bg-slate-900/80 backdrop-blur-xs overflow-y-auto overscroll-contain">
          <div className="bg-white text-slate-900 rounded-2xl max-w-md w-full shadow-2xl border border-slate-100 my-auto text-right dir-rtl animate-in fade-in zoom-in duration-150 p-5 space-y-4">
            
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-700 flex items-center justify-center shrink-0">
                <ShieldCheck size={22} />
              </div>
              <div>
                <h3 className="font-black text-base text-slate-900">
                  تأكيد إخلاء الذمة وإغلاق العهدة
                </h3>
                <p className="text-xs text-slate-500">
                  العهدة: [{clearanceActionCustody.custodyNumber}] - {clearanceActionCustody.recipientName}
                </p>
              </div>
            </div>

            {(() => {
              const stats = getCustodyStats(clearanceActionCustody);
              return (
                <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-2 text-xs">
                  <div className="flex justify-between">
                    <span className="text-slate-500 font-bold">المبلغ المسلم:</span>
                    <span className="font-black text-slate-900">
                      {formatCurrency(clearanceActionCustody.amount, clearanceActionCustody.currency)}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500 font-bold">المصفى بالفواتير:</span>
                    <span className="font-black text-emerald-700">
                      {formatCurrency(stats.totalSettled, clearanceActionCustody.currency)}
                    </span>
                  </div>
                  <div className="flex justify-between border-t border-slate-200 pt-1.5">
                    <span className="font-bold text-slate-700">
                      {stats.balance > 0 ? 'الفائض المسترد للصندوق:' : stats.balance < 0 ? 'العجز المصروف للأمين:' : 'الرصيد النهائي:'}
                    </span>
                    <span className={`font-black ${stats.balance > 0 ? 'text-sky-700' : stats.balance < 0 ? 'text-rose-600' : 'text-emerald-700'}`}>
                      {stats.balance === 0 ? '0 (مطابقة تامة)' : formatCurrency(Math.abs(stats.balance), clearanceActionCustody.currency)}
                    </span>
                  </div>
                </div>
              );
            })()}

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                ملاحظات إخلاء الذمة (اختياري):
              </label>
              <input
                type="text"
                value={clearanceNotes}
                onChange={(e) => setClearanceNotes(e.target.value)}
                placeholder="مثال: تم تدقيق الفواتير وتوريد المتبقي نقداً للصندوق"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-800 focus:outline-hidden focus:border-amber-500"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setClearanceActionCustody(null)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition-all cursor-pointer"
              >
                إلغاء
              </button>
              <button
                type="button"
                onClick={handleConfirmClearance}
                className="px-5 py-2 bg-slate-900 hover:bg-slate-800 text-amber-300 font-black rounded-xl text-xs transition-all shadow-md cursor-pointer active:scale-95"
              >
                اعتماد وإخلاء العهدة نهائياً
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
