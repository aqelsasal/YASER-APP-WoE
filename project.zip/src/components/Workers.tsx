/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import PageHeaderCard from './PageHeaderCard';
import { isOwnerUser } from './AttributionBadge';
import { AmountInWords } from './AmountInWords';
import { 
  PlusCircle, 
  Trash2, 
  UserPlus, 
  FileSpreadsheet, 
  FileText, 
  Calendar, 
  Hammer, 
  ChevronLeft, 
  ArrowLeft, 
  Coins, 
  Receipt,
  User,
  Clock,
  Search,
  Filter,
  Info,
  Pencil,
  UserCheck,
  ArrowRightLeft,
  Copy,
  Users,
  ChevronDown,
  ChevronUp,
  Utensils,
  X,
  RotateCcw,
  CalendarX,
  Sparkles,
  Check,
  Eye,
  EyeOff
} from 'lucide-react';
import * as XLSX from 'xlsx';
import AttributionBadge from './AttributionBadge';
import Calculator from './Calculator';
import ShareMenu from './ShareMenu';
import OptionsMenu from './OptionsMenu';
import PhoneNumbersInput, { PhoneNumbersDisplay } from './PhoneNumbersInput';
import ExcelColumnFilter, { ColumnFilterConfig, ActiveColumnFilter, ColumnSortState } from './ExcelColumnFilter';
import { ColumnResizeHandle } from './ColumnResizeHandle';
import { ColumnFreezeButton } from './ColumnFreezeButton';
import { AutoFitNotesCell } from './AutoFitNotesCell';
import CopyMoveLedgerModal from './CopyMoveLedgerModal';
import CustomReportOptionsModal, { ReportFormatType } from './CustomReportOptionsModal';
import { useBodyScrollLock } from '../utils/modalScrollLock';
import { 
  Worker, 
  Employee,
  Supplier,
  LedgerEntry, 
  NutritionPeriod,
  AbsenceRecord,
  getAbsenceTotalDays,
  calculateDaysOfWork, 
  calculateActualDaysOfWork,
  calculateNutritionDays,
  getPersonWorkStatus,
  formatCurrency, 
  formatDateArabic,
  cleanLedgerDescription,
  exportToCSV,
  exportToXLSX,
  exportMultiSheetXLSX,
  printPDF,
  directShareReportPDF
} from '../types';
import { 
  generateSvgDonutChart, 
  generateSvgBalanceComparison, 
  generateMetricCardsGrid 
} from '../utils/reportCharts';

interface WorkersProps {
  workers: Worker[];
  employees?: Employee[];
  suppliers?: Supplier[];
  onAddWorker: (worker: Omit<Worker, 'id' | 'ledger'>) => void;
  onDeleteWorker: (id: string) => void;
  onUpdateWorker?: (id: string, updatedData: Omit<Worker, 'id' | 'ledger' | 'createdBy'>) => void;
  onAddWorkerLedgerEntry: (workerId: string, entry: Omit<LedgerEntry, 'id'>) => void;
  onDeleteWorkerLedgerEntry: (workerId: string, entryId: string) => void;
  onUpdateWorkerLedgerEntry?: (workerId: string, entryId: string, updatedEntry: Omit<LedgerEntry, 'id' | 'createdBy'>) => void;
  onAddWorkerExtraPeriod?: (workerId: string, startDate: string, endDate: string) => void;
  onDeleteWorkerExtraPeriod?: (workerId: string, periodId: string) => void;
  onAddWorkerAbsence?: (workerId: string, absence: Omit<AbsenceRecord, 'id'>) => void;
  onDeleteWorkerAbsence?: (workerId: string, absenceId: string) => void;
  onAddWorkerNutritionPeriod?: (workerId: string, nutrition: Omit<NutritionPeriod, 'id'>) => void;
  onUpdateWorkerNutritionPeriod?: (workerId: string, nutritionId: string, updatedNutrition: Partial<Omit<NutritionPeriod, 'id'>>) => void;
  onDeleteWorkerNutritionPeriod?: (workerId: string, nutritionId: string) => void;
  onTransferWorkerToEmployee?: (worker: Worker) => void;
  onCopyLedgerEntry?: (sourceType: 'worker' | 'employee' | 'supplier', sourceId: string, entry: LedgerEntry, targetType: 'worker' | 'employee' | 'supplier', targetId: string) => void;
  onMoveLedgerEntry?: (sourceType: 'worker' | 'employee' | 'supplier', sourceId: string, entry: LedgerEntry, targetType: 'worker' | 'employee' | 'supplier', targetId: string) => void;
  setActiveTab?: (tab: string) => void;
  currency?: string;
  sharedRole?: 'owner' | 'read' | 'add' | 'full';
}

// Calculate accumulated days of work including extra periods
export const getWorkerTotalDays = (w: Worker, isOwner: boolean = true) => {
  const mainDays = calculateDaysOfWork(w.startDate, w.endDate, isOwner);
  const extraDays = (w.extraPeriods || []).reduce((sum, p) => sum + calculateDaysOfWork(p.startDate, p.endDate, isOwner), 0);
  return mainDays + extraDays;
};

// Calculate total deducted absence days
export const getWorkerAbsenceDays = (w: Worker): number => {
  return getAbsenceTotalDays(w.absences);
};

// Calculate net payable days of work after absence deduction
export const getWorkerNetDays = (w: Worker, isOwner: boolean = true): number => {
  return Math.max(0, getWorkerTotalDays(w, isOwner) - getWorkerAbsenceDays(w));
};

// Calculate actual accumulated days of work dynamically up to today (the phone's current date)
export const getWorkerActualDays = (w: Worker, isOwner: boolean = true) => {
  const mainActualDays = calculateActualDaysOfWork(w.startDate, w.endDate, isOwner);
  const extraActualDays = (w.extraPeriods || []).reduce((sum, p) => sum + calculateActualDaysOfWork(p.startDate, p.endDate, isOwner), 0);
  const absences = getWorkerAbsenceDays(w);
  return Math.max(0, mainActualDays + extraActualDays - absences);
};

export default function Workers({
  workers,
  employees = [],
  suppliers = [],
  onAddWorker,
  onDeleteWorker,
  onUpdateWorker,
  onAddWorkerLedgerEntry,
  onDeleteWorkerLedgerEntry,
  onUpdateWorkerLedgerEntry,
  onAddWorkerExtraPeriod,
  onDeleteWorkerExtraPeriod,
  onAddWorkerAbsence,
  onDeleteWorkerAbsence,
  onAddWorkerNutritionPeriod,
  onUpdateWorkerNutritionPeriod,
  onDeleteWorkerNutritionPeriod,
  onTransferWorkerToEmployee,
  onCopyLedgerEntry,
  onMoveLedgerEntry,
  setActiveTab,
  currency = 'YER',
  sharedRole = 'owner'
}: WorkersProps) {
  
  // Selection & Form states
  const [selectedWorkerId, setSelectedWorkerId] = useState<string | null>(null);
  const [isWorkersCustomReportModalOpen, setIsWorkersCustomReportModalOpen] = useState(false);

  // Edit states
  const [editingWorker, setEditingWorker] = useState<Worker | null>(null);
  const [editingWorkerLedger, setEditingWorkerLedger] = useState<{ workerId: string; entry: LedgerEntry } | null>(null);

  // Copy / Move Ledger Entry modal state
  const [copyMoveModalState, setCopyMoveModalState] = useState<{
    isOpen: boolean;
    mode: 'copy' | 'move';
    entry: LedgerEntry | null;
    workerId: string;
    workerName: string;
  }>({
    isOpen: false,
    mode: 'copy',
    entry: null,
    workerId: '',
    workerName: ''
  });

  // Excel File upload/import handler for active worker's ledger
  const handleWorkerLedgerExcelImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !selectedWorkerId) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const data = event.target?.result;
        const workbook = XLSX.read(data, { type: 'binary' });
        const sheetName = workbook.SheetNames[0];
        const sheet = workbook.Sheets[sheetName];
        const rows = XLSX.utils.sheet_to_json<any>(sheet);

        let count = 0;
        rows.forEach((row: any) => {
          const dateVal = row['التاريخ'] || row['تاريخ'] || row['Date'] || row['date'];
          const desc = row['البيان'] || row['التفاصيل'] || row['Description'] || row['description'] || row['Details'] || row['details'] || row['البيان/العمليات'];
          const onHim = parseFloat(row['مبلغ عليه (سلف)'] || row['مبلغ عليه'] || row['سلف'] || row['عليه'] || row['دفعة'] || row['On Him'] || row['Debit'] || row['on_him'] || row['debit']) || 0;
          const forHim = parseFloat(row['مبلغ له (أجور/مكافآت)'] || row['مبلغ له'] || row['أجر'] || row['مستحقات'] || row['له'] || row['For Him'] || row['Credit'] || row['for_him'] || row['credit']) || 0;
          const notes = row['ملاحظات'] || row['الملاحظات'] || row['Notes'] || row['notes'] || '';
          const cur = row['العملة'] || row['currency'] || row['Currency'] || ledgerCurrency || currency || 'YER';

          if (dateVal && desc && (onHim > 0 || forHim > 0)) {
            const parseDate = (d: any) => {
              if (!d) return new Date().toISOString().split('T')[0];
              if (typeof d === 'number') {
                const dateObj = new Date((d - 25569) * 86400 * 1000);
                return dateObj.toISOString().split('T')[0];
              }
              const stringDate = String(d).trim();
              const parsed = Date.parse(stringDate);
              if (!isNaN(parsed)) {
                return new Date(parsed).toISOString().split('T')[0];
              }
              return stringDate;
            };

            onAddWorkerLedgerEntry(selectedWorkerId, {
              date: parseDate(dateVal),
              amountOnHim: onHim,
              amountForHim: forHim,
              description: String(desc).trim(),
              notes: String(notes).trim(),
              currency: String(cur).trim()
            });
            count++;
          }
        });

        alert(`تم استيراد ${count} حركة بنجاح من ملف Excel!`);
      } catch (err) {
        console.error("Error reading Excel for worker ledger:", err);
        alert('حدث خطأ أثناء قراءة ملف Excel. يرجى التأكد من أن الأعمدة مطابقة (التاريخ، البيان، مبلغ عليه، مبلغ له).');
      }
    };
    reader.readAsBinaryString(file);
    e.target.value = '';
  };

  // Submit handler for editing worker
  const handleEditWorkerSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingWorker) return;
    const rawPhones = editingWorker.phoneNumbers || [];
    if (rawPhones.some(p => p.trim().length > 0 && p.trim().length < 9)) {
      alert('رقم الهاتف يجب أن يتكون من 9 أرقام (مثال: 771234567)');
      return;
    }
    const cleanPhones = rawPhones.map(p => p.trim()).filter(p => p.length === 9);

    if (onUpdateWorker) {
      onUpdateWorker(editingWorker.id, {
        name: editingWorker.name,
        profession: editingWorker.profession,
        startDate: editingWorker.startDate,
        endDate: editingWorker.endDate || '',
        phoneNumbers: cleanPhones,
        notes: editingWorker.notes || '',
        extraPeriods: editingWorker.extraPeriods,
        nutritionPeriods: editingWorker.nutritionPeriods,
        absences: editingWorker.absences,
        dailyWage: editingWorker.dailyWage,
        dailyWageCurrency: editingWorker.dailyWageCurrency
      });
    }
    setEditingWorker(null);
  };

  // Submit handler for editing ledger entry
  const handleEditWorkerLedgerSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingWorkerLedger) return;
    if (onUpdateWorkerLedgerEntry) {
      onUpdateWorkerLedgerEntry(editingWorkerLedger.workerId, editingWorkerLedger.entry.id, {
        date: editingWorkerLedger.entry.date,
        amountOnHim: editingWorkerLedger.entry.amountOnHim,
        amountForHim: editingWorkerLedger.entry.amountForHim,
        description: editingWorkerLedger.entry.description,
        notes: editingWorkerLedger.entry.notes,
        currency: editingWorkerLedger.entry.currency || 'YER'
      });
    }
    setEditingWorkerLedger(null);
  };
  
  // Add Worker form
  const [showAddWorkerForm, setShowAddWorkerForm] = useState(false);
  const [newWorkerName, setNewWorkerName] = useState('');
  const [newWorkerProfession, setNewWorkerProfession] = useState('');
  const [newWorkerStartDate, setNewWorkerStartDate] = useState('');
  const [newWorkerEndDate, setNewWorkerEndDate] = useState('');
  const [newWorkerDailyWage, setNewWorkerDailyWage] = useState('');
  const [newWorkerPhoneNumbers, setNewWorkerPhoneNumbers] = useState<string[]>(['']);
  const [newWorkerNotes, setNewWorkerNotes] = useState('');

  // Extra Work Period form states
  const [showExtraForm, setShowExtraForm] = useState(false);
  const [extraStart, setExtraStart] = useState('');
  const [extraEnd, setExtraEnd] = useState('');
  const [extraFormError, setExtraFormError] = useState('');

  // Nutrition Period Modal & Form States
  const [showNutritionModal, setShowNutritionModal] = useState(false);
  const [editingNutritionPeriod, setEditingNutritionPeriod] = useState<NutritionPeriod | null>(null);
  const [nutrWorkerName, setNutrWorkerName] = useState('');
  const [nutrDailyAmount, setNutrDailyAmount] = useState('');
  const [nutrStartDate, setNutrStartDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [nutrEndDate, setNutrEndDate] = useState('');
  const [nutrNotes, setNutrNotes] = useState('');
  const [nutrFormError, setNutrFormError] = useState('');

  // Work Data and Status collapsible state (hidden by default, expands on click)
  const [showWorkDataSection, setShowWorkDataSection] = useState(false);

  // Nutrition Card collapsible state (hidden by default)
  const [showNutritionSection, setShowNutritionSection] = useState(false);

  // Absence / Leave management states
  const [showAbsenceSection, setShowAbsenceSection] = useState(false);
  const [showAddAbsenceForm, setShowAddAbsenceForm] = useState(false);
  const [absenceDate, setAbsenceDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [absenceType, setAbsenceType] = useState<'full' | 'half'>('full');
  const [absenceReason, setAbsenceReason] = useState('إجازة اعتيادية');
  const [absenceNotes, setAbsenceNotes] = useState('');
  const [absenceError, setAbsenceError] = useState('');

  // Quick Daily Wage modal state
  const [showQuickWageModal, setShowQuickWageModal] = useState(false);
  const [quickDailyWage, setQuickDailyWage] = useState('');

  // Lock background scrolling when any modal in Workers is open
  useBodyScrollLock(Boolean(editingWorker || editingWorkerLedger || showNutritionModal || showQuickWageModal));

  // Add Worker Ledger Entry form
  const [ledgerDate, setLedgerDate] = useState(() => {
    const today = new Date();
    return today.toISOString().split('T')[0];
  });
  const [ledgerAmountOnHim, setLedgerAmountOnHim] = useState(''); // عليه
  const [ledgerAmountForHim, setLedgerAmountForHim] = useState(''); // له
  const [ledgerDescription, setLedgerDescription] = useState('');
  const [ledgerNotes, setLedgerNotes] = useState('');
  const [ledgerCurrency, setLedgerCurrency] = useState(currency);
  const [showAddLedgerForm, setShowAddLedgerForm] = useState(false);

  // Search filter & sort filters
  const [searchQuery, setSearchQuery] = useState('');
  const [workerSortOrder, setWorkerSortOrder] = useState<'asc' | 'desc'>('desc'); // Default desc: newest first
  
  // Ledger filters state
  const [isLedgerFiltersOpen, setIsLedgerFiltersOpen] = useState(false);
  const [ledgerSearchTerm, setLedgerSearchTerm] = useState('');
  const [ledgerStartDate, setLedgerStartDate] = useState('');
  const [ledgerEndDate, setLedgerEndDate] = useState('');
  const [ledgerTypeFilter, setLedgerTypeFilter] = useState<'all' | 'onHim' | 'forHim'>('all');
  const [ledgerSortOption, setLedgerSortOption] = useState<'date-desc' | 'date-asc' | 'desc-alpha' | 'amountOnHim-desc' | 'amountForHim-desc'>('date-desc');

  // Error/Success alerts
  const [workerError, setWorkerError] = useState('');
  const [ledgerError, setLedgerError] = useState('');

  // Keep ledger currency in sync with global currency selection when prop changes
  useEffect(() => {
    setLedgerCurrency(currency);
  }, [currency]);

  // Find active worker details
  const activeWorker = workers.find(w => w.id === selectedWorkerId);

  // Nutrition Period Modal Handlers
  const handleOpenAddNutritionModal = () => {
    setEditingNutritionPeriod(null);
    setNutrWorkerName(activeWorker?.name || '');
    setNutrDailyAmount('');
    setNutrStartDate(new Date().toISOString().split('T')[0]);
    setNutrEndDate('');
    setNutrNotes('');
    setNutrFormError('');
    setShowNutritionModal(true);
  };

  const handleOpenEditNutritionModal = (period: NutritionPeriod) => {
    setEditingNutritionPeriod(period);
    setNutrWorkerName(period.workerName);
    setNutrDailyAmount(period.dailyAmount.toString());
    setNutrStartDate(period.startDate);
    setNutrEndDate(period.endDate || '');
    setNutrNotes(period.notes || '');
    setNutrFormError('');
    setShowNutritionModal(true);
  };

  const handleNutritionSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setNutrFormError('');

    if (!nutrWorkerName.trim()) {
      setNutrFormError('الرجاء إدخال اسم العامل / المساعد.');
      return;
    }
    const dailyAmt = parseFloat(nutrDailyAmount);
    if (isNaN(dailyAmt) || dailyAmt <= 0) {
      setNutrFormError('الرجاء إدخال مبلغ تغذية يومي صحيح وأكبر من صفر.');
      return;
    }
    if (!nutrStartDate) {
      setNutrFormError('الرجاء اختيار تاريخ البدء.');
      return;
    }
    if (nutrEndDate && new Date(nutrStartDate) > new Date(nutrEndDate)) {
      setNutrFormError('تاريخ البدء يجب أن يكون قبل أو يساوي تاريخ الانتهاء.');
      return;
    }

    if (activeWorker) {
      if (editingNutritionPeriod) {
        onUpdateWorkerNutritionPeriod?.(activeWorker.id, editingNutritionPeriod.id, {
          workerName: nutrWorkerName.trim(),
          dailyAmount: dailyAmt,
          startDate: nutrStartDate,
          endDate: nutrEndDate || undefined,
          notes: nutrNotes.trim()
        });
      } else {
        onAddWorkerNutritionPeriod?.(activeWorker.id, {
          workerName: nutrWorkerName.trim(),
          dailyAmount: dailyAmt,
          startDate: nutrStartDate,
          endDate: nutrEndDate || undefined,
          notes: nutrNotes.trim()
        });
      }
    }

    setShowNutritionModal(false);
  };

  // Absence submission & deletion handlers
  const handleAddAbsenceSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeWorker) return;
    if (!absenceDate) {
      setAbsenceError('يرجى تحديد تاريخ يوم الغياب/الإجازة');
      return;
    }
    const existing = (activeWorker.absences || []).find(a => a.date === absenceDate);
    if (existing) {
      if (!confirm(`يوجد بالفعل سجل غياب مسجل لهذا العامل بتاريخ (${absenceDate}). هل ترغب بتسجيله على أي حال؟`)) {
        return;
      }
    }
    onAddWorkerAbsence?.(activeWorker.id, {
      date: absenceDate,
      type: absenceType,
      reason: absenceReason.trim() || (absenceType === 'full' ? 'غياب يوم كامل' : 'غياب نصف يوم'),
      notes: absenceNotes.trim()
    });
    setShowAddAbsenceForm(false);
    setAbsenceReason('إجازة اعتيادية');
    setAbsenceNotes('');
    setAbsenceError('');
  };

  const handleDeleteAbsence = (absenceId: string) => {
    if (!activeWorker) return;
    if (confirm('هل أنت متأكد من حذف هذا السجل وإلغاء الخصم واستعادة اليوم لحساب العامل؟')) {
      onDeleteWorkerAbsence?.(activeWorker.id, absenceId);
    }
  };

  // Quick Daily Wage save handler
  const handleQuickWageSave = () => {
    if (!activeWorker || !onUpdateWorker) return;
    const wageNum = parseFloat(quickDailyWage) || 0;
    onUpdateWorker(activeWorker.id, {
      name: activeWorker.name,
      profession: activeWorker.profession,
      startDate: activeWorker.startDate,
      endDate: activeWorker.endDate,
      phoneNumbers: activeWorker.phoneNumbers,
      notes: activeWorker.notes,
      extraPeriods: activeWorker.extraPeriods,
      nutritionPeriods: activeWorker.nutritionPeriods,
      absences: activeWorker.absences,
      dailyWage: wageNum,
      dailyWageCurrency: activeWorker.dailyWageCurrency || currency || 'YER'
    });
    setShowQuickWageModal(false);
  };

  // Form submit for new worker
  const handleAddWorkerSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setWorkerError('');

    if (!newWorkerName.trim()) {
      setWorkerError('الرجاء إدخال اسم العامل.');
      return;
    }
    if (!newWorkerProfession.trim()) {
      setWorkerError('الرجاء إدخال مهنة العامل.');
      return;
    }
    if (!newWorkerStartDate) {
      setWorkerError('الرجاء اختيار تاريخ البدء.');
      return;
    }
    if (newWorkerEndDate && new Date(newWorkerStartDate) > new Date(newWorkerEndDate)) {
      setWorkerError('تاريخ البدء يجب أن يكون قبل أو يساوي تاريخ الانتهاء.');
      return;
    }

    if (newWorkerPhoneNumbers.some(p => p.trim().length > 0 && p.trim().length < 9)) {
      setWorkerError('رقم الهاتف يجب أن يتكون من 9 أرقام (مثال: 771234567).');
      return;
    }

    const validPhones = newWorkerPhoneNumbers.map(p => p.trim()).filter(p => p.length === 9);

    onAddWorker({
      name: newWorkerName.trim(),
      profession: newWorkerProfession.trim(),
      startDate: newWorkerStartDate,
      endDate: newWorkerEndDate || '',
      phoneNumbers: validPhones,
      notes: newWorkerNotes.trim(),
      dailyWage: parseFloat(newWorkerDailyWage) || 0,
      dailyWageCurrency: currency
    });

    // Reset Form
    setNewWorkerName('');
    setNewWorkerProfession('');
    setNewWorkerStartDate('');
    setNewWorkerEndDate('');
    setNewWorkerDailyWage('');
    setNewWorkerPhoneNumbers(['']);
    setNewWorkerNotes('');
    setShowAddWorkerForm(false);
  };

  const handleResetAddWorkerForm = () => {
    setNewWorkerName('');
    setNewWorkerProfession('');
    setNewWorkerStartDate('');
    setNewWorkerEndDate('');
    setNewWorkerDailyWage('');
    setNewWorkerPhoneNumbers(['']);
    setNewWorkerNotes('');
    setWorkerError('');
  };

  const handleResetAddLedgerForm = () => {
    setLedgerDate(new Date().toISOString().split('T')[0]);
    setLedgerAmountOnHim('');
    setLedgerAmountForHim('');
    setLedgerDescription('');
    setLedgerNotes('');
    setLedgerCurrency(currency);
    setLedgerError('');
  };

  // Submit Handler for Extra Period
  const handleExtraPeriodSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setExtraFormError('');

    if (!extraStart || !extraEnd) {
      setExtraFormError('الرجاء إدخال تاريخ البدء والانتهاء.');
      return;
    }
    if (new Date(extraStart) > new Date(extraEnd)) {
      setExtraFormError('تاريخ البدء يجب أن يكون قبل أو يساوي تاريخ الانتهاء.');
      return;
    }

    if (selectedWorkerId && onAddWorkerExtraPeriod) {
      onAddWorkerExtraPeriod(selectedWorkerId, extraStart, extraEnd);
      setExtraStart('');
      setExtraEnd('');
      setShowExtraForm(false);
    }
  };

  // Excel File upload/import handler
  const handleExcelImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const data = event.target?.result;
        const workbook = XLSX.read(data, { type: 'binary' });
        const sheetName = workbook.SheetNames[0];
        const sheet = workbook.Sheets[sheetName];
        const rows = XLSX.utils.sheet_to_json<any>(sheet);

        let count = 0;
        rows.forEach((row: any) => {
          // Map properties (support both Arabic and English names)
          const name = row['اسم العامل'] || row['اسم العامل / المقاول'] || row['الاسم'] || row['الاسم الكامل'] || row['Name'] || row['name'];
          const profession = row['المهنة'] || row['الوظيفة'] || row['Profession'] || row['profession'] || row['Job'] || row['job'] || 'عامل';
          let startDate = row['تاريخ البدء'] || row['تاريخ مباشرة العمل'] || row['Start Date'] || row['start_date'] || row['Start'] || row['start'];
          let endDate = row['تاريخ الانتهاء'] || row['End Date'] || row['end_date'] || row['End'] || row['end'] || '';
          const phoneRaw = row['رقم الهاتف'] || row['الهاتف'] || row['رقم الجوال'] || row['الجوال'] || row['Phone'] || row['phone'] || '';

          const phoneNumbers: string[] = [];
          if (phoneRaw) {
            String(phoneRaw).split(/[,;/\n]+/).forEach(p => {
              const digits = p.replace(/\D/g, '').slice(0, 9);
              if (digits.length === 9) phoneNumbers.push(digits);
            });
          }

          if (name && startDate) {
            const parseDate = (d: any) => {
              if (!d) return '';
              if (typeof d === 'number') {
                const dateObj = new Date((d - 25569) * 86400 * 1000);
                return dateObj.toISOString().split('T')[0];
              }
              const stringDate = String(d).trim();
              const parsed = Date.parse(stringDate);
              if (!isNaN(parsed)) {
                return new Date(parsed).toISOString().split('T')[0];
              }
              return stringDate;
            };

            onAddWorker({
              name: String(name).trim(),
              profession: String(profession).trim(),
              startDate: parseDate(startDate),
              endDate: parseDate(endDate),
              phoneNumbers
            });
            count++;
          }
        });

        alert(`تم استيراد ${count} عامل بنجاح من ملف Excel!`);
      } catch (err) {
        console.error("Error reading Excel:", err);
        alert('حدث خطأ أثناء قراءة ملف Excel. يرجى التأكد من أن الأعمدة مطابقة (الاسم، المهنة، تاريخ البدء، تاريخ الانتهاء).');
      }
    };
    reader.readAsBinaryString(file);
    e.target.value = '';
  };

  // Form submit for worker ledger entry
  const handleAddLedgerSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLedgerError('');

    const onHim = parseFloat(ledgerAmountOnHim) || 0;
    const forHim = parseFloat(ledgerAmountForHim) || 0;

    if (onHim === 0 && forHim === 0) {
      setLedgerError('يجب إدخال قيمة في حقل "مبلغ عليه" أو "مبلغ له".');
      return;
    }
    if (onHim < 0 || forHim < 0) {
      setLedgerError('المبالغ يجب أن تكون قيم موجبة.');
      return;
    }
    if (!ledgerDescription.trim()) {
      setLedgerError('الرجاء إدخال البيان للتسجيل.');
      return;
    }

    if (selectedWorkerId) {
      onAddWorkerLedgerEntry(selectedWorkerId, {
        date: ledgerDate,
        amountOnHim: onHim,
        amountForHim: forHim,
        description: ledgerDescription.trim(),
        notes: ledgerNotes.trim(),
        currency: ledgerCurrency
      });

      // Reset Form fields
      setLedgerAmountOnHim('');
      setLedgerAmountForHim('');
      setLedgerDescription('');
      setLedgerNotes('');
    }
  };

  // Export Workers Directory & Detailed Ledgers to Multi-sheet Excel
  const handleExportAllCSV = () => {
    // Sheet 1: Summary of workers
    const summaryHeaders = [
      'الرقم التعريفي',
      'اسم العامل / المقاول',
      'المهنة / التخصص',
      'رقم الهاتف',
      'تاريخ البدء',
      'تاريخ الانتهاء',
      'إجمالي فترات العمل (أيام)',
      'أيام الغياب المخصومة',
      'صافي أيام العمل المستحقة',
      'الأجر اليومي',
      'إجمالي له (أجور ومكافآت)',
      'إجمالي عليه (سلف ومسحوبات)',
      'صافي الرصيد',
      'الوضع المالي'
    ];

    const summaryRows = workers.map(w => {
      const grossDays = getWorkerTotalDays(w, sharedRole === 'owner');
      const absDays = getWorkerAbsenceDays(w);
      const netDays = getWorkerNetDays(w, sharedRole === 'owner');
      const totalOnHim = w.ledger.reduce((sum, e) => sum + e.amountOnHim, 0);
      const totalForHim = w.ledger.reduce((sum, e) => sum + e.amountForHim, 0);
      const net = totalForHim - totalOnHim;
      const netText = net === 0 ? 'خالص' : net > 0 ? `له: ${net}` : `عليه: ${Math.abs(net)}`;

      return [
        w.id,
        w.name,
        w.profession,
        w.phoneNumbers && w.phoneNumbers.length > 0 ? w.phoneNumbers.join(' - ') : '-',
        w.startDate,
        w.endDate || '',
        grossDays,
        absDays,
        netDays,
        w.dailyWage || 0,
        totalForHim,
        totalOnHim,
        net,
        netText
      ];
    });

    // Sheet 2: Detailed ledger entries for ALL workers
    const ledgerHeaders = [
      'اسم العامل',
      'المهنة',
      'تاريخ الحركة',
      'البيان / الوصف التفصيلي',
      'مبلغ له (أجور ومكافآت)',
      'مبلغ عليه (سلف ومسحوبات)',
      'العملة',
      'الملاحظات',
      'بواسطة'
    ];

    const ledgerRows: (string | number)[][] = [];
    workers.forEach(w => {
      w.ledger.forEach(entry => {
        ledgerRows.push([
          w.name,
          w.profession,
          entry.date,
          entry.description,
          entry.amountForHim || 0,
          entry.amountOnHim || 0,
          entry.currency || currency,
          entry.notes || '-',
          (entry.createdBy && !isOwnerUser(entry.createdBy)) ? entry.createdBy : '-'
        ]);
      });
    });
    ledgerRows.sort((a, b) => (b[2] as string).localeCompare(a[2] as string));

    exportMultiSheetXLSX(`تقرير_العمال_التفصيلي_الشامل_${new Date().toISOString().split('T')[0]}`, [
      { sheetName: 'سجل العمال العام', headers: summaryHeaders, rows: summaryRows },
      { sheetName: 'تفاصيل حركات كشف العمال', headers: ledgerHeaders, rows: ledgerRows }
    ]);
  };

  // Export Active Worker's Ledger to Excel (native numbers and dates)
  const handleExportWorkerLedgerExcel = (worker: Worker) => {
    const headers = [
      'التاريخ',
      'البيان',
      'مبلغ عليه (سلف)',
      'مبلغ له (أجور/مكافآت)',
      'العملة',
      'ملاحظات'
    ];

    const sortedLedger = [...worker.ledger].sort((a, b) => b.date.localeCompare(a.date));
    const rows = sortedLedger.map(e => [
      e.date,
      e.description,
      e.amountOnHim,
      e.amountForHim,
      e.currency || ledgerCurrency || currency || 'YER',
      e.notes || ''
    ]);

    exportToXLSX(`كشف_حساب_العامل_${worker.name.replace(/\s+/g, '_')}`, headers, rows, 'كشف الحساب');
  };

  // Export Active Worker's Ledger to CSV
  const handleExportLedgerCSV = (worker: Worker) => {
    const headers = [
      'التاريخ',
      'البيان',
      'مبلغ عليه (سلف)',
      'مبلغ له (أجور/مكافآت)',
      'ملاحظات'
    ];

    const sortedLedger = [...worker.ledger].sort((a, b) => b.date.localeCompare(a.date));
    const rows = sortedLedger.map(e => [
      e.date,
      e.description,
      e.amountOnHim.toString(),
      e.amountForHim.toString(),
      e.notes
    ]);

    exportToCSV(`كشف_حساب_العامل_${worker.name.replace(/\s+/g, '_')}`, headers, rows);
  };

  // Build Active Worker's Ledger HTML (Detailed vs Summary)
  const buildWorkerLedgerReportHtml = (worker: Worker, isDetailed: boolean = true): { title: string; htmlContent: string } => {
    const days = getWorkerTotalDays(worker, sharedRole === 'owner');
    const totalOnHim = worker.ledger.reduce((sum, e) => sum + e.amountOnHim, 0);
    const totalForHim = worker.ledger.reduce((sum, e) => sum + e.amountForHim, 0);
    const net = totalForHim - totalOnHim;

    let ledgerRowsHtml = '';
    const sortedLedgerForPrint = [...worker.ledger].sort((a, b) => b.date.localeCompare(a.date));
    sortedLedgerForPrint.forEach((e, idx) => {
      ledgerRowsHtml += `
        <tr style="background-color: ${idx % 2 === 0 ? '#ffffff' : '#f8fafc'};">
          <td style="padding: 8px; border: 1px solid #e2e8f0; font-family: monospace; width: 14%;">${formatDateArabic(e.date)}</td>
          <td style="padding: 8px; border: 1px solid #e2e8f0; font-weight: bold; width: 38%;" class="col-statement">${e.description}</td>
          <td style="padding: 8px; border: 1px solid #e2e8f0; text-align: center; color: #dc2626; font-weight: bold; width: 17%;">${e.amountOnHim > 0 ? formatCurrency(e.amountOnHim, currency) : '-'}</td>
          <td style="padding: 8px; border: 1px solid #e2e8f0; text-align: center; color: #16a34a; font-weight: bold; width: 17%;">${e.amountForHim > 0 ? formatCurrency(e.amountForHim, currency) : '-'}</td>
          <td style="padding: 8px; border: 1px solid #e2e8f0; font-size: 9.5px; color: #64748b; line-height: 1.35; width: 14%;" class="col-notes">${e.notes || '-'}</td>
        </tr>
      `;
    });

    let extraPeriodsHtml = '';
    if (worker.extraPeriods && worker.extraPeriods.length > 0) {
      extraPeriodsHtml += `
        <div style="grid-column: span 3; margin-top: 8px; border-top: 1px dashed #cbd5e1; padding-top: 8px;">
          <span style="font-weight: bold; font-size: 11px; color: #475569; display: block; margin-bottom: 4px;">فترات العمل الإضافية المضافة:</span>
          <div style="display: flex; flex-direction: column; gap: 4px;">
      `;
      worker.extraPeriods.forEach((p, idx) => {
        const pDays = calculateDaysOfWork(p.startDate, p.endDate);
        extraPeriodsHtml += `
          <div style="font-size: 11px; color: #475569;">
            • فترة ${idx + 1}: من <strong>${formatDateArabic(p.startDate)}</strong> إلى <strong>${formatDateArabic(p.endDate)}</strong> (${pDays} يوم عمل)
          </div>
        `;
      });
      extraPeriodsHtml += `
          </div>
        </div>
      `;
    }

    const metricCardsHtml = generateMetricCardsGrid([
      {
        title: 'إجمالي الأجور المستحقة (له)',
        value: formatCurrency(totalForHim, currency),
        badge: 'استحقاقات عمل',
        bgColor: '#f0fdf4',
        borderColor: '#bbf7d0',
        textColor: '#15803d'
      },
      {
        title: 'إجمالي السلف والمدفوعات (عليه)',
        value: formatCurrency(totalOnHim, currency),
        badge: 'مسحوبات وسلف',
        bgColor: '#fef2f2',
        borderColor: '#fecaca',
        textColor: '#b91c1c'
      },
      {
        title: 'صافي الرصيد المستحق',
        value: formatCurrency(Math.abs(net), currency),
        badge: net >= 0 ? 'مستحق للعامل' : 'سلفة زائدة',
        bgColor: net >= 0 ? '#f0fdf4' : '#fffbeb',
        borderColor: net >= 0 ? '#bbf7d0' : '#fde68a',
        textColor: net >= 0 ? '#15803d' : '#b45309'
      }
    ], 3);

    const balanceGaugeHtml = generateSvgBalanceComparison({
      forHim: totalForHim,
      onHim: totalOnHim,
      forHimLabel: 'المستحق له (أجور)',
      onHimLabel: 'المسدد عليه (سلف)',
      forHimFormatted: formatCurrency(totalForHim, currency),
      onHimFormatted: formatCurrency(totalOnHim, currency),
      netFormatted: net >= 0 ? `له (${formatCurrency(net, currency)})` : `عليه (${formatCurrency(Math.abs(net), currency)})`,
      isPositive: net >= 0
    });

    const htmlContent = `
      <div style="direction: rtl; font-family: sans-serif; padding: 15px;">
        
        <!-- Header -->
        <div style="border-bottom: 2px solid #0284c7; padding-bottom: 12px; margin-bottom: 16px; display: flex; justify-content: space-between; align-items: center;">
          <div>
            <h1 style="margin: 0; color: #0f172a; font-size: 19px;">📋 ${isDetailed ? 'كشف حساب مستحقات العامل التفصيلي' : 'الملخص التنفيذي لحساب العامل'}</h1>
            <p style="margin: 4px 0 0 0; color: #64748b; font-size: 12px;">ورلد أوف إيليتس للتجارة والمقاولات</p>
          </div>
          <div style="text-align: left; font-size: 11.5px; color: #64748b;">
            تاريخ الطباعة: ${new Date().toLocaleDateString('ar-EG-u-nu-latn')}
          </div>
        </div>

        <!-- Worker Info -->
        <div style="background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 12px 16px; margin-bottom: 16px;">
          <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; font-size: 12px;">
            <div><strong>اسم العامل:</strong> ${worker.name}</div>
            <div><strong>المهنة / الصفة:</strong> ${worker.profession}</div>
            <div><strong>تاريخ البدء:</strong> ${formatDateArabic(worker.startDate)}</div>
            <div><strong>تاريخ الانتهاء:</strong> ${worker.endDate ? formatDateArabic(worker.endDate) : 'مستمر'}</div>
            <div><strong>صافي أيام العمل:</strong> ${getWorkerNetDays(worker, sharedRole === 'owner')} يوم ${getWorkerAbsenceDays(worker) > 0 ? `<span style="color: #dc2626;">(مخصوم ${getWorkerAbsenceDays(worker)} غياب)</span>` : ''}</div>
            ${worker.dailyWage && worker.dailyWage > 0 ? `<div><strong>الأجر اليومي:</strong> ${formatCurrency(worker.dailyWage, worker.dailyWageCurrency || currency)}</div>` : ''}
            ${extraPeriodsHtml}
          </div>
        </div>

        <!-- Analytics Visuals -->
        <div style="margin-bottom: 16px; page-break-inside: avoid;">
          ${metricCardsHtml}
          ${balanceGaugeHtml}
        </div>

        ${isDetailed ? `
        <!-- Detailed Table -->
        <table class="report-data-table" style="width: 100%; border-collapse: collapse; font-size: 11.5px; margin-bottom: 20px;">
          <thead>
            <tr style="background-color: #0284c7; color: white;">
              <th style="padding: 8px; border: 1px solid #cbd5e1; text-align: right; width: 14%;">التاريخ</th>
              <th style="padding: 8px; border: 1px solid #cbd5e1; text-align: right; width: 38%;" class="col-statement">البيان التفصيلي</th>
              <th style="padding: 8px; border: 1px solid #cbd5e1; text-align: center; width: 17%;">المبلغ عليه (سلف)</th>
              <th style="padding: 8px; border: 1px solid #cbd5e1; text-align: center; width: 17%;">المبلغ له (أجور)</th>
              <th style="padding: 8px; border: 1px solid #cbd5e1; text-align: right; width: 14%;" class="col-notes">ملاحظات</th>
            </tr>
          </thead>
          <tbody>
            ${worker.ledger.length === 0 ? '<tr><td colspan="5" style="text-align: center; color: #94a3b8; padding: 12px;">لا توجد معاملات مسجلة في هذا الحساب حالياً.</td></tr>' : ledgerRowsHtml}
          </tbody>
        </table>
        ` : ''}

        <!-- Summary Footer -->
        <div style="background-color: #f1f5f9; border-radius: 8px; padding: 12px; font-size: 12px; border: 1px solid #cbd5e1; display: flex; justify-content: space-between; align-items: center;">
          <div>إجمالي السلف: <strong style="color: #dc2626;">${formatCurrency(totalOnHim, currency)}</strong></div>
          <div>إجمالي الأجور: <strong style="color: #16a34a;">${formatCurrency(totalForHim, currency)}</strong></div>
          <div>صافي الرصيد: <strong style="color: ${net >= 0 ? '#15803d' : '#b91c1c'}; font-size: 14px;">${net >= 0 ? `له (${formatCurrency(net, currency)})` : `عليه (${formatCurrency(Math.abs(net), currency)})`}</strong></div>
        </div>
      </div>
    `;

    return {
      title: `كشف حساب العامل ${worker.name}`,
      htmlContent
    };
  };

  const handlePrintWorkerPDF = (worker: Worker, isDetailed: boolean = true) => {
    const { title, htmlContent } = buildWorkerLedgerReportHtml(worker, isDetailed);
    printPDF(title, htmlContent);
  };

  const handleShareWorkerPDF = async (format: 'detailed' | 'summary', method: 'whatsapp' | 'system') => {
    if (!activeWorker) return;
    const { title, htmlContent } = buildWorkerLedgerReportHtml(activeWorker, format === 'detailed');
    await directShareReportPDF({ title, htmlContent, target: method });
  };

  // Build Overall Workers Directory Report HTML (Summary or Detailed)
  const buildAllWorkersReportHtml = (reportType: ReportFormatType = 'detailed'): { title: string; htmlContent: string } => {
    let grandOnHim = 0;
    let grandForHim = 0;
    const professionCounts: Record<string, { count: number; totalWages: number }> = {};

    let workerSummaryRowsHtml = '';
    let workersDetailedLedgersHtml = '';

    workers.forEach(w => {
      const days = getWorkerTotalDays(w, sharedRole === 'owner');
      const totalOnHim = w.ledger.reduce((sum, e) => sum + e.amountOnHim, 0);
      const totalForHim = w.ledger.reduce((sum, e) => sum + e.amountForHim, 0);
      const net = totalForHim - totalOnHim;

      grandOnHim += totalOnHim;
      grandForHim += totalForHim;

      const prof = w.profession?.trim() || 'عامل';
      if (!professionCounts[prof]) {
        professionCounts[prof] = { count: 0, totalWages: 0 };
      }
      professionCounts[prof].count += 1;
      professionCounts[prof].totalWages += totalForHim;

      const grossDays = getWorkerTotalDays(w, sharedRole === 'owner');
      const absDays = getWorkerAbsenceDays(w);
      const netDays = getWorkerNetDays(w, sharedRole === 'owner');

      // 1. Summary row
      workerSummaryRowsHtml += `
        <tr>
          <td style="padding: 7px 8px; border: 1px solid #cbd5e1; font-weight: bold;">${w.name}</td>
          <td style="padding: 7px 8px; border: 1px solid #cbd5e1;">${w.profession}</td>
          <td style="padding: 7px 8px; border: 1px solid #cbd5e1; font-size: 11px;">${formatDateArabic(w.startDate)} إلى ${w.endDate ? formatDateArabic(w.endDate) : 'مستمر'}</td>
          <td style="padding: 7px 8px; border: 1px solid #cbd5e1; text-align: center; font-weight: bold;">
            ${netDays} يوم ${absDays > 0 ? `<br><span style="font-size: 9.5px; color: #dc2626;">(خصم ${absDays} غياب)</span>` : ''}
          </td>
          <td style="padding: 7px 8px; border: 1px solid #cbd5e1; color: #dc2626; font-family: monospace; text-align: center;">${formatCurrency(totalOnHim, currency)}</td>
          <td style="padding: 7px 8px; border: 1px solid #cbd5e1; color: #16a34a; font-family: monospace; text-align: center;">${formatCurrency(totalForHim, currency)}</td>
          <td style="padding: 7px 8px; border: 1px solid #cbd5e1; font-weight: bold; color: ${net >= 0 ? '#15803d' : '#b91c1c'}; font-family: monospace; text-align: center;">
            ${net === 0 ? 'خالص' : net > 0 ? `له (${formatCurrency(net, currency)})` : `عليه (${formatCurrency(Math.abs(net), currency)})`}
          </td>
        </tr>
      `;

      // 2. Detailed ledger table for this worker
      let ledgerRowsHtml = '';
      w.ledger.forEach(e => {
        ledgerRowsHtml += `
          <tr>
            <td style="padding: 6px 8px; border: 1px solid #cbd5e1; font-family: monospace; width: 14%;">${formatDateArabic(e.date)}</td>
            <td style="padding: 6px 8px; border: 1px solid #cbd5e1; font-weight: bold; width: 38%;" class="col-statement">${e.description}</td>
            <td style="padding: 6px 8px; border: 1px solid #cbd5e1; color: #dc2626; font-family: monospace; text-align: center; width: 17%;">${e.amountOnHim > 0 ? formatCurrency(e.amountOnHim, currency) : '-'}</td>
            <td style="padding: 6px 8px; border: 1px solid #cbd5e1; color: #16a34a; font-family: monospace; text-align: center; width: 17%;">${e.amountForHim > 0 ? formatCurrency(e.amountForHim, currency) : '-'}</td>
            <td style="padding: 6px 8px; border: 1px solid #cbd5e1; font-size: 9.5px; color: #64748b; line-height: 1.35; width: 14%;" class="col-notes">${e.notes || '-'}</td>
          </tr>
        `;
      });

      workersDetailedLedgersHtml += `
        <div style="margin-top: 14px; margin-bottom: 18px; border: 1px solid #cbd5e1; border-radius: 8px; overflow: hidden; break-inside: auto;">
          <div style="background-color: #0f172a; color: #ffffff; padding: 8px 12px; display: flex; justify-content: space-between; align-items: center; break-after: avoid; page-break-after: avoid;">
            <div>
              <span style="font-weight: bold; font-size: 13.5px;">👷 العامل: ${w.name}</span>
              <span style="font-size: 11.5px; color: #94a3b8; margin-right: 8px;">(${w.profession} - ${days} يوم عمل)</span>
            </div>
            <div style="font-size: 11.5px; font-weight: bold;">
              <span style="color: #f87171; margin-left: 8px;">عليه: ${formatCurrency(totalOnHim, currency)}</span> | 
              <span style="color: #4ade80; margin-left: 8px;">له: ${formatCurrency(totalForHim, currency)}</span> | 
              <span style="color: #60a5fa;">الصافي: ${net >= 0 ? formatCurrency(net, currency) : `-${formatCurrency(Math.abs(net), currency)}`}</span>
            </div>
          </div>
          <table class="report-data-table" style="margin: 0; width: 100%; border-collapse: collapse; font-size: 11.5px;">
            <thead>
              <tr style="background-color: #f1f5f9; color: #1e293b; break-inside: avoid; page-break-inside: avoid;">
                <th style="padding: 6px 8px; border: 1px solid #cbd5e1; width: 14%;">التاريخ</th>
                <th style="padding: 6px 8px; border: 1px solid #cbd5e1; width: 38%;" class="col-statement">البيان / الحركة</th>
                <th style="padding: 6px 8px; border: 1px solid #cbd5e1; width: 17%; text-align: center;">عليه (سلف)</th>
                <th style="padding: 6px 8px; border: 1px solid #cbd5e1; width: 17%; text-align: center;">له (أجور)</th>
                <th style="padding: 6px 8px; border: 1px solid #cbd5e1; width: 14%;" class="col-notes">ملاحظات</th>
              </tr>
            </thead>
            <tbody>
              ${w.ledger.length === 0 ? '<tr><td colspan="5" style="text-align: center; color: #94a3b8; padding: 10px;">لا توجد معاملات مسجلة لهذا العامل حالياً.</td></tr>' : ledgerRowsHtml}
            </tbody>
          </table>
        </div>
      `;
    });

    const grandNet = grandForHim - grandOnHim;

    // Profession Chart
    const profColors = ['#0284c7', '#059669', '#d97706', '#8b5cf6', '#6366f1', '#ec4899', '#14b8a6'];
    const sortedProfessions = Object.entries(professionCounts).sort((a, b) => b[1].count - a[1].count);
    const profChartData = sortedProfessions.map(([name, data], idx) => ({
      label: name,
      value: data.count,
      color: profColors[idx % profColors.length],
      formattedValue: `${data.count} عامل`,
      subText: data.totalWages > 0 ? formatCurrency(data.totalWages, currency) : undefined
    }));

    const profDonutChartHtml = generateSvgDonutChart({
      data: profChartData,
      size: 140,
      centerTitle: `${workers.length}`,
      centerSubtitle: 'إجمالي العمال',
      showLegend: true
    });

    const metricCardsHtml = generateMetricCardsGrid([
      {
        title: 'إجمالي عدد العمال المسجلين',
        value: `${workers.length} عامل`,
        badge: 'العمالة والمقاولين',
        bgColor: '#eff6ff',
        borderColor: '#bfdbfe',
        textColor: '#1d4ed8'
      },
      {
        title: 'إجمالي الأجور المستحقة (له)',
        value: formatCurrency(grandForHim, currency),
        badge: 'أجور مستحقة',
        bgColor: '#f0fdf4',
        borderColor: '#bbf7d0',
        textColor: '#15803d'
      },
      {
        title: 'إجمالي السلف والمدفوعات (عليه)',
        value: formatCurrency(grandOnHim, currency),
        badge: 'مسحوبات وسلف',
        bgColor: '#fef2f2',
        borderColor: '#fecaca',
        textColor: '#b91c1c'
      },
      {
        title: 'صافي الرصيد المستحق',
        value: formatCurrency(Math.abs(grandNet), currency),
        badge: grandNet >= 0 ? 'مستحق للعمال' : 'سلف مستردة',
        bgColor: grandNet >= 0 ? '#f0fdf4' : '#fffbeb',
        borderColor: grandNet >= 0 ? '#bbf7d0' : '#fde68a',
        textColor: grandNet >= 0 ? '#15803d' : '#b45309'
      }
    ], 4);

    const balanceComparisonHtml = generateSvgBalanceComparison({
      forHim: grandForHim,
      onHim: grandOnHim,
      forHimLabel: 'إجمالي أجور العمال (له)',
      onHimLabel: 'إجمالي السلف والمسحوبات (عليه)',
      forHimFormatted: formatCurrency(grandForHim, currency),
      onHimFormatted: formatCurrency(grandOnHim, currency),
      netFormatted: grandNet >= 0 ? `له (${formatCurrency(grandNet, currency)})` : `عليه (${formatCurrency(Math.abs(grandNet), currency)})`,
      isPositive: grandNet >= 0
    });

    const htmlContent = `
      <div style="direction: rtl; font-family: sans-serif; padding: 10px;">
        
        <!-- Header -->
        <div style="border-bottom: 2px solid #0284c7; padding-bottom: 12px; margin-bottom: 16px; display: flex; justify-content: space-between; align-items: center;">
          <div>
            <h1 style="margin: 0; color: #0f172a; font-size: 19px;">📊 التقرير الشامل لحسابات العمال والمقاولين</h1>
            <p style="margin: 4px 0 0 0; color: #64748b; font-size: 12px;">ورلد أوف إيليتس للتجارة والمقاولات</p>
          </div>
          <div style="text-align: left; font-size: 11.5px; color: #64748b;">
            تاريخ استخراج التقرير: ${new Date().toLocaleDateString('ar-EG-u-nu-latn')}
          </div>
        </div>

        <!-- 📊 PAGE 1: EXECUTIVE ANALYTICS DASHBOARD -->
        <div style="margin-bottom: 20px; page-break-inside: avoid;">
          
          <div style="background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%); color: #ffffff; padding: 10px 14px; border-radius: 8px; margin-bottom: 12px; display: flex; justify-content: space-between; align-items: center; border-right: 4px solid #0284c7;">
            <div>
              <h2 style="margin: 0; font-size: 14px; font-weight: 800; color: #ffffff;">لوحة التحليلات والمؤشرات البيانية لحسابات العمال</h2>
              <div style="font-size: 9.5px; color: #94a3b8; margin-top: 2px;">ملخص إجمالي الأجور والسلف وتوزيع العمال حسب المهن والحرف</div>
            </div>
            <span style="font-size: 10.5px; background-color: #0284c7; color: #ffffff; padding: 3px 8px; border-radius: 10px; font-weight: bold;">العملة: ${currency}</span>
          </div>

          <!-- Metric Cards Grid -->
          ${metricCardsHtml}

          <!-- Balance Comparison Gauge -->
          ${balanceComparisonHtml}

          <!-- Donut chart for professions -->
          <div style="background-color: #ffffff; border: 1px solid #cbd5e1; border-radius: 8px; padding: 10px; margin-bottom: 12px;">
            <div style="font-size: 11px; font-weight: bold; color: #0f172a; border-bottom: 1px solid #e2e8f0; padding-bottom: 4px; margin-bottom: 8px;">
              🍩 توزيع العمالة والمقاولين حسب المهن والتخصصات
            </div>
            ${profDonutChartHtml}
          </div>

        </div>

        <!-- PAGE BREAK AFTER DASHBOARD -->
        <div style="page-break-before: always;"></div>

        <!-- SECTION 1: OVERALL SUMMARY TABLE -->
        <div style="margin-bottom: 25px;">
          <h3 style="font-size: 14px; font-weight: bold; color: #0f172a; border-bottom: 2px solid #0284c7; padding-bottom: 6px; margin-bottom: 12px;">
            أولاً: جدول ملخص حسابات وأرصدة جميع العمال
          </h3>
          <table style="width: 100%; border-collapse: collapse; font-size: 11.5px;">
            <thead>
              <tr style="background-color: #1e293b; color: white;">
                <th style="padding: 8px; border: 1px solid #334155; text-align: right;">الاسم</th>
                <th style="padding: 8px; border: 1px solid #334155; text-align: right;">المهنة</th>
                <th style="padding: 8px; border: 1px solid #334155; text-align: right;">فترة العمل</th>
                <th style="padding: 8px; border: 1px solid #334155; text-align: center;">الأيام</th>
                <th style="padding: 8px; border: 1px solid #334155; text-align: center;">إجمالي عليه (سلف)</th>
                <th style="padding: 8px; border: 1px solid #334155; text-align: center;">إجمالي له (أجور)</th>
                <th style="padding: 8px; border: 1px solid #334155; text-align: center;">صافي الرصيد</th>
              </tr>
            </thead>
            <tbody>
              ${workers.length === 0 ? '<tr><td colspan="7" style="text-align: center; color: #94a3b8; padding: 12px;">لا يوجد عمال مسجلين حالياً.</td></tr>' : workerSummaryRowsHtml}
            </tbody>
            <tfoot>
              <tr style="background-color: #f1f5f9; font-weight: bold;">
                <td colspan="4" style="padding: 8px; border: 1px solid #cbd5e1; text-align: left;">المجموع الكلي:</td>
                <td style="padding: 8px; border: 1px solid #cbd5e1; color: #dc2626; text-align: center;">${formatCurrency(grandOnHim, currency)}</td>
                <td style="padding: 8px; border: 1px solid #cbd5e1; color: #16a34a; text-align: center;">${formatCurrency(grandForHim, currency)}</td>
                <td style="padding: 8px; border: 1px solid #cbd5e1; color: ${grandNet >= 0 ? '#15803d' : '#b91c1c'}; text-align: center;">
                  ${grandNet >= 0 ? `له: ${formatCurrency(grandNet, currency)}` : `عليه: ${formatCurrency(Math.abs(grandNet), currency)}`}
                </td>
              </tr>
            </tfoot>
          </table>
        </div>

        ${reportType === 'detailed' ? `
        <!-- SECTION 2: DETAILED LEDGER TABLES FOR ALL WORKERS -->
        <div style="margin-bottom: 25px;">
          <h3 style="font-size: 14px; font-weight: bold; color: #0f172a; border-bottom: 2px solid #0284c7; padding-bottom: 6px; margin-top: 20px; margin-bottom: 12px; break-after: avoid; page-break-after: avoid; break-before: auto;">
            ثانياً: كشوفات تفصيلية بكافة العمليات والحركات المالية لكل عامل
          </h3>
          ${workers.length === 0 ? '<p style="text-align: center; color: #94a3b8;">لا توجد بيانات تفصيلية.</p>' : workersDetailedLedgersHtml}
        </div>
        ` : ''}
      </div>
    `;

    return {
      title: reportType === 'detailed' ? 'التقرير_الشامل_للعمال_ومستحقاتهم' : 'التقرير_التنفيذي_الموجز_للعمال',
      htmlContent
    };
  };

  const handlePrintAllWorkersPDF = (reportType: ReportFormatType = 'detailed') => {
    const { title, htmlContent } = buildAllWorkersReportHtml(reportType);
    printPDF(title, htmlContent);
  };

  const handleShareAllWorkersPDF = async (format: 'detailed' | 'summary', method: 'whatsapp' | 'system') => {
    const { title, htmlContent } = buildAllWorkersReportHtml(format);
    await directShareReportPDF({ title, htmlContent, target: method });
  };

  // Filter workers based on query
  const filteredWorkers = workers.filter(w => 
    w.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    w.profession.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (w.phoneNumbers && w.phoneNumbers.some(p => p.includes(searchQuery)))
  );

  // Sorted workers list (Default: Oldest to Newest start date)
  const sortedWorkers = [...filteredWorkers].sort((a, b) => {
    const dateA = a.startDate || '';
    const dateB = b.startDate || '';
    const cmp = dateA.localeCompare(dateB);
    return workerSortOrder === 'asc' ? cmp : -cmp;
  });

  // Excel Column Filter State for Worker Ledger
  const [workerLedgerColumnFilters, setWorkerLedgerColumnFilters] = useState<Record<string, ActiveColumnFilter>>({});
  const [workerLedgerColumnSort, setWorkerLedgerColumnSort] = useState<ColumnSortState | null>(null);

  const handleWorkerLedgerFilterChange = (key: string, filter: ActiveColumnFilter | null) => {
    setWorkerLedgerColumnFilters(prev => {
      const next = { ...prev };
      if (!filter) {
        delete next[key];
      } else {
        next[key] = filter;
      }
      return next;
    });
  };

  const handleWorkerLedgerSortChange = (sort: ColumnSortState | null) => {
    setWorkerLedgerColumnSort(sort);
  };

  const handleClearWorkerLedgerFilters = () => {
    setWorkerLedgerColumnFilters({});
    setWorkerLedgerColumnSort(null);
  };

  const workerLedgerColumnConfigs: Record<string, ColumnFilterConfig<LedgerEntry>> = {
    date: {
      key: 'date',
      title: 'التاريخ',
      sortType: 'date',
      getValue: (e) => e.date,
      getDisplayValue: (val) => formatDateArabic(String(val))
    },
    description: {
      key: 'description',
      title: 'البيان',
      sortType: 'string',
      getValue: (e) => cleanLedgerDescription(e.description)
    },
    amountOnHim: {
      key: 'amountOnHim',
      title: 'مبلغ عليه (سلف)',
      sortType: 'number',
      getValue: (e) => e.amountOnHim,
      getDisplayValue: (val) => Number(val) > 0 ? formatCurrency(Number(val), currency || 'YER') : '-'
    },
    amountForHim: {
      key: 'amountForHim',
      title: 'مبلغ له (مستحقات)',
      sortType: 'number',
      getValue: (e) => e.amountForHim,
      getDisplayValue: (val) => Number(val) > 0 ? formatCurrency(Number(val), currency || 'YER') : '-'
    },
    notes: {
      key: 'notes',
      title: 'ملاحظات',
      sortType: 'string',
      getValue: (e) => e.notes || ''
    }
  };

  // Base filtered worker ledger entries (matching top search, date, type filters)
  const baseFilteredLedger = useMemo(() => {
    if (!activeWorker) return [];
    return activeWorker.ledger.filter(entry => {
      if (ledgerSearchTerm.trim()) {
        const term = ledgerSearchTerm.trim().toLowerCase();
        const matchDesc = entry.description.toLowerCase().includes(term);
        const matchNotes = (entry.notes || '').toLowerCase().includes(term);
        if (!matchDesc && !matchNotes) return false;
      }
      if (ledgerStartDate && entry.date < ledgerStartDate) return false;
      if (ledgerEndDate && entry.date > ledgerEndDate) return false;
      if (ledgerTypeFilter === 'onHim' && !(entry.amountOnHim > 0)) return false;
      if (ledgerTypeFilter === 'forHim' && !(entry.amountForHim > 0)) return false;
      return true;
    });
  }, [activeWorker, ledgerSearchTerm, ledgerStartDate, ledgerEndDate, ledgerTypeFilter]);

  // Filtered & Sorted active worker ledger entries (cascading with column filters)
  const filteredLedger = useMemo(() => {
    return baseFilteredLedger.filter(entry => {
      // Apply column filters
      for (const [colKey, filter] of Object.entries(workerLedgerColumnFilters) as [string, ActiveColumnFilter][]) {
        const config = workerLedgerColumnConfigs[colKey];
        if (!config || !filter || !filter.selectedValues) continue;

        const allowedSet = new Set(filter.selectedValues);
        const raw = config.getValue(entry);

        if (Array.isArray(raw)) {
          if (raw.length === 0) {
            if (!allowedSet.has('(فارغ)')) return false;
          } else {
            const hasAny = raw.some(val => {
              const strVal = val !== null && val !== undefined && String(val).trim() !== '' ? String(val) : '(فارغ)';
              return allowedSet.has(strVal);
            });
            if (!hasAny) return false;
          }
        } else {
          const strVal = raw !== null && raw !== undefined && String(raw).trim() !== '' ? String(raw) : '(فارغ)';
          if (!allowedSet.has(strVal)) return false;
        }
      }

      return true;
    });
  }, [baseFilteredLedger, workerLedgerColumnFilters, workerLedgerColumnConfigs]);

  const sortedLedger = [...filteredLedger].sort((a, b) => {
    if (workerLedgerColumnSort) {
      const config = workerLedgerColumnConfigs[workerLedgerColumnSort.key];
      if (config) {
        const rawA = config.getValue(a);
        const rawB = config.getValue(b);

        if (rawA === rawB) return 0;
        if (rawA === null || rawA === undefined || rawA === '') return 1;
        if (rawB === null || rawB === undefined || rawB === '') return -1;

        let comp = 0;
        if (config.sortType === 'number') {
          const numA = typeof rawA === 'number' ? rawA : parseFloat(String(rawA)) || 0;
          const numB = typeof rawB === 'number' ? rawB : parseFloat(String(rawB)) || 0;
          comp = numA - numB;
        } else if (config.sortType === 'date') {
          comp = String(rawA).localeCompare(String(rawB));
        } else {
          const strA = config.getDisplayValue ? config.getDisplayValue(String(rawA)) : String(rawA);
          const strB = config.getDisplayValue ? config.getDisplayValue(String(rawB)) : String(rawB);
          comp = strA.localeCompare(strB, 'ar');
        }

        return workerLedgerColumnSort.direction === 'asc' ? comp : -comp;
      }
    }

    if (ledgerSortOption === 'date-asc') {
      return a.date.localeCompare(b.date);
    } else if (ledgerSortOption === 'desc-alpha') {
      return a.description.localeCompare(b.description, 'ar');
    } else if (ledgerSortOption === 'amountOnHim-desc') {
      return b.amountOnHim - a.amountOnHim;
    } else if (ledgerSortOption === 'amountForHim-desc') {
      return b.amountForHim - a.amountForHim;
    }
    return b.date.localeCompare(a.date);
  });

  const hasActiveWorkerLedgerColumnFilters = Object.keys(workerLedgerColumnFilters).length > 0 || workerLedgerColumnSort !== null;

  const isLedgerFilterActive = Boolean(
    ledgerSearchTerm || ledgerStartDate || ledgerEndDate || ledgerTypeFilter !== 'all' || ledgerSortOption !== 'date-desc' || hasActiveWorkerLedgerColumnFilters
  );

  // Calculate sum of filtered ledger entries grouped by currency
  const ledgerTotalsByCurrency = filteredLedger.reduce((acc, curr) => {
    const code = curr.currency || currency || 'YER';
    if (!acc[code]) {
      acc[code] = { onHim: 0, forHim: 0 };
    }
    acc[code].onHim += curr.amountOnHim || 0;
    acc[code].forHim += curr.amountForHim || 0;
    return acc;
  }, {} as Record<string, { onHim: number; forHim: number }>);

  return (
    <div className="space-y-4 animate-fade-in" id="workers-section">
      
      {/* Dynamic view toggler */}
      {activeWorker ? (
        
        /* --------------------------------- DETAIL VIEW --------------------------------- */
        <div className="space-y-4 animate-fade-in" id="worker-details-pane">
          
          {/* Detail Header / Nav back */}
          <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-100 shadow-xs space-y-3">
            <div className="flex items-start justify-between gap-4 w-full">
              <div className="flex items-center gap-3">
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <h2 className="text-xl font-bold text-slate-800">{activeWorker.name}</h2>
                    <span className="text-xs bg-slate-100 text-slate-600 px-2.5 py-0.5 rounded-full font-medium">{activeWorker.profession}</span>
                    {(() => {
                      const status = getPersonWorkStatus(activeWorker.endDate);
                      return (
                        <span className={`text-[11px] px-2.5 py-0.5 rounded-full font-bold border ${status.badgeClass} flex items-center gap-1`}>
                          <span className={`w-1.5 h-1.5 rounded-full ${status.isStopped ? 'bg-rose-500' : 'bg-emerald-500'}`}></span>
                          {status.statusText}
                        </span>
                      );
                    })()}
                    <AttributionBadge createdBy={activeWorker.createdBy} updatedBy={activeWorker.updatedBy} />
                  </div>
                  <p className="text-slate-400 text-xs mt-1 flex items-center gap-1.5">
                    <Calendar size={13} />
                    تاريخ العمل: {formatDateArabic(activeWorker.startDate)} إلى {activeWorker.endDate ? formatDateArabic(activeWorker.endDate) : 'الآن (مستمر)'}
                  </p>
                  <PhoneNumbersDisplay phoneNumbers={activeWorker.phoneNumbers} className="mt-2" />
                </div>
              </div>

              <div className="flex flex-col items-end gap-1.5 shrink-0">
                {setActiveTab && (
                  <button 
                    onClick={() => setActiveTab('dashboard')}
                    className="h-8 px-3 bg-white hover:bg-slate-50 text-slate-800 font-bold text-[11px] border border-slate-200/90 rounded-lg shadow-2xs hover:shadow-xs transition-all duration-200 flex items-center gap-1.5 cursor-pointer shrink-0 w-full justify-center"
                    title="الرجوع للرئيسية"
                  >
                    <ArrowLeft size={14} className="text-slate-700 shrink-0" />
                    <span>الرجوع للرئيسية</span>
                  </button>
                )}

                <button 
                  onClick={() => { setSelectedWorkerId(null); setLedgerError(''); }}
                  className="h-8 px-3 bg-white hover:bg-slate-50 text-slate-800 font-bold text-[11px] border border-slate-200/90 rounded-lg shadow-2xs hover:shadow-xs transition-all duration-200 flex items-center gap-1.5 cursor-pointer shrink-0 w-full justify-center"
                  title="الرجوع لقائمة العمال"
                >
                  <ArrowLeft size={14} className="text-slate-700 shrink-0" />
                  <span>الرجوع لقائمة العمال</span>
                </button>

                <OptionsMenu 
                  onExportExcel={() => handleExportWorkerLedgerExcel(activeWorker)}
                  onExportPDF={() => handlePrintWorkerPDF(activeWorker)}
                  onSharePDF={handleShareWorkerPDF}
                  onImportExcel={sharedRole !== 'read' ? handleWorkerLedgerExcelImport : undefined}
                  shareTitle={`كشف حساب العامل: ${activeWorker.name}`}
                  shareText={(() => {
                    const days = getWorkerTotalDays(activeWorker, sharedRole === 'owner');
                    const totalOnHim = activeWorker.ledger.reduce((sum, e) => sum + e.amountOnHim, 0);
                    const totalForHim = activeWorker.ledger.reduce((sum, e) => sum + e.amountForHim, 0);
                    const net = totalForHim - totalOnHim;
                    const status = net === 0 ? 'خالص' : net > 0 ? `له: ${formatCurrency(net, currency)}` : `عليه: ${formatCurrency(Math.abs(net), currency)}`;

                    return `👷 كشف حساب العامل التفصيلي: ${activeWorker.name}\n🔨 المهنة: ${activeWorker.profession}\n📅 تاريخ العمل: من ${activeWorker.startDate} إلى ${activeWorker.endDate || 'الآن'}\n⏱️ أيام العمل المحتسبة: ${days} يوم\n\n💰 إجمالي الاستحقاقات (له): ${formatCurrency(totalForHim, currency)}\n💸 إجمالي السلف/المدفوعات (عليه): ${formatCurrency(totalOnHim, currency)}\n⚖️ الصافي المالي الحالي: ${status}\n\n*تم استخراجه ومشاركته من كشوفات المقاولات*`;
                  })()}
                />
              </div>
            </div>

            {/* Actions for active worker */}
            {(sharedRole !== 'read' || onTransferWorkerToEmployee) && (
              <div className="flex items-center gap-2.5 flex-wrap w-full pt-1">
                {sharedRole !== 'read' && (
                  <button 
                    onClick={() => setEditingWorker(activeWorker)}
                    className="h-9 px-3.5 bg-white hover:bg-amber-50 text-amber-800 font-bold text-xs border border-slate-200/90 rounded-xl shadow-xs hover:shadow-md transition-all flex items-center gap-2 cursor-pointer shrink-0"
                    title="تعديل تاريخ البدء أو الانتهاء أو بيانات العامل"
                  >
                    <Pencil size={15} className="text-amber-600 shrink-0" />
                    <span>تعديل</span>
                  </button>
                )}

                {sharedRole !== 'read' && onTransferWorkerToEmployee && (
                  <button 
                    onClick={() => {
                      if (confirm(`هل ترغب بنقل كافة بيانات العامل "${activeWorker.name}" إلى نافذة الموظفين؟`)) {
                        onTransferWorkerToEmployee(activeWorker);
                      }
                    }}
                    className="h-9 px-3.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-800 font-bold text-xs border border-indigo-200 rounded-xl shadow-xs hover:shadow-md transition-all flex items-center gap-2 cursor-pointer shrink-0"
                    title="نقل الي الموظفين"
                  >
                    <ArrowRightLeft size={15} className="text-indigo-600 shrink-0" />
                    <span>نقل الي الموظفين</span>
                  </button>
                )}
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            
            {/* Left Col: Basic Info Metrics & Add Transaction */}
            <div className="space-y-4">
              
              {/* Metrics Box (بيانات وحالة العمل) - Collapsible */}
              <div className="bg-white p-3.5 sm:p-4 rounded-2xl border border-slate-100 shadow-xs transition-all duration-300 space-y-3">
                <button
                  type="button"
                  onClick={() => setShowWorkDataSection(!showWorkDataSection)}
                  className="w-full flex items-center justify-between text-right font-bold text-slate-800 text-sm hover:text-sky-700 transition-colors cursor-pointer select-none"
                >
                  <div className="flex items-center gap-2.5">
                    <div className="p-1.5 bg-sky-50 text-sky-600 rounded-lg shrink-0">
                      <Info size={16} />
                    </div>
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <h3 className="font-bold text-slate-800 text-sm">بيانات وحالة العمل</h3>
                        <span className={`text-[10px] px-2 py-0.5 rounded-md font-bold ${activeWorker.endDate ? 'bg-amber-50 text-amber-700 border border-amber-200' : 'bg-emerald-50 text-emerald-700 border border-emerald-200'}`}>
                          {activeWorker.endDate ? 'منتهي العمل' : 'على رأس العمل'}
                        </span>
                        {Boolean(activeWorker.dailyWage && activeWorker.dailyWage > 0) && (
                          <span className="text-[10px] bg-slate-100 text-slate-700 font-mono font-bold px-2 py-0.5 rounded-md border border-slate-200/60">
                            {formatCurrency(activeWorker.dailyWage, activeWorker.dailyWageCurrency || currency)}/يوم
                          </span>
                        )}
                      </div>
                      <p className="text-[10px] text-slate-400 font-normal">الأجر اليومي، فترات العمل، صافي الأيام المستحقة، وملخص الأرصدة</p>
                    </div>
                  </div>
                  <div className={`flex items-center gap-1.5 text-xs font-bold px-3 py-1.5 rounded-xl transition-all shrink-0 ${
                    showWorkDataSection 
                      ? 'text-slate-600 bg-slate-100 hover:bg-slate-200 border border-slate-200' 
                      : 'text-sky-700 bg-sky-50 hover:bg-sky-100 border border-sky-200 shadow-2xs'
                  }`}>
                    {showWorkDataSection ? (
                      <>
                        <EyeOff size={14} className="text-slate-500" />
                        <span>طي البيانات</span>
                        <ChevronUp size={15} />
                      </>
                    ) : (
                      <>
                        <Eye size={14} className="text-sky-600" />
                        <span>إظهار</span>
                        <ChevronDown size={15} />
                      </>
                    )}
                  </div>
                </button>

                {showWorkDataSection && (
                  <div className="space-y-3 pt-3 border-t border-slate-100 animate-fade-in">
                
                {/* Daily Wage Block (if defined or quick set) */}
                <div className="flex items-center justify-between p-3 bg-slate-50 rounded-xl border border-slate-100">
                  <div>
                    <div className="text-xs text-slate-700 font-bold flex items-center gap-1.5">
                      <Coins size={13} className="text-amber-500" />
                      <span>الأجر اليومي المتفق عليه:</span>
                    </div>
                    <div className="text-[10px] text-slate-400">
                      {activeWorker.dailyWage && activeWorker.dailyWage > 0 
                        ? 'مربوط تلقائياً بصافي أيام العمل' 
                        : 'اختياري للاحتساب والخصم التلقائي'}
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="font-black text-slate-800 text-sm bg-white border border-slate-200/80 px-2.5 py-1 rounded-lg shadow-2xs font-mono">
                      {activeWorker.dailyWage && activeWorker.dailyWage > 0 
                        ? formatCurrency(activeWorker.dailyWage, activeWorker.dailyWageCurrency || currency)
                        : 'غير محدد'}
                    </span>
                    {sharedRole !== 'read' && onUpdateWorker && (
                      <button
                        type="button"
                        onClick={() => {
                          setQuickDailyWage(String(activeWorker.dailyWage || ''));
                          setShowQuickWageModal(true);
                        }}
                        className="p-1.5 text-slate-400 hover:text-amber-600 hover:bg-amber-50 rounded-lg transition-colors cursor-pointer"
                        title="تحديد أو تعديل الأجر اليومي للعامل"
                      >
                        <Pencil size={13} />
                      </button>
                    )}
                  </div>
                </div>

                {/* Days of work block with Absence Deduction breakdown */}
                {(() => {
                  const grossDays = getWorkerTotalDays(activeWorker, sharedRole === 'owner');
                  const absDays = getWorkerAbsenceDays(activeWorker);
                  const netDays = getWorkerNetDays(activeWorker, sharedRole === 'owner');
                  return (
                    <div className="p-3 bg-slate-50 rounded-xl border border-slate-100 space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="space-y-0.5">
                          <span className="text-xs text-slate-700 font-bold block">صافي أيام العمل المستحقة:</span>
                          <span className="text-[10px] text-slate-400 block font-mono">
                            فترة العمل: {grossDays} يوم {absDays > 0 ? ` [خصم غياب/إجازة: ${absDays} يوم]` : ''}
                          </span>
                        </div>
                        <span className="font-black text-emerald-700 text-sm bg-white border border-emerald-200/80 px-3 py-1 rounded-lg shadow-2xs font-mono">
                          {netDays} يوم صافي
                        </span>
                      </div>
                      {absDays > 0 && (
                        <div className="flex items-center justify-between text-[11px] bg-rose-50/90 border border-rose-200/80 text-rose-800 px-2.5 py-1.5 rounded-lg font-mono">
                          <span className="font-semibold flex items-center gap-1">
                            <span>🚫 أيام الغياب المخصومة:</span>
                          </span>
                          <span className="font-bold text-rose-700 font-mono">-{absDays} يوم غياب</span>
                        </div>
                      )}
                    </div>
                  );
                })()}

                {/* Automatically Linked Calculation in Ledger (if dailyWage > 0) */}
                {Boolean(activeWorker.dailyWage && activeWorker.dailyWage > 0) && (() => {
                  const netDays = getWorkerNetDays(activeWorker, sharedRole === 'owner');
                  const wage = activeWorker.dailyWage || 0;
                  const calculated = netDays * wage;
                  return (
                    <div className="p-3 bg-indigo-50/70 rounded-xl border border-indigo-100 space-y-1.5">
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] font-bold text-indigo-950 flex items-center gap-1">
                          <Receipt size={13} className="text-indigo-600" />
                          <span>العملية المالية التلقائية بالكشف:</span>
                        </span>
                        <span className="font-mono font-black text-emerald-700 text-xs bg-white px-2 py-0.5 rounded-md border border-indigo-200/60 shadow-2xs">
                          له: {formatCurrency(calculated, activeWorker.dailyWageCurrency || currency)}
                        </span>
                      </div>
                      <div className="text-[10px] text-indigo-700/80 font-mono">
                        {netDays} يوم صافي × {formatCurrency(wage, activeWorker.dailyWageCurrency || currency)} = {formatCurrency(calculated, activeWorker.dailyWageCurrency || currency)}
                      </div>
                      <div className="text-[10px] text-indigo-700/80 flex items-center gap-1 pt-1 border-t border-indigo-100/70">
                        <Sparkles size={11} className="text-indigo-600 shrink-0" />
                        <span>مربوطة تلقائياً: أي تعديل بالأجر أو أيام العمل أو الغياب يتحدث هنا وبالكشف فوراً.</span>
                      </div>
                    </div>
                  );
                })()}

                {/* Work Periods List & Add Extra Period Inline Form */}
                <div className="pt-3 border-t border-slate-100 text-right">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-700">فترات العمل المسجلة:</span>
                    {sharedRole !== 'read' && (
                      <button
                        type="button"
                        onClick={() => {
                          setShowExtraForm(!showExtraForm);
                          setExtraFormError('');
                        }}
                        className="text-[11px] bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 px-2.5 py-1 rounded-lg font-bold flex items-center gap-1 cursor-pointer transition-colors shadow-2xs"
                      >
                        <PlusCircle size={12} />
                        إضافة فترة عمل إضافية
                      </button>
                    )}
                  </div>

                  {/* List of Periods */}
                  <div className="space-y-1.5 mt-2 max-h-40 overflow-y-auto">
                    {/* Main Period */}
                    <div className="flex items-center justify-between bg-slate-50 p-2 rounded-lg text-[11px] text-slate-600 font-medium">
                      <div className="flex items-center gap-1">
                        <span className="w-1.5 h-1.5 rounded-full bg-sky-500"></span>
                        <span>الأساسية: {formatDateArabic(activeWorker.startDate)} إلى {activeWorker.endDate ? formatDateArabic(activeWorker.endDate) : 'الآن'}</span>
                      </div>
                      <span className="bg-slate-200/50 px-1.5 py-0.5 rounded text-slate-800 font-bold font-mono">{calculateDaysOfWork(activeWorker.startDate, activeWorker.endDate, sharedRole === 'owner')} يوم</span>
                    </div>

                    {/* Extra Periods */}
                    {(activeWorker.extraPeriods || []).map((p, idx) => {
                      const pDays = calculateDaysOfWork(p.startDate, p.endDate);
                      return (
                        <div key={p.id} className="flex items-center justify-between bg-sky-50/50 p-2 rounded-lg text-[11px] text-slate-600 font-medium border border-sky-100/30">
                          <div className="flex items-center gap-1">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                            <span>فترة {idx + 1}: {formatDateArabic(p.startDate)} إلى {formatDateArabic(p.endDate)}</span>
                          </div>
                          <div className="flex items-center gap-2 font-mono">
                            <span className="bg-sky-100/60 text-sky-800 px-1.5 py-0.5 rounded font-bold">{pDays} يوم</span>
                            {sharedRole !== 'read' && sharedRole !== 'add' && (
                              <button
                                type="button"
                                onClick={() => onDeleteWorkerExtraPeriod?.(activeWorker.id, p.id)}
                                className="text-rose-500 hover:text-rose-600 cursor-pointer"
                                title="حذف هذه الفترة"
                              >
                                <Trash2 size={12} />
                              </button>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  {/* Extra Period Form */}
                  {showExtraForm && (
                    <form onSubmit={handleExtraPeriodSubmit} className="mt-3 p-3 bg-slate-50 border border-slate-200/60 rounded-xl space-y-2.5 animate-fade-in text-right">
                      <div className="grid grid-cols-2 gap-2">
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold text-slate-500 block">تاريخ البدء</label>
                          <input
                            type="date"
                            value={extraStart}
                            onChange={(e) => setExtraStart(e.target.value)}
                            className="w-full p-1.5 bg-white border border-slate-200 rounded-lg text-xs text-slate-700"
                            required
                          />
                        </div>
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold text-slate-500 block">تاريخ الانتهاء</label>
                          <input
                            type="date"
                            value={extraEnd}
                            onChange={(e) => setExtraEnd(e.target.value)}
                            className="w-full p-1.5 bg-white border border-slate-200 rounded-lg text-xs text-slate-700"
                            required
                          />
                        </div>
                      </div>
                      {extraFormError && <p className="text-[10px] text-rose-500">{extraFormError}</p>}
                      <div className="flex justify-end gap-1.5 pt-1">
                        <button
                          type="button"
                          onClick={() => { setShowExtraForm(false); setExtraStart(''); setExtraEnd(''); setExtraFormError(''); }}
                          className="px-2.5 py-1 text-[10px] font-bold text-slate-500 hover:bg-slate-200/50 rounded-lg border border-slate-200 bg-white flex items-center gap-1 cursor-pointer"
                        >
                          <RotateCcw size={11} />
                          <span>إلغاء / تنظيف</span>
                        </button>
                        <button
                          type="submit"
                          className="px-2.5 py-1 text-[10px] font-bold text-white bg-sky-600 hover:bg-sky-700 rounded-lg"
                        >
                          حفظ الفترة
                        </button>
                      </div>
                    </form>
                  )}
                </div>

                {/* Ledger balances summary grouped by currency */}
                <div className="space-y-3 pt-2 border-t border-slate-50">
                  {['YER', 'SAR', 'USD'].map(cur => {
                    const totalOnHim = activeWorker.ledger.filter(e => (e.currency || 'YER') === cur).reduce((sum, e) => sum + e.amountOnHim, 0);
                    const totalForHim = activeWorker.ledger.filter(e => (e.currency || 'YER') === cur).reduce((sum, e) => sum + e.amountForHim, 0);
                    const balance = totalForHim - totalOnHim;
                    
                    if (totalOnHim === 0 && totalForHim === 0) return null;
                    
                    return (
                      <div key={cur} className="bg-slate-50 p-2.5 rounded-xl border border-slate-100 space-y-1.5 font-mono">
                        <div className="flex justify-between items-center text-[11px] font-bold text-slate-700">
                          <span>العملة:</span>
                          <span className="bg-slate-200 text-slate-800 px-1.5 py-0.5 rounded-md text-[10px]">{cur}</span>
                        </div>
                        <div className="flex justify-between text-[10px] text-slate-500">
                          <span>عليه (سلف):</span>
                          <span className="font-semibold text-rose-600">{formatCurrency(totalOnHim, cur)}</span>
                        </div>
                        <div className="flex justify-between text-[10px] text-slate-500">
                          <span>له (أجور):</span>
                          <span className="font-semibold text-emerald-600">{formatCurrency(totalForHim, cur)}</span>
                        </div>
                        <div className="flex justify-between text-[11px] font-bold border-t border-slate-200/50 pt-1.5 mt-1">
                          <span>صافي الرصيد:</span>
                          <span className={balance < 0 ? 'text-rose-600' : balance > 0 ? 'text-emerald-600' : 'text-slate-400'}>
                            {balance === 0 ? 'خالص' : balance > 0 ? `له: ${formatCurrency(balance, cur)}` : `عليه: ${formatCurrency(Math.abs(balance), cur)}`}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                  {activeWorker.ledger.length === 0 && (
                    <p className="text-xs text-slate-400 text-center py-2 animate-pulse">لا توجد حركات مالية مسجلة بعد</p>
                  )}
                </div>
              </div>
            )}
          </div>

              {/* Absence / Leave Records Card (سجل الغياب والإجازات وخصم الأيام) */}
              <div className="bg-white p-3.5 sm:p-4 rounded-2xl border border-slate-100 shadow-xs transition-all duration-300 space-y-3">
                <button
                  type="button"
                  onClick={() => setShowAbsenceSection(!showAbsenceSection)}
                  className="w-full flex items-center justify-between text-right font-bold text-slate-800 text-sm hover:text-rose-700 transition-colors cursor-pointer select-none"
                >
                  <div className="flex items-center gap-2.5">
                    <div className="p-1.5 bg-rose-50 text-rose-600 rounded-lg shrink-0">
                      <Calendar size={16} />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="font-bold text-slate-800 text-sm">أيام الغياب والإجازات</h3>
                        {activeWorker.absences && activeWorker.absences.length > 0 ? (
                          <span className="text-[10px] bg-rose-100 text-rose-800 font-extrabold px-2 py-0.5 rounded-full font-mono">
                            {getWorkerAbsenceDays(activeWorker)} يوم مخصوم ({activeWorker.absences.length} تسجيل)
                          </span>
                        ) : (
                          <span className="text-[10px] bg-emerald-50 text-emerald-700 font-bold px-2 py-0.5 rounded-full">
                            حضور كامل (0 غياب)
                          </span>
                        )}
                      </div>
                      <p className="text-[10px] text-slate-400 font-normal">تسجيل أيام أو نصف يوم غياب/إجازة ليتم خصمها من الراتب وحساب الأجر تلقائياً</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5 text-xs font-bold text-slate-600 bg-slate-100 hover:bg-slate-200 px-3 py-1.5 rounded-xl transition-colors shrink-0">
                    <span>{showAbsenceSection ? 'طي السجل' : 'إظهار الغياب'}</span>
                    {showAbsenceSection ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
                  </div>
                </button>

                {showAbsenceSection && (
                  <div className="space-y-3 pt-2.5 border-t border-slate-100 animate-fade-in">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-semibold text-slate-500">سجل أيام الغياب والإجازات:</span>
                      {sharedRole !== 'read' && (
                        <button
                          type="button"
                          onClick={() => {
                            setShowAddAbsenceForm(!showAddAbsenceForm);
                            setAbsenceError('');
                          }}
                          className="text-[11px] bg-rose-600 hover:bg-rose-700 text-white px-3 py-1.5 rounded-xl font-bold flex items-center gap-1.5 transition-colors cursor-pointer shadow-xs active:scale-95"
                          title="تسجيل يوم أو نصف يوم غياب"
                        >
                          <PlusCircle size={13} />
                          <span>تسجيل غياب / إجازة</span>
                        </button>
                      )}
                    </div>

                    {/* Add Absence Form */}
                    {showAddAbsenceForm && (
                      <form onSubmit={handleAddAbsenceSubmit} className="p-3 bg-rose-50/60 border border-rose-200/70 rounded-xl space-y-3 animate-fade-in text-right">
                        <div className="flex items-center justify-between border-b border-rose-200/50 pb-1.5">
                          <span className="text-xs font-extrabold text-rose-900 flex items-center gap-1">
                            <Calendar size={13} className="text-rose-600" />
                            <span>تحديد يوم الغياب أو الإجازة للخصم</span>
                          </span>
                          <span className="text-[10px] text-rose-700 font-semibold">يخصم فوراً من صافي الأيام</span>
                        </div>

                        {/* Date */}
                        <div className="space-y-1">
                          <label className="text-[11px] font-bold text-slate-600 block">تاريخ الغياب / الإجازة <span className="text-rose-500">*</span></label>
                          <input
                            type="date"
                            value={absenceDate}
                            onChange={(e) => setAbsenceDate(e.target.value)}
                            className="w-full p-2 bg-white border border-rose-200 rounded-lg text-xs text-slate-800 font-bold focus:outline-hidden focus:border-rose-500"
                            required
                          />
                        </div>

                        {/* Type: Full Day or Half Day */}
                        <div className="space-y-1.5">
                          <label className="text-[11px] font-bold text-slate-600 block">مقدار الخصم من اليوم</label>
                          <div className="grid grid-cols-2 gap-2">
                            <button
                              type="button"
                              onClick={() => setAbsenceType('full')}
                              className={`p-2 rounded-xl text-xs font-bold border transition-all flex flex-col items-center justify-center gap-1 cursor-pointer ${
                                absenceType === 'full'
                                  ? 'bg-rose-600 text-white border-rose-700 shadow-xs'
                                  : 'bg-white text-slate-700 border-slate-200 hover:bg-rose-50'
                              }`}
                            >
                              <span className="text-sm">☀️ يوم كامل</span>
                              <span className="text-[10px] opacity-90 font-mono">خصم 1.0 يوم من الأجر</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => setAbsenceType('half')}
                              className={`p-2 rounded-xl text-xs font-bold border transition-all flex flex-col items-center justify-center gap-1 cursor-pointer ${
                                absenceType === 'half'
                                  ? 'bg-amber-600 text-white border-amber-700 shadow-xs'
                                  : 'bg-white text-slate-700 border-slate-200 hover:bg-amber-50'
                              }`}
                            >
                              <span className="text-sm">🌤️ نصف يوم</span>
                              <span className="text-[10px] opacity-90 font-mono">خصم 0.5 يوم من الأجر</span>
                            </button>
                          </div>
                        </div>

                        {/* Reason & Quick options */}
                        <div className="space-y-1">
                          <div className="flex items-center justify-between">
                            <label className="text-[11px] font-bold text-slate-600">السبب / نوع الإجازة</label>
                            <span className="text-[10px] text-slate-400">انقر لاختيار سريع:</span>
                          </div>
                          <div className="flex flex-wrap gap-1 mb-1.5">
                            {['إجازة اعتيادية', 'ظرف طارئ', 'إجازة مرضية', 'غياب بدون إذن', 'إجازة رسمية'].map(tag => (
                              <button
                                key={tag}
                                type="button"
                                onClick={() => setAbsenceReason(tag)}
                                className={`text-[10px] px-2 py-0.5 rounded-lg border transition-colors cursor-pointer ${
                                  absenceReason === tag 
                                    ? 'bg-rose-600 text-white border-rose-600 font-bold' 
                                    : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-100'
                                }`}
                              >
                                {tag}
                              </button>
                            ))}
                          </div>
                          <input
                            type="text"
                            value={absenceReason}
                            onChange={(e) => setAbsenceReason(e.target.value)}
                            placeholder="مثال: إجازة خاصة، ظرف عائلي، مرض..."
                            className="w-full p-2 bg-white border border-rose-200 rounded-lg text-xs text-slate-700 focus:outline-hidden focus:border-rose-500"
                          />
                        </div>

                        {/* Notes */}
                        <div className="space-y-1">
                          <label className="text-[11px] font-bold text-slate-600 block">ملاحظات إضافية (اختياري)</label>
                          <input
                            type="text"
                            value={absenceNotes}
                            onChange={(e) => setAbsenceNotes(e.target.value)}
                            placeholder="أي تفاصيل عن الإجازة أو التنسيق..."
                            className="w-full p-2 bg-white border border-rose-200 rounded-lg text-xs text-slate-700 focus:outline-hidden focus:border-rose-500"
                          />
                        </div>

                        {absenceError && (
                          <p className="text-[11px] text-rose-600 font-bold bg-white p-2 rounded-lg border border-rose-200">{absenceError}</p>
                        )}

                        <div className="flex justify-end gap-2 pt-1 border-t border-rose-200/50">
                          <button
                            type="button"
                            onClick={() => {
                              setShowAddAbsenceForm(false);
                              setAbsenceError('');
                            }}
                            className="px-3 py-1.5 text-xs text-slate-600 hover:bg-slate-100 bg-white border border-slate-200 rounded-xl cursor-pointer"
                          >
                            إلغاء
                          </button>
                          <button
                            type="submit"
                            className="px-3.5 py-1.5 text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-xl cursor-pointer shadow-xs"
                          >
                            تأكيد وخصم الغياب
                          </button>
                        </div>
                      </form>
                    )}

                    {/* Absence List */}
                    {(!activeWorker.absences || activeWorker.absences.length === 0) ? (
                      <div className="text-center py-4 px-2 bg-slate-50 border border-dashed border-slate-200 rounded-xl text-slate-400 text-xs">
                        لا توجد أي أيام غياب أو إجازات مسجلة لهذا العامل (سجل الحضور كامل).
                      </div>
                    ) : (
                      <div className="space-y-2 max-h-56 overflow-y-auto">
                        {activeWorker.absences.map((abs) => (
                          <div 
                            key={abs.id}
                            className="p-2.5 bg-rose-50/40 border border-rose-100 rounded-xl flex items-center justify-between gap-2 text-right transition-all hover:bg-rose-50/70"
                          >
                            <div className="space-y-0.5 min-w-0">
                              <div className="flex items-center gap-2 flex-wrap">
                                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md font-mono ${
                                  abs.type === 'half'
                                    ? 'bg-amber-100 text-amber-800 border border-amber-200'
                                    : 'bg-rose-100 text-rose-800 border border-rose-200'
                                }`}>
                                  {abs.type === 'half' ? '🌤️ نصف يوم (-0.5)' : '☀️ يوم كامل (-1.0)'}
                                </span>
                                <span className="text-xs font-bold text-slate-800">
                                  {formatDateArabic(abs.date)}
                                </span>
                              </div>
                              <div className="text-[11px] text-slate-600 flex items-center gap-1.5 flex-wrap">
                                {abs.reason && <span className="font-semibold text-rose-900">{abs.reason}</span>}
                                {abs.notes && <span className="text-slate-400 text-[10px]">({abs.notes})</span>}
                              </div>
                            </div>

                            {sharedRole !== 'read' && (
                              <button
                                type="button"
                                onClick={() => handleDeleteAbsence(abs.id)}
                                className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-white rounded-lg transition-colors cursor-pointer shrink-0 border border-transparent hover:border-rose-200"
                                title="إلغاء هذا الغياب واستعادة اليوم المخصوم"
                              >
                                <Trash2 size={13} />
                              </button>
                            )}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Nutrition Periods Card (بيانات التغذية) - Collapsible by default */}
              <div className="bg-white p-3.5 sm:p-4 rounded-2xl border border-slate-100 shadow-xs transition-all duration-300 space-y-3">
                <button
                  type="button"
                  onClick={() => setShowNutritionSection(!showNutritionSection)}
                  className="w-full flex items-center justify-between text-right font-bold text-slate-800 text-sm hover:text-emerald-700 transition-colors cursor-pointer select-none"
                >
                  <div className="flex items-center gap-2.5">
                    <div className="p-1.5 bg-emerald-50 text-emerald-600 rounded-lg shrink-0">
                      <Utensils size={16} />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="font-bold text-slate-800 text-sm">بيانات التغذية</h3>
                        {activeWorker.nutritionPeriods && activeWorker.nutritionPeriods.length > 0 && (
                          <span className="text-[10px] bg-emerald-100 text-emerald-800 font-extrabold px-2 py-0.5 rounded-full">
                            {activeWorker.nutritionPeriods.length} فترات
                          </span>
                        )}
                      </div>
                      <p className="text-[10px] text-slate-400 font-normal">خاصة ببيانات وأسعار التغذية للعمال والمساعدين</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5 text-xs font-bold text-slate-600 bg-slate-100 hover:bg-slate-200 px-3 py-1.5 rounded-xl transition-colors shrink-0">
                    <span>{showNutritionSection ? 'طي البيانات' : 'إظهار التغذية'}</span>
                    {showNutritionSection ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
                  </div>
                </button>

                {showNutritionSection && (
                  <div className="space-y-3 pt-2.5 border-t border-slate-100 animate-fade-in">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-semibold text-slate-500">سجل فترات التغذية المسجلة:</span>
                      {sharedRole !== 'read' && (
                        <button
                          type="button"
                          onClick={handleOpenAddNutritionModal}
                          className="text-[11px] bg-emerald-600 hover:bg-emerald-700 text-white px-3 py-1.5 rounded-xl font-bold flex items-center gap-1.5 transition-colors cursor-pointer shadow-xs active:scale-95"
                          title="إضافة فترة تغذية جديدة"
                        >
                          <PlusCircle size={13} />
                          <span>+ فترة جديدة</span>
                        </button>
                      )}
                    </div>

                    {/* Nutrition Periods List */}
                    {(!activeWorker.nutritionPeriods || activeWorker.nutritionPeriods.length === 0) ? (
                      <div className="text-center py-4 bg-slate-50/70 rounded-xl border border-dashed border-slate-200 p-3 space-y-1.5">
                        <p className="text-xs text-slate-400">لا توجد فترات تغذية مسجلة لهذا العامل حالياً</p>
                        {sharedRole !== 'read' && (
                          <button
                            type="button"
                            onClick={handleOpenAddNutritionModal}
                            className="text-xs text-emerald-600 hover:text-emerald-700 font-bold underline inline-block cursor-pointer"
                          >
                            + إضافة التغذية
                          </button>
                        )}
                      </div>
                    ) : (
                      <div className="space-y-2.5 max-h-80 overflow-y-auto pr-0.5">
                        {activeWorker.nutritionPeriods.map((period) => {
                          const days = calculateNutritionDays(period.startDate, period.endDate);
                          const total = period.dailyAmount * days;
                          const isOpen = !period.endDate;

                          return (
                            <div key={period.id} className="p-3 bg-slate-50 border border-slate-200/80 rounded-xl space-y-2 relative transition-all hover:border-emerald-200">
                              <div className="flex items-center justify-between gap-2">
                                <div className="flex items-center gap-2">
                                  <span className="font-bold text-slate-800 text-xs">{period.workerName}</span>
                                  <span className={`text-[10px] px-2 py-0.5 rounded-full font-extrabold flex items-center gap-1 ${
                                    isOpen 
                                      ? 'bg-emerald-100 text-emerald-800 border border-emerald-200' 
                                      : 'bg-sky-100 text-sky-800 border border-sky-200'
                                  }`}>
                                    {isOpen ? '🟢 مستمرة' : '🔵 مكتملة'}
                                  </span>
                                </div>

                                {sharedRole !== 'read' && (
                                  <div className="flex items-center gap-1">
                                    <button
                                      type="button"
                                      onClick={() => handleOpenEditNutritionModal(period)}
                                      className="p-1 text-slate-400 hover:text-amber-600 hover:bg-amber-50 rounded-lg transition-colors cursor-pointer"
                                      title="تعديل بيانات التغذية"
                                    >
                                      <Pencil size={13} />
                                    </button>
                                    <button
                                      type="button"
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        const confirmText = `هل أنت متأكد من حذف فترة التغذية الخاصة بـ "${period.workerName}"؟`;
                                        if (typeof window === 'undefined' || !window.confirm || window.confirm(confirmText)) {
                                          onDeleteWorkerNutritionPeriod?.(activeWorker.id, period.id);
                                        }
                                      }}
                                      className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                                      title="حذف فترة التغذية"
                                    >
                                      <Trash2 size={13} />
                                    </button>
                                  </div>
                                )}
                              </div>

                              <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-600">
                                <div>
                                  <span className="text-slate-400 block text-[10px]">مبلغ التغذية اليومية:</span>
                                  <span className="font-bold text-slate-700">{formatCurrency(period.dailyAmount, currency)}</span>
                                </div>
                                <div>
                                  <span className="text-slate-400 block text-[10px]">عدد أيام التغذية:</span>
                                  <span className="font-bold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-100">{days} يوم</span>
                                </div>
                              </div>

                              <div className="flex items-center justify-between text-[11px] pt-1.5 border-t border-slate-200/60">
                                <span className="text-slate-400 text-[10px]">
                                  {formatDateArabic(period.startDate)} {period.endDate ? `إلى ${formatDateArabic(period.endDate)}` : 'إلى الآن (مستمر)'}
                                </span>
                                <div className="text-left font-mono">
                                  <span className="text-[10px] text-slate-400 block">إجمالي التغذية:</span>
                                  <span className="font-black text-rose-600 text-xs">{formatCurrency(total, currency)}</span>
                                </div>
                              </div>

                              {period.notes && (
                                <p className="text-[10px] text-slate-500 italic bg-white/60 p-1.5 rounded border border-slate-100">
                                  📝 {period.notes}
                                </p>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Add Transaction Form */}
              <div className="bg-white p-3.5 sm:p-4 rounded-2xl border border-emerald-100 shadow-xs transition-all duration-300">
                <button
                  type="button"
                  onClick={() => setShowAddLedgerForm(!showAddLedgerForm)}
                  className="w-full bg-gradient-to-r from-emerald-600 via-emerald-600 to-emerald-700 hover:from-emerald-700 hover:to-emerald-800 text-white font-extrabold text-sm sm:text-base p-3.5 rounded-xl shadow-md shadow-emerald-600/20 flex items-center justify-between transition-all cursor-pointer select-none active:scale-[0.99] border border-emerald-500/50 text-right"
                >
                  <div className="flex items-center gap-2.5">
                    <div className="p-1.5 bg-white/20 rounded-lg text-white shrink-0">
                      <PlusCircle size={18} />
                    </div>
                    <span className="font-extrabold tracking-wide">إضافة حركة مالية جديدة للكشف</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-950 bg-white/90 hover:bg-white px-3 py-1.5 rounded-lg transition-colors shadow-xs shrink-0">
                    <span>{showAddLedgerForm ? 'طي النموذج ▲' : 'فتح النموذج ▼'}</span>
                  </div>
                </button>

                {showAddLedgerForm && (
                  <form onSubmit={handleAddLedgerSubmit} className="space-y-3.5 mt-4 pt-3.5 border-t border-slate-100 animate-fade-in">
                    {/* Date */}
                    <div className="space-y-1">
                      <label className="text-[11px] font-bold text-slate-500">التاريخ</label>
                      <input 
                        type="date"
                        value={ledgerDate}
                        onChange={(e) => setLedgerDate(e.target.value)}
                        className="w-full h-[42px] px-3 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 text-xs focus:outline-hidden focus:border-sky-500"
                        required
                      />
                    </div>

                    {/* Amounts row & Currency selector */}
                    <div className="grid grid-cols-3 gap-2">
                      <div className="space-y-1 col-span-1">
                        <label className="text-[10px] font-bold text-slate-500 block text-rose-600 truncate">مبلغ عليه</label>
                        <div className="flex gap-1 items-center">
                          <input 
                            type="number"
                            placeholder="0"
                            value={ledgerAmountOnHim}
                            onChange={(e) => setLedgerAmountOnHim(e.target.value)}
                            className="w-full h-[42px] px-3 bg-rose-50/20 border border-slate-200 rounded-lg text-slate-700 text-xs focus:outline-hidden focus:border-rose-500 min-w-0"
                          />
                          <Calculator onApply={(val) => setLedgerAmountOnHim(String(val))} buttonTitle="حسابة مبلغ عليه" />
                        </div>
                        <AmountInWords amount={ledgerAmountOnHim} currency={ledgerCurrency} />
                      </div>
                      <div className="space-y-1 col-span-1">
                        <label className="text-[10px] font-bold text-slate-500 block text-emerald-600 truncate">مبلغ له</label>
                        <div className="flex gap-1 items-center">
                          <input 
                            type="number"
                            placeholder="0"
                            value={ledgerAmountForHim}
                            onChange={(e) => setLedgerAmountForHim(e.target.value)}
                            className="w-full h-[42px] px-3 bg-emerald-50/20 border border-slate-200 rounded-lg text-slate-700 text-xs focus:outline-hidden focus:border-emerald-500 min-w-0"
                          />
                          <Calculator onApply={(val) => setLedgerAmountForHim(String(val))} buttonTitle="حسابة مبلغ له" />
                        </div>
                        <AmountInWords amount={ledgerAmountForHim} currency={ledgerCurrency} />
                      </div>
                      <div className="space-y-1 col-span-1">
                        <label className="text-[10px] font-bold text-slate-500 block truncate">العملة</label>
                        <select
                          value={ledgerCurrency}
                          onChange={(e) => setLedgerCurrency(e.target.value)}
                          className="w-full h-[42px] px-3 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 text-xs focus:outline-hidden focus:border-sky-500 cursor-pointer"
                        >
                          <option value="YER">YER</option>
                          <option value="SAR">SAR</option>
                          <option value="USD">USD</option>
                        </select>
                      </div>
                    </div>

                    {/* Statement */}
                    <div className="space-y-1">
                      <label className="text-[11px] font-bold text-slate-500">البيان (نوع الحركة)</label>
                      <input 
                        type="text"
                        placeholder="مثال: سلفة أسبوعية / أجر شهر حزيران"
                        value={ledgerDescription}
                        onChange={(e) => setLedgerDescription(e.target.value)}
                        className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 text-xs focus:outline-hidden focus:border-sky-500"
                        required
                      />
                    </div>

                    {/* Notes */}
                    <div className="space-y-1">
                      <label className="text-[11px] font-bold text-slate-500">ملاحظات إضافية</label>
                      <textarea 
                        placeholder="أي ملاحظات حول العملية..."
                        value={ledgerNotes}
                        onChange={(e) => setLedgerNotes(e.target.value)}
                        rows={2}
                        className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 text-xs focus:outline-hidden focus:border-sky-500 resize-none"
                      />
                    </div>

                    {ledgerError && (
                      <p className="text-[11px] text-rose-600 font-semibold bg-rose-50 p-2 rounded-lg">{ledgerError}</p>
                    )}

                    <div className="flex gap-2 pt-1">
                      <button 
                        type="submit"
                        className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs py-2.5 px-4 rounded-xl shadow-md shadow-emerald-600/20 transition-colors flex items-center justify-center gap-1.5 cursor-pointer active:scale-98"
                      >
                        <PlusCircle size={15} />
                        حفظ في كشف الحساب
                      </button>
                      <button 
                        type="button"
                        onClick={handleResetAddLedgerForm}
                        className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold text-xs rounded-lg transition-colors flex items-center justify-center gap-1 cursor-pointer"
                        title="إلغاء وتنظيف الحقول"
                      >
                        <RotateCcw size={13} />
                        <span>إلغاء / تنظيف</span>
                      </button>
                    </div>
                  </form>
                )}
              </div>

            </div>

            {/* Right Col: Ledger Transactions Log Table */}
            <div className="lg:col-span-2 space-y-3">
              {/* Ledger Filters Card */}
              <div className="bg-white p-3.5 sm:p-4 rounded-2xl border border-slate-100 shadow-xs transition-all" id="worker-ledger-filters">
                <button
                  type="button"
                  onClick={() => setIsLedgerFiltersOpen(!isLedgerFiltersOpen)}
                  className="w-full flex items-center justify-between text-right font-bold text-slate-700 text-xs sm:text-sm hover:text-slate-900 cursor-pointer select-none"
                >
                  <div className="flex items-center gap-2">
                    <Filter size={16} className="text-sky-500" />
                    <span>أدوات البحث والتصفية (سجل الكشوفات والحركات التفصيلي)</span>
                    {isLedgerFilterActive && (
                      <span className="text-[10px] font-extrabold text-sky-700 bg-sky-50 px-2 py-0.5 rounded-full border border-sky-200">
                        فلتر نشط ({sortedLedger.length} حركات)
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-1.5 text-slate-400 text-xs font-normal">
                    <span className="text-slate-400 text-xs hidden sm:inline">{isLedgerFiltersOpen ? 'إخفاء' : 'عرض الخيارات'}</span>
                    {isLedgerFiltersOpen ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
                  </div>
                </button>
                
                {isLedgerFiltersOpen && (
                  <div className="pt-3 space-y-3 border-t border-slate-100 mt-3 animate-fade-in">
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                      
                      {/* Search text */}
                      <div className="relative col-span-1 sm:col-span-2 lg:col-span-1">
                        <input 
                          type="text"
                          value={ledgerSearchTerm}
                          onChange={(e) => setLedgerSearchTerm(e.target.value)}
                          placeholder="بحث في البيان، الملاحظات..."
                          className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 text-xs pr-8 pl-8 focus:outline-hidden focus:border-sky-500 transition-colors"
                        />
                        <Search size={14} className="absolute top-1/2 -translate-y-1/2 right-2.5 text-slate-400 pointer-events-none" />
                        {ledgerSearchTerm && (
                          <button
                            type="button"
                            onClick={() => setLedgerSearchTerm('')}
                            className="absolute top-1/2 -translate-y-1/2 left-2 p-1 text-slate-400 hover:text-slate-600 hover:bg-slate-200/70 rounded-full transition-colors cursor-pointer"
                            title="إلغاء البحث ومسح النص"
                          >
                            <X size={13} className="stroke-[2.5]" />
                          </button>
                        )}
                      </div>

                      {/* Start Date */}
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-slate-500 shrink-0">من:</span>
                        <input 
                          type="date"
                          value={ledgerStartDate}
                          onChange={(e) => setLedgerStartDate(e.target.value)}
                          className="w-full h-8 px-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 text-xs focus:outline-hidden focus:border-sky-500"
                        />
                      </div>

                      {/* End Date */}
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-slate-500 shrink-0">إلى:</span>
                        <input 
                          type="date"
                          value={ledgerEndDate}
                          onChange={(e) => setLedgerEndDate(e.target.value)}
                          className="w-full h-8 px-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 text-xs focus:outline-hidden focus:border-sky-500"
                        />
                      </div>

                      {/* Sort Order Filter */}
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-slate-500 shrink-0">الترتيب:</span>
                        <select
                          value={ledgerSortOption}
                          onChange={(e) => setLedgerSortOption(e.target.value as any)}
                          className="w-full h-8 px-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 text-xs font-bold focus:outline-hidden focus:border-sky-500 cursor-pointer"
                        >
                          <option value="date-desc">الأحدث أولاً ⬇️ (افتراضي)</option>
                          <option value="date-asc">الأقدم أولاً ⬆️</option>
                          <option value="desc-alpha">أبجدياً حسب البيان (أ - ي) 🔤</option>
                          <option value="amountOnHim-desc">حسب مبلغ عليه (الأعلى أولاً) 🔴</option>
                          <option value="amountForHim-desc">حسب مبلغ له (الأعلى أولاً) 🟢</option>
                        </select>
                      </div>

                      {/* Transaction Type Filter */}
                      <div className="flex items-center gap-2 sm:col-span-2 lg:col-span-2">
                        <span className="text-xs text-slate-500 shrink-0">نوع الحركة:</span>
                        <select
                          value={ledgerTypeFilter}
                          onChange={(e) => setLedgerTypeFilter(e.target.value as 'all' | 'onHim' | 'forHim')}
                          className="w-full h-8 px-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 text-xs font-bold focus:outline-hidden focus:border-sky-500 cursor-pointer"
                        >
                          <option value="all">كافة الحركات المالية (له وعليه)</option>
                          <option value="onHim">مبالغ عليه فقط (سلف / مسحوبات)</option>
                          <option value="forHim">مبالغ له فقط (أجور / مستحقات)</option>
                        </select>
                      </div>

                    </div>

                    {/* Clear filters shortcut */}
                    {isLedgerFilterActive && (
                      <div className="flex justify-end pt-1">
                        <button 
                          type="button"
                          onClick={() => {
                            setLedgerSearchTerm('');
                            setLedgerStartDate('');
                            setLedgerEndDate('');
                            setLedgerTypeFilter('all');
                            setLedgerSortOption('date-desc');
                          }}
                          className="text-[11px] text-sky-600 hover:text-sky-800 hover:underline font-bold cursor-pointer"
                        >
                          إلغاء التصفية وإعادة الضبط 🔄
                        </button>
                      </div>
                    )}
                  </div>
                )}
              </div>

              <div className="bg-white rounded-2xl border border-slate-100 shadow-xs overflow-hidden">
                <div className="p-4 border-b border-slate-100 bg-slate-50/40 flex items-center justify-between gap-3 flex-wrap">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className="font-bold text-slate-800 text-sm">سجل الكشوفات والحركات التفصيلي</h3>
                    {hasActiveWorkerLedgerColumnFilters && (
                      <div className="flex items-center gap-1.5 bg-sky-50 border border-sky-200 text-sky-800 px-2 py-0.5 rounded-lg text-xs font-bold">
                        <Filter size={12} className="fill-current text-sky-600" />
                        <span>تصفية مخصصة للأعمدة</span>
                        <button
                          type="button"
                          onClick={handleClearWorkerLedgerFilters}
                          className="text-[10px] text-sky-600 hover:text-sky-800 hover:underline mr-1 cursor-pointer font-bold"
                        >
                          إلغاء فلاتر الأعمدة ✕
                        </button>
                      </div>
                    )}
                    <span className="text-[10px] text-slate-400 font-bold bg-slate-100 px-2 py-0.5 rounded-md">
                      عدد العمليات: {sortedLedger.length}
                    </span>
                  </div>

                  <div className="text-slate-700 text-xs font-bold flex flex-wrap items-center gap-2 bg-white px-3 py-1.5 rounded-xl border border-slate-100">
                    <span>إجمالي المصفى:</span>
                    {Object.keys(ledgerTotalsByCurrency).length === 0 ? (
                      <span className="text-slate-400">0</span>
                    ) : (
                      (Object.entries(ledgerTotalsByCurrency) as [string, { onHim: number; forHim: number }][]).map(([cur, totals]) => (
                        <div key={cur} className="flex items-center gap-1.5 font-mono text-xs">
                          {totals.forHim > 0 && (
                            <span className="bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded-lg border border-emerald-100 font-extrabold" title="إجمالي له (أجور ومستحقات)">
                              له: {formatCurrency(totals.forHim, cur)}
                            </span>
                          )}
                          {totals.onHim > 0 && (
                            <span className="bg-rose-50 text-rose-700 px-2 py-0.5 rounded-lg border border-rose-100 font-extrabold" title="إجمالي عليه (سلف ومسحوبات)">
                              عليه: {formatCurrency(totals.onHim, cur)}
                            </span>
                          )}
                          {totals.forHim === 0 && totals.onHim === 0 && (
                            <span className="bg-slate-50 text-slate-500 px-2 py-0.5 rounded-lg border border-slate-100 font-extrabold">
                              0 {cur}
                            </span>
                          )}
                        </div>
                      ))
                    )}
                  </div>
                </div>

                <div className="overflow-x-auto">
                  {sortedLedger.length === 0 ? (
                    <div className="text-center py-12 px-4 space-y-2">
                      <p className="text-slate-400 text-sm font-medium">كشف الحساب فارغ حالياً</p>
                      <p className="text-xs text-slate-300">قم بإضافة حركة مالية جديدة أو ترحيل النفقات لهذا العامل</p>
                    </div>
                  ) : (
                    <table className="w-full text-right text-xs resizable-data-table">
                      <thead>
                        <tr className="bg-slate-50 text-slate-500 font-bold">
                          <th className="py-1 px-2.5 relative whitespace-nowrap select-none w-[110px] min-w-[95px]">
                            <div className="flex items-center justify-between gap-1">
                              <span>التاريخ</span>
                              <ExcelColumnFilter
                                config={workerLedgerColumnConfigs.date}
                                data={baseFilteredLedger}
                                allColumnFilters={workerLedgerColumnFilters}
                                allConfigs={workerLedgerColumnConfigs}
                                activeFilter={workerLedgerColumnFilters.date}
                                onFilterChange={handleWorkerLedgerFilterChange}
                                activeSort={workerLedgerColumnSort}
                                onSortChange={handleWorkerLedgerSortChange}
                                accentColor="sky"
                              />
                            </div>
                          </th>
                          <th className="py-1 px-2.5 relative whitespace-nowrap select-none min-w-[200px]">
                            <div className="flex items-center justify-between gap-1">
                              <span>البيان</span>
                              <ExcelColumnFilter
                                config={workerLedgerColumnConfigs.description}
                                data={baseFilteredLedger}
                                allColumnFilters={workerLedgerColumnFilters}
                                allConfigs={workerLedgerColumnConfigs}
                                activeFilter={workerLedgerColumnFilters.description}
                                onFilterChange={handleWorkerLedgerFilterChange}
                                activeSort={workerLedgerColumnSort}
                                onSortChange={handleWorkerLedgerSortChange}
                                accentColor="sky"
                              />
                            </div>
                          </th>
                          <th className="py-1 px-2.5 text-rose-600 relative whitespace-nowrap select-none w-[125px] min-w-[105px]">
                            <div className="flex items-center justify-between gap-1">
                              <span>مبلغ عليه (سلف)</span>
                              <ExcelColumnFilter
                                config={workerLedgerColumnConfigs.amountOnHim}
                                data={baseFilteredLedger}
                                allColumnFilters={workerLedgerColumnFilters}
                                allConfigs={workerLedgerColumnConfigs}
                                activeFilter={workerLedgerColumnFilters.amountOnHim}
                                onFilterChange={handleWorkerLedgerFilterChange}
                                activeSort={workerLedgerColumnSort}
                                onSortChange={handleWorkerLedgerSortChange}
                                accentColor="rose"
                              />
                            </div>
                          </th>
                          <th className="py-1 px-2.5 text-emerald-600 relative whitespace-nowrap select-none w-[125px] min-w-[105px]">
                            <div className="flex items-center justify-between gap-1">
                              <span>مبلغ له (مستحقات)</span>
                              <ExcelColumnFilter
                                config={workerLedgerColumnConfigs.amountForHim}
                                data={baseFilteredLedger}
                                allColumnFilters={workerLedgerColumnFilters}
                                allConfigs={workerLedgerColumnConfigs}
                                activeFilter={workerLedgerColumnFilters.amountForHim}
                                onFilterChange={handleWorkerLedgerFilterChange}
                                activeSort={workerLedgerColumnSort}
                                onSortChange={handleWorkerLedgerSortChange}
                                accentColor="emerald"
                              />
                            </div>
                          </th>
                          <th className="py-1 px-2.5 relative whitespace-nowrap select-none w-[140px] min-w-[100px]">
                            <div className="flex items-center justify-between gap-1">
                              <span>ملاحظات</span>
                              <ExcelColumnFilter
                                config={workerLedgerColumnConfigs.notes}
                                data={baseFilteredLedger}
                                allColumnFilters={workerLedgerColumnFilters}
                                allConfigs={workerLedgerColumnConfigs}
                                activeFilter={workerLedgerColumnFilters.notes}
                                onFilterChange={handleWorkerLedgerFilterChange}
                                activeSort={workerLedgerColumnSort}
                                onSortChange={handleWorkerLedgerSortChange}
                                accentColor="sky"
                              />
                            </div>
                          </th>
                          <th className="py-1 px-2.5 text-center relative whitespace-nowrap select-none w-[80px] min-w-[70px]">
                            <div className="flex items-center justify-center gap-1">
                              <span>إجراءات</span>
                              <ColumnFreezeButton columnTitle="إجراءات" />
                            </div>
                            <ColumnResizeHandle />
                          </th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-50">
                        {sortedLedger.map((e) => (
                          <tr key={e.id} className="hover:bg-slate-50/50 transition-colors">
                            <td className="p-3 text-slate-500 break-words whitespace-normal align-top">{formatDateArabic(e.date)}</td>
                            <td className="p-3 font-semibold text-slate-800 break-words whitespace-normal align-top leading-relaxed">
                              <div className="flex items-center gap-1.5 flex-wrap">
                                <span className="break-words whitespace-normal">{cleanLedgerDescription(e.description)}</span>
                                {e.isNutrition && (
                                  <span className="text-[9px] bg-emerald-50 text-emerald-700 border border-emerald-200 font-bold px-1.5 py-0.5 rounded-sm flex items-center gap-0.5">
                                    <Utensils size={10} />
                                    <span>تغذية مرحلة تلقائياً</span>
                                  </span>
                                )}
                                {e.isPosted && (
                                  <span className="text-[9px] bg-rose-50 text-rose-700 border border-rose-100 font-bold px-1.5 py-0.5 rounded-sm">
                                    مرحلة تلقائياً من النفقات اليومية
                                  </span>
                                )}
                                <AttributionBadge createdBy={e.createdBy} />
                              </div>
                            </td>
                            <td className="p-3 font-bold text-rose-600 break-words whitespace-normal align-top font-mono">
                              {e.amountOnHim > 0 ? formatCurrency(e.amountOnHim, e.currency || 'YER') : '-'}
                            </td>
                            <td className="p-3 font-bold text-emerald-600 break-words whitespace-normal align-top font-mono">
                              {e.amountForHim > 0 ? formatCurrency(e.amountForHim, e.currency || 'YER') : '-'}
                            </td>
                            <td className="p-3 align-top">
                              <AutoFitNotesCell notes={e.notes} titlePrefix="ملاحظات العامل" />
                            </td>
                            <td className="p-3 text-center flex items-center justify-center gap-1.5">
                              {sharedRole !== 'read' && (
                                <button 
                                  onClick={() => {
                                    setCopyMoveModalState({
                                      isOpen: true,
                                      mode: 'copy',
                                      entry: e,
                                      workerId: activeWorker.id,
                                      workerName: activeWorker.name
                                    });
                                  }}
                                  className="p-1 hover:bg-emerald-50 text-slate-300 hover:text-emerald-600 rounded-sm cursor-pointer transition-colors"
                                  title="نسخ العملية إلى حساب آخر"
                                >
                                  <Copy size={13} />
                                </button>
                              )}
                              {sharedRole !== 'read' && (
                                <button 
                                  onClick={() => {
                                    setCopyMoveModalState({
                                      isOpen: true,
                                      mode: 'move',
                                      entry: e,
                                      workerId: activeWorker.id,
                                      workerName: activeWorker.name
                                    });
                                  }}
                                  className="p-1 hover:bg-amber-50 text-slate-300 hover:text-amber-600 rounded-sm cursor-pointer transition-colors"
                                  title="نقل العملية إلى حساب آخر"
                                >
                                  <ArrowRightLeft size={13} />
                                </button>
                              )}
                              {sharedRole !== 'read' && (
                                <button 
                                  onClick={() => {
                                    setEditingWorkerLedger({ workerId: activeWorker.id, entry: e });
                                  }}
                                  className="p-1 hover:bg-slate-50 text-slate-300 hover:text-sky-600 rounded-sm cursor-pointer"
                                  title="تعديل القيد"
                                >
                                  <Pencil size={13} />
                                </button>
                              )}
                              {sharedRole !== 'read' && sharedRole !== 'add' && (
                                <button 
                                  onClick={() => {
                                    if (confirm('هل أنت متأكد من حذف هذه الحركة؟ (سيتم تحديث النفقات اليومية تلقائياً إذا كانت مرحلة)')) {
                                      onDeleteWorkerLedgerEntry(activeWorker.id, e.id);
                                    }
                                  }}
                                  className="p-1 hover:bg-rose-50 text-slate-300 hover:text-rose-500 rounded-sm cursor-pointer"
                                  title="حذف القيد"
                                >
                                  <Trash2 size={13} />
                                </button>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  )}
                </div>
              </div>
            </div>

          </div>

        </div>

      ) : (
        
        /* --------------------------------- DIRECTORY LIST VIEW --------------------------------- */
        <div className="space-y-3 sm:space-y-5 animate-fade-in" id="workers-list-pane">
          
          {/* Header Row */}
          <PageHeaderCard
            title="سجل عمال المشروع وحساب الأجور"
            description="إدارة العمال وتتبع أجورهم اليومية، السلفيات والخصومات مع استخراج كشوفات تفصيلية."
            icon={<Users size={20} />}
            onBack={setActiveTab ? () => setActiveTab('dashboard') : undefined}
            optionsMenu={
              <OptionsMenu 
                onExportExcel={handleExportAllCSV}
                onExportPDF={() => setIsWorkersCustomReportModalOpen(true)}
                onSharePDF={handleShareAllWorkersPDF}
                pdfLabel="طباعة تقرير مخصص"
                onImportExcel={sharedRole !== 'read' ? handleExcelImport : undefined}
                shareTitle="التقرير المالي العام لعمال الموقع"
                shareText={(() => {
                  const workersSummary = workers.map(w => {
                    const grossDays = getWorkerTotalDays(w, sharedRole === 'owner');
                    const absDays = getWorkerAbsenceDays(w);
                    const netDays = getWorkerNetDays(w, sharedRole === 'owner');
                    const totalOnHim = w.ledger.reduce((sum, e) => sum + e.amountOnHim, 0);
                    const totalForHim = w.ledger.reduce((sum, e) => sum + e.amountForHim, 0);
                    const net = totalForHim - totalOnHim;
                    const status = net === 0 ? 'خالص' : net > 0 ? `له: ${formatCurrency(net, currency)}` : `عليه: ${formatCurrency(Math.abs(net), currency)}`;
                    return `- ${w.name} (${w.profession}): ${status} [${netDays} يوم صافي${absDays > 0 ? ` (خصم ${absDays} غياب)` : ''}]`;
                  }).join('\n');

                  return `👷 التقرير المالي العام لعمال الموقع\n📅 تاريخ الاستخراج: ${new Date().toLocaleDateString('ar-EG-u-nu-latn')}\n\n📊 ملخص مستحقات العمال:\n${workers.length === 0 ? 'لا يوجد عمال مسجلين حالياً.' : workersSummary}\n\n*تم توليده ومشاركته من كشوفات المقاولات*`;
                })()}
              />
            }
          />

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-2.5 sm:gap-4">
            
            {/* Column 1: Add Worker Form Card */}
            <div className="bg-white p-2.5 sm:p-3.5 rounded-xl sm:rounded-2xl border border-slate-100 shadow-xs h-fit" id="add-worker-form-container">
              {sharedRole === 'read' ? (
                <div className="text-center py-8 space-y-3">
                  <div className="mx-auto w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center text-slate-400">
                    <User size={24} />
                  </div>
                  <h3 className="font-bold text-slate-800 text-sm">وضع عرض الحساب المشترك</h3>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    تمت دعوتك بصلاحية (عرض فقط). لا يمكنك إضافة عمال جدد أو تسجيل حركات مالية في هذا الكشف.
                  </p>
                </div>
              ) : (
                <>
                  <button
                    type="button"
                    onClick={() => setShowAddWorkerForm(!showAddWorkerForm)}
                    className="w-full bg-gradient-to-r from-emerald-600 via-emerald-600 to-emerald-700 hover:from-emerald-700 hover:to-emerald-800 text-white font-extrabold text-xs sm:text-sm py-2 px-2.5 sm:py-2.5 sm:px-3.5 rounded-lg sm:rounded-xl shadow-xs flex items-center justify-between transition-all cursor-pointer select-none border border-emerald-500/50"
                  >
                    <div className="flex items-center gap-2">
                      <div className="p-1 bg-white/20 rounded-md text-white shrink-0">
                        <UserPlus size={15} />
                      </div>
                      <span className="font-extrabold tracking-wide">إضافة عامل جديد للموقع</span>
                    </div>
                    <span className="text-[10px] sm:text-xs px-2 py-0.5 sm:px-2.5 sm:py-1 rounded-md font-bold flex items-center gap-1 transition-all bg-white/90 text-emerald-950 shadow-xs">
                      {showAddWorkerForm ? 'إخفاء البيانات ▲' : '+ إضافة عامل جديد ▼'}
                    </span>
                  </button>

                  {showAddWorkerForm && (
                    <div className="pt-3 mt-2.5 border-t border-slate-100 animate-slide-up">
                      <form onSubmit={handleAddWorkerSubmit} className="space-y-4">
                        
                        {/* Name */}
                        <div className="space-y-1">
                          <label className="text-xs font-bold text-slate-600 block">الاسم الكامل</label>
                          <div className="relative">
                            <input 
                              type="text" 
                              value={newWorkerName}
                              onChange={(e) => setNewWorkerName(e.target.value)}
                              placeholder="مثال: علي جاسم محمد"
                              className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-sm focus:outline-hidden focus:border-sky-500 transition-colors pr-9"
                              required
                            />
                            <User size={16} className="absolute top-1/2 -translate-y-1/2 right-3 text-slate-400 pointer-events-none" />
                          </div>
                        </div>

                        {/* Profession */}
                        <div className="space-y-1">
                          <label className="text-xs font-bold text-slate-600 block">المهنة / الصفة</label>
                          <div className="relative">
                            <input 
                              type="text" 
                              value={newWorkerProfession}
                              onChange={(e) => setNewWorkerProfession(e.target.value)}
                              placeholder="مثال: خلفة بناء / نجار مسلح / عامل يومي"
                              className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-sm focus:outline-hidden focus:border-sky-500 transition-colors pr-9"
                              required
                            />
                            <Hammer size={16} className="absolute top-1/2 -translate-y-1/2 right-3 text-slate-400 pointer-events-none" />
                          </div>
                        </div>

                        {/* Phone Number(s) */}
                        <PhoneNumbersInput 
                          phoneNumbers={newWorkerPhoneNumbers} 
                          onChange={setNewWorkerPhoneNumbers} 
                        />

                        {/* Start Date */}
                        <div className="space-y-1">
                          <label className="text-xs font-bold text-slate-600 block">تاريخ مباشرة العمل</label>
                          <div className="relative">
                            <input 
                              type="date" 
                              value={newWorkerStartDate}
                              onChange={(e) => setNewWorkerStartDate(e.target.value)}
                              className="w-full h-[42px] px-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-sm focus:outline-hidden focus:border-sky-500 transition-colors pr-9"
                              required
                            />
                            <Calendar size={16} className="absolute top-1/2 -translate-y-1/2 right-3 text-slate-400 pointer-events-none" />
                          </div>
                        </div>

                        {/* End Date */}
                        <div className="space-y-1">
                          <label className="text-xs font-bold text-slate-600 block">تاريخ انتهاء التعاقد / العمل (اختياري)</label>
                          <div className="relative">
                            <input 
                              type="date" 
                              value={newWorkerEndDate}
                              onChange={(e) => setNewWorkerEndDate(e.target.value)}
                              className="w-full h-[42px] px-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-sm focus:outline-hidden focus:border-sky-500 transition-colors pr-9"
                            />
                            <Calendar size={16} className="absolute top-1/2 -translate-y-1/2 right-3 text-slate-400 pointer-events-none" />
                          </div>
                          <span className="text-[10px] text-slate-400">يمكن تركه فارغاً إذا كان العامل مستمراً بالعمل حالياً.</span>
                        </div>

                        {/* Daily Wage (Optional) */}
                        <div className="space-y-1">
                          <label className="text-xs font-bold text-slate-600 block">الأجر اليومي المتفق عليه (اختياري)</label>
                          <div className="relative">
                            <input 
                              type="number"
                              min="0"
                              step="any"
                              value={newWorkerDailyWage}
                              onChange={(e) => setNewWorkerDailyWage(e.target.value)}
                              placeholder="0 (اتركه فارغاً للسندات اليدوية)"
                              className="w-full h-[42px] px-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-sm font-bold font-mono focus:outline-hidden focus:border-amber-500 transition-colors pr-9"
                            />
                            <Coins size={16} className="absolute top-1/2 -translate-y-1/2 right-3 text-slate-400 pointer-events-none" />
                          </div>
                          <span className="text-[10px] text-slate-400">إذا حُدد، سيقوم النظام تلقائياً بضرب الأجر في صافي أيام العمل بعد خصم الغياب.</span>
                        </div>

                        {/* Notes */}
                        <div className="space-y-1">
                          <label className="text-xs font-bold text-slate-600 block">ملاحظات (اختياري)</label>
                          <textarea 
                            value={newWorkerNotes}
                            onChange={(e) => setNewWorkerNotes(e.target.value)}
                            placeholder="أي ملاحظات تفصيلية عن العامل أو الاتفاق..."
                            rows={2}
                            className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-xs focus:outline-hidden focus:border-sky-500 transition-colors resize-none"
                          />
                        </div>

                        {/* Alerts */}
                        {workerError && (
                          <p className="text-xs text-rose-600 font-semibold bg-rose-50 p-2.5 rounded-xl border border-rose-100">{workerError}</p>
                        )}

                        {/* Dynamic Work Days Box */}
                        {newWorkerStartDate && (
                          <div className="space-y-2">
                            <div className="p-3 bg-sky-50 border border-sky-100 rounded-xl flex items-center justify-between text-xs text-slate-600">
                              <span className="font-semibold flex items-center gap-1.5">
                                <Clock size={14} className="text-sky-500" />
                                المدة الإجمالية:
                              </span>
                              <span className="font-bold text-sky-700 text-sm">
                                {calculateDaysOfWork(newWorkerStartDate, newWorkerEndDate, sharedRole === 'owner')} {newWorkerEndDate ? 'يوم عمل' : 'يوم عمل حتى الآن'}
                              </span>
                            </div>

                            <div className="p-3 bg-violet-50/70 border border-violet-100 rounded-xl space-y-1.5 text-right">
                              <span className="text-[11px] text-violet-700 font-bold block">عدد أيام العمل الفعلية (مربع نص تلقائي):</span>
                              <input
                                type="text"
                                readOnly
                                value={sharedRole === 'owner' ? `${calculateActualDaysOfWork(newWorkerStartDate, newWorkerEndDate, true)} يوم عمل فعلي` : 'غير متاح لحسابات المشاركة'}
                                className="w-full text-center p-2 bg-white border border-violet-200 rounded-xl text-violet-800 text-xs font-extrabold focus:outline-hidden"
                              />
                            </div>
                          </div>
                        )}

                        <div className="flex gap-2 pt-1">
                          <button 
                            type="submit"
                            className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm py-2.5 px-4 rounded-xl shadow-md shadow-emerald-600/20 transition-colors flex items-center justify-center gap-2 cursor-pointer active:scale-98"
                          >
                            <PlusCircle size={18} />
                            تسجيل العامل
                          </button>
                          <button 
                            type="button"
                            onClick={handleResetAddWorkerForm}
                            className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold text-xs rounded-xl transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                            title="إلغاء وتنظيف الحقول"
                          >
                            <RotateCcw size={15} />
                            <span>إلغاء / تنظيف</span>
                          </button>
                        </div>
                      </form>
                    </div>
                  )}
                </>
              )}
            </div>

            {/* Column 2 & 3: Workers list table */}
            <div className="lg:col-span-2 space-y-2.5 sm:space-y-4">
              
              {/* Search Card & Sort Filter */}
              <div className="bg-white p-2.5 sm:p-4 rounded-xl sm:rounded-2xl border border-slate-100 shadow-xs flex flex-col sm:flex-row items-center gap-2 sm:gap-3">
                <div className="relative flex-1 w-full">
                  <input 
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="ابحث عن عامل بالاسم أو المهنة..."
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-xs pr-8 pl-8 focus:outline-hidden focus:border-sky-500 transition-colors"
                  />
                  <Search size={14} className="absolute top-1/2 -translate-y-1/2 right-2.5 text-slate-400 pointer-events-none" />
                  {searchQuery && (
                    <button
                      type="button"
                      onClick={() => setSearchQuery('')}
                      className="absolute top-1/2 -translate-y-1/2 left-2 p-1 text-slate-400 hover:text-slate-600 hover:bg-slate-200/70 rounded-full transition-colors cursor-pointer"
                      title="إلغاء البحث ومسح النص"
                    >
                      <X size={13} className="stroke-[2.5]" />
                    </button>
                  )}
                </div>
                
                {/* Workers Sort Filter */}
                <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-xs shrink-0 w-full sm:w-auto">
                  <span className="text-slate-400 font-medium">الترتيب:</span>
                  <select
                    value={workerSortOrder}
                    onChange={(e) => setWorkerSortOrder(e.target.value as 'asc' | 'desc')}
                    className="bg-transparent text-slate-700 font-bold focus:outline-none cursor-pointer text-xs"
                  >
                    <option value="desc">تاريخ البدء: الأحدث أولاً ⬇️ (افتراضي)</option>
                    <option value="asc">تاريخ البدء: الأقدم أولاً ⬆️</option>
                  </select>
                </div>
              </div>

              {/* Workers Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5 sm:gap-3.5">
                {sortedWorkers.length === 0 ? (
                  <div className="bg-white p-12 text-center rounded-2xl border border-slate-100 shadow-xs md:col-span-2">
                    <p className="text-slate-400 text-sm font-medium">لا يوجد عمال يطابقون البحث</p>
                    <p className="text-xs text-slate-300 mt-1">أدخل عمالاً جدداً للبدء</p>
                  </div>
                ) : (
                  sortedWorkers.map(w => {
                    const grossDays = getWorkerTotalDays(w, sharedRole === 'owner');
                    const absDays = getWorkerAbsenceDays(w);
                    const netDays = getWorkerNetDays(w, sharedRole === 'owner');
                    const totalOnHim = w.ledger.reduce((sum, e) => sum + e.amountOnHim, 0);
                    const totalForHim = w.ledger.reduce((sum, e) => sum + e.amountForHim, 0);
                    const net = totalForHim - totalOnHim;
                    
                    return (
                      <div 
                        key={w.id} 
                        className="bg-white rounded-xl sm:rounded-2xl border border-slate-100 shadow-xs p-3 sm:p-4 hover:border-sky-200 transition-all flex flex-col justify-between group relative"
                        id={`worker-card-${w.id}`}
                      >
                        {/* Header card */}
                        <div className="space-y-1 sm:space-y-1.5">
                          <div className="flex items-start justify-between gap-2">
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-1.5 flex-wrap">
                                <h4 className="font-bold text-slate-800 text-sm sm:text-base">{w.name}</h4>
                                {(() => {
                                  const status = getPersonWorkStatus(w.endDate);
                                  return (
                                    <span className={`text-[9px] sm:text-[10px] px-1.5 py-0.2 sm:px-2 sm:py-0.5 rounded-full font-bold border ${status.badgeClass} inline-flex items-center gap-1 shrink-0`}>
                                      <span className={`w-1.5 h-1.5 rounded-full ${status.isStopped ? 'bg-rose-500' : 'bg-emerald-500'}`}></span>
                                      {status.statusText}
                                    </span>
                                  );
                                })()}
                                <AttributionBadge createdBy={w.createdBy} updatedBy={w.updatedBy} />
                              </div>
                              <p className="text-[11px] sm:text-xs text-slate-400 mt-0.5">{w.profession}</p>
                            </div>
                            <span className="text-[9px] sm:text-[10px] bg-slate-50 text-slate-600 font-bold px-2 py-0.5 rounded-full border border-slate-100 shrink-0 font-mono" title={`إجمالي فترة العمل: ${grossDays} يوم ${absDays > 0 ? `(خصم غياب: ${absDays} يوم)` : ''}`}>
                              {netDays} يوم صافي {absDays > 0 ? <span className="text-rose-600">(-{absDays})</span> : ''}
                            </span>
                          </div>
                          
                          <div className="text-[10px] sm:text-[11px] text-slate-400 pt-0.5 flex items-center gap-1">
                            <Calendar size={12} />
                            <span>{formatDateArabic(w.startDate)} ⇠ {w.endDate ? formatDateArabic(w.endDate) : 'الآن (مستمر)'}</span>
                          </div>

                          <PhoneNumbersDisplay phoneNumbers={w.phoneNumbers} className="pt-0.5" />

                          {w.notes && (
                            <div className="mt-1 text-[10px] sm:text-[11px] text-slate-600 bg-slate-50 border border-slate-100 p-1.5 rounded-lg text-right font-medium">
                              <span className="font-bold text-slate-400 text-[9px] block mb-0.5">ملاحظات:</span>
                              {w.notes}
                            </div>
                          )}
                        </div>

                        {/* Balances per currency */}
                        {(() => {
                          const workerBalances = w.ledger.reduce((acc, entry) => {
                            const cur = entry.currency || 'YER';
                            if (!acc[cur]) acc[cur] = { onHim: 0, forHim: 0 };
                            acc[cur].onHim += entry.amountOnHim || 0;
                            acc[cur].forHim += entry.amountForHim || 0;
                            return acc;
                          }, {} as Record<string, { onHim: number; forHim: number }>);

                          return (
                            <div className="mt-2.5 pt-2 border-t border-slate-100 space-y-1 text-xs text-right">
                              <span className="text-slate-400 block text-[9px] sm:text-[10px] font-bold">حسابات المستحقات بالعملة:</span>
                              {Object.keys(workerBalances).length === 0 ? (
                                <div className="flex justify-between items-center text-[10px] sm:text-[11px] text-slate-500 font-mono">
                                  <span>YER</span>
                                  <span className="font-bold text-slate-400">خالص الطرفين</span>
                                </div>
                              ) : (
                                Object.entries(workerBalances).map(([cur, b]) => {
                                  const netVal = b.forHim - b.onHim;
                                  return (
                                    <div key={cur} className="flex justify-between items-center border-b border-dashed border-slate-100 last:border-0 pb-0.5 last:pb-0 font-mono text-[10px] sm:text-[11px]">
                                      <span className="text-slate-500 font-bold">{cur}</span>
                                      <span className={netVal < 0 ? 'text-rose-600 font-extrabold' : netVal > 0 ? 'text-emerald-600 font-extrabold' : 'text-slate-400'}>
                                        {netVal === 0 ? 'خالص' : netVal > 0 ? `له: ${formatCurrency(netVal, cur)}` : `عليه: ${formatCurrency(Math.abs(netVal), cur)}`}
                                      </span>
                                    </div>
                                  );
                                })
                              )}
                            </div>
                          );
                        })()}

                        {/* Action section footer */}
                        <div className="flex items-center justify-between mt-2.5 pt-2 border-t border-slate-100">
                          <span className="text-[11px] sm:text-xs font-bold text-slate-400">كشف الحساب:</span>
                          
                          <div className="flex items-center gap-1 sm:gap-1.5">
                            <button 
                              onClick={() => setSelectedWorkerId(w.id)}
                              className="bg-slate-50 hover:bg-sky-50 text-sky-600 font-bold text-[11px] sm:text-xs py-1 px-2.5 sm:py-1.5 sm:px-3 rounded-lg border border-slate-200 group-hover:border-sky-200 transition-colors cursor-pointer flex items-center gap-1"
                            >
                              عرض الكشف
                              <ChevronLeft size={13} className="rotate-180" />
                            </button>
                            {sharedRole !== 'read' && (
                              <button 
                                onClick={() => setEditingWorker(w)}
                                className="p-1 sm:p-1.5 hover:bg-slate-50 text-slate-400 hover:text-slate-700 rounded-lg transition-colors cursor-pointer"
                                title="تعديل بيانات وتواريخ العامل"
                              >
                                <Pencil size={13} />
                              </button>
                            )}
                            {sharedRole !== 'read' && onTransferWorkerToEmployee && (
                              <button 
                                onClick={() => {
                                  if (confirm(`هل ترغب بنقل العامل "${w.name}" إلى نافذة الموظفين؟`)) {
                                    onTransferWorkerToEmployee(w);
                                  }
                                }}
                                className="p-1 sm:p-1.5 hover:bg-indigo-50 text-indigo-500 hover:text-indigo-700 rounded-lg transition-colors cursor-pointer"
                                title="نقل الي الموظفين"
                              >
                                <ArrowRightLeft size={13} />
                              </button>
                            )}
                            {sharedRole !== 'read' && sharedRole !== 'add' && (
                              <button 
                                onClick={() => {
                                  if (confirm(`هل أنت متأكد من حذف العامل ${w.name}؟ سيتم حذف كافة سجلات كشف حسابه تلقائياً.`)) {
                                    onDeleteWorker(w.id);
                                  }
                                }}
                                className="p-1 sm:p-1.5 hover:bg-rose-50 text-slate-300 hover:text-rose-600 rounded-lg transition-colors cursor-pointer"
                                title="حذف العامل"
                              >
                                <Trash2 size={13} />
                              </button>
                            )}
                          </div>
                        </div>

                      </div>
                    );
                  })
                )}
              </div>
            </div>

          </div>

        </div>
      )}

      {/* Edit Worker Modal */}
      {editingWorker && (
        <div 
          className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-2.5 sm:p-4 overflow-y-auto dir-rtl text-right overscroll-contain"
          onTouchMove={(e) => {
            if (e.target === e.currentTarget) e.preventDefault();
          }}
        >
          <div 
            className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-md w-full animate-scale-up my-auto max-h-[88vh] sm:max-h-[90vh] flex flex-col overflow-hidden overscroll-contain"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-4 border-b border-slate-100 flex items-center justify-between shrink-0 bg-white">
              <h3 className="font-bold text-slate-800 text-base sm:text-lg">تعديل بيانات العامل</h3>
              <button
                type="button"
                onClick={() => setEditingWorker(null)}
                className="p-1 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100 cursor-pointer"
              >
                ✕
              </button>
            </div>
            <form onSubmit={handleEditWorkerSubmit} className="flex flex-col flex-1 overflow-hidden min-h-0">
              <div className="p-4 overflow-y-auto space-y-4 flex-1 min-h-0 overscroll-contain touch-pan-y custom-scrollbar modal-scroll-area">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-600 block">اسم العامل</label>
                  <input 
                    type="text" 
                    value={editingWorker.name}
                    onChange={(e) => setEditingWorker({ ...editingWorker, name: e.target.value })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-sm focus:outline-hidden focus:border-sky-500"
                    required
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-600 block">المهنة / التخصص</label>
                  <input 
                    type="text" 
                    value={editingWorker.profession}
                    onChange={(e) => setEditingWorker({ ...editingWorker, profession: e.target.value })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-sm focus:outline-hidden focus:border-sky-500"
                    required
                  />
                </div>

                <PhoneNumbersInput 
                  phoneNumbers={editingWorker.phoneNumbers || ['']} 
                  onChange={(phones) => setEditingWorker({ ...editingWorker, phoneNumbers: phones })} 
                />
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-600 block">تاريخ بدء العمل</label>
                  <input 
                    type="date" 
                    value={editingWorker.startDate}
                    onChange={(e) => setEditingWorker({ ...editingWorker, startDate: e.target.value })}
                    className="w-full h-[42px] px-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-sm focus:outline-hidden focus:border-sky-500"
                    required
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-600 block">تاريخ الانتهاء (اختياري)</label>
                  <input 
                    type="date" 
                    value={editingWorker.endDate || ''}
                    onChange={(e) => setEditingWorker({ ...editingWorker, endDate: e.target.value })}
                    className="w-full h-[42px] px-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-sm focus:outline-hidden focus:border-sky-500"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-600 block">الأجر اليومي المتفق عليه (اختياري)</label>
                  <div className="flex items-center gap-2">
                    <input 
                      type="number" 
                      min="0"
                      step="any"
                      value={editingWorker.dailyWage || ''}
                      onChange={(e) => setEditingWorker({ ...editingWorker, dailyWage: parseFloat(e.target.value) || 0 })}
                      placeholder="0 (اتركه فارغاً للسندات اليدوية)"
                      className="w-full h-[42px] px-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-sm font-bold font-mono focus:outline-hidden focus:border-amber-500"
                    />
                    <span className="text-xs font-bold text-slate-500 bg-slate-100 px-3 py-2.5 rounded-xl border border-slate-200 shrink-0">
                      {editingWorker.dailyWageCurrency || currency}
                    </span>
                  </div>
                  <span className="text-[10px] text-slate-400">يُضرب تلقائياً في صافي أيام العمل بعد خصم الغياب.</span>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-600 block">ملاحظات (اختياري)</label>
                  <textarea 
                    value={editingWorker.notes || ''}
                    onChange={(e) => setEditingWorker({ ...editingWorker, notes: e.target.value })}
                    rows={2}
                    placeholder="أي ملاحظات..."
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-xs focus:outline-hidden focus:border-sky-500 resize-none"
                  />
                </div>

                {editingWorker.startDate && (
                  <div className="space-y-2">
                    <div className="p-3 bg-sky-50 border border-sky-100 rounded-xl flex items-center justify-between text-xs text-slate-600">
                      <span className="font-semibold flex items-center gap-1.5">
                        <Clock size={14} className="text-sky-500" />
                        المدة الإجمالية:
                      </span>
                      <span className="font-bold text-sky-700 text-sm">
                        {calculateDaysOfWork(editingWorker.startDate, editingWorker.endDate, sharedRole === 'owner')} {editingWorker.endDate ? 'يوم عمل' : 'يوم عمل حتى الآن'}
                      </span>
                    </div>

                    <div className="p-3 bg-violet-50/70 border border-violet-100 rounded-xl space-y-1.5 text-right">
                      <span className="text-[11px] text-violet-700 font-bold block">عدد أيام العمل الفعلية (مربع نص تلقائي):</span>
                      <input
                        type="text"
                        readOnly
                        value={sharedRole === 'owner' ? `${calculateActualDaysOfWork(editingWorker.startDate, editingWorker.endDate, true)} يوم عمل فعلي` : 'غير متاح لحسابات المشاركة'}
                        className="w-full text-center p-2 bg-white border border-violet-200 rounded-xl text-violet-800 text-xs font-extrabold focus:outline-hidden"
                      />
                    </div>
                  </div>
                )}
              </div>
              <div className="flex justify-end gap-2 p-3.5 bg-slate-50 border-t border-slate-100 shrink-0">
                <button 
                  type="button" 
                  onClick={() => setEditingWorker(null)}
                  className="bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold text-xs py-2 px-4 rounded-xl transition-colors cursor-pointer"
                >
                  إلغاء / إغلاق
                </button>
                <button 
                  type="submit"
                  className="bg-sky-600 hover:bg-sky-700 text-white font-bold text-xs py-2 px-4 rounded-xl shadow-xs transition-colors cursor-pointer"
                >
                  حفظ التعديلات
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Worker Ledger Entry Modal */}
      {editingWorkerLedger && (
        <div 
          className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-2.5 sm:p-4 overflow-y-auto dir-rtl text-right overscroll-contain"
          onTouchMove={(e) => {
            if (e.target === e.currentTarget) e.preventDefault();
          }}
        >
          <div 
            className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-md w-full animate-scale-up my-auto max-h-[88vh] sm:max-h-[90vh] flex flex-col overflow-hidden overscroll-contain"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-4 border-b border-slate-100 flex items-center justify-between shrink-0 bg-white">
              <h3 className="font-bold text-slate-800 text-base sm:text-lg">تعديل قيد كشف الحساب</h3>
              <button
                type="button"
                onClick={() => setEditingWorkerLedger(null)}
                className="p-1 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100 cursor-pointer"
              >
                ✕
              </button>
            </div>
            <form onSubmit={handleEditWorkerLedgerSubmit} className="flex flex-col flex-1 overflow-hidden min-h-0">
              <div className="p-4 overflow-y-auto space-y-4 flex-1 min-h-0 overscroll-contain touch-pan-y custom-scrollbar modal-scroll-area">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-600 block">التاريخ</label>
                  <input 
                    type="date" 
                    value={editingWorkerLedger.entry.date}
                    onChange={(e) => setEditingWorkerLedger({
                      ...editingWorkerLedger,
                      entry: { ...editingWorkerLedger.entry, date: e.target.value }
                    })}
                    className="w-full h-[42px] px-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-sm focus:outline-hidden focus:border-sky-500"
                    required
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-600 block">مبلغ عليه (سلف / دفعات)</label>
                    <div className="flex gap-1.5 items-center">
                      <input 
                        type="number" 
                        value={editingWorkerLedger.entry.amountOnHim || ''}
                        onChange={(e) => setEditingWorkerLedger({
                          ...editingWorkerLedger,
                          entry: { ...editingWorkerLedger.entry, amountOnHim: parseFloat(e.target.value) || 0 }
                        })}
                        className="w-full h-[42px] px-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-sm focus:outline-hidden focus:border-sky-500 font-mono text-left min-w-0"
                        placeholder="0"
                      />
                      <Calculator onApply={(val) => setEditingWorkerLedger({
                        ...editingWorkerLedger,
                        entry: { ...editingWorkerLedger.entry, amountOnHim: val }
                      })} buttonTitle="حسابة مبلغ عليه" />
                    </div>
                    <AmountInWords amount={editingWorkerLedger.entry.amountOnHim} currency={editingWorkerLedger.entry.currency || 'YER'} />
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-600 block">مبلغ له (مستحقات / أجر)</label>
                    <div className="flex gap-1.5 items-center">
                      <input 
                        type="number" 
                        value={editingWorkerLedger.entry.amountForHim || ''}
                        onChange={(e) => setEditingWorkerLedger({
                          ...editingWorkerLedger,
                          entry: { ...editingWorkerLedger.entry, amountForHim: parseFloat(e.target.value) || 0 }
                        })}
                        className="w-full h-[42px] px-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-sm focus:outline-hidden focus:border-sky-500 font-mono text-left min-w-0"
                        placeholder="0"
                      />
                      <Calculator onApply={(val) => setEditingWorkerLedger({
                        ...editingWorkerLedger,
                        entry: { ...editingWorkerLedger.entry, amountForHim: val }
                      })} buttonTitle="حسابة مبلغ له" />
                    </div>
                    <AmountInWords amount={editingWorkerLedger.entry.amountForHim} currency={editingWorkerLedger.entry.currency || 'YER'} />
                  </div>
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-600 block">العملة</label>
                  <select 
                    value={editingWorkerLedger.entry.currency || 'YER'}
                    onChange={(e) => setEditingWorkerLedger({
                      ...editingWorkerLedger,
                      entry: { ...editingWorkerLedger.entry, currency: e.target.value }
                    })}
                    className="w-full h-[42px] px-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-sm focus:outline-hidden focus:border-sky-500 cursor-pointer"
                  >
                    <option value="YER">ريال يمني (YER)</option>
                    <option value="SAR">ريال سعودي (SAR)</option>
                    <option value="USD">دولار أمريكي (USD)</option>
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-600 block">البيان (نوع الحركة)</label>
                  <input 
                    type="text" 
                    value={editingWorkerLedger.entry.description}
                    onChange={(e) => setEditingWorkerLedger({
                      ...editingWorkerLedger,
                      entry: { ...editingWorkerLedger.entry, description: e.target.value }
                    })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-sm focus:outline-hidden focus:border-sky-500"
                    required
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-600 block">ملاحظات</label>
                  <textarea 
                    value={editingWorkerLedger.entry.notes || ''}
                    onChange={(e) => setEditingWorkerLedger({
                      ...editingWorkerLedger,
                      entry: { ...editingWorkerLedger.entry, notes: e.target.value }
                    })}
                    rows={2}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-sm focus:outline-hidden focus:border-sky-500 resize-none"
                  />
                </div>
              </div>
              <div className="flex justify-end gap-2 p-3.5 bg-slate-50 border-t border-slate-100 shrink-0">
                <button 
                  type="button" 
                  onClick={() => setEditingWorkerLedger(null)}
                  className="bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold text-xs py-2 px-4 rounded-xl transition-colors cursor-pointer"
                >
                  إلغاء / إغلاق
                </button>
                <button 
                  type="submit"
                  className="bg-sky-600 hover:bg-sky-700 text-white font-bold text-xs py-2 px-4 rounded-xl shadow-xs transition-colors cursor-pointer"
                >
                  حفظ التعديلات
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Nutrition Modal "بيانات التغذية" */}
      {showNutritionModal && activeWorker && (
        <div 
          className="fixed inset-0 z-[100] bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto animate-fade-in dir-rtl text-right overscroll-contain"
          onTouchMove={(e) => {
            if (e.target === e.currentTarget) e.preventDefault();
          }}
        >
          <div 
            className="bg-white rounded-3xl shadow-2xl border border-slate-100 max-w-lg w-full overflow-hidden my-auto animate-scale-up overscroll-contain max-h-[88vh] sm:max-h-[90vh] flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="bg-gradient-to-r from-emerald-700 to-teal-800 text-white p-4 sm:p-5 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-white/10 rounded-xl">
                  <Utensils size={20} className="text-emerald-200" />
                </div>
                <div>
                  <h3 className="font-extrabold text-base">بيانات التغذية</h3>
                  <p className="text-xs text-emerald-100">للعامل الرئيسي أو العمال المساعدين التابعين له</p>
                </div>
              </div>
              <button 
                type="button"
                onClick={() => setShowNutritionModal(false)}
                className="p-1.5 text-emerald-200 hover:text-white hover:bg-white/10 rounded-xl transition-colors cursor-pointer"
              >
                <X size={20} />
              </button>
            </div>

            {/* Modal Form */}
            <form onSubmit={handleNutritionSubmit} className="flex flex-col flex-1 overflow-hidden min-h-0">
              <div className="p-4 sm:p-5 space-y-4 flex-1 overflow-y-auto min-h-0 overscroll-contain touch-pan-y custom-scrollbar modal-scroll-area">
              
              {/* Worker Name */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 block">
                  اسم العمال / المساعد <span className="text-rose-500">*</span>
                </label>
                <input 
                  type="text"
                  value={nutrWorkerName}
                  onChange={(e) => setNutrWorkerName(e.target.value)}
                  placeholder="أدخل اسم العامل الرئيسي أو المساعد"
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 text-xs focus:outline-hidden focus:border-emerald-500 focus:bg-white transition-all"
                  required
                />
              </div>

              {/* Daily Amount */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 block">
                  مبلغ التغذية اليومية للعامل ({currency}) <span className="text-rose-500">*</span>
                </label>
                <div className="flex gap-1.5 items-center">
                  <input 
                    type="number"
                    value={nutrDailyAmount}
                    onChange={(e) => setNutrDailyAmount(e.target.value)}
                    placeholder="مثال: 5000"
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 text-xs font-mono font-bold focus:outline-hidden focus:border-emerald-500 focus:bg-white transition-all min-w-0"
                    required
                  />
                  <Calculator onApply={(val) => setNutrDailyAmount(String(val))} buttonTitle="حسابة المبلغ اليومي" />
                </div>
                <AmountInWords amount={nutrDailyAmount} currency={currency} />
              </div>

              {/* Dates Row */}
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700 block">
                    تاريخ البدء <span className="text-rose-500">*</span>
                  </label>
                  <input 
                    type="date"
                    value={nutrStartDate}
                    onChange={(e) => setNutrStartDate(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 text-xs focus:outline-hidden focus:border-emerald-500 focus:bg-white transition-all"
                    required
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700 block">
                    تاريخ الانتهاء <span className="text-slate-400 font-normal">(اختياري)</span>
                  </label>
                  <input 
                    type="date"
                    value={nutrEndDate}
                    onChange={(e) => setNutrEndDate(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 text-xs focus:outline-hidden focus:border-emerald-500 focus:bg-white transition-all"
                  />
                  <span className="text-[10px] text-slate-400 block">* اتركه فارغاً إذا كانت الفترة مستمرة.</span>
                </div>
              </div>

              {/* Dynamic Real-Time Calculation Box */}
              {(() => {
                const calcDays = calculateNutritionDays(nutrStartDate, nutrEndDate);
                const dailyVal = parseFloat(nutrDailyAmount) || 0;
                const calcTotal = dailyVal * calcDays;
                const isOngoing = !nutrEndDate;

                return (
                  <div className="p-3.5 bg-emerald-50/70 border border-emerald-200/80 rounded-2xl space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-bold text-emerald-900">حالة فترة التغذية:</span>
                      <span className={`px-2.5 py-0.5 rounded-full text-xs font-extrabold ${
                        isOngoing 
                          ? 'bg-emerald-100 text-emerald-800 border border-emerald-300' 
                          : 'bg-sky-100 text-sky-800 border border-sky-300'
                      }`}>
                        {isOngoing ? '🟢 مستمرة (غير محددة بنهاية)' : '🔵 مكتملة'}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-xs pt-1 border-t border-emerald-200/50">
                      <div className="bg-white p-2 rounded-xl border border-emerald-100 text-center">
                        <span className="text-[10px] text-slate-500 block">عدد أيام التغذية:</span>
                        <span className="font-black text-emerald-800 text-sm">{calcDays} يوم</span>
                      </div>
                      <div className="bg-white p-2 rounded-xl border border-emerald-100 text-center">
                        <span className="text-[10px] text-slate-500 block">إجمالي التغذية المحتسب:</span>
                        <span className="font-black text-rose-600 text-sm">{formatCurrency(calcTotal, currency)}</span>
                      </div>
                    </div>
                  </div>
                );
              })()}

              {/* Notes */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 block">ملاحظات</label>
                <textarea 
                  value={nutrNotes}
                  onChange={(e) => setNutrNotes(e.target.value)}
                  placeholder="أي ملاحظات إضافية حول التغذية..."
                  rows={2}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 text-xs focus:outline-hidden focus:border-emerald-500 focus:bg-white resize-none"
                />
              </div>

              {nutrFormError && (
                <p className="text-xs font-bold text-rose-600 bg-rose-50 p-2.5 rounded-xl border border-rose-200">{nutrFormError}</p>
              )}

              </div>

              {/* Modal Action Buttons */}
              <div className="flex items-center justify-between gap-2 p-3.5 sm:p-4 bg-slate-50 border-t border-slate-100 shrink-0">
                {editingNutritionPeriod && sharedRole !== 'read' ? (
                  <button
                    type="button"
                    onClick={() => {
                      const confirmText = `هل أنت متأكد من حذف فترة التغذية الخاصة بـ "${editingNutritionPeriod.workerName}"؟`;
                      if (typeof window === 'undefined' || !window.confirm || window.confirm(confirmText)) {
                        onDeleteWorkerNutritionPeriod?.(activeWorker.id, editingNutritionPeriod.id);
                        setShowNutritionModal(false);
                      }
                    }}
                    className="px-3.5 py-2 text-xs font-bold text-rose-600 bg-rose-50 hover:bg-rose-100 rounded-xl transition-colors cursor-pointer flex items-center gap-1.5"
                  >
                    <Trash2 size={13} />
                    <span>حذف الفترة</span>
                  </button>
                ) : <div />}

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setShowNutritionModal(false)}
                    className="px-4 py-2 text-xs font-bold text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors cursor-pointer"
                  >
                    إلغاء / إغلاق
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl transition-colors shadow-xs cursor-pointer flex items-center gap-1.5"
                  >
                    <Utensils size={14} />
                    <span>{editingNutritionPeriod ? 'حفظ التعديلات' : 'إضافة التغذية وحفظ الكشف'}</span>
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Copy / Move Ledger Entry Modal */}
      <CopyMoveLedgerModal
        isOpen={copyMoveModalState.isOpen}
        mode={copyMoveModalState.mode}
        entry={copyMoveModalState.entry}
        sourceType="worker"
        sourceId={copyMoveModalState.workerId}
        sourceName={copyMoveModalState.workerName}
        workers={workers}
        employees={employees}
        suppliers={suppliers}
        currency={currency}
        onClose={() => setCopyMoveModalState(prev => ({ ...prev, isOpen: false }))}
        onConfirm={(mode, sType, sId, entry, tType, tId) => {
          if (mode === 'copy') {
            onCopyLedgerEntry?.(sType, sId, entry, tType, tId);
          } else {
            onMoveLedgerEntry?.(sType, sId, entry, tType, tId);
          }
        }}
      />

      {/* Quick Daily Wage Modal */}
      {showQuickWageModal && activeWorker && (
        <div className="fixed inset-0 z-[110] bg-slate-900/60 backdrop-blur-2xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 max-w-sm w-full space-y-4 text-right dir-rtl shadow-2xl border border-amber-200 animate-scale-up">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2 text-amber-600 font-extrabold text-sm">
                <Coins size={18} />
                <span>تحديد الأجر اليومي للعامل</span>
              </div>
              <button
                type="button"
                onClick={() => setShowQuickWageModal(false)}
                className="p-1 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
              >
                <X size={16} />
              </button>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed">
              عند تحديد الأجر اليومي، سيقوم النظام تلقائياً بضرب الأجر في <strong>صافي أيام العمل المستحقة</strong> (بعد خصم الغياب) وتحديث المستحق المالي بكشف الحساب فوراً.
            </p>

            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700 block">الأجر اليومي ({activeWorker.dailyWageCurrency || currency}):</label>
              <input
                type="number"
                min="0"
                step="any"
                value={quickDailyWage}
                onChange={(e) => setQuickDailyWage(e.target.value)}
                placeholder="أدخل الأجر اليومي المتفق عليه..."
                className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold text-slate-800 font-mono focus:outline-hidden focus:border-amber-500"
                autoFocus
              />
              <span className="text-[10px] text-slate-400 block">
                اتركه فارغاً أو 0 لإلغاء الاحتساب التلقائي والاعتماد على إدخال السندات اليدوي.
              </span>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setShowQuickWageModal(false)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl cursor-pointer"
              >
                إلغاء / إغلاق
              </button>
              <button
                type="button"
                onClick={handleQuickWageSave}
                className="px-5 py-2 bg-amber-600 hover:bg-amber-700 text-white text-xs font-black rounded-xl shadow-xs cursor-pointer flex items-center gap-1.5"
              >
                <Check size={14} />
                <span>حفظ واحتساب الأجر</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Custom Report Options Modal for Workers */}
      <CustomReportOptionsModal
        isOpen={isWorkersCustomReportModalOpen}
        onClose={() => setIsWorkersCustomReportModalOpen(false)}
        onConfirm={(reportType) => handlePrintAllWorkersPDF(reportType)}
        title="خيارات طباعة تقرير مخصص للعمال"
        subtitle="اختر هيئة وصيغة التقرير المالي للعمال المطلوب استخراجه وطباعته (PDF)"
        detailedTitle="تقرير شامل وتفصيلي (كافة العمال وكشوفات العمليات)"
        detailedDescription="يحتوي على كافة بيانات العمال، كشوفات الحسابات الفردية، أيام العمل، تفاصيل السلف والخصومات والدفعات بالتفصيل الكامل."
        condensedTitle="تقرير مختصر وموجز (ملخص تنفيذي لأرصدة العمال)"
        condensedDescription="جدول موجز وملخص إحصائي بأسماء العمال، المهن، فترات العمل، إجمالي الأيام، إجمالي له وعليه وصافي المستحقات دون سرد الحركات اليومية."
        metrics={[
          { label: 'إجمالي العمال', value: workers.length }
        ]}
      />

    </div>
  );
}
