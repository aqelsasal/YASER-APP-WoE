/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { 
  Home,
  FolderKanban,
  Coins,
  Boxes,
  Award,
  LayoutDashboard, 
  TrendingUp, 
  Users, 
  FileText, 
  FileSpreadsheet,
  Grid, 
  Briefcase, 
  Truck, 
  Wallet, 
  Database,
  Building2,
  X,
  Landmark
} from 'lucide-react';

interface BottomNavigationProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

export default function BottomNavigation({
  activeTab,
  onTabChange
}: BottomNavigationProps) {
  const [isMoreOpen, setIsMoreOpen] = useState(false);
  const [isKeyboardVisible, setIsKeyboardVisible] = useState(false);
  const moreRef = useRef<HTMLDivElement>(null);

  // Detect when typing in inputs/textareas/selects or when the mobile keyboard is open
  useEffect(() => {
    if (typeof window === 'undefined') return;

    // Check if the currently active element is an editable field
    const checkActiveInput = () => {
      const activeEl = document.activeElement;
      if (!activeEl) {
        setIsKeyboardVisible(false);
        return;
      }
      const tagName = activeEl.tagName?.toLowerCase();
      const isInput = tagName === 'input' && !['button', 'submit', 'checkbox', 'radio', 'file', 'reset'].includes((activeEl as HTMLInputElement).type?.toLowerCase());
      const isTextArea = tagName === 'textarea';
      const isSelect = tagName === 'select';
      const isContentEditable = activeEl.getAttribute('contenteditable') === 'true' || (activeEl as HTMLElement).isContentEditable;

      setIsKeyboardVisible(isInput || isTextArea || isSelect || isContentEditable);
    };

    const handleFocusIn = () => {
      setTimeout(checkActiveInput, 30);
    };

    const handleFocusOut = () => {
      setTimeout(checkActiveInput, 80);
    };

    let initialViewportHeight = window.visualViewport ? window.visualViewport.height : window.innerHeight;

    const handleViewportResize = () => {
      if (window.visualViewport) {
        const currentHeight = window.visualViewport.height;
        if (initialViewportHeight - currentHeight > 140) {
          setIsKeyboardVisible(true);
        } else if (currentHeight >= initialViewportHeight - 40) {
          checkActiveInput();
        }
      }
    };

    document.addEventListener('focusin', handleFocusIn);
    document.addEventListener('focusout', handleFocusOut);
    if (window.visualViewport) {
      window.visualViewport.addEventListener('resize', handleViewportResize);
    }

    return () => {
      document.removeEventListener('focusin', handleFocusIn);
      document.removeEventListener('focusout', handleFocusOut);
      if (window.visualViewport) {
        window.visualViewport.removeEventListener('resize', handleViewportResize);
      }
    };
  }, []);

  // Close "More" popover when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (moreRef.current && !moreRef.current.contains(event.target as Node)) {
        setIsMoreOpen(false);
      }
    };
    if (isMoreOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isMoreOpen]);

  // Hide bottom navigation if keyboard is active while typing in input fields
  if (isKeyboardVisible) {
    return null;
  }

  // Project sub-tabs where the project-specific navigation operates
  const projectSpecificSubTabs = ['dashboard', 'expenses', 'workers', 'employees', 'suppliers', 'budget', 'debts', 'reports', 'backup', 'boq', 'contract_items'];
  const isProjectSubTabMode = projectSpecificSubTabs.includes(activeTab);

  const secondaryTabs = ['budget', 'debts', 'reports', 'backup', 'boq', 'contract_items', 'evaluations', 'main_hub', 'projects', 'construction_projects', 'company_assets', 'general_debts'];
  const isMoreActive = secondaryTabs.includes(activeTab);

  const handleSelectTab = (tab: string) => {
    onTabChange(tab);
    setIsMoreOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 w-full z-40 pointer-events-none dir-rtl m-0 p-0" id="bottom-navigation-dock">
      
      {/* "More" Sheet / Popover for Project Mode */}
      {isMoreOpen && (
        <div className="fixed inset-0 z-40 bg-slate-900/50 backdrop-blur-xs pointer-events-auto flex items-end justify-center pb-16 sm:pb-20 px-3" onClick={() => setIsMoreOpen(false)}>
          <div 
            ref={moreRef}
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl sm:rounded-2xl shadow-2xl p-3.5 sm:p-4 space-y-3.5 animate-slide-up text-right text-white mb-2 max-h-[82vh] overflow-y-auto"
          >
            <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
              <span className="font-extrabold text-sm flex items-center gap-2 text-slate-200">
                <Grid size={18} className="text-amber-400" />
                المزيد من نوافذ وأقسام التطبيق
              </span>
              <button 
                onClick={() => setIsMoreOpen(false)}
                className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 cursor-pointer"
              >
                <X size={18} />
              </button>
            </div>

            {/* Section 1: Project Tools (الميزانية العامة - ديون المشروع - التقارير الشاملة - النسخ الاحتياطي) */}
            <div className="space-y-2">
              <span className="text-[11px] font-bold text-slate-400 block">أقسام وأدوات المشروع الحالي:</span>
              <div className="grid grid-cols-2 gap-2 sm:gap-2.5">
                
                {/* 1. Item: Budget (الميزانية العامة) */}
                <button
                  onClick={() => handleSelectTab('budget')}
                  className={`p-2.5 sm:p-3 rounded-2xl flex items-center gap-2.5 text-xs font-bold transition-all text-right cursor-pointer min-h-[58px] ${
                    activeTab === 'budget'
                      ? 'bg-emerald-600 text-white shadow-md'
                      : 'bg-slate-800/80 hover:bg-slate-800 text-slate-200 border border-slate-800/60'
                  }`}
                >
                  <div className={`p-2 rounded-xl shrink-0 ${activeTab === 'budget' ? 'bg-white/20' : 'bg-emerald-500/20 text-emerald-400'}`}>
                    <Wallet size={18} />
                  </div>
                  <div className="min-w-0 flex-1">
                    <span className="block font-bold truncate">الميزانية العامة</span>
                    <span className="text-[10px] text-slate-400 font-normal truncate block">تغذية الصندوق العام</span>
                  </div>
                </button>

                {/* 2. Item: Debts (ديون المشروع) */}
                <button
                  onClick={() => handleSelectTab('debts')}
                  className={`p-2.5 sm:p-3 rounded-2xl flex items-center gap-2.5 text-xs font-bold transition-all text-right cursor-pointer min-h-[58px] ${
                    activeTab === 'debts'
                      ? 'bg-rose-600 text-white shadow-md'
                      : 'bg-slate-800/80 hover:bg-slate-800 text-slate-200 border border-slate-800/60'
                  }`}
                >
                  <div className={`p-2 rounded-xl shrink-0 ${activeTab === 'debts' ? 'bg-white/20' : 'bg-rose-500/20 text-rose-400'}`}>
                    <Coins size={18} />
                  </div>
                  <div className="min-w-0 flex-1">
                    <span className="block font-bold truncate">ديون المشروع</span>
                    <span className="text-[10px] text-slate-400 font-normal truncate block">المستحقات الآجلة</span>
                  </div>
                </button>

                {/* 3. Item: Reports (التقارير الشاملة) */}
                <button
                  onClick={() => handleSelectTab('reports')}
                  className={`p-2.5 sm:p-3 rounded-2xl flex items-center gap-2.5 text-xs font-bold transition-all text-right cursor-pointer min-h-[58px] ${
                    activeTab === 'reports'
                      ? 'bg-violet-600 text-white shadow-md'
                      : 'bg-slate-800/80 hover:bg-slate-800 text-slate-200 border border-slate-800/60'
                  }`}
                >
                  <div className={`p-2 rounded-xl shrink-0 ${activeTab === 'reports' ? 'bg-white/20' : 'bg-violet-500/20 text-violet-400'}`}>
                    <FileText size={18} />
                  </div>
                  <div className="min-w-0 flex-1">
                    <span className="block font-bold truncate">التقارير الشاملة</span>
                    <span className="text-[10px] text-slate-400 font-normal truncate block">كشوفات وتقارير وتصدير</span>
                  </div>
                </button>

                {/* 4. Item: Backup (النسخ الاحتياطي) */}
                <button
                  onClick={() => handleSelectTab('backup')}
                  className={`p-2.5 sm:p-3 rounded-2xl flex items-center gap-2.5 text-xs font-bold transition-all text-right cursor-pointer min-h-[58px] ${
                    activeTab === 'backup'
                      ? 'bg-cyan-600 text-white shadow-md'
                      : 'bg-slate-800/80 hover:bg-slate-800 text-slate-200 border border-slate-800/60'
                  }`}
                >
                  <div className={`p-2 rounded-xl shrink-0 ${activeTab === 'backup' ? 'bg-white/20' : 'bg-cyan-500/20 text-cyan-400'}`}>
                    <Database size={18} />
                  </div>
                  <div className="min-w-0 flex-1">
                    <span className="block font-bold truncate">النسخ الاحتياطي</span>
                    <span className="text-[10px] text-slate-400 font-normal truncate block">حفظ واستعادة السجلات</span>
                  </div>
                </button>

                {/* 5. Item: BOQ & Contract Items (جدول الكميات وبنود العقد) */}
                <button
                  onClick={() => handleSelectTab('boq')}
                  className={`col-span-2 p-2.5 sm:p-3 rounded-2xl flex items-center gap-2.5 text-xs font-bold transition-all text-right cursor-pointer min-h-[54px] ${
                    activeTab === 'boq' || activeTab === 'contract_items'
                      ? 'bg-teal-600 text-white shadow-md font-black'
                      : 'bg-slate-800/80 hover:bg-slate-800 text-slate-200 border border-slate-800/60'
                  }`}
                >
                  <div className={`p-2 rounded-xl shrink-0 ${activeTab === 'boq' || activeTab === 'contract_items' ? 'bg-white/20' : 'bg-teal-500/20 text-teal-400'}`}>
                    <FileSpreadsheet size={18} />
                  </div>
                  <div className="min-w-0 flex-1">
                    <span className="block font-bold truncate">جدول الكميات وبنود عقد المشروع</span>
                    <span className="text-[10px] text-slate-400 font-normal truncate block">إدارة بنود وفقرات العقد وربطها بالتكاليف والنفقات الفعلية</span>
                  </div>
                </button>

              </div>
            </div>

            {/* Section 2: Global Portals in a Separate Frame (الواجهة الرئيسية - إدارة المشاريع - أصول الشركة - الديون والالتزامات - تقييم الأداء) */}
            <div className="bg-slate-800/60 border border-slate-700/70 rounded-2xl p-3 space-y-2.5">
              <div className="flex items-center justify-between border-b border-slate-700/60 pb-2">
                <span className="text-[11px] font-extrabold text-amber-400 flex items-center gap-1.5">
                  <Building2 size={14} />
                  النوافذ والأقسام العامة للشركة
                </span>
                <span className="text-[10px] text-slate-400">مركز التحكم العام</span>
              </div>

              <div className="grid grid-cols-2 gap-2">
                
                {/* 1. الواجهة الرئيسية */}
                <button
                  onClick={() => handleSelectTab('main_hub')}
                  className={`p-2.5 rounded-xl flex items-center gap-2 text-xs font-bold transition-all text-right cursor-pointer min-h-[54px] ${
                    activeTab === 'main_hub'
                      ? 'bg-amber-500 text-slate-950 shadow-md font-black'
                      : 'bg-slate-900/80 hover:bg-slate-900 text-slate-200 border border-slate-700/50'
                  }`}
                >
                  <div className={`p-1.5 rounded-lg shrink-0 ${activeTab === 'main_hub' ? 'bg-slate-950/20' : 'bg-amber-500/20 text-amber-400'}`}>
                    <Home size={16} />
                  </div>
                  <div className="min-w-0 flex-1">
                    <span className="block font-bold truncate">الواجهة الرئيسية</span>
                    <span className="text-[9.5px] text-slate-400 font-normal truncate block">مركز قيادة الشركة</span>
                  </div>
                </button>

                {/* 2. إدارة المشاريع */}
                <button
                  onClick={() => handleSelectTab('construction_projects')}
                  className={`p-2.5 rounded-xl flex items-center gap-2 text-xs font-bold transition-all text-right cursor-pointer min-h-[54px] ${
                    activeTab === 'construction_projects' || activeTab === 'projects'
                      ? 'bg-sky-600 text-white shadow-md'
                      : 'bg-slate-900/80 hover:bg-slate-900 text-slate-200 border border-slate-700/50'
                  }`}
                >
                  <div className={`p-1.5 rounded-lg shrink-0 ${activeTab === 'construction_projects' || activeTab === 'projects' ? 'bg-white/20' : 'bg-sky-500/20 text-sky-400'}`}>
                    <FolderKanban size={16} />
                  </div>
                  <div className="min-w-0 flex-1">
                    <span className="block font-bold truncate">إدارة المشاريع</span>
                    <span className="text-[9.5px] text-slate-400 font-normal truncate block">لوحة تحكم المشاريع</span>
                  </div>
                </button>

                {/* 3. أصول الشركة */}
                <button
                  onClick={() => handleSelectTab('company_assets')}
                  className={`p-2.5 rounded-xl flex items-center gap-2 text-xs font-bold transition-all text-right cursor-pointer min-h-[54px] ${
                    activeTab === 'company_assets'
                      ? 'bg-amber-600 text-white shadow-md'
                      : 'bg-slate-900/80 hover:bg-slate-900 text-slate-200 border border-slate-700/50'
                  }`}
                >
                  <div className={`p-1.5 rounded-lg shrink-0 ${activeTab === 'company_assets' ? 'bg-white/20' : 'bg-amber-500/20 text-amber-400'}`}>
                    <Boxes size={16} />
                  </div>
                  <div className="min-w-0 flex-1">
                    <span className="block font-bold truncate">أصول الشركة</span>
                    <span className="text-[9.5px] text-slate-400 font-normal truncate block">المعدات والمخزون</span>
                  </div>
                </button>

                {/* 4. الديون والالتزامات */}
                <button
                  onClick={() => handleSelectTab('general_debts')}
                  className={`p-2.5 rounded-xl flex items-center gap-2 text-xs font-bold transition-all text-right cursor-pointer min-h-[54px] ${
                    activeTab === 'general_debts'
                      ? 'bg-teal-600 text-white shadow-md'
                      : 'bg-slate-900/80 hover:bg-slate-900 text-slate-200 border border-slate-700/50'
                  }`}
                >
                  <div className={`p-1.5 rounded-lg shrink-0 ${activeTab === 'general_debts' ? 'bg-white/20' : 'bg-teal-500/20 text-teal-400'}`}>
                    <Landmark size={16} />
                  </div>
                  <div className="min-w-0 flex-1">
                    <span className="block font-bold truncate">الديون والالتزامات</span>
                    <span className="text-[9.5px] text-slate-400 font-normal truncate block">ديون والتزامات الشركة</span>
                  </div>
                </button>

                {/* 5. تقييم الأداء */}
                <button
                  onClick={() => handleSelectTab('evaluations')}
                  className={`col-span-2 p-2.5 rounded-xl flex items-center gap-2 text-xs font-bold transition-all text-right cursor-pointer min-h-[52px] ${
                    activeTab === 'evaluations'
                      ? 'bg-amber-600 text-white shadow-md'
                      : 'bg-slate-900/80 hover:bg-slate-900 text-slate-200 border border-slate-700/50'
                  }`}
                >
                  <div className={`p-1.5 rounded-lg shrink-0 ${activeTab === 'evaluations' ? 'bg-white/20' : 'bg-amber-500/20 text-amber-400'}`}>
                    <Award size={16} />
                  </div>
                  <div className="min-w-0 flex-1">
                    <span className="block font-bold truncate">تقييم الأداء</span>
                    <span className="text-[9.5px] text-slate-400 font-normal truncate block">تقييم الموظفين والعمال والموردين</span>
                  </div>
                </button>

              </div>
            </div>

          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* CASE 1: Project Sub-Tabs Navigation (Inside a specific project view)     */}
      {/* 7 Items: [لوحة التحكم | النفقات | العمال | 🏠 الرئيسية (بارزة) | الموظفين | الموردين | المزيد] */}
      {/* ========================================================================= */}
      {isProjectSubTabMode ? (
        <div className="pointer-events-auto w-full bg-slate-900 border-t border-slate-800 shadow-[0_-4px_25px_rgba(0,0,0,0.5)] m-0 pb-[env(safe-area-inset-bottom,0px)]">
          <div className="max-w-xl sm:max-w-2xl mx-auto px-1 sm:px-3 py-1 sm:py-1.5 flex items-center justify-around gap-0.5 sm:gap-1 relative">
            
            {/* 1. Dashboard (لوحة التحكم للمشروع) */}
            <button
              type="button"
              onClick={() => handleSelectTab('dashboard')}
              className={`flex flex-col items-center justify-center py-1 sm:py-1.5 px-1 sm:px-2 rounded-xl transition-all cursor-pointer min-w-[42px] sm:min-w-[50px] flex-1 ${
                activeTab === 'dashboard'
                  ? 'text-sky-400 bg-sky-500/15 font-bold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              title="لوحة تحكم المشروع"
              id="project-bottom-nav-dashboard-btn"
            >
              <LayoutDashboard size={18} className={activeTab === 'dashboard' ? 'scale-110 transition-transform' : ''} />
              <span className="text-[9.5px] sm:text-[10px] mt-1 font-semibold truncate">لوحة التحكم</span>
            </button>

            {/* 2. Expenses (النفقات) */}
            <button
              type="button"
              onClick={() => handleSelectTab('expenses')}
              className={`flex flex-col items-center justify-center py-1 sm:py-1.5 px-1 sm:px-2 rounded-xl transition-all cursor-pointer min-w-[42px] sm:min-w-[50px] flex-1 ${
                activeTab === 'expenses'
                  ? 'text-rose-400 bg-rose-500/15 font-bold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              title="نفقات ومصروفات المشروع"
              id="project-bottom-nav-expenses-btn"
            >
              <TrendingUp size={18} className={activeTab === 'expenses' ? 'scale-110 transition-transform' : ''} />
              <span className="text-[9.5px] sm:text-[10px] mt-1 font-semibold truncate">النفقات</span>
            </button>

            {/* 3. Workers (العمال) */}
            <button
              type="button"
              onClick={() => handleSelectTab('workers')}
              className={`flex flex-col items-center justify-center py-1 sm:py-1.5 px-1 sm:px-2 rounded-xl transition-all cursor-pointer min-w-[42px] sm:min-w-[50px] flex-1 ${
                activeTab === 'workers'
                  ? 'text-sky-400 bg-sky-500/15 font-bold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              title="سجلات وحسابات العمال"
              id="project-bottom-nav-workers-btn"
            >
              <Users size={18} className={activeTab === 'workers' ? 'scale-110 transition-transform' : ''} />
              <span className="text-[9.5px] sm:text-[10px] mt-1 font-semibold truncate">العمال</span>
            </button>

            {/* 4. الرئيسية (النافذة الرئيسية للتطبيق - في منتصف الشريط وبشكل دائرة بارزة مع أيقونة منزل) */}
            <div className="flex flex-col items-center justify-center px-0.5 sm:px-1 shrink-0">
              <button
                type="button"
                onClick={() => handleSelectTab('main_hub')}
                className={`relative -mt-6 sm:-mt-7 flex flex-col items-center justify-center w-14 h-14 sm:w-15 sm:h-15 rounded-full transition-all cursor-pointer shadow-xl active:scale-95 z-20 border-2 ${
                  activeTab === 'main_hub'
                    ? 'bg-gradient-to-tr from-amber-500 via-amber-400 to-amber-300 text-slate-950 ring-4 ring-slate-900 border-amber-200 shadow-amber-500/40'
                    : 'bg-gradient-to-tr from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 ring-4 ring-slate-900 border-amber-300/80 shadow-amber-900/40'
                }`}
                title="الانتقال إلى شاشة التطبيق الرئيسية"
                id="project-bottom-nav-main-hub-btn"
              >
                <Home size={22} className="stroke-[2.5] text-slate-950 drop-shadow-xs" />
                <span className="text-[9px] font-black text-slate-950 leading-none mt-0.5">الرئيسية</span>
              </button>
            </div>

            {/* 5. Employees (الموظفين) */}
            <button
              type="button"
              onClick={() => handleSelectTab('employees')}
              className={`flex flex-col items-center justify-center py-1 sm:py-1.5 px-1 sm:px-2 rounded-xl transition-all cursor-pointer min-w-[42px] sm:min-w-[50px] flex-1 ${
                activeTab === 'employees'
                  ? 'text-indigo-400 bg-indigo-500/15 font-bold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              title="سجلات ورواتب الموظفين"
              id="project-bottom-nav-employees-btn"
            >
              <Briefcase size={18} className={activeTab === 'employees' ? 'scale-110 transition-transform' : ''} />
              <span className="text-[9.5px] sm:text-[10px] mt-1 font-semibold truncate">الموظفين</span>
            </button>

            {/* 6. Suppliers (الموردين) */}
            <button
              type="button"
              onClick={() => handleSelectTab('suppliers')}
              className={`flex flex-col items-center justify-center py-1 sm:py-1.5 px-1 sm:px-2 rounded-xl transition-all cursor-pointer min-w-[42px] sm:min-w-[50px] flex-1 ${
                activeTab === 'suppliers'
                  ? 'text-amber-400 bg-amber-500/15 font-bold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              title="حسابات ومشتريات الموردين"
              id="project-bottom-nav-suppliers-btn"
            >
              <Truck size={18} className={activeTab === 'suppliers' ? 'scale-110 transition-transform' : ''} />
              <span className="text-[9.5px] sm:text-[10px] mt-1 font-semibold truncate">الموردين</span>
            </button>

            {/* 7. More (المزيد) */}
            <button
              type="button"
              onClick={() => setIsMoreOpen(!isMoreOpen)}
              className={`relative flex flex-col items-center justify-center py-1 sm:py-1.5 px-1 sm:px-2 rounded-xl transition-all cursor-pointer min-w-[42px] sm:min-w-[50px] flex-1 ${
                isMoreActive || isMoreOpen
                  ? 'text-amber-400 bg-amber-500/15 font-bold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              title="المزيد من أقسام وأدوات المشروع"
              id="project-bottom-nav-more-btn"
            >
              {isMoreActive && (
                <span className="absolute top-1 right-2 sm:right-3 w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
              )}
              <Grid size={18} className={isMoreActive || isMoreOpen ? 'scale-110 transition-transform' : ''} />
              <span className="text-[9.5px] sm:text-[10px] mt-1 font-semibold truncate">المزيد</span>
            </button>

          </div>
        </div>
      ) : (
        /* ========================================================================= */
        /* CASE 2: Global Bottom Navigation (Across all other app windows)           */
        /* 5 Icons: [المشاريع | الديون | 🏠 الرئيسية (بارزة) | الأصول | تقييم الأداء] */
        /* ========================================================================= */
        <div className="pointer-events-auto w-full bg-slate-900 border-t border-slate-800 shadow-[0_-4px_25px_rgba(0,0,0,0.5)] m-0 pb-[env(safe-area-inset-bottom,0px)]">
          <div className="max-w-xl sm:max-w-2xl mx-auto px-1 sm:px-3 py-1 sm:py-1.5 flex items-center justify-around gap-1 relative">
            
            {/* 1. المشاريع (إدارة المشاريع الإنشائية) */}
            <button
              type="button"
              onClick={() => handleSelectTab('construction_projects')}
              className={`flex flex-col items-center justify-center py-1.5 px-2 rounded-xl transition-all cursor-pointer min-w-[58px] flex-1 ${
                activeTab === 'construction_projects' || activeTab === 'projects'
                  ? 'text-amber-400 bg-amber-500/15 font-black'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              title="إدارة المشاريع الإنشائية"
              id="global-bottom-nav-projects-btn"
            >
              <FolderKanban size={19} className={activeTab === 'construction_projects' || activeTab === 'projects' ? 'scale-110 transition-transform text-amber-400' : ''} />
              <span className="text-[10px] mt-1 font-bold">المشاريع</span>
            </button>

            {/* 2. الديون (الديون والالتزامات العامة) */}
            <button
              type="button"
              onClick={() => handleSelectTab('general_debts')}
              className={`flex flex-col items-center justify-center py-1.5 px-2 rounded-xl transition-all cursor-pointer min-w-[58px] flex-1 ${
                activeTab === 'general_debts'
                  ? 'text-amber-400 bg-amber-500/15 font-black'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              title="الديون والالتزامات العامة للشركة"
              id="global-bottom-nav-debts-btn"
            >
              <Coins size={19} className={activeTab === 'general_debts' ? 'scale-110 transition-transform text-amber-400' : ''} />
              <span className="text-[10px] mt-1 font-bold">الديون</span>
            </button>

            {/* 3. الرئيسية (النافذة الرئيسية للتطبيق - في المنتصف وبشكل دائرة بارزة مع أيقونة منزل) */}
            <div className="flex flex-col items-center justify-center px-1 shrink-0">
              <button
                type="button"
                onClick={() => handleSelectTab('main_hub')}
                className={`relative -mt-6 sm:-mt-7 flex flex-col items-center justify-center w-14 h-14 sm:w-15 sm:h-15 rounded-full transition-all cursor-pointer shadow-xl active:scale-95 z-20 border-2 ${
                  activeTab === 'main_hub'
                    ? 'bg-gradient-to-tr from-amber-500 via-amber-400 to-amber-300 text-slate-950 ring-4 ring-slate-900 border-amber-200 shadow-amber-500/40'
                    : 'bg-gradient-to-tr from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 ring-4 ring-slate-900 border-amber-300/80 shadow-amber-900/40'
                }`}
                title="النافذة الرئيسية للتطبيق"
                id="global-bottom-nav-main-hub-btn"
              >
                <Home size={22} className="stroke-[2.5] text-slate-950 drop-shadow-xs" />
                <span className="text-[9px] font-black text-slate-950 leading-none mt-0.5">الرئيسية</span>
              </button>
            </div>

            {/* 4. الأصول (مواد وأصول الشركة والمخزون) */}
            <button
              type="button"
              onClick={() => handleSelectTab('company_assets')}
              className={`flex flex-col items-center justify-center py-1.5 px-2 rounded-xl transition-all cursor-pointer min-w-[58px] flex-1 ${
                activeTab === 'company_assets'
                  ? 'text-amber-400 bg-amber-500/15 font-black'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              title="مواد وأصول الشركة والمخزون"
              id="global-bottom-nav-assets-btn"
            >
              <Boxes size={19} className={activeTab === 'company_assets' ? 'scale-110 transition-transform text-amber-400' : ''} />
              <span className="text-[10px] mt-1 font-bold">الأصول</span>
            </button>

            {/* 5. تقييم الأداء (تقييم الأداء والتميز) */}
            <button
              type="button"
              onClick={() => handleSelectTab('evaluations')}
              className={`flex flex-col items-center justify-center py-1.5 px-2 rounded-xl transition-all cursor-pointer min-w-[58px] flex-1 ${
                activeTab === 'evaluations'
                  ? 'text-amber-400 bg-amber-500/15 font-black'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              title="تقييم الأداء (الموظفون • العمال • الموردون)"
              id="global-bottom-nav-evaluations-btn"
            >
              <Award size={19} className={activeTab === 'evaluations' ? 'scale-110 transition-transform text-amber-400' : ''} />
              <span className="text-[10px] mt-1 font-bold">تقييم الأداء</span>
            </button>

          </div>
        </div>
      )}

    </div>
  );
}
