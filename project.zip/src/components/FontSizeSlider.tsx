/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Type, 
  RotateCcw, 
  ZoomIn, 
  ZoomOut, 
  Check, 
  Sliders, 
  Heading1, 
  FileText, 
  Table2,
  Sparkles
} from 'lucide-react';
import { 
  GLOBAL_FONT_STEPS, 
  CATEGORY_FONT_STEPS,
  applyFontStep,
  applyHeadingsStep,
  applySubtextStep,
  applyTablesStep,
  getSavedHeadingsStep,
  getSavedSubtextStep,
  getSavedTablesStep
} from '../utils/fontSizeManager';

interface FontSizeSliderProps {
  currentStep: number;
  onStepChange: (newStep: number) => void;
  className?: string;
}

export const FontSizeSlider: React.FC<FontSizeSliderProps> = ({
  currentStep,
  onStepChange,
  className = ''
}) => {
  // Global 8 Steps Ordered from Right to Left for Arabic layout:
  // Right side: +2, +1 (2 نقاط تكبير)
  // Center: 0 (الافتراضي)
  // Left side: -1, -2, -3, -4, -5 (5 نقاط تصغير)
  const globalStepsRTL = [
    { step: 2, label: '+2', subLabel: 'أكبر', px: 18, type: 'enlarge' },
    { step: 1, label: '+1', subLabel: 'كبير', px: 17, type: 'enlarge' },
    { step: 0, label: '0', subLabel: 'الافتراضي', px: 16, type: 'default' },
    { step: -1, label: '-1', subLabel: 'صغير', px: 15, type: 'reduce' },
    { step: -2, label: '-2', subLabel: 'أصغر', px: 14, type: 'reduce' },
    { step: -3, label: '-3', subLabel: 'مضغوط', px: 13, type: 'reduce' },
    { step: -4, label: '-4', subLabel: 'دقيق', px: 12, type: 'reduce' },
    { step: -5, label: '-5', subLabel: 'الأصغر', px: 11, type: 'reduce' },
  ];

  // Specific 5 Steps for Sub-categories:
  // Right side: +2, +1 (تكبير)
  // Center: 0 (الافتراضي)
  // Left side: -1, -2 (تصغير)
  const categoryStepsRTL = [
    { step: 2, label: '+2', subLabel: 'أكبر', type: 'enlarge' },
    { step: 1, label: '+1', subLabel: 'كبير', type: 'enlarge' },
    { step: 0, label: '0', subLabel: 'الافتراضي', type: 'default' },
    { step: -1, label: '-1', subLabel: 'صغير', type: 'reduce' },
    { step: -2, label: '-2', subLabel: 'أصغر', type: 'reduce' },
  ];

  // Sub-category steps state
  const [headingsStep, setHeadingsStep] = useState<number>(() => getSavedHeadingsStep());
  const [subtextStep, setSubtextStep] = useState<number>(() => getSavedSubtextStep());
  const [tablesStep, setTablesStep] = useState<number>(() => getSavedTablesStep());

  // Active tab inside font settings: 'global' or 'granular'
  const [activeFontTab, setActiveFontTab] = useState<'global' | 'granular'>('global');

  const handleSelectGlobalStep = (stepVal: number) => {
    onStepChange(stepVal);
    applyFontStep(stepVal);
  };

  const handleSelectHeadingsStep = (stepVal: number) => {
    setHeadingsStep(stepVal);
    applyHeadingsStep(stepVal);
  };

  const handleSelectSubtextStep = (stepVal: number) => {
    setSubtextStep(stepVal);
    applySubtextStep(stepVal);
  };

  const handleSelectTablesStep = (stepVal: number) => {
    setTablesStep(stepVal);
    applyTablesStep(stepVal);
  };

  const handleResetAllToDefault = () => {
    handleSelectGlobalStep(0);
    handleSelectHeadingsStep(0);
    handleSelectSubtextStep(0);
    handleSelectTablesStep(0);
    if (typeof window !== 'undefined' && (window as any).showToast) {
      (window as any).showToast('↺ تم إعادة ضبط كافة خطوط التطبيق إلى الحجم الافتراضي القياسي');
    }
  };

  const currentGlobalConfig = GLOBAL_FONT_STEPS.find(s => s.step === currentStep) || GLOBAL_FONT_STEPS[2];

  // Progress for global slider (-5 to +2, span = 7 units)
  const globalProgressPercent = ((currentStep - (-5)) / 7) * 100;

  // Render a straight line track with discrete points
  const renderStraightLineTrack = (
    steps: Array<{ step: number; label: string; subLabel: string; type: string }>,
    activeStep: number,
    onSelect: (s: number) => void,
    colorScheme: 'amber' | 'indigo' | 'emerald' | 'purple' = 'amber'
  ) => {
    const minStep = steps[steps.length - 1].step;
    const maxStep = steps[0].step;
    const span = Math.max(1, maxStep - minStep);
    const progress = ((activeStep - minStep) / span) * 100;
    const centerPercent = ((0 - minStep) / span) * 100;

    const accentBg = {
      amber: 'bg-amber-500 text-slate-950 ring-amber-400/40 shadow-amber-500/30',
      indigo: 'bg-indigo-600 text-white ring-indigo-400/40 shadow-indigo-500/30',
      emerald: 'bg-emerald-600 text-white ring-emerald-400/40 shadow-emerald-500/30',
      purple: 'bg-purple-600 text-white ring-purple-400/40 shadow-purple-500/30',
    }[colorScheme];

    return (
      <div className="pt-2 pb-3 px-1 sm:px-2">
        <div className="relative flex items-center justify-between select-none">
          {/* Background Straight Horizontal Line Track */}
          <div className="absolute top-4 left-3 right-3 h-2 bg-slate-200 dark:bg-slate-700 rounded-full z-0 overflow-hidden">
            <div 
              className="absolute top-0 bottom-0 bg-gradient-to-r from-sky-500 via-amber-400 to-amber-500 transition-all duration-200 rounded-full"
              style={{
                left: `${Math.min(progress, centerPercent)}%`,
                width: `${Math.abs(progress - centerPercent)}%`
              }}
            />
          </div>

          {/* Points along the line from Right to Left */}
          {steps.map((item) => {
            const isSelected = activeStep === item.step;
            const isCenterDefault = item.step === 0;
            const isEnlarge = item.step > 0;
            const isReduce = item.step < 0;

            return (
              <div 
                key={item.step}
                className="relative z-10 flex flex-col items-center group cursor-pointer"
                onClick={() => onSelect(item.step)}
                title={item.subLabel}
              >
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    onSelect(item.step);
                  }}
                  className={`w-7 h-7 sm:w-8 sm:h-8 rounded-full flex items-center justify-center transition-all duration-200 cursor-pointer text-xs font-black shadow-md ${
                    isSelected
                      ? `${accentBg} ring-4 scale-110`
                      : isCenterDefault
                      ? 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-2 border-emerald-500 hover:border-emerald-400 hover:scale-105'
                      : isEnlarge
                      ? 'bg-white dark:bg-slate-800 text-amber-500 border-2 border-amber-400/70 hover:border-amber-500 hover:scale-105'
                      : 'bg-white dark:bg-slate-800 text-sky-500 border-2 border-sky-400/70 hover:border-sky-500 hover:scale-105'
                  }`}
                  aria-label={`تحديد: ${item.label}`}
                >
                  {isSelected ? (
                    <Check size={13} className="stroke-[3]" />
                  ) : (
                    <span>{item.label}</span>
                  )}
                </button>

                <div className="mt-1.5 text-center">
                  <span className={`block text-[10.5px] font-bold leading-tight ${
                    isSelected 
                      ? 'text-amber-500 dark:text-amber-400 font-black' 
                      : 'text-slate-600 dark:text-slate-400'
                  }`}>
                    {item.label}
                  </span>
                  <span className={`block text-[9px] leading-tight ${
                    isSelected 
                      ? 'text-slate-900 dark:text-slate-100 font-extrabold' 
                      : 'text-slate-600 dark:text-slate-400'
                  }`}>
                    {item.subLabel}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  const hasAnyCustomSetting = currentStep !== 0 || headingsStep !== 0 || subtextStep !== 0 || tablesStep !== 0;

  return (
    <div className={`p-4 bg-slate-50 dark:bg-slate-900/60 rounded-2xl border border-slate-200/90 dark:border-slate-800 space-y-4 dir-rtl text-right ${className}`}>
      
      {/* Header with Title and Mode Tabs */}
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-amber-500/15 text-amber-500 flex items-center justify-center font-bold shrink-0 border border-amber-500/25">
            <Type size={18} />
          </div>
          <div>
            <h4 className="font-extrabold text-xs sm:text-sm text-slate-800 dark:text-slate-100 flex items-center gap-1.5">
              <span>التحكم في أحجام خطوط التطبيق</span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/15 text-amber-500 font-bold border border-amber-500/30">
                {currentStep > 0 ? `+${currentStep}` : currentStep} ({16 + currentStep}px)
              </span>
            </h4>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
              تعديل الحجم الشامل أو تخصيص الخطوط لكل نوع من النصوص ولوحات العرض بشكل مستقل
            </p>
          </div>
        </div>

        {/* Global Reset Button */}
        {hasAnyCustomSetting && (
          <button
            type="button"
            onClick={handleResetAllToDefault}
            className="px-2.5 py-1 text-[11px] font-bold text-slate-600 dark:text-slate-300 hover:text-amber-500 bg-white dark:bg-slate-800 hover:bg-amber-50 dark:hover:bg-slate-700/80 border border-slate-200 dark:border-slate-700 rounded-lg transition-all flex items-center gap-1 cursor-pointer shadow-2xs"
            title="إعادة ضبط كافة الخطوط إلى الحجم الافتراضي (0)"
          >
            <RotateCcw size={12} />
            <span>استعادة الافتراضي للكل</span>
          </button>
        )}
      </div>

      {/* Switch between: [الخط العام الشامل] and [تخصيص العناوين والنصوص الفرعية والجداول] */}
      <div className="flex items-center gap-1.5 p-1 bg-slate-200/80 dark:bg-slate-800/80 rounded-xl">
        <button
          type="button"
          onClick={() => setActiveFontTab('global')}
          className={`flex-1 py-1.5 px-3 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
            activeFontTab === 'global'
              ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs font-black'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          <Type size={14} className="text-amber-500" />
          <span>الخط العام لكامل التطبيق (8 درجات)</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveFontTab('granular')}
          className={`flex-1 py-1.5 px-3 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
            activeFontTab === 'granular'
              ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs font-black'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          <Sliders size={14} className="text-sky-500" />
          <span>تخصيص العناوين، النصوص الفرعية، والجداول</span>
          {(headingsStep !== 0 || subtextStep !== 0 || tablesStep !== 0) && (
            <span className="w-2 h-2 rounded-full bg-sky-500 animate-pulse" />
          )}
        </button>
      </div>

      {/* TAB 1: Global Font Scale Track (8 Points: -5 to +2) */}
      {activeFontTab === 'global' && (
        <div className="space-y-3 animate-fade-in">
          <div className="flex items-center justify-between text-[11px] font-extrabold text-slate-600 dark:text-slate-400 px-1 border-b border-slate-200/60 dark:border-slate-800 pb-2">
            <div className="flex items-center gap-1.5 text-amber-500">
              <ZoomIn size={14} className="stroke-[2.5]" />
              <span>اليمين: نقطتان لتكبير الخط (+1، +2)</span>
            </div>
            <div className="flex items-center gap-1.5 text-sky-500">
              <span>اليسار: 5 نقط لتصغير الخط (-1، -2، -3، -4، -5)</span>
              <ZoomOut size={14} className="stroke-[2.5]" />
            </div>
          </div>

          {/* Straight line for Global Scale */}
          {renderStraightLineTrack(globalStepsRTL, currentStep, handleSelectGlobalStep, 'amber')}
        </div>
      )}

      {/* TAB 2: Granular Controls for Headings, Subtext/Display Panels, and Data Tables */}
      {activeFontTab === 'granular' && (
        <div className="space-y-4 animate-fade-in divide-y divide-slate-200/70 dark:divide-slate-800">
          
          {/* Section 1: العناوين الرئيسية والتبويبات */}
          <div className="space-y-2 pt-1">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                <Heading1 size={14} className="text-amber-500" />
                <span>العناوين الرئيسية وأسماء التبويبات:</span>
              </span>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-500/15 text-amber-500 border border-amber-500/20">
                {headingsStep > 0 ? `+${headingsStep}` : headingsStep === 0 ? 'افتراضي' : headingsStep}
              </span>
            </div>
            <p className="text-[10.5px] text-slate-500">
              يتحكم في حجم عناوين الصفحات، التبويبات العلوية والسفلية، وعناوين النوافذ المنبثقة
            </p>
            {renderStraightLineTrack(categoryStepsRTL, headingsStep, handleSelectHeadingsStep, 'amber')}
          </div>

          {/* Section 2: النصوص الفرعية والبيانات التوضيحية في لوحات العرض */}
          <div className="space-y-2 pt-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                <FileText size={14} className="text-sky-500" />
                <span>النصوص الفرعية والبيانات التوضيحية في لوحات العرض:</span>
              </span>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-sky-500/15 text-sky-500 border border-sky-500/20">
                {subtextStep > 0 ? `+${subtextStep}` : subtextStep === 0 ? 'افتراضي' : subtextStep}
              </span>
            </div>
            <p className="text-[10.5px] text-slate-500">
              تكبير النصوص التوضيحية الصغيرة، بيانات بطاقات العرض، تفاصيل الكروت، والإشعارات لسهولة القراءة
            </p>
            {renderStraightLineTrack(categoryStepsRTL, subtextStep, handleSelectSubtextStep, 'indigo')}
          </div>

          {/* Section 3: جداول البيانات والأرقام المحاسبية */}
          <div className="space-y-2 pt-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                <Table2 size={14} className="text-emerald-500" />
                <span>نصوص وأرقام الجداول المحاسبية والكشوفات:</span>
              </span>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-500 border border-emerald-500/20">
                {tablesStep > 0 ? `+${tablesStep}` : tablesStep === 0 ? 'افتراضي' : tablesStep}
              </span>
            </div>
            <p className="text-[10.5px] text-slate-500">
              يتحكم في نصوص السجلات، صفوف الجداول، التواريخ، والمبالغ المالية في كشوفات الحسابات
            </p>
            {renderStraightLineTrack(categoryStepsRTL, tablesStep, handleSelectTablesStep, 'emerald')}
          </div>

        </div>
      )}

      {/* Live Interactive Multi-Type Text Preview Card */}
      <div className="p-3.5 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl space-y-2.5 shadow-xs transition-all">
        <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-2">
          <span className="text-xs font-bold text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
            <Sparkles size={13} className="text-amber-500" />
            <span>معاينة حية ومباشرة لتناسق كافة أنواع النصوص:</span>
          </span>
          <span className="text-[10.5px] font-extrabold text-amber-500 bg-amber-500/10 px-2 py-0.5 rounded-md border border-amber-500/20">
            {currentGlobalConfig.description}
          </span>
        </div>

        {/* Live elements showing Headings, Subtext, and Data Tables reacting to the settings */}
        <div className="space-y-2">
          {/* Heading Preview */}
          <h3 className="font-extrabold text-slate-900 dark:text-white leading-tight flex items-center gap-2">
            <span>لوحة تحكم المشروع - ورلد أوف إيليتس للتجارة والمقاولات</span>
            <span className="text-[10px] px-2 py-0.5 rounded-md bg-sky-500/15 text-sky-500 font-bold border border-sky-500/25">
              تبويب نشط
            </span>
          </h3>

          {/* Subtext / Explanatory card text preview */}
          <p className="text-slate-600 dark:text-slate-300 leading-relaxed card-subtext">
            بيانات توضيحية: هذا النص الفرعي يوضح وضوح القراءة في بطاقات العرض والنوافذ ولوحات المعلومات بعد الضبط المستقل.
          </p>

          {/* Table & Numeric preview */}
          <div className="overflow-x-auto pt-1">
            <table className="w-full text-xs text-right border border-slate-200 dark:border-slate-800 rounded-lg overflow-hidden">
              <thead className="bg-slate-100 dark:bg-slate-900 text-slate-700 dark:text-slate-300 font-bold">
                <tr>
                  <th className="p-1.5 border-b border-slate-200 dark:border-slate-800">البند / البيان</th>
                  <th className="p-1.5 border-b border-slate-200 dark:border-slate-800 text-center">التاريخ</th>
                  <th className="p-1.5 border-b border-slate-200 dark:border-slate-800 text-left">المبلغ</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                <tr>
                  <td className="p-1.5 text-slate-800 dark:text-slate-200">توريد مواد بناء وأسمنت</td>
                  <td className="p-1.5 text-center text-slate-500 font-mono">2026/09/28</td>
                  <td className="p-1.5 text-left font-mono font-bold text-emerald-600">850,000 ر.ي</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>

    </div>
  );
};

export default FontSizeSlider;
