/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { createContext, useContext, useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { TRANSLATIONS_EN, DYNAMIC_PATTERNS_EN } from './translations';

export type SupportedLanguage = 'ar' | 'en';

interface LanguageContextType {
  language: SupportedLanguage;
  setLanguage: (lang: SupportedLanguage) => void;
  toggleLanguage: () => void;
  t: (text: string, fallback?: string) => string;
  isRTL: boolean;
  dir: 'rtl' | 'ltr';
}

const LanguageContext = createContext<LanguageContextType>({
  language: 'ar',
  setLanguage: () => {},
  toggleLanguage: () => {},
  t: (text) => text,
  isRTL: true,
  dir: 'rtl'
});

const ARABIC_CHAR_REGEX = /[\u0600-\u06FF]/;

/**
 * Intelligent text translation helper
 */
export function translateText(text: string, lang: SupportedLanguage, fallback?: string): string {
  if (!text || typeof text !== 'string') return text;
  if (lang === 'ar') return text;

  // Preserve leading and trailing whitespace
  const leadingSpace = text.match(/^\s*/)?.[0] || '';
  const trailingSpace = text.match(/\s*$/)?.[0] || '';
  const trimmed = text.trim();

  if (!trimmed) return text;

  // If text does not contain Arabic characters, return as-is
  if (!ARABIC_CHAR_REGEX.test(trimmed)) {
    return text;
  }

  // 1. Direct dictionary match
  if (TRANSLATIONS_EN[trimmed]) {
    return leadingSpace + TRANSLATIONS_EN[trimmed] + trailingSpace;
  }

  // 2. Trailing punctuation & symbols (: or * or (اختياري) etc.)
  if (trimmed.endsWith(':')) {
    const base = trimmed.slice(0, -1).trim();
    if (TRANSLATIONS_EN[base]) {
      return leadingSpace + `${TRANSLATIONS_EN[base]}:` + trailingSpace;
    }
  }

  if (trimmed.endsWith('*')) {
    const base = trimmed.replace(/\*+$/, '').trim();
    if (TRANSLATIONS_EN[base]) {
      return leadingSpace + `${TRANSLATIONS_EN[base]} *` + trailingSpace;
    }
  }

  // Suffix: (اختياري) -> (Optional)
  if (trimmed.endsWith('(اختياري)')) {
    const base = trimmed.replace(/\(اختياري\)$/, '').trim();
    const translatedBase = TRANSLATIONS_EN[base] || base;
    return leadingSpace + `${translatedBase} (Optional)` + trailingSpace;
  }

  // 3. Leading icons, emojis or bullets (e.g., "⚙️ الإعدادات" -> "⚙️ Settings")
  const emojiMatch = trimmed.match(/^([\p{Extended_Pictographic}\u200d\uFE0F\s\u25A0-\u25FF\u2B50\u2700-\u27BF+\-*•·»«><()#]+)(.+)$/u);
  if (emojiMatch) {
    const iconPrefix = emojiMatch[1];
    const restText = emojiMatch[2].trim();
    if (TRANSLATIONS_EN[restText]) {
      return leadingSpace + `${iconPrefix}${TRANSLATIONS_EN[restText]}` + trailingSpace;
    }
    // Also test restText with dynamic patterns
    for (const pattern of DYNAMIC_PATTERNS_EN) {
      const match = restText.match(pattern.regex);
      if (match) {
        return leadingSpace + `${iconPrefix}${pattern.replace(match)}` + trailingSpace;
      }
    }
  }

  // 4. Dynamic Regex Patterns (e.g. "إجمالي ...", "كشف حساب ...", "تعديل ...")
  for (const pattern of DYNAMIC_PATTERNS_EN) {
    const match = trimmed.match(pattern.regex);
    if (match) {
      return leadingSpace + pattern.replace(match) + trailingSpace;
    }
  }

  return fallback || text;
}

// Elements where text nodes should NOT be auto-translated
const EXCLUDED_TAGS = new Set([
  'SCRIPT', 'STYLE', 'CODE', 'PRE', 'SVG', 'CANVAS', 'TEXTAREA', 'INPUT'
]);

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<SupportedLanguage>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('site_language');
      if (saved === 'en' || saved === 'ar') return saved;
    }
    return 'ar';
  });

  const observerRef = useRef<MutationObserver | null>(null);
  const translatedNodesMap = useRef<WeakMap<Node, string>>(new WeakMap());
  const translatedElementsMap = useRef<WeakMap<HTMLElement, { placeholder?: string | null; title?: string | null; ariaLabel?: string | null }>>(new WeakMap());

  // Function to translate a single text node
  const translateTextNode = useCallback((node: Text) => {
    if (!node.nodeValue || !ARABIC_CHAR_REGEX.test(node.nodeValue)) return;
    const parent = node.parentElement;
    if (!parent) return;

    if (EXCLUDED_TAGS.has(parent.tagName)) return;
    if (parent.closest('[data-no-translate="true"], [data-user-data="true"], .user-data, [contenteditable="true"]')) return;

    const original = node.nodeValue;
    const translated = translateText(original, 'en');
    if (translated !== original) {
      if (!translatedNodesMap.current.has(node)) {
        translatedNodesMap.current.set(node, original);
      }
      node.nodeValue = translated;
    }
  }, []);

  // Function to translate element attributes (placeholder, title, aria-label)
  const translateElementAttrs = useCallback((el: HTMLElement) => {
    if (EXCLUDED_TAGS.has(el.tagName) && el.tagName !== 'INPUT') return;
    if (el.closest('[data-no-translate="true"]')) return;

    const currentSaved = translatedElementsMap.current.get(el) || {};

    // Placeholder
    const placeholder = el.getAttribute('placeholder');
    if (placeholder && ARABIC_CHAR_REGEX.test(placeholder)) {
      const translated = translateText(placeholder, 'en');
      if (translated !== placeholder) {
        if (currentSaved.placeholder === undefined) {
          currentSaved.placeholder = placeholder;
        }
        el.setAttribute('placeholder', translated);
      }
    }

    // Title
    const title = el.getAttribute('title');
    if (title && ARABIC_CHAR_REGEX.test(title)) {
      const translated = translateText(title, 'en');
      if (translated !== title) {
        if (currentSaved.title === undefined) {
          currentSaved.title = title;
        }
        el.setAttribute('title', translated);
      }
    }

    // Aria-label
    const ariaLabel = el.getAttribute('aria-label');
    if (ariaLabel && ARABIC_CHAR_REGEX.test(ariaLabel)) {
      const translated = translateText(ariaLabel, 'en');
      if (translated !== ariaLabel) {
        if (currentSaved.ariaLabel === undefined) {
          currentSaved.ariaLabel = ariaLabel;
        }
        el.setAttribute('aria-label', translated);
      }
    }

    if (currentSaved.placeholder !== undefined || currentSaved.title !== undefined || currentSaved.ariaLabel !== undefined) {
      translatedElementsMap.current.set(el, currentSaved);
    }
  }, []);

  // Recursive DOM subtree translator
  const translateSubtree = useCallback((root: Node) => {
    if (!root) return;

    if (root.nodeType === Node.TEXT_NODE) {
      translateTextNode(root as Text);
      return;
    }

    if (root.nodeType === Node.ELEMENT_NODE) {
      const el = root as HTMLElement;
      if (EXCLUDED_TAGS.has(el.tagName) && el.tagName !== 'INPUT') return;
      if (el.hasAttribute && el.hasAttribute('data-no-translate')) return;

      translateElementAttrs(el);

      // Walk children
      let child = el.firstChild;
      while (child) {
        translateSubtree(child);
        child = child.nextSibling;
      }
    }
  }, [translateTextNode, translateElementAttrs]);

  // Revert DOM back to Arabic
  const revertDOMToArabic = useCallback((root: Node = document.body) => {
    if (!root) return;

    if (root.nodeType === Node.TEXT_NODE) {
      const orig = translatedNodesMap.current.get(root);
      if (orig !== undefined) {
        (root as Text).nodeValue = orig;
      }
      return;
    }

    if (root.nodeType === Node.ELEMENT_NODE) {
      const el = root as HTMLElement;
      const origAttrs = translatedElementsMap.current.get(el);
      if (origAttrs) {
        if (origAttrs.placeholder !== undefined && origAttrs.placeholder !== null) {
          el.setAttribute('placeholder', origAttrs.placeholder);
        }
        if (origAttrs.title !== undefined && origAttrs.title !== null) {
          el.setAttribute('title', origAttrs.title);
        }
        if (origAttrs.ariaLabel !== undefined && origAttrs.ariaLabel !== null) {
          el.setAttribute('aria-label', origAttrs.ariaLabel);
        }
      }

      let child = el.firstChild;
      while (child) {
        revertDOMToArabic(child);
        child = child.nextSibling;
      }
    }
  }, []);

  // DOM Language and Direction applier
  const applyLanguageToDOM = useCallback((lang: SupportedLanguage) => {
    if (typeof document === 'undefined') return;

    const html = document.documentElement;
    const body = document.body;

    html.lang = lang;
    html.dir = lang === 'en' ? 'ltr' : 'rtl';
    html.setAttribute('data-site-lang', lang);
    if (body) {
      body.dir = lang === 'en' ? 'ltr' : 'rtl';
    }

    if (lang === 'en') {
      html.classList.add('lang-en');
      html.classList.remove('lang-ar');

      // Stop existing observer if any
      if (observerRef.current) {
        observerRef.current.disconnect();
      }

      // Initial translation of current DOM
      translateSubtree(document.body);

      // Setup MutationObserver to continuously catch React state changes and new modals
      const observer = new MutationObserver((mutations) => {
        for (const mutation of mutations) {
          if (mutation.type === 'childList') {
            for (let i = 0; i < mutation.addedNodes.length; i++) {
              translateSubtree(mutation.addedNodes[i]);
            }
          } else if (mutation.type === 'characterData') {
            if (mutation.target.nodeType === Node.TEXT_NODE) {
              translateTextNode(mutation.target as Text);
            }
          } else if (mutation.type === 'attributes') {
            if (mutation.target.nodeType === Node.ELEMENT_NODE) {
              translateElementAttrs(mutation.target as HTMLElement);
            }
          }
        }
      });

      observer.observe(document.body, {
        childList: true,
        subtree: true,
        characterData: true,
        attributes: true,
        attributeFilter: ['placeholder', 'title', 'aria-label']
      });

      observerRef.current = observer;
    } else {
      // Revert to Arabic
      html.classList.remove('lang-en');
      html.classList.add('lang-ar');

      if (observerRef.current) {
        observerRef.current.disconnect();
        observerRef.current = null;
      }

      revertDOMToArabic(document.body);
    }
  }, [translateSubtree, translateTextNode, translateElementAttrs, revertDOMToArabic]);

  const setLanguage = useCallback((newLang: SupportedLanguage) => {
    setLanguageState(newLang);
    if (typeof window !== 'undefined') {
      localStorage.setItem('site_language', newLang);
      applyLanguageToDOM(newLang);
      window.dispatchEvent(new CustomEvent('languagechange', { detail: newLang }));
    }
  }, [applyLanguageToDOM]);

  const toggleLanguage = useCallback(() => {
    setLanguage(language === 'ar' ? 'en' : 'ar');
  }, [language, setLanguage]);

  useEffect(() => {
    applyLanguageToDOM(language);
    return () => {
      if (observerRef.current) {
        observerRef.current.disconnect();
      }
    };
  }, [language, applyLanguageToDOM]);

  // Listen to cross-component or window language events
  useEffect(() => {
    const handleStorage = (e: StorageEvent) => {
      if (e.key === 'site_language' && (e.newValue === 'ar' || e.newValue === 'en')) {
        setLanguageState(e.newValue);
        applyLanguageToDOM(e.newValue);
      }
    };

    const handleCustomLang = (e: any) => {
      if (e.detail && (e.detail === 'ar' || e.detail === 'en') && e.detail !== language) {
        setLanguageState(e.detail);
        applyLanguageToDOM(e.detail);
      }
    };

    window.addEventListener('storage', handleStorage);
    window.addEventListener('languagechange', handleCustomLang);
    return () => {
      window.removeEventListener('storage', handleStorage);
      window.removeEventListener('languagechange', handleCustomLang);
    };
  }, [language, applyLanguageToDOM]);

  const t = useCallback((text: string, fallback?: string): string => {
    return translateText(text, language, fallback);
  }, [language]);

  const isRTL = language === 'ar';
  const dir: 'rtl' | 'ltr' = isRTL ? 'rtl' : 'ltr';

  const contextValue = useMemo(() => ({
    language,
    setLanguage,
    toggleLanguage,
    t,
    isRTL,
    dir
  }), [language, setLanguage, toggleLanguage, t, isRTL, dir]);

  return (
    <LanguageContext.Provider value={contextValue}>
      {children}
    </LanguageContext.Provider>
  );
};

export function useLanguage() {
  return useContext(LanguageContext);
}

export function useTranslation() {
  const { t, language, isRTL, dir, setLanguage, toggleLanguage } = useLanguage();
  return { t, language, isRTL, dir, setLanguage, toggleLanguage };
}

export default LanguageContext;
