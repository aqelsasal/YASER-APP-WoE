/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { registerPlugin, Capacitor } from '@capacitor/core';

export interface NativeBiometricAvailability {
  isAvailable: boolean;
  hasHardware: boolean;
  isEnrolled: boolean;
  code: string;
  message: string;
}

export interface NativeBiometricAuthResult {
  verified: boolean;
  cancelled?: boolean;
  errorCode?: number;
  error?: string;
}

export interface NativeBiometricPluginInterface {
  isAvailable(): Promise<NativeBiometricAvailability>;
  openBiometricSettings(): Promise<{ success: boolean }>;
  authenticate(options?: {
    title?: string;
    subtitle?: string;
    description?: string;
    negativeButtonText?: string;
  }): Promise<NativeBiometricAuthResult>;
}

// Register the custom Capacitor NativeBiometric plugin implemented in the Android layer
export const NativeBiometric = registerPlugin<NativeBiometricPluginInterface>('NativeBiometric');

export interface BiometricStatus {
  isSupported: boolean;
  hasHardware: boolean;
  isEnrolled: boolean;
  isNative: boolean;
  message?: string;
  code?: string;
}

/**
 * Check biometric (fingerprint/face) availability across Android APK and Web platforms
 */
export async function getBiometricStatus(): Promise<BiometricStatus> {
  const isNative = Capacitor.isNativePlatform();

  if (isNative) {
    try {
      const res = await NativeBiometric.isAvailable();
      return {
        isSupported: res.isAvailable,
        hasHardware: res.hasHardware,
        isEnrolled: res.isEnrolled,
        isNative: true,
        message: res.message,
        code: res.code
      };
    } catch (err: any) {
      console.warn('NativeBiometric.isAvailable() failed, falling back:', err);
      return {
        isSupported: false,
        hasHardware: true,
        isEnrolled: false,
        isNative: true,
        message: 'مستشعر البصمة غير متاح حالياً.',
        code: 'ERROR'
      };
    }
  }

  // Web Platform / PWA / Browser Fallback via WebAuthn
  if (typeof window !== 'undefined' && window.PublicKeyCredential) {
    try {
      if (typeof PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable === 'function') {
        const available = await PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable();
        return {
          isSupported: available,
          hasHardware: available,
          isEnrolled: available,
          isNative: false,
          message: available ? 'مستشعر البصمة متاح على المتصفح.' : 'المتصفح لا يدعم مستشعر بصمة نشط.'
        };
      }
      return {
        isSupported: true,
        hasHardware: true,
        isEnrolled: true,
        isNative: false
      };
    } catch (e) {
      return {
        isSupported: false,
        hasHardware: false,
        isEnrolled: false,
        isNative: false,
        message: 'فحص البصمة على المتصفح غير مدعوم.'
      };
    }
  }

  return {
    isSupported: false,
    hasHardware: false,
    isEnrolled: false,
    isNative: false,
    message: 'المتصفح الحالي لا يدعم مستشعر البصمة.'
  };
}

/**
 * Open device's native fingerprint/biometric enrollment settings
 */
export async function openPhoneBiometricSettings(): Promise<boolean> {
  if (Capacitor.isNativePlatform()) {
    try {
      const res = await NativeBiometric.openBiometricSettings();
      return Boolean(res?.success);
    } catch (e) {
      console.warn('Could not open native biometric settings', e);
      return false;
    }
  }
  return false;
}

/**
 * Unified Biometric Unlock trigger
 */
export async function performBiometricAuthentication(options?: {
  title?: string;
  subtitle?: string;
  description?: string;
  negativeButtonText?: string;
}): Promise<{ success: boolean; error?: string; cancelled?: boolean; needEnrollment?: boolean }> {
  const isNative = Capacitor.isNativePlatform();

  if (isNative) {
    try {
      const status = await NativeBiometric.isAvailable();
      if (!status.isAvailable) {
        if (status.code === 'NONE_ENROLLED') {
          return {
            success: false,
            needEnrollment: true,
            error: 'الهاتف يدعم البصمة ولكن لم يتم تسجيل أي بصمة في إعدادات الهاتف بعد. يرجى تسجيل بصمتك في إعدادات الهاتف.'
          };
        }
        return {
          success: false,
          error: status.message || 'مستشعر البصمة غير متاح على هذا الهاتف.'
        };
      }

      const res = await NativeBiometric.authenticate({
        title: options?.title || 'نظام الأمان والتحقق من الهوية',
        subtitle: options?.subtitle || 'المس مستشعر البصمة لفتح قفل التطبيق',
        description: options?.description || 'يرجى مسح بصمة إصبعك لتأكيد هويتك ومتابعة استخدام التطبيق بأمان',
        negativeButtonText: options?.negativeButtonText || 'إلغاء / استخدام كلمة المرور'
      });

      if (res.verified) {
        return { success: true };
      }

      if (res.cancelled) {
        return { success: false, cancelled: true, error: 'تم إلغاء عملية البصمة.' };
      }

      return {
        success: false,
        error: res.error || 'لم يتم التعرف على البصمة بواسطة مستشعر الهاتف.'
      };
    } catch (err: any) {
      console.error('Native biometric authentication error:', err);
      return {
        success: false,
        error: err.message || 'حدث خطأ أثناء الاتصال بمستشعر البصمة.'
      };
    }
  }

  // Not native (Web browser WebAuthn handled in securityManager)
  return { success: false, error: 'NOT_NATIVE' };
}
