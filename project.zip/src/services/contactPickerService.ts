/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { registerPlugin } from '@capacitor/core';

export interface NativeContactResult {
  phoneNumber?: string;
  phoneNumbers?: string[];
  name?: string;
  cancelled?: boolean;
}

export interface ContactPickerPluginInterface {
  pickContact(): Promise<NativeContactResult>;
}

// Register the custom Capacitor ContactPicker plugin implemented in Android native layer
const ContactPicker = registerPlugin<ContactPickerPluginInterface>('ContactPicker');

/**
 * Standardize and clean phone number to 9-digit format (Yemeni / local standard)
 */
export function cleanPhoneNumber(raw: string): string {
  if (!raw) return '';
  // Remove all non-digit characters
  let digits = raw.replace(/\D/g, '');

  // Strip international Yemen prefixes (+967 / 00967 / 967)
  if (digits.startsWith('00967') && digits.length >= 14) {
    digits = digits.slice(5);
  } else if (digits.startsWith('967') && digits.length >= 12) {
    digits = digits.slice(3);
  } else if (digits.startsWith('0') && digits.length === 10) {
    digits = digits.slice(1);
  }

  // If longer than 9 digits, look for a 9-digit segment starting with 7 (mobile) or take last 9 digits
  if (digits.length > 9) {
    const match = digits.match(/7[0-9]{8}/);
    if (match) {
      return match[0];
    }
    return digits.slice(-9);
  }

  return digits;
}

export interface PickContactResponse {
  success: boolean;
  phoneNumbers?: string[];
  phoneNumber?: string;
  contactName?: string;
  rawPhoneNumbers?: string[];
  cancelled?: boolean;
  message?: string;
}

/**
 * Directly opens the device's native Phone Contacts screen to select a contact,
 * and fetches ALL phone numbers present in that contact.
 * Operates without showing any intermediate in-app popup dialogs.
 */
export async function pickContactDirectly(): Promise<PickContactResponse> {
  // 1. Android Native APK Flow (Capacitor Native Activity Intent)
  try {
    const res = await ContactPicker.pickContact();
    if (res && res.cancelled) {
      return { success: false, cancelled: true };
    }

    // Collect all raw phone numbers returned
    const rawList: string[] = [];
    if (Array.isArray(res.phoneNumbers) && res.phoneNumbers.length > 0) {
      res.phoneNumbers.forEach(n => {
        if (n && typeof n === 'string' && n.trim().length > 0) {
          rawList.push(n.trim());
        }
      });
    } else if (res.phoneNumber && typeof res.phoneNumber === 'string' && res.phoneNumber.trim().length > 0) {
      rawList.push(res.phoneNumber.trim());
    }

    if (rawList.length > 0) {
      // Clean and deduplicate all numbers
      const cleanedList: string[] = [];
      rawList.forEach(raw => {
        const cleaned = cleanPhoneNumber(raw) || raw;
        if (cleaned && !cleanedList.includes(cleaned)) {
          cleanedList.push(cleaned);
        }
      });

      return {
        success: true,
        phoneNumbers: cleanedList,
        phoneNumber: cleanedList[0] || '',
        contactName: res.name || '',
        rawPhoneNumbers: rawList,
        cancelled: false
      };
    }

    return {
      success: false,
      cancelled: false,
      message: 'جهة الاتصال المحددة لا تحتوي على أي أرقام هواتف مسجلة.'
    };
  } catch (nativeErr: any) {
    console.warn('Native ContactPicker plugin error, trying web fallback:', nativeErr);
  }

  // 2. Web Browser Fallback (e.g., Chrome on Android or Desktop PWA)
  if (typeof navigator !== 'undefined' && 'contacts' in navigator && typeof (navigator as any).contacts?.select === 'function') {
    try {
      const contacts = await (navigator as any).contacts.select(['tel', 'name'], { multiple: false });
      if (contacts && contacts.length > 0) {
        const selected = contacts[0];
        const rawList: string[] = [];

        if (Array.isArray(selected.tel)) {
          selected.tel.forEach((t: string) => {
            if (t && typeof t === 'string' && t.trim().length > 0) {
              rawList.push(t.trim());
            }
          });
        } else if (typeof selected.tel === 'string' && selected.tel.trim().length > 0) {
          rawList.push(selected.tel.trim());
        }

        const nameVal = Array.isArray(selected.name) && selected.name.length > 0 
          ? selected.name[0] 
          : (typeof selected.name === 'string' ? selected.name : '');

        const cleanedList: string[] = [];
        rawList.forEach(raw => {
          const cleaned = cleanPhoneNumber(raw) || raw;
          if (cleaned && !cleanedList.includes(cleaned)) {
            cleanedList.push(cleaned);
          }
        });

        if (cleanedList.length > 0) {
          return {
            success: true,
            phoneNumbers: cleanedList,
            phoneNumber: cleanedList[0],
            contactName: nameVal,
            rawPhoneNumbers: rawList,
            cancelled: false
          };
        }
      }
      return { success: false, cancelled: true };
    } catch (webErr: any) {
      if (webErr?.name === 'AbortError') {
        return { success: false, cancelled: true };
      }
      console.warn('Web ContactPicker error:', webErr);
    }
  }

  // 3. Fallback when neither native plugin nor browser picker is supported
  return {
    success: false,
    cancelled: false,
    message: 'دليل جهات الاتصال متاح فقط على أجهزة الهاتف أو المتصفحات الداعمة.'
  };
}
