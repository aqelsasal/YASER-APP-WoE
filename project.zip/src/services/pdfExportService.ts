/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Capacitor } from '@capacitor/core';
import { Filesystem, Directory } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';
import html2canvas from 'html2canvas';
import { jsPDF } from 'jspdf';
import { ensureDateInFilename } from '../types';

export interface PDFExportOptions {
  title: string;
  htmlContent: string;
  onStatusUpdate?: (status: string) => void;
  mode?: 'export_print' | 'share';
}

export interface PDFExportResult {
  success: boolean;
  message: string;
  filePath?: string;
  fileUri?: string;
  isNative: boolean;
  error?: string;
}

/**
 * Check if the application is running as a native Android or iOS app via Capacitor
 */
export function isNativeAndroidApp(): boolean {
  try {
    return Capacitor.isNativePlatform() || Capacitor.getPlatform() === 'android';
  } catch {
    return false;
  }
}

/**
 * Clean and format filename for safe filesystem saving
 */
export function sanitizeReportFilename(rawTitle: string, extension: string = 'pdf'): string {
  const datedTitle = ensureDateInFilename(rawTitle);
  // Replace illegal filename characters with underscores
  const clean = datedTitle
    .replace(/[/\\?%*:|"<>]/g, '_')
    .replace(/\s+/g, '_')
    .trim();
  const ext = extension.startsWith('.') ? extension : `.${extension}`;
  return clean.toLowerCase().endsWith(ext.toLowerCase()) ? clean : `${clean}${ext}`;
}

/**
 * Wrap raw HTML into a styled standalone document for PDF rendering
 */
export function wrapHtmlForPdf(htmlContent: string, title: string): string {
  return `
    <div class="pdf-export-wrapper" dir="rtl" style="font-family: 'Cairo', 'Segoe UI', Tahoma, sans-serif; color: #0f172a; background: #ffffff; padding: 18px 20px; width: 794px; max-width: 794px; box-sizing: border-box; margin: 0; line-height: 1.45; -webkit-font-smoothing: antialiased;">
      <style>
        .no-print, .no-print-btn, button { display: none !important; }
        
        /* Layout tables (headers/footers) must not have borders */
        .official-report-layout-table, 
        .official-report-layout-table > thead > tr > td,
        .official-report-layout-table > tbody > tr > td,
        .official-report-layout-table > tfoot > tr > td {
          border: none !important;
          padding: 0 !important;
          background: transparent !important;
        }

        /* Data tables styling */
        table {
          width: 100% !important;
          border-collapse: collapse !important;
          margin-bottom: 12px !important;
          table-layout: auto !important;
          background-color: #ffffff !important;
        }
        
        th, td {
          border: 1px solid #cbd5e1 !important;
          padding: 6px 8px !important;
          text-align: right !important;
          font-size: 11px !important;
          color: #0f172a !important;
          vertical-align: middle !important;
        }

        /* Clean header styling */
        th {
          background-color: #f1f5f9 !important;
          color: #002B49 !important;
          font-weight: 800 !important;
        }

        .report-section-title {
          font-size: 13px !important;
          font-weight: 800 !important;
          color: #002B49 !important;
          margin: 14px 0 6px 0 !important;
          border-bottom: 2px solid #e2e8f0 !important;
          padding-bottom: 4px !important;
        }

        .official-report-header {
          border-bottom: 3px double #002B49 !important;
          padding-bottom: 10px !important;
          margin-bottom: 14px !important;
        }

        tr {
          page-break-inside: avoid !important;
          break-inside: avoid !important;
        }

        img {
          max-width: 100% !important;
          height: auto !important;
          display: inline-block !important;
        }

        /* Ensure font display */
        * {
          box-sizing: border-box !important;
          font-family: 'Cairo', 'Segoe UI', Tahoma, sans-serif;
        }
      </style>
      ${htmlContent}
    </div>
  `;
}

/**
 * Main native/web PDF export engine using direct html2canvas + jsPDF
 * High quality, zero empty pages, verified multi-page slicing
 */
export async function exportReportToPDF(options: PDFExportOptions): Promise<PDFExportResult> {
  const { title, htmlContent, onStatusUpdate, mode = 'export_print' } = options;
  const isNative = isNativeAndroidApp();
  const safeFilename = sanitizeReportFilename(title, 'pdf');

  let tempContainer: HTMLElement | null = null;

  try {
    if (onStatusUpdate) onStatusUpdate('جاري إعداد محتوى التقرير للطباعة...');

    // 1. Create a visible container at top-left with high positive zIndex
    // Critical: NEVER set zIndex to negative, as html2canvas renders negative z-index
    // behind the canvas white background causing blank/empty pages!
    tempContainer = document.createElement('div');
    tempContainer.id = 'active-pdf-export-container';
    tempContainer.dir = 'rtl';
    tempContainer.style.position = 'fixed';
    tempContainer.style.top = '0';
    tempContainer.style.left = '0';
    tempContainer.style.width = '794px';
    tempContainer.style.maxWidth = '794px';
    tempContainer.style.minHeight = 'auto';
    tempContainer.style.backgroundColor = '#ffffff';
    tempContainer.style.color = '#0f172a';
    tempContainer.style.zIndex = '999999'; // Positive high zIndex so it's fully painted
    tempContainer.style.opacity = '1';
    tempContainer.style.visibility = 'visible';
    tempContainer.style.overflow = 'visible';
    tempContainer.style.pointerEvents = 'none';
    tempContainer.style.boxSizing = 'border-box';
    tempContainer.style.margin = '0';
    tempContainer.style.padding = '0';
    tempContainer.innerHTML = wrapHtmlForPdf(htmlContent, title);
    document.body.appendChild(tempContainer);

    // 2. Allow styles, fonts, and images to settle in DOM
    await new Promise(resolve => setTimeout(resolve, 220));
    if (document.fonts && document.fonts.ready) {
      try { await document.fonts.ready; } catch (_) {}
    }

    // Wait for any images (logos, stamps) to load
    const images = Array.from(tempContainer.querySelectorAll('img'));
    if (images.length > 0) {
      await Promise.all(images.map(img => {
        if (img.complete && img.naturalHeight > 0) return Promise.resolve(true);
        return new Promise(res => {
          img.onload = () => res(true);
          img.onerror = () => res(true);
          setTimeout(() => res(true), 600);
        });
      }));
    }

    if (onStatusUpdate) onStatusUpdate('جاري معالجة وتحويل التقرير إلى مستند PDF عالي الجودة...');

    // 3. Detect and extract header and footer elements for repeating on ALL pages
    const headerEl = (tempContainer.querySelector('.official-report-header') ||
      tempContainer.querySelector('.report-header') ||
      tempContainer.querySelector('thead.report-header')) as HTMLElement | null;

    const footerEl = (tempContainer.querySelector('.official-report-footer') ||
      tempContainer.querySelector('.report-footer') ||
      tempContainer.querySelector('tfoot.report-footer')) as HTMLElement | null;

    // Auto-calculate scale: high quality for standard docs, balanced for long reports to protect mobile RAM
    const containerHeight = tempContainer.scrollHeight || tempContainer.offsetHeight || 1000;
    let scale = isNative ? 1.5 : 1.8;
    if (isNative && containerHeight > 3500) {
      scale = 1.25;
    }
    if (isNative && containerHeight > 7000) {
      scale = 1.0;
    }

    let headerCanvas: HTMLCanvasElement | null = null;
    let footerCanvas: HTMLCanvasElement | null = null;

    // Render official header to dedicated canvas (to repeat on every page)
    if (headerEl) {
      const headerWrapper = document.createElement('div');
      headerWrapper.style.width = '794px';
      headerWrapper.style.backgroundColor = '#ffffff';
      headerWrapper.style.direction = 'rtl';
      headerWrapper.style.fontFamily = "'Cairo', 'Segoe UI', Tahoma, sans-serif";
      headerWrapper.style.boxSizing = 'border-box';
      headerWrapper.style.padding = '0';
      headerWrapper.style.margin = '0';
      if (headerEl.tagName.toLowerCase() === 'thead') {
        headerWrapper.innerHTML = `<table style="width: 100%; border-collapse: collapse; margin: 0; padding: 0; border: none;">${headerEl.outerHTML}</table>`;
      } else {
        headerWrapper.innerHTML = headerEl.outerHTML;
      }
      headerWrapper.style.position = 'fixed';
      headerWrapper.style.top = '0';
      headerWrapper.style.left = '0';
      headerWrapper.style.zIndex = '999998';
      document.body.appendChild(headerWrapper);

      // Wait for any logo images inside header
      const headerImgs = Array.from(headerWrapper.querySelectorAll('img'));
      if (headerImgs.length > 0) {
        await Promise.all(headerImgs.map(img => {
          if (img.complete && img.naturalHeight > 0) return Promise.resolve(true);
          return new Promise(res => {
            img.onload = () => res(true);
            img.onerror = () => res(true);
            setTimeout(() => res(true), 300);
          });
        }));
      }

      try {
        headerCanvas = await html2canvas(headerWrapper, {
          scale,
          useCORS: true,
          allowTaint: true,
          backgroundColor: '#ffffff',
          logging: false,
          windowWidth: 794
        });
      } catch (hErr) {
        console.warn('Failed to render isolated header:', hErr);
      } finally {
        if (headerWrapper.parentNode) headerWrapper.parentNode.removeChild(headerWrapper);
      }
    }

    // Render official footer to dedicated canvas (to repeat on every page)
    if (footerEl) {
      const footerWrapper = document.createElement('div');
      footerWrapper.style.width = '794px';
      footerWrapper.style.backgroundColor = '#ffffff';
      footerWrapper.style.direction = 'rtl';
      footerWrapper.style.fontFamily = "'Cairo', 'Segoe UI', Tahoma, sans-serif";
      footerWrapper.style.boxSizing = 'border-box';
      footerWrapper.style.padding = '0';
      footerWrapper.style.margin = '0';
      if (footerEl.tagName.toLowerCase() === 'tfoot') {
        footerWrapper.innerHTML = `<table style="width: 100%; border-collapse: collapse; margin: 0; padding: 0; border: none;">${footerEl.outerHTML}</table>`;
      } else {
        footerWrapper.innerHTML = footerEl.outerHTML;
      }
      footerWrapper.style.position = 'fixed';
      footerWrapper.style.top = '0';
      footerWrapper.style.left = '0';
      footerWrapper.style.zIndex = '999998';
      document.body.appendChild(footerWrapper);

      try {
        footerCanvas = await html2canvas(footerWrapper, {
          scale,
          useCORS: true,
          allowTaint: true,
          backgroundColor: '#ffffff',
          logging: false,
          windowWidth: 794
        });
      } catch (fErr) {
        console.warn('Failed to render isolated footer:', fErr);
      } finally {
        if (footerWrapper.parentNode) footerWrapper.parentNode.removeChild(footerWrapper);
      }
    }

    // Hide original header and footer from body container to prevent duplication
    if (headerEl) headerEl.style.display = 'none';
    if (footerEl) footerEl.style.display = 'none';

    // 4. Render the body content container
    const bodyCanvas = await html2canvas(tempContainer, {
      scale,
      useCORS: true,
      allowTaint: true,
      backgroundColor: '#ffffff',
      logging: false,
      scrollX: 0,
      scrollY: 0,
      windowWidth: 794
    });

    // Clean up temporary DOM container immediately
    if (tempContainer && tempContainer.parentNode) {
      document.body.removeChild(tempContainer);
      tempContainer = null;
    }

    // Validate body canvas contains data
    if (!bodyCanvas || bodyCanvas.width === 0 || bodyCanvas.height === 0) {
      throw new Error('فشل التقاط محتوى التقرير (لوحة الرسم فارغة)');
    }

    if (onStatusUpdate) onStatusUpdate('جاري تجميع وتنسيق صفحات الـ PDF وترتيب الترويسة والتذييل...');

    // 5. Construct A4 PDF document using jsPDF with exact multi-page pagination
    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4',
      compress: true
    });

    const pageWidth = 210; // mm
    const pageHeight = 297; // mm
    const marginX = 7; // mm left & right margins
    const marginTop = 6; // mm top margin
    const marginBottom = 6; // mm bottom margin
    const printableWidth = pageWidth - (marginX * 2); // 196 mm

    const headerHeightMm = headerCanvas ? (headerCanvas.height * printableWidth) / headerCanvas.width : 0;
    const footerHeightMm = footerCanvas ? (footerCanvas.height * printableWidth) / footerCanvas.width : 0;
    const gapTop = headerCanvas ? 2 : 0;
    const gapBottom = footerCanvas ? 2 : 0;

    // Available height strictly for the body content slice on each page
    const availableContentHeightMm = Math.max(70, pageHeight - marginTop - marginBottom - headerHeightMm - footerHeightMm - gapTop - gapBottom);

    // Canvas pixels corresponding to one page of body content
    const canvasSliceHeight = (bodyCanvas.width * availableContentHeightMm) / printableWidth;
    const totalPages = Math.max(1, Math.ceil(bodyCanvas.height / canvasSliceHeight));

    // Pre-encode header and footer once for all pages (HUGE performance boost on mobile)
    const headerImgData = headerCanvas ? headerCanvas.toDataURL('image/jpeg', 0.92) : null;
    const footerImgData = footerCanvas ? footerCanvas.toDataURL('image/jpeg', 0.92) : null;

    // Reusable slice canvas
    const sliceCanvas = document.createElement('canvas');
    sliceCanvas.width = bodyCanvas.width;
    const sliceCtx = sliceCanvas.getContext('2d');

    // Construct each page with repeating header, slice of body content, repeating footer, and page number
    for (let page = 0; page < totalPages; page++) {
      if (page > 0) {
        pdf.addPage();
      }

      // 1. Draw Header on EVERY page
      if (headerImgData) {
        pdf.addImage(headerImgData, 'JPEG', marginX, marginTop, printableWidth, headerHeightMm, undefined, 'FAST');
      }

      // 2. Draw Body slice for this page
      const sourceY = page * canvasSliceHeight;
      const currentSliceHeight = Math.min(canvasSliceHeight, bodyCanvas.height - sourceY);

      if (currentSliceHeight > 0 && sliceCtx) {
        sliceCanvas.height = currentSliceHeight;
        sliceCtx.fillStyle = '#ffffff';
        sliceCtx.fillRect(0, 0, sliceCanvas.width, currentSliceHeight);
        sliceCtx.drawImage(
          bodyCanvas,
          0, sourceY, bodyCanvas.width, currentSliceHeight,
          0, 0, sliceCanvas.width, currentSliceHeight
        );

        const sliceImgData = sliceCanvas.toDataURL('image/jpeg', 0.90);
        const renderHeightMm = (currentSliceHeight * printableWidth) / bodyCanvas.width;
        const bodyY = marginTop + headerHeightMm + gapTop;
        pdf.addImage(sliceImgData, 'JPEG', marginX, bodyY, printableWidth, renderHeightMm, undefined, 'FAST');
      }

      // 3. Draw Footer on EVERY page
      if (footerImgData) {
        const footerY = pageHeight - marginBottom - footerHeightMm;
        pdf.addImage(footerImgData, 'JPEG', marginX, footerY, printableWidth, footerHeightMm, undefined, 'FAST');
      }

      // 4. Draw Page Number at bottom of every page
      pdf.setFontSize(8);
      pdf.setTextColor(100, 116, 139);
      pdf.text(`صفحة ${page + 1} من ${totalPages}`, pageWidth / 2, pageHeight - 2.5, { align: 'center' });
    }

    // 6. Output PDF as Data URI & Base64
    const dataUri: string = pdf.output('datauristring');
    const commaIndex = dataUri.indexOf(',');
    const base64Data = commaIndex !== -1 ? dataUri.substring(commaIndex + 1) : dataUri;

    if (!base64Data || base64Data.length < 500) {
      throw new Error('تعذر إنشاء مستند الـ PDF بشكل سليم');
    }

    if (isNative) {
      // 📱 NATIVE ANDROID FLOW:
      if (onStatusUpdate) onStatusUpdate('جاري حفظ مستند الـ PDF وفتح الطباعة بالهاتف...');

      // A. Write to Cache directory first (Guaranteed, zero permission issues, FileProvider compatible)
      let shareUri = '';
      try {
        const cacheResult = await Filesystem.writeFile({
          path: safeFilename,
          data: base64Data,
          directory: Directory.Cache,
          recursive: true
        });
        shareUri = cacheResult.uri;
      } catch (cacheErr) {
        console.warn('PDF cache write failed:', cacheErr);
      }

      // B. Asynchronous background write to Documents directory (Non-blocking, never freezes UI)
      const savedPath = `YaserAqelApp_Reports/${safeFilename}`;
      Filesystem.writeFile({
        path: savedPath,
        data: base64Data,
        directory: Directory.Documents,
        recursive: true
      }).catch(() => {
        Filesystem.writeFile({
          path: safeFilename,
          data: base64Data,
          directory: Directory.Data,
          recursive: true
        }).catch(() => {});
      });

      const fileToShare = shareUri;

      if (mode === 'share') {
        if (onStatusUpdate) onStatusUpdate('تم إنشاء مستند الـ PDF! جاري فتح نافذة المشاركة بالهاتف...');

        try {
          await Share.share({
            title: title,
            files: [fileToShare],
            dialogTitle: 'مشاركة مستند التقرير PDF'
          });
        } catch (shareErr) {
          // If share dialog dismissed, file is still saved successfully
        }

        return {
          success: true,
          message: `تم فتح نافذة المشاركة لمستند الـ PDF بنجاح (${safeFilename})`,
          filePath: savedPath,
          fileUri: fileToShare,
          isNative: true
        };
      } else {
        // mode === 'export_print': ON ANDROID, LAUNCH THE SYSTEM PRINT / PDF INTENT IMMEDIATELY
        // Android's native share sheet includes the Default Print Service (خدمة الطباعة), Drive & PDF Viewers!
        if (onStatusUpdate) onStatusUpdate('تم تجهيز التقرير! جاري فتح خيارات الطباعة والحفظ بالهاتف...');

        try {
          await Share.share({
            title: title,
            files: [fileToShare],
            dialogTitle: 'طباعة أو فتح مستند الـ PDF'
          });
        } catch (_) {
          // User closed print/share sheet, still successful
        }

        return {
          success: true,
          message: `تم تصدير مستند الـ PDF بنجاح (${safeFilename}) وفُتحت خيارات الطباعة بالهاتف`,
          filePath: savedPath,
          fileUri: fileToShare,
          isNative: true
        };
      }
    } else {
      // 💻 WEB BROWSER FLOW:
      if (mode === 'share') {
        const pdfBlob = pdf.output('blob');
        const pdfFile = new File([pdfBlob], safeFilename, { type: 'application/pdf' });

        if (typeof navigator !== 'undefined' && navigator.canShare && navigator.canShare({ files: [pdfFile] })) {
          try {
            await navigator.share({
              files: [pdfFile],
              title: title
            });
            return {
              success: true,
              message: `تمت مشاركة مستند الـ PDF بنجاح: ${safeFilename}`,
              filePath: safeFilename,
              isNative: false
            };
          } catch (shareErr: any) {
            if (shareErr?.name === 'AbortError') {
              return { success: true, message: 'تم إغلاق نافذة المشاركة', filePath: safeFilename, isNative: false };
            }
          }
        }

        // Direct file download fallback for browsers without file sharing
        pdf.save(safeFilename);

        return {
          success: true,
          message: `تم تنزيل مستند الـ PDF بنجاح (${safeFilename}) ويمكنك مشاركته الآن.`,
          filePath: safeFilename,
          isNative: false
        };
      } else {
        // Direct browser PDF file download
        pdf.save(safeFilename);

        return {
          success: true,
          message: `تم تنزيل ملف الـ PDF بنجاح: ${safeFilename}`,
          filePath: safeFilename,
          isNative: false
        };
      }
    }
  } catch (err: any) {
    // Ensure clean DOM cleanup on error
    if (tempContainer && tempContainer.parentNode) {
      tempContainer.parentNode.removeChild(tempContainer);
    }
    const orphan = document.getElementById('active-pdf-export-container');
    if (orphan && orphan.parentNode) {
      orphan.parentNode.removeChild(orphan);
    }

    console.error('Error generating PDF report:', err);
    return {
      success: false,
      message: err?.message || 'حدث خطأ أثناء تصدير ملف الـ PDF',
      isNative,
      error: String(err)
    };
  }
}

/**
 * Direct PDF report generation and sharing without passing through the print preview modal.
 * Triggers native Android Share sheet or WhatsApp directly.
 */
export async function directShareReportPDF(options: {
  title: string;
  htmlContent: string;
  target?: 'whatsapp' | 'system';
  onStatusUpdate?: (status: string) => void;
}): Promise<PDFExportResult> {
  const { title, htmlContent, onStatusUpdate } = options;
  if (typeof window !== 'undefined' && (window as any).showToast) {
    (window as any).showToast('📄 جاري معالجة وتجهيز مستند الـ PDF للمشاركة...');
  }
  return exportReportToPDF({
    title,
    htmlContent,
    onStatusUpdate,
    mode: 'share'
  });
}

/**
 * Export report as standalone HTML file (Native phone saving + Web download)
 */
export async function exportReportToHTML(options: PDFExportOptions): Promise<PDFExportResult> {
  const { title, htmlContent, onStatusUpdate } = options;
  const isNative = isNativeAndroidApp();
  const safeFilename = sanitizeReportFilename(title, 'html');

  try {
    const fullHtml = `<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
  <meta charset="utf-8">
  <title>${title}</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800&display=swap" rel="stylesheet">
  <style>
    body { font-family: 'Cairo', sans-serif; padding: 20px; color: #1e293b; direction: rtl; background-color: #fff; line-height: 1.5; }
    table { width: 100%; border-collapse: collapse; margin-bottom: 16px; }
    th, td { border: 1px solid #cbd5e1; padding: 8px 10px; text-align: right; font-size: 11.5px; }
    th { background-color: #f1f5f9; color: #0f172a; font-weight: bold; }
    .no-print { display: none !important; }
    @media print {
      @page { size: A4 portrait; margin: 10mm; }
      body { padding: 0; }
      tr { break-inside: avoid; page-break-inside: avoid; }
    }
  </style>
</head>
<body>
  ${htmlContent}
</body>
</html>`;

  if (isNative) {
    if (onStatusUpdate) onStatusUpdate('جاري حفظ ملف HTML في الهاتف...');
    
    // Encode UTF-8 string to base64 for Capacitor Filesystem
    const utf8Bytes = new TextEncoder().encode(fullHtml);
    let binary = '';
    for (let i = 0; i < utf8Bytes.length; i++) {
      binary += String.fromCharCode(utf8Bytes[i]);
    }
    const base64Data = btoa(binary);

    let shareUri = '';
    try {
      const cacheResult = await Filesystem.writeFile({
        path: safeFilename,
        data: base64Data,
        directory: Directory.Cache,
        recursive: true
      });
      shareUri = cacheResult.uri;
    } catch (cacheErr) {
      console.warn('HTML cache write failed:', cacheErr);
    }

    let savedFileUri = shareUri;
    try {
      const writeResult = await Filesystem.writeFile({
        path: `YaserAqelApp_Reports/${safeFilename}`,
        data: base64Data,
        directory: Directory.Documents,
        recursive: true
      });
      savedFileUri = writeResult.uri;
    } catch {
      try {
        const dataResult = await Filesystem.writeFile({
          path: safeFilename,
          data: base64Data,
          directory: Directory.Data,
          recursive: true
        });
        savedFileUri = dataResult.uri;
      } catch (_) {}
    }

    try {
      await Share.share({
        title: title,
        files: [shareUri || savedFileUri],
        dialogTitle: 'فتح أو مشاركة ملف التقرير'
      });
    } catch (shareErr) {}

    return {
      success: true,
      message: `تم حفظ ومشاركة ملف التقرير بنجاح: ${safeFilename}`,
      filePath: safeFilename,
      fileUri: savedFileUri || shareUri,
      isNative: true
    };
  } else {
    const blob = new Blob([fullHtml], { type: 'text/html;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = safeFilename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    return {
      success: true,
      message: `تم تحميل ملف HTML بنجاح: ${safeFilename}`,
      filePath: safeFilename,
      isNative: false
    };
  }
} catch (err: any) {
  return {
    success: false,
    message: err?.message || 'حدث خطأ أثناء تصدير ملف HTML',
    isNative,
    error: String(err)
  };
}
}
