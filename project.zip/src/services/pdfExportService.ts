/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Capacitor } from '@capacitor/core';
import { Filesystem, Directory } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';
import { ensureDateInFilename } from '../types';

export interface PDFExportOptions {
  title: string;
  htmlContent: string;
  onStatusUpdate?: (status: string) => void;
}

export interface PDFExportResult {
  success: boolean;
  message: string;
  filePath?: string;
  fileUri?: string;
  isNative: boolean;
  error?: string;
}

/**
 * Check if the application is running as a native Android or iOS app via Capacitor
 */
export function isNativeAndroidApp(): boolean {
  try {
    return Capacitor.isNativePlatform() || Capacitor.getPlatform() === 'android';
  } catch {
    return false;
  }
}

/**
 * Clean and format filename for safe filesystem saving
 */
export function sanitizeReportFilename(rawTitle: string, extension: string = 'pdf'): string {
  const datedTitle = ensureDateInFilename(rawTitle);
  // Replace illegal filename characters with underscores
  const clean = datedTitle
    .replace(/[/\\?%*:|"<>]/g, '_')
    .replace(/\s+/g, '_')
    .trim();
  const ext = extension.startsWith('.') ? extension : `.${extension}`;
  return clean.toLowerCase().endsWith(ext.toLowerCase()) ? clean : `${clean}${ext}`;
}

/**
 * Wrap raw HTML into a styled standalone document for PDF rendering
 */
export function wrapHtmlForPdf(htmlContent: string, title: string): string {
  return `
    <div class="pdf-export-wrapper" dir="rtl" style="font-family: 'Cairo', 'Segoe UI', Tahoma, sans-serif; color: #1e293b; background: #ffffff; padding: 12px; width: 100%; box-sizing: border-box;">
      <style>
        .no-print, .no-print-btn, button { display: none !important; }
        table { width: 100% !important; border-collapse: collapse !important; margin-bottom: 14px !important; }
        th, td { border: 1px solid #cbd5e1 !important; padding: 6px 8px !important; text-align: right !important; font-size: 11px !important; }
        th { background-color: #f1f5f9 !important; color: #0f172a !important; font-weight: bold !important; }
        .report-section-title { font-size: 13px !important; font-weight: 800 !important; color: #002B49 !important; margin: 16px 0 8px 0 !important; border-bottom: 2px solid #e2e8f0 !important; padding-bottom: 4px !important; }
        .official-report-header { border-bottom: 3px double #002B49 !important; padding-bottom: 10px !important; margin-bottom: 16px !important; }
        tr { page-break-inside: avoid !important; break-inside: avoid !important; }
        img { max-width: 100% !important; height: auto !important; }
      </style>
      ${htmlContent}
    </div>
  `;
}

/**
 * Main native/web PDF export engine
 */
export async function exportReportToPDF(options: PDFExportOptions): Promise<PDFExportResult> {
  const { title, htmlContent, onStatusUpdate } = options;
  const isNative = isNativeAndroidApp();
  const safeFilename = sanitizeReportFilename(title, 'pdf');

  try {
    if (onStatusUpdate) onStatusUpdate('جاري إعداد محتوى التقرير للطباعة...');

    // Create an offscreen temporary DOM container to render HTML cleanly
    const tempContainer = document.createElement('div');
    tempContainer.id = 'temp-pdf-export-container';
    tempContainer.style.position = 'fixed';
    tempContainer.style.left = '-9999px';
    tempContainer.style.top = '0';
    tempContainer.style.width = '820px'; // Standard A4 width proportion
    tempContainer.style.backgroundColor = '#ffffff';
    tempContainer.style.zIndex = '-9999';
    tempContainer.innerHTML = wrapHtmlForPdf(htmlContent, title);
    document.body.appendChild(tempContainer);

    // Ensure html2pdf is available
    const html2pdfLib = (window as any).html2pdf;
    if (!html2pdfLib) {
      document.body.removeChild(tempContainer);
      throw new Error('مكتبة html2pdf غير متوفرة في الصفحة');
    }

    if (onStatusUpdate) onStatusUpdate('جاري تحويل التقرير إلى مستند PDF عالي الجودة...');

    const pdfOptions = {
      margin: [8, 8, 10, 8], // mm margins
      filename: safeFilename,
      image: { type: 'jpeg', quality: 0.98 },
      html2canvas: {
        scale: 2,
        useCORS: true,
        logging: false,
        letterRendering: true,
        scrollX: 0,
        scrollY: 0
      },
      jsPDF: {
        unit: 'mm',
        format: 'a4',
        orientation: 'portrait',
        compress: true
      },
      pagebreak: { mode: ['avoid-all', 'css', 'legacy'] }
    };

    if (isNative) {
      // 📱 NATIVE ANDROID/IOS FLOW:
      // Generate PDF data as Base64 URI string
      if (onStatusUpdate) onStatusUpdate('جاري حفظ ملف الـ PDF في ذاكرة الهاتف...');
      
      const worker = html2pdfLib().set(pdfOptions).from(tempContainer);
      const dataUri: string = await worker.outputPdf('datauristring');
      
      // Remove temporary DOM container
      if (tempContainer.parentNode) {
        document.body.removeChild(tempContainer);
      }

      // Extract raw base64 data (without 'data:application/pdf;base64,' prefix)
      const base64Index = dataUri.indexOf(';base64,');
      const base64Data = base64Index !== -1 ? dataUri.substring(base64Index + 8) : dataUri;

      // 1. Write file to Cache directory first (guaranteed FileProvider compatible for Android Share Sheet)
      let shareUri = '';
      try {
        const cacheResult = await Filesystem.writeFile({
          path: safeFilename,
          data: base64Data,
          directory: Directory.Cache,
          recursive: true
        });
        shareUri = cacheResult.uri;
      } catch (cacheErr) {
        console.warn('PDF cache write failed:', cacheErr);
      }

      // 2. Also write to Documents directory for persistent file keeping in the phone
      let savedFileUri = shareUri;
      let savedPath = safeFilename;

      try {
        const docResult = await Filesystem.writeFile({
          path: `YaserAqelApp_Reports/${safeFilename}`,
          data: base64Data,
          directory: Directory.Documents,
          recursive: true
        });
        savedFileUri = docResult.uri;
      } catch (docErr) {
        try {
          const dataResult = await Filesystem.writeFile({
            path: safeFilename,
            data: base64Data,
            directory: Directory.Data,
            recursive: true
          });
          savedFileUri = dataResult.uri;
        } catch (_) {}
      }

      if (onStatusUpdate) onStatusUpdate('تم إنشاء الـ PDF! جاري فتح نافذة المشاركة والطباعة بالهاتف...');

      // Open Android native share sheet to let user open in PDF Viewer, WhatsApp, or Print Service
      try {
        await Share.share({
          title: title,
          text: `تقرير مالي: ${title}`,
          url: shareUri || savedFileUri,
          dialogTitle: 'فتح أو طباعة تقرير الـ PDF'
        });
      } catch (shareErr) {
        // If share dialog cancelled or failed, file is still saved successfully
      }

      return {
        success: true,
        message: `تم حفظ تقرير الـ PDF بنجاح في جهازك (${safeFilename})`,
        filePath: savedPath,
        fileUri: savedFileUri || shareUri,
        isNative: true
      };
    } else {
      // 💻 WEB BROWSER FLOW:
      // Trigger browser PDF file download directly
      await html2pdfLib().set(pdfOptions).from(tempContainer).save();

      // Clean up DOM container
      if (tempContainer.parentNode) {
        document.body.removeChild(tempContainer);
      }

      return {
        success: true,
        message: `تم تنزيل ملف الـ PDF بنجاح: ${safeFilename}`,
        filePath: safeFilename,
        isNative: false
      };
    }
  } catch (err: any) {
    // Ensure clean DOM cleanup on error
    const orphan = document.getElementById('temp-pdf-export-container');
    if (orphan && orphan.parentNode) {
      orphan.parentNode.removeChild(orphan);
    }

    console.error('Error generating PDF report:', err);
    return {
      success: false,
      message: err?.message || 'حدث خطأ أثناء تصدير ملف الـ PDF',
      isNative,
      error: String(err)
    };
  }
}

/**
 * Export report as standalone HTML file (Native phone saving + Web download)
 */
export async function exportReportToHTML(options: PDFExportOptions): Promise<PDFExportResult> {
  const { title, htmlContent, onStatusUpdate } = options;
  const isNative = isNativeAndroidApp();
  const safeFilename = sanitizeReportFilename(title, 'html');

  try {
    const fullHtml = `<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
  <meta charset="utf-8">
  <title>${title}</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800&display=swap" rel="stylesheet">
  <style>
    body { font-family: 'Cairo', sans-serif; padding: 20px; color: #1e293b; direction: rtl; background-color: #fff; line-height: 1.5; }
    table { width: 100%; border-collapse: collapse; margin-bottom: 16px; }
    th, td { border: 1px solid #cbd5e1; padding: 8px 10px; text-align: right; font-size: 11.5px; }
    th { background-color: #f1f5f9; color: #0f172a; font-weight: bold; }
    .no-print { display: none !important; }
    @media print {
      @page { size: A4 portrait; margin: 10mm; }
      body { padding: 0; }
      tr { break-inside: avoid; page-break-inside: avoid; }
    }
  </style>
</head>
<body>
  ${htmlContent}
</body>
</html>`;

    if (isNative) {
      if (onStatusUpdate) onStatusUpdate('جاري حفظ ملف HTML في الهاتف...');
      
      // Encode UTF-8 string to base64 for Capacitor Filesystem
      const utf8Bytes = new TextEncoder().encode(fullHtml);
      let binary = '';
      for (let i = 0; i < utf8Bytes.length; i++) {
        binary += String.fromCharCode(utf8Bytes[i]);
      }
      const base64Data = btoa(binary);

      let shareUri = '';
      try {
        const cacheResult = await Filesystem.writeFile({
          path: safeFilename,
          data: base64Data,
          directory: Directory.Cache,
          recursive: true
        });
        shareUri = cacheResult.uri;
      } catch (cacheErr) {
        console.warn('HTML cache write failed:', cacheErr);
      }

      let savedFileUri = shareUri;
      try {
        const writeResult = await Filesystem.writeFile({
          path: `YaserAqelApp_Reports/${safeFilename}`,
          data: base64Data,
          directory: Directory.Documents,
          recursive: true
        });
        savedFileUri = writeResult.uri;
      } catch {
        try {
          const dataResult = await Filesystem.writeFile({
            path: safeFilename,
            data: base64Data,
            directory: Directory.Data,
            recursive: true
          });
          savedFileUri = dataResult.uri;
        } catch (_) {}
      }

      try {
        await Share.share({
          title: title,
          text: `تقرير HTML: ${title}`,
          url: shareUri || savedFileUri,
          dialogTitle: 'فتح أو مشاركة ملف التقرير'
        });
      } catch (shareErr) {}

      return {
        success: true,
        message: `تم حفظ ومشاركة ملف التقرير بنجاح: ${safeFilename}`,
        filePath: safeFilename,
        fileUri: savedFileUri || shareUri,
        isNative: true
      };
    } else {
      const blob = new Blob([fullHtml], { type: 'text/html;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = safeFilename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      return {
        success: true,
        message: `تم تحميل ملف HTML بنجاح: ${safeFilename}`,
        filePath: safeFilename,
        isNative: false
      };
    }
  } catch (err: any) {
    return {
      success: false,
      message: err?.message || 'حدث خطأ أثناء تصدير ملف HTML',
      isNative,
      error: String(err)
    };
  }
}
