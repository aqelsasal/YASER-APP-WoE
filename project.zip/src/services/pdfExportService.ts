/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Capacitor } from '@capacitor/core';
import { Filesystem, Directory } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';
import html2canvas from 'html2canvas';
import { jsPDF } from 'jspdf';
import { ensureDateInFilename } from '../types';

export interface PDFExportOptions {
  title: string;
  htmlContent: string;
  onStatusUpdate?: (status: string) => void;
  mode?: 'export_print' | 'share';
}

export interface PDFExportResult {
  success: boolean;
  message: string;
  filePath?: string;
  fileUri?: string;
  isNative: boolean;
  error?: string;
}

/**
 * Check if the application is running as a native Android or iOS app via Capacitor
 */
export function isNativeAndroidApp(): boolean {
  try {
    return Capacitor.isNativePlatform() || Capacitor.getPlatform() === 'android';
  } catch {
    return false;
  }
}

/**
 * Clean and format filename for safe filesystem saving
 */
export function sanitizeReportFilename(rawTitle: string, extension: string = 'pdf'): string {
  const datedTitle = ensureDateInFilename(rawTitle);
  // Replace illegal filename characters with underscores
  const clean = datedTitle
    .replace(/[/\\?%*:|"<>]/g, '_')
    .replace(/\s+/g, '_')
    .trim();
  const ext = extension.startsWith('.') ? extension : `.${extension}`;
  return clean.toLowerCase().endsWith(ext.toLowerCase()) ? clean : `${clean}${ext}`;
}

/**
 * Wrap raw HTML into a styled standalone document for PDF rendering
 */
export function wrapHtmlForPdf(htmlContent: string, title: string): string {
  return `
    <div class="pdf-export-wrapper" dir="rtl" style="font-family: 'Cairo', 'Segoe UI', Tahoma, sans-serif; color: #0f172a; background: #ffffff; padding: 18px 20px; width: 794px; max-width: 794px; box-sizing: border-box; margin: 0; line-height: 1.45; -webkit-font-smoothing: antialiased;">
      <style>
        .no-print, .no-print-btn, button { display: none !important; }
        
        /* Layout tables (headers/footers) must not have borders */
        .official-report-layout-table, 
        .official-report-layout-table > thead > tr > td,
        .official-report-layout-table > tbody > tr > td,
        .official-report-layout-table > tfoot > tr > td {
          border: none !important;
          padding: 0 !important;
          background: transparent !important;
        }

        /* Data tables styling */
        table {
          width: 100% !important;
          border-collapse: collapse !important;
          margin-bottom: 12px !important;
          table-layout: auto !important;
          background-color: #ffffff !important;
        }
        
        th, td {
          border: 1px solid #cbd5e1 !important;
          padding: 6px 8px !important;
          text-align: right !important;
          font-size: 11px !important;
          color: #0f172a !important;
          vertical-align: middle !important;
        }

        /* Clean header styling */
        th {
          background-color: #f1f5f9 !important;
          color: #002B49 !important;
          font-weight: 800 !important;
        }

        .report-section-title {
          font-size: 13px !important;
          font-weight: 800 !important;
          color: #002B49 !important;
          margin: 14px 0 6px 0 !important;
          border-bottom: 2px solid #e2e8f0 !important;
          padding-bottom: 4px !important;
        }

        .official-report-header {
          border-bottom: 3px double #002B49 !important;
          padding-bottom: 10px !important;
          margin-bottom: 14px !important;
        }

        tr {
          page-break-inside: avoid !important;
          break-inside: avoid !important;
        }

        img {
          max-width: 100% !important;
          height: auto !important;
          display: inline-block !important;
        }

        /* Ensure font display */
        * {
          box-sizing: border-box !important;
          font-family: 'Cairo', 'Segoe UI', Tahoma, sans-serif;
        }
      </style>
      ${htmlContent}
    </div>
  `;
}

/**
 * Main native/web PDF export engine using direct html2canvas + jsPDF
 * High quality, zero empty pages, verified multi-page slicing
 */
export async function exportReportToPDF(options: PDFExportOptions): Promise<PDFExportResult> {
  const { title, htmlContent, onStatusUpdate, mode = 'export_print' } = options;
  const isNative = isNativeAndroidApp();
  const safeFilename = sanitizeReportFilename(title, 'pdf');

  let tempContainer: HTMLElement | null = null;

  try {
    if (onStatusUpdate) onStatusUpdate('جاري إعداد محتوى التقرير للطباعة...');

    // 1. Create a visible container at top-left with high positive zIndex
    // Critical: NEVER set zIndex to negative, as html2canvas renders negative z-index
    // behind the canvas white background causing blank/empty pages!
    tempContainer = document.createElement('div');
    tempContainer.id = 'active-pdf-export-container';
    tempContainer.dir = 'rtl';
    tempContainer.style.position = 'fixed';
    tempContainer.style.top = '0';
    tempContainer.style.left = '0';
    tempContainer.style.width = '794px';
    tempContainer.style.maxWidth = '794px';
    tempContainer.style.minHeight = 'auto';
    tempContainer.style.backgroundColor = '#ffffff';
    tempContainer.style.color = '#0f172a';
    tempContainer.style.zIndex = '999999'; // Positive high zIndex so it's fully painted
    tempContainer.style.opacity = '1';
    tempContainer.style.visibility = 'visible';
    tempContainer.style.overflow = 'visible';
    tempContainer.style.pointerEvents = 'none';
    tempContainer.style.boxSizing = 'border-box';
    tempContainer.style.margin = '0';
    tempContainer.style.padding = '0';
    tempContainer.innerHTML = wrapHtmlForPdf(htmlContent, title);
    document.body.appendChild(tempContainer);

    // 2. Allow styles, fonts, and images to settle in DOM
    await new Promise(resolve => setTimeout(resolve, 220));
    if (document.fonts && document.fonts.ready) {
      try { await document.fonts.ready; } catch (_) {}
    }

    // Wait for any images (logos, stamps) to load
    const images = Array.from(tempContainer.querySelectorAll('img'));
    if (images.length > 0) {
      await Promise.all(images.map(img => {
        if (img.complete && img.naturalHeight > 0) return Promise.resolve(true);
        return new Promise(res => {
          img.onload = () => res(true);
          img.onerror = () => res(true);
          setTimeout(() => res(true), 600);
        });
      }));
    }

    if (onStatusUpdate) onStatusUpdate('جاري معالجة وتحويل التقرير إلى مستند PDF عالي الجودة...');

    // 3. Render container to high-res canvas with html2canvas
    const containerHeight = tempContainer.scrollHeight || tempContainer.offsetHeight || 1123;
    // Scale 2 for pristine print quality; if extremely tall, scale 1.5 to stay within device canvas memory
    const scale = containerHeight > 4500 ? 1.5 : 2;

    const canvas = await html2canvas(tempContainer, {
      scale,
      useCORS: true,
      allowTaint: true,
      backgroundColor: '#ffffff',
      logging: false,
      scrollX: 0,
      scrollY: 0,
      windowWidth: 794
    });

    // 4. Clean up temporary DOM container immediately
    if (tempContainer && tempContainer.parentNode) {
      document.body.removeChild(tempContainer);
      tempContainer = null;
    }

    // Validate canvas contains data
    if (!canvas || canvas.width === 0 || canvas.height === 0) {
      throw new Error('فشل التقاط محتوى التقرير (لوحة الرسم فارغة)');
    }

    if (onStatusUpdate) onStatusUpdate('جاري تجميع وتنسيق صفحات الـ PDF (A4)...');

    // 5. Construct A4 PDF document using jsPDF with exact multi-page pagination
    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4',
      compress: true
    });

    const pageWidth = 210; // mm
    const pageHeight = 297; // mm
    const margin = 6; // mm margins
    const printableWidth = pageWidth - (margin * 2); // 198 mm
    const printableHeight = pageHeight - (margin * 2); // 285 mm

    // How many canvas pixels correspond to one printable page height
    const canvasPageHeight = (canvas.width * printableHeight) / printableWidth;
    let sourceY = 0;
    let totalHeightRemaining = canvas.height;
    let pageNumber = 0;

    while (totalHeightRemaining > 0) {
      if (pageNumber > 0) {
        pdf.addPage();
      }

      const currentChunkHeight = Math.min(canvasPageHeight, totalHeightRemaining);

      // Create a clean canvas slice for this page
      const pageCanvas = document.createElement('canvas');
      pageCanvas.width = canvas.width;
      pageCanvas.height = currentChunkHeight;
      const pageCtx = pageCanvas.getContext('2d');

      if (pageCtx) {
        pageCtx.fillStyle = '#ffffff';
        pageCtx.fillRect(0, 0, pageCanvas.width, pageCanvas.height);
        pageCtx.drawImage(
          canvas,
          0, sourceY, canvas.width, currentChunkHeight,
          0, 0, pageCanvas.width, currentChunkHeight
        );

        const pageImgData = pageCanvas.toDataURL('image/jpeg', 0.95);
        const renderHeight = (currentChunkHeight * printableWidth) / canvas.width;
        pdf.addImage(pageImgData, 'JPEG', margin, margin, printableWidth, renderHeight, undefined, 'FAST');
      }

      sourceY += currentChunkHeight;
      totalHeightRemaining -= currentChunkHeight;
      pageNumber++;
    }

    // 6. Output PDF as Data URI & Base64
    const dataUri: string = pdf.output('datauristring');
    const commaIndex = dataUri.indexOf(',');
    const base64Data = commaIndex !== -1 ? dataUri.substring(commaIndex + 1) : dataUri;

    if (!base64Data || base64Data.length < 500) {
      throw new Error('تعذر إنشاء مستند الـ PDF بشكل سليم');
    }

    if (isNative) {
      // 📱 NATIVE ANDROID FLOW:
      if (onStatusUpdate) onStatusUpdate('جاري حفظ مستند الـ PDF في ذاكرة الهاتف...');

      // A. Write to Cache directory first (FileProvider compatible for Android Share Sheet)
      let shareUri = '';
      try {
        const cacheResult = await Filesystem.writeFile({
          path: safeFilename,
          data: base64Data,
          directory: Directory.Cache,
          recursive: true
        });
        shareUri = cacheResult.uri;
      } catch (cacheErr) {
        console.warn('PDF cache write failed:', cacheErr);
      }

      // B. Write to Documents directory for permanent storage
      let savedFileUri = shareUri;
      let savedPath = `YaserAqelApp_Reports/${safeFilename}`;

      try {
        const docResult = await Filesystem.writeFile({
          path: savedPath,
          data: base64Data,
          directory: Directory.Documents,
          recursive: true
        });
        savedFileUri = docResult.uri;
      } catch (docErr) {
        try {
          const dataResult = await Filesystem.writeFile({
            path: safeFilename,
            data: base64Data,
            directory: Directory.Data,
            recursive: true
          });
          savedFileUri = dataResult.uri;
          savedPath = safeFilename;
        } catch (_) {}
      }

      if (mode === 'share') {
        if (onStatusUpdate) onStatusUpdate('تم إنشاء مستند الـ PDF! جاري فتح نافذة المشاركة بالهاتف...');

        // Share specifically as a PDF DOCUMENT:
        // Pass ONLY files array without text or extra url so WhatsApp sends as a true PDF document attachment!
        try {
          await Share.share({
            title: title,
            files: [shareUri || savedFileUri],
            dialogTitle: 'مشاركة مستند التقرير PDF'
          });
        } catch (shareErr) {
          // If share dialog dismissed, file is still saved successfully
        }

        return {
          success: true,
          message: `تم فتح نافذة المشاركة لمستند الـ PDF بنجاح (${safeFilename})`,
          filePath: savedPath,
          fileUri: savedFileUri || shareUri,
          isNative: true
        };
      } else {
        // mode === 'export_print': DEDICATED FOR EXPORT & PRINT ONLY (NO SHARE POPUP)
        if (onStatusUpdate) onStatusUpdate('تم تصدير وحفظ ملف الـ PDF بنجاح.');

        return {
          success: true,
          message: `تم تصدير وحفظ تقرير الـ PDF بنجاح في مجلد المستندات بالهاتف (Documents/${safeFilename})`,
          filePath: savedPath,
          fileUri: savedFileUri || shareUri,
          isNative: true
        };
      }
    } else {
      // 💻 WEB BROWSER FLOW:
      if (mode === 'share') {
        const pdfBlob = pdf.output('blob');
        const pdfFile = new File([pdfBlob], safeFilename, { type: 'application/pdf' });

        if (typeof navigator !== 'undefined' && navigator.canShare && navigator.canShare({ files: [pdfFile] })) {
          try {
            await navigator.share({
              files: [pdfFile],
              title: title
            });
            return {
              success: true,
              message: `تمت مشاركة مستند الـ PDF بنجاح: ${safeFilename}`,
              filePath: safeFilename,
              isNative: false
            };
          } catch (shareErr: any) {
            if (shareErr?.name === 'AbortError') {
              return { success: true, message: 'تم إغلاق نافذة المشاركة', filePath: safeFilename, isNative: false };
            }
          }
        }

        // Direct file download fallback for browsers without file sharing
        pdf.save(safeFilename);

        return {
          success: true,
          message: `تم تنزيل مستند الـ PDF بنجاح (${safeFilename}) ويمكنك مشاركته الآن.`,
          filePath: safeFilename,
          isNative: false
        };
      } else {
        // Direct browser PDF file download
        pdf.save(safeFilename);

        return {
          success: true,
          message: `تم تنزيل ملف الـ PDF بنجاح: ${safeFilename}`,
          filePath: safeFilename,
          isNative: false
        };
      }
    }
  } catch (err: any) {
    // Ensure clean DOM cleanup on error
    if (tempContainer && tempContainer.parentNode) {
      tempContainer.parentNode.removeChild(tempContainer);
    }
    const orphan = document.getElementById('active-pdf-export-container');
    if (orphan && orphan.parentNode) {
      orphan.parentNode.removeChild(orphan);
    }

    console.error('Error generating PDF report:', err);
    return {
      success: false,
      message: err?.message || 'حدث خطأ أثناء تصدير ملف الـ PDF',
      isNative,
      error: String(err)
    };
  }
}

/**
 * Export report as standalone HTML file (Native phone saving + Web download)
 */
export async function exportReportToHTML(options: PDFExportOptions): Promise<PDFExportResult> {
  const { title, htmlContent, onStatusUpdate } = options;
  const isNative = isNativeAndroidApp();
  const safeFilename = sanitizeReportFilename(title, 'html');

  try {
    const fullHtml = `<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
  <meta charset="utf-8">
  <title>${title}</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800&display=swap" rel="stylesheet">
  <style>
    body { font-family: 'Cairo', sans-serif; padding: 20px; color: #1e293b; direction: rtl; background-color: #fff; line-height: 1.5; }
    table { width: 100%; border-collapse: collapse; margin-bottom: 16px; }
    th, td { border: 1px solid #cbd5e1; padding: 8px 10px; text-align: right; font-size: 11.5px; }
    th { background-color: #f1f5f9; color: #0f172a; font-weight: bold; }
    .no-print { display: none !important; }
    @media print {
      @page { size: A4 portrait; margin: 10mm; }
      body { padding: 0; }
      tr { break-inside: avoid; page-break-inside: avoid; }
    }
  </style>
</head>
<body>
  ${htmlContent}
</body>
</html>`;

  if (isNative) {
    if (onStatusUpdate) onStatusUpdate('جاري حفظ ملف HTML في الهاتف...');
    
    // Encode UTF-8 string to base64 for Capacitor Filesystem
    const utf8Bytes = new TextEncoder().encode(fullHtml);
    let binary = '';
    for (let i = 0; i < utf8Bytes.length; i++) {
      binary += String.fromCharCode(utf8Bytes[i]);
    }
    const base64Data = btoa(binary);

    let shareUri = '';
    try {
      const cacheResult = await Filesystem.writeFile({
        path: safeFilename,
        data: base64Data,
        directory: Directory.Cache,
        recursive: true
      });
      shareUri = cacheResult.uri;
    } catch (cacheErr) {
      console.warn('HTML cache write failed:', cacheErr);
    }

    let savedFileUri = shareUri;
    try {
      const writeResult = await Filesystem.writeFile({
        path: `YaserAqelApp_Reports/${safeFilename}`,
        data: base64Data,
        directory: Directory.Documents,
        recursive: true
      });
      savedFileUri = writeResult.uri;
    } catch {
      try {
        const dataResult = await Filesystem.writeFile({
          path: safeFilename,
          data: base64Data,
          directory: Directory.Data,
          recursive: true
        });
        savedFileUri = dataResult.uri;
      } catch (_) {}
    }

    try {
      await Share.share({
        title: title,
        files: [shareUri || savedFileUri],
        dialogTitle: 'فتح أو مشاركة ملف التقرير'
      });
    } catch (shareErr) {}

    return {
      success: true,
      message: `تم حفظ ومشاركة ملف التقرير بنجاح: ${safeFilename}`,
      filePath: safeFilename,
      fileUri: savedFileUri || shareUri,
      isNative: true
    };
  } else {
    const blob = new Blob([fullHtml], { type: 'text/html;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = safeFilename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    return {
      success: true,
      message: `تم تحميل ملف HTML بنجاح: ${safeFilename}`,
      filePath: safeFilename,
      isNative: false
    };
  }
} catch (err: any) {
  return {
    success: false,
    message: err?.message || 'حدث خطأ أثناء تصدير ملف HTML',
    isNative,
    error: String(err)
  };
}
}
