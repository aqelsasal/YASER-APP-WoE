/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Header & Footer Custom Configuration for Official Reports
 * Supports per-field text, custom icons, typography (font family, size, color, bold, italic, underline, alignment, direction).
 */

import { safeLocalStorageGet, safeLocalStorageSet } from './safeStorage';

export interface FieldTypography {
  fontFamily: string;
  fontSize: number; // in pixels
  color: string;
  bold: boolean;
  italic: boolean;
  underline: boolean;
  align: 'right' | 'center' | 'left';
  dir: 'rtl' | 'ltr';
}

export interface HeaderRightFieldConfig {
  text: string;
  style: FieldTypography;
}

export interface FooterFieldConfig {
  text: string;
  icon: string;
  style: FieldTypography;
}

export interface ReportHeaderFooterConfig {
  headerRight: {
    companyNameAr: HeaderRightFieldConfig;
    companyNameEn: HeaderRightFieldConfig;
    generalDept: HeaderRightFieldConfig;
    subDept: HeaderRightFieldConfig;
    extra: HeaderRightFieldConfig;
  };
  footer: {
    address: FooterFieldConfig;
    email: FooterFieldConfig;
    website: FooterFieldConfig;
    mobiles: FooterFieldConfig;
    phones: FooterFieldConfig;
  };
}

export const AVAILABLE_FONT_FAMILIES = [
  { id: "'Cairo', 'Segoe UI', Tahoma, sans-serif", name: 'Cairo (كايرو - الرسمي)' },
  { id: "'Segoe UI', Arial, sans-serif", name: 'Segoe UI (سيجو يو آي)' },
  { id: "'Tahoma', 'Segoe UI', sans-serif", name: 'Tahoma (تهوما)' },
  { id: "'Amiri', serif", name: 'Amiri (الخط الأميري)' },
  { id: "'Tajawal', sans-serif", name: 'Tajawal (خط تجوال)' },
  { id: "'Almarai', sans-serif", name: 'Almarai (خط المراعي)' },
  { id: "'Arial', sans-serif", name: 'Arial (أريال القياسي)' },
  { id: "'Courier New', monospace", name: 'Courier New (الآلة الكاتبة)' },
];

export const AVAILABLE_FOOTER_ICONS: { id: string; name: string; category: string }[] = [
  { id: 'map-pin', name: 'دبوس الموقع', category: 'العنوان' },
  { id: 'building', name: 'مبنى / فرع', category: 'العنوان' },
  { id: 'navigation', name: 'ملاحة وتوجيه', category: 'العنوان' },
  { id: 'home', name: 'المقر / منزل', category: 'العنوان' },

  { id: 'mail', name: 'بريد إلكتروني', category: 'التواصل الإلكتروني' },
  { id: 'at-sign', name: 'رمز @', category: 'التواصل الإلكتروني' },
  { id: 'send', name: 'إرسال / مراسلة', category: 'التواصل الإلكتروني' },

  { id: 'globe', name: 'موقع ويب / كرة أرضية', category: 'الإنترنت' },
  { id: 'link', name: 'رابط مباشر', category: 'الإنترنت' },
  { id: 'external-link', name: 'نافذة خارجية', category: 'الإنترنت' },

  { id: 'smartphone', name: 'جوال / موبايل', category: 'الاتصال' },
  { id: 'phone', name: 'هاتف ثابت', category: 'الاتصال' },
  { id: 'phone-call', name: 'اتصال هاتفي', category: 'الاتصال' },
  { id: 'message-square', name: 'رسائل / واتساب', category: 'الاتصال' },

  { id: 'hash', name: 'رمز الرقم #', category: 'أخرى' },
  { id: 'file-text', name: 'سجل رسمي', category: 'أخرى' },
];

export const DEFAULT_HEADER_FOOTER_CONFIG: ReportHeaderFooterConfig = {
  headerRight: {
    companyNameAr: {
      text: 'ورلد أوف إيليتس للتجارة والمقاولات',
      style: {
        fontFamily: "'Cairo', 'Segoe UI', Tahoma, sans-serif",
        fontSize: 15,
        color: '#002B49',
        bold: true,
        italic: false,
        underline: false,
        align: 'right',
        dir: 'rtl',
      },
    },
    companyNameEn: {
      text: 'World of Elites for Trading & Contracting',
      style: {
        fontFamily: "'Segoe UI', Arial, sans-serif",
        fontSize: 13.5,
        color: '#E85D25',
        bold: true,
        italic: false,
        underline: false,
        align: 'right',
        dir: 'ltr',
      },
    },
    generalDept: {
      text: 'الإدارة المالية والتنفيذية للمشاريع',
      style: {
        fontFamily: "'Cairo', 'Segoe UI', Tahoma, sans-serif",
        fontSize: 12,
        color: '#1e293b',
        bold: true,
        italic: false,
        underline: false,
        align: 'right',
        dir: 'rtl',
      },
    },
    subDept: {
      text: 'قسم الحسابات والرقابة المالية',
      style: {
        fontFamily: "'Cairo', 'Segoe UI', Tahoma, sans-serif",
        fontSize: 11.5,
        color: '#334155',
        bold: true,
        italic: false,
        underline: false,
        align: 'right',
        dir: 'rtl',
      },
    },
    extra: {
      text: '',
      style: {
        fontFamily: "'Cairo', 'Segoe UI', Tahoma, sans-serif",
        fontSize: 11,
        color: '#64748b',
        bold: false,
        italic: false,
        underline: false,
        align: 'right',
        dir: 'rtl',
      },
    },
  },
  footer: {
    address: {
      text: 'صنعاء - بيت بوس - شارع الخمسين',
      icon: 'map-pin',
      style: {
        fontFamily: "'Cairo', 'Segoe UI', Tahoma, sans-serif",
        fontSize: 11.5,
        color: '#002B49',
        bold: true,
        italic: false,
        underline: false,
        align: 'right',
        dir: 'rtl',
      },
    },
    email: {
      text: 'Info@WorldofElites.com',
      icon: 'mail',
      style: {
        fontFamily: "'Segoe UI', Tahoma, sans-serif",
        fontSize: 11.5,
        color: '#002B49',
        bold: true,
        italic: false,
        underline: false,
        align: 'left',
        dir: 'ltr',
      },
    },
    website: {
      text: 'www.WorldofElites.com',
      icon: 'globe',
      style: {
        fontFamily: "'Segoe UI', Tahoma, sans-serif",
        fontSize: 11.5,
        color: '#002B49',
        bold: true,
        italic: false,
        underline: false,
        align: 'left',
        dir: 'ltr',
      },
    },
    mobiles: {
      text: '+967 782 222 877 | +967 779 992 996',
      icon: 'smartphone',
      style: {
        fontFamily: "'Segoe UI', Tahoma, monospace, sans-serif",
        fontSize: 12,
        color: '#002B49',
        bold: true,
        italic: false,
        underline: false,
        align: 'left',
        dir: 'ltr',
      },
    },
    phones: {
      text: '+967 101915558 | +967 1-699888',
      icon: 'phone',
      style: {
        fontFamily: "'Segoe UI', Tahoma, monospace, sans-serif",
        fontSize: 12,
        color: '#002B49',
        bold: true,
        italic: false,
        underline: false,
        align: 'left',
        dir: 'ltr',
      },
    },
  },
};

const STORAGE_KEY = 'site_report_header_footer_config_v1';

export function getHeaderFooterConfig(): ReportHeaderFooterConfig {
  try {
    const raw = safeLocalStorageGet(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      // Deep merge with defaults to safeguard against missing keys
      return {
        headerRight: {
          companyNameAr: {
            text: parsed.headerRight?.companyNameAr?.text ?? DEFAULT_HEADER_FOOTER_CONFIG.headerRight.companyNameAr.text,
            style: { ...DEFAULT_HEADER_FOOTER_CONFIG.headerRight.companyNameAr.style, ...parsed.headerRight?.companyNameAr?.style },
          },
          companyNameEn: {
            text: parsed.headerRight?.companyNameEn?.text ?? DEFAULT_HEADER_FOOTER_CONFIG.headerRight.companyNameEn.text,
            style: { ...DEFAULT_HEADER_FOOTER_CONFIG.headerRight.companyNameEn.style, ...parsed.headerRight?.companyNameEn?.style },
          },
          generalDept: {
            text: parsed.headerRight?.generalDept?.text ?? DEFAULT_HEADER_FOOTER_CONFIG.headerRight.generalDept.text,
            style: { ...DEFAULT_HEADER_FOOTER_CONFIG.headerRight.generalDept.style, ...parsed.headerRight?.generalDept?.style },
          },
          subDept: {
            text: parsed.headerRight?.subDept?.text ?? DEFAULT_HEADER_FOOTER_CONFIG.headerRight.subDept.text,
            style: { ...DEFAULT_HEADER_FOOTER_CONFIG.headerRight.subDept.style, ...parsed.headerRight?.subDept?.style },
          },
          extra: {
            text: parsed.headerRight?.extra?.text ?? DEFAULT_HEADER_FOOTER_CONFIG.headerRight.extra.text,
            style: { ...DEFAULT_HEADER_FOOTER_CONFIG.headerRight.extra.style, ...parsed.headerRight?.extra?.style },
          },
        },
        footer: {
          address: {
            text: parsed.footer?.address?.text ?? DEFAULT_HEADER_FOOTER_CONFIG.footer.address.text,
            icon: parsed.footer?.address?.icon ?? DEFAULT_HEADER_FOOTER_CONFIG.footer.address.icon,
            style: { ...DEFAULT_HEADER_FOOTER_CONFIG.footer.address.style, ...parsed.footer?.address?.style },
          },
          email: {
            text: parsed.footer?.email?.text ?? DEFAULT_HEADER_FOOTER_CONFIG.footer.email.text,
            icon: parsed.footer?.email?.icon ?? DEFAULT_HEADER_FOOTER_CONFIG.footer.email.icon,
            style: { ...DEFAULT_HEADER_FOOTER_CONFIG.footer.email.style, ...parsed.footer?.email?.style },
          },
          website: {
            text: parsed.footer?.website?.text ?? DEFAULT_HEADER_FOOTER_CONFIG.footer.website.text,
            icon: parsed.footer?.website?.icon ?? DEFAULT_HEADER_FOOTER_CONFIG.footer.website.icon,
            style: { ...DEFAULT_HEADER_FOOTER_CONFIG.footer.website.style, ...parsed.footer?.website?.style },
          },
          mobiles: {
            text: parsed.footer?.mobiles?.text ?? DEFAULT_HEADER_FOOTER_CONFIG.footer.mobiles.text,
            icon: parsed.footer?.mobiles?.icon ?? DEFAULT_HEADER_FOOTER_CONFIG.footer.mobiles.icon,
            style: { ...DEFAULT_HEADER_FOOTER_CONFIG.footer.mobiles.style, ...parsed.footer?.mobiles?.style },
          },
          phones: {
            text: parsed.footer?.phones?.text ?? DEFAULT_HEADER_FOOTER_CONFIG.footer.phones.text,
            icon: parsed.footer?.phones?.icon ?? DEFAULT_HEADER_FOOTER_CONFIG.footer.phones.icon,
            style: { ...DEFAULT_HEADER_FOOTER_CONFIG.footer.phones.style, ...parsed.footer?.phones?.style },
          },
        },
      };
    }
  } catch (e) {
    console.warn('[reportHeaderFooterConfig] Error parsing saved config:', e);
  }

  // Fallback to defaults, respecting legacy localStorage company name/address/phone if set
  const cfg = JSON.parse(JSON.stringify(DEFAULT_HEADER_FOOTER_CONFIG)) as ReportHeaderFooterConfig;
  const legacyCompName = safeLocalStorageGet('site_company_name');
  if (legacyCompName && legacyCompName.trim()) {
    cfg.headerRight.companyNameAr.text = legacyCompName.trim();
  }
  const legacyCompAddress = safeLocalStorageGet('site_company_address');
  if (legacyCompAddress && legacyCompAddress.trim()) {
    cfg.footer.address.text = legacyCompAddress.trim();
  }
  const legacyCompPhone = safeLocalStorageGet('site_company_phone');
  if (legacyCompPhone && legacyCompPhone.trim()) {
    cfg.footer.mobiles.text = legacyCompPhone.trim();
  }
  return cfg;
}

export function saveHeaderFooterConfig(config: ReportHeaderFooterConfig): void {
  try {
    safeLocalStorageSet(STORAGE_KEY, JSON.stringify(config));
    // Keep legacy keys in sync for backward compatibility
    if (config.headerRight?.companyNameAr?.text) {
      safeLocalStorageSet('site_company_name', config.headerRight.companyNameAr.text);
    }
    if (config.footer?.address?.text) {
      safeLocalStorageSet('site_company_address', config.footer.address.text);
    }
    if (config.footer?.mobiles?.text) {
      safeLocalStorageSet('site_company_phone', config.footer.mobiles.text);
    }
  } catch (e) {
    console.warn('[reportHeaderFooterConfig] Error saving config:', e);
  }
}

export function resetHeaderFooterConfig(): ReportHeaderFooterConfig {
  const defaults = JSON.parse(JSON.stringify(DEFAULT_HEADER_FOOTER_CONFIG)) as ReportHeaderFooterConfig;
  saveHeaderFooterConfig(defaults);
  return defaults;
}

export function typographyToCssString(t: FieldTypography): string {
  return [
    `font-family: ${t.fontFamily};`,
    `font-size: ${t.fontSize}px;`,
    `color: ${t.color};`,
    `font-weight: ${t.bold ? '800' : '400'};`,
    `font-style: ${t.italic ? 'italic' : 'normal'};`,
    `text-decoration: ${t.underline ? 'underline' : 'none'};`,
    `text-align: ${t.align};`,
    `direction: ${t.dir};`,
    `line-height: 1.35;`,
  ].join(' ');
}

export function typographyToReactStyle(t: FieldTypography): React.CSSProperties {
  return {
    fontFamily: t.fontFamily,
    fontSize: `${t.fontSize}px`,
    color: t.color,
    fontWeight: t.bold ? 800 : 400,
    fontStyle: t.italic ? 'italic' : 'normal',
    textDecoration: t.underline ? 'underline' : 'none',
    textAlign: t.align,
    direction: t.dir,
    lineHeight: 1.35,
  };
}

/**
 * Returns white inline SVG paths for circular orange footer icons (24x24 viewBox)
 */
export function getFooterIconSvg(iconId: string): string {
  const common = `viewBox="0 0 24 24" fill="none" stroke="#ffffff" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round" style="width: 12px; height: 12px; display: block;"`;

  switch (iconId) {
    case 'building':
      return `<svg ${common}><rect x="4" y="2" width="16" height="20" rx="2" ry="2"></rect><path d="M9 22v-4h6v4"></path><path d="M8 6h.01"></path><path d="M16 6h.01"></path><path d="M12 6h.01"></path><path d="M12 10h.01"></path><path d="M12 14h.01"></path><path d="M16 10h.01"></path><path d="M16 14h.01"></path><path d="M8 10h.01"></path><path d="M8 14h.01"></path></svg>`;
    case 'navigation':
      return `<svg ${common}><polygon points="3 11 22 2 13 21 11 13 3 11"></polygon></svg>`;
    case 'home':
      return `<svg ${common}><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg>`;
    case 'mail':
      return `<svg ${common}><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path><polyline points="22,6 12,13 2,6"></polyline></svg>`;
    case 'at-sign':
      return `<svg ${common}><circle cx="12" cy="12" r="4"></circle><path d="M16 8v5a3 3 0 0 0 6 0v-1a10 10 0 1 0-3.92 7.94"></path></svg>`;
    case 'send':
      return `<svg ${common}><line x1="22" y1="2" x2="11" y2="13"></line><polygon points="22 2 15 22 11 13 2 9 22 2"></polygon></svg>`;
    case 'globe':
      return `<svg ${common}><circle cx="12" cy="12" r="10"></circle><line x1="2" y1="12" x2="22" y2="12"></line><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path></svg>`;
    case 'link':
      return `<svg ${common}><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"></path><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"></path></svg>`;
    case 'external-link':
      return `<svg ${common}><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path><polyline points="15 3 21 3 21 9"></polyline><line x1="10" y1="14" x2="21" y2="3"></line></svg>`;
    case 'smartphone':
      return `<svg ${common}><rect x="5" y="2" width="14" height="20" rx="2" ry="2"></rect><line x1="12" y1="18" x2="12.01" y2="18"></line></svg>`;
    case 'phone':
      return `<svg ${common}><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg>`;
    case 'phone-call':
      return `<svg ${common}><path d="M15.05 5A5 5 0 0 1 19 8.95M15.05 1A9 9 0 0 1 23 8.94m-1 7.98v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg>`;
    case 'message-square':
      return `<svg ${common}><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>`;
    case 'hash':
      return `<svg ${common}><line x1="4" y1="9" x2="20" y2="9"></line><line x1="4" y1="15" x2="20" y2="15"></line><line x1="10" y1="3" x2="8" y2="21"></line><line x1="16" y1="3" x2="14" y2="21"></line></svg>`;
    case 'file-text':
      return `<svg ${common}><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>`;
    case 'map-pin':
    default:
      return `<svg ${common}><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>`;
  }
}

/**
 * Renders the stacked right-side header texts as HTML with exact custom styles.
 */
export function renderHeaderRightHtml(customConfig?: ReportHeaderFooterConfig): string {
  const cfg = customConfig || getHeaderFooterConfig();
  const hr = cfg.headerRight;

  const items = [
    { text: hr.companyNameAr.text, style: hr.companyNameAr.style },
    { text: hr.companyNameEn.text, style: hr.companyNameEn.style },
    { text: hr.generalDept.text, style: hr.generalDept.style },
    { text: hr.subDept.text, style: hr.subDept.style },
    { text: hr.extra.text, style: hr.extra.style },
  ];

  return items
    .filter(item => item.text && item.text.trim())
    .map(item => `<div style="${typographyToCssString(item.style)} margin-bottom: 2px;">${item.text}</div>`)
    .join('\n');
}

/**
 * Renders the complete official footer block as HTML with custom texts, icons, and styles.
 */
export function renderFooterHtml(customConfig?: ReportHeaderFooterConfig): string {
  const cfg = customConfig || getHeaderFooterConfig();
  const f = cfg.footer;

  const iconBadge = (iconId: string) => `
    <span style="display: inline-flex; align-items: center; justify-content: center; width: 22px; height: 22px; min-width: 22px; min-height: 22px; background-color: #E85D25; border-radius: 50%; vertical-align: middle;">
      ${getFooterIconSvg(iconId)}
    </span>
  `;

  return `
    <div style="display: flex; justify-content: space-between; align-items: center; gap: 16px;">
      <!-- Right Side: Address (Line 1) & Email + Website (Line 2) -->
      <div style="text-align: right; flex: 1.35; min-width: 0; display: flex; flex-direction: column; justify-content: center; gap: 7px;">
        <!-- Line 1: Address -->
        <div style="display: flex; align-items: center; gap: 8px; white-space: nowrap;">
          ${iconBadge(f.address.icon)}
          <span style="${typographyToCssString(f.address.style)}">${f.address.text}</span>
        </div>

        <!-- Line 2: Email & Website -->
        <div style="display: flex; align-items: center; gap: 7px; white-space: nowrap;">
          ${iconBadge(f.email.icon)}
          <a href="mailto:${f.email.text}" style="${typographyToCssString(f.email.style)} text-decoration: none;">${f.email.text}</a>

          ${iconBadge(f.website.icon)}
          <a href="https://${f.website.text.replace(/^https?:\/\//i, '')}" target="_blank" style="${typographyToCssString(f.website.style)} text-decoration: none;">${f.website.text}</a>
        </div>
      </div>

      <!-- Vertical Divider -->
      <div style="width: 1.5px; min-height: 46px; background-color: #cbd5e1; align-self: stretch;"></div>

      <!-- Left Side: Mobiles (Line 1) & Phones (Line 2) -->
      <div style="text-align: left; direction: ltr; flex: 1; min-width: 0; display: flex; flex-direction: column; justify-content: center; gap: 7px;">
        <!-- Line 1: Mobiles -->
        <div style="display: flex; align-items: center; gap: 8px; white-space: nowrap;">
          ${iconBadge(f.mobiles.icon)}
          <span style="${typographyToCssString(f.mobiles.style)} display: inline-block; letter-spacing: 0.2px;">${f.mobiles.text}</span>
        </div>

        <!-- Line 2: Other Phones -->
        <div style="display: flex; align-items: center; gap: 8px; white-space: nowrap;">
          ${iconBadge(f.phones.icon)}
          <span style="${typographyToCssString(f.phones.style)} display: inline-block; letter-spacing: 0.2px;">${f.phones.text}</span>
        </div>
      </div>
    </div>
  `;
}

// -------------------------------------------------------------
// Official Signature Slots (خانات التوقيع الرسمية المخولة)
// -------------------------------------------------------------
export interface SignatureSlot {
  id?: string;
  role: string;
  name: string;
  enabled?: boolean;
}

export const DEFAULT_SIGNATURE_SLOTS: SignatureSlot[] = [
  { id: 'sig-1', role: 'توقيع المستلم', name: '', enabled: true },
  { id: 'sig-2', role: 'توقيع المحاسب المسئول', name: '', enabled: true },
  { id: 'sig-3', role: 'توقيع مدير المشروع', name: '', enabled: true },
  { id: 'sig-4', role: 'توقيع واعتماد المدير العام', name: '', enabled: true },
];

export const SIGNATURE_STORAGE_KEY = 'site_signature_slots';

export function getSignatureSlots(): SignatureSlot[] {
  try {
    const raw = typeof localStorage !== 'undefined' ? localStorage.getItem(SIGNATURE_STORAGE_KEY) : null;
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed.map((item, idx) => ({
          id: item.id || `sig-${idx + 1}-${Date.now()}`,
          role: typeof item.role === 'string' ? item.role : (DEFAULT_SIGNATURE_SLOTS[idx]?.role || `توقيع معتمد (${idx + 1})`),
          name: typeof item.name === 'string' ? item.name : '',
          enabled: item.enabled !== false,
        }));
      }
    }
  } catch (e) {
    console.warn('Failed to parse signature slots from storage:', e);
  }
  return DEFAULT_SIGNATURE_SLOTS;
}

export function saveSignatureSlots(slots: SignatureSlot[]): void {
  try {
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem(SIGNATURE_STORAGE_KEY, JSON.stringify(slots));
    }
  } catch (e) {
    console.warn('Failed to save signature slots to storage:', e);
  }
}

/**
 * Renders the active/enabled official signature slots as an HTML block for PDF and print previews.
 */
export function renderSignatureBlocksHtml(customSlots?: SignatureSlot[]): string {
  const slots = customSlots || getSignatureSlots();
  const activeSlots = slots.filter(s => s.enabled !== false && (s.role?.trim() || s.name?.trim()));
  
  if (activeSlots.length === 0) {
    return '';
  }

  const count = activeSlots.length;
  const itemFlexBasis = count === 1 ? '240px' : count === 2 ? '190px' : count === 3 ? '160px' : '140px';
  const itemMaxWidth = count === 1 ? '280px' : '240px';

  return `
    <div class="official-signature-blocks" style="margin-top: 25px; display: flex; flex-wrap: wrap; justify-content: center; align-items: stretch; gap: 12px; text-align: center; border-top: 1.5px dashed #cbd5e1; padding-top: 18px; page-break-inside: avoid; direction: rtl; font-family: 'Cairo', 'Segoe UI', Tahoma, sans-serif;">
      ${activeSlots.map((slot, idx) => `
        <div style="flex: 1 1 ${itemFlexBasis}; max-width: ${itemMaxWidth}; min-width: 130px; background-color: #fafbfc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 10px 8px; box-shadow: 0 1px 2px rgba(0,0,0,0.02); box-sizing: border-box;">
          <p style="margin: 0 0 4px 0; color: #002B49; font-weight: 800; font-size: 11.5px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
            ${slot.role || `توقيع معتمد (${idx + 1})`}
          </p>
          ${slot.name ? `
            <p style="margin: 0 0 14px 0; color: #334155; font-size: 11px; font-weight: bold; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
              ${slot.name}
            </p>
          ` : `
            <div style="height: 18px; margin-bottom: 2px;"></div>
          `}
          <div style="color: #94a3b8; font-family: monospace; letter-spacing: 2px; font-size: 11px; margin: 6px 0 2px 0;">.....................</div>
        </div>
      `).join('')}
    </div>
  `;
}
