/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export const FONT_SCALE_STORAGE_KEY = 'app_font_scale_step';
export const FONT_HEADINGS_STORAGE_KEY = 'app_font_headings_step';
export const FONT_SUBTEXT_STORAGE_KEY = 'app_font_subtext_step';
export const FONT_TABLES_STORAGE_KEY = 'app_font_tables_step';

export interface FontStepConfig {
  step: number;
  label: string;
  subLabel: string;
  pxSize?: number;
  description: string;
}

// 8 points for Global Font Size: 2 enlargement (+1, +2), 1 default (0), 5 reduction (-1, -2, -3, -4, -5)
export const GLOBAL_FONT_STEPS: FontStepConfig[] = [
  {
    step: 2,
    label: '+2',
    subLabel: 'أكبر',
    pxSize: 18,
    description: 'تكبير بمقدار 2 (18px - خط عريض وواضح جداً)'
  },
  {
    step: 1,
    label: '+1',
    subLabel: 'كبير',
    pxSize: 17,
    description: 'تكبير بمقدار 1 (17px - سهولة قراءة معززة)'
  },
  {
    step: 0,
    label: '0',
    subLabel: 'الافتراضي',
    pxSize: 16,
    description: 'الحجم القياسي المعتمد (16px)'
  },
  {
    step: -1,
    label: '-1',
    subLabel: 'صغير',
    pxSize: 15,
    description: 'تصغير بمقدار 1 (15px - خط مدمج مريح)'
  },
  {
    step: -2,
    label: '-2',
    subLabel: 'أصغر',
    pxSize: 14,
    description: 'تصغير بمقدار 2 (14px - عرض جداول مضغوطة)'
  },
  {
    step: -3,
    label: '-3',
    subLabel: 'مضغوط',
    pxSize: 13,
    description: 'تصغير بمقدار 3 (13px - استيعاب أعلى للشاشات)'
  },
  {
    step: -4,
    label: '-4',
    subLabel: 'دقيق',
    pxSize: 12,
    description: 'تصغير بمقدار 4 (12px - كثافة بيانات عالية)'
  },
  {
    step: -5,
    label: '-5',
    subLabel: 'الأصغر',
    pxSize: 11,
    description: 'تصغير بمقدار 5 (11px - أقصى تصغير ممكن)'
  }
];

// 5 points for Specific Categories: 2 enlargement (+1, +2), 1 default (0), 2 reduction (-1, -2)
export const CATEGORY_FONT_STEPS: FontStepConfig[] = [
  {
    step: 2,
    label: '+2',
    subLabel: 'أكبر',
    description: 'تكبير بمقدار 2 درجة'
  },
  {
    step: 1,
    label: '+1',
    subLabel: 'كبير',
    description: 'تكبير بمقدار 1 درجة'
  },
  {
    step: 0,
    label: '0',
    subLabel: 'الافتراضي',
    description: 'الحجم القياسي المتوازن'
  },
  {
    step: -1,
    label: '-1',
    subLabel: 'صغير',
    description: 'تصغير بمقدار 1 درجة'
  },
  {
    step: -2,
    label: '-2',
    subLabel: 'أصغر',
    description: 'تصغير بمقدار 2 درجة'
  }
];

// Backwards compatibility alias
export const FONT_STEPS = GLOBAL_FONT_STEPS;

export function getSavedFontStep(): number {
  if (typeof window === 'undefined') return 0;
  try {
    const val = localStorage.getItem(FONT_SCALE_STORAGE_KEY);
    if (val !== null) {
      const parsed = parseInt(val, 10);
      if (!isNaN(parsed) && parsed >= -5 && parsed <= 2) {
        return parsed;
      }
    }
  } catch {
    // ignore
  }
  return 0;
}

export function getSavedHeadingsStep(): number {
  if (typeof window === 'undefined') return 0;
  try {
    const val = localStorage.getItem(FONT_HEADINGS_STORAGE_KEY);
    if (val !== null) {
      const parsed = parseInt(val, 10);
      if (!isNaN(parsed) && parsed >= -2 && parsed <= 2) {
        return parsed;
      }
    }
  } catch {
    // ignore
  }
  return 0;
}

export function getSavedSubtextStep(): number {
  if (typeof window === 'undefined') return 0;
  try {
    const val = localStorage.getItem(FONT_SUBTEXT_STORAGE_KEY);
    if (val !== null) {
      const parsed = parseInt(val, 10);
      if (!isNaN(parsed) && parsed >= -2 && parsed <= 2) {
        return parsed;
      }
    }
  } catch {
    // ignore
  }
  return 0;
}

export function getSavedTablesStep(): number {
  if (typeof window === 'undefined') return 0;
  try {
    const val = localStorage.getItem(FONT_TABLES_STORAGE_KEY);
    if (val !== null) {
      const parsed = parseInt(val, 10);
      if (!isNaN(parsed) && parsed >= -2 && parsed <= 2) {
        return parsed;
      }
    }
  } catch {
    // ignore
  }
  return 0;
}

export function applyFontStep(step: number): void {
  if (typeof document === 'undefined') return;
  const clamped = Math.max(-5, Math.min(2, step));
  document.documentElement.setAttribute('data-font-step', String(clamped));
  document.documentElement.style.fontSize = `${16 + clamped}px`;
  if (document.body) {
    document.body.style.fontSize = `${16 + clamped}px`;
  }
  try {
    localStorage.setItem(FONT_SCALE_STORAGE_KEY, String(clamped));
  } catch {
    // ignore
  }
}

export function applyHeadingsStep(step: number): void {
  if (typeof document === 'undefined') return;
  const clamped = Math.max(-2, Math.min(2, step));
  document.documentElement.setAttribute('data-font-headings-step', String(clamped));
  try {
    localStorage.setItem(FONT_HEADINGS_STORAGE_KEY, String(clamped));
  } catch {
    // ignore
  }
}

export function applySubtextStep(step: number): void {
  if (typeof document === 'undefined') return;
  const clamped = Math.max(-2, Math.min(2, step));
  document.documentElement.setAttribute('data-font-subtext-step', String(clamped));
  try {
    localStorage.setItem(FONT_SUBTEXT_STORAGE_KEY, String(clamped));
  } catch {
    // ignore
  }
}

export function applyTablesStep(step: number): void {
  if (typeof document === 'undefined') return;
  const clamped = Math.max(-2, Math.min(2, step));
  document.documentElement.setAttribute('data-font-tables-step', String(clamped));
  try {
    localStorage.setItem(FONT_TABLES_STORAGE_KEY, String(clamped));
  } catch {
    // ignore
  }
}

export function applyAllSavedFontSettings(): void {
  applyFontStep(getSavedFontStep());
  applyHeadingsStep(getSavedHeadingsStep());
  applySubtextStep(getSavedSubtextStep());
  applyTablesStep(getSavedTablesStep());
}
