/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Capacitor } from '@capacitor/core';
import { 
  getBiometricStatus, 
  performBiometricAuthentication, 
  openPhoneBiometricSettings,
  type BiometricStatus 
} from '../services/nativeBiometricService';

export { openPhoneBiometricSettings, getBiometricStatus, type BiometricStatus };

export interface SecuritySettings {
  enabled: boolean;
  username: string;
  passwordHash: string;
  passwordSalt: string;
  biometricsEnabled: boolean;
  biometricCredentialId?: string;
  autoLockIntervalMinutes: number; // 0 = immediately, 1 = 1 min, 5 = 5 min, -1 = on reload only
  securityQuestion?: string;
  securityAnswerHash?: string;
  securityAnswerSalt?: string;
}

const STORAGE_KEY = 'app_security_config_v1';
const UNLOCKED_KEY = 'app_is_currently_unlocked';
const LAST_ACTIVE_KEY = 'app_last_active_timestamp';

// Helper: Convert ArrayBuffer to hex string
function bufferToHex(buffer: ArrayBuffer): string {
  const byteArray = new Uint8Array(buffer);
  let hexString = '';
  for (let i = 0; i < byteArray.byteLength; i++) {
    const hex = byteArray[i].toString(16).padStart(2, '0');
    hexString += hex;
  }
  return hexString;
}

// Generate random salt
export function generateSalt(length = 16): string {
  const array = new Uint8Array(length);
  if (typeof window !== 'undefined' && window.crypto && window.crypto.getRandomValues) {
    window.crypto.getRandomValues(array);
  } else {
    for (let i = 0; i < length; i++) {
      array[i] = Math.floor(Math.random() * 256);
    }
  }
  return bufferToHex(array.buffer);
}

// Cryptographic hash for passwords (SHA-256 + Salt)
export async function hashString(value: string, salt: string): Promise<string> {
  const text = `${salt}:${value}:${salt}`;
  if (typeof window !== 'undefined' && window.crypto && window.crypto.subtle) {
    try {
      const encoder = new TextEncoder();
      const data = encoder.encode(text);
      const hashBuffer = await window.crypto.subtle.digest('SHA-256', data);
      return bufferToHex(hashBuffer);
    } catch {
      // Fallback below
    }
  }
  // Simple fallback hash if crypto.subtle is restricted
  let hash = 0;
  for (let i = 0; i < text.length; i++) {
    const char = text.charCodeAt(i);
    hash = (hash << 5) - hash + char;
    hash |= 0;
  }
  return Math.abs(hash).toString(16).padStart(16, '0');
}

// Get saved security configuration
export function getSecuritySettings(): SecuritySettings | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    return JSON.parse(raw);
  } catch (e) {
    console.error('Failed to parse security settings', e);
    return null;
  }
}

// Save security configuration
export function saveSecuritySettings(settings: SecuritySettings): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(settings));
  } catch (e) {
    console.error('Failed to save security settings', e);
  }
}

// Helper: Get safe RP ID for WebAuthn (omits IP addresses and invalid hosts)
function getValidRpId(): string | undefined {
  if (typeof window === 'undefined') return undefined;
  const hostname = window.location.hostname;
  if (!hostname || hostname === 'localhost' || /^[0-9.]+$/.test(hostname)) {
    return undefined;
  }
  return hostname;
}

// Check if biometrics (Native Android BiometricPrompt or WebAuthn) is supported on this device/browser
export async function isBiometricsSupported(): Promise<boolean> {
  if (Capacitor.isNativePlatform()) {
    try {
      const status = await getBiometricStatus();
      return status.hasHardware || status.isSupported;
    } catch {
      return false;
    }
  }

  if (typeof window === 'undefined') return false;
  if (!window.PublicKeyCredential) return false;
  try {
    if (typeof PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable === 'function') {
      const available = await PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable();
      return available;
    }
    return true;
  } catch (err) {
    console.warn('Biometrics check error:', err);
    return false;
  }
}

// Register Biometric Credential for current device (Native Android BiometricPrompt or WebAuthn)
export async function registerBiometricsCredential(username: string): Promise<{ success: boolean; credentialId?: string; error?: string; needEnrollment?: boolean }> {
  if (Capacitor.isNativePlatform()) {
    try {
      const status = await getBiometricStatus();
      if (!status.isSupported) {
        if (status.code === 'NONE_ENROLLED') {
          return {
            success: false,
            needEnrollment: true,
            error: 'الهاتف يدعم البصمة ولكن لم يتم تسجيل أي بصمة في إعدادات الهاتف بعد. يرجى تسجيل بصمتك في إعدادات الهاتف أولاً.'
          };
        }
        return {
          success: false,
          error: status.message || 'مستشعر البصمة غير متاح على هذا الهاتف.'
        };
      }

      const res = await performBiometricAuthentication({
        title: 'تفعيل مستشعر البصمة',
        subtitle: 'المس مستشعر البصمة لتأكيد هويتك وتفعيل القفل بالبصمة',
        description: 'سيتم ربط قفل التطبيق بمستشعر بصمة الهاتف بأمان تام'
      });

      if (res.success) {
        const nativeId = 'native_android_bio_' + Date.now().toString(16);
        return { success: true, credentialId: nativeId };
      }
      return { success: false, error: res.error || 'تعذر تفعيل البصمة على الهاتف.' };
    } catch (err: any) {
      return { success: false, error: err.message || 'حدث خطأ أثناء تفعيل البصمة على الهاتف.' };
    }
  }

  // Web Browser Platform (WebAuthn)
  try {
    if (!window.PublicKeyCredential) {
      return { success: false, error: 'المتصفح أو الهاتف لا يدعم مستشعر البصمة البيومترية.' };
    }

    const challenge = new Uint8Array(32);
    window.crypto.getRandomValues(challenge);

    const userId = new Uint8Array(16);
    window.crypto.getRandomValues(userId);

    const validRpId = getValidRpId();

    const createOptions: PublicKeyCredentialCreationOptions = {
      challenge,
      rp: {
        name: 'إدارة مشاريع ورلد أوف إيليتس',
        ...(validRpId ? { id: validRpId } : {})
      },
      user: {
        id: userId,
        name: username || 'admin',
        displayName: username || 'مدير النظام'
      },
      pubKeyCredParams: [
        { alg: -7, type: 'public-key' },  // ES256 (Primary Android & iOS biometric key)
        { alg: -257, type: 'public-key' } // RS256 (Fallback)
      ],
      authenticatorSelection: {
        authenticatorAttachment: 'platform', // Enforce on-device hardware sensor (e.g. S22 Ultra ultrasonic scanner)
        userVerification: 'required',
        residentKey: 'preferred',
        requireResidentKey: false
      },
      timeout: 60000,
      attestation: 'none'
    };

    const credential = (await navigator.credentials.create({
      publicKey: createOptions
    })) as PublicKeyCredential;

    if (!credential) {
      return { success: false, error: 'تم إلغاء عملية تفعيل البصمة على الهاتف.' };
    }

    const rawIdBuffer = credential.rawId;
    const credentialId = bufferToHex(rawIdBuffer);

    return { success: true, credentialId };
  } catch (err: any) {
    console.error('Register biometrics failed:', err);
    let msg = 'تعذر تفعيل مستشعر البصمة على هذا الجهاز.';
    if (err.name === 'NotAllowedError') {
      msg = 'تم إلغاء طلب البصمة من قبل المستخدم أو لم يكتمل التحقق.';
    } else if (err.name === 'InvalidStateError') {
      msg = 'البصمة مسجلة مسبقاً، يمكنك تسجيل الدخول بها الآن.';
    } else if (err.name === 'SecurityError') {
      msg = 'قيود أمان المتصفح تتطلب تشغيل التطبيق عبر اتصال آمن (HTTPS).';
    }
    return { success: false, error: msg };
  }
}

// Verify Biometric Authentication (Unlock with Samsung Fingerprint / Android BiometricPrompt or WebAuthn)
export async function verifyBiometricsUnlock(credentialId?: string): Promise<{ success: boolean; error?: string; needEnrollment?: boolean }> {
  if (Capacitor.isNativePlatform()) {
    try {
      const res = await performBiometricAuthentication({
        title: 'نظام الأمان والتحقق من الهوية',
        subtitle: 'المس مستشعر البصمة أو استخدم بصمة الوجه لفتح قفل التطبيق',
        description: 'يرجى مسح بصمة إصبعك لتأكيد هويتك ومتابعة استخدام التطبيق بأمان'
      });
      if (res.success) {
        return { success: true };
      }
      return {
        success: false,
        error: res.error || 'لم يتم التعرف على البصمة بواسطة مستشعر الهاتف.',
        needEnrollment: res.needEnrollment
      };
    } catch (err: any) {
      return { success: false, error: err.message || 'حدث خطأ في مستشعر البصمة.' };
    }
  }

  // Web Browser Platform (WebAuthn)
  try {
    if (!window.PublicKeyCredential) {
      return { success: false, error: 'مستشعر البصمة غير مدعوم على هذا المتصفح أو الهاتف.' };
    }

    const challenge = new Uint8Array(32);
    window.crypto.getRandomValues(challenge);

    const allowCredentials: PublicKeyCredentialDescriptor[] = [];
    if (credentialId && !credentialId.startsWith('native_')) {
      const match = credentialId.match(/.{1,2}/g);
      if (match) {
        const idArray = new Uint8Array(match.map(byte => parseInt(byte, 16)));
        allowCredentials.push({
          type: 'public-key',
          id: idArray
        });
      }
    }

    const validRpId = getValidRpId();

    const getOptions: PublicKeyCredentialRequestOptions = {
      challenge,
      ...(validRpId ? { rpId: validRpId } : {}),
      timeout: 60000,
      userVerification: 'required',
      ...(allowCredentials.length > 0 ? { allowCredentials } : {})
    };

    const assertion = await navigator.credentials.get({
      publicKey: getOptions
    });

    if (assertion) {
      return { success: true };
    }
    return { success: false, error: 'لم يتم التعرف على البصمة بواسطة مستشعر الهاتف.' };
  } catch (err: any) {
    console.warn('Biometric verify error:', err);
    let msg = 'فشل التحقق من بصمة الهاتف.';
    if (err.name === 'NotAllowedError') {
      msg = 'تم إلغاء طلب البصمة من الهاتف، أو لم يتم لمس المستشعر بالوقت المناسب.';
    } else if (err.name === 'InvalidStateError') {
      msg = 'بيانات البصمة السابقة تحتاج إلى تجديد على هذا الجهاز.';
    }
    return { success: false, error: msg };
  }
}

// Session state management
export function isAppUnlockedSession(): boolean {
  try {
    const isUnlocked = sessionStorage.getItem(UNLOCKED_KEY) === 'true';
    if (!isUnlocked) return false;

    // Check auto lock interval
    const settings = getSecuritySettings();
    if (!settings || !settings.enabled) return true;

    if (settings.autoLockIntervalMinutes === 0) {
      // 0 means immediately on reload/app launch
      return false;
    }

    if (settings.autoLockIntervalMinutes > 0) {
      const lastActive = parseInt(sessionStorage.getItem(LAST_ACTIVE_KEY) || '0', 10);
      if (lastActive > 0) {
        const diffMinutes = (Date.now() - lastActive) / (1000 * 60);
        if (diffMinutes >= settings.autoLockIntervalMinutes) {
          sessionStorage.removeItem(UNLOCKED_KEY);
          return false;
        }
      }
    }

    return true;
  } catch {
    return false;
  }
}

export function setAppUnlockedSession(unlocked: boolean): void {
  try {
    if (unlocked) {
      sessionStorage.setItem(UNLOCKED_KEY, 'true');
      sessionStorage.setItem(LAST_ACTIVE_KEY, String(Date.now()));
    } else {
      sessionStorage.removeItem(UNLOCKED_KEY);
    }
  } catch {
    // Ignore storage issues
  }
}

export function updateLastActiveTimestamp(): void {
  try {
    sessionStorage.setItem(LAST_ACTIVE_KEY, String(Date.now()));
  } catch {
    // Ignore
  }
}
