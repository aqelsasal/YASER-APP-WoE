/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Worker, Supplier, Employee, getTodayDateString } from '../types';

export interface ParsedExpenseItem {
  id: string;
  originalLine: string;
  date: string;
  description: string;
  amount: number;
  currency: string;
  category: string;
  categories: string[];
  notes: string;
  recipientType: 'worker' | 'supplier' | 'employee' | 'none';
  recipientId: string;
  recipientName: string;
  expenseType: 'direct' | 'indirect';
  confidence: 'high' | 'medium' | 'low';
  selected: boolean;
  validationError?: string;
}

// Robust currency regex strictly matching explicit currency terms without corrupting Arabic words
// (e.g. "ري" which means irrigation/watering in Arabic is NEVER treated as currency!)
// (e.g. "سعودي" and "يمني" are nationalities/names and only stripped if preceded by "ريال")
export const CURRENCY_BOUNDED_REGEX = /(?<=^|[^\p{L}\p{N}])(?:ريال\s*سعودي|ريال\s*يمني|ريالات|ريال|دولار|دولارات|درهم|درهم\s*إماراتي|ر\.س|ر\.ي|\$|usd|sar|yer|aed)(?=$|[^\p{L}\p{N}])/giu;

// Convert Eastern Arabic numerals (٠-٩) and Persian numerals to Western Arabic (0-9)
// and normalize Arabic decimal / thousands separators
export const normalizeDigits = (str: string): string => {
  if (!str) return '';
  return str
    .replace(/[٠۰]/g, '0')
    .replace(/[١۱]/g, '1')
    .replace(/[٢۲]/g, '2')
    .replace(/[٣۳]/g, '3')
    .replace(/[٤۴]/g, '4')
    .replace(/[٥۵]/g, '5')
    .replace(/[٦۶]/g, '6')
    .replace(/[٧۷]/g, '7')
    .replace(/[٨۸]/g, '8')
    .replace(/[٩۹]/g, '9')
    .replace(/٫/g, '.')
    .replace(/٬/g, ',')
    .replace(/(?<=\d)[،,](?=\d)/g, ',');
};

// Date extraction helper - only strips explicit date prefix tags without stripping words from descriptions
export const detectDate = (text: string, defaultDate: string = getTodayDateString()): { date: string; cleanedText: string } => {
  let cleaned = text || '';
  const today = new Date();

  // Check for 'اليوم' only as a leading prefix tag (e.g. "اليوم: ..." or "تاريخ اليوم: ...")
  const todayPrefixMatch = cleaned.match(/^(?:بتاريخ\s+|تاريخ\s+)?اليوم\s*[:\-\u2014]\s*/iu);
  if (todayPrefixMatch) {
    cleaned = cleaned.slice(todayPrefixMatch[0].length).trim();
    return { date: defaultDate, cleanedText: cleaned };
  }

  // Check for 'أمس' or 'امس' only as a leading prefix tag (e.g. "أمس: ..." or "امس - ...")
  const yesterdayPrefixMatch = cleaned.match(/^(?:بتاريخ\s+|تاريخ\s+)?(?:أمس|امس)\s*[:\-\u2014]\s*/iu);
  if (yesterdayPrefixMatch) {
    cleaned = cleaned.slice(yesterdayPrefixMatch[0].length).trim();
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    const yStr = `${yesterday.getFullYear()}-${String(yesterday.getMonth() + 1).padStart(2, '0')}-${String(yesterday.getDate()).padStart(2, '0')}`;
    return { date: yStr, cleanedText: cleaned };
  }

  // Check ISO format YYYY[-/]MM[-/]DD
  const isoMatch = cleaned.match(/(?:^|\s)(20\d{2})[-/](0?[1-9]|1[0-2])[-/](0?[1-9]|[12]\d|3[01])(?:\s|:|$)/);
  if (isoMatch) {
    const y = isoMatch[1];
    const m = isoMatch[2].padStart(2, '0');
    const d = isoMatch[3].padStart(2, '0');
    cleaned = cleaned.replace(isoMatch[0].trim(), ' ').trim();
    return { date: `${y}-${m}-${d}`, cleanedText: cleaned };
  }

  // Check DMY format DD[-/]MM[-/]YYYY
  const dmyMatch = cleaned.match(/(?:^|\s)(0?[1-9]|[12]\d|3[01])[-/](0?[1-9]|1[0-2])[-/](20\d{2})(?:\s|:|$)/);
  if (dmyMatch) {
    const d = dmyMatch[1].padStart(2, '0');
    const m = dmyMatch[2].padStart(2, '0');
    const y = dmyMatch[3];
    cleaned = cleaned.replace(dmyMatch[0].trim(), ' ').trim();
    return { date: `${y}-${m}-${d}`, cleanedText: cleaned };
  }

  // Check short date DD/MM or MM/DD within current year only at beginning or end
  const shortMatch = cleaned.match(/^(?:بتاريخ\s+|تاريخ\s+)?(0?[1-9]|[12]\d|3[01])[-/](0?[1-9]|1[0-2])\s*[:\-\u2014]?\s*/);
  if (shortMatch) {
    const d = shortMatch[1].padStart(2, '0');
    const m = shortMatch[2].padStart(2, '0');
    const y = today.getFullYear();
    cleaned = cleaned.slice(shortMatch[0].length).trim();
    return { date: `${y}-${m}-${d}`, cleanedText: cleaned };
  }

  return { date: defaultDate, cleanedText: cleaned };
};

// Automatic Category detection strictly adhering to user's defined categories
export const detectCategory = (description: string, availableCategories: string[] = []): string => {
  const d = (description || '').toLowerCase();
  
  // Safe list of categories provided by the application
  const cats = Array.isArray(availableCategories) && availableCategories.length > 0
    ? availableCategories.filter(c => typeof c === 'string' && c.trim().length > 0)
    : [
        'مواد استهلاكية',
        'مواد غذائية',
        'مواد بناء وكهرباء',
        'اصول مضافة',
        'مرتبات وموظفين',
        'أجور وعمالة',
        'أخرى'
      ];

  const findMatching = (regex: RegExp): string | undefined => {
    return cats.find(c => regex.test(c));
  };

  // Labor & Wages keywords
  if (/(اجرة|أجرة|يومية|يوميات|حساب|أتعاب|مصاريف عمال|صب|عمال|مليس|نجار|حداد|بناء|معلم|مقاول|مساعد|عتالة|تعتيل)/i.test(d)) {
    const matched = findMatching(/(أجور|عمال|عمالة)/i);
    if (matched) return matched;
  }

  // Building Materials & Electrical
  if (/(اسمنت|سمنت|حديد|خشب|طوب|بلك|رمل|كري|صلبخ|نيس|جبس|دهان|بوية|معجون|بلاط|سيراميك|رخام|غراء|عازل|مسامير|زنك|شبك|بردورات|كهرباء|سلك|اسلاك|قاطع|قواطع|لمبة|لمبات|انارة|سباكة|ماصورة|مواسير|كوع|اكواع|محبس|خلاط|دينمو|مضخة|غطاس)/i.test(d)) {
    const matched = findMatching(/(بناء|كهرباء|مواد)/i);
    if (matched) return matched;
  }

  // Food & Sustenance
  if (/(غداء|صبوح|فطور|عشاء|وجبة|طعام|ماء|شاي|سكر|عصائر|كراتين ماء|كوثر|بسكوت|كافتيريا|مطعم)/i.test(d)) {
    const matched = findMatching(/(غذائية|إعاشة|طعام)/i);
    if (matched) return matched;
  }

  // Fuel, Transport, Equipment
  if (/(ديزل|بنزين|بترول|غاز|نقل|مشوار|شحن|تاكسي|دينا|قلاب|وايت|بوزة|توصيل|اجرة سيارة|شاحنة|كرين|ونش|ايجار|إيجار|تصليح|صيانة|دريل|صاروخ|شاكوش|ادوات|عدة|قطع غيار|زيوت|بطارية)/i.test(d)) {
    const matched = findMatching(/(استهلاكية|اصول|أصول|معدات|صيانة|نقل)/i);
    if (matched) return matched;
  }

  // Salaries & Employees
  if (/(راتب|رواتب|مرتب|مرتبات|سلفة موظف|حافز|مكافأة)/i.test(d)) {
    const matched = findMatching(/(مرتبات|موظفين)/i);
    if (matched) return matched;
  }

  // Fallback to "أخرى" if exists in the categories, otherwise pick the first defined category
  const otherCat = cats.find(c => /(أخرى|اخرى|عامة)/i.test(c));
  if (otherCat) return otherCat;

  return cats[0] || 'أخرى';
};

// Safe Recipient matching with full defensive checks
export const matchRecipient = (
  text: string,
  workers: Worker[] = [],
  suppliers: Supplier[] = [],
  employees: Employee[] = []
): {
  recipientType: 'worker' | 'supplier' | 'employee' | 'none';
  recipientId: string;
  recipientName: string;
} => {
  const clean = (text || '').toLowerCase();
  if (!clean || clean.length < 2) {
    return { recipientType: 'none', recipientId: '', recipientName: '' };
  }

  // Safely check suppliers
  const safeSuppliers = Array.isArray(suppliers) ? suppliers : [];
  for (const s of safeSuppliers) {
    if (!s || !s.name) continue;
    const sName = s.name.trim().toLowerCase();
    if (sName.length >= 3 && clean.includes(sName)) {
      return { recipientType: 'supplier', recipientId: s.id || '', recipientName: s.name };
    }
  }

  // Safely check employees
  const safeEmployees = Array.isArray(employees) ? employees : [];
  for (const em of safeEmployees) {
    if (!em || !em.name) continue;
    const emName = em.name.trim().toLowerCase();
    if (emName.length >= 3 && clean.includes(emName)) {
      return { recipientType: 'employee', recipientId: em.id || '', recipientName: em.name };
    }
  }

  // Safely check workers
  const safeWorkers = Array.isArray(workers) ? workers : [];
  for (const w of safeWorkers) {
    if (!w || !w.name) continue;
    const wName = w.name.trim().toLowerCase();
    if (wName.length >= 3 && clean.includes(wName)) {
      return { recipientType: 'worker', recipientId: w.id || '', recipientName: w.name };
    }
  }

  return { recipientType: 'none', recipientId: '', recipientName: '' };
};

/**
 * Main parser function to parse multi-line note string into structured expense objects.
 * Per user instruction:
 * Always adopt the project's default currency without branching or complex automatic detection.
 */
export const parseNotesToExpenses = (
  rawText: string,
  options: {
    defaultDate?: string;
    defaultCurrency?: string;
    workers?: Worker[];
    suppliers?: Supplier[];
    employees?: Employee[];
    availableCategories?: string[];
    autoNotes?: boolean;
  } = {}
): ParsedExpenseItem[] => {
  const {
    defaultDate = getTodayDateString(),
    defaultCurrency = 'ريال يمني',
    workers = [],
    suppliers = [],
    employees = [],
    availableCategories = [],
    autoNotes = true
  } = options || {};

  if (!rawText || typeof rawText !== 'string' || !rawText.trim()) {
    return [];
  }

  const lines = rawText.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
  const items: ParsedExpenseItem[] = [];

  lines.forEach((line, index) => {
    // Skip obvious header or separator lines (e.g. "-----------------", "مصاريف اليوم:", etc.)
    if (/^[-=_*#~]{3,}$/.test(line)) return;
    if (/^(الملاحظات|ملاحظات|المصاريف|النفقات|كشف النفقات|التاريخ|البيان|المبلغ)\s*:?$/i.test(line)) return;

    // Convert Arabic-Indic numerals to 0-9 and normalize separators
    let workingLine = normalizeDigits(line);

    // Remove leading list numbers or bullet points like "1- ", "1. ", "1) ", "* ", "-", "• "
    // (Ensure dates like "10-10-2026" are not stripped of their leading day number)
    workingLine = workingLine.replace(/^(\d+[\.)]\s+|(?:\d+\s*[-]\s+(?!\d))|[\*\-•▪▫►]\s*)/, '').trim();

    // 1. Detect and strip Date if present
    const { date: extractedDate, cleanedText: textWithoutDate } = detectDate(workingLine, defaultDate);
    workingLine = textWithoutDate;

    // 2. Remove any currency words with strict Unicode boundaries so letters inside Arabic words are NEVER stripped
    const textWithoutCur = workingLine.replace(CURRENCY_BOUNDED_REGEX, ' ');

    // 3. Extract Amount
    // Matches numbers with optional thousand commas/spaces and optional decimals
    const numberRegex = /(?:\b|^)(\d{1,3}(?:[,\s]\d{3})+(?:\.\d+)?|\d+(?:\.\d+)?)(?:\b|$)/g;
    const matches: { value: number; raw: string; index: number }[] = [];

    let m: RegExpExecArray | null;
    while ((m = numberRegex.exec(textWithoutCur)) !== null) {
      const rawNum = m[1].replace(/[,\s]/g, '');
      const parsedNum = parseFloat(rawNum);
      if (!isNaN(parsedNum) && parsedNum > 0) {
        matches.push({ value: parsedNum, raw: m[1], index: m.index });
      }
    }

    if (matches.length === 0) {
      // Line has no discernible amount
      return;
    }

    // Pick best match (e.g. highest or last amount, ignoring small quantities like '20 كيس')
    let bestMatch = matches[matches.length - 1];
    if (matches.length > 1) {
      const sortedByVal = [...matches].sort((a, b) => b.value - a.value);
      if (sortedByVal[0].value > 50 && sortedByVal[0].value > sortedByVal[1].value * 3) {
        bestMatch = sortedByVal[0];
      }
    }

    const amount = bestMatch.value;

    // 4. Clean Description: Slice out the exact amount occurrence by index from textWithoutCur
    // This guarantees that earlier numbers (e.g. "20 كيس" or "10 طن") and Arabic words remain completely untouched!
    const beforeAmount = textWithoutCur.slice(0, bestMatch.index);
    const afterAmount = textWithoutCur.slice(bestMatch.index + bestMatch.raw.length);
    let desc = (beforeAmount + ' ' + afterAmount)
      .replace(/[:=\-_/|]+/g, ' ')
      .replace(/\s{2,}/g, ' ')
      .replace(/^[\.\-\*•,،\s]+|[\.\-\*•,،\s]+$/g, '')
      .trim();

    if (!desc || desc.length < 2) {
      desc = `نفقة مستوردة بمبلغ ${amount}`;
    }

    // 5. Detect Category strictly from availableCategories
    let category = detectCategory(desc, availableCategories);

    // 6. Match Recipient safely
    const recipient = matchRecipient(desc, workers, suppliers, employees);

    // If recipient is employee or worker, auto-align category accordingly:
    if (recipient.recipientType === 'employee') {
      category = availableCategories.find(c => c === 'مرتبات وموظفين') || 'مرتبات وموظفين';
    } else if (recipient.recipientType === 'worker') {
      category = availableCategories.find(c => c === 'أجور وعمالة') || 'أجور وعمالة';
    }

    // 7. Always adopt the project's default currency
    items.push({
      id: `imp_${Date.now()}_${index}_${Math.random().toString(36).slice(2, 6)}`,
      originalLine: line,
      date: extractedDate,
      description: desc,
      amount,
      currency: defaultCurrency,
      category,
      categories: [category],
      notes: autoNotes ? `مستورد من الملاحظات (${line})` : '',
      recipientType: recipient.recipientType,
      recipientId: recipient.recipientId,
      recipientName: recipient.recipientName,
      expenseType: 'direct',
      confidence: matches.length > 1 ? 'medium' : 'high',
      selected: true
    });
  });

  return items;
};
