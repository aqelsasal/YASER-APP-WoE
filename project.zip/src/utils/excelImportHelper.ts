/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Universal robust parser for Excel date values.
 * Handles Excel serial timestamps, Date instances, and string formats (YYYY-MM-DD, DD/MM/YYYY, etc.)
 */
export function parseExcelDate(raw: any, defaultToday: boolean = true): string {
  if (raw === undefined || raw === null || raw === '' || raw === '-') {
    return defaultToday ? new Date().toISOString().split('T')[0] : '';
  }

  // If already a JavaScript Date instance
  if (raw instanceof Date) {
    if (!isNaN(raw.getTime())) {
      return raw.toISOString().split('T')[0];
    }
  }

  // If Excel numeric serial date (e.g., 45123)
  if (typeof raw === 'number') {
    // Excel epoch begins at Dec 30 1899
    const dateObj = new Date((raw - 25569) * 86400 * 1000);
    if (!isNaN(dateObj.getTime())) {
      return dateObj.toISOString().split('T')[0];
    }
  }

  const str = String(raw).trim();

  // Pure number string (e.g. "45123")
  if (/^\d{5}$/.test(str)) {
    const num = parseInt(str, 10);
    const dateObj = new Date((num - 25569) * 86400 * 1000);
    if (!isNaN(dateObj.getTime())) {
      return dateObj.toISOString().split('T')[0];
    }
  }

  // Standard YYYY-MM-DD or YYYY/MM/DD
  const ymdMatch = str.match(/^(\d{4})[-/](\d{1,2})[-/](\d{1,2})/);
  if (ymdMatch) {
    const y = ymdMatch[1];
    const m = ymdMatch[2].padStart(2, '0');
    const d = ymdMatch[3].padStart(2, '0');
    return `${y}-${m}-${d}`;
  }

  // DD/MM/YYYY or DD-MM-YYYY
  const dmyMatch = str.match(/^(\d{1,2})[-/](\d{1,2})[-/](\d{4})/);
  if (dmyMatch) {
    const d = dmyMatch[1].padStart(2, '0');
    const m = dmyMatch[2].padStart(2, '0');
    const y = dmyMatch[3];
    return `${y}-${m}-${d}`;
  }

  // Fallback to Date.parse
  const parsed = Date.parse(str);
  if (!isNaN(parsed)) {
    return new Date(parsed).toISOString().split('T')[0];
  }

  return defaultToday ? new Date().toISOString().split('T')[0] : '';
}

/**
 * Universal robust parser for Excel numeric cells.
 * Strips commas, currency markers, non-numeric noise and returns clean number.
 */
export function parseExcelNumber(raw: any, defaultValue: number = 0): number {
  if (raw === undefined || raw === null || raw === '' || raw === '-') {
    return defaultValue;
  }
  if (typeof raw === 'number') {
    return isNaN(raw) ? defaultValue : raw;
  }
  const cleanStr = String(raw).replace(/[^\d.-]/g, '');
  const parsed = parseFloat(cleanStr);
  return isNaN(parsed) ? defaultValue : parsed;
}

/**
 * Clean string extraction from Excel cell
 */
export function parseExcelString(raw: any, defaultValue: string = ''): string {
  if (raw === undefined || raw === null) return defaultValue;
  const str = String(raw).trim();
  if (str === '-' || str === 'undefined' || str === 'null') return defaultValue;
  return str;
}

/**
 * Standardize currency from Excel
 */
export function parseExcelCurrency(raw: any, defaultCur: string = 'YER'): 'YER' | 'SAR' | 'USD' {
  if (!raw) return (defaultCur as 'YER' | 'SAR' | 'USD') || 'YER';
  const str = String(raw).toUpperCase().trim();
  if (str.includes('SAR') || str.includes('سعودي') || str.includes('ر.س')) return 'SAR';
  if (str.includes('USD') || str.includes('دولار') || str.includes('$')) return 'USD';
  return 'YER';
}
