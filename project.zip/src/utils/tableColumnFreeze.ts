/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { safeLocalStorageGetJSON, safeLocalStorageSet } from './safeStorage';

const TABLE_FREEZE_STORAGE_PREFIX = 'table_freeze_cols_';

// Keep track of active MutationObservers per table
const activeObservers = new WeakMap<HTMLTableElement, MutationObserver>();

/**
 * Returns a stable unique ID for a table element to persist freeze preferences.
 */
export const getTableIdentifier = (table: HTMLTableElement): string => {
  if (table.id) return table.id;
  const customId = table.getAttribute('data-table-id');
  if (customId) return customId;

  // Derive an identifier based on closest tab or container with an ID
  const container = table.closest('[id]');
  if (container?.id) return `tbl_${container.id}`;

  // Use header texts signature as a deterministic unique fingerprint
  try {
    const ths = table.querySelectorAll('thead tr:first-child > th');
    if (ths.length > 0) {
      const headerSig = Array.from(ths)
        .map((th) => (th.textContent || '').replace(/[◀▶▲▼🔒🔓\s]/g, '').slice(0, 8))
        .filter(Boolean)
        .join('_');
      if (headerSig) return `tbl_${headerSig}`;
    }
  } catch {}

  // Fallback to table className snippet
  const classKey = (table.className || '').split(' ').slice(0, 3).join('_');
  return `tbl_${classKey || 'default'}`;
};

/**
 * Retrieves the set of currently frozen column indices for a table.
 */
export const getFrozenColumnIndices = (table: HTMLTableElement): Set<number> => {
  const attr = table.getAttribute('data-frozen-cols');
  if (attr) {
    try {
      const parsed = JSON.parse(attr);
      if (Array.isArray(parsed)) {
        return new Set<number>(parsed.map(Number));
      }
    } catch {}
  }

  // Check safeLocalStorage
  const tableId = getTableIdentifier(table);
  const saved = safeLocalStorageGetJSON<number[]>(`${TABLE_FREEZE_STORAGE_PREFIX}${tableId}`, []);
  if (Array.isArray(saved) && saved.length > 0) {
    table.setAttribute('data-frozen-cols', JSON.stringify(saved));
    return new Set<number>(saved);
  }

  return new Set<number>();
};

/**
 * Checks if a specific column index in a table is currently frozen.
 */
export const isColumnFrozen = (table: HTMLTableElement, colIndex: number): boolean => {
  const frozenSet = getFrozenColumnIndices(table);
  return frozenSet.has(colIndex);
};

/**
 * Recalculates and applies sticky positioning styles to all frozen headers and cells in a table.
 */
export const applyTableFreeze = (table: HTMLTableElement | null): void => {
  if (!table) return;

  const ths = Array.from(table.querySelectorAll('thead tr:first-child > th')) as HTMLElement[];
  if (ths.length === 0) return;

  const frozenIndices = getFrozenColumnIndices(table);
  const maxFrozenIdx = frozenIndices.size > 0 ? Math.max(...Array.from(frozenIndices)) : -1;

  // In RTL layout (standard for this app), index 0 is on the far right.
  // We accumulate widths from right to left (index 0, 1, 2...).
  let accumulatedRight = 0;

  ths.forEach((th, idx) => {
    const isFrozen = frozenIndices.has(idx);
    const isEdge = isFrozen && idx === maxFrozenIdx;

    if (isFrozen) {
      const width = Math.round(th.getBoundingClientRect().width);
      th.style.setProperty('position', 'sticky', 'important');
      th.style.setProperty('right', `${accumulatedRight}px`, 'important');
      th.style.setProperty('z-index', '35', 'important');
      th.setAttribute('data-col-frozen', 'true');
      th.classList.add('col-frozen');

      if (isEdge) {
        th.classList.add('col-frozen-edge');
      } else {
        th.classList.remove('col-frozen-edge');
      }

      // Update all corresponding cells in tbody
      const rows = table.querySelectorAll('tbody tr');
      rows.forEach((row) => {
        // Skip empty-state rows or full-width spanned rows
        if (row.children.length <= 1) return;

        const cell = row.children[idx] as HTMLElement;
        if (cell) {
          cell.style.setProperty('position', 'sticky', 'important');
          cell.style.setProperty('right', `${accumulatedRight}px`, 'important');
          cell.style.setProperty('z-index', '20', 'important');
          cell.setAttribute('data-col-frozen', 'true');
          cell.classList.add('col-frozen');

          if (isEdge) {
            cell.classList.add('col-frozen-edge');
          } else {
            cell.classList.remove('col-frozen-edge');
          }
        }
      });

      accumulatedRight += width;
    } else {
      th.style.removeProperty('position');
      th.style.removeProperty('right');
      th.style.removeProperty('z-index');
      th.removeAttribute('data-col-frozen');
      th.classList.remove('col-frozen', 'col-frozen-edge');

      const rows = table.querySelectorAll('tbody tr');
      rows.forEach((row) => {
        if (row.children.length <= 1) return;

        const cell = row.children[idx] as HTMLElement;
        if (cell) {
          cell.style.removeProperty('position');
          cell.style.removeProperty('right');
          cell.style.removeProperty('z-index');
          cell.removeAttribute('data-col-frozen');
          cell.classList.remove('col-frozen', 'col-frozen-edge');
        }
      });
    }
  });

  // Attach a MutationObserver to tbody to automatically apply styles when rows re-render
  if (!activeObservers.has(table)) {
    const tbody = table.querySelector('tbody');
    if (tbody) {
      const observer = new MutationObserver(() => {
        // Debounce / run on next tick
        requestAnimationFrame(() => {
          applyTableFreeze(table);
        });
      });
      observer.observe(tbody, { childList: true });
      activeObservers.set(table, observer);
    }
  }
};

/**
 * Toggles the frozen status of a column at colIndex in a table.
 * Returns the new frozen state (true = frozen, false = unfrozen).
 */
export const toggleColumnFreeze = (table: HTMLTableElement, colIndex: number): boolean => {
  const frozenSet = getFrozenColumnIndices(table);
  const willBeFrozen = !frozenSet.has(colIndex);

  if (willBeFrozen) {
    frozenSet.add(colIndex);
  } else {
    frozenSet.delete(colIndex);
  }

  const arr = Array.from(frozenSet).sort((a, b) => a - b);
  table.setAttribute('data-frozen-cols', JSON.stringify(arr));

  // Persist preference in localStorage
  const tableId = getTableIdentifier(table);
  safeLocalStorageSet(`${TABLE_FREEZE_STORAGE_PREFIX}${tableId}`, JSON.stringify(arr));

  // Apply visual layout updates immediately
  applyTableFreeze(table);

  // Dispatch custom window event so buttons update their active icons
  window.dispatchEvent(
    new CustomEvent('table-freeze-change', {
      detail: { table, colIndex, isFrozen: willBeFrozen }
    })
  );

  return willBeFrozen;
};
