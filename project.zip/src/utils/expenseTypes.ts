/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useCallback } from 'react';

export interface ExpenseTypeItem {
  id: string;
  name: string;
  isDefault?: boolean;
}

export const DEFAULT_EXPENSE_TYPES: ExpenseTypeItem[] = [
  { id: 'direct', name: 'نفقات مباشرة', isDefault: true },
  { id: 'indirect', name: 'نفقات غير مباشرة', isDefault: true }
];

const STORAGE_KEY = 'custom_expense_types_list';
const EVENT_NAME = 'expenseTypesChanged';

export function getStoredExpenseTypes(): ExpenseTypeItem[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [...DEFAULT_EXPENSE_TYPES];
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed) && parsed.length > 0) {
      return parsed.filter(t => t && typeof t.id === 'string' && typeof t.name === 'string');
    }
  } catch (e) {
    console.error('Failed to load expense types:', e);
  }
  return [...DEFAULT_EXPENSE_TYPES];
}

export function saveStoredExpenseTypes(types: ExpenseTypeItem[]): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(types));
    window.dispatchEvent(new CustomEvent(EVENT_NAME, { detail: { types } }));
  } catch (e) {
    console.error('Failed to save expense types:', e);
  }
}

export function addStoredExpenseType(name: string): { success: boolean; message?: string; item?: ExpenseTypeItem } {
  const trimmed = name.trim();
  if (!trimmed) {
    return { success: false, message: 'الرجاء إدخال اسم نوع النفقة.' };
  }

  const current = getStoredExpenseTypes();
  if (current.some(t => t.name.toLowerCase() === trimmed.toLowerCase())) {
    return { success: false, message: 'هذا النوع موجود مسبقاً.' };
  }

  const newId = 'type_' + Date.now().toString() + '_' + Math.random().toString(36).substring(2, 5);
  const newItem: ExpenseTypeItem = { id: newId, name: trimmed, isDefault: false };
  const updated = [...current, newItem];
  saveStoredExpenseTypes(updated);
  return { success: true, item: newItem };
}

export function editStoredExpenseType(id: string, newName: string): { success: boolean; message?: string } {
  const trimmed = newName.trim();
  if (!trimmed) {
    return { success: false, message: 'الرجاء إدخال الاسم الجديد لنوع النفقة.' };
  }

  const current = getStoredExpenseTypes();
  if (current.some(t => t.id !== id && t.name.toLowerCase() === trimmed.toLowerCase())) {
    return { success: false, message: 'يوجد نوع نفقة آخر بنفس هذا الاسم.' };
  }

  const updated = current.map(t => t.id === id ? { ...t, name: trimmed } : t);
  saveStoredExpenseTypes(updated);
  return { success: true };
}

export function deleteStoredExpenseType(id: string): { success: boolean; message?: string } {
  const current = getStoredExpenseTypes();
  if (current.length <= 1) {
    return { success: false, message: 'يجب الإبقاء على نوع نفقة واحد على الأقل في النظام.' };
  }

  const updated = current.filter(t => t.id !== id);
  saveStoredExpenseTypes(updated);
  return { success: true };
}

export function resetStoredExpenseTypes(): void {
  saveStoredExpenseTypes([...DEFAULT_EXPENSE_TYPES]);
}

export function reorderStoredExpenseTypes(fromIndex: number, toIndex: number): void {
  const current = getStoredExpenseTypes();
  if (fromIndex < 0 || fromIndex >= current.length || toIndex < 0 || toIndex >= current.length) return;
  const updated = [...current];
  const [moved] = updated.splice(fromIndex, 1);
  updated.splice(toIndex, 0, moved);
  saveStoredExpenseTypes(updated);
}

export function useExpenseTypes() {
  const [expenseTypes, setExpenseTypes] = useState<ExpenseTypeItem[]>(() => getStoredExpenseTypes());

  const refresh = useCallback(() => {
    const next = getStoredExpenseTypes();
    setExpenseTypes(prev => {
      if (
        prev.length === next.length &&
        prev.every((v, i) => v.id === next[i].id && v.name === next[i].name)
      ) {
        return prev;
      }
      return next;
    });
  }, []);

  useEffect(() => {
    refresh();

    const handleUpdate = () => refresh();
    window.addEventListener(EVENT_NAME, handleUpdate);
    window.addEventListener('storage', handleUpdate);

    return () => {
      window.removeEventListener(EVENT_NAME, handleUpdate);
      window.removeEventListener('storage', handleUpdate);
    };
  }, [refresh]);

  const reorderExpenseType = useCallback((fromIndex: number, toIndex: number) => {
    setExpenseTypes(prev => {
      if (fromIndex < 0 || fromIndex >= prev.length || toIndex < 0 || toIndex >= prev.length) return prev;
      const updated = [...prev];
      const [moved] = updated.splice(fromIndex, 1);
      updated.splice(toIndex, 0, moved);
      saveStoredExpenseTypes(updated);
      return updated;
    });
  }, []);

  const getTypeName = useCallback((typeId: string | undefined): string => {
    if (!typeId) return 'نفقات مباشرة';
    const found = expenseTypes.find(t => t.id === typeId || t.name === typeId);
    if (found) return found.name;
    if (typeId === 'direct') return 'نفقات مباشرة';
    if (typeId === 'indirect') return 'نفقات غير مباشرة';
    return typeId;
  }, [expenseTypes]);

  return {
    expenseTypes,
    getTypeName,
    addExpenseType: addStoredExpenseType,
    editExpenseType: editStoredExpenseType,
    deleteExpenseType: deleteStoredExpenseType,
    reorderExpenseType,
    resetDefaults: resetStoredExpenseTypes,
    refresh
  };
}
