/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useCallback, useRef } from 'react';

export const DEFAULT_EXPENSE_CATEGORIES = [
  'مواد استهلاكية',
  'مواد غذائية',
  'مواد بناء وكهرباء',
  'اصول مضافة',
  'مرتبات وموظفين',
  'أجور وعمالة',
  'أخرى'
];

const STORAGE_KEY = 'custom_expense_categories_list';
const EVENT_NAME = 'expenseCategoriesChanged';

export function getStoredExpenseCategories(): string[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [...DEFAULT_EXPENSE_CATEGORIES];
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed) && parsed.length > 0) {
      return parsed.filter(c => typeof c === 'string' && c.trim().length > 0).map(c => c.trim());
    }
  } catch (e) {
    console.error('Failed to load expense categories:', e);
  }
  return [...DEFAULT_EXPENSE_CATEGORIES];
}

export function saveStoredExpenseCategories(categories: string[]): void {
  try {
    const unique = Array.from(new Set(categories.map(c => c.trim()).filter(Boolean)));
    localStorage.setItem(STORAGE_KEY, JSON.stringify(unique));
    window.dispatchEvent(new CustomEvent(EVENT_NAME, { detail: { categories: unique } }));
  } catch (e) {
    console.error('Failed to save expense categories:', e);
  }
}

export function addStoredExpenseCategory(name: string): { success: boolean; message?: string } {
  const trimmed = name.trim();
  if (!trimmed) {
    return { success: false, message: 'الرجاء إدخال اسم الفئة.' };
  }

  const current = getStoredExpenseCategories();
  if (current.some(c => c.toLowerCase() === trimmed.toLowerCase())) {
    return { success: false, message: 'هذه الفئة موجودة مسبقاً.' };
  }

  const updated = [...current, trimmed];
  saveStoredExpenseCategories(updated);
  return { success: true };
}

export function editStoredExpenseCategory(oldName: string, newName: string): { success: boolean; message?: string } {
  const trimmedOld = oldName.trim();
  const trimmedNew = newName.trim();
  if (!trimmedNew) {
    return { success: false, message: 'الرجاء إدخال اسم الفئة الجديد.' };
  }

  const current = getStoredExpenseCategories();
  if (trimmedOld.toLowerCase() !== trimmedNew.toLowerCase()) {
    if (current.some(c => c.toLowerCase() === trimmedNew.toLowerCase())) {
      return { success: false, message: 'يوجد فئة أخرى بنفس هذا الاسم.' };
    }
  }

  const updated = current.map(c => c.toLowerCase() === trimmedOld.toLowerCase() ? trimmedNew : c);
  saveStoredExpenseCategories(updated);
  return { success: true };
}

export function deleteStoredExpenseCategory(name: string): { success: boolean; message?: string } {
  const trimmed = name.trim();
  const current = getStoredExpenseCategories();
  const updated = current.filter(c => c.toLowerCase() !== trimmed.toLowerCase());
  
  if (updated.length === 0) {
    return { success: false, message: 'يجب الإبقاء على فئة واحدة على الأقل في النظام.' };
  }

  saveStoredExpenseCategories(updated);
  return { success: true };
}

export function resetStoredExpenseCategories(): void {
  saveStoredExpenseCategories([...DEFAULT_EXPENSE_CATEGORIES]);
}

export function reorderStoredExpenseCategories(fromIndex: number, toIndex: number): void {
  const current = getStoredExpenseCategories();
  if (fromIndex < 0 || fromIndex >= current.length || toIndex < 0 || toIndex >= current.length) return;
  const updated = [...current];
  const [moved] = updated.splice(fromIndex, 1);
  updated.splice(toIndex, 0, moved);
  saveStoredExpenseCategories(updated);
}

const EMPTY_STRINGS: string[] = [];

export function useExpenseCategories(additionalFromData: string[] = EMPTY_STRINGS) {
  const additionalRef = useRef<string[]>(additionalFromData);
  additionalRef.current = additionalFromData;

  const computeCategories = useCallback(() => {
    const base = getStoredExpenseCategories();
    const set = new Set(base);
    const extra = additionalRef.current || [];
    extra.forEach(c => {
      if (c && typeof c === 'string' && c.trim()) set.add(c.trim());
    });
    return Array.from(set);
  }, []);

  const [categories, setCategories] = useState<string[]>(() => {
    const base = getStoredExpenseCategories();
    const set = new Set(base);
    (additionalFromData || []).forEach(c => {
      if (c && typeof c === 'string' && c.trim()) set.add(c.trim());
    });
    return Array.from(set);
  });

  const refresh = useCallback(() => {
    const nextCategories = computeCategories();
    setCategories(prev => {
      if (
        prev.length === nextCategories.length &&
        prev.every((val, idx) => val === nextCategories[idx])
      ) {
        return prev;
      }
      return nextCategories;
    });
  }, [computeCategories]);

  // Sync if additionalFromData contents actually change
  const additionalKey = (additionalFromData || []).join('||');
  useEffect(() => {
    refresh();
  }, [additionalKey, refresh]);

  useEffect(() => {
    const handleUpdate = () => refresh();
    window.addEventListener(EVENT_NAME, handleUpdate);
    window.addEventListener('storage', handleUpdate);

    return () => {
      window.removeEventListener(EVENT_NAME, handleUpdate);
      window.removeEventListener('storage', handleUpdate);
    };
  }, [refresh]);

  const reorderCategory = useCallback((fromIndex: number, toIndex: number) => {
    setCategories(prev => {
      if (fromIndex < 0 || fromIndex >= prev.length || toIndex < 0 || toIndex >= prev.length) return prev;
      const updated = [...prev];
      const [moved] = updated.splice(fromIndex, 1);
      updated.splice(toIndex, 0, moved);
      saveStoredExpenseCategories(updated);
      return updated;
    });
  }, []);

  return {
    categories,
    addCategory: addStoredExpenseCategory,
    editCategory: editStoredExpenseCategory,
    deleteCategory: deleteStoredExpenseCategory,
    reorderCategory,
    resetDefaults: resetStoredExpenseCategories,
    refresh
  };
}
