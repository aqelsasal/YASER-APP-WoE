/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Capacitor } from '@capacitor/core';
import { Filesystem, Directory, Encoding } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';
import * as XLSX from 'xlsx';

/**
 * Checks if running on an Android or iOS native app environment via Capacitor
 */
export function isNativeAndroidApp(): boolean {
  try {
    return Capacitor.isNativePlatform() || Capacitor.getPlatform() === 'android';
  } catch {
    return false;
  }
}

/**
 * Clean filename and ensure valid characters and proper extension
 */
export function sanitizeFilename(filename: string, defaultExt: string = 'json'): string {
  let clean = (filename || 'file')
    .trim()
    .replace(/[/\\?%*:|"<>]/g, '_')
    .replace(/\s+/g, '_');
  const ext = defaultExt.startsWith('.') ? defaultExt : `.${defaultExt}`;
  if (!clean.toLowerCase().endsWith(ext.toLowerCase())) {
    clean = `${clean}${ext}`;
  }
  return clean;
}

/**
 * Browser Blob download helper
 */
function downloadWebBlob(filename: string, data: string | Blob, mimeType: string = 'application/json;charset=utf-8;'): void {
  const blob = typeof data === 'string' ? new Blob([data], { type: mimeType }) : data;
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  setTimeout(() => {
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }, 300);
}

export interface FileActionResult {
  success: boolean;
  message: string;
  isNative: boolean;
  fileUri?: string;
  error?: string;
}

/**
 * Saves and opens/shares a JSON file (Project backup, System backup, Settings).
 * - On Android APK: Writes to device storage via Capacitor Filesystem and opens Android Native Share Sheet.
 * - On Web Browser: Triggers direct file download.
 */
export async function saveAndShareJsonFile(
  filename: string,
  jsonString: string,
  shareTitle: string = 'نسخة احتياطية للبيانات'
): Promise<FileActionResult> {
  const isNative = isNativeAndroidApp();
  const safeName = sanitizeFilename(filename, 'json');

  if (isNative) {
    try {
      let shareUri = '';

      // 1. Write file to Cache directory first (guaranteed FileProvider compatible for Android Share Sheet)
      try {
        const cacheWrite = await Filesystem.writeFile({
          path: safeName,
          data: jsonString,
          directory: Directory.Cache,
          encoding: Encoding.UTF8,
          recursive: true
        });
        shareUri = cacheWrite.uri;
      } catch (cacheErr) {
        console.warn('Cache write failed:', cacheErr);
      }

      // 2. Also write to Documents directory for persistent file management
      let docUri = shareUri;
      try {
        const docWrite = await Filesystem.writeFile({
          path: `YaserAqelApp_Backups/${safeName}`,
          data: jsonString,
          directory: Directory.Documents,
          encoding: Encoding.UTF8,
          recursive: true
        });
        docUri = docWrite.uri;
      } catch (docErr) {
        try {
          const dataWrite = await Filesystem.writeFile({
            path: safeName,
            data: jsonString,
            directory: Directory.Data,
            encoding: Encoding.UTF8,
            recursive: true
          });
          docUri = dataWrite.uri;
        } catch (_) {}
      }

      // 3. Open Android Native Share Sheet using the Cache URI
      try {
        await Share.share({
          title: shareTitle,
          text: `ملف: ${safeName}`,
          url: shareUri || docUri,
          dialogTitle: 'اختر مكان حفظ النسخة الاحتياطية أو التطبيق المطلوب للمشاركة'
        });
      } catch (shareErr: any) {
        if (shareErr?.name === 'AbortError') {
          return {
            success: true,
            message: `تم حفظ النسخة في ذاكرة الهاتف (${safeName}).`,
            isNative: true,
            fileUri: docUri || shareUri
          };
        }
      }

      return {
        success: true,
        message: `تم حفظ النسخة الاحتياطية بنجاح (${safeName}) في ذاكرة الهاتف.`,
        isNative: true,
        fileUri: docUri || shareUri
      };
    } catch (err: any) {
      console.error('saveAndShareJsonFile native error:', err);
      // Fallback to web download if filesystem error occurs
      downloadWebBlob(safeName, jsonString, 'application/json;charset=utf-8;');
      return {
        success: true,
        message: `تم تنزيل النسخة الاحتياطية: ${safeName}`,
        isNative: false
      };
    }
  } else {
    downloadWebBlob(safeName, jsonString, 'application/json;charset=utf-8;');
    return {
      success: true,
      message: `تم تنزيل النسخة الاحتياطية بنجاح: ${safeName}`,
      isNative: false
    };
  }
}

/**
 * Saves and opens/shares an Excel (.xlsx) workbook.
 * - On Android APK: Writes binary base64 to device storage and opens native share sheet.
 * - On Web: Uses XLSX.writeFile.
 */
export async function saveAndShareExcelWorkbook(
  workbook: XLSX.WorkBook,
  filename: string,
  shareTitle: string = 'ملف بيانات Excel'
): Promise<FileActionResult> {
  const isNative = isNativeAndroidApp();
  const safeName = sanitizeFilename(filename, 'xlsx');

  if (isNative) {
    try {
      // Generate Base64 representation of XLSX file
      const base64Data = XLSX.write(workbook, { bookType: 'xlsx', type: 'base64' });
      let shareUri = '';

      // 1. Write file to Cache directory first for FileProvider compatibility
      try {
        const cacheRes = await Filesystem.writeFile({
          path: safeName,
          data: base64Data,
          directory: Directory.Cache,
          recursive: true
        });
        shareUri = cacheRes.uri;
      } catch (cacheErr) {
        console.warn('Excel cache write failed:', cacheErr);
      }

      // 2. Also persist file to Documents / Data
      let docUri = shareUri;
      try {
        const docRes = await Filesystem.writeFile({
          path: `YaserAqelApp_Reports/${safeName}`,
          data: base64Data,
          directory: Directory.Documents,
          recursive: true
        });
        docUri = docRes.uri;
      } catch {
        try {
          const dataRes = await Filesystem.writeFile({
            path: safeName,
            data: base64Data,
            directory: Directory.Data,
            recursive: true
          });
          docUri = dataRes.uri;
        } catch (_) {}
      }

      try {
        await Share.share({
          title: shareTitle,
          text: `ملف Excel: ${safeName}`,
          url: shareUri || docUri,
          dialogTitle: 'فتح أو مشاركة ملف Excel'
        });
      } catch (shareErr) {
        // Share dialog cancelled or dismissed
      }

      return {
        success: true,
        message: `تم تصدير وحفظ ملف Excel بنجاح: ${safeName}`,
        isNative: true,
        fileUri: docUri || shareUri
      };
    } catch (err: any) {
      console.error('saveAndShareExcelWorkbook error:', err);
      XLSX.writeFile(workbook, safeName);
      return {
        success: true,
        message: `تم تصدير ملف Excel: ${safeName}`,
        isNative: false
      };
    }
  } else {
    XLSX.writeFile(workbook, safeName);
    return {
      success: true,
      message: `تم تنزيل ملف Excel بنجاح: ${safeName}`,
      isNative: false
    };
  }
}
