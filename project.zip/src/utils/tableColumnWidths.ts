/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Persistent Table Column Widths Utility.
 * Ensures user-customized table column widths & auto-fit sizes persist
 * permanently across tab navigation, page changes, and app restarts.
 */

import { safeLocalStorageGetJSON, safeLocalStorageSet } from './safeStorage';
import { applyTableFreeze, getTableIdentifier } from './tableColumnFreeze';

export const TABLE_WIDTHS_STORAGE_PREFIX = 'table_col_widths_v1_';

export interface SavedColumnWidths {
  tableWidth?: number;
  columns: Record<number, number>; // colIndex -> width in px
  columnKeys?: Record<string, number>; // header title/key -> width in px
  timestamp: number;
}

// Memory cache to debounce multi-handle mount calls in the same frame
const frameRestorationMap = new WeakMap<HTMLTableElement, number>();

/**
 * Derives a clean header text key for a <th> element.
 */
export const getColumnHeaderKey = (th: HTMLElement, index: number): string => {
  const customKey = th.getAttribute('data-col-key');
  if (customKey) return customKey;

  // Extract primary text label (ignoring icons, arrows, buttons)
  const span = th.querySelector('span:not(.text-\\[9px\\])');
  const text = (span?.textContent || th.textContent || '')
    .replace(/[◀▶▲▼🔒🔓\s]/g, '')
    .trim();

  return text || `col_${index}`;
};

/**
 * Saves all current column widths and overall table width to localStorage.
 */
export const saveTableColumnWidths = (table: HTMLTableElement | null): void => {
  if (!table) return;

  try {
    const tableId = getTableIdentifier(table);
    if (!tableId) return;

    const ths = Array.from(table.querySelectorAll('thead tr:first-child > th')) as HTMLElement[];
    if (ths.length === 0) return;

    const columnWidths: Record<number, number> = {};
    const columnKeys: Record<string, number> = {};

    ths.forEach((th, idx) => {
      // Get the rendered pixel width
      const width = Math.round(th.getBoundingClientRect().width);
      if (width > 15) {
        columnWidths[idx] = width;
        const key = getColumnHeaderKey(th, idx);
        columnKeys[key] = width;
      }
    });

    const tableRect = table.getBoundingClientRect();
    const tableWidth = Math.round(tableRect.width);

    const payload: SavedColumnWidths = {
      tableWidth: tableWidth > 100 ? tableWidth : undefined,
      columns: columnWidths,
      columnKeys,
      timestamp: Date.now()
    };

    safeLocalStorageSet(`${TABLE_WIDTHS_STORAGE_PREFIX}${tableId}`, JSON.stringify(payload));
  } catch (err) {
    console.warn('[TableColumnWidths] Failed to save column widths:', err);
  }
};

/**
 * Restores saved column widths for a table element from localStorage.
 * Returns true if saved widths were found and applied.
 */
export const restoreTableColumnWidths = (table: HTMLTableElement | null): boolean => {
  if (!table) return false;

  try {
    const tableId = getTableIdentifier(table);
    if (!tableId) return false;

    const saved = safeLocalStorageGetJSON<SavedColumnWidths | null>(
      `${TABLE_WIDTHS_STORAGE_PREFIX}${tableId}`,
      null
    );

    if (!saved || !saved.columns) return false;

    const ths = Array.from(table.querySelectorAll('thead tr:first-child > th')) as HTMLElement[];
    if (ths.length === 0) return false;

    // Apply fixed table layout so explicit pixel widths are strictly respected
    table.style.tableLayout = 'fixed';

    let totalCalculatedWidth = 0;

    ths.forEach((th, idx) => {
      const headerKey = getColumnHeaderKey(th, idx);
      // Try by column index first, then fallback to header key
      const savedWidth = saved.columns[idx] || (saved.columnKeys && saved.columnKeys[headerKey]);

      if (savedWidth && savedWidth >= 20) {
        th.style.width = `${savedWidth}px`;
        th.style.minWidth = `${savedWidth}px`;
        totalCalculatedWidth += savedWidth;
      } else {
        const curW = Math.round(th.getBoundingClientRect().width);
        if (curW > 20) {
          th.style.width = `${curW}px`;
          th.style.minWidth = `${curW}px`;
          totalCalculatedWidth += curW;
        }
      }
    });

    const finalTableWidth = saved.tableWidth || totalCalculatedWidth;
    if (finalTableWidth > 100) {
      table.style.width = `${finalTableWidth}px`;
      table.style.minWidth = `${finalTableWidth}px`;
    }

    // Mark as having restored widths
    table.setAttribute('data-col-widths-restored', 'true');

    // Update sticky positioning offsets for any frozen columns
    applyTableFreeze(table);

    return true;
  } catch (err) {
    console.warn('[TableColumnWidths] Failed to restore column widths:', err);
    return false;
  }
};

/**
 * Debounced version of restoreTableColumnWidths to avoid multiple executions
 * when multiple ColumnResizeHandle components mount simultaneously in the same header row.
 */
export const scheduleRestoreTableColumnWidths = (table: HTMLTableElement | null): void => {
  if (!table) return;

  const existingRaf = frameRestorationMap.get(table);
  if (existingRaf) {
    cancelAnimationFrame(existingRaf);
  }

  const rafId = requestAnimationFrame(() => {
    frameRestorationMap.delete(table);
    restoreTableColumnWidths(table);
  });

  frameRestorationMap.set(table, rafId);
};

/**
 * Resets table column widths back to their default responsive CSS sizes
 * and removes the saved preferences from localStorage.
 */
export const resetTableColumnWidths = (table: HTMLTableElement | null): void => {
  if (!table) return;

  try {
    const tableId = getTableIdentifier(table);
    if (tableId) {
      try {
        localStorage.removeItem(`${TABLE_WIDTHS_STORAGE_PREFIX}${tableId}`);
      } catch {}
    }

    // Clear inline styles on table
    table.style.removeProperty('table-layout');
    table.style.removeProperty('width');
    table.style.removeProperty('min-width');
    table.removeAttribute('data-col-widths-restored');

    // Clear inline styles on all headers
    const ths = Array.from(table.querySelectorAll('thead tr:first-child > th')) as HTMLElement[];
    ths.forEach((th) => {
      th.style.removeProperty('width');
      th.style.removeProperty('min-width');
    });

    // Reapply freeze offsets if any exist
    applyTableFreeze(table);
  } catch (err) {
    console.warn('[TableColumnWidths] Failed to reset column widths:', err);
  }
};
