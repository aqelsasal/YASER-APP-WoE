/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type UndoCategory =
  | 'expenses'
  | 'workers'
  | 'employees'
  | 'suppliers'
  | 'general_debts'
  | 'company_assets'
  | 'projects'
  | 'boq'
  | 'budget'
  | 'evaluations';

export type UndoActionType = 'delete' | 'update' | 'add';

export interface UndoItemDetail {
  label: string;
  value: string;
}

export interface UndoItem {
  id: string;
  timestamp: string; // ISO
  formattedTime: string; // e.g. "10:30 ص" or "2026-09-24"
  timeAgo: string; // e.g. "منذ دقيقة"
  category: UndoCategory;
  categoryLabel: string; // e.g. "المصروفات اليومية"
  actionType: UndoActionType;
  actionLabel: string; // e.g. "حذف سند صرف"
  title: string; // e.g. "سند صرف بمبلغ 50,000 ر.ي لمحمد"
  description?: string;
  details: UndoItemDetail[];
  projectId?: string;
  projectName?: string;
  payload: {
    type: string;
    data: any;
    extra?: any;
  };
}
