/**
 * Utility for locking background scroll and isolating touch gestures
 * when modals/popups are open. Supports nested modals via reference counting.
 */

let lockCount = 0;
let scrollY = 0;
let previousBodyOverflow = '';
let previousHtmlOverflow = '';
let previousBodyOverscroll = '';
let previousBodyPosition = '';
let previousBodyTop = '';
let previousBodyWidth = '';

let touchStartY = 0;
let touchStartX = 0;

function handleTouchStart(e: TouchEvent) {
  if (e.touches && e.touches.length > 0) {
    touchStartY = e.touches[0].clientY;
    touchStartX = e.touches[0].clientX;
  }
}

function handleTouchMove(e: TouchEvent) {
  if (!e.touches || e.touches.length === 0) return;

  const target = e.target as HTMLElement | null;
  if (!target) return;

  // If touch is inside ANY modal card, dialog, header, body, form, or content
  // (any element inside the modal backdrop container that is not the backdrop itself),
  // NEVER call preventDefault! Allow 100% natural, fluid touch scrolling and swiping.
  const modalBackdrop = target.closest('.fixed.inset-0, [id*="backdrop"], [role="dialog"]');
  if (modalBackdrop && target !== modalBackdrop) {
    return;
  }

  const isInsideModal = target.closest(
    '[id*="modal"], [role="dialog"], .modal-dialog-card, .modal-scroll-area, .custom-scrollbar, .overflow-y-auto, .overflow-auto, form, table, input, textarea, select, button, label, header, footer'
  );

  if (isInsideModal) {
    // Let the browser handle touch scrolling naturally with full inertia
    return;
  }

  // Only prevent default if touching the bare dark backdrop outside the modal card
  if (e.cancelable && (target === modalBackdrop || target.classList.contains('fixed'))) {
    e.preventDefault();
  }
}

export function lockScroll() {
  if (typeof document === 'undefined' || typeof window === 'undefined') return;

  if (lockCount === 0) {
    scrollY = window.scrollY || window.pageYOffset || 0;
    previousBodyOverflow = document.body.style.overflow;
    previousHtmlOverflow = document.documentElement.style.overflow;
    previousBodyOverscroll = document.body.style.overscrollBehavior;
    previousBodyPosition = document.body.style.position;
    previousBodyTop = document.body.style.top;
    previousBodyWidth = document.body.style.width;

    document.body.style.position = 'fixed';
    document.body.style.top = `-${scrollY}px`;
    document.body.style.width = '100%';
    document.body.style.overflow = 'hidden';
    document.documentElement.style.overflow = 'hidden';
    document.body.style.overscrollBehavior = 'none';
    document.documentElement.style.overscrollBehavior = 'none';
    document.body.classList.add('modal-open');

    window.addEventListener('touchstart', handleTouchStart, { passive: true });
    window.addEventListener('touchmove', handleTouchMove, { passive: false });
  }
  lockCount++;
}

export function unlockScroll() {
  if (typeof document === 'undefined' || typeof window === 'undefined') return;

  lockCount = Math.max(0, lockCount - 1);
  if (lockCount === 0) {
    document.body.style.position = previousBodyPosition;
    document.body.style.top = previousBodyTop;
    document.body.style.width = previousBodyWidth;
    document.body.style.overflow = previousBodyOverflow;
    document.documentElement.style.overflow = previousHtmlOverflow;
    document.body.style.overscrollBehavior = previousBodyOverscroll;
    document.documentElement.style.overscrollBehavior = '';
    document.body.classList.remove('modal-open');

    window.removeEventListener('touchstart', handleTouchStart);
    window.removeEventListener('touchmove', handleTouchMove);

    window.scrollTo(0, scrollY);
  }
}

import { useEffect } from 'react';

export function useBodyScrollLock(isLocked: boolean = true) {
  useEffect(() => {
    if (!isLocked) return;

    lockScroll();
    return () => {
      unlockScroll();
    };
  }, [isLocked]);
}

