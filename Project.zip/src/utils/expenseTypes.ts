/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useCallback } from 'react';

export interface ExpenseTypeItem {
  id: string;
  name: string;
  isDefault?: boolean;
}

export const DEFAULT_EXPENSE_TYPES: ExpenseTypeItem[] = [
  { id: 'direct', name: 'نفقات مباشرة', isDefault: true },
  { id: 'indirect', name: 'نفقات غير مباشرة', isDefault: true }
];

const STORAGE_KEY = 'custom_expense_types_list';
const EVENT_NAME = 'expenseTypesChanged';

export function getStoredExpenseTypes(): ExpenseTypeItem[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [...DEFAULT_EXPENSE_TYPES];
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed) && parsed.length > 0) {
      return parsed.filter(t => t && typeof t.id === 'string' && typeof t.name === 'string');
    }
  } catch (e) {
    console.error('Failed to load expense types:', e);
  }
  return [...DEFAULT_EXPENSE_TYPES];
}

export function saveStoredExpenseTypes(types: ExpenseTypeItem[]): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(types));
    window.dispatchEvent(new CustomEvent(EVENT_NAME, { detail: { types } }));
  } catch (e) {
    console.error('Failed to save expense types:', e);
  }
}

export function addStoredExpenseType(name: string): { success: boolean; message?: string; item?: ExpenseTypeItem } {
  const trimmed = name.trim();
  if (!trimmed) {
    return { success: false, message: 'الرجاء إدخال اسم نوع النفقة.' };
  }

  const current = getStoredExpenseTypes();
  if (current.some(t => t.name.toLowerCase() === trimmed.toLowerCase())) {
    return { success: false, message: 'هذا النوع موجود مسبقاً.' };
  }

  const newId = 'type_' + Date.now().toString() + '_' + Math.random().toString(36).substring(2, 5);
  const newItem: ExpenseTypeItem = { id: newId, name: trimmed, isDefault: false };
  const updated = [...current, newItem];
  saveStoredExpenseTypes(updated);
  return { success: true, item: newItem };
}

export function editStoredExpenseType(id: string, newName: string): { success: boolean; message?: string } {
  const trimmed = newName.trim();
  if (!trimmed) {
    return { success: false, message: 'الرجاء إدخال الاسم الجديد لنوع النفقة.' };
  }

  const current = getStoredExpenseTypes();
  if (current.some(t => t.id !== id && t.name.toLowerCase() === trimmed.toLowerCase())) {
    return { success: false, message: 'يوجد نوع نفقة آخر بنفس هذا الاسم.' };
  }

  const updated = current.map(t => t.id === id ? { ...t, name: trimmed } : t);
  saveStoredExpenseTypes(updated);
  return { success: true };
}

export function deleteStoredExpenseType(id: string): { success: boolean; message?: string } {
  const current = getStoredExpenseTypes();
  if (current.length <= 1) {
    return { success: false, message: 'يجب الإبقاء على نوع نفقة واحد على الأقل في النظام.' };
  }

  const updated = current.filter(t => t.id !== id);
  saveStoredExpenseTypes(updated);
  return { success: true };
}

export function resetStoredExpenseTypes(): void {
  saveStoredExpenseTypes([...DEFAULT_EXPENSE_TYPES]);
}

export function useExpenseTypes() {
  const [expenseTypes, setExpenseTypes] = useState<ExpenseTypeItem[]>(() => getStoredExpenseTypes());

  const refresh = useCallback(() => {
    setExpenseTypes(getStoredExpenseTypes());
  }, []);

  useEffect(() => {
    refresh();

    const handleUpdate = () => refresh();
    window.addEventListener(EVENT_NAME, handleUpdate);
    window.addEventListener('storage', handleUpdate);

    return () => {
      window.removeEventListener(EVENT_NAME, handleUpdate);
      window.removeEventListener('storage', handleUpdate);
    };
  }, [refresh]);

  const getTypeName = useCallback((typeId: string | undefined): string => {
    if (!typeId) return 'نفقات مباشرة';
    const found = expenseTypes.find(t => t.id === typeId || t.name === typeId);
    if (found) return found.name;
    if (typeId === 'direct') return 'نفقات مباشرة';
    if (typeId === 'indirect') return 'نفقات غير مباشرة';
    return typeId;
  }, [expenseTypes]);

  return {
    expenseTypes,
    getTypeName,
    addExpenseType: addStoredExpenseType,
    editExpenseType: editStoredExpenseType,
    deleteExpenseType: deleteStoredExpenseType,
    resetDefaults: resetStoredExpenseTypes,
    refresh
  };
}
