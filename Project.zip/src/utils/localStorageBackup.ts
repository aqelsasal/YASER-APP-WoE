/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Backward compatibility wrapper around backupService.ts.
 * Strictly READ-ONLY: Never writes, mutates, or deletes any localStorage data.
 */

import {
  extractRawLocalStorageData,
  createBackupFile,
  shareBackup,
  downloadBackupFileDirect,
  copyJsonToClipboard,
  calculateChecksum,
  validateBackupFileContent,
  executeRestore,
  isNativePlatform,
  getRuntimePlatform,
  LocalStorageBackupPayload,
  BackupExecutionResult,
  RestoreValidationResult
} from '../services/backupService';

export type {
  LocalStorageBackupPayload,
  BackupExecutionResult,
  RestoreValidationResult
};

export interface LocalStorageBackupData {
  backupObject: any;
  jsonString: string;
  fileName: string;
  keysCount: number;
  sizeKb: number;
  checksum: string;
}

export interface LocalStorageBackupResult {
  success: boolean;
  message: string;
  deliveryMethod?: 'download' | 'share' | 'clipboard' | 'ready';
  data?: LocalStorageBackupData;
  error?: string;
}

export function calculateSimpleChecksum(str: string): string {
  return calculateChecksum(str);
}

export function generateLocalStorageRawBackupData(): LocalStorageBackupData {
  const { payload, jsonString, fileName, sizeKb } = extractRawLocalStorageData();
  return {
    backupObject: payload,
    jsonString,
    fileName,
    keysCount: payload.metadata.totalKeysCount,
    sizeKb,
    checksum: payload.checksum
  };
}

export function downloadBackupFile(fileName: string, jsonString: string): boolean {
  return downloadBackupFileDirect(fileName, jsonString);
}

export async function shareBackupFile(
  fileName: string,
  jsonString: string,
  title: string = 'نسخة احتياطية لبيانات التطبيق'
): Promise<{ success: boolean; message?: string }> {
  return shareBackup({
    success: true,
    message: '',
    fileName,
    sizeKb: parseFloat((new Blob([jsonString]).size / 1024).toFixed(2)),
    keysCount: 0,
    checksum: '',
    jsonString,
    platform: getRuntimePlatform(),
    isNative: isNativePlatform()
  });
}

export async function copyBackupToClipboard(jsonString: string): Promise<boolean> {
  return copyJsonToClipboard(jsonString);
}

export {
  createBackupFile,
  shareBackup,
  validateBackupFileContent,
  executeRestore,
  isNativePlatform,
  getRuntimePlatform
};
