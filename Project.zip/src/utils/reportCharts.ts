// Utility to generate self-contained, crisp vector SVG charts and executive dashboard layouts
// for Print/PDF reports across all modules (Financial Reports, Daily Expenses, Employees, Workers, Suppliers).

import { Supplier, SupplierMaterialItem, formatCurrency } from '../types';

export const MATERIAL_CATEGORY_COLORS: Record<string, string> = {
  'سمنت': '#0284c7',       // Sky blue
  'سمنت ابيض': '#06b6d4',  // Cyan
  'حديد تسليح': '#b91c1c',  // Deep red
  'حديد ورش': '#ea580c',    // Orange
  'خرسانة جاهزة': '#4f46e5',// Indigo
  'بلك': '#d97706',        // Amber
  'حجر': '#78716c',        // Stone
  'نيسة/رملة': '#eab308',   // Yellow
  'كري': '#64748b',        // Slate
  'مواد كهرباء': '#8b5cf6', // Violet
  'مواد سباكة': '#0ea5e9',  // Light blue
  'رنج/دهان': '#ec4899',   // Pink
  'ادوات ومعدات': '#10b981',// Emerald
  'مستلزمات': '#14b8a6',   // Teal
  'كسر رخام': '#a855f7',   // Purple
  'عام': '#64748b',
  'أخرى': '#94a3b8'
};

export const PALETTE_FALLBACKS = [
  '#0284c7', '#b91c1c', '#059669', '#d97706', '#7c3aed', 
  '#ea580c', '#4f46e5', '#06b6d4', '#ec4899', '#14b8a6', 
  '#eab308', '#78716c', '#64748b', '#a855f7', '#10b981'
];

export function resolveCategoryColor(category?: string, fallbackIdx: number = 0): string {
  if (!category) return '#64748b';
  const trimmed = category.trim();
  if (MATERIAL_CATEGORY_COLORS[trimmed]) return MATERIAL_CATEGORY_COLORS[trimmed];
  try {
    const raw = typeof window !== 'undefined' ? localStorage.getItem('custom_supplier_material_category_colors') : null;
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed && parsed[trimmed]) return parsed[trimmed];
    }
  } catch (e) {}
  let hash = 0;
  for (let i = 0; i < trimmed.length; i++) {
    hash = (hash << 5) - hash + trimmed.charCodeAt(i);
    hash |= 0;
  }
  const idx = Math.abs(hash + fallbackIdx) % PALETTE_FALLBACKS.length;
  return PALETTE_FALLBACKS[idx];
}

export interface ChartDataItem {
  label: string;
  value: number;
  color: string;
  formattedValue?: string;
  subText?: string;
}

export interface MetricCardItem {
  title: string;
  value: string;
  subText?: string;
  badge?: string;
  bgColor: string;
  borderColor: string;
  textColor: string;
}

/**
 * Generates an SVG Donut Chart with percentage slices, legend, and center text
 */
export function generateSvgDonutChart(options: {
  data: ChartDataItem[];
  size?: number;
  centerTitle?: string;
  centerSubtitle?: string;
  showLegend?: boolean;
}): string {
  const { data, size = 180, centerTitle = '', centerSubtitle = '', showLegend = true } = options;
  const total = data.reduce((sum, d) => sum + (d.value > 0 ? d.value : 0), 0);

  if (total <= 0) {
    return `
      <div style="display: flex; align-items: center; justify-content: center; height: 120px; color: #94a3b8; font-size: 11px; background: #f8fafc; border-radius: 8px; border: 1px dashed #cbd5e1;">
        لا توجد بيانات كافية لرسم المخطط البياني
      </div>
    `;
  }

  const radius = 64;
  const strokeWidth = 28;
  const circumference = 2 * Math.PI * radius;
  let accumulatedOffset = 0;

  const circles = data
    .filter(d => d.value > 0)
    .map(d => {
      const percentage = (d.value / total) * 100;
      const strokeDasharray = `${(percentage / 100) * circumference} ${circumference}`;
      const strokeDashoffset = -accumulatedOffset;
      accumulatedOffset += (percentage / 100) * circumference;

      return `
        <circle
          cx="100"
          cy="100"
          r="${radius}"
          fill="none"
          stroke="${d.color}"
          stroke-width="${strokeWidth}"
          stroke-dasharray="${strokeDasharray}"
          stroke-dashoffset="${strokeDashoffset}"
        />
      `;
    })
    .join('');

  const svgChart = `
    <div style="position: relative; width: ${size}px; height: ${size}px; margin: 0 auto; display: flex; align-items: center; justify-content: center;">
      <svg viewBox="0 0 200 200" width="${size}" height="${size}" style="transform: rotate(-90deg); overflow: visible;">
        <circle cx="100" cy="100" r="${radius}" fill="none" stroke="#f1f5f9" stroke-width="${strokeWidth}" />
        ${circles}
      </svg>
      <div style="position: absolute; inset: 0; display: flex; flex-direction: column; align-items: center; justify-content: center; text-align: center; pointer-events: none;">
        ${centerTitle ? `<span style="font-size: 13px; font-weight: 900; color: #0f172a; line-height: 1.1;">${centerTitle}</span>` : ''}
        ${centerSubtitle ? `<span style="font-size: 9.5px; color: #64748b; margin-top: 2px;">${centerSubtitle}</span>` : ''}
      </div>
    </div>
  `;

  if (!showLegend) return svgChart;

  const legendItems = data
    .filter(d => d.value > 0)
    .map(d => {
      const pct = ((d.value / total) * 100).toFixed(1);
      return `
        <div style="display: flex; justify-content: space-between; align-items: center; font-size: 10.5px; margin-bottom: 4px;">
          <div style="display: flex; align-items: center; gap: 5px;">
            <span style="display: inline-block; width: 8px; height: 8px; border-radius: 50%; background-color: ${d.color}; shrink-0;"></span>
            <span style="color: #334155; font-weight: bold;">${d.label}</span>
          </div>
          <div style="display: flex; align-items: center; gap: 6px;">
            <span style="font-family: monospace; font-weight: bold; color: #0f172a;">${d.formattedValue || d.value.toLocaleString()}</span>
            <span style="font-size: 9.5px; color: #64748b; font-weight: bold; background: #f1f5f9; padding: 1px 4px; border-radius: 4px;">${pct}%</span>
          </div>
        </div>
      `;
    })
    .join('');

  return `
    <div style="display: grid; grid-template-columns: ${size}px 1fr; gap: 12px; align-items: center;">
      ${svgChart}
      <div style="display: flex; flex-direction: column; justify-content: center;">
        ${legendItems}
      </div>
    </div>
  `;
}

/**
 * Generates Horizontal Percentage/Value Bars
 */
export function generateSvgHorizontalBars(options: {
  data: ChartDataItem[];
  maxVal?: number;
  unit?: string;
}): string {
  const { data, unit = '' } = options;
  const total = data.reduce((max, d) => Math.max(max, d.value), 0);
  const maxVal = options.maxVal && options.maxVal > 0 ? options.maxVal : (total > 0 ? total : 1);

  return data
    .filter(d => d.value >= 0)
    .map(d => {
      const pct = Math.min(100, Math.max(2, Math.round((d.value / maxVal) * 100)));
      return `
        <div style="margin-bottom: 6px;">
          <div style="display: flex; justify-content: space-between; align-items: center; font-size: 10.5px; margin-bottom: 2px;">
            <span style="color: #1e293b; font-weight: bold; display: flex; align-items: center; gap: 4px;">
              <span style="display: inline-block; width: 7px; height: 7px; border-radius: 2px; background-color: ${d.color};"></span>
              ${d.label} ${d.subText ? `<span style="font-size: 9px; color: #64748b;">(${d.subText})</span>` : ''}
            </span>
            <span style="font-weight: bold; font-family: monospace; color: #0f172a; font-size: 10.5px;">
              ${d.formattedValue || d.value.toLocaleString()} ${unit}
            </span>
          </div>
          <div style="width: 100%; height: 7px; background-color: #f1f5f9; border-radius: 4px; overflow: hidden;">
            <div style="width: ${pct}%; height: 100%; background-color: ${d.color}; border-radius: 4px;"></div>
          </div>
        </div>
      `;
    })
    .join('');
}

/**
 * Generates Dual Balance Comparison Gauge (e.g. له vs عليه)
 */
export function generateSvgBalanceComparison(options: {
  forHim: number;
  onHim: number;
  forHimLabel?: string;
  onHimLabel?: string;
  forHimFormatted: string;
  onHimFormatted: string;
  netFormatted: string;
  isPositive: boolean;
}): string {
  const {
    forHim,
    onHim,
    forHimLabel = 'إجمالي المستحقات (له)',
    onHimLabel = 'إجمالي المسدد والسلف (عليه)',
    forHimFormatted,
    onHimFormatted,
    netFormatted,
    isPositive
  } = options;

  const total = (forHim + onHim) || 1;
  const forHimPct = Math.round((forHim / total) * 100);
  const onHimPct = 100 - forHimPct;

  return `
    <div style="background-color: #ffffff; border: 1px solid #e2e8f0; border-radius: 8px; padding: 10px 12px; margin-bottom: 10px;">
      <div style="display: flex; justify-content: space-between; align-items: center; font-size: 11px; font-weight: bold; margin-bottom: 6px;">
        <span style="color: #10b981;">• ${forHimLabel}: <strong>${forHimFormatted}</strong> (${forHimPct}%)</span>
        <span style="color: #e11d48;">• ${onHimLabel}: <strong>${onHimFormatted}</strong> (${onHimPct}%)</span>
      </div>
      <div style="width: 100%; height: 10px; background-color: #f1f5f9; border-radius: 5px; overflow: hidden; display: flex; margin-bottom: 8px;">
        <div style="width: ${forHimPct}%; height: 100%; background-color: #10b981;"></div>
        <div style="width: ${onHimPct}%; height: 100%; background-color: #e11d48;"></div>
      </div>
      <div style="display: flex; justify-content: space-between; align-items: center; font-size: 10.5px; background-color: ${isPositive ? '#f0fdf4' : '#fef2f2'}; border: 1px solid ${isPositive ? '#bbf7d0' : '#fecaca'}; border-radius: 6px; padding: 5px 10px;">
        <span style="font-weight: bold; color: ${isPositive ? '#166534' : '#991b1b'};">صافي المستحق النهائي:</span>
        <span style="font-weight: 900; font-family: monospace; font-size: 12px; color: ${isPositive ? '#15803d' : '#b91c1c'};">${netFormatted}</span>
      </div>
    </div>
  `;
}

/**
 * Generates an Executive KPI Metric Cards Grid
 */
export function generateMetricCardsGrid(cards: MetricCardItem[], columns = 4): string {
  const cardsHtml = cards
    .map(c => `
      <div style="background-color: ${c.bgColor}; border: 1px solid ${c.borderColor}; border-radius: 8px; padding: 8px 10px; display: flex; flex-direction: column; justify-content: space-between;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 4px;">
          <span style="font-size: 10px; font-weight: bold; color: ${c.textColor};">${c.title}</span>
          ${c.badge ? `<span style="font-size: 9px; font-weight: 800; background: #ffffff; padding: 1px 5px; border-radius: 4px; border: 1px solid ${c.borderColor}; color: ${c.textColor};">${c.badge}</span>` : ''}
        </div>
        <div style="font-size: 13.5px; font-weight: 900; color: ${c.textColor}; font-family: monospace; line-height: 1.2;">
          ${c.value}
        </div>
        ${c.subText ? `<div style="font-size: 9px; color: #64748b; margin-top: 3px;">${c.subText}</div>` : ''}
      </div>
    `)
    .join('');

  return `
    <div style="display: grid; grid-template-columns: repeat(${columns}, 1fr); gap: 8px; margin-bottom: 12px;">
      ${cardsHtml}
    </div>
  `;
}

/**
 * Renders an elegant, full-width HTML table showing detailed material items for a single transaction/entry
 * Optimized for full-width sub-row presentation without cell compression.
 */
export function generateSupplierItemsDetailedTableHtml(
  items: SupplierMaterialItem[],
  currency: string,
  invoiceNumber?: string,
  materialDiscount?: number
): string {
  if (!items || items.length === 0) return '';

  const totalSum = items.reduce((acc, it) => acc + (it.total || (it.quantity * it.unitPrice) || 0), 0);
  const discount = (materialDiscount && materialDiscount > 0) ? materialDiscount : 0;
  const netTotal = Math.max(0, totalSum - discount);

  const rowsHtml = items.map((it, idx) => {
    const categoryName = it.category?.trim() || 'غير محدد';
    const catColor = resolveCategoryColor(categoryName, idx);
    const itemTotal = it.total || (it.quantity * it.unitPrice) || 0;

    return `
      <tr style="background-color: ${idx % 2 === 0 ? '#ffffff' : '#fffdf9'};">
        <td style="padding: 6px 8px; border: 1px solid #fed7aa; text-align: center; font-family: monospace; font-weight: bold; color: #9a3412; width: 4%; font-size: 11px;">${idx + 1}</td>
        <td style="padding: 6px 10px; border: 1px solid #fed7aa; font-weight: bold; color: #0f172a; width: 30%; font-size: 11px;">
          <div style="font-weight: 800; color: #0f172a;">${it.itemName}</div>
          ${it.notes ? `<div style="font-size: 9px; font-weight: normal; color: #64748b; margin-top: 2px; line-height: 1.3;">📌 ملاحظة: ${it.notes}</div>` : ''}
        </td>
        <td style="padding: 6px 8px; border: 1px solid #fed7aa; text-align: center; width: 16%;">
          <span style="display: inline-block; background-color: #fff7ed; color: ${catColor}; border: 1px solid ${catColor}55; padding: 2.5px 8px; border-radius: 12px; font-size: 10px; font-weight: 800; white-space: nowrap;">
            🏷️ ${categoryName}
          </span>
        </td>
        <td style="padding: 6px 8px; border: 1px solid #fed7aa; text-align: center; font-family: monospace; font-weight: bold; color: #0f172a; width: 10%; font-size: 11.5px;">${it.quantity}</td>
        <td style="padding: 6px 8px; border: 1px solid #fed7aa; text-align: center; color: #475569; font-size: 10.5px; width: 8%; font-weight: 600;">${it.unit || '-'}</td>
        <td style="padding: 6px 8px; border: 1px solid #fed7aa; text-align: center; font-family: monospace; color: #334155; width: 15%; font-size: 11px;">${formatCurrency(it.unitPrice, currency)}</td>
        <td style="padding: 6px 8px; border: 1px solid #fed7aa; text-align: center; font-family: monospace; font-weight: 900; color: #c2410c; width: 17%; font-size: 11.5px;">${formatCurrency(itemTotal, currency)}</td>
      </tr>
    `;
  }).join('');

  return `
    <div style="margin: 4px 0 6px 0; border: 1.5px solid #fed7aa; border-radius: 8px; overflow: hidden; background: #ffffff; box-shadow: 0 1px 3px rgba(0,0,0,0.03); font-size: 11px; width: 100%;">
      <div style="background: linear-gradient(135deg, #fff7ed 0%, #ffedd5 100%); padding: 6px 12px; display: flex; justify-content: space-between; align-items: center; border-bottom: 1.5px solid #fed7aa; flex-wrap: wrap; gap: 8px;">
        <div style="display: flex; align-items: center; gap: 8px; flex-wrap: wrap;">
          <span style="font-weight: 900; color: #9a3412; font-size: 11.5px; display: flex; align-items: center; gap: 4px;">
            📦 كشف أصناف ومواد الفاتورة (${items.length} ${items.length === 1 ? 'صنف' : 'أصناف'})
          </span>
          ${invoiceNumber ? `<span style="font-family: monospace; font-size: 10px; font-weight: bold; background: #ffffff; color: #c2410c; padding: 2px 8px; border-radius: 6px; border: 1px solid #fdba74;">فاتورة رقم: #${invoiceNumber}</span>` : ''}
        </div>
        <div style="font-size: 10.5px; font-weight: bold; color: #9a3412; display: flex; align-items: center; gap: 10px; flex-wrap: wrap;">
          ${discount > 0 ? `<span>إجمالي المواد: <strong style="font-family: monospace; color: #334155; font-size: 11px;">${formatCurrency(totalSum, currency)}</strong></span>` : ''}
          ${discount > 0 ? `<span style="color: #b91c1c;">الخصم المطبق: <strong style="font-family: monospace; font-size: 11px;">-${formatCurrency(discount, currency)}</strong></span>` : ''}
          <span style="background: #ffffff; padding: 2px 8px; border-radius: 6px; border: 1px solid #fdba74;">
            صافي الفاتورة: <strong style="font-family: monospace; font-size: 12px; color: #c2410c;">${formatCurrency(netTotal, currency)}</strong>
          </span>
        </div>
      </div>
      <table style="width: 100%; border-collapse: collapse; text-align: right; margin: 0; background: #ffffff;">
        <thead>
          <tr style="background-color: #fff7ed; color: #7c2d12; font-size: 10.5px; font-weight: 800;">
            <th style="padding: 6px 8px; border: 1px solid #fed7aa; text-align: center; width: 4%;">#</th>
            <th style="padding: 6px 10px; border: 1px solid #fed7aa; width: 30%;">الصنف / المادة</th>
            <th style="padding: 6px 8px; border: 1px solid #fed7aa; text-align: center; width: 16%;">الفئة</th>
            <th style="padding: 6px 8px; border: 1px solid #fed7aa; text-align: center; width: 10%;">الكمية</th>
            <th style="padding: 6px 8px; border: 1px solid #fed7aa; text-align: center; width: 8%;">الوحدة</th>
            <th style="padding: 6px 8px; border: 1px solid #fed7aa; text-align: center; width: 15%;">سعر الوحدة</th>
            <th style="padding: 6px 8px; border: 1px solid #fed7aa; text-align: center; width: 17%;">الإجمالي</th>
          </tr>
        </thead>
        <tbody>
          ${rowsHtml}
        </tbody>
        ${discount > 0 ? `
        <tfoot>
          <tr style="background-color: #f8fafc; font-size: 10.5px; border-top: 1px solid #fed7aa;">
            <td colspan="6" style="padding: 5px 10px; text-align: left; font-weight: bold; color: #64748b;">إجمالي قيمة الأصناف:</td>
            <td style="padding: 5px 8px; text-align: center; font-family: monospace; font-weight: bold; color: #475569; font-size: 11px;">${formatCurrency(totalSum, currency)}</td>
          </tr>
          <tr style="background-color: #fff1f2; font-size: 10.5px;">
            <td colspan="6" style="padding: 5px 10px; text-align: left; font-weight: bold; color: #be123c;">الخصم / التخفيض المستبعد:</td>
            <td style="padding: 5px 8px; text-align: center; font-family: monospace; font-weight: bold; color: #be123c; font-size: 11px;">-${formatCurrency(discount, currency)}</td>
          </tr>
          <tr style="background-color: #fff7ed; font-size: 11px; border-top: 1.5px solid #fed7aa;">
            <td colspan="6" style="padding: 6px 10px; text-align: left; font-weight: 900; color: #9a3412;">الصافي النهائي لكشف المواد:</td>
            <td style="padding: 6px 8px; text-align: center; font-family: monospace; font-weight: 900; color: #c2410c; font-size: 12px;">${formatCurrency(netTotal, currency)}</td>
          </tr>
        </tfoot>
        ` : ''}
      </table>
    </div>
  `;
}

/**
 * Generates the full Executive Dashboard & Analytics Chart for Material Categories
 * across all suppliers (as requested: summary panel & chart of total costs per category on page 1 / start of reports).
 */
export function generateMaterialCategoryAnalyticsHtml(options: {
  suppliers: Supplier[];
  currency: string;
  dateFilter?: (date: string) => boolean;
  panelTitle?: string;
  panelSubtitle?: string;
}): string {
  const {
    suppliers,
    currency,
    dateFilter,
    panelTitle = 'لوحة التحليلات والرسم البياني لإجمالي تكاليف فئات المواد والأصناف الموردة',
    panelSubtitle = 'ملخص تفصيلي لتكاليف التوريدات بحسب فئة المادة ونسبتها المئوية من إجمالي مشتريات المشروع (كافة الموردين)'
  } = options;

  interface CategoryAgg {
    category: string;
    totalCost: number;
    itemsCount: number;
    quantitiesByUnit: Record<string, number>;
    suppliersSet: Set<string>;
  }

  const catMap: Record<string, CategoryAgg> = {};
  let grandTotalMaterials = 0;
  let totalItemsCount = 0;

  suppliers.forEach(s => {
    s.ledger.forEach(entry => {
      if (dateFilter && !dateFilter(entry.date)) return;

      if (entry.materialItems && entry.materialItems.length > 0) {
        entry.materialItems.forEach(item => {
          const cat = item.category?.trim() || (s.materialType?.trim() ? s.materialType.trim() : 'توريدات عامة');
          const cost = item.total || (item.quantity * item.unitPrice) || 0;

          if (!catMap[cat]) {
            catMap[cat] = {
              category: cat,
              totalCost: 0,
              itemsCount: 0,
              quantitiesByUnit: {},
              suppliersSet: new Set<string>()
            };
          }

          catMap[cat].totalCost += cost;
          catMap[cat].itemsCount += 1;
          const u = item.unit?.trim() || 'وحدة';
          catMap[cat].quantitiesByUnit[u] = (catMap[cat].quantitiesByUnit[u] || 0) + (item.quantity || 0);
          catMap[cat].suppliersSet.add(s.name);

          grandTotalMaterials += cost;
          totalItemsCount += 1;
        });
      } else if (entry.amountForHim > 0) {
        // Fallback if transaction was logged without individual items breakdown
        const cat = s.materialType?.trim() || 'توريدات عامة';
        const cost = entry.amountForHim;

        if (!catMap[cat]) {
          catMap[cat] = {
            category: cat,
            totalCost: 0,
            itemsCount: 0,
            quantitiesByUnit: {},
            suppliersSet: new Set<string>()
          };
        }

        catMap[cat].totalCost += cost;
        catMap[cat].itemsCount += 1;
        catMap[cat].suppliersSet.add(s.name);

        grandTotalMaterials += cost;
        totalItemsCount += 1;
      }
    });
  });

  const sortedCategories = Object.values(catMap).sort((a, b) => b.totalCost - a.totalCost);

  if (sortedCategories.length === 0 || grandTotalMaterials <= 0) {
    return `
      <div style="margin-bottom: 20px; page-break-inside: avoid; border: 1px solid #e2e8f0; border-radius: 8px; background: #f8fafc; padding: 16px; text-align: center;">
        <div style="font-weight: bold; color: #475569; font-size: 13px;">📦 ${panelTitle}</div>
        <p style="color: #94a3b8; font-size: 11px; margin-top: 6px;">لا توجد أصناف مواد أو فئات مسجلة ضمن كشوفات الموردين في هذه الفترة.</p>
      </div>
    `;
  }

  // Assign colors
  const chartData: ChartDataItem[] = sortedCategories.map((c, idx) => {
    const color = resolveCategoryColor(c.category, idx);
    const pct = ((c.totalCost / grandTotalMaterials) * 100).toFixed(1);
    return {
      label: c.category,
      value: c.totalCost,
      color,
      formattedValue: formatCurrency(c.totalCost, currency),
      subText: `${pct}% (${c.itemsCount} بند)`
    };
  });

  // Top category
  const topCat = sortedCategories[0];
  const topPct = ((topCat.totalCost / grandTotalMaterials) * 100).toFixed(1);

  // Executive Metric Cards
  const metricCardsHtml = generateMetricCardsGrid([
    {
      title: 'إجمالي تكاليف المواد المقيدة',
      value: formatCurrency(grandTotalMaterials, currency),
      badge: 'إجمالي المشتريات',
      bgColor: '#fffbeb',
      borderColor: '#fde68a',
      textColor: '#b45309'
    },
    {
      title: 'عدد فئات المواد المسجلة',
      value: `${sortedCategories.length} فئة`,
      badge: 'التصنيفات المعتمدة',
      bgColor: '#f5f3ff',
      borderColor: '#ddd6fe',
      textColor: '#6d28d9'
    },
    {
      title: 'إجمالي عدد بنود الأصناف',
      value: `${totalItemsCount} صنف`,
      badge: 'أصناف المواد',
      bgColor: '#f0fdf4',
      borderColor: '#bbf7d0',
      textColor: '#15803d'
    },
    {
      title: 'أعلى فئة تكلفة بالمشروع',
      value: topCat.category,
      subText: `${formatCurrency(topCat.totalCost, currency)} (${topPct}%)`,
      badge: 'الفئة الأكثر استهلاكاً',
      bgColor: '#fef2f2',
      borderColor: '#fecaca',
      textColor: '#b91c1c'
    }
  ], 4);

  // Donut chart
  const donutHtml = generateSvgDonutChart({
    data: chartData,
    size: 120,
    centerTitle: formatCurrency(grandTotalMaterials, currency),
    centerSubtitle: 'إجمالي تكاليف المواد',
    showLegend: true
  });

  // Horizontal bars
  const barsHtml = generateSvgHorizontalBars({
    data: chartData,
    unit: ''
  });

  // Summary Table Rows
  const tableRowsHtml = sortedCategories.map((c, idx) => {
    const color = MATERIAL_CATEGORY_COLORS[c.category] || PALETTE_FALLBACKS[idx % PALETTE_FALLBACKS.length];
    const pct = ((c.totalCost / grandTotalMaterials) * 100).toFixed(1);
    const qtySummary = Object.entries(c.quantitiesByUnit)
      .map(([u, q]) => `${q} ${u}`)
      .join('، ') || '-';

    return `
      <tr style="background-color: ${idx % 2 === 0 ? '#ffffff' : '#f8fafc'};">
        <td style="padding: 6px 8px; border: 1px solid #cbd5e1; text-align: center; font-family: monospace; font-weight: bold; width: 5%;">${idx + 1}</td>
        <td style="padding: 6px 8px; border: 1px solid #cbd5e1; font-weight: bold; color: #1e293b; width: 22%;">
          <span style="display: inline-block; width: 8px; height: 8px; border-radius: 2px; background-color: ${color}; margin-left: 6px;"></span>
          ${c.category}
        </td>
        <td style="padding: 6px 8px; border: 1px solid #cbd5e1; text-align: center; font-family: monospace; color: #475569; width: 14%;">${c.itemsCount} صنف</td>
        <td style="padding: 6px 8px; border: 1px solid #cbd5e1; text-align: center; font-size: 10px; color: #64748b; width: 22%;">${qtySummary}</td>
        <td style="padding: 6px 8px; border: 1px solid #cbd5e1; text-align: center; font-size: 10.5px; color: #334155; width: 12%;">${c.suppliersSet.size} مورد</td>
        <td style="padding: 6px 8px; border: 1px solid #cbd5e1; text-align: center; font-family: monospace; font-weight: bold; color: #0f172a; width: 15%;">${formatCurrency(c.totalCost, currency)}</td>
        <td style="padding: 6px 8px; border: 1px solid #cbd5e1; text-align: center; width: 10%;">
          <span style="background-color: #f1f5f9; color: #1e293b; padding: 2px 6px; border-radius: 4px; font-weight: bold; font-family: monospace; font-size: 10px;">
            ${pct}%
          </span>
        </td>
      </tr>
    `;
  }).join('');

  return `
    <div class="chart-single-page" style="margin-top: 14px; margin-bottom: 20px; break-inside: auto; border: 1px solid #cbd5e1; border-radius: 8px; overflow: hidden; background: #ffffff;">
      
      <!-- Panel Header -->
      <div style="background: linear-gradient(135deg, #1e1b4b 0%, #312e81 100%); color: #ffffff; padding: 8px 12px; display: flex; justify-content: space-between; align-items: center; border-right: 4px solid #f59e0b; break-after: avoid; page-break-after: avoid;">
        <div>
          <h2 style="margin: 0; font-size: 13.5px; font-weight: 800; color: #ffffff;">📊 ${panelTitle}</h2>
          <div style="font-size: 9.5px; color: #c7d2fe; margin-top: 2px;">${panelSubtitle}</div>
        </div>
        <span style="font-size: 10.5px; background-color: #4338ca; color: #ffffff; padding: 3px 8px; border-radius: 10px; font-weight: bold; font-family: monospace;">العملة: ${currency}</span>
      </div>

      <div style="padding: 12px;">
        <!-- Metric Cards -->
        ${metricCardsHtml}

        <!-- Charts Grid (Donut on right, Bars on left) -->
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 12px;">
          
          <!-- Donut Chart Card -->
          <div style="background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 10px;">
            <div style="font-size: 11px; font-weight: bold; color: #1e1b4b; border-bottom: 1px solid #e2e8f0; padding-bottom: 4px; margin-bottom: 8px;">
              🍩 التوزيع النسبي لتكاليف المواد بحسب الفئات
            </div>
            ${donutHtml}
          </div>

          <!-- Horizontal Bars Card -->
          <div style="background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 10px;">
            <div style="font-size: 11px; font-weight: bold; color: #1e1b4b; border-bottom: 1px solid #e2e8f0; padding-bottom: 4px; margin-bottom: 8px;">
              📈 ترتيب الفئات حسب حجم الإنفاق المالي
            </div>
            <div style="max-height: 180px; overflow-y: hidden;">
              ${barsHtml}
            </div>
          </div>

        </div>

        <!-- Category Summary Table -->
        <div style="border: 1px solid #e2e8f0; border-radius: 6px; overflow: hidden;">
          <div style="background-color: #f1f5f9; padding: 6px 10px; font-size: 11px; font-weight: bold; color: #334155; border-bottom: 1px solid #e2e8f0;">
            📋 جدول ملخص تكاليف وأصناف كل فئة موردة
          </div>
          <table style="width: 100%; border-collapse: collapse; font-size: 11px; text-align: right;">
            <thead>
              <tr style="background-color: #312e81; color: #ffffff; font-size: 10.5px;">
                <th style="padding: 6px 8px; border: 1px solid #1e1b4b; text-align: center; width: 5%;">#</th>
                <th style="padding: 6px 8px; border: 1px solid #1e1b4b; width: 22%;">فئة المادة الموردة</th>
                <th style="padding: 6px 8px; border: 1px solid #1e1b4b; text-align: center; width: 14%;">عدد الأصناف</th>
                <th style="padding: 6px 8px; border: 1px solid #1e1b4b; text-align: center; width: 22%;">إجمالي الكميات</th>
                <th style="padding: 6px 8px; border: 1px solid #1e1b4b; text-align: center; width: 12%;">الموردون</th>
                <th style="padding: 6px 8px; border: 1px solid #1e1b4b; text-align: center; width: 15%;">إجمالي التكلفة</th>
                <th style="padding: 6px 8px; border: 1px solid #1e1b4b; text-align: center; width: 10%;">النسبة %</th>
              </tr>
            </thead>
            <tbody>
              ${tableRowsHtml}
            </tbody>
            <tfoot>
              <tr style="background-color: #e0e7ff; font-weight: bold; color: #1e1b4b;">
                <td colspan="2" style="padding: 6px 8px; border: 1px solid #cbd5e1;">المجموع الإجمالي لكافة فئات المواد:</td>
                <td style="padding: 6px 8px; border: 1px solid #cbd5e1; text-align: center; font-family: monospace;">${totalItemsCount} صنف</td>
                <td style="padding: 6px 8px; border: 1px solid #cbd5e1; text-align: center;">-</td>
                <td style="padding: 6px 8px; border: 1px solid #cbd5e1; text-align: center;">${suppliers.length} مورد</td>
                <td style="padding: 6px 8px; border: 1px solid #cbd5e1; text-align: center; font-family: monospace; color: #15803d; font-size: 12px;">${formatCurrency(grandTotalMaterials, currency)}</td>
                <td style="padding: 6px 8px; border: 1px solid #cbd5e1; text-align: center; font-family: monospace;">100%</td>
              </tr>
            </tfoot>
          </table>
        </div>

      </div>

    </div>
  `;
}

/**
 * Generates an SVG Pie/Donut Chart for Direct vs Indirect Expenses
 * Displays direct & indirect expenses with their percentage and formatted amount around the circle,
 * with explanatory callout arrows exiting from the circle towards each expense label,
 * and a light summary table underneath displaying the type, percentage, and amount.
 */
export function generateDirectVsIndirectPieChart(options: {
  directExp: number;
  indirectExp: number;
  currency: string;
}): string {
  const { directExp, indirectExp, currency } = options;
  const total = directExp + indirectExp;

  if (total <= 0) {
    return `
      <div style="display: flex; align-items: center; justify-content: center; height: 110px; color: #94a3b8; font-size: 10.5px; background: #f8fafc; border-radius: 8px; border: 1px dashed #cbd5e1;">
        لا توجد نفقات مسجلة ضمن هذه الفترة
      </div>
    `;
  }

  const directPct = Math.round((directExp / total) * 1000) / 10;
  const indirectPct = Math.round((100 - directPct) * 10) / 10;
  const directFormatted = formatCurrency(directExp, currency);
  const indirectFormatted = formatCurrency(indirectExp, currency);

  // Geometry
  const width = 340;
  const height = 136;
  const cx = 170;
  const cy = 68;
  const r = 34;
  const strokeW = 18;
  const outerR = r + strokeW / 2; // 43
  const circumference = 2 * Math.PI * r;

  const directDash = (directPct / 100) * circumference;
  const indirectDash = (indirectPct / 100) * circumference;

  // Mid-angles starting at top (-90 degrees)
  const directSpan = (directPct / 100) * 360;
  const directMidAngle = -90 + directSpan / 2;
  const directMidRad = (directMidAngle * Math.PI) / 180;

  const indirectSpan = (indirectPct / 100) * 360;
  const indirectMidAngle = -90 + directSpan + indirectSpan / 2;
  const indirectMidRad = (indirectMidAngle * Math.PI) / 180;

  // Exit points on the circle boundary
  const dExitX = Math.round(cx + outerR * Math.cos(directMidRad));
  const dExitY = Math.round(cy + outerR * Math.sin(directMidRad));

  const iExitX = Math.round(cx + outerR * Math.cos(indirectMidRad));
  const iExitY = Math.round(cy + outerR * Math.sin(indirectMidRad));

  // Label card placement
  // Direct label card on the right
  const dCardX = 230;
  const dCardY = 18;
  const dTargetX = 224;
  const dTargetY = Math.max(35, Math.min(100, dExitY));

  // Indirect label card on the left
  const iCardX = 6;
  const iCardY = 18;
  const iTargetX = 112;
  const iTargetY = Math.max(35, Math.min(100, iExitY));

  return `
    <div style="position: relative; width: 100%; max-width: 350px; margin: 0 auto;">
      <!-- Circular Chart with Callout Arrows -->
      <svg viewBox="0 0 ${width} ${height}" width="100%" height="${height}" style="overflow: visible; display: block;">
        <defs>
          <marker id="d-arrow-head" markerWidth="6" markerHeight="6" refX="5" refY="3" orient="auto">
            <path d="M0,0 L0,6 L6,3 z" fill="#0284c7" />
          </marker>
          <marker id="i-arrow-head" markerWidth="6" markerHeight="6" refX="5" refY="3" orient="auto">
            <path d="M0,0 L0,6 L6,3 z" fill="#d97706" />
          </marker>
          <filter id="shadow-d" x="-10%" y="-10%" width="120%" height="120%">
            <feDropShadow dx="0" dy="1" stdDeviation="1.5" flood-opacity="0.1" />
          </filter>
        </defs>

        <!-- Base background ring -->
        <circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="#f1f5f9" stroke-width="${strokeW}" />

        <!-- Direct Slice (Blue) -->
        <circle
          cx="${cx}"
          cy="${cy}"
          r="${r}"
          fill="none"
          stroke="#0284c7"
          stroke-width="${strokeW}"
          stroke-dasharray="${directDash} ${circumference}"
          stroke-dashoffset="0"
          transform="rotate(-90 ${cx} ${cy})"
        />

        <!-- Indirect Slice (Amber) -->
        <circle
          cx="${cx}"
          cy="${cy}"
          r="${r}"
          fill="none"
          stroke="#f59e0b"
          stroke-width="${strokeW}"
          stroke-dasharray="${indirectDash} ${circumference}"
          stroke-dashoffset="-${directDash}"
          transform="rotate(-90 ${cx} ${cy})"
        />

        <!-- Inner Center Badge -->
        <circle cx="${cx}" cy="${cy}" r="23" fill="#ffffff" stroke="#cbd5e1" stroke-width="1.2" />
        <text x="${cx}" y="${cy - 3}" text-anchor="middle" font-size="8.5" font-weight="bold" fill="#334155">هيكل</text>
        <text x="${cx}" y="${cy + 9}" text-anchor="middle" font-size="8" font-weight="bold" fill="#64748b">النفقة</text>

        <!-- Arrow exiting from Direct Expense Slice -->
        <circle cx="${dExitX}" cy="${dExitY}" r="2.5" fill="#0284c7" />
        <path
          d="M ${dExitX} ${dExitY} L ${dTargetX} ${dTargetY}"
          stroke="#0284c7"
          stroke-width="1.8"
          stroke-linecap="round"
          marker-end="url(#d-arrow-head)"
          fill="none"
        />

        <!-- Direct Expense Callout Box (Right) -->
        <g transform="translate(${dCardX}, ${dCardY})" filter="url(#shadow-d)">
          <rect x="0" y="0" width="104" height="66" rx="6" fill="#f0f9ff" stroke="#bae6fd" stroke-width="1.2" />
          <rect x="4" y="4" width="96" height="16" rx="3.5" fill="#0284c7" />
          <text x="52" y="15.5" text-anchor="middle" font-size="8.5" font-weight="bold" fill="#ffffff">نفقات مباشرة</text>
          <text x="52" y="38" text-anchor="middle" font-size="13" font-weight="900" font-family="monospace" fill="#0369a1">${directPct}%</text>
          <text x="52" y="54" text-anchor="middle" font-size="8.5" font-weight="bold" font-family="monospace" fill="#0f172a">${directFormatted}</text>
        </g>

        <!-- Arrow exiting from Indirect Expense Slice -->
        <circle cx="${iExitX}" cy="${iExitY}" r="2.5" fill="#d97706" />
        <path
          d="M ${iExitX} ${iExitY} L ${iTargetX} ${iTargetY}"
          stroke="#d97706"
          stroke-width="1.8"
          stroke-linecap="round"
          marker-end="url(#i-arrow-head)"
          fill="none"
        />

        <!-- Indirect Expense Callout Box (Left) -->
        <g transform="translate(${iCardX}, ${iCardY})" filter="url(#shadow-d)">
          <rect x="0" y="0" width="104" height="66" rx="6" fill="#fffbeb" stroke="#fde68a" stroke-width="1.2" />
          <rect x="4" y="4" width="96" height="16" rx="3.5" fill="#d97706" />
          <text x="52" y="15.5" text-anchor="middle" font-size="8.5" font-weight="bold" fill="#ffffff">نفقات غير مباشرة</text>
          <text x="52" y="38" text-anchor="middle" font-size="13" font-weight="900" font-family="monospace" fill="#b45309">${indirectPct}%</text>
          <text x="52" y="54" text-anchor="middle" font-size="8.5" font-weight="bold" font-family="monospace" fill="#0f172a">${indirectFormatted}</text>
        </g>
      </svg>

      <!-- Light Summary Table Below the Circular Chart -->
      <div style="margin-top: 6px; background: #ffffff; border: 1px solid #e2e8f0; border-radius: 6px; overflow: hidden;">
        <table style="width: 100%; font-size: 9.5px; border-collapse: collapse; text-align: right;">
          <thead>
            <tr style="background: #f8fafc; color: #475569; border-bottom: 1px solid #e2e8f0; font-size: 9px;">
              <th style="padding: 4px 8px; font-weight: 800;">نوع النفقة</th>
              <th style="padding: 4px 8px; text-align: center; font-weight: 800;">النسبة</th>
              <th style="padding: 4px 8px; text-align: left; font-weight: 800;">إجمالي المبلغ (${currency})</th>
            </tr>
          </thead>
          <tbody>
            <tr style="border-bottom: 1px solid #f1f5f9;">
              <td style="padding: 4.5px 8px; font-weight: bold; color: #0284c7; white-space: nowrap;">
                <span style="display: inline-block; width: 7px; height: 7px; border-radius: 50%; background: #0284c7; margin-left: 5px; vertical-align: middle;"></span>
                نفقات مباشرة
              </td>
              <td style="padding: 4.5px 8px; text-align: center; font-family: monospace; font-weight: 800; color: #0369a1;">
                ${directPct}%
              </td>
              <td style="padding: 4.5px 8px; text-align: left; font-family: monospace; font-weight: bold; color: #0f172a; white-space: nowrap;">
                ${directFormatted}
              </td>
            </tr>
            <tr>
              <td style="padding: 4.5px 8px; font-weight: bold; color: #d97706; white-space: nowrap;">
                <span style="display: inline-block; width: 7px; height: 7px; border-radius: 50%; background: #f59e0b; margin-left: 5px; vertical-align: middle;"></span>
                نفقات غير مباشرة
              </td>
              <td style="padding: 4.5px 8px; text-align: center; font-family: monospace; font-weight: 800; color: #b45309;">
                ${indirectPct}%
              </td>
              <td style="padding: 4.5px 8px; text-align: left; font-family: monospace; font-weight: bold; color: #0f172a; white-space: nowrap;">
                ${indirectFormatted}
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  `;
}

/**
 * Generates an Executive Chart for Parties Expense Distribution (Workers, Employees, Suppliers, General)
 * Positioned with the Chart at top and full-width explanatory breakdown below without text wrapping.
 */
export function generatePartiesExpenseChart(options: {
  workerExp: number;
  employeeExp: number;
  supplierExp: number;
  noneExp: number;
  currency: string;
}): string {
  const { workerExp, employeeExp, supplierExp, noneExp, currency } = options;
  const total = workerExp + employeeExp + supplierExp + noneExp;

  if (total <= 0) {
    return `
      <div style="display: flex; align-items: center; justify-content: center; height: 140px; color: #94a3b8; font-size: 10.5px; background: #f8fafc; border-radius: 6px; border: 1px dashed #cbd5e1;">
        لا توجد مصاريف مسجلة حسب الأطراف
      </div>
    `;
  }

  const parties = [
    { key: 'worker', label: '👷 مصاريف وسلف العمال', val: workerExp, color: '#0284c7' },
    { key: 'employee', label: '👔 مصاريف وسلف الموظفين', val: employeeExp, color: '#8b5cf6' },
    { key: 'supplier', label: '🚚 مصاريف ودفعات الموردين', val: supplierExp, color: '#059669' },
    { key: 'none', label: '📦 مصاريف عامة وغير مرحلة', val: noneExp, color: '#f59e0b' }
  ];

  const size = 86;
  const r = 31;
  const strokeW = 16;
  const circumference = 2 * Math.PI * r;
  let accumulatedOffset = 0;

  const circles = parties
    .filter(p => p.val > 0)
    .map(p => {
      const pct = (p.val / total) * 100;
      const strokeDasharray = `${(pct / 100) * circumference} ${circumference}`;
      const strokeDashoffset = -accumulatedOffset;
      accumulatedOffset += (pct / 100) * circumference;

      return `
        <circle
          cx="50"
          cy="50"
          r="${r}"
          fill="none"
          stroke="${p.color}"
          stroke-width="${strokeW}"
          stroke-dasharray="${strokeDasharray}"
          stroke-dashoffset="${strokeDashoffset}"
        />
      `;
    })
    .join('');

  const rowsHtml = parties.map(p => {
    const pct = total > 0 ? ((p.val / total) * 100).toFixed(1) : '0.0';
    return `
      <div style="margin-bottom: 4.5px;">
        <div style="display: flex; justify-content: space-between; align-items: center; font-size: 9.5px; margin-bottom: 2px; white-space: nowrap;">
          <div style="display: flex; align-items: center; gap: 5px; white-space: nowrap;">
            <span style="display: inline-block; width: 7px; height: 7px; border-radius: 50%; background-color: ${p.color}; flex-shrink: 0;"></span>
            <span style="color: #334155; font-weight: bold; white-space: nowrap;">${p.label}</span>
          </div>
          <div style="display: flex; align-items: center; gap: 6px; white-space: nowrap;">
            <span style="font-family: monospace; font-weight: bold; color: #0f172a; font-size: 9.5px; white-space: nowrap;">${formatCurrency(p.val, currency)}</span>
            <span style="font-size: 8.5px; color: #334155; font-weight: bold; background: #ffffff; border: 1px solid #cbd5e1; padding: 1px 4px; border-radius: 3px; min-width: 38px; text-align: center; font-family: monospace; white-space: nowrap;">${pct}%</span>
          </div>
        </div>
        <div style="width: 100%; height: 3.5px; background-color: #e2e8f0; border-radius: 2px; overflow: hidden;">
          <div style="width: ${pct}%; height: 100%; background-color: ${p.color}; border-radius: 2px;"></div>
        </div>
      </div>
    `;
  }).join('');

  return `
    <div style="display: flex; flex-direction: column; align-items: stretch; gap: 8px;">
      <!-- Chart on Top -->
      <div style="display: flex; justify-content: center; align-items: center; padding: 2px 0;">
        <div style="position: relative; width: ${size}px; height: ${size}px;">
          <svg viewBox="0 0 100 100" width="${size}" height="${size}" style="transform: rotate(-90deg); overflow: visible;">
            <circle cx="50" cy="50" r="${r}" fill="none" stroke="#f1f5f9" stroke-width="${strokeW}" />
            ${circles}
          </svg>
          <div style="position: absolute; inset: 0; display: flex; flex-direction: column; align-items: center; justify-content: center; text-align: center; pointer-events: none;">
            <span style="font-size: 8px; font-weight: bold; color: #64748b;">الأطراف</span>
            <span style="font-size: 9px; font-weight: 900; font-family: monospace; color: #0f172a;">100%</span>
          </div>
        </div>
      </div>

      <!-- Explanatory Breakdown Below with Full Width & No Text Wrapping -->
      <div style="background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 8px 10px;">
        ${rowsHtml}
      </div>
    </div>
  `;
}

/**
 * Generates an Executive Chart for Debts & Obligations Distribution (Workers, Employees, Suppliers)
 * Positioned with the Chart at top and full-width explanatory breakdown below without text wrapping.
 */
export function generateDebtsDistributionChart(options: {
  workerDebt: number;
  employeeDebt: number;
  supplierDebt: number;
  currency: string;
}): string {
  const { workerDebt, employeeDebt, supplierDebt, currency } = options;
  const total = workerDebt + employeeDebt + supplierDebt;

  if (total <= 0) {
    return `
      <div style="display: flex; flex-direction: column; align-items: center; justify-content: center; height: 160px; color: #15803d; background: #f0fdf4; border-radius: 6px; border: 1px solid #bbf7d0; text-align: center; padding: 12px;">
        <span style="font-size: 24px; margin-bottom: 6px;">✅</span>
        <span style="font-weight: 800; font-size: 11px;">لا توجد أي ديون أو التزامات مستحقة مسجلة</span>
        <span style="font-size: 9px; color: #166534; margin-top: 4px;">كافة الحسابات المالية للمشروع مستوفاة وخالصة (0 ${currency})</span>
      </div>
    `;
  }

  const debts = [
    { key: 'worker', label: '👷 ديون ومستحقات العمال', val: workerDebt, color: '#d97706' },
    { key: 'employee', label: '👔 ديون ومستحقات الموظفين', val: employeeDebt, color: '#8b5cf6' },
    { key: 'supplier', label: '🚚 ديون ومستحقات الموردين', val: supplierDebt, color: '#e11d48' }
  ];

  const size = 86;
  const r = 31;
  const strokeW = 16;
  const circumference = 2 * Math.PI * r;
  let accumulatedOffset = 0;

  const circles = debts
    .filter(d => d.val > 0)
    .map(d => {
      const pct = (d.val / total) * 100;
      const strokeDasharray = `${(pct / 100) * circumference} ${circumference}`;
      const strokeDashoffset = -accumulatedOffset;
      accumulatedOffset += (pct / 100) * circumference;

      return `
        <circle
          cx="50"
          cy="50"
          r="${r}"
          fill="none"
          stroke="${d.color}"
          stroke-width="${strokeW}"
          stroke-dasharray="${strokeDasharray}"
          stroke-dashoffset="${strokeDashoffset}"
        />
      `;
    })
    .join('');

  const rowsHtml = debts.map(d => {
    const pct = total > 0 ? ((d.val / total) * 100).toFixed(1) : '0.0';
    return `
      <div style="margin-bottom: 4.5px;">
        <div style="display: flex; justify-content: space-between; align-items: center; font-size: 9.5px; margin-bottom: 2px; white-space: nowrap;">
          <div style="display: flex; align-items: center; gap: 5px; white-space: nowrap;">
            <span style="display: inline-block; width: 7px; height: 7px; border-radius: 50%; background-color: ${d.color}; flex-shrink: 0;"></span>
            <span style="color: #334155; font-weight: bold; white-space: nowrap;">${d.label}</span>
          </div>
          <div style="display: flex; align-items: center; gap: 6px; white-space: nowrap;">
            <span style="font-family: monospace; font-weight: bold; color: ${d.color}; font-size: 9.5px; white-space: nowrap;">${formatCurrency(d.val, currency)}</span>
            <span style="font-size: 8.5px; color: #334155; font-weight: bold; background: #ffffff; border: 1px solid #cbd5e1; padding: 1px 4px; border-radius: 3px; min-width: 38px; text-align: center; font-family: monospace; white-space: nowrap;">${pct}%</span>
          </div>
        </div>
        <div style="width: 100%; height: 3.5px; background-color: #e2e8f0; border-radius: 2px; overflow: hidden;">
          <div style="width: ${pct}%; height: 100%; background-color: ${d.color}; border-radius: 2px;"></div>
        </div>
      </div>
    `;
  }).join('');

  return `
    <div style="display: flex; flex-direction: column; align-items: stretch; gap: 8px;">
      <!-- Chart on Top -->
      <div style="display: flex; justify-content: center; align-items: center; padding: 2px 0;">
        <div style="position: relative; width: ${size}px; height: ${size}px;">
          <svg viewBox="0 0 100 100" width="${size}" height="${size}" style="transform: rotate(-90deg); overflow: visible;">
            <circle cx="50" cy="50" r="${r}" fill="none" stroke="#f1f5f9" stroke-width="${strokeW}" />
            ${circles}
          </svg>
          <div style="position: absolute; inset: 0; display: flex; flex-direction: column; align-items: center; justify-content: center; text-align: center; pointer-events: none;">
            <span style="font-size: 7.5px; font-weight: bold; color: #b45309;">إجمالي الديون</span>
            <span style="font-size: 8.5px; font-weight: 900; font-family: monospace; color: #b91c1c;">${formatCurrency(total, currency)}</span>
          </div>
        </div>
      </div>

      <!-- Explanatory Breakdown Below with Full Width & No Text Wrapping -->
      <div style="background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 8px 10px;">
        ${rowsHtml}
        <div style="border-top: 1px dashed #cbd5e1; margin-top: 5px; padding-top: 4px; display: flex; justify-content: space-between; align-items: center; font-size: 9.5px; font-weight: 800; white-space: nowrap;">
          <span style="color: #475569;">إجمالي الالتزامات المستحقة:</span>
          <span style="color: #b91c1c; font-family: monospace;">${formatCurrency(total, currency)}</span>
        </div>
      </div>
    </div>
  `;
}



