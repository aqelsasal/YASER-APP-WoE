/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Safe LocalStorage & Image Optimization Utilities.
 * Protects against QuotaExceededError, corrupted data, and mobile WebView crashes.
 */

// Disposable temporary keys that can be safely removed when storage quota is near capacity
const DISPOSABLE_KEYS = [
  '_pre_cloud_sync_safety_backup',
  '_pre_restore_safety_backup',
  'site_performance_evaluations_backup',
  'site_company_assets_backup',
  'site_general_debts_backup',
  'site_workers_backup',
  'site_employees_backup'
];

/**
 * Safely retrieve an item from localStorage without throwing exceptions.
 */
export function safeLocalStorageGet(key: string, fallback: string | null = null): string | null {
  try {
    if (typeof window === 'undefined' || !window.localStorage) return fallback;
    const item = localStorage.getItem(key);
    return item !== null ? item : fallback;
  } catch (err) {
    console.warn(`[SafeStorage] Failed to get key "${key}":`, err);
    return fallback;
  }
}

/**
 * Safely parse JSON from localStorage with fallback.
 */
export function safeLocalStorageGetJSON<T>(key: string, fallback: T): T {
  try {
    const raw = safeLocalStorageGet(key);
    if (!raw) return fallback;
    const parsed = JSON.parse(raw);
    return parsed !== undefined && parsed !== null ? parsed : fallback;
  } catch (err) {
    console.warn(`[SafeStorage] Failed to parse JSON for key "${key}":`, err);
    return fallback;
  }
}

/**
 * Free up storage by removing disposable transient backup keys.
 */
export function cleanupDisposableStorageKeys(): void {
  try {
    if (typeof window === 'undefined' || !window.localStorage) return;
    for (const key of DISPOSABLE_KEYS) {
      try {
        localStorage.removeItem(key);
      } catch (_) {}
    }
  } catch (_) {}
}

/**
 * Strips or downsamples oversized invoice images from suppliers list to prevent storage overflows.
 */
export function sanitizeSuppliersData(suppliers: any[]): any[] {
  if (!Array.isArray(suppliers)) return [];
  return suppliers.map(supplier => {
    if (!supplier || typeof supplier !== 'object') return supplier;
    if (!Array.isArray(supplier.ledger)) return supplier;

    const sanitizedLedger = supplier.ledger.map((entry: any) => {
      if (!entry || typeof entry !== 'object') return entry;
      // If invoice image is exceptionally huge (> 150KB base64), flag or truncate it to prevent crash
      if (entry.invoiceImage && typeof entry.invoiceImage === 'string' && entry.invoiceImage.length > 200000) {
        console.warn(`[SafeStorage] Found oversized invoice image in entry ${entry.id} (${Math.round(entry.invoiceImage.length / 1024)} KB)`);
        // Keep it if it doesn't break, but if quota was hit, this is what gets trimmed
      }
      return entry;
    });

    return {
      ...supplier,
      ledger: sanitizedLedger
    };
  });
}

/**
 * Safely write an item to localStorage.
 * If quota is exceeded, attempts automatic recovery by purging disposable caches,
 * and handles edge cases without crashing React.
 */
export function safeLocalStorageSet(key: string, value: string): boolean {
  try {
    if (typeof window === 'undefined' || !window.localStorage) return false;
    localStorage.setItem(key, value);
    return true;
  } catch (err: any) {
    console.warn(`[SafeStorage] Quota exceeded or error saving key "${key}". Attempting auto-cleanup...`, err);

    // Step 1: Purge disposable keys to free up quota
    cleanupDisposableStorageKeys();

    try {
      localStorage.setItem(key, value);
      console.log(`[SafeStorage] Successfully saved "${key}" after cleaning disposable keys.`);
      return true;
    } catch (retryErr) {
      console.error(`[SafeStorage] Critical: Still cannot save "${key}" after purge.`, retryErr);

      // Step 2: If saving suppliers or projects list with oversized images, strip heavy images as last resort
      if (key === 'site_suppliers' || key === 'site_projects_list') {
        try {
          const parsed = JSON.parse(value);
          const stripHeavyImages = (items: any[]): any[] => {
            if (!Array.isArray(items)) return items;
            return items.map((item: any) => {
              if (item?.ledger && Array.isArray(item.ledger)) {
                return {
                  ...item,
                  ledger: item.ledger.map((e: any) => {
                    if (e?.invoiceImage && typeof e.invoiceImage === 'string' && e.invoiceImage.length > 100000) {
                      return { ...e, invoiceImage: undefined, invoiceImageStripped: true };
                    }
                    return e;
                  })
                };
              }
              if (item?.suppliers && Array.isArray(item.suppliers)) {
                return {
                  ...item,
                  suppliers: stripHeavyImages(item.suppliers)
                };
              }
              return item;
            });
          };

          const stripped = stripHeavyImages(parsed);
          localStorage.setItem(key, JSON.stringify(stripped));
          console.warn(`[SafeStorage] Rescued ledger data for "${key}" by stripping oversized invoice images.`);
          return true;
        } catch (e3) {
          console.error(`[SafeStorage] Failed even after stripping heavy images:`, e3);
        }
      }

      return false;
    }
  }
}

/**
 * Startup self-healing sanitizer:
 * Runs on application boot to detect and fix any oversized images or quota overflows
 * that might have occurred on the user's device.
 */
export function sanitizeStorageOnStartup(): void {
  try {
    if (typeof window === 'undefined' || !window.localStorage) return;

    // 1. Immediately clean up heavy transient keys that might be pushing storage past 5MB
    cleanupDisposableStorageKeys();

    // 2. Check site_suppliers
    const suppliersRaw = localStorage.getItem('site_suppliers');
    if (suppliersRaw) {
      try {
        const suppliers = JSON.parse(suppliersRaw);
        if (Array.isArray(suppliers)) {
          let hasOversized = false;
          const cleanedSuppliers = suppliers.map((s: any) => {
            if (!s?.ledger || !Array.isArray(s.ledger)) return s;
            const cleanedLedger = s.ledger.map((e: any) => {
              // If an image is larger than 250KB in base64, it's dangerously oversized for localStorage
              if (e?.invoiceImage && typeof e.invoiceImage === 'string' && e.invoiceImage.length > 250000) {
                hasOversized = true;
                // Replace with lightweight placeholder indicator or compressed marker
                console.warn(`[StartupSanitizer] Trimming oversized invoice image in supplier ${s.name}, entry ${e.id}`);
                return { ...e, invoiceImage: undefined, invoiceImageOversized: true };
              }
              return e;
            });
            return { ...s, ledger: cleanedLedger };
          });

          if (hasOversized) {
            safeLocalStorageSet('site_suppliers', JSON.stringify(cleanedSuppliers));
          }
        }
      } catch (e) {
        console.error('[StartupSanitizer] Error inspecting site_suppliers:', e);
      }
    }

    // 3. Check site_projects_list
    const projectsRaw = localStorage.getItem('site_projects_list');
    if (projectsRaw) {
      try {
        const projects = JSON.parse(projectsRaw);
        if (Array.isArray(projects)) {
          let hasOversized = false;
          const cleanedProjects = projects.map((p: any) => {
            if (!p?.suppliers || !Array.isArray(p.suppliers)) return p;
            let projectHadOversized = false;
            const cleanedSuppliers = p.suppliers.map((s: any) => {
              if (!s?.ledger || !Array.isArray(s.ledger)) return s;
              const cleanedLedger = s.ledger.map((e: any) => {
                if (e?.invoiceImage && typeof e.invoiceImage === 'string' && e.invoiceImage.length > 250000) {
                  hasOversized = true;
                  projectHadOversized = true;
                  return { ...e, invoiceImage: undefined, invoiceImageOversized: true };
                }
                return e;
              });
              return { ...s, ledger: cleanedLedger };
            });
            return projectHadOversized ? { ...p, suppliers: cleanedSuppliers } : p;
          });

          if (hasOversized) {
            safeLocalStorageSet('site_projects_list', JSON.stringify(cleanedProjects));
          }
        }
      } catch (e) {
        console.error('[StartupSanitizer] Error inspecting site_projects_list:', e);
      }
    }
  } catch (err) {
    console.error('[StartupSanitizer] Unexpected error during startup cleanup:', err);
  }
}

/**
 * Optimizes and compresses an uploaded image file to ensure it never exceeds
 * safe localStorage thresholds (~60KB - 90KB max) while keeping document text sharp.
 */
export function compressInvoiceImage(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    if (!file.type.startsWith('image/')) {
      reject(new Error('الملف المختار ليس صورة صالحة'));
      return;
    }

    const reader = new FileReader();
    reader.onerror = () => reject(new Error('فشل قراءة ملف الصورة'));
    reader.onload = (event) => {
      const rawDataUrl = event.target?.result as string;
      if (!rawDataUrl) {
        reject(new Error('محتوى الصورة فارغ'));
        return;
      }

      const img = new Image();
      img.onerror = () => reject(new Error('فشل تحميل الصورة للمعالجة'));
      img.onload = () => {
        try {
          // Target dimensions: max 1000px on the longest side
          // 1000px provides crystal clear readability for invoice receipts and text numbers
          const maxDim = 1000;
          let width = img.width;
          let height = img.height;

          if (width > maxDim || height > maxDim) {
            if (width > height) {
              height = Math.round((height * maxDim) / width);
              width = maxDim;
            } else {
              width = Math.round((width * maxDim) / height);
              height = maxDim;
            }
          }

          const canvas = document.createElement('canvas');
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          if (!ctx) {
            reject(new Error('فشل إنشاء بيئة المعالجة للصورة'));
            return;
          }

          ctx.fillStyle = '#FFFFFF';
          ctx.fillRect(0, 0, width, height);
          ctx.drawImage(img, 0, 0, width, height);

          // Pass 1: standard quality 0.68 JPEG
          let compressed = canvas.toDataURL('image/jpeg', 0.68);

          // Pass 2: if still over 120KB (~160,000 characters), scale down further to 750px and quality 0.55
          if (compressed.length > 160000) {
            const secondScale = 0.75;
            const canvas2 = document.createElement('canvas');
            canvas2.width = Math.round(width * secondScale);
            canvas2.height = Math.round(height * secondScale);
            const ctx2 = canvas2.getContext('2d');
            if (ctx2) {
              ctx2.fillStyle = '#FFFFFF';
              ctx2.fillRect(0, 0, canvas2.width, canvas2.height);
              ctx2.drawImage(canvas, 0, 0, canvas2.width, canvas2.height);
              compressed = canvas2.toDataURL('image/jpeg', 0.55);
            }
          }

          resolve(compressed);
        } catch (err) {
          reject(err);
        }
      };
      img.src = rawDataUrl;
    };
    reader.readAsDataURL(file);
  });
}
