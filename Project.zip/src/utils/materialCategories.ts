/**
 * Supplier Material Categories Utility
 * Manages standard and custom categories for supplier materials,
 * handles persistent storage, color assignment, and synchronization across
 * modals, tables, and reports.
 */

import { useState, useEffect, useCallback } from 'react';
import { SUPPLIER_MATERIAL_CATEGORIES } from '../types';
import { MATERIAL_CATEGORY_COLORS } from './reportCharts';

const CUSTOM_CATEGORIES_KEY = 'custom_supplier_material_categories';
const EXCLUDED_CATEGORIES_KEY = 'excluded_supplier_material_categories';
const CATEGORY_COLORS_KEY = 'custom_supplier_material_category_colors';
const EVENT_NAME = 'supplierMaterialCategoriesChanged';

// Dynamic vibrant color palette for newly created categories
export const DYNAMIC_PALETTE = [
  '#0284c7', // Sky
  '#b91c1c', // Deep Red
  '#059669', // Emerald
  '#d97706', // Amber
  '#7c3aed', // Purple
  '#ea580c', // Orange
  '#4f46e5', // Indigo
  '#06b6d4', // Cyan
  '#ec4899', // Pink
  '#14b8a6', // Teal
  '#eab308', // Yellow
  '#78716c', // Stone
  '#64748b', // Slate
  '#a855f7', // Violet
  '#10b981', // Green
  '#84cc16', // Lime
  '#f43f5e', // Rose
  '#6366f1', // Indigo light
  '#0891b2', // Deep cyan
  '#c026d3'  // Fuchsia
];

/**
 * Get custom categories saved by the user in localStorage
 */
export function getCustomMaterialCategories(): string[] {
  try {
    const raw = localStorage.getItem(CUSTOM_CATEGORIES_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed)) {
      return parsed.filter(c => typeof c === 'string' && c.trim().length > 0).map(c => c.trim());
    }
  } catch (e) {
    console.error('Failed to parse custom material categories from storage:', e);
  }
  return [];
}

/**
 * Save custom categories to localStorage and notify listeners
 */
export function saveCustomMaterialCategories(categories: string[]): void {
  try {
    const unique = Array.from(new Set(categories.map(c => c.trim()).filter(Boolean)));
    localStorage.setItem(CUSTOM_CATEGORIES_KEY, JSON.stringify(unique));
    window.dispatchEvent(new CustomEvent(EVENT_NAME, { detail: { categories: unique } }));
  } catch (e) {
    console.error('Failed to save custom material categories:', e);
  }
}

/**
 * Get excluded default categories
 */
export function getExcludedMaterialCategories(): string[] {
  try {
    const raw = localStorage.getItem(EXCLUDED_CATEGORIES_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed)) {
      return parsed.filter(c => typeof c === 'string' && c.trim().length > 0).map(c => c.trim());
    }
  } catch (e) {
    console.error('Failed to parse excluded categories:', e);
  }
  return [];
}

/**
 * Save excluded categories to localStorage
 */
export function saveExcludedMaterialCategories(excluded: string[]): void {
  try {
    localStorage.setItem(EXCLUDED_CATEGORIES_KEY, JSON.stringify(excluded));
  } catch (e) {
    console.error('Failed to save excluded categories:', e);
  }
}

/**
 * Get map of custom assigned colors for categories
 */
export function getCustomCategoryColors(): Record<string, string> {
  try {
    const raw = localStorage.getItem(CATEGORY_COLORS_KEY);
    if (!raw) return {};
    const parsed = JSON.parse(raw);
    if (typeof parsed === 'object' && parsed !== null) {
      return parsed;
    }
  } catch (e) {
    console.error('Failed to parse custom category colors:', e);
  }
  return {};
}

/**
 * Save custom assigned colors to localStorage
 */
export function saveCustomCategoryColors(colors: Record<string, string>): void {
  try {
    localStorage.setItem(CATEGORY_COLORS_KEY, JSON.stringify(colors));
  } catch (e) {
    console.error('Failed to save custom category colors:', e);
  }
}

/**
 * Generate a consistent, deterministic color for any category name
 */
export function getMaterialCategoryColor(category: string): string {
  if (!category) return '#64748b';
  const trimmed = category.trim();

  // 1. Check custom saved colors
  const customColors = getCustomCategoryColors();
  if (customColors[trimmed]) return customColors[trimmed];

  // 2. Check predefined system colors
  if (MATERIAL_CATEGORY_COLORS[trimmed]) {
    return MATERIAL_CATEGORY_COLORS[trimmed];
  }

  // 3. Deterministic hash from name into DYNAMIC_PALETTE
  let hash = 0;
  for (let i = 0; i < trimmed.length; i++) {
    hash = (hash << 5) - hash + trimmed.charCodeAt(i);
    hash |= 0;
  }
  const index = Math.abs(hash) % DYNAMIC_PALETTE.length;
  return DYNAMIC_PALETTE[index];
}

/**
 * Get all available categories (predefined + custom + any from current data)
 */
export function getAllMaterialCategories(additionalCategories: string[] = []): string[] {
  const custom = getCustomMaterialCategories();
  const excluded = getExcludedMaterialCategories();
  const set = new Set<string>();

  // Add default categories if not excluded
  SUPPLIER_MATERIAL_CATEGORIES.forEach(c => {
    if (!excluded.includes(c.trim())) {
      set.add(c.trim());
    }
  });

  // Add custom categories
  custom.forEach(c => set.add(c.trim()));

  // Add any categories found in the provided data
  additionalCategories.forEach(c => {
    if (c && typeof c === 'string' && c.trim()) {
      set.add(c.trim());
    }
  });

  return Array.from(set);
}

/**
 * Add a new custom category
 */
export function addCustomMaterialCategory(
  name: string,
  color?: string
): { success: boolean; message?: string; category?: string } {
  const trimmed = name.trim();
  if (!trimmed) {
    return { success: false, message: 'الرجاء إدخال اسم الفئة.' };
  }

  if (trimmed.length > 50) {
    return { success: false, message: 'اسم الفئة يجب ألا يتجاوز 50 حرفاً.' };
  }

  const allCurrent = getAllMaterialCategories();
  const exists = allCurrent.some(c => c.toLowerCase() === trimmed.toLowerCase());
  if (exists) {
    return { success: false, message: 'هذه الفئة موجودة مسبقاً في القائمة.', category: trimmed };
  }

  // If it was in excluded, un-exclude it
  const excluded = getExcludedMaterialCategories();
  if (excluded.some(c => c.toLowerCase() === trimmed.toLowerCase())) {
    saveExcludedMaterialCategories(excluded.filter(c => c.toLowerCase() !== trimmed.toLowerCase()));
  }

  const custom = getCustomMaterialCategories();
  const updated = [...custom, trimmed];
  saveCustomMaterialCategories(updated);

  if (color) {
    const colors = getCustomCategoryColors();
    colors[trimmed] = color;
    saveCustomCategoryColors(colors);
  }

  return { success: true, category: trimmed };
}

/**
 * Edit an existing category (custom or default)
 */
export function editCustomMaterialCategory(
  oldName: string,
  newName: string,
  color?: string
): { success: boolean; message?: string } {
  const trimmedOld = oldName.trim();
  const trimmedNew = newName.trim();

  if (!trimmedNew) {
    return { success: false, message: 'الرجاء إدخال الاسم الجديد للفئة.' };
  }

  if (trimmedNew.length > 50) {
    return { success: false, message: 'اسم الفئة يجب ألا يتجاوز 50 حرفاً.' };
  }

  const allCurrent = getAllMaterialCategories();
  if (trimmedOld.toLowerCase() !== trimmedNew.toLowerCase()) {
    if (allCurrent.some(c => c.toLowerCase() === trimmedNew.toLowerCase())) {
      return { success: false, message: 'يوجد فئة أخرى بنفس هذا الاسم.' };
    }
  }

  // Handle color update
  const colors = getCustomCategoryColors();
  const currentColor = color || colors[trimmedOld] || getMaterialCategoryColor(trimmedOld);
  if (trimmedOld !== trimmedNew && colors[trimmedOld]) {
    delete colors[trimmedOld];
  }
  colors[trimmedNew] = currentColor;
  saveCustomCategoryColors(colors);

  // If oldName was a default category, exclude it and add newName to custom
  const isDefault = SUPPLIER_MATERIAL_CATEGORIES.some(c => c.toLowerCase() === trimmedOld.toLowerCase());
  if (isDefault) {
    const excluded = getExcludedMaterialCategories();
    if (!excluded.includes(trimmedOld)) {
      saveExcludedMaterialCategories([...excluded, trimmedOld]);
    }
  }

  const custom = getCustomMaterialCategories();
  const filtered = custom.filter(c => c.toLowerCase() !== trimmedOld.toLowerCase());
  const updated = [...filtered, trimmedNew];
  saveCustomMaterialCategories(updated);

  return { success: true };
}

/**
 * Remove a category (custom or default)
 */
export function deleteCustomMaterialCategory(name: string): { success: boolean; message?: string } {
  const trimmed = name.trim();
  const allCurrent = getAllMaterialCategories();
  if (allCurrent.length <= 1) {
    return { success: false, message: 'يجب الإبقاء على فئة واحدة على الأقل في النظام.' };
  }

  const isDefault = SUPPLIER_MATERIAL_CATEGORIES.some(c => c.toLowerCase() === trimmed.toLowerCase());
  if (isDefault) {
    const excluded = getExcludedMaterialCategories();
    if (!excluded.includes(trimmed)) {
      saveExcludedMaterialCategories([...excluded, trimmed]);
    }
  }

  const custom = getCustomMaterialCategories();
  const filtered = custom.filter(c => c.toLowerCase() !== trimmed.toLowerCase());
  saveCustomMaterialCategories(filtered);

  const colors = getCustomCategoryColors();
  if (colors[trimmed]) {
    delete colors[trimmed];
    saveCustomCategoryColors(colors);
  }

  return { success: true };
}

/**
 * Reset material categories to defaults
 */
export function resetMaterialCategories(): void {
  saveExcludedMaterialCategories([]);
  saveCustomMaterialCategories([]);
  saveCustomCategoryColors({});
  window.dispatchEvent(new CustomEvent(EVENT_NAME, { detail: { categories: SUPPLIER_MATERIAL_CATEGORIES } }));
}

/**
 * React hook to access and synchronize material categories across components
 */
export function useSupplierMaterialCategories(additionalCategories: string[] = []) {
  const [categories, setCategories] = useState<string[]>(() => getAllMaterialCategories(additionalCategories));
  const [customCategories, setCustomCategories] = useState<string[]>(() => getCustomMaterialCategories());

  const refresh = useCallback(() => {
    setCategories(getAllMaterialCategories(additionalCategories));
    setCustomCategories(getCustomMaterialCategories());
  }, [additionalCategories]);

  useEffect(() => {
    refresh();

    const handleUpdate = () => {
      refresh();
    };

    window.addEventListener(EVENT_NAME, handleUpdate);
    window.addEventListener('storage', handleUpdate);

    return () => {
      window.removeEventListener(EVENT_NAME, handleUpdate);
      window.removeEventListener('storage', handleUpdate);
    };
  }, [refresh]);

  const addCategory = useCallback((name: string, color?: string) => {
    const res = addCustomMaterialCategory(name, color);
    if (res.success) {
      refresh();
    }
    return res;
  }, [refresh]);

  const editCategory = useCallback((oldName: string, newName: string, color?: string) => {
    const res = editCustomMaterialCategory(oldName, newName, color);
    if (res.success) {
      refresh();
    }
    return res;
  }, [refresh]);

  const deleteCategory = useCallback((name: string) => {
    const res = deleteCustomMaterialCategory(name);
    if (res.success) {
      refresh();
    }
    return res;
  }, [refresh]);

  const resetDefaults = useCallback(() => {
    resetMaterialCategories();
    refresh();
  }, [refresh]);

  return {
    categories,
    customCategories,
    addCategory,
    editCategory,
    deleteCategory,
    resetDefaults,
    getCategoryColor: getMaterialCategoryColor,
    refresh
  };
}
