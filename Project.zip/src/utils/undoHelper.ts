/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { UndoItem, UndoCategory, UndoActionType } from '../types/undo';

export function getTimeAgoArabic(dateStr: string): string {
  try {
    const diffMs = Date.now() - new Date(dateStr).getTime();
    const diffSec = Math.floor(diffMs / 1000);
    if (diffSec < 10) return 'الآن';
    if (diffSec < 60) return `منذ ${diffSec} ثانية`;
    const diffMin = Math.floor(diffSec / 60);
    if (diffMin === 1) return 'منذ دقيقة';
    if (diffMin === 2) return 'منذ دقيقتين';
    if (diffMin <= 10) return `منذ ${diffMin} دقائق`;
    if (diffMin < 60) return `منذ ${diffMin} دقيقة`;
    const diffHours = Math.floor(diffMin / 60);
    if (diffHours === 1) return 'منذ ساعة';
    if (diffHours === 2) return 'منذ ساعتين';
    if (diffHours <= 10) return `منذ ${diffHours} ساعات`;
    if (diffHours < 24) return `منذ ${diffHours} ساعة`;
    const diffDays = Math.floor(diffHours / 24);
    if (diffDays === 1) return 'منذ يوم';
    if (diffDays === 2) return 'منذ يومين';
    return `منذ ${diffDays} أيام`;
  } catch {
    return 'مؤخراً';
  }
}

export function buildUndoItem({
  category,
  categoryLabel,
  actionType,
  actionLabel,
  title,
  description,
  details = [],
  projectId,
  projectName,
  payload
}: {
  category: UndoCategory;
  categoryLabel: string;
  actionType: UndoActionType;
  actionLabel: string;
  title: string;
  description?: string;
  details?: { label: string; value: string }[];
  projectId?: string;
  projectName?: string;
  payload: {
    type: string;
    data: any;
    extra?: any;
  };
}): UndoItem {
  const now = new Date();
  const timestamp = now.toISOString();
  const hours = now.getHours();
  const minutes = String(now.getMinutes()).padStart(2, '0');
  const ampm = hours >= 12 ? 'م' : 'ص';
  const hour12 = hours % 12 || 12;
  const formattedTime = `${hour12}:${minutes} ${ampm}`;

  return {
    id: 'undo_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7),
    timestamp,
    formattedTime,
    timeAgo: 'الآن',
    category,
    categoryLabel,
    actionType,
    actionLabel,
    title,
    description,
    details,
    projectId,
    projectName,
    payload
  };
}
