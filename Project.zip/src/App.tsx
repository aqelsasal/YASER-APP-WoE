/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { 
  LayoutDashboard, 
  TrendingUp, 
  Users, 
  Truck, 
  Wallet,
  Menu,
  X,
  Calculator,
  Printer,
  FileText,
  FileSpreadsheet,
  Download,
  Briefcase,
  Coins,
  LogOut,
  Database,
  Lock,
  Building2,
  ArrowRight,
  Settings,
  Landmark,
  Award,
  Star,
  Boxes,
  Sun,
  Moon,
  RotateCcw,
  MapPin,
  Mail,
  Globe,
  Smartphone,
  Phone
} from 'lucide-react';

// Components
import Dashboard from './components/Dashboard';
import DailyExpenses from './components/DailyExpenses';
import Workers from './components/Workers';
import Employees from './components/Employees';
import Suppliers from './components/Suppliers';
import Budget from './components/Budget';
import FinancialReports from './components/FinancialReports';
import Debts from './components/Debts';
import GeneralDebts from './components/GeneralDebts';
import BackupRestore from './components/BackupRestore';
import ProjectsHub from './components/ProjectsHub';
import MainApplicationHub from './components/MainApplicationHub';
import PerformanceEvaluations from './components/PerformanceEvaluations';
import { CompanyAssets } from './components/CompanyAssets';
import ContractBOQ from './components/ContractBOQ';
import AttributionBadge from './components/AttributionBadge';
import BottomNavigation from './components/BottomNavigation';
import SettingsModal from './components/SettingsModal';
import { AndroidInstallModal } from './components/AndroidInstallModal';
import { OfflineIndicator } from './components/OfflineIndicator';
import AppHeaderDrawerMenu from './components/AppHeaderDrawerMenu';
import AppInfoModal from './components/AppInfoModal';
import LocalStorageBackupModal from './components/LocalStorageBackupModal';
import UndoModal from './components/UndoModal';
import { UndoItem } from './types/undo';
import { buildUndoItem, getTimeAgoArabic } from './utils/undoHelper';
import { GlobalModalScrollIndicator } from './components/DraggableScrollIndicator';
import { useBodyScrollLock } from './utils/modalScrollLock';
import { safeLocalStorageGet, safeLocalStorageSet, sanitizeSuppliersData } from './utils/safeStorage';

// Types & Helpers
import { COMPANY_LOGO_BASE64 } from './companyLogo';
import { Project, Expense, Worker, Employee, Supplier, BudgetItem, LedgerEntry, NutritionPeriod, calculateDaysOfWork, formatDateArabic, getTodayDateString, ensureDateInFilename, syncWorkerNutritionLedger, syncEmployeeNutritionLedger, syncEmployeeWageLedger, syncEmployeeAllLedgers, GeneralDebt, GeneralDebtPayment, GeneralDebtEntry, PerformanceEvaluation, CompanyAsset, CompanyAssetMovement, ContractItem } from './types';

// Seed Initial Data if empty so the user starts with a realistic sandbox
const SEED_BUDGET: BudgetItem[] = [
  {
    id: 'bud_seed_1',
    date: '2026-06-01',
    amount: 15000000,
    description: 'رأس مال المشروع المخصص من المستثمر دفعة أولى',
    notes: 'تم استلام المبلغ نقداً في الموقع'
  }
];

const SEED_WORKERS: Worker[] = [
  {
    id: 'worker_seed_1',
    name: 'أحمد جاسم كريم',
    profession: 'خلفة بناء طابوق',
    startDate: '2026-06-01',
    endDate: '2026-06-30',
    ledger: [
      {
        id: 'wled_seed_1',
        date: '2026-06-01',
        amountOnHim: 0,
        amountForHim: 1200000,
        description: 'أجور مستحقة عن النصف الأول من الشهر',
        notes: 'محتسب على أساس 15 يوم عمل'
      },
      {
        id: 'wled_seed_2',
        date: '2026-06-10',
        amountOnHim: 150000,
        amountForHim: 0,
        description: 'سلفة نقدية طارئة',
        notes: 'تم التسليم باليد'
      }
    ]
  },
  {
    id: 'worker_seed_2',
    name: 'سعدون أبو ميثم',
    profession: 'خلفة نجار مسلح',
    startDate: '2026-06-05',
    endDate: '2026-06-25',
    ledger: [
      {
        id: 'wled_seed_3',
        date: '2026-06-15',
        amountOnHim: 0,
        amountForHim: 900000,
        description: 'أجر متفق عليه عن صبة السقف الأول',
        notes: 'تم إنجاز الصب بنجاح'
      }
    ]
  }
];

const SEED_EMPLOYEES: Employee[] = [
  {
    id: 'emp_fikri',
    name: 'فكري',
    profession: 'مهندس',
    startDate: '2026-05-01',
    endDate: '',
    dailyWage: 0,
    createdBy: 'إدارة المشروع',
    ledger: [
      {
        id: 'eled_fikri_1',
        date: '2026-05-10',
        amountOnHim: 0,
        amountForHim: 200000,
        description: 'مستحقات أجر وإشراف هندسي وتصميم خرائط خرسانية',
        notes: 'مستحقات هندسية مرحلة من نافذة العمال',
        currency: 'YER',
        createdBy: 'إدارة المشروع'
      },
      {
        id: 'eled_fikri_2',
        date: '2026-06-01',
        amountOnHim: 0,
        amountForHim: 143275,
        description: 'مستحقات أجر وإشراف هندسي وتدقيق مقاسات التنفيذ',
        notes: 'مستحقات إضافية معتمدة',
        currency: 'YER',
        createdBy: 'إدارة المشروع'
      },
      {
        id: 'eled_fikri_3',
        date: '2026-05-18',
        amountOnHim: 250000,
        amountForHim: 0,
        description: 'سلفة نقدية أولى تسليم موقع',
        notes: 'سند صرف نقدي من الصندوق',
        currency: 'YER',
        createdBy: 'المحاسب'
      },
      {
        id: 'eled_fikri_4',
        date: '2026-06-05',
        amountOnHim: 175000,
        amountForHim: 0,
        description: 'سلفة نقدية ثانية عبر حوالة مالية',
        notes: 'سند صرف رقم 108',
        currency: 'YER',
        createdBy: 'المحاسب'
      },
      {
        id: 'eled_fikri_5',
        date: '2026-06-18',
        amountOnHim: 100000,
        amountForHim: 0,
        description: 'سلفة نقدية ثالثة ومصاريف شخصية',
        notes: 'مقيدة على حسابه الشخصي',
        currency: 'YER',
        createdBy: 'المحاسب'
      }
    ]
  }
];

const SEED_SUPPLIERS: Supplier[] = [
  {
    id: 'supplier_seed_1',
    name: 'شركة الرافدين للإسمنت والحديد',
    materialType: 'إسمنت مقاوم وحديد تسليح',
    ledger: [
      {
        id: 'sled_seed_1',
        date: '2026-06-02',
        amountOnHim: 0,
        amountForHim: 4500000,
        description: 'توريد 10 طن إسمنت مقاوم عراقي',
        notes: 'سعر الطن 450 ألف'
      },
      {
        id: 'sled_seed_2',
        date: '2026-06-03',
        amountOnHim: 3000000,
        amountForHim: 0,
        description: 'دفعة نقدية أولى تسديد للمواد المستلمة',
        notes: 'تم التحويل بموجب وصل استلام رقم 4829'
      }
    ]
  }
];

const SEED_EXPENSES: Expense[] = [
  {
    id: 'exp_seed_1',
    date: '2026-06-03',
    amount: 3000000,
    description: 'تسديد دفعة لشركة الرافدين للإسمنت والحديد',
    notes: 'تم ترحيلها لحساب المورد تلقائياً',
    recipientId: 'supplier_seed_1',
    recipientType: 'supplier',
    recipientName: 'شركة الرافدين للإسمنت والحديد'
  },
  {
    id: 'exp_seed_2',
    date: '2026-06-10',
    amount: 150000,
    description: 'سلفة نقدية طارئة - أحمد جاسم كريم',
    notes: 'تم ترحيلها لحساب العامل تلقائياً',
    recipientId: 'worker_seed_1',
    recipientType: 'worker',
    recipientName: 'أحمد جاسم كريم'
  },
  {
    id: 'exp_seed_fikri_1',
    date: '2026-06-06',
    amount: 100000,
    description: 'سلفة نقدية طارئة من الصندوق - فكري',
    notes: 'تم ترحيلها لحساب الموظف فكري تلقائياً',
    recipientId: 'emp_fikri',
    recipientType: 'employee',
    recipientName: 'فكري',
    currency: 'YER'
  },
  {
    id: 'exp_seed_fikri_2',
    date: '2026-06-15',
    amount: 150000,
    description: 'دفعة سلفة ثانية من الحساب - فكري',
    notes: 'حوالة مالية عبر الصراف - مرحلة لحساب الموظف فكري',
    recipientId: 'emp_fikri',
    recipientType: 'employee',
    recipientName: 'فكري',
    currency: 'YER'
  },
  {
    id: 'exp_seed_3',
    date: '2026-06-12',
    amount: 85000,
    description: 'شراء وقود للمولد الكهربائي والساحبات',
    notes: 'مصروفات تشغيلية عامة',
    recipientId: '',
    recipientType: 'none',
    recipientName: ''
  }
];

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('main_hub');

  // Automatic one-time cleanup on startup to ensure default user info if not set
  useEffect(() => {
    if (!localStorage.getItem('site_user_role')) {
      localStorage.setItem('site_user_role', 'owner');
    }
    if (!localStorage.getItem('site_user_name')) {
      localStorage.setItem('site_user_name', 'المهندس/ ياسر عقيل');
    }
  }, []);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'instant' });
  }, [activeTab]);

  // Auto scroll focused input elements into view above mobile soft keyboard
  useEffect(() => {
    const handleFocusIn = (e: FocusEvent) => {
      const target = e.target as HTMLElement;
      if (
        target &&
        (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.tagName === 'SELECT')
      ) {
        // Immediate scroll to center element in viewport
        target.scrollIntoView({
          behavior: 'smooth',
          block: 'center',
          inline: 'nearest'
        });

        // Secondary scroll after soft keyboard expansion on mobile browsers (280ms)
        setTimeout(() => {
          target.scrollIntoView({
            behavior: 'smooth',
            block: 'center',
            inline: 'nearest'
          });
        }, 280);
      }
    };

    document.addEventListener('focusin', handleFocusIn);
    return () => {
      document.removeEventListener('focusin', handleFocusIn);
    };
  }, []);
  const [mobileMenuOpen, setMobileMenuOpen] = useState<boolean>(false);
  const [showAppInfoModal, setShowAppInfoModal] = useState<boolean>(false);
  const [currency, setCurrency] = useState<string>(() => {
    return localStorage.getItem('site_currency') || 'YER';
  });

  // Collaborative Sharing States - Retrieve project from URL or from saved local project
  const [projectId, setProjectId] = useState<string | null>(() => {
    try {
      if (typeof window !== 'undefined' && window.location.search) {
        const urlParams = new URLSearchParams(window.location.search);
        const p = urlParams.get('project');
        if (p) return p;
      }
      const savedProjects = localStorage.getItem('site_projects_list');
      const activeId = localStorage.getItem('site_active_project_id');
      if (savedProjects) {
        const list: Project[] = JSON.parse(savedProjects);
        if (Array.isArray(list)) {
          const activeProj = list.find(p => p.id === activeId) || list[0];
          if (activeProj?.syncProjectId) {
            return activeProj.syncProjectId;
          }
        }
      }
    } catch (e) {}
    return null;
  });

  const [sharedRole, setSharedRole] = useState<'owner' | 'read' | 'add' | 'full'>(() => {
    try {
      if (typeof window !== 'undefined' && window.location.search) {
        const urlParams = new URLSearchParams(window.location.search);
        const role = urlParams.get('role') as 'owner' | 'read' | 'add' | 'full' | null;
        if (role) return role;
      }
    } catch (e) {}
    return (localStorage.getItem('site_user_role') as 'owner' | 'read' | 'add' | 'full') || 'owner';
  });

  const handleRestoreOwnerRole = () => {
    localStorage.setItem('site_user_role', 'owner');
    localStorage.setItem('site_user_name', 'المهندس/ ياسر عقيل');
    setUserName('المهندس/ ياسر عقيل');
    setSharedRole('owner');
    setProjectId(null);
    setPromptUserName(false);
    setIsSyncDisabled(false);
    // Remove syncProjectId from all local projects
    setProjects(prev => prev.map(p => ({ ...p, syncProjectId: null })));
    try {
      const savedProjects = localStorage.getItem('site_projects_list');
      if (savedProjects) {
        const list: Project[] = JSON.parse(savedProjects);
        const cleaned = list.map(p => ({ ...p, syncProjectId: null }));
        localStorage.setItem('site_projects_list', JSON.stringify(cleaned));
      }
    } catch (e) {}
    window.history.replaceState({}, '', window.location.pathname);
    if (typeof window !== 'undefined' && (window as any).showToast) {
      (window as any).showToast('👑 تم إلغاء كافة المعرفات السحابية والعودة كمالك رئيسي (المهندس/ياسر عقيل) للمشروع الأساسي!');
    }
  };

  const [userName, setUserName] = useState<string>(() => {
    return localStorage.getItem('site_user_name') || '';
  });

  const [promptUserName, setPromptUserName] = useState<boolean>(false);
  const [showExitConfirmModal, setShowExitConfirmModal] = useState<boolean>(false);
  const [showSettingsModal, setShowSettingsModal] = useState<boolean>(false);
  const [showAndroidInstallModal, setShowAndroidInstallModal] = useState<boolean>(false);
  const [showGlobalBackupModal, setShowGlobalBackupModal] = useState<boolean>(false);
  const [theme, setTheme] = useState<'light' | 'dark'>(() => {
    return (localStorage.getItem('site_theme') as 'light' | 'dark') || 'light';
  });
  const [isSyncDisabled, setIsSyncDisabled] = useState<boolean>(false);
  const [syncDisabledMessage, setSyncDisabledMessage] = useState<string>('');

  // ============================ UNDO SYSTEM STATE & HANDLERS ============================
  const [undoStack, setUndoStack] = useState<UndoItem[]>(() => {
    try {
      const saved = sessionStorage.getItem('site_undo_stack');
      if (saved) {
        const parsed: UndoItem[] = JSON.parse(saved);
        return parsed.map(item => ({
          ...item,
          timeAgo: getTimeAgoArabic(item.timestamp)
        }));
      }
    } catch {}
    return [];
  });

  const [showUndoModal, setShowUndoModal] = useState<boolean>(false);

  const pushUndoItem = useCallback((itemConfig: Parameters<typeof buildUndoItem>[0]) => {
    const item = buildUndoItem(itemConfig);
    setUndoStack(prev => {
      const updated = [item, ...prev].slice(0, 30);
      try {
        sessionStorage.setItem('site_undo_stack', JSON.stringify(updated));
      } catch {}
      return updated;
    });
  }, []);

  const handleOpenUndoModal = () => {
    setUndoStack(prev => prev.map(i => ({
      ...i,
      timeAgo: getTimeAgoArabic(i.timestamp)
    })));
    setShowUndoModal(true);
  };

  const handleClearUndoStack = () => {
    setUndoStack([]);
    try {
      sessionStorage.removeItem('site_undo_stack');
    } catch {}
    setShowUndoModal(false);
    if (typeof window !== 'undefined' && (window as any).showToast) {
      (window as any).showToast('🗑️ تم مسح سجل التراجع.');
    }
  };

  const handleExecuteUndo = (itemToUndo: UndoItem) => {
    try {
      const { type, data } = itemToUndo.payload;

      switch (type) {
        case 'expense_delete': {
          const restoredExpense: Expense = data;
          setExpenses(prev => [restoredExpense, ...prev]);
          break;
        }

        case 'expense_update': {
          const oldExpense: Expense = data;
          setExpenses(prev => prev.map(e => e.id === oldExpense.id ? oldExpense : e));
          break;
        }

        case 'worker_delete': {
          const restoredWorker: Worker = data;
          setWorkers(prev => [restoredWorker, ...prev]);
          break;
        }

        case 'worker_update': {
          const oldWorker: Worker = data;
          setWorkers(prev => prev.map(w => w.id === oldWorker.id ? oldWorker : w));
          break;
        }

        case 'worker_ledger_delete': {
          const { workerId, entry } = data;
          setWorkers(prev => prev.map(w => w.id === workerId ? { ...w, ledger: [entry, ...w.ledger] } : w));
          break;
        }

        case 'employee_delete': {
          const restoredEmployee: Employee = data;
          setEmployees(prev => [restoredEmployee, ...prev]);
          break;
        }

        case 'employee_update': {
          const oldEmployee: Employee = data;
          setEmployees(prev => prev.map(e => e.id === oldEmployee.id ? oldEmployee : e));
          break;
        }

        case 'employee_ledger_delete': {
          const { employeeId, entry } = data;
          setEmployees(prev => prev.map(e => e.id === employeeId ? { ...e, ledger: [entry, ...e.ledger] } : e));
          break;
        }

        case 'supplier_delete': {
          const restoredSupplier: Supplier = data;
          setSuppliers(prev => [restoredSupplier, ...prev]);
          break;
        }

        case 'supplier_update': {
          const oldSupplier: Supplier = data;
          setSuppliers(prev => prev.map(s => s.id === oldSupplier.id ? oldSupplier : s));
          break;
        }

        case 'supplier_ledger_delete': {
          const { supplierId, entry } = data;
          setSuppliers(prev => prev.map(s => s.id === supplierId ? { ...s, ledger: [entry, ...s.ledger] } : s));
          break;
        }

        case 'general_debt_delete': {
          const restoredDebt: GeneralDebt = data;
          setGeneralDebts(prev => [restoredDebt, ...prev]);
          break;
        }

        case 'general_debt_update': {
          const oldDebt: GeneralDebt = data;
          setGeneralDebts(prev => prev.map(d => d.id === oldDebt.id ? oldDebt : d));
          break;
        }

        case 'general_debt_payment_delete': {
          const { debtId, payment } = data;
          setGeneralDebts(prev => prev.map(d => {
            if (d.id !== debtId) return d;
            const updatedPayments = [payment, ...(d.payments || [])];
            return {
              ...d,
              payments: updatedPayments,
              updatedAt: new Date().toISOString()
            };
          }));
          break;
        }

        case 'asset_delete': {
          const restoredAsset: CompanyAsset = data;
          setCompanyAssets(prev => [restoredAsset, ...prev]);
          break;
        }

        case 'asset_update': {
          const oldAsset: CompanyAsset = data;
          setCompanyAssets(prev => prev.map(a => a.id === oldAsset.id ? oldAsset : a));
          break;
        }

        case 'project_delete': {
          const restoredProject: Project = data;
          setProjects(prev => {
            const updated = [restoredProject, ...prev];
            safeLocalStorageSet('site_projects_list', JSON.stringify(updated));
            return updated;
          });
          break;
        }

        case 'project_update': {
          const oldProject: Project = data;
          setProjects(prev => {
            const updated = prev.map(p => p.id === oldProject.id ? oldProject : p);
            safeLocalStorageSet('site_projects_list', JSON.stringify(updated));
            return updated;
          });
          break;
        }

        case 'contract_item_delete': {
          const restoredContractItem: ContractItem = data;
          setContractItems(prev => [restoredContractItem, ...prev]);
          break;
        }

        case 'contract_item_update': {
          const oldContractItem: ContractItem = data;
          setContractItems(prev => prev.map(c => c.id === oldContractItem.id ? oldContractItem : c));
          break;
        }

        case 'budget_delete': {
          const restoredBudgetItem: BudgetItem = data;
          setBudget(prev => [restoredBudgetItem, ...prev]);
          break;
        }

        case 'budget_update': {
          const oldBudgetItem: BudgetItem = data;
          setBudget(prev => prev.map(b => b.id === oldBudgetItem.id ? oldBudgetItem : b));
          break;
        }

        case 'evaluation_delete': {
          const restoredEval: PerformanceEvaluation = data;
          setEvaluations(prev => [restoredEval, ...prev]);
          break;
        }

        case 'evaluation_update': {
          const oldEval: PerformanceEvaluation = data;
          setEvaluations(prev => prev.map(e => e.id === oldEval.id ? oldEval : e));
          break;
        }

        default:
          console.warn('Unknown undo type:', type);
      }

      setUndoStack(prev => {
        const next = prev.filter(i => i.id !== itemToUndo.id);
        try {
          sessionStorage.setItem('site_undo_stack', JSON.stringify(next));
        } catch {}
        return next;
      });

      setShowUndoModal(false);

      if (typeof window !== 'undefined' && (window as any).showToast) {
        (window as any).showToast(`✅ تم التراجع عن العملية بنجاح واسترجاع: ${itemToUndo.title}`);
      }
    } catch (err) {
      console.error('Error executing undo:', err);
      alert('⚠️ حدث خطأ أثناء التراجع عن العملية.');
    }
  };

  const handleSetProjectId = (id: string | null) => {
    hasLoadedRemoteRef.current = false;
    setProjectId(id);
    if (id) {
      if (sharedRole !== 'owner') {
        setSharedRole('full');
      }
      window.history.pushState({}, '', `?project=${id}&role=${sharedRole === 'owner' ? 'owner' : 'full'}`);
    } else {
      window.history.pushState({}, '', window.location.pathname);
    }
  };

  const handleResetAllData = () => {
    localStorage.clear();
    window.location.reload();
  };

  // Manage Phone Hardware Back Button & Navigation History Stack
  const handleTabChange = useCallback((newTab: string) => {
    setActiveTab(prev => {
      if (prev !== newTab) {
        try {
          window.history.pushState({ tab: newTab }, '');
        } catch (e) {}
      }
      return newTab;
    });
  }, []);

  // Handle exiting the app across Android APK / WebViews / Capacitor / Cordova / Browsers
  const handleExitApp = useCallback(() => {
    // 1. Capacitor App plugin
    if ((window as any).Capacitor?.Plugins?.App?.exitApp) {
      try { (window as any).Capacitor.Plugins.App.exitApp(); return; } catch (e) {}
    }
    // 2. Cordova / PhoneGap / Ionic
    if ((window as any).navigator?.app?.exitApp) {
      try { (window as any).navigator.app.exitApp(); return; } catch (e) {}
    }
    // 3. Android WebView JS Interfaces
    if ((window as any).Android?.exitApp) {
      try { (window as any).Android.exitApp(); return; } catch (e) {}
    }
    if ((window as any).AndroidInterface?.exitApp) {
      try { (window as any).AndroidInterface.exitApp(); return; } catch (e) {}
    }
    if ((window as any).AndroidBridge?.exitApp) {
      try { (window as any).AndroidBridge.exitApp(); return; } catch (e) {}
    }
    // 4. Fallback for Web/Browser
    try {
      window.close();
    } catch (e) {}
    setShowExitConfirmModal(false);
  }, []);
  const [tempUserName, setTempUserName] = useState<string>('');
  const [syncStatus, setSyncStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  const [lastSyncedAt, setLastSyncedAt] = useState<string>('');
  
  // Custom print and toast states
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [printPreview, setPrintPreview] = useState<{ title: string; htmlContent: string } | null>(null);
  const [companyName, setCompanyName] = useState<string>(() => {
    const saved = localStorage.getItem('site_company_name');
    if (saved && saved !== 'شركة ورلد أوف إيليتس للمقاولات والخدمات' && saved !== 'ورلد أوف إيليتس للمقاولات والخدمات') {
      return saved;
    }
    return 'ورلد أوف إيليتس للتجارة والمقاولات';
  });
  const [projectName, setProjectName] = useState<string>(() => {
    return localStorage.getItem('site_project_name') || 'مشروع المقاولات والإنشاءات الرئيسي';
  });
  const [companyAddress, setCompanyAddress] = useState<string>(() => {
    const saved = localStorage.getItem('site_company_address');
    if (saved && saved !== 'صنعاء - شارع الستين - عمارة النخبة' && saved !== 'صنعاء - شارع الستين') {
      return saved;
    }
    return "صنعاء - بيت بوس - شارع الخمسين - 50 St - Bait Boos - Sana'a";
  });
  const [companyPhone, setCompanyPhone] = useState<string>(() => {
    const saved = localStorage.getItem('site_company_phone');
    if (saved && saved !== '+967 770 000 000 / +967 01 200000') {
      return saved;
    }
    return '+967 782 222 877 | +967 779 992 996';
  });
  const [companyLogo, setCompanyLogo] = useState<string>(() => {
    return localStorage.getItem('site_company_custom_logo') || COMPANY_LOGO_BASE64;
  });
  const [isGeneratingPDF, setIsGeneratingPDF] = useState<boolean>(false);

  // Lock background scroll when any global modal or menu is open
  useBodyScrollLock(Boolean(promptUserName || printPreview || showExitConfirmModal || isSyncDisabled || showSettingsModal || showAndroidInstallModal || mobileMenuOpen || showAppInfoModal));

  useEffect(() => {
    (window as any).showToast = (msg: string) => {
      setToastMessage(msg);
      setTimeout(() => {
        setToastMessage(prev => prev === msg ? null : prev);
      }, 5000);
    };
    (window as any).showPrintPreview = (title: string, htmlContent: string) => {
      const datedTitle = ensureDateInFilename(title);
      setPrintPreview({ title: datedTitle, htmlContent });
    };
    return () => {
      delete (window as any).showToast;
      delete (window as any).showPrintPreview;
    };
  }, []);

  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
      document.body.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
      document.body.classList.remove('dark');
    }
    localStorage.setItem('site_theme', theme);
  }, [theme]);

  const handleToggleTheme = () => {
    const nextTheme = theme === 'dark' ? 'light' : 'dark';
    setTheme(nextTheme);
    if (typeof window !== 'undefined' && (window as any).showToast) {
      (window as any).showToast(nextTheme === 'dark' ? '🌙 تم تفعيل الوضع الداكن بنجاح' : '☀️ تم تفعيل الوضع الفاتح بنجاح');
    }
  };

  useEffect(() => {
    const savedLang = localStorage.getItem('site_language');
    if (savedLang) {
      document.documentElement.lang = savedLang;
      document.documentElement.dir = savedLang === 'en' ? 'ltr' : 'rtl';
    }
  }, []);

  // Hardware Back Button Manager (for Browsers, Android APK, WebView, Cordova, Capacitor)
  useEffect(() => {
    try {
      if (!window.history.state || !window.history.state.tab) {
        window.history.replaceState({ tab: 'main_hub' }, '');
      }
    } catch (e) {}

    const handleBackAction = () => {
      // Priority 1: Close active modals or menus first if open
      if (printPreview) {
        setPrintPreview(null);
        return;
      }
      if (mobileMenuOpen) {
        setMobileMenuOpen(false);
        return;
      }
      if (showExitConfirmModal) {
        setShowExitConfirmModal(false);
        return;
      }

      // Priority 2: Return to main_hub tab if in another tab
      if (activeTab !== 'main_hub') {
        setActiveTab('main_hub');
        try {
          window.history.pushState({ tab: 'main_hub' }, '');
        } catch (e) {}
        return;
      }

      // Priority 3: On main hub screen -> Show exit confirmation modal
      setShowExitConfirmModal(true);
      try {
        window.history.pushState({ tab: 'main_hub', modal: 'exit' }, '');
      } catch (e) {}
    };

    const handlePopState = (e: PopStateEvent) => {
      if (printPreview) {
        setPrintPreview(null);
        return;
      }
      if (mobileMenuOpen) {
        setMobileMenuOpen(false);
        return;
      }
      if (showExitConfirmModal) {
        setShowExitConfirmModal(false);
        return;
      }

      const stateTab = e.state?.tab;
      if (stateTab && stateTab !== activeTab) {
        setActiveTab(stateTab);
      } else if (activeTab !== 'main_hub') {
        setActiveTab('main_hub');
      } else {
        setShowExitConfirmModal(true);
        try {
          window.history.pushState({ tab: 'main_hub', modal: 'exit' }, '');
        } catch (err) {}
      }
    };

    const handleCordovaBackButton = (e: Event) => {
      e.preventDefault();
      handleBackAction();
    };

    // Browser & Webview PopState
    window.addEventListener('popstate', handlePopState);

    // Cordova / PhoneGap / Android Webview hardware back button
    document.addEventListener('backbutton', handleCordovaBackButton, false);

    // Capacitor App Plugin backButton
    let capacitorRemove: (() => void) | null = null;
    if ((window as any).Capacitor?.Plugins?.App?.addListener) {
      try {
        const sub = (window as any).Capacitor.Plugins.App.addListener('backButton', () => {
          handleBackAction();
        });
        if (sub && typeof sub.remove === 'function') {
          capacitorRemove = () => sub.remove();
        }
      } catch (err) {}
    }

    return () => {
      window.removeEventListener('popstate', handlePopState);
      document.removeEventListener('backbutton', handleCordovaBackButton, false);
      if (capacitorRemove) {
        capacitorRemove();
      }
    };
  }, [activeTab, mobileMenuOpen, printPreview, showExitConfirmModal]);

  const isIncomingUpdateRef = useRef(false);
  const hasLoadedRemoteRef = useRef(false);

  // Synchronous State Initializations from LocalStorage (or seed data if null)
  const [budget, setBudget] = useState<BudgetItem[]>(() => {
    const saved = localStorage.getItem('site_budget');
    return saved ? JSON.parse(saved) : SEED_BUDGET;
  });

  const [workers, setWorkers] = useState<Worker[]>(() => {
    const saved = localStorage.getItem('site_workers');
    let initialWorkers: Worker[] = SEED_WORKERS;
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) initialWorkers = parsed;
      } catch (e) {}
    } else {
      const backup = localStorage.getItem('site_workers_backup');
      if (backup) {
        try {
          const parsedBackup = JSON.parse(backup);
          if (Array.isArray(parsedBackup) && parsedBackup.length > 0) initialWorkers = parsedBackup;
        } catch (e) {}
      }
    }
    return initialWorkers.map(w => syncWorkerNutritionLedger(w));
  });

  const [employees, setEmployees] = useState<Employee[]>(() => {
    const saved = localStorage.getItem('site_employees');
    let initialEmployees: Employee[] = SEED_EMPLOYEES;
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) initialEmployees = parsed;
      } catch (e) {}
    } else {
      const backup = localStorage.getItem('site_employees_backup');
      if (backup) {
        try {
          const parsedBackup = JSON.parse(backup);
          if (Array.isArray(parsedBackup) && parsedBackup.length > 0) initialEmployees = parsedBackup;
        } catch (e) {}
      }
    }
    return initialEmployees.map(e => syncEmployeeAllLedgers(e));
  });

  const [suppliers, setSuppliers] = useState<Supplier[]>(() => {
    try {
      const saved = safeLocalStorageGet('site_suppliers');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return sanitizeSuppliersData(parsed);
      }
    } catch (e) {
      console.warn('Failed to parse site_suppliers:', e);
    }
    return SEED_SUPPLIERS;
  });

  const [expenses, setExpenses] = useState<Expense[]>(() => {
    try {
      const saved = safeLocalStorageGet('site_expenses');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch (e) {
      console.warn('Failed to parse site_expenses:', e);
    }
    return SEED_EXPENSES;
  });

  // 📋 جداول الكميات وبنود عقد المشروع
  const [contractItems, setContractItems] = useState<ContractItem[]>(() => {
    try {
      const saved = safeLocalStorageGet('site_contract_items');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch (e) {
      console.warn('Failed to parse site_contract_items:', e);
    }
    return [];
  });

  useEffect(() => {
    safeLocalStorageSet('site_contract_items', JSON.stringify(contractItems));
  }, [contractItems]);

  // 🏢 الديون والالتزامات العامة للشركة (منفصلة تماماً ومستقلة عن أي مشروع)
  const [generalDebts, setGeneralDebts] = useState<GeneralDebt[]>(() => {
    const saved = localStorage.getItem('site_general_debts');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      } catch (e) {}
    }
    const backup = localStorage.getItem('site_general_debts_backup');
    if (backup) {
      try {
        const parsedBackup = JSON.parse(backup);
        if (Array.isArray(parsedBackup)) return parsedBackup;
      } catch (e) {}
    }
    return [];
  });

  // حفظ الديون والالتزامات العامة في مفتاحها المستقل
  useEffect(() => {
    try {
      localStorage.setItem('site_general_debts', JSON.stringify(generalDebts));
      if (generalDebts.length > 0) {
        localStorage.setItem('site_general_debts_backup', JSON.stringify(generalDebts));
      }
    } catch (e) {}
  }, [generalDebts]);

  // ⭐ تقييم الأداء (للموظفين، العمال، والموردين - مستقل ومحفوظ في مفتاح مستقل)
  const [evaluations, setEvaluations] = useState<PerformanceEvaluation[]>(() => {
    const saved = localStorage.getItem('site_performance_evaluations');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      } catch (e) {}
    }
    const backup = localStorage.getItem('site_performance_evaluations_backup');
    if (backup) {
      try {
        const parsedBackup = JSON.parse(backup);
        if (Array.isArray(parsedBackup)) return parsedBackup;
      } catch (e) {}
    }
    return [];
  });

  // حفظ تقييمات الأداء في مفتاحها المستقل
  useEffect(() => {
    try {
      localStorage.setItem('site_performance_evaluations', JSON.stringify(evaluations));
      if (evaluations.length > 0) {
        localStorage.setItem('site_performance_evaluations_backup', JSON.stringify(evaluations));
      }
    } catch (e) {}
  }, [evaluations]);

  // 🚜 مواد وأصول الشركة والمشاريع (المعدات، الآليات، المخزون، العهد - مستقل ومحفوظ في مفتاح مستقل)
  const [companyAssets, setCompanyAssets] = useState<CompanyAsset[]>(() => {
    const saved = localStorage.getItem('site_company_assets');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      } catch (e) {}
    }
    const backup = localStorage.getItem('site_company_assets_backup');
    if (backup) {
      try {
        const parsedBackup = JSON.parse(backup);
        if (Array.isArray(parsedBackup)) return parsedBackup;
      } catch (e) {}
    }
    return [];
  });

  // حفظ أصول الشركة في مفتاحها المستقل
  useEffect(() => {
    try {
      localStorage.setItem('site_company_assets', JSON.stringify(companyAssets));
      if (companyAssets.length > 0) {
        localStorage.setItem('site_company_assets_backup', JSON.stringify(companyAssets));
      }
    } catch (e) {}
  }, [companyAssets]);

  // Projects Hub Multi-Project Management State
  const [projects, setProjects] = useState<Project[]>(() => {
    const saved = safeLocalStorageGet('site_projects_list');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      } catch (e) {}
    }

    const safeParse = (key: string, fallback: any) => {
      try {
        const val = safeLocalStorageGet(key);
        return val ? JSON.parse(val) : fallback;
      } catch (_) {
        return fallback;
      }
    };

    const defaultProj: Project = {
      id: 'proj_default',
      name: safeLocalStorageGet('site_project_name') || 'مشروع المقاولات والإنشاءات الرئيسي',
      location: safeLocalStorageGet('site_company_address') || 'صنعاء - شارع الستين',
      client: 'العميل الرئيسي',
      status: 'active',
      startDate: new Date().toISOString().split('T')[0],
      notes: 'المشروع الرئيسي الافتراضي',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      budget: safeParse('site_budget', SEED_BUDGET),
      workers: safeParse('site_workers', SEED_WORKERS),
      employees: safeParse('site_employees', SEED_EMPLOYEES),
      suppliers: sanitizeSuppliersData(safeParse('site_suppliers', SEED_SUPPLIERS)),
      expenses: safeParse('site_expenses', SEED_EXPENSES)
    };

    return [defaultProj];
  });

  const [activeProjectId, setActiveProjectId] = useState<string>(() => {
    return localStorage.getItem('site_active_project_id') || projects[0]?.id || 'proj_default';
  });

  // Multi-Project Handlers
  const handleSelectProjectDirect = useCallback((id: string, projectList: Project[]) => {
    const target = projectList.find(p => p.id === id) || projectList[0];
    if (!target) return;

    const b = target.budget || [];
    const w = target.workers || [];
    const e = target.employees || [];
    const s = target.suppliers || [];
    const ex = target.expenses || [];
    const ci = target.contractItems || [];

    setActiveProjectId(target.id);
    setProjectName(target.name);
    setBudget(b);
    setWorkers(w);
    setEmployees(e);
    setSuppliers(s);
    setExpenses(ex);
    setContractItems(ci);

    safeLocalStorageSet('site_active_project_id', target.id);
    safeLocalStorageSet('site_project_name', target.name);
    safeLocalStorageSet('site_budget', JSON.stringify(b));
    safeLocalStorageSet('site_workers', JSON.stringify(w));
    safeLocalStorageSet('site_employees', JSON.stringify(e));
    safeLocalStorageSet('site_suppliers', JSON.stringify(s));
    safeLocalStorageSet('site_expenses', JSON.stringify(ex));
    safeLocalStorageSet('site_contract_items', JSON.stringify(ci));
  }, []);

  const handleSelectProject = (id: string) => {
    handleSelectProjectDirect(id, projects);
  };

  const handleCreateProject = (newProjData: Omit<Project, 'id' | 'createdAt' | 'updatedAt'>) => {
    const newId = 'proj_' + Math.random().toString(36).substring(2, 10);
    const newProj: Project = {
      ...newProjData,
      id: newId,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    const updatedList = [newProj, ...projects];
    setProjects(updatedList);
    safeLocalStorageSet('site_projects_list', JSON.stringify(updatedList));
    handleSelectProject(newId);
  };

  const handleUpdateProject = (updatedProj: Project) => {
    const oldProj = projects.find(p => p.id === updatedProj.id);
    if (oldProj) {
      pushUndoItem({
        category: 'projects',
        categoryLabel: 'المشاريع الإنشائية',
        actionType: 'update',
        actionLabel: 'تعديل مشروع',
        title: `مشروع: ${oldProj.name}`,
        details: [
          { label: 'اسم المشروع', value: oldProj.name },
          { label: 'الموقع السابق', value: oldProj.location || 'غير محدد' },
          { label: 'العميل السابق', value: oldProj.client || 'غير محدد' }
        ],
        payload: { type: 'project_update', data: oldProj }
      });
    }

    const updatedList = projects.map(p => p.id === updatedProj.id ? updatedProj : p);
    setProjects(updatedList);
    safeLocalStorageSet('site_projects_list', JSON.stringify(updatedList));
    if (updatedProj.id === activeProjectId) {
      setProjectName(updatedProj.name);
    }
  };

  const handleDeleteProject = (id: string) => {
    if (projects.length <= 1) {
      alert('لا يمكن حذف المشروع الوحيد المتبقي.');
      return;
    }
    const target = projects.find(p => p.id === id);
    if (target) {
      pushUndoItem({
        category: 'projects',
        categoryLabel: 'المشاريع الإنشائية',
        actionType: 'delete',
        actionLabel: 'حذف مشروع',
        title: `مشروع: ${target.name}`,
        details: [
          { label: 'اسم المشروع', value: target.name },
          { label: 'الموقع', value: target.location || 'غير محدد' },
          { label: 'العميل', value: target.client || 'غير محدد' }
        ],
        payload: { type: 'project_delete', data: target }
      });
    }

    const updatedList = projects.filter(p => p.id !== id);
    setProjects(updatedList);
    safeLocalStorageSet('site_projects_list', JSON.stringify(updatedList));

    if (activeProjectId === id) {
      handleSelectProject(updatedList[0].id);
    }
  };

  // Full App Projects Backup & Restore Handler
  const handleRestoreAllProjects = useCallback((
    data: { projects: Project[]; settings?: any; externalDebts?: any[] },
    mode: 'overwrite' | 'merge'
  ) => {
    try {
      if (data.settings) {
        if (data.settings.companyName) {
          setCompanyName(data.settings.companyName);
          localStorage.setItem('site_company_name', data.settings.companyName);
        }
        if (data.settings.companyAddress) {
          setCompanyAddress(data.settings.companyAddress);
          localStorage.setItem('site_company_address', data.settings.companyAddress);
        }
        if (data.settings.companyPhone) {
          setCompanyPhone(data.settings.companyPhone);
          localStorage.setItem('site_company_phone', data.settings.companyPhone);
        }
        if (data.settings.currency) {
          setCurrency(data.settings.currency);
          localStorage.setItem('site_currency', data.settings.currency);
        }
      }

      if (data.externalDebts && Array.isArray(data.externalDebts)) {
        if (mode === 'overwrite') {
          localStorage.setItem('site_external_debts', JSON.stringify(data.externalDebts));
        } else {
          const currentDebts = JSON.parse(localStorage.getItem('site_external_debts') || '[]');
          const debtMap = new Map();
          currentDebts.forEach((d: any) => debtMap.set(d.id, d));
          data.externalDebts.forEach((d: any) => {
            if (!debtMap.has(d.id)) debtMap.set(d.id, d);
          });
          localStorage.setItem('site_external_debts', JSON.stringify(Array.from(debtMap.values())));
        }
      }

      if ((data as any).generalDebts && Array.isArray((data as any).generalDebts)) {
        if (mode === 'overwrite') {
          setGeneralDebts((data as any).generalDebts);
          localStorage.setItem('site_general_debts', JSON.stringify((data as any).generalDebts));
          localStorage.setItem('site_general_debts_backup', JSON.stringify((data as any).generalDebts));
        } else {
          setGeneralDebts(prev => {
            const debtMap = new Map();
            prev.forEach(d => debtMap.set(d.id, d));
            (data as any).generalDebts.forEach((d: any) => {
              if (!debtMap.has(d.id)) debtMap.set(d.id, d);
            });
            const merged = Array.from(debtMap.values());
            localStorage.setItem('site_general_debts', JSON.stringify(merged));
            localStorage.setItem('site_general_debts_backup', JSON.stringify(merged));
            return merged;
          });
        }
      }

      if ((data as any).companyAssets && Array.isArray((data as any).companyAssets)) {
        if (mode === 'overwrite') {
          setCompanyAssets((data as any).companyAssets);
          localStorage.setItem('site_company_assets', JSON.stringify((data as any).companyAssets));
          localStorage.setItem('site_company_assets_backup', JSON.stringify((data as any).companyAssets));
        } else {
          setCompanyAssets(prev => {
            const assetMap = new Map();
            prev.forEach(a => assetMap.set(a.id, a));
            (data as any).companyAssets.forEach((a: any) => {
              if (!assetMap.has(a.id)) assetMap.set(a.id, a);
            });
            const merged = Array.from(assetMap.values());
            localStorage.setItem('site_company_assets', JSON.stringify(merged));
            localStorage.setItem('site_company_assets_backup', JSON.stringify(merged));
            return merged;
          });
        }
      }

      if ((data as any).evaluations && Array.isArray((data as any).evaluations)) {
        if (mode === 'overwrite') {
          setEvaluations((data as any).evaluations);
          localStorage.setItem('site_performance_evaluations', JSON.stringify((data as any).evaluations));
          localStorage.setItem('site_performance_evaluations_backup', JSON.stringify((data as any).evaluations));
        } else {
          setEvaluations(prev => {
            const evalMap = new Map();
            prev.forEach(e => evalMap.set(e.id, e));
            (data as any).evaluations.forEach((e: any) => {
              if (!evalMap.has(e.id)) evalMap.set(e.id, e);
            });
            const merged = Array.from(evalMap.values());
            localStorage.setItem('site_performance_evaluations', JSON.stringify(merged));
            localStorage.setItem('site_performance_evaluations_backup', JSON.stringify(merged));
            return merged;
          });
        }
      }

      if (mode === 'overwrite') {
        if (Array.isArray(data.projects) && data.projects.length > 0) {
          setProjects(data.projects);
          localStorage.setItem('site_projects_list', JSON.stringify(data.projects));

          const targetId = data.settings?.activeProjectId && data.projects.some(p => p.id === data.settings.activeProjectId)
            ? data.settings.activeProjectId
            : data.projects[0].id;
          handleSelectProjectDirect(targetId, data.projects);
        }
      } else {
        // Merge mode
        if (Array.isArray(data.projects) && data.projects.length > 0) {
          let mergedList: Project[] = [];
          setProjects(prevProjects => {
            const projMap = new Map<string, Project>();
            prevProjects.forEach(p => projMap.set(p.id, p));
            data.projects.forEach(p => {
              if (!projMap.has(p.id)) {
                projMap.set(p.id, p);
              } else {
                const existing = projMap.get(p.id)!;
                projMap.set(p.id, {
                  ...existing,
                  ...p,
                  budget: p.budget && p.budget.length > 0 ? p.budget : existing.budget,
                  workers: p.workers && p.workers.length > 0 ? p.workers : existing.workers,
                  employees: p.employees && p.employees.length > 0 ? p.employees : existing.employees,
                  suppliers: p.suppliers && p.suppliers.length > 0 ? p.suppliers : existing.suppliers,
                  expenses: p.expenses && p.expenses.length > 0 ? p.expenses : existing.expenses,
                  updatedAt: new Date().toISOString()
                });
              }
            });
            mergedList = Array.from(projMap.values());
            localStorage.setItem('site_projects_list', JSON.stringify(mergedList));
            return mergedList;
          });

          const targetId = data.settings?.activeProjectId && mergedList.some(p => p.id === data.settings.activeProjectId)
            ? data.settings.activeProjectId
            : activeProjectId;

          handleSelectProjectDirect(targetId, mergedList.length > 0 ? mergedList : data.projects);
        }
      }

      if (typeof window !== 'undefined' && (window as any).showToast) {
        (window as any).showToast('✅ تم استعادة وحفظ كافة مشاريع وبيانات التطبيق بنجاح!');
      }
    } catch (err) {
      console.error('Error restoring all projects:', err);
      alert('حدث خطأ أثناء استعادة مشاريع التطبيق!');
    }
  }, [handleSelectProjectDirect, activeProjectId]);

  const handleDuplicateProject = (id: string) => {
    const target = projects.find(p => p.id === id);
    if (!target) return;
    const newId = 'proj_' + Math.random().toString(36).substring(2, 10);
    const copyProj: Project = {
      ...target,
      id: newId,
      name: `${target.name} (نسخة)`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    const updatedList = [copyProj, ...projects];
    setProjects(updatedList);
    localStorage.setItem('site_projects_list', JSON.stringify(updatedList));
  };

  // Cross-project Entity Migration Handler
  const handleMigrateEntity = ({
    sourceProjectId,
    targetProjectId,
    entityType,
    entityId,
    includeLedger
  }: {
    sourceProjectId: string;
    targetProjectId: string;
    entityType: 'worker' | 'employee' | 'supplier';
    entityId: string;
    includeLedger: boolean;
  }) => {
    if (sourceProjectId === targetProjectId) return;

    const sourceProj = projects.find(p => p.id === sourceProjectId);
    const targetProj = projects.find(p => p.id === targetProjectId);
    if (!sourceProj || !targetProj) return;

    if (entityType === 'worker') {
      const workerToMove = sourceProj.workers?.find(w => w.id === entityId);
      if (!workerToMove) return;
      const newWorker = {
        ...workerToMove,
        id: 'worker_' + Date.now().toString(),
        ledger: includeLedger ? workerToMove.ledger.map(e => ({ ...e, id: 'wled_' + Math.random().toString(36).substring(2, 9) })) : []
      };
      const updatedTargetWorkers = [newWorker, ...(targetProj.workers || [])];
      const updatedProjects = projects.map(p => {
        if (p.id === targetProjectId) {
          return { ...p, workers: updatedTargetWorkers, updatedAt: new Date().toISOString() };
        }
        return p;
      });
      setProjects(updatedProjects);
      safeLocalStorageSet('site_projects_list', JSON.stringify(updatedProjects));
      if (activeProjectId === targetProjectId) {
        setWorkers(updatedTargetWorkers);
      }
    } else if (entityType === 'employee') {
      const empToMove = sourceProj.employees?.find(e => e.id === entityId);
      if (!empToMove) return;
      const newEmp = {
        ...empToMove,
        id: 'emp_' + Date.now().toString(),
        ledger: includeLedger ? empToMove.ledger.map(e => ({ ...e, id: 'eled_' + Math.random().toString(36).substring(2, 9) })) : []
      };
      const updatedTargetEmps = [newEmp, ...(targetProj.employees || [])];
      const updatedProjects = projects.map(p => {
        if (p.id === targetProjectId) {
          return { ...p, employees: updatedTargetEmps, updatedAt: new Date().toISOString() };
        }
        return p;
      });
      setProjects(updatedProjects);
      safeLocalStorageSet('site_projects_list', JSON.stringify(updatedProjects));
      if (activeProjectId === targetProjectId) {
        setEmployees(updatedTargetEmps);
      }
    } else if (entityType === 'supplier') {
      const suppToMove = sourceProj.suppliers?.find(s => s.id === entityId);
      if (!suppToMove) return;
      const newSupp = {
        ...suppToMove,
        id: 'supplier_' + Date.now().toString(),
        ledger: includeLedger ? suppToMove.ledger.map(e => ({ ...e, id: 'sled_' + Math.random().toString(36).substring(2, 9) })) : []
      };
      const updatedTargetSupps = [newSupp, ...(targetProj.suppliers || [])];
      const updatedProjects = projects.map(p => {
        if (p.id === targetProjectId) {
          return { ...p, suppliers: updatedTargetSupps, updatedAt: new Date().toISOString() };
        }
        return p;
      });
      setProjects(updatedProjects);
      safeLocalStorageSet('site_projects_list', JSON.stringify(updatedProjects));
      if (activeProjectId === targetProjectId) {
        setSuppliers(updatedTargetSupps);
      }
    }
  };

  // Keep projects list updated whenever active state changes
  useEffect(() => {
    setProjects(prevProjects => {
      const idx = prevProjects.findIndex(p => p.id === activeProjectId);
      if (idx === -1) return prevProjects;
      const current = prevProjects[idx];

      if (
        current.name === projectName &&
        current.budget === budget &&
        current.workers === workers &&
        current.employees === employees &&
        current.suppliers === suppliers &&
        current.expenses === expenses &&
        current.contractItems === contractItems
      ) {
        return prevProjects;
      }

      const copy = [...prevProjects];
      copy[idx] = {
        ...current,
        name: projectName,
        budget,
        workers,
        employees,
        suppliers,
        expenses,
        contractItems,
        updatedAt: new Date().toISOString()
      };
      safeLocalStorageSet('site_projects_list', JSON.stringify(copy));
      return copy;
    });
  }, [budget, workers, employees, suppliers, expenses, contractItems, projectName, activeProjectId]);

  // Save/Load Shared Project and Syncing Effects
  useEffect(() => {
    if (!projectId) return;

    const fetchProject = async () => {
      try {
        const res = await fetch(`/api/projects/${projectId}`);
        const data = await res.json().catch(() => ({}));

        if (res.ok) {
          console.log(`[SYNC:REMOTE_FETCHED] ProjectID: ${projectId}, Remote updatedAt: ${data.updatedAt}, Expenses: ${data.expenses?.length || 0}`);
          if (data.disabled || data.isSyncActive === false) {
            if (sharedRole !== 'owner') {
              setSyncDisabledMessage(data.error || 'تم إلغاء المزامنة السحابية لهذا المشروع من قبل المالك. لم يعد الوصول أو الاطلاع عبر هذا الرابط متاحاً.');
              setIsSyncDisabled(true);
            }
            setProjects(prev => prev.map(p => p.syncProjectId === projectId ? { ...p, syncProjectId: null } : p));
            setProjectId(null);
            hasLoadedRemoteRef.current = false;
            window.history.replaceState({}, '', window.location.pathname);
            return;
          }

          if (!hasLoadedRemoteRef.current || data.updatedAt !== lastSyncedAt) {
            const remoteBudget = data.budget || [];
            const remoteWorkers = data.workers || [];
            const remoteEmployees = Array.isArray(data.employees) ? data.employees : [];
            const remoteSuppliers = data.suppliers || [];
            const remoteExpenses = data.expenses || [];
            const remoteName = data.name || data.projectName || '';

            // Detect whether Local Data is newer / more complete than Cloud (e.g. Local 17/8 vs Cloud 10/8)
            let localMaxDate = '';
            for (const exp of expenses) {
              if (exp.date && exp.date > localMaxDate) localMaxDate = exp.date;
            }
            let remoteMaxDate = '';
            for (const exp of remoteExpenses) {
              if (exp.date && exp.date > remoteMaxDate) remoteMaxDate = exp.date;
            }

            const localIsNewer = (localMaxDate && remoteMaxDate && localMaxDate > remoteMaxDate) || (expenses.length > remoteExpenses.length);

            // CRITICAL SAFETY RULE: If user is Owner and Local is newer or has more transactions, DO NOT OVERWRITE LOCAL!
            // Instead, mark loaded and trigger a safe upload (Local 17/8 -> Cloud)
            if (sharedRole === 'owner' && localIsNewer && expenses.length > 0) {
              console.log(`[SYNC:LOCAL_NEWER] ProjectID: ${projectId}. Local Max Date: ${localMaxDate} vs Remote: ${remoteMaxDate}. Local expenses: ${expenses.length} vs Remote: ${remoteExpenses.length}. Preserving Local data.`);
              hasLoadedRemoteRef.current = true;
              setLastSyncedAt(data.updatedAt);
              setSyncStatus('idle');

              // Immediately push local 17/8 data to the existing cloud project via PUT
              try {
                const snapshot = {
                  timestamp: new Date().toISOString(),
                  budget,
                  workers,
                  employees,
                  suppliers,
                  expenses,
                  projectName,
                  currency
                };
                localStorage.setItem('_pre_cloud_sync_safety_backup', JSON.stringify(snapshot));
                
                console.log(`[SYNC:PUT_STARTED] Sending Local (17/8) to Cloud for ProjectID: ${projectId}`);
                fetch(`/api/projects/${projectId}`, {
                  method: 'PUT',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({ 
                    budget, 
                    workers, 
                    employees, 
                    suppliers, 
                    expenses,
                    projectName,
                    currency 
                  })
                }).then(r => r.json()).then(resData => {
                  if (resData?.updatedAt) {
                    console.log(`[SYNC:PUT_SUCCESS] Successfully updated Cloud ProjectID: ${projectId}, new updatedAt: ${resData.updatedAt}`);
                    setLastSyncedAt(resData.updatedAt);
                    setSyncStatus('success');
                  } else {
                    console.warn(`[SYNC:PUT_FAILED] Response missing updatedAt for ProjectID: ${projectId}`, resData);
                  }
                }).catch(err => {
                  console.error(`[SYNC:PUT_FAILED] Network or Server Error for ProjectID: ${projectId}:`, err);
                });
              } catch (e) {}
              return;
            }

            isIncomingUpdateRef.current = true;
            hasLoadedRemoteRef.current = true;

            setBudget(remoteBudget);
            setWorkers(remoteWorkers);
            setEmployees(remoteEmployees);
            setSuppliers(remoteSuppliers);
            setExpenses(remoteExpenses);

            if (remoteName) {
              setProjectName(remoteName);
              localStorage.setItem('site_project_name', remoteName);
            }
            if (data.currency) {
              setCurrency(data.currency);
              localStorage.setItem('site_currency', data.currency);
            }

            setLastSyncedAt(data.updatedAt);
            setSyncStatus('success');

            // Synchronize active project in projects list
            setProjects(prevProjects => {
              const existingIdx = prevProjects.findIndex(p => p.id === projectId || p.syncProjectId === projectId);
              if (existingIdx !== -1) {
                const updated = [...prevProjects];
                updated[existingIdx] = {
                  ...updated[existingIdx],
                  syncProjectId: projectId,
                  name: remoteName || updated[existingIdx].name,
                  budget: remoteBudget,
                  workers: remoteWorkers,
                  employees: remoteEmployees,
                  suppliers: remoteSuppliers,
                  expenses: remoteExpenses,
                  updatedAt: data.updatedAt || new Date().toISOString()
                };
                safeLocalStorageSet('site_projects_list', JSON.stringify(updated));
                return updated;
              } else {
                const newProject: Project = {
                  id: projectId,
                  syncProjectId: projectId,
                  name: remoteName || 'مشروع مشارك سحابياً',
                  location: data.location || '',
                  client: data.client || '',
                  status: data.status || 'active',
                  startDate: new Date().toISOString().split('T')[0],
                  createdAt: new Date().toISOString(),
                  updatedAt: data.updatedAt || new Date().toISOString(),
                  budget: remoteBudget,
                  workers: remoteWorkers,
                  employees: remoteEmployees,
                  suppliers: remoteSuppliers,
                  expenses: remoteExpenses
                };
                const updated = [newProject, ...prevProjects];
                safeLocalStorageSet('site_projects_list', JSON.stringify(updated));
                return updated;
              }
            });

            setActiveProjectId(projectId);
            localStorage.setItem('site_active_project_id', projectId);
          }
        } else {
          if (res.status === 403 || res.status === 404 || data.disabled) {
            if (sharedRole !== 'owner') {
              setSyncDisabledMessage(data.error || 'تم إلغاء المزامنة السحابية لهذا المشروع من قبل المالك. لم يعد الوصول أو الاطلاع عبر هذا الرابط متاحاً.');
              setIsSyncDisabled(true);
            }
            setProjects(prev => prev.map(p => p.syncProjectId === projectId ? { ...p, syncProjectId: null } : p));
            setProjectId(null);
            hasLoadedRemoteRef.current = false;
            window.history.replaceState({}, '', window.location.pathname);
          } else {
            setSyncStatus('error');
          }
        }
      } catch (err: any) {
        setSyncStatus('error');
      }
    };

    fetchProject();
    const interval = setInterval(fetchProject, 8000); // sync every 8 seconds
    return () => clearInterval(interval);
  }, [projectId, lastSyncedAt]);

  useEffect(() => {
    if (!projectId) return;
    if (!hasLoadedRemoteRef.current) return; // Prevent overwriting cloud data before initial load
    if (isIncomingUpdateRef.current) {
      isIncomingUpdateRef.current = false;
      return;
    }
    if (sharedRole === 'read') return;

    const saveData = async () => {
      try {
        // Safety snapshot before cloud save
        try {
          const snapshot = {
            timestamp: new Date().toISOString(),
            budget,
            workers,
            employees,
            suppliers,
            expenses,
            projectName,
            currency
          };
          localStorage.setItem('_pre_cloud_sync_safety_backup', JSON.stringify(snapshot));
        } catch (e) {}

        setSyncStatus('loading');
        const res = await fetch(`/api/projects/${projectId}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ 
            budget, 
            workers, 
            employees, 
            suppliers, 
            expenses,
            projectName,
            currency 
          })
        });
        const data = await res.json().catch(() => ({}));
        if (res.ok) {
          setLastSyncedAt(data.updatedAt);
          setSyncStatus('success');
        } else {
          if (res.status === 403 || res.status === 404 || data.disabled) {
            if (sharedRole !== 'owner') {
              setSyncDisabledMessage(data.error || 'تم إلغاء المزامنة السحابية لهذا المشروع من قبل المالك. لم يعد الوصول أو الاطلاع عبر هذا الرابط متاحاً.');
              setIsSyncDisabled(true);
            }
            setProjects(prev => prev.map(p => p.syncProjectId === projectId ? { ...p, syncProjectId: null } : p));
            setProjectId(null);
            hasLoadedRemoteRef.current = false;
            window.history.replaceState({}, '', window.location.pathname);
          } else {
            setSyncStatus('error');
          }
        }
      } catch (err: any) {
        setSyncStatus('error');
      }
    };

    const debounce = setTimeout(saveData, 1200);
    return () => clearTimeout(debounce);
  }, [budget, workers, employees, suppliers, expenses, projectName, currency, projectId, sharedRole]);

  // Automatic Recovery Effect for missing employees/workers from expenses log
  useEffect(() => {
    if (expenses.length === 0) return;

    // Recover missing employees referenced in expenses
    const missingEmpExpenses = expenses.filter(exp => 
      exp.recipientType === 'employee' && 
      exp.recipientId && 
      !employees.some(emp => emp.id === exp.recipientId)
    );

    if (missingEmpExpenses.length > 0) {
      const recoveredMap = new Map<string, Employee>();
      missingEmpExpenses.forEach(exp => {
        if (!recoveredMap.has(exp.recipientId)) {
          recoveredMap.set(exp.recipientId, {
            id: exp.recipientId,
            name: exp.recipientName || 'موظف',
            profession: 'موظف (مسترجع تلقائياً من كشف الحساب)',
            startDate: exp.date,
            endDate: '',
            dailyWage: 0,
            ledger: [],
            createdBy: exp.createdBy || 'النظام'
          });
        }
      });

      const newRecovered = Array.from(recoveredMap.values()).map(emp => {
        const empExpenses = expenses.filter(exp => exp.recipientId === emp.id && exp.recipientType === 'employee');
        const reconstructedLedger: LedgerEntry[] = empExpenses.map(exp => ({
          id: 'posted_' + exp.id,
          date: exp.date,
          amountOnHim: exp.amount,
          amountForHim: 0,
          description: exp.description,
          notes: exp.notes,
          isPosted: true,
          currency: exp.currency || 'YER',
          createdBy: exp.createdBy || 'النظام'
        }));
        return { ...emp, ledger: reconstructedLedger };
      });

      setEmployees(prev => [...prev, ...newRecovered]);
    }

    // Recover missing workers referenced in expenses
    const missingWorkerExpenses = expenses.filter(exp => 
      exp.recipientType === 'worker' && 
      exp.recipientId && 
      !workers.some(w => w.id === exp.recipientId)
    );

    if (missingWorkerExpenses.length > 0) {
      const recoveredMap = new Map<string, Worker>();
      missingWorkerExpenses.forEach(exp => {
        if (!recoveredMap.has(exp.recipientId)) {
          recoveredMap.set(exp.recipientId, {
            id: exp.recipientId,
            name: exp.recipientName || 'عامل',
            profession: 'عامل (مسترجع تلقائياً من كشف الحساب)',
            startDate: exp.date,
            endDate: '',
            ledger: [],
            createdBy: exp.createdBy || 'النظام'
          });
        }
      });

      const newRecovered = Array.from(recoveredMap.values()).map(worker => {
        const workerExpenses = expenses.filter(exp => exp.recipientId === worker.id && exp.recipientType === 'worker');
        const reconstructedLedger: LedgerEntry[] = workerExpenses.map(exp => ({
          id: 'posted_' + exp.id,
          date: exp.date,
          amountOnHim: exp.amount,
          amountForHim: 0,
          description: exp.description,
          notes: exp.notes,
          isPosted: true,
          currency: exp.currency || 'YER',
          createdBy: exp.createdBy || 'النظام'
        }));
        return { ...worker, ledger: reconstructedLedger };
      });

      setWorkers(prev => [...prev, ...newRecovered]);
    }
  }, [expenses]);

  // Ensure Fikri is not lingering in workers list
  useEffect(() => {
    const fikriWorker = workers.find(w => w.name.includes('فكري') || w.id === 'emp_fikri' || w.id === 'worker_fikri');
    if (fikriWorker) {
      setWorkers(prev => prev.filter(w => w.id !== fikriWorker.id && !w.name.includes('فكري')));
    }
  }, [workers]);

  // Synchronize expense recipient names with latest worker/employee/supplier names across all operations
  useEffect(() => {
    let hasChanges = false;
    const workerMap = new Map(workers.map(w => [w.id, w.name]));
    const employeeMap = new Map(employees.map(e => [e.id, e.name]));
    const supplierMap = new Map(suppliers.map(s => [s.id, s.name]));

    const updatedExpenses = expenses.map(exp => {
      let currentName = exp.recipientName;
      if (exp.recipientType === 'worker' && exp.recipientId && workerMap.has(exp.recipientId)) {
        currentName = workerMap.get(exp.recipientId)!;
      } else if (exp.recipientType === 'employee' && exp.recipientId && employeeMap.has(exp.recipientId)) {
        currentName = employeeMap.get(exp.recipientId)!;
      } else if (exp.recipientType === 'supplier' && exp.recipientId && supplierMap.has(exp.recipientId)) {
        currentName = supplierMap.get(exp.recipientId)!;
      }

      if (currentName && currentName.trim() !== '' && currentName !== exp.recipientName) {
        hasChanges = true;
        return { ...exp, recipientName: currentName };
      }
      return exp;
    });

    if (hasChanges) {
      setExpenses(updatedExpenses);
    }
  }, [workers, employees, suppliers]);

  // Watch for changes to persist to LocalStorage (as fallback with backup)
  useEffect(() => {
    safeLocalStorageSet('site_budget', JSON.stringify(budget));
  }, [budget]);

  useEffect(() => {
    safeLocalStorageSet('site_workers', JSON.stringify(workers));
    if (workers.length > 0) {
      safeLocalStorageSet('site_workers_backup', JSON.stringify(workers));
    }
  }, [workers]);

  useEffect(() => {
    safeLocalStorageSet('site_employees', JSON.stringify(employees));
    if (employees.length > 0) {
      safeLocalStorageSet('site_employees_backup', JSON.stringify(employees));
    }
  }, [employees]);

  useEffect(() => {
    safeLocalStorageSet('site_suppliers', JSON.stringify(suppliers));
  }, [suppliers]);

  useEffect(() => {
    safeLocalStorageSet('site_expenses', JSON.stringify(expenses));
  }, [expenses]);

  useEffect(() => {
    safeLocalStorageSet('site_currency', currency);
  }, [currency]);

  // Handle name saving
  const handleSaveUserName = () => {
    if (!tempUserName.trim()) {
      alert('الرجاء إدخال اسمك للانضمام للحساب المشترك');
      return;
    }
    const cleanName = tempUserName.trim();
    localStorage.setItem('site_user_name', cleanName);
    setUserName(cleanName);
    setPromptUserName(false);
  };

  // Generate shareable link callback
  const handleCreateShareLink = async (role: 'read' | 'add' | 'full' = 'full') => {
    if (sharedRole !== 'owner') {
      alert("صلاحية المشاركة مع اخرين تتم فقط بواسطة المهندس/ياسر عقيل للتواصل 771999911");
      return null;
    }
    try {
      // Pre-share safety backup
      try {
        const snapshot = {
          timestamp: new Date().toISOString(),
          budget,
          workers,
          employees,
          suppliers,
          expenses,
          projectName,
          currency
        };
        localStorage.setItem('_pre_cloud_sync_safety_backup', JSON.stringify(snapshot));
      } catch (e) {}

      setSyncStatus('loading');

      let targetProjectId = projectId;

      if (!targetProjectId) {
        const activeProj = projects.find(p => p.id === activeProjectId);
        if (activeProj?.syncProjectId) {
          targetProjectId = activeProj.syncProjectId;
        }
      }

      if (targetProjectId) {
        // Update existing cloud project on server
        const res = await fetch(`/api/projects/${targetProjectId}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ budget, workers, employees, suppliers, expenses, projectName, currency })
        });

        if (res.ok) {
          setProjectId(targetProjectId);
          setSharedRole('owner');
          hasLoadedRemoteRef.current = true;
          setLastSyncedAt(new Date().toISOString());
          setSyncStatus('success');

          window.history.replaceState({}, '', `?project=${targetProjectId}&role=owner`);

          // Update active project's syncProjectId in projects list
          setProjects(prev => prev.map(p => (p.id === activeProjectId || p.id === targetProjectId) ? { ...p, syncProjectId: targetProjectId } : p));

          return `${window.location.origin}${window.location.pathname}?project=${targetProjectId}&role=${role}`;
        }
      }

      // Create a brand new cloud project on server
      const res = await fetch('/api/projects/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ budget, workers, employees, suppliers, expenses, projectName, currency })
      });

      if (res.ok) {
        const data = await res.json();
        const newId = data.projectId;
        setProjectId(newId);
        setSharedRole('owner');
        hasLoadedRemoteRef.current = true;
        setLastSyncedAt(new Date().toISOString());
        setSyncStatus('success');

        window.history.replaceState({}, '', `?project=${newId}&role=owner`);

        // Update active project's syncProjectId in projects list
        setProjects(prev => prev.map(p => p.id === activeProjectId ? { ...p, syncProjectId: newId } : p));

        return `${window.location.origin}${window.location.pathname}?project=${newId}&role=${role}`;
      } else {
        setSyncStatus('error');
        return null;
      }
    } catch (err: any) {
      setSyncStatus('error');
      return null;
    }
  };

  // Cancel Cloud Sync callback
  const handleCancelCloudSync = async () => {
    if (!projectId) return;
    if (sharedRole !== 'owner') {
      alert("إلغاء المزامنة السحابية متاح فقط لمالك المشروع الرئيسي.");
      return;
    }
    try {
      setSyncStatus('loading');
      await fetch(`/api/projects/${projectId}/cancel-sync`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      });
    } catch (err: any) {
      // Gracefully handle cancel request network error
    }
    // Unlink syncProjectId from projects list
    setProjects(prev => prev.map(p => p.syncProjectId === projectId ? { ...p, syncProjectId: null } : p));
    setProjectId(null);
    hasLoadedRemoteRef.current = false;
    setSharedRole('owner');
    setSyncStatus('idle');
    window.history.replaceState({}, '', window.location.pathname);
    alert('تم إلغاء المزامنة السحابية وتعطيل جميع روابط الدعوة الخاصة بهذا المشروع بنجاح. أصبحت جميع الروابط السابقة غير صالحة والوصول من خلالها محالاً.');
  };


  // =================================== ACTION HANDLERS ===================================

  const getActorName = () => (sharedRole === 'owner' ? 'مالك المشروع' : (userName || 'مشارك'));

  // Add Expense & Post to Ledger if recipient is selected
  const handleAddExpense = (expenseData: Omit<Expense, 'id'>) => {
    const newId = 'exp_' + Date.now().toString();
    const phoneToday = getTodayDateString();
    const newExpense: Expense = {
      ...expenseData,
      id: newId,
      recordedDate: expenseData.recordedDate || phoneToday,
      createdBy: getActorName()
    };

    setExpenses(prev => [newExpense, ...prev]);

    // Check if we need to post copy to recipient's ledger
    if (newExpense.recipientId && newExpense.recipientType !== 'none') {
      const postedLedgerEntry: LedgerEntry = {
        id: 'posted_' + newId,
        date: newExpense.date,
        amountOnHim: newExpense.amount, // المبلغ عليه
        amountForHim: 0,
        description: newExpense.description,
        notes: newExpense.notes,
        isPosted: true,
        currency: newExpense.currency || 'YER',
        createdBy: getActorName()
      };

      if (newExpense.recipientType === 'worker') {
        setWorkers(prevWorkers => 
          prevWorkers.map(w => 
            w.id === newExpense.recipientId 
              ? { ...w, ledger: [postedLedgerEntry, ...w.ledger] }
              : w
          )
        );
      } else if (newExpense.recipientType === 'employee') {
        setEmployees(prevEmployees => 
          prevEmployees.map(emp => 
            emp.id === newExpense.recipientId 
              ? { ...emp, ledger: [postedLedgerEntry, ...emp.ledger] }
              : emp
          )
        );
      } else if (newExpense.recipientType === 'supplier') {
        setSuppliers(prevSuppliers => 
          prevSuppliers.map(s => 
            s.id === newExpense.recipientId 
              ? { ...s, ledger: [postedLedgerEntry, ...s.ledger] }
              : s
          )
        );
      }
    }
  };

  // Delete Expense & Revert/Clean ledger posting if any
  const handleDeleteExpense = (id: string) => {
    const target = expenses.find(exp => exp.id === id);
    if (target) {
      pushUndoItem({
        category: 'expenses',
        categoryLabel: 'المصروفات اليومية',
        actionType: 'delete',
        actionLabel: 'حذف سند صرف',
        title: `سند صرف: ${target.description || 'بدون بيان'}`,
        details: [
          { label: 'المبلغ', value: `${Number(target.amount).toLocaleString()} ${target.currency || currency}` },
          { label: 'المستفيد', value: target.recipientName || 'غير محدد' },
          { label: 'التاريخ', value: target.date || '' },
          { label: 'البيان', value: target.description || 'بدون بيان' }
        ],
        projectId: activeProjectId,
        projectName: projectName,
        payload: { type: 'expense_delete', data: target }
      });
    }

    if (target && target.recipientId && target.recipientType !== 'none') {
      const postedId = 'posted_' + id;
      const altWledId = id.replace('exp_', 'wled_');
      const altEledId = id.replace('exp_', 'eled_');
      const altSledId = id.replace('exp_', 'sled_');

      const filterLedger = (ledger: LedgerEntry[]) => ledger.filter(e => {
        if (e.id === postedId || e.id === id || e.id === altWledId || e.id === altEledId || e.id === altSledId) {
          return false;
        }
        if (e.isPosted && e.date === target.date) {
          const amt = e.amountOnHim > 0 ? e.amountOnHim : e.amountForHim;
          if (amt === target.amount) return false;
        }
        return true;
      });

      if (target.recipientType === 'worker') {
        setWorkers(prevWorkers => 
          prevWorkers.map(w => 
            w.id === target.recipientId 
              ? { ...w, ledger: filterLedger(w.ledger) }
              : w
          )
        );
      } else if (target.recipientType === 'employee') {
        setEmployees(prevEmployees => 
          prevEmployees.map(emp => 
            emp.id === target.recipientId 
              ? { ...emp, ledger: filterLedger(emp.ledger) }
              : emp
          )
        );
      } else if (target.recipientType === 'supplier') {
        setSuppliers(prevSuppliers => 
          prevSuppliers.map(s => 
            s.id === target.recipientId 
              ? { ...s, ledger: filterLedger(s.ledger) }
              : s
          )
        );
      }
    }
    setExpenses(prev => prev.filter(exp => exp.id !== id));
  };

  // Add Worker
  const handleAddWorker = (workerData: Omit<Worker, 'id' | 'ledger'>) => {
    const newWorker: Worker = {
      ...workerData,
      id: 'worker_' + Date.now().toString(),
      ledger: [],
      createdBy: getActorName()
    };
    setWorkers(prev => [newWorker, ...prev]);
    return newWorker;
  };

  // Delete Worker & Clean up expenses referencing this worker
  const handleDeleteWorker = (workerId: string) => {
    const target = workers.find(w => w.id === workerId);
    if (target) {
      pushUndoItem({
        category: 'workers',
        categoryLabel: 'العمال وكشف الحساب',
        actionType: 'delete',
        actionLabel: 'حذف عامل',
        title: `العامل: ${target.name}`,
        details: [
          { label: 'اسم العامل', value: target.name },
          { label: 'المهنة', value: target.profession || 'غير محدد' },
          { label: 'عدد الحركات', value: `${target.ledger?.length || 0} حركة` }
        ],
        projectId: activeProjectId,
        projectName: projectName,
        payload: { type: 'worker_delete', data: target }
      });
    }

    setWorkers(prev => prev.filter(w => w.id !== workerId));
    
    // Safety cleanup: set deleted worker name but detach reference
    setExpenses(prevExpenses => 
      prevExpenses.map(exp => 
        exp.recipientId === workerId && exp.recipientType === 'worker'
          ? { ...exp, recipientId: '', recipientType: 'none', recipientName: `${exp.recipientName} (محذوف)` }
          : exp
      )
    );
  };

  // Add Manual Worker Ledger Entry
  const handleAddWorkerLedgerEntry = (workerId: string, entryData: Omit<LedgerEntry, 'id'>) => {
    const entryId = 'wled_' + Date.now().toString();
    const newEntry: LedgerEntry = {
      ...entryData,
      id: entryId,
      createdBy: getActorName()
    };

    setWorkers(prev => 
      prev.map(w => 
        w.id === workerId 
          ? { ...w, ledger: [newEntry, ...w.ledger] }
          : w
      )
    );
  };

  // Delete Worker Ledger Entry
  const handleDeleteWorkerLedgerEntry = (workerId: string, entryId: string) => {
    const worker = workers.find(w => w.id === workerId);
    const targetEntry = worker?.ledger.find(e => e.id === entryId);

    if (worker && targetEntry) {
      pushUndoItem({
        category: 'workers',
        categoryLabel: 'العمال وكشف الحساب',
        actionType: 'delete',
        actionLabel: 'حذف حركة كشف حساب عامل',
        title: `حركة للعامل (${worker.name}): ${targetEntry.description || 'حركة حساب'}`,
        details: [
          { label: 'العامل', value: worker.name },
          { label: 'له', value: `${Number(targetEntry.amountForHim).toLocaleString()} ${currency}` },
          { label: 'عليه', value: `${Number(targetEntry.amountOnHim).toLocaleString()} ${currency}` },
          { label: 'التاريخ', value: targetEntry.date }
        ],
        projectId: activeProjectId,
        projectName: projectName,
        payload: { type: 'worker_ledger_delete', data: { workerId, entry: targetEntry } }
      });
    }

    setWorkers(prev => 
      prev.map(w => {
        if (w.id !== workerId) return w;
        const updatedLedger = w.ledger.filter(e => e.id !== entryId);
        return {
          ...w,
          updatedBy: getActorName(),
          ledger: updatedLedger
        };
      })
    );

    // Only delete from daily expenses if this entry was originally posted from daily expenses
    if (entryId.startsWith('posted_') || entryId.startsWith('exp_') || targetEntry?.isPosted) {
      const expenseId = entryId.startsWith('posted_') ? entryId.replace('posted_', '') : entryId;
      setExpenses(prev => prev.filter(exp => exp.id !== expenseId));
    }
  };

  // Add Nutrition Period for Worker
  const handleAddWorkerNutritionPeriod = (workerId: string, nutritionData: Omit<NutritionPeriod, 'id'>) => {
    const nutrId = 'nutr_' + Date.now().toString();
    const newPeriod: NutritionPeriod = {
      ...nutritionData,
      id: nutrId,
      createdBy: getActorName()
    };

    setWorkers(prev => 
      prev.map(w => {
        if (w.id !== workerId) return w;
        const updatedWorker = {
          ...w,
          updatedBy: getActorName(),
          nutritionPeriods: [...(w.nutritionPeriods || []), newPeriod]
        };
        return syncWorkerNutritionLedger(updatedWorker);
      })
    );
  };

  // Update Nutrition Period for Worker
  const handleUpdateWorkerNutritionPeriod = (workerId: string, nutritionId: string, updatedData: Partial<Omit<NutritionPeriod, 'id'>>) => {
    setWorkers(prev => 
      prev.map(w => {
        if (w.id !== workerId) return w;
        const updatedPeriods = (w.nutritionPeriods || []).map(np => 
          np.id === nutritionId ? { ...np, ...updatedData, updatedBy: getActorName() } : np
        );
        const updatedWorker = {
          ...w,
          updatedBy: getActorName(),
          nutritionPeriods: updatedPeriods
        };
        return syncWorkerNutritionLedger(updatedWorker);
      })
    );
  };

  // Delete Nutrition Period for Worker
  const handleDeleteWorkerNutritionPeriod = (workerId: string, nutritionId: string) => {
    setWorkers(prev => 
      prev.map(w => {
        if (w.id !== workerId) return w;
        const updatedPeriods = (w.nutritionPeriods || []).filter(np => np.id !== nutritionId);
        const updatedLedger = w.ledger.filter(e => e.nutritionPeriodId !== nutritionId && e.id !== `nutr_entry_${nutritionId}`);
        const updatedWorker = {
          ...w,
          updatedBy: getActorName(),
          nutritionPeriods: updatedPeriods,
          ledger: updatedLedger
        };
        return syncWorkerNutritionLedger(updatedWorker);
      })
    );
  };

  // Add Extra Period for Worker
  const handleAddWorkerExtraPeriod = (workerId: string, startDate: string, endDate: string) => {
    setWorkers(prev => 
      prev.map(w => 
        w.id === workerId 
          ? { 
              ...w, 
              updatedBy: getActorName(),
              extraPeriods: [
                ...(w.extraPeriods || []),
                {
                  id: 'period_' + Date.now().toString(),
                  startDate,
                  endDate
                }
              ] 
            }
          : w
      )
    );
  };

  // Delete Extra Period for Worker
  const handleDeleteWorkerExtraPeriod = (workerId: string, periodId: string) => {
    setWorkers(prev => 
      prev.map(w => 
        w.id === workerId 
          ? { 
              ...w, 
              updatedBy: getActorName(),
              extraPeriods: (w.extraPeriods || []).filter(p => p.id !== periodId) 
            }
          : w
      )
    );
  };

  // =================================== EMPLOYEE HANDLERS ===================================

  // Add Employee
  const handleAddEmployee = (employeeData: Omit<Employee, 'id' | 'ledger'>) => {
    const empId = 'emp_' + Date.now().toString();
    const wageCurrency = employeeData.dailyWageCurrency || currency || 'YER';

    const newEmployee: Employee = {
      ...employeeData,
      dailyWageCurrency: wageCurrency,
      id: empId,
      ledger: [],
      createdBy: getActorName()
    };
    const syncedEmployee = syncEmployeeAllLedgers(newEmployee, sharedRole === 'owner');
    setEmployees(prev => [syncedEmployee, ...prev]);
    return syncedEmployee;
  };

  // Delete Employee & Clean up expenses
  const handleDeleteEmployee = (employeeId: string) => {
    const target = employees.find(e => e.id === employeeId);
    if (target) {
      pushUndoItem({
        category: 'employees',
        categoryLabel: 'الموظفون والأجور',
        actionType: 'delete',
        actionLabel: 'حذف موظف',
        title: `الموظف: ${target.name}`,
        details: [
          { label: 'المسمى الوظيفي', value: target.profession || 'غير محدد' },
          { label: 'الأجر اليومي', value: `${target.dailyWage || 0} ${currency}` },
          { label: 'عدد الحركات', value: `${target.ledger?.length || 0} حركة` }
        ],
        projectId: activeProjectId,
        projectName: projectName,
        payload: { type: 'employee_delete', data: target }
      });
    }

    setEmployees(prev => prev.filter(e => e.id !== employeeId));
    setExpenses(prevExpenses => 
      prevExpenses.map(exp => 
        exp.recipientId === employeeId && exp.recipientType === 'employee'
          ? { ...exp, recipientId: '', recipientType: 'none', recipientName: `${exp.recipientName} (محذوف)` }
          : exp
      )
    );
  };

  // Update Employee
  const handleUpdateEmployee = (employeeId: string, updatedData: Partial<Omit<Employee, 'id' | 'ledger'>>) => {
    const oldEmp = employees.find(e => e.id === employeeId);
    if (oldEmp) {
      pushUndoItem({
        category: 'employees',
        categoryLabel: 'الموظفون والأجور',
        actionType: 'update',
        actionLabel: 'تعديل بيانات موظف',
        title: `الموظف: ${oldEmp.name}`,
        details: [
          { label: 'الاسم السابق', value: oldEmp.name },
          { label: 'المسمى السابق', value: oldEmp.profession || 'غير محدد' },
          { label: 'الأجر اليومي السابق', value: `${oldEmp.dailyWage || 0} ${currency}` }
        ],
        projectId: activeProjectId,
        projectName: projectName,
        payload: { type: 'employee_update', data: oldEmp }
      });
    }

    const oldName = oldEmp?.name;
    setEmployees(prev => 
      prev.map(e => {
        if (e.id !== employeeId) return e;
        const updated = { 
          ...e, 
          ...updatedData, 
          updatedBy: getActorName(),
          // When daily wage, periods or work data are updated, ensure auto calculation is active and exclusion cleared
          disableAutoSalaryCalculation: false,
          excludedSalaryMonthKeys: []
        };
        return syncEmployeeAllLedgers(updated, sharedRole === 'owner', true);
      })
    );

    // Propagate new employee name to all associated financial operations / daily expenses
    if (updatedData.name && updatedData.name.trim() !== '') {
      const newName = updatedData.name.trim();
      setExpenses(prev => 
        prev.map(exp => {
          const matchesId = exp.recipientId === employeeId && exp.recipientType === 'employee';
          const matchesName = exp.recipientType === 'employee' && Boolean(oldName) && exp.recipientName === oldName;
          if (matchesId || matchesName) {
            return {
              ...exp,
              recipientName: newName,
              recipientId: exp.recipientId || employeeId,
              updatedBy: getActorName()
            };
          }
          return exp;
        })
      );
    }
  };

  // Add Manual Employee Ledger Entry
  const handleAddEmployeeLedgerEntry = (employeeId: string, entryData: Omit<LedgerEntry, 'id'> & { id?: string }) => {
    const entryId = entryData.id || ('eled_' + Date.now().toString() + '_' + Math.random().toString(36).substring(2, 6));
    const newEntry: LedgerEntry = {
      ...entryData,
      id: entryId,
      createdBy: getActorName()
    };

    setEmployees(prev => 
      prev.map(e => 
        e.id === employeeId 
          ? { ...e, ledger: [newEntry, ...e.ledger] }
          : e
      )
    );
  };

  // Delete Employee Ledger Entry
  const handleDeleteEmployeeLedgerEntry = (employeeId: string, entryId: string, isUserAction: boolean = true) => {
    const employee = employees.find(e => e.id === employeeId);
    const targetEntry = employee?.ledger.find(e => e.id === entryId);

    if (employee && targetEntry && isUserAction) {
      pushUndoItem({
        category: 'employees',
        categoryLabel: 'الموظفون والأجور',
        actionType: 'delete',
        actionLabel: 'حذف حركة كشف حساب موظف',
        title: `حركة للموظف (${employee.name}): ${targetEntry.description || 'حركة حساب'}`,
        details: [
          { label: 'الموظف', value: employee.name },
          { label: 'له', value: `${Number(targetEntry.amountForHim).toLocaleString()} ${currency}` },
          { label: 'عليه', value: `${Number(targetEntry.amountOnHim).toLocaleString()} ${currency}` },
          { label: 'التاريخ', value: targetEntry.date }
        ],
        projectId: activeProjectId,
        projectName: projectName,
        payload: { type: 'employee_ledger_delete', data: { employeeId, entry: targetEntry } }
      });
    }

    // If deleting an auto monthly salary or daily wage entry explicitly by the user, prevent auto loop from re-generating it until next edit
    let salaryMonthKeyToDelete: string | null = null;
    let isDailyWageToDelete = false;
    if (isUserAction) {
      if (targetEntry?.salaryMonthKey) {
        salaryMonthKeyToDelete = targetEntry.salaryMonthKey;
      } else if (entryId.startsWith(`auto_salary_${employeeId}_`)) {
        salaryMonthKeyToDelete = entryId.replace(`auto_salary_${employeeId}_`, '');
      } else if (entryId.startsWith('auto_salary_')) {
        const parts = entryId.split('_');
        if (parts.length >= 4) {
          salaryMonthKeyToDelete = parts.slice(3).join('_');
        }
      } else if (targetEntry?.isAutoMonthlySalary && targetEntry.date) {
        salaryMonthKeyToDelete = targetEntry.date.substring(0, 7);
      } else if (targetEntry?.isAutoDailyWage || entryId === `auto_wage_${employeeId}` || entryId.startsWith('auto_wage_')) {
        isDailyWageToDelete = true;
      }
    }

    setEmployees(prev => 
      prev.map(e => {
        if (e.id !== employeeId) return e;
        const updatedLedger = e.ledger.filter(entry => entry.id !== entryId);
        
        let updatedExcludedKeys = [...(e.excludedSalaryMonthKeys || [])];
        if (salaryMonthKeyToDelete && !updatedExcludedKeys.includes(salaryMonthKeyToDelete)) {
          updatedExcludedKeys.push(salaryMonthKeyToDelete);
        }
        if (isDailyWageToDelete && !updatedExcludedKeys.includes('daily_wage')) {
          updatedExcludedKeys.push('daily_wage');
        }

        const updatedEmployee = {
          ...e,
          updatedBy: getActorName(),
          ledger: updatedLedger,
          excludedSalaryMonthKeys: updatedExcludedKeys,
          disableAutoSalaryCalculation: isDailyWageToDelete ? true : e.disableAutoSalaryCalculation
        };
        return updatedEmployee;
      })
    );

    // Only delete from daily expenses if this entry was originally posted from daily expenses
    if (entryId.startsWith('posted_') || entryId.startsWith('exp_') || targetEntry?.isPosted) {
      const expenseId = entryId.startsWith('posted_') ? entryId.replace('posted_', '') : entryId;
      setExpenses(prev => prev.filter(exp => exp.id !== expenseId));
    }
  };

  // Add Nutrition Period for Employee
  const handleAddEmployeeNutritionPeriod = (employeeId: string, nutritionData: Omit<NutritionPeriod, 'id'>) => {
    const nutrId = 'nutr_' + Date.now().toString();
    const newPeriod: NutritionPeriod = {
      ...nutritionData,
      id: nutrId,
      createdBy: getActorName()
    };

    setEmployees(prev => 
      prev.map(e => {
        if (e.id !== employeeId) return e;
        const updatedEmployee = {
          ...e,
          updatedBy: getActorName(),
          nutritionPeriods: [...(e.nutritionPeriods || []), newPeriod]
        };
        return syncEmployeeNutritionLedger(updatedEmployee);
      })
    );
  };

  // Update Nutrition Period for Employee
  const handleUpdateEmployeeNutritionPeriod = (employeeId: string, nutritionId: string, updatedData: Partial<Omit<NutritionPeriod, 'id'>>) => {
    setEmployees(prev => 
      prev.map(e => {
        if (e.id !== employeeId) return e;
        const updatedPeriods = (e.nutritionPeriods || []).map(np => 
          np.id === nutritionId ? { ...np, ...updatedData, updatedBy: getActorName() } : np
        );
        const updatedEmployee = {
          ...e,
          updatedBy: getActorName(),
          nutritionPeriods: updatedPeriods
        };
        return syncEmployeeNutritionLedger(updatedEmployee);
      })
    );
  };

  // Delete Nutrition Period for Employee
  const handleDeleteEmployeeNutritionPeriod = (employeeId: string, nutritionId: string) => {
    setEmployees(prev => 
      prev.map(e => {
        if (e.id !== employeeId) return e;
        const updatedPeriods = (e.nutritionPeriods || []).filter(np => np.id !== nutritionId);
        const updatedLedger = e.ledger.filter(entry => entry.nutritionPeriodId !== nutritionId && entry.id !== `nutr_entry_${nutritionId}`);
        const updatedEmployee = {
          ...e,
          updatedBy: getActorName(),
          nutritionPeriods: updatedPeriods,
          ledger: updatedLedger
        };
        return syncEmployeeNutritionLedger(updatedEmployee);
      })
    );
  };

  // Update Employee Ledger Entry
  const handleUpdateEmployeeLedgerEntry = (employeeId: string, entryId: string, updatedData: Omit<LedgerEntry, 'id' | 'createdBy'>) => {
    setEmployees(prev => 
      prev.map(e => {
        if (e.id !== employeeId) return e;
        const targetEntry = e.ledger.find(entry => entry.id === entryId);
        const isAutoWage = targetEntry?.isAutoDailyWage || entryId.startsWith('auto_wage_');

        let updatedEmployee: Employee = { 
          ...e, 
          ledger: e.ledger.map(entry => entry.id === entryId ? { ...entry, ...updatedData, updatedBy: getActorName() } : entry) 
        };

        // If the user modified the auto-wage entry directly, synchronize employee dailyWage if amount changed
        if (isAutoWage && (e.wageType || 'daily') === 'daily') {
          const mainDays = calculateDaysOfWork(e.startDate, e.endDate, sharedRole === 'owner');
          const extraDays = (e.extraPeriods || []).reduce((sum, p) => sum + calculateDaysOfWork(p.startDate, p.endDate, sharedRole === 'owner'), 0);
          const totalDays = mainDays + extraDays;
          if (totalDays > 0 && updatedData.amountForHim > 0 && Math.round(updatedData.amountForHim) !== Math.round((e.dailyWage || 0) * totalDays)) {
            updatedEmployee.dailyWage = Math.round((updatedData.amountForHim / totalDays) * 100) / 100;
          }
          if (updatedData.currency) {
            updatedEmployee.dailyWageCurrency = updatedData.currency;
          }
        }

        return syncEmployeeAllLedgers(updatedEmployee, sharedRole === 'owner');
      })
    );

    // Only sync to expenses if this entry was posted from daily expenses
    if (entryId.startsWith('posted_') || entryId.startsWith('exp_')) {
      const expenseId = entryId.startsWith('posted_') ? entryId.replace('posted_', '') : entryId;
      const cleanDesc = updatedData.description.replace(/\s*\(مرحّل من النفقات اليومية\)\s*/g, '').trim();
      const expenseAmt = updatedData.amountOnHim > 0 ? updatedData.amountOnHim : updatedData.amountForHim;

      setExpenses(prev => prev.map(exp => {
        if (exp.id === expenseId) {
          return {
            ...exp,
            date: updatedData.date,
            amount: expenseAmt,
            description: cleanDesc,
            notes: updatedData.notes || '',
            currency: updatedData.currency || exp.currency || 'YER',
            updatedBy: getActorName()
          };
        }
        return exp;
      }));
    }
  };

  // Add Extra Period for Employee
  const handleAddEmployeeExtraPeriod = (employeeId: string, startDate: string, endDate: string) => {
    setEmployees(prev => 
      prev.map(e => {
        if (e.id !== employeeId) return e;
        const updated = { 
          ...e, 
          updatedBy: getActorName(),
          disableAutoSalaryCalculation: false,
          excludedSalaryMonthKeys: [],
          extraPeriods: [
            ...(e.extraPeriods || []),
            {
              id: 'period_' + Date.now().toString(),
              startDate,
              endDate
            }
          ] 
        };
        return syncEmployeeAllLedgers(updated, sharedRole === 'owner', true);
      })
    );
  };

  // Update Extra Period for Employee
  const handleUpdateEmployeeExtraPeriod = (employeeId: string, periodId: string, startDate: string, endDate: string) => {
    setEmployees(prev => 
      prev.map(e => {
        if (e.id !== employeeId) return e;
        const updatedPeriods = (e.extraPeriods || []).map(p =>
          p.id === periodId ? { ...p, startDate, endDate } : p
        );
        const updated = { 
          ...e, 
          updatedBy: getActorName(),
          disableAutoSalaryCalculation: false,
          excludedSalaryMonthKeys: [],
          extraPeriods: updatedPeriods
        };
        return syncEmployeeAllLedgers(updated, sharedRole === 'owner', true);
      })
    );
  };

  // Delete Extra Period for Employee
  const handleDeleteEmployeeExtraPeriod = (employeeId: string, periodId: string) => {
    setEmployees(prev => 
      prev.map(e => {
        if (e.id !== employeeId) return e;
        const updated = { 
          ...e, 
          updatedBy: getActorName(),
          disableAutoSalaryCalculation: false,
          excludedSalaryMonthKeys: [],
          extraPeriods: (e.extraPeriods || []).filter(p => p.id !== periodId) 
        };
        return syncEmployeeAllLedgers(updated, sharedRole === 'owner', true);
      })
    );
  };

  // Transfer Worker -> Employee
  const handleTransferWorkerToEmployee = (worker: Worker) => {
    const workerId = worker.id;
    const newEmployee: Employee = {
      id: worker.id,
      name: worker.name,
      profession: worker.profession,
      dailyWage: 0,
      startDate: worker.startDate,
      endDate: worker.endDate,
      phoneNumbers: worker.phoneNumbers || [],
      ledger: worker.ledger,
      extraPeriods: worker.extraPeriods || [],
      nutritionPeriods: worker.nutritionPeriods || [],
      createdBy: worker.createdBy || getActorName()
    };

    setWorkers(prev => prev.filter(w => w.id !== workerId));
    setEmployees(prev => [newEmployee, ...prev]);

    setExpenses(prev => 
      prev.map(exp => 
        exp.recipientId === workerId && exp.recipientType === 'worker'
          ? { ...exp, recipientType: 'employee' }
          : exp
      )
    );
  };

  // Transfer Employee -> Worker
  const handleTransferEmployeeToWorker = (employee: Employee) => {
    const employeeId = employee.id;
    const newWorker: Worker = {
      id: employee.id,
      name: employee.name,
      profession: employee.profession,
      startDate: employee.startDate,
      endDate: employee.endDate,
      phoneNumbers: employee.phoneNumbers || [],
      ledger: employee.ledger,
      extraPeriods: employee.extraPeriods || [],
      nutritionPeriods: employee.nutritionPeriods || [],
      createdBy: employee.createdBy || getActorName()
    };

    setEmployees(prev => prev.filter(e => e.id !== employeeId));
    setWorkers(prev => [newWorker, ...prev]);

    setExpenses(prev => 
      prev.map(exp => 
        exp.recipientId === employeeId && exp.recipientType === 'employee'
          ? { ...exp, recipientType: 'worker' }
          : exp
      )
    );
  };

  // Add Supplier
  const handleAddSupplier = (supplierData: Omit<Supplier, 'id' | 'ledger'>) => {
    const newSupplier: Supplier = {
      ...supplierData,
      id: 'supplier_' + Date.now().toString(),
      ledger: [],
      createdBy: getActorName()
    };
    setSuppliers(prev => [newSupplier, ...prev]);
    return newSupplier;
  };

  // Delete Supplier & Clean up expenses referencing this supplier
  const handleDeleteSupplier = (supplierId: string) => {
    const target = suppliers.find(s => s.id === supplierId);
    if (target) {
      pushUndoItem({
        category: 'suppliers',
        categoryLabel: 'الموردون والمشتريات',
        actionType: 'delete',
        actionLabel: 'حذف مورد',
        title: `المورد: ${target.name}`,
        details: [
          { label: 'اسم المورد', value: target.name },
          { label: 'المجال / الصنف', value: target.materialType || target.material || 'غير محدد' },
          { label: 'عدد الحركات', value: `${target.ledger?.length || 0} حركة` }
        ],
        projectId: activeProjectId,
        projectName: projectName,
        payload: { type: 'supplier_delete', data: target }
      });
    }

    setSuppliers(prev => prev.filter(s => s.id !== supplierId));

    // Safety cleanup: set deleted supplier name but detach reference
    setExpenses(prevExpenses => 
      prevExpenses.map(exp => 
        exp.recipientId === supplierId && exp.recipientType === 'supplier'
          ? { ...exp, recipientId: '', recipientType: 'none', recipientName: `${exp.recipientName} (محذوف)` }
          : exp
      )
    );
  };

  // Add Manual Supplier Ledger Entry
  const handleAddSupplierLedgerEntry = (supplierId: string, entryData: Omit<LedgerEntry, 'id'>) => {
    const entryId = 'sled_' + Date.now().toString();
    const newEntry: LedgerEntry = {
      ...entryData,
      id: entryId,
      createdBy: getActorName()
    };

    setSuppliers(prev => 
      prev.map(s => 
        s.id === supplierId 
          ? { ...s, ledger: [newEntry, ...s.ledger] }
          : s
      )
    );
  };

  // Delete Supplier Ledger Entry
  const handleDeleteSupplierLedgerEntry = (supplierId: string, entryId: string) => {
    const supplier = suppliers.find(s => s.id === supplierId);
    const targetEntry = supplier?.ledger.find(e => e.id === entryId);

    if (supplier && targetEntry) {
      pushUndoItem({
        category: 'suppliers',
        categoryLabel: 'الموردون والمشتريات',
        actionType: 'delete',
        actionLabel: 'حذف حركة كشف حساب مورد',
        title: `حركة للمورد (${supplier.name}): ${targetEntry.description || 'حركة حساب'}`,
        details: [
          { label: 'المورد', value: supplier.name },
          { label: 'له', value: `${Number(targetEntry.amountForHim).toLocaleString()} ${currency}` },
          { label: 'عليه', value: `${Number(targetEntry.amountOnHim).toLocaleString()} ${currency}` },
          { label: 'التاريخ', value: targetEntry.date }
        ],
        projectId: activeProjectId,
        projectName: projectName,
        payload: { type: 'supplier_ledger_delete', data: { supplierId, entry: targetEntry } }
      });
    }

    setSuppliers(prev => 
      prev.map(s => 
        s.id === supplierId 
          ? { ...s, ledger: s.ledger.filter(e => e.id !== entryId) }
          : s
      )
    );

    // Only delete from daily expenses if this entry was originally posted from daily expenses
    if (entryId.startsWith('posted_') || entryId.startsWith('exp_') || targetEntry?.isPosted) {
      const expenseId = entryId.startsWith('posted_') ? entryId.replace('posted_', '') : entryId;
      setExpenses(prev => prev.filter(exp => exp.id !== expenseId));
    }
  };

  // Add Budget Capital Item
  const handleAddBudgetItem = (itemData: Omit<BudgetItem, 'id'>) => {
    const newItem: BudgetItem = {
      ...itemData,
      id: 'bud_' + Date.now().toString(),
      createdBy: getActorName()
    };
    setBudget(prev => [newItem, ...prev]);
  };

  // Delete Budget Item
  const handleDeleteBudgetItem = (id: string) => {
    const target = budget.find(item => item.id === id);
    if (target) {
      pushUndoItem({
        category: 'budget',
        categoryLabel: 'الميزانية العامة والصندوق',
        actionType: 'delete',
        actionLabel: 'حذف بند تمويل',
        title: `بند تمويل: ${target.description}`,
        details: [
          { label: 'المبلغ', value: `${Number(target.amount).toLocaleString()} ${target.currency || currency}` },
          { label: 'التاريخ', value: target.date }
        ],
        projectId: activeProjectId,
        projectName: projectName,
        payload: { type: 'budget_delete', data: target }
      });
    }
    setBudget(prev => prev.filter(item => item.id !== id));
  };

  // Update Worker
  const handleUpdateWorker = (id: string, updatedData: Omit<Worker, 'id' | 'ledger' | 'createdBy'>) => {
    const oldWorker = workers.find(w => w.id === id);
    if (oldWorker) {
      pushUndoItem({
        category: 'workers',
        categoryLabel: 'العمال وكشف الحساب',
        actionType: 'update',
        actionLabel: 'تعديل بيانات عامل',
        title: `العامل: ${oldWorker.name}`,
        details: [
          { label: 'الاسم السابق', value: oldWorker.name },
          { label: 'المهنة السابقة', value: oldWorker.profession || 'غير محدد' }
        ],
        projectId: activeProjectId,
        projectName: projectName,
        payload: { type: 'worker_update', data: oldWorker }
      });
    }

    const oldName = oldWorker?.name;
    setWorkers(prev => prev.map(w => w.id === id ? { ...w, ...updatedData, updatedBy: getActorName() } : w));

    // Propagate new worker name to all associated financial operations / daily expenses
    if (updatedData.name && updatedData.name.trim() !== '') {
      const newName = updatedData.name.trim();
      setExpenses(prev => 
        prev.map(exp => {
          const matchesId = exp.recipientId === id && exp.recipientType === 'worker';
          const matchesName = exp.recipientType === 'worker' && Boolean(oldName) && exp.recipientName === oldName;
          if (matchesId || matchesName) {
            return {
              ...exp,
              recipientName: newName,
              recipientId: exp.recipientId || id,
              updatedBy: getActorName()
            };
          }
          return exp;
        })
      );
    }
  };

  // Update Worker Ledger Entry
  const handleUpdateWorkerLedgerEntry = (workerId: string, entryId: string, updatedEntryData: Omit<LedgerEntry, 'id' | 'createdBy'>) => {
    setWorkers(prev => prev.map(w => w.id === workerId ? {
      ...w,
      ledger: w.ledger.map(e => e.id === entryId ? { ...e, ...updatedEntryData, updatedBy: getActorName() } : e)
    } : w));

    // Only sync to expenses if this entry was posted from daily expenses
    if (entryId.startsWith('posted_') || entryId.startsWith('exp_')) {
      const expenseId = entryId.startsWith('posted_') ? entryId.replace('posted_', '') : entryId;
      const cleanDesc = updatedEntryData.description.replace(/\s*\(مرحّل من النفقات اليومية\)\s*/g, '').trim();
      const expenseAmt = updatedEntryData.amountOnHim > 0 ? updatedEntryData.amountOnHim : updatedEntryData.amountForHim;

      setExpenses(prev => prev.map(exp => {
        if (exp.id === expenseId) {
          return {
            ...exp,
            date: updatedEntryData.date,
            amount: expenseAmt,
            description: cleanDesc,
            notes: updatedEntryData.notes || '',
            currency: updatedEntryData.currency || exp.currency || 'YER',
            updatedBy: getActorName()
          };
        }
        return exp;
      }));
    }
  };

  // Update Supplier
  const handleUpdateSupplier = (id: string, updatedData: Omit<Supplier, 'id' | 'ledger' | 'createdBy'>) => {
    const oldSupplier = suppliers.find(s => s.id === id);
    if (oldSupplier) {
      pushUndoItem({
        category: 'suppliers',
        categoryLabel: 'الموردون والمشتريات',
        actionType: 'update',
        actionLabel: 'تعديل بيانات مورد',
        title: `المورد: ${oldSupplier.name}`,
        details: [
          { label: 'الاسم السابق', value: oldSupplier.name },
          { label: 'المجال السابق', value: oldSupplier.materialType || oldSupplier.material || 'غير محدد' }
        ],
        projectId: activeProjectId,
        projectName: projectName,
        payload: { type: 'supplier_update', data: oldSupplier }
      });
    }

    const oldName = oldSupplier?.name;
    setSuppliers(prev => prev.map(s => s.id === id ? { ...s, ...updatedData, updatedBy: getActorName() } : s));

    // Propagate new supplier name to all associated financial operations / daily expenses
    if (updatedData.name && updatedData.name.trim() !== '') {
      const newName = updatedData.name.trim();
      setExpenses(prev => 
        prev.map(exp => {
          const matchesId = exp.recipientId === id && exp.recipientType === 'supplier';
          const matchesName = exp.recipientType === 'supplier' && Boolean(oldName) && exp.recipientName === oldName;
          if (matchesId || matchesName) {
            return {
              ...exp,
              recipientName: newName,
              recipientId: exp.recipientId || id,
              updatedBy: getActorName()
            };
          }
          return exp;
        })
      );
    }
  };

  // Update Supplier Ledger Entry
  const handleUpdateSupplierLedgerEntry = (supplierId: string, entryId: string, updatedEntryData: Omit<LedgerEntry, 'id' | 'createdBy'>) => {
    setSuppliers(prev => prev.map(s => s.id === supplierId ? {
      ...s,
      ledger: s.ledger.map(e => e.id === entryId ? { ...e, ...updatedEntryData, updatedBy: getActorName() } : e)
    } : s));

    // Only sync to expenses if this entry was posted from daily expenses
    if (entryId.startsWith('posted_') || entryId.startsWith('exp_')) {
      const expenseId = entryId.startsWith('posted_') ? entryId.replace('posted_', '') : entryId;
      const cleanDesc = updatedEntryData.description.replace(/\s*\(مرحّل من النفقات اليومية\)\s*/g, '').trim();
      const expenseAmt = updatedEntryData.amountOnHim > 0 ? updatedEntryData.amountOnHim : updatedEntryData.amountForHim;

      setExpenses(prev => prev.map(exp => {
        if (exp.id === expenseId) {
          return {
            ...exp,
            date: updatedEntryData.date,
            amount: expenseAmt,
            description: cleanDesc,
            notes: updatedEntryData.notes || '',
            currency: updatedEntryData.currency || exp.currency || 'YER',
            updatedBy: getActorName()
          };
        }
        return exp;
      }));
    }
  };

  // 📋 Copy Ledger Entry from one account to another (Worker, Employee, Supplier)
  const handleCopyLedgerEntry = (
    sourceType: 'worker' | 'employee' | 'supplier',
    sourceId: string,
    entry: LedgerEntry,
    targetType: 'worker' | 'employee' | 'supplier',
    targetId: string
  ) => {
    // Determine target name
    let targetName = '';
    if (targetType === 'worker') {
      targetName = workers.find(w => w.id === targetId)?.name || 'عامل';
    } else if (targetType === 'employee') {
      targetName = employees.find(e => e.id === targetId)?.name || 'موظف';
    } else if (targetType === 'supplier') {
      targetName = suppliers.find(s => s.id === targetId)?.name || 'مورد';
    }

    const newEntryId = `${targetType[0]}led_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
    
    // Check if the entry is posted from daily expenses
    const isPosted = Boolean(entry.isPosted || entry.id.startsWith('posted_') || entry.id.startsWith('exp_'));

    let newExpenseId: string | null = null;
    if (isPosted) {
      newExpenseId = `exp_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
      const cleanDesc = (entry.description || '').replace(/\s*\(مرحّل من النفقات اليومية\)\s*/g, '').trim();
      const expenseAmount = entry.amountOnHim > 0 ? entry.amountOnHim : entry.amountForHim;

      const newExpense: Expense = {
        id: newExpenseId,
        date: entry.date,
        description: cleanDesc || 'دفعة/حركة منسوخة',
        amount: expenseAmount,
        category: targetType === 'worker' ? 'أجور عمال' : targetType === 'employee' ? 'رواتب موظفين' : 'مواد بناء وتوريدات',
        recipientType: targetType,
        recipientId: targetId,
        recipientName: targetName,
        currency: entry.currency || currency || 'YER',
        notes: entry.notes || `منسوخة من حركة حساب سابق`,
        recordedDate: getTodayDateString(),
        createdBy: getActorName()
      };

      setExpenses(prev => [newExpense, ...prev]);
    }

    const copiedEntry: LedgerEntry = {
      ...entry,
      id: isPosted && newExpenseId ? `posted_${newExpenseId}` : newEntryId,
      isPosted: isPosted,
      createdBy: getActorName(),
      updatedBy: undefined
    };

    // Add to target account
    if (targetType === 'worker') {
      setWorkers(prev => prev.map(w => w.id === targetId ? { ...w, ledger: [copiedEntry, ...w.ledger] } : w));
    } else if (targetType === 'employee') {
      setEmployees(prev => prev.map(e => e.id === targetId ? { ...e, ledger: [copiedEntry, ...e.ledger] } : e));
    } else if (targetType === 'supplier') {
      setSuppliers(prev => prev.map(s => s.id === targetId ? { ...s, ledger: [copiedEntry, ...s.ledger] } : s));
    }

    setToastMessage(`تم نسخ الحركة بنجاح إلى حساب ${targetName}`);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // 🔄 Move Ledger Entry from one account to another (Worker, Employee, Supplier)
  const handleMoveLedgerEntry = (
    sourceType: 'worker' | 'employee' | 'supplier',
    sourceId: string,
    entry: LedgerEntry,
    targetType: 'worker' | 'employee' | 'supplier',
    targetId: string
  ) => {
    // Determine target name
    let targetName = '';
    if (targetType === 'worker') {
      targetName = workers.find(w => w.id === targetId)?.name || 'عامل';
    } else if (targetType === 'employee') {
      targetName = employees.find(e => e.id === targetId)?.name || 'موظف';
    } else if (targetType === 'supplier') {
      targetName = suppliers.find(s => s.id === targetId)?.name || 'مورد';
    }

    // 1. Remove from source account
    if (sourceType === 'worker') {
      setWorkers(prev => prev.map(w => {
        if (w.id !== sourceId) return w;
        return {
          ...w,
          ledger: w.ledger.filter(e => e.id !== entry.id)
        };
      }));
    } else if (sourceType === 'employee') {
      setEmployees(prev => prev.map(e => {
        if (e.id !== sourceId) return e;
        return {
          ...e,
          ledger: e.ledger.filter(item => item.id !== entry.id)
        };
      }));
    } else if (sourceType === 'supplier') {
      setSuppliers(prev => prev.map(s => {
        if (s.id !== sourceId) return s;
        return {
          ...s,
          ledger: s.ledger.filter(e => e.id !== entry.id)
        };
      }));
    }

    // 2. Check if the entry is posted from daily expenses -> update the expense
    const isPosted = Boolean(entry.isPosted || entry.id.startsWith('posted_') || entry.id.startsWith('exp_'));
    if (isPosted) {
      const expenseId = entry.id.startsWith('posted_') ? entry.id.replace('posted_', '') : entry.id;
      setExpenses(prev => prev.map(exp => {
        if (exp.id === expenseId) {
          return {
            ...exp,
            recipientType: targetType,
            recipientId: targetId,
            recipientName: targetName,
            category: targetType === 'worker' ? 'أجور عمال' : targetType === 'employee' ? 'رواتب موظفين' : 'مواد بناء وتوريدات',
            updatedBy: getActorName()
          };
        }
        return exp;
      }));
    }

    // 3. Add to target account
    const movedEntry: LedgerEntry = {
      ...entry,
      updatedBy: getActorName()
    };

    if (targetType === 'worker') {
      setWorkers(prev => prev.map(w => w.id === targetId ? { ...w, ledger: [movedEntry, ...w.ledger] } : w));
    } else if (targetType === 'employee') {
      setEmployees(prev => prev.map(e => e.id === targetId ? { ...e, ledger: [movedEntry, ...e.ledger] } : e));
    } else if (targetType === 'supplier') {
      setSuppliers(prev => prev.map(s => s.id === targetId ? { ...s, ledger: [movedEntry, ...s.ledger] } : s));
    }

    setToastMessage(`تم نقل الحركة بنجاح إلى حساب ${targetName}`);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Update Expense & Handle Ledger sync
  const handleUpdateExpense = (id: string, updatedExpenseData: Omit<Expense, 'id' | 'createdBy'>) => {
    const oldExpense = expenses.find(exp => exp.id === id);
    if (!oldExpense) return;

    pushUndoItem({
      category: 'expenses',
      categoryLabel: 'المصروفات اليومية',
      actionType: 'update',
      actionLabel: 'تعديل سند صرف',
      title: `سند صرف: ${oldExpense.description || 'بدون بيان'}`,
      details: [
        { label: 'المبلغ السابق', value: `${Number(oldExpense.amount).toLocaleString()} ${oldExpense.currency || currency}` },
        { label: 'المستفيد السابق', value: oldExpense.recipientName || 'غير محدد' },
        { label: 'التاريخ السابق', value: oldExpense.date || '' }
      ],
      projectId: activeProjectId,
      projectName: projectName,
      payload: { type: 'expense_update', data: oldExpense }
    });

    const phoneToday = getTodayDateString();
    const updatedExpense: Expense = {
      ...oldExpense,
      ...updatedExpenseData,
      recordedDate: phoneToday, // تحديث تاريخ الإضافة/التعديل تلقائياً بحسب تاريخ الهاتف الحالي عند التعديل
      updatedBy: getActorName()
    };

    setExpenses(prev => prev.map(exp => exp.id === id ? updatedExpense : exp));

    const oldRecipientId = oldExpense.recipientId;
    const oldRecipientType = oldExpense.recipientType;
    const newRecipientId = updatedExpense.recipientId;
    const newRecipientType = updatedExpense.recipientType;

    const isSameRecipient = oldRecipientId === newRecipientId && oldRecipientType === newRecipientType;

    if (isSameRecipient && newRecipientId && newRecipientType !== 'none') {
      // Update entry in place in recipient ledger
      const updateLedgerInPlace = (ledger: LedgerEntry[]) => ledger.map(e => {
        const isMatch = e.id === 'posted_' + id || e.id === id || e.id === id.replace('exp_', 'wled_') || e.id === id.replace('exp_', 'eled_') || e.id === id.replace('exp_', 'sled_');
        if (isMatch) {
          return {
            ...e,
            date: updatedExpense.date,
            amountOnHim: updatedExpense.amount,
            amountForHim: 0,
            description: `${updatedExpense.description} (مرحّل من النفقات اليومية)`,
            notes: updatedExpense.notes || '',
            currency: updatedExpense.currency || 'YER',
            updatedBy: getActorName()
          };
        }
        return e;
      });

      if (newRecipientType === 'worker') {
        setWorkers(prev => prev.map(w => w.id === newRecipientId ? { ...w, ledger: updateLedgerInPlace(w.ledger) } : w));
      } else if (newRecipientType === 'employee') {
        setEmployees(prev => prev.map(emp => emp.id === newRecipientId ? { ...emp, ledger: updateLedgerInPlace(emp.ledger) } : emp));
      } else if (newRecipientType === 'supplier') {
        setSuppliers(prev => prev.map(s => s.id === newRecipientId ? { ...s, ledger: updateLedgerInPlace(s.ledger) } : s));
      }
    } else {
      // Recipient changed or removed:
      if (oldRecipientId && oldRecipientType !== 'none') {
        const removeMatching = (ledger: LedgerEntry[]) => ledger.filter(e => {
          return !(e.id === 'posted_' + id || e.id === id || e.id === id.replace('exp_', 'wled_') || e.id === id.replace('exp_', 'eled_') || e.id === id.replace('exp_', 'sled_'));
        });

        if (oldRecipientType === 'worker') {
          setWorkers(prev => prev.map(w => w.id === oldRecipientId ? { ...w, ledger: removeMatching(w.ledger) } : w));
        } else if (oldRecipientType === 'employee') {
          setEmployees(prev => prev.map(emp => emp.id === oldRecipientId ? { ...emp, ledger: removeMatching(emp.ledger) } : emp));
        } else if (oldRecipientType === 'supplier') {
          setSuppliers(prev => prev.map(s => s.id === oldRecipientId ? { ...s, ledger: removeMatching(s.ledger) } : s));
        }
      }

      if (newRecipientId && newRecipientType !== 'none') {
        const postedLedgerEntry: LedgerEntry = {
          id: 'posted_' + id,
          date: updatedExpense.date,
          amountOnHim: updatedExpense.amount,
          amountForHim: 0,
          description: `${updatedExpense.description} (مرحّل من النفقات اليومية)`,
          notes: updatedExpense.notes || '',
          isPosted: true,
          currency: updatedExpense.currency || 'YER',
          createdBy: oldExpense.createdBy,
          updatedBy: getActorName()
        };

        if (newRecipientType === 'worker') {
          setWorkers(prev => prev.map(w => w.id === newRecipientId ? { ...w, ledger: [postedLedgerEntry, ...w.ledger] } : w));
        } else if (newRecipientType === 'employee') {
          setEmployees(prev => prev.map(emp => emp.id === newRecipientId ? { ...emp, ledger: [postedLedgerEntry, ...emp.ledger] } : emp));
        } else if (newRecipientType === 'supplier') {
          setSuppliers(prev => prev.map(s => s.id === newRecipientId ? { ...s, ledger: [postedLedgerEntry, ...s.ledger] } : s));
        }
      }
    }
  };

  // Update Budget Capital Item
  const handleUpdateBudgetItem = (id: string, updatedData: Omit<BudgetItem, 'id' | 'createdBy'>) => {
    setBudget(prev => prev.map(item => item.id === id ? { ...item, ...updatedData, updatedBy: getActorName() } : item));
  };

  // =================================== CONTRACT BOQ HANDLERS ===================================
  const handleAddContractItem = (itemData: Omit<ContractItem, 'id' | 'createdAt' | 'updatedAt'>) => {
    const newItem: ContractItem = {
      ...itemData,
      id: 'boq_' + Date.now().toString() + '_' + Math.random().toString(36).substring(2, 7),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    setContractItems(prev => [...prev, newItem]);
  };

  const handleUpdateContractItem = (id: string, updatedFields: Partial<ContractItem>) => {
    setContractItems(prev => prev.map(item => item.id === id ? {
      ...item,
      ...updatedFields,
      updatedAt: new Date().toISOString()
    } : item));
  };

  const handleDeleteContractItem = (id: string) => {
    const target = contractItems.find(item => item.id === id);
    if (target) {
      pushUndoItem({
        category: 'boq',
        categoryLabel: 'جدول الكميات وبنود العقد',
        actionType: 'delete',
        actionLabel: 'حذف بند عقد',
        title: target.name ? `بند عقد: ${target.name}` : `بند عقد: ${target.itemNumber}`,
        details: [
          { label: 'رقم البند', value: target.itemNumber || '-' },
          { label: 'الكمية', value: `${target.quantity || 0} ${target.unit || ''}` },
          { label: 'الإجمالي', value: `${((target.quantity || 0) * (target.unitPrice || 0)).toLocaleString()} ${currency}` }
        ],
        projectId: activeProjectId,
        projectName: projectName,
        payload: { type: 'contract_item_delete', data: target }
      });
    }

    if (!target) {
      setContractItems(prev => prev.filter(item => item.id !== id));
      return;
    }
    if (target.isMainItem) {
      setContractItems(prev => prev.filter(item => item.id !== id && item.parentItemNumber !== target.itemNumber));
    } else {
      setContractItems(prev => prev.filter(item => item.id !== id));
    }
  };

  const handleImportContractItems = (newItems: ContractItem[]) => {
    setContractItems(newItems);
  };

  // =================================== GENERAL DEBTS HANDLERS ===================================
  const handleAddGeneralDebt = (debtData: Omit<GeneralDebt, 'id' | 'payments' | 'createdAt' | 'updatedAt' | 'status'>) => {
    const debtId = 'gdebt_' + Date.now().toString() + '_' + Math.random().toString(36).substring(2, 6);
    const initialEntry: GeneralDebtEntry = {
      id: `${debtId}_entry_1`,
      amount: debtData.totalAmount,
      currency: debtData.currency,
      date: debtData.startDate,
      description: debtData.description,
      projectScope: debtData.projectScope || (debtData.projectName ? 'project' : 'general'),
      projectId: debtData.projectId,
      projectName: debtData.projectName,
      notes: debtData.notes,
      createdBy: debtData.createdBy,
      createdAt: new Date().toISOString()
    };

    const newDebt: GeneralDebt = {
      ...debtData,
      id: debtId,
      entries: debtData.entries && debtData.entries.length > 0 ? debtData.entries : [initialEntry],
      payments: [],
      status: 'active',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    setGeneralDebts(prev => [newDebt, ...prev]);
  };

  const handleUpdateGeneralDebt = (id: string, updatedData: Partial<GeneralDebt>) => {
    const oldDebt = generalDebts.find(d => d.id === id);
    if (oldDebt) {
      pushUndoItem({
        category: 'general_debts',
        categoryLabel: 'الديون والالتزامات العامة',
        actionType: 'update',
        actionLabel: 'تعديل بيانات دين عام',
        title: `دين: ${oldDebt.personOrEntityName} (${Number(oldDebt.totalAmount).toLocaleString()} ${oldDebt.currency})`,
        details: [
          { label: 'الشخص / الجهة', value: oldDebt.personOrEntityName },
          { label: 'المبلغ السابق', value: `${Number(oldDebt.totalAmount).toLocaleString()} ${oldDebt.currency}` },
          { label: 'المشروع المرتبط', value: oldDebt.projectName || 'دين عام' }
        ],
        payload: { type: 'general_debt_update', data: oldDebt }
      });
    }

    setGeneralDebts(prev => prev.map(d => {
      if (d.id !== id) return d;
      const updated: GeneralDebt = { ...d, ...updatedData, updatedAt: new Date().toISOString() };
      // Auto-compute status based on totalPaid vs totalAmount
      const totalPaid = (updated.payments || []).reduce((sum, p) => sum + (Number(p.amount) || 0), 0);
      if (totalPaid >= updated.totalAmount && updated.totalAmount > 0) {
        updated.status = 'settled';
      } else if (totalPaid > 0) {
        updated.status = 'partially_paid';
      } else {
        updated.status = 'active';
      }
      return updated;
    }));
  };

  const handleDeleteGeneralDebt = (id: string) => {
    const target = generalDebts.find(d => d.id === id);
    if (target) {
      pushUndoItem({
        category: 'general_debts',
        categoryLabel: 'الديون والالتزامات العامة',
        actionType: 'delete',
        actionLabel: 'حذف سجل دين عام',
        title: `دين: ${target.personOrEntityName} (${Number(target.totalAmount).toLocaleString()} ${target.currency})`,
        details: [
          { label: 'الشخص / الجهة', value: target.personOrEntityName },
          { label: 'إجمالي المبلغ', value: `${Number(target.totalAmount).toLocaleString()} ${target.currency}` },
          { label: 'نوع الدين', value: target.type === 'payable' ? 'دين علينا (التزام)' : 'دين لنا (مستحق)' },
          { label: 'المشروع المرتبط', value: target.projectName || 'دين عام' }
        ],
        payload: { type: 'general_debt_delete', data: target }
      });
    }

    setGeneralDebts(prev => prev.filter(d => d.id !== id));
  };

  const handleAddGeneralDebtPayment = (debtId: string, paymentData: Omit<GeneralDebtPayment, 'id' | 'createdAt'>) => {
    const newPayment: GeneralDebtPayment = {
      ...paymentData,
      id: 'gpay_' + Date.now().toString() + '_' + Math.random().toString(36).substring(2, 6),
      createdAt: new Date().toISOString()
    };

    setGeneralDebts(prev => prev.map(d => {
      if (d.id !== debtId) return d;
      const updatedPayments = [newPayment, ...(d.payments || [])];
      const totalPaid = updatedPayments.reduce((sum, p) => sum + (Number(p.amount) || 0), 0);
      let status: 'active' | 'partially_paid' | 'settled' = 'active';
      if (totalPaid >= d.totalAmount && d.totalAmount > 0) {
        status = 'settled';
      } else if (totalPaid > 0) {
        status = 'partially_paid';
      }
      return {
        ...d,
        payments: updatedPayments,
        status,
        updatedAt: new Date().toISOString()
      };
    }));
  };

  const handleDeleteGeneralDebtPayment = (debtId: string, paymentId: string) => {
    const debt = generalDebts.find(d => d.id === debtId);
    const targetPayment = debt?.payments.find(p => p.id === paymentId);
    if (debt && targetPayment) {
      pushUndoItem({
        category: 'general_debts',
        categoryLabel: 'الديون والالتزامات العامة',
        actionType: 'delete',
        actionLabel: 'حذف دفعة سداد دين',
        title: `دفعة دين (${debt.personOrEntityName}): ${Number(targetPayment.amount).toLocaleString()} ${targetPayment.currency || debt.currency}`,
        details: [
          { label: 'الشخص / الجهة', value: debt.personOrEntityName },
          { label: 'المبلغ', value: `${Number(targetPayment.amount).toLocaleString()} ${targetPayment.currency || debt.currency}` },
          { label: 'التاريخ', value: targetPayment.date },
          { label: 'البيان', value: targetPayment.notes || 'دفعة سداد' }
        ],
        payload: { type: 'general_debt_payment_delete', data: { debtId, payment: targetPayment } }
      });
    }

    setGeneralDebts(prev => prev.map(d => {
      if (d.id !== debtId) return d;
      const updatedPayments = (d.payments || []).filter(p => p.id !== paymentId);
      const totalPaid = updatedPayments.reduce((sum, p) => sum + (Number(p.amount) || 0), 0);
      let status: 'active' | 'partially_paid' | 'settled' = 'active';
      if (totalPaid >= d.totalAmount && d.totalAmount > 0) {
        status = 'settled';
      } else if (totalPaid > 0) {
        status = 'partially_paid';
      }
      return {
        ...d,
        payments: updatedPayments,
        status,
        updatedAt: new Date().toISOString()
      };
    }));
  };

  const handleAddGeneralDebtEntry = (debtId: string, entryData: Omit<GeneralDebtEntry, 'id' | 'createdAt'>) => {
    const newEntry: GeneralDebtEntry = {
      ...entryData,
      id: 'gdentry_' + Date.now().toString() + '_' + Math.random().toString(36).substring(2, 6),
      createdAt: new Date().toISOString()
    };

    setGeneralDebts(prev => prev.map(d => {
      if (d.id !== debtId) return d;
      
      const existingEntries = (d.entries && d.entries.length > 0)
        ? d.entries
        : [{
            id: `${d.id}_entry_initial`,
            amount: d.totalAmount,
            currency: d.currency,
            date: d.startDate || d.createdAt?.split('T')[0] || new Date().toISOString().split('T')[0],
            description: d.description,
            projectScope: d.projectScope || (d.projectName ? 'project' : 'general'),
            projectId: d.projectId,
            projectName: d.projectName,
            notes: d.notes,
            createdBy: d.createdBy,
            createdAt: d.createdAt
          }];

      const updatedEntries = [...existingEntries, newEntry];
      
      const primaryTotal = updatedEntries
        .filter(e => e.currency === d.currency)
        .reduce((sum, e) => sum + (Number(e.amount) || 0), 0);
      
      const primaryPaid = (d.payments || [])
        .filter(p => (p.currency || d.currency) === d.currency)
        .reduce((sum, p) => sum + (Number(p.amount) || 0), 0);

      let status: 'active' | 'partially_paid' | 'settled' = 'active';
      if (primaryPaid >= primaryTotal && primaryTotal > 0) {
        status = 'settled';
      } else if (primaryPaid > 0) {
        status = 'partially_paid';
      }

      return {
        ...d,
        entries: updatedEntries,
        totalAmount: primaryTotal,
        status,
        updatedAt: new Date().toISOString()
      };
    }));
  };

  const handleDeleteGeneralDebtEntry = (debtId: string, entryId: string) => {
    setGeneralDebts(prev => prev.map(d => {
      if (d.id !== debtId) return d;
      const updatedEntries = (d.entries || []).filter(e => e.id !== entryId);
      const primaryTotal = updatedEntries
        .filter(e => e.currency === d.currency)
        .reduce((sum, e) => sum + (Number(e.amount) || 0), 0);

      const primaryPaid = (d.payments || [])
        .filter(p => (p.currency || d.currency) === d.currency)
        .reduce((sum, p) => sum + (Number(p.amount) || 0), 0);

      let status: 'active' | 'partially_paid' | 'settled' = 'active';
      if (primaryPaid >= primaryTotal && primaryTotal > 0) {
        status = 'settled';
      } else if (primaryPaid > 0) {
        status = 'partially_paid';
      }

      return {
        ...d,
        entries: updatedEntries,
        totalAmount: primaryTotal,
        status,
        updatedAt: new Date().toISOString()
      };
    }));
  };

  // ===================== AUTO-SYNC MIGRATED DEBTS WITH PROJECT ACCOUNTS =====================
  useEffect(() => {
    if (!activeProjectId || generalDebts.length === 0) return;

    let hasChanges = false;
    const updated = generalDebts.map(debt => {
      if (debt.projectId !== activeProjectId || !debt.sourceEntityType || !debt.sourceEntityId) {
        return debt;
      }

      let netBalance: number | null = null;
      const targetCur = debt.currency || 'YER';

      if (debt.sourceEntityType === 'worker') {
        const w = workers.find(item => item.id === debt.sourceEntityId);
        if (w) {
          const ledger = w.ledger || [];
          let forHim = 0;
          let onHim = 0;
          ledger.forEach(e => {
            if ((e.currency || 'YER') === targetCur) {
              forHim += e.amountForHim || 0;
              onHim += e.amountOnHim || 0;
            }
          });
          netBalance = forHim - onHim;
        }
      } else if (debt.sourceEntityType === 'employee') {
        const emp = employees.find(item => item.id === debt.sourceEntityId);
        if (emp) {
          const ledger = emp.ledger || [];
          let forHim = 0;
          let onHim = 0;
          ledger.forEach(e => {
            if ((e.currency || 'YER') === targetCur) {
              forHim += e.amountForHim || 0;
              onHim += e.amountOnHim || 0;
            }
          });
          netBalance = forHim - onHim;
        }
      } else if (debt.sourceEntityType === 'supplier') {
        const s = suppliers.find(item => item.id === debt.sourceEntityId);
        if (s) {
          const ledger = s.ledger || [];
          let forHim = 0;
          let onHim = 0;
          ledger.forEach(e => {
            if ((e.currency || 'YER') === targetCur) {
              forHim += e.amountForHim || 0;
              onHim += e.amountOnHim || 0;
            }
          });
          netBalance = forHim - onHim;
        }
      }

      if (netBalance !== null) {
        const expectedTotal = Math.abs(netBalance);
        const expectedType: 'payable' | 'receivable' = netBalance >= 0 ? 'payable' : 'receivable';
        const expectedStatus: 'active' | 'partially_paid' | 'settled' = expectedTotal < 0.001
          ? 'settled'
          : (debt.status === 'settled' ? 'active' : (debt.status || 'active'));

        const isTypeChanged = debt.type !== expectedType && expectedTotal >= 0.001;
        const isAmountChanged = Math.abs(debt.totalAmount - expectedTotal) > 0.001;
        const isStatusChanged = expectedTotal < 0.001 && debt.status !== 'settled';

        if (isTypeChanged || isAmountChanged || isStatusChanged) {
          hasChanges = true;
          const updatedEntries = debt.entries ? debt.entries.map((entry, idx) => {
            if (idx === 0) return { ...entry, amount: expectedTotal };
            return entry;
          }) : undefined;

          return {
            ...debt,
            type: expectedType,
            totalAmount: expectedTotal,
            status: expectedStatus,
            entries: updatedEntries,
            updatedAt: new Date().toISOString()
          };
        }
      }

      return debt;
    });

    if (hasChanges) {
      setGeneralDebts(updated);
    }
  }, [workers, employees, suppliers, activeProjectId]);

  // =================================== PERFORMANCE EVALUATIONS HANDLERS ===================================
  const handleAddEvaluation = (evalData: Omit<PerformanceEvaluation, 'id' | 'createdAt' | 'updatedAt'>) => {
    const newEval: PerformanceEvaluation = {
      ...evalData,
      id: 'eval_' + Date.now().toString() + '_' + Math.random().toString(36).substring(2, 6),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    setEvaluations(prev => [newEval, ...prev]);
  };

  const handleUpdateEvaluation = (updatedEval: PerformanceEvaluation) => {
    setEvaluations(prev => prev.map(e => e.id === updatedEval.id ? { ...updatedEval, updatedAt: new Date().toISOString() } : e));
  };

  const handleDeleteEvaluation = (id: string) => {
    setEvaluations(prev => prev.filter(e => e.id !== id));
  };

  const handleNavigateToEntityLedger = useCallback((category: 'employee' | 'worker' | 'supplier', _entityId: string, targetProjectId?: string) => {
    if (targetProjectId && targetProjectId !== activeProjectId && projects.some(p => p.id === targetProjectId)) {
      handleSelectProject(targetProjectId);
    }
    if (category === 'worker') {
      handleTabChange('workers');
    } else if (category === 'employee') {
      handleTabChange('employees');
    } else if (category === 'supplier') {
      handleTabChange('suppliers');
    }
  }, [activeProjectId, projects, handleTabChange]);

  // =================================== COMPANY ASSETS HANDLERS ===================================
  const handleAddAsset = (assetData: Omit<CompanyAsset, 'id' | 'movements' | 'createdAt' | 'updatedAt'>) => {
    const newAsset: CompanyAsset = {
      ...assetData,
      id: 'asset_' + Date.now().toString() + '_' + Math.random().toString(36).substring(2, 6),
      movements: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    setCompanyAssets(prev => [newAsset, ...prev]);
  };

  const handleUpdateAsset = (id: string, updatedData: Partial<CompanyAsset>) => {
    const oldAsset = companyAssets.find(a => a.id === id);
    if (oldAsset) {
      pushUndoItem({
        category: 'company_assets',
        categoryLabel: 'أصول وممتلكات الشركة',
        actionType: 'update',
        actionLabel: 'تعديل بيانات أصل',
        title: `أصل: ${oldAsset.name}`,
        details: [
          { label: 'الاسم السابق', value: oldAsset.name },
          { label: 'الحالة السابقة', value: oldAsset.condition || 'جيد' }
        ],
        payload: { type: 'asset_update', data: oldAsset }
      });
    }
    setCompanyAssets(prev => prev.map(a => a.id === id ? { ...a, ...updatedData, updatedAt: new Date().toISOString() } : a));
  };

  const handleDeleteAsset = (id: string) => {
    const target = companyAssets.find(a => a.id === id);
    if (target) {
      pushUndoItem({
        category: 'company_assets',
        categoryLabel: 'أصول وممتلكات الشركة',
        actionType: 'delete',
        actionLabel: 'حذف أصل',
        title: `أصل: ${target.name}`,
        details: [
          { label: 'اسم الأصل', value: target.name },
          { label: 'التصنيف', value: target.category || 'غير محدد' },
          { label: 'سعر الشراء', value: `${Number(target.purchasePrice || 0).toLocaleString()} ${target.currency}` }
        ],
        payload: { type: 'asset_delete', data: target }
      });
    }
    setCompanyAssets(prev => prev.filter(a => a.id !== id));
  };

  const handleAddAssetMovement = (assetId: string, movementData: Omit<CompanyAssetMovement, 'id' | 'createdAt'>) => {
    const newMovement: CompanyAssetMovement = {
      ...movementData,
      id: 'mov_' + Date.now().toString() + '_' + Math.random().toString(36).substring(2, 6),
      createdAt: new Date().toISOString()
    };

    setCompanyAssets(prev => prev.map(a => {
      if (a.id !== assetId) return a;

      const updatedMovements = [newMovement, ...(a.movements || [])];
      let updatedLocation = a.currentLocation;
      let updatedCustodian = a.custodianName;
      let updatedCondition = a.condition;

      if (movementData.toLocation) {
        updatedLocation = movementData.toLocation;
      }
      if (movementData.custodianName) {
        updatedCustodian = movementData.custodianName;
      }
      if (movementData.conditionAfter) {
        updatedCondition = movementData.conditionAfter;
      }

      return {
        ...a,
        movements: updatedMovements,
        currentLocation: updatedLocation,
        custodianName: updatedCustodian,
        condition: updatedCondition,
        updatedAt: new Date().toISOString()
      };
    }));
  };

  const handleDeleteAssetMovement = (assetId: string, movementId: string) => {
    setCompanyAssets(prev => prev.map(a => {
      if (a.id !== assetId) return a;
      return {
        ...a,
        movements: (a.movements || []).filter(m => m.id !== movementId),
        updatedAt: new Date().toISOString()
      };
    }));
  };

  // =================================== TAB CONTENT ROUTING ===================================
  const renderTabContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return (
          <Dashboard 
            expenses={expenses}
            workers={workers}
            suppliers={suppliers}
            employees={employees}
            budget={budget}
            currency={currency}
            projectId={projectId}
            sharedRole={sharedRole}
            syncStatus={syncStatus}
            onSetProjectId={handleSetProjectId}
            onCreateShareLink={handleCreateShareLink}
            onCancelCloudSync={handleCancelCloudSync}
            onRestoreOwnerRole={handleRestoreOwnerRole}
            setActiveTab={(tab) => {
              handleTabChange(tab);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
          />
        );
      case 'expenses':
        return (
          <DailyExpenses 
            expenses={expenses}
            workers={workers}
            suppliers={suppliers}
            employees={employees}
            contractItems={contractItems}
            onAddExpense={handleAddExpense}
            onDeleteExpense={handleDeleteExpense}
            onUpdateExpense={handleUpdateExpense}
            onAddWorker={handleAddWorker}
            onAddEmployee={handleAddEmployee}
            onAddSupplier={handleAddSupplier}
            setActiveTab={handleTabChange}
            currency={currency}
            sharedRole={sharedRole}
          />
        );
      case 'boq':
      case 'contract_items':
        return (
          <ContractBOQ 
            contractItems={contractItems}
            onAddContractItem={handleAddContractItem}
            onUpdateContractItem={handleUpdateContractItem}
            onDeleteContractItem={handleDeleteContractItem}
            onImportContractItems={handleImportContractItems}
            expenses={expenses}
            suppliers={suppliers}
            workers={workers}
            currency={currency}
            projectName={projectName}
            companyName={companyName}
            companyAddress={companyAddress}
            companyPhone={companyPhone}
            sharedRole={sharedRole}
            currentUser={getActorName()}
            setActiveTab={handleTabChange}
          />
        );
      case 'workers':
        return (
          <Workers 
            workers={workers.map(w => syncWorkerNutritionLedger(w))}
            employees={employees}
            suppliers={suppliers}
            onAddWorker={handleAddWorker}
            onDeleteWorker={handleDeleteWorker}
            onUpdateWorker={handleUpdateWorker}
            onAddWorkerLedgerEntry={handleAddWorkerLedgerEntry}
            onDeleteWorkerLedgerEntry={handleDeleteWorkerLedgerEntry}
            onUpdateWorkerLedgerEntry={handleUpdateWorkerLedgerEntry}
            onCopyLedgerEntry={handleCopyLedgerEntry}
            onMoveLedgerEntry={handleMoveLedgerEntry}
            onAddWorkerExtraPeriod={handleAddWorkerExtraPeriod}
            onDeleteWorkerExtraPeriod={handleDeleteWorkerExtraPeriod}
            onAddWorkerNutritionPeriod={handleAddWorkerNutritionPeriod}
            onUpdateWorkerNutritionPeriod={handleUpdateWorkerNutritionPeriod}
            onDeleteWorkerNutritionPeriod={handleDeleteWorkerNutritionPeriod}
            onTransferWorkerToEmployee={handleTransferWorkerToEmployee}
            setActiveTab={handleTabChange}
            currency={currency}
            sharedRole={sharedRole}
          />
        );
      case 'employees':
        return (
          <Employees 
            employees={employees.map(e => syncEmployeeAllLedgers(e, sharedRole === 'owner'))}
            workers={workers}
            suppliers={suppliers}
            onAddEmployee={handleAddEmployee}
            onDeleteEmployee={handleDeleteEmployee}
            onUpdateEmployee={handleUpdateEmployee}
            onAddEmployeeLedgerEntry={handleAddEmployeeLedgerEntry}
            onDeleteEmployeeLedgerEntry={handleDeleteEmployeeLedgerEntry}
            onUpdateEmployeeLedgerEntry={handleUpdateEmployeeLedgerEntry}
            onCopyLedgerEntry={handleCopyLedgerEntry}
            onMoveLedgerEntry={handleMoveLedgerEntry}
            onAddEmployeeExtraPeriod={handleAddEmployeeExtraPeriod}
            onUpdateEmployeeExtraPeriod={handleUpdateEmployeeExtraPeriod}
            onDeleteEmployeeExtraPeriod={handleDeleteEmployeeExtraPeriod}
            onAddEmployeeNutritionPeriod={handleAddEmployeeNutritionPeriod}
            onUpdateEmployeeNutritionPeriod={handleUpdateEmployeeNutritionPeriod}
            onDeleteEmployeeNutritionPeriod={handleDeleteEmployeeNutritionPeriod}
            onTransferEmployeeToWorker={handleTransferEmployeeToWorker}
            setActiveTab={handleTabChange}
            currency={currency}
            sharedRole={sharedRole}
          />
        );
      case 'suppliers':
        return (
          <Suppliers 
            suppliers={suppliers}
            workers={workers}
            employees={employees}
            onAddSupplier={handleAddSupplier}
            onDeleteSupplier={handleDeleteSupplier}
            onUpdateSupplier={handleUpdateSupplier}
            onAddSupplierLedgerEntry={handleAddSupplierLedgerEntry}
            onDeleteSupplierLedgerEntry={handleDeleteSupplierLedgerEntry}
            onUpdateSupplierLedgerEntry={handleUpdateSupplierLedgerEntry}
            onCopyLedgerEntry={handleCopyLedgerEntry}
            onMoveLedgerEntry={handleMoveLedgerEntry}
            setActiveTab={handleTabChange}
            currency={currency}
            sharedRole={sharedRole}
          />
        );
      case 'budget':
        return (
          <Budget 
            budget={budget}
            expenses={expenses}
            workers={workers}
            employees={employees}
            suppliers={suppliers}
            onAddBudgetItem={handleAddBudgetItem}
            onDeleteBudgetItem={handleDeleteBudgetItem}
            onUpdateBudgetItem={handleUpdateBudgetItem}
            setActiveTab={handleTabChange}
            currency={currency}
            sharedRole={sharedRole}
          />
        );
      case 'reports':
        return (
          <FinancialReports 
            budget={budget}
            expenses={expenses}
            workers={workers}
            suppliers={suppliers}
            employees={employees}
            currency={currency}
            setActiveTab={handleTabChange}
            sharedRole={sharedRole}
          />
        );
      case 'debts':
        return (
          <Debts 
            workers={workers}
            employees={employees}
            suppliers={suppliers}
            currency={currency}
            setActiveTab={handleTabChange}
            sharedRole={sharedRole}
            onAddWorkerLedgerEntry={handleAddWorkerLedgerEntry}
            onAddEmployeeLedgerEntry={handleAddEmployeeLedgerEntry}
            onAddSupplierLedgerEntry={handleAddSupplierLedgerEntry}
            generalDebts={generalDebts}
            onAddGeneralDebt={handleAddGeneralDebt}
            onUpdateGeneralDebt={handleUpdateGeneralDebt}
            onDeleteGeneralDebt={handleDeleteGeneralDebt}
            projectId={activeProjectId}
            projectName={projectName}
          />
        );
      case 'general_debts':
        return (
          <GeneralDebts 
            generalDebts={generalDebts}
            projects={projects}
            onAddGeneralDebt={handleAddGeneralDebt}
            onUpdateGeneralDebt={handleUpdateGeneralDebt}
            onDeleteGeneralDebt={handleDeleteGeneralDebt}
            onAddPayment={handleAddGeneralDebtPayment}
            onDeletePayment={handleDeleteGeneralDebtPayment}
            onAddDebtEntry={handleAddGeneralDebtEntry}
            onDeleteDebtEntry={handleDeleteGeneralDebtEntry}
            setActiveTab={handleTabChange}
            sharedRole={sharedRole}
            currentUser={userName || 'المدير'}
          />
        );
      case 'main_hub':
        return (
          <MainApplicationHub
            projects={projects}
            activeProjectId={activeProjectId}
            onSelectProject={handleSelectProject}
            currency={currency}
            companyName={companyName}
            companyAddress={companyAddress}
            companyPhone={companyPhone}
            companyLogo={companyLogo}
            designerName="م/ ياسر عقيل"
            designerPhone="771999911"
            projectId={projectId}
            sharedRole={sharedRole}
            syncStatus={syncStatus}
            onCreateShareLink={handleCreateShareLink}
            onSetProjectId={handleSetProjectId}
            onCancelCloudSync={handleCancelCloudSync}
            onRestoreAllProjects={handleRestoreAllProjects}
            onRestoreOwnerRole={handleRestoreOwnerRole}
            setActiveTab={handleTabChange}
            generalDebts={generalDebts}
            companyAssets={companyAssets}
            currentUser={userName || 'المدير'}
            onOpenGlobalBackup={() => setShowGlobalBackupModal(true)}
          />
        );
      case 'construction_projects':
      case 'projects':
        return (
          <ProjectsHub 
            projects={projects}
            activeProjectId={activeProjectId}
            onSelectProject={handleSelectProject}
            onCreateProject={handleCreateProject}
            onUpdateProject={handleUpdateProject}
            onDeleteProject={handleDeleteProject}
            onDuplicateProject={handleDuplicateProject}
            currency={currency}
            companyName={companyName}
            companyAddress={companyAddress}
            companyPhone={companyPhone}
            designerName="م/ ياسر عقيل"
            designerPhone="771999911"
            projectId={projectId}
            sharedRole={sharedRole}
            syncStatus={syncStatus}
            onCreateShareLink={handleCreateShareLink}
            onSetProjectId={handleSetProjectId}
            onCancelCloudSync={handleCancelCloudSync}
            onMigrateEntity={handleMigrateEntity}
            onRestoreAllProjects={handleRestoreAllProjects}
            onRestoreOwnerRole={handleRestoreOwnerRole}
            setActiveTab={handleTabChange}
            generalDebts={generalDebts}
            onAddGeneralDebt={handleAddGeneralDebt}
            onUpdateGeneralDebt={handleUpdateGeneralDebt}
            onDeleteGeneralDebt={handleDeleteGeneralDebt}
            onAddGeneralDebtPayment={handleAddGeneralDebtPayment}
            onDeleteGeneralDebtPayment={handleDeleteGeneralDebtPayment}
            currentUser={userName || 'المدير'}
          />
        );
      case 'backup':
        return (
          <BackupRestore 
            expenses={expenses}
            setExpenses={setExpenses}
            workers={workers}
            setWorkers={setWorkers}
            employees={employees}
            setEmployees={setEmployees}
            suppliers={suppliers}
            setSuppliers={setSuppliers}
            budget={budget}
            setBudget={setBudget}
            currency={currency}
            setCurrency={setCurrency}
            projectName={projectName}
            setProjectName={setProjectName}
            companyName={companyName}
            setCompanyName={setCompanyName}
            companyAddress={companyAddress}
            setCompanyAddress={setCompanyAddress}
            companyPhone={companyPhone}
            setCompanyPhone={setCompanyPhone}
            userName={userName}
            setUserName={setUserName}
            setActiveTab={handleTabChange}
            sharedRole={sharedRole}
          />
        );
      case 'evaluations':
        return (
          <PerformanceEvaluations 
            evaluations={evaluations}
            onAddEvaluation={handleAddEvaluation}
            onUpdateEvaluation={handleUpdateEvaluation}
            onDeleteEvaluation={handleDeleteEvaluation}
            employees={employees}
            workers={workers}
            suppliers={suppliers}
            projects={projects}
            activeProjectId={activeProjectId}
            projectName={projectName}
            setActiveTab={handleTabChange}
            onNavigateToEntityLedger={handleNavigateToEntityLedger}
            currentUser={userName || 'المدير'}
            sharedRole={sharedRole}
            companyName={companyName}
            companyAddress={companyAddress}
            companyPhone={companyPhone}
          />
        );
      case 'company_assets':
        return (
          <CompanyAssets
            assets={companyAssets}
            onAddAsset={handleAddAsset}
            onUpdateAsset={handleUpdateAsset}
            onDeleteAsset={handleDeleteAsset}
            onAddMovement={handleAddAssetMovement}
            onDeleteMovement={handleDeleteAssetMovement}
            projects={projects}
            expenses={expenses}
            suppliers={suppliers}
            employees={employees}
            setActiveTab={handleTabChange}
            sharedRole={sharedRole}
            currentUser={userName || 'المدير'}
          />
        );
      default:
        return <div className="text-center py-12">تحميل التبويب...</div>;
    }
  };

  const printInNewTab = () => {
    if (!printPreview) return;
    
    const printWindow = window.open('', '_blank');
    if (!printWindow) {
      if ((window as any).showToast) {
        (window as any).showToast("⚠️ الرجاء السماح بالنوافذ المنبثقة (Popups) في متصفحك لفتح صفحة الطباعة.");
      }
      return;
    }

    const showHeader = localStorage.getItem('site_show_report_header') !== 'false';
    const showSignatures = localStorage.getItem('site_show_signature_blocks') !== 'false';
    const showAttribution = localStorage.getItem('site_show_designer_attribution') !== 'false';
    const footerNotes = (localStorage.getItem('site_report_footer_notes') || '').trim();
    
    // Check if content ALREADY contains an official header / table header structure
    const hasExistingHeader = printPreview.htmlContent.includes('report-header') || printPreview.htmlContent.includes('official-report-header') || printPreview.htmlContent.includes('pdf-report-root');

    const headerHtml = (showHeader && !hasExistingHeader) ? `
      <div class="official-report-header" style="display: flex; justify-content: space-between; align-items: center; border-bottom: 3px double #002B49; padding-bottom: 12px; margin-bottom: 20px; page-break-after: avoid; direction: rtl;">
        <div class="header-col-right" style="text-align: right; flex: 1.35;">
          <h2 style="margin: 0; font-size: 15px; color: #002B49; font-weight: 800; font-family: 'Cairo', sans-serif; line-height: 1.25;">${companyName}</h2>
          <div style="font-size: 13.5px; font-weight: 800; color: #E85D25; font-family: 'Segoe UI', Arial, sans-serif; letter-spacing: 0.3px; margin-top: 3px; direction: ltr; text-align: right; line-height: 1.25;">World of Elites for Trading & Contracting</div>
          <p style="margin: 4px 0 0 0; font-size: 12px; font-weight: 700; color: #1e293b; line-height: 1.35;">الإدارة المالية والتنفيذية للمشاريع</p>
          <p style="margin: 2px 0 0 0; font-size: 11.5px; font-weight: 600; color: #334155; line-height: 1.35;">قسم الحسابات والرقابة المالية</p>
        </div>
        <div class="header-col-center" style="text-align: center; flex: 1; display: flex; flex-direction: column; align-items: center; justify-content: center;">
          <div style="width: 72px; height: 50px; border-radius: 8px; overflow: hidden; display: flex; align-items: center; justify-content: center; margin-bottom: 4px; background-color: #ffffff; padding: 2px;">
            <img src="${companyLogo}" style="max-width: 100%; max-height: 100%; object-fit: contain;" alt="شعار الشركة" />
          </div>
          <h1 style="margin: 0; font-size: 16px; font-weight: 800; color: #002B49;">${printPreview.title}</h1>
          <span style="font-size: 10px; color: #64748b; margin-top: 2px; font-weight: bold;">الإدارة المالية والتنفيذية للمشاريع</span>
        </div>
        <div class="header-col-left" style="text-align: left; flex: 1;">
          <h3 style="margin: 0; font-size: 11px; color: #002B49; font-weight: bold;">الحسابات وإدارة المشاريع</h3>
          <p style="margin: 2px 0 0 0; font-size: 10.5px; color: #E85D25; font-weight: bold;">المشروع: ${projectName || 'مشروع العمل الجاري'}</p>
          <p style="margin: 2px 0 0 0; font-size: 9.5px; color: #64748b;">تاريخ استخراج التقرير: ${new Date().toLocaleDateString('ar-EG-u-nu-latn')}</p>
          <p style="margin: 2px 0 0 0; font-size: 9.5px; color: #16a34a; font-weight: bold;">الحالة: كشف معتمد داخلياً</p>
        </div>
      </div>
    ` : '';

    let footerCustomHtml = '';

    if (footerNotes) {
      footerCustomHtml += `
        <div style="margin-top: 20px; padding: 12px 16px; background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; font-size: 11px; color: #334155; line-height: 1.6; page-break-inside: avoid;">
          <strong style="color: #002B49; display: block; margin-bottom: 4px; font-size: 12px;">📌 الملاحظات الختامية والشروط:</strong>
          <div style="white-space: pre-wrap;">${footerNotes}</div>
        </div>
      `;
    }

    if (showSignatures) {
      footerCustomHtml += `
        <div style="margin-top: 35px; display: flex; justify-content: space-between; text-align: center; font-size: 12px; font-weight: bold; border-top: 1px dashed #cbd5e1; padding-top: 20px; page-break-inside: avoid;">
          <div style="flex: 1;"><p style="margin:0 0 30px 0; color: #002B49;">توقيع المستلم</p><p style="margin:0; color: #94a3b8;">.................................</p></div>
          <div style="flex: 1;"><p style="margin:0 0 30px 0; color: #002B49;">توقيع المحاسب المسئول</p><p style="margin:0; color: #94a3b8;">.................................</p></div>
          <div style="flex: 1;"><p style="margin:0 0 30px 0; color: #002B49;">توقيع واعتماد المدير</p><p style="margin:0; color: #94a3b8;">.................................</p></div>
        </div>
      `;
    }

    if (!hasExistingHeader) {
      footerCustomHtml += `
        <div style="border-top: 2px solid #002B49; padding-top: 10px; margin-top: 25px; font-size: 11.5px; color: #002B49; direction: rtl; line-height: 1.5; font-family: 'Cairo', 'Segoe UI', Tahoma, sans-serif; page-break-inside: avoid;">
          <div style="display: flex; justify-content: space-between; align-items: center; gap: 16px;">
            
            <!-- جهة اليمين: العنوان في سطر والبريد والموقع في سطر واحد يفصل بينهما الرمز التعبيري، في صفين فقط بدون نصوص توضيحية -->
            <div style="text-align: right; flex: 1.35; min-width: 0; display: flex; flex-direction: column; justify-content: center; gap: 7px;">
              <div style="display: flex; align-items: center; gap: 8px; white-space: nowrap;">
                <span style="display: inline-flex; align-items: center; justify-content: center; width: 22px; height: 22px; min-width: 22px; min-height: 22px; background-color: #E85D25; border-radius: 50%; vertical-align: middle;">
                  <svg style="width: 12px; height: 12px;" viewBox="0 0 24 24" fill="none" stroke="#ffffff" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                    <circle cx="12" cy="10" r="3"></circle>
                  </svg>
                </span>
                <span style="color: #002B49; font-weight: 700; font-size: 11.5px; font-family: 'Cairo', 'Segoe UI', Tahoma, sans-serif;">${companyAddress}</span>
              </div>
              <div style="display: flex; align-items: center; gap: 7px; white-space: nowrap;">
                <span style="display: inline-flex; align-items: center; justify-content: center; width: 22px; height: 22px; min-width: 22px; min-height: 22px; background-color: #E85D25; border-radius: 50%; vertical-align: middle;">
                  <svg style="width: 12px; height: 12px;" viewBox="0 0 24 24" fill="none" stroke="#ffffff" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path>
                    <polyline points="22,6 12,13 2,6"></polyline>
                  </svg>
                </span>
                <a href="mailto:Info@WorldofElites.com" style="direction: ltr; font-family: 'Segoe UI', Tahoma, sans-serif; font-weight: 700; font-size: 11.5px; color: #002B49; text-decoration: none;">Info@WorldofElites.com</a>
                
                <span style="display: inline-flex; align-items: center; justify-content: center; width: 22px; height: 22px; min-width: 22px; min-height: 22px; background-color: #E85D25; border-radius: 50%; vertical-align: middle; margin: 0 4px;">
                  <svg style="width: 12px; height: 12px;" viewBox="0 0 24 24" fill="none" stroke="#ffffff" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round">
                    <circle cx="12" cy="12" r="10"></circle>
                    <line x1="2" y1="12" x2="22" y2="12"></line>
                    <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path>
                  </svg>
                </span>
                <a href="https://www.WorldofElites.com" target="_blank" style="direction: ltr; font-family: 'Segoe UI', Tahoma, sans-serif; font-weight: 700; font-size: 11.5px; color: #002B49; text-decoration: none;">www.WorldofElites.com</a>
              </div>
            </div>

            <!-- خط عمودي فاصل بين الجهة اليمنى والجهة اليسرى -->
            <div style="width: 1.5px; min-height: 46px; background-color: #cbd5e1; align-self: stretch;"></div>

            <!-- جهة اليسار: أرقام التواصل في صفين فقط، بدون نصوص توضيحية، بأيقونات بيضاء داخل دوائر برتقالية من اليسار لليمين -->
            <div style="text-align: left; direction: ltr; flex: 1; min-width: 0; display: flex; flex-direction: column; justify-content: center; gap: 7px;">
              <div style="display: flex; align-items: center; gap: 8px; white-space: nowrap;">
                <span style="display: inline-flex; align-items: center; justify-content: center; width: 22px; height: 22px; min-width: 22px; min-height: 22px; background-color: #E85D25; border-radius: 50%; vertical-align: middle;">
                  <svg style="width: 12px; height: 12px;" viewBox="0 0 24 24" fill="none" stroke="#ffffff" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round">
                    <rect x="5" y="2" width="14" height="20" rx="2" ry="2"></rect>
                    <line x1="12" y1="18" x2="12.01" y2="18"></line>
                  </svg>
                </span>
                <span style="direction: ltr; display: inline-block; font-family: 'Segoe UI', Tahoma, monospace, sans-serif; font-weight: 700; font-size: 12px; color: #002B49; letter-spacing: 0.2px;">+967 782 222 877 | +967 779 992 996</span>
              </div>
              <div style="display: flex; align-items: center; gap: 8px; white-space: nowrap;">
                <span style="display: inline-flex; align-items: center; justify-content: center; width: 22px; height: 22px; min-width: 22px; min-height: 22px; background-color: #E85D25; border-radius: 50%; vertical-align: middle;">
                  <svg style="width: 12px; height: 12px;" viewBox="0 0 24 24" fill="none" stroke="#ffffff" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
                  </svg>
                </span>
                <span style="direction: ltr; display: inline-block; font-family: 'Segoe UI', Tahoma, monospace, sans-serif; font-weight: 700; font-size: 12px; color: #002B49; letter-spacing: 0.2px;">+967 101915558 | +967 1-699888</span>
              </div>
            </div>

          </div>
        </div>
      `;
    }

    if (showAttribution) {
      footerCustomHtml += `
        <div class="footer-note" style="margin-top: 25px; text-align: center; font-size: 10px; color: #64748b; border-top: 1px solid #f1f5f9; padding-top: 10px; page-break-inside: avoid;">
          تم توليد هذا التقرير تلقائياً بواسطة تطبيق الحسابات وادارة المشاريع - ${companyName} | توقيع المهندس/المصمم ومطور النظام المعتمد | تاريخ الطباعة: ${new Date().toLocaleDateString('ar-EG-u-nu-latn')}
        </div>
      `;
    } else {
      footerCustomHtml += `
        <div class="footer-note" style="margin-top: 25px; text-align: center; font-size: 10px; color: #64748b; border-top: 1px solid #f1f5f9; padding-top: 10px; page-break-inside: avoid;">
          ${companyName} - تاريخ الطباعة: ${new Date().toLocaleDateString('ar-EG-u-nu-latn')}
        </div>
      `;
    }

    // Generate full self-contained print-ready HTML for the new window
    const fullHtml = `
<!DOCTYPE html>
<html dir="rtl" lang="ar">
  <head>
    <title>${printPreview.title}</title>
    <meta charset="utf-8">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700;800&display=swap" rel="stylesheet">
    <style>
      @media print {
        @page {
          size: A4 portrait;
          margin: 10mm 10mm 12mm 10mm;
        }
        body {
          margin: 0 !important;
          padding: 0 !important;
          -webkit-print-color-adjust: exact !important;
          print-color-adjust: exact !important;
        }
        .no-print-btn { display: none !important; }
        thead.report-header {
          display: table-header-group !important;
        }
        tfoot.report-footer {
          display: table-footer-group !important;
        }
        h1, h2, h3, h4, h5, h6, .report-section-title, .report-heading {
          break-after: avoid !important;
          page-break-after: avoid !important;
        }
        table, .report-data-table {
          break-before: auto !important;
          page-break-before: auto !important;
        }
        tr {
          break-inside: avoid !important;
          page-break-inside: avoid !important;
        }
        .chart-single-page {
          break-inside: avoid !important;
          page-break-inside: avoid !important;
          max-height: 940px !important;
        }
      }
      body {
        font-family: 'Cairo', 'Segoe UI', Tahoma, sans-serif;
        padding: 24px;
        color: #334155;
        direction: rtl;
        background-color: #fff;
        line-height: 1.5;
        margin: 0;
      }
      .official-report-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        border-bottom: 3px double #0f172a;
        padding-bottom: 12px;
        margin-bottom: 20px;
        page-break-after: avoid;
      }
      .header-col-right {
        text-align: right;
        flex: 1;
      }
      .header-col-center {
        text-align: center;
        flex: 1;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
      }
      .header-col-left {
        text-align: left;
        flex: 1;
      }
      .badge {
        font-size: 10px;
        font-weight: bold;
        color: #0369a1;
        background-color: #f0f9ff;
        border: 1px solid #bae6fd;
        border-radius: 9999px;
        padding: 4px 10px;
        margin-bottom: 6px;
        display: inline-block;
      }
      .header {
        display: none !important;
      }
      table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 10px;
        font-size: 13px;
      }
      th {
        background-color: #1e293b !important;
        color: #ffffff !important;
        font-weight: bold;
        text-align: right;
        padding: 8px 10px;
        border: 1px solid #0f172a;
      }
      td {
        padding: 8px 10px;
        border: 1px solid #cbd5e1;
        text-align: right;
      }
      tr:nth-child(even) td {
        background-color: #f8fafc;
      }
      /* عمود البيان: مساحة أكبر من باقي الأعمدة */
      th.col-statement,
      td.col-statement,
      .col-statement,
      .col-description,
      .col-desc {
        width: 38% !important;
        min-width: 170px !important;
        font-weight: 700 !important;
        text-align: right !important;
      }
      /* عمود الملاحظات: أصغر حجماً والخط فيه بحجم صغير */
      th.col-notes,
      td.col-notes,
      .col-notes {
        width: 14% !important;
        font-size: 9.5px !important;
        color: #64748b !important;
        line-height: 1.35 !important;
        font-weight: normal !important;
        word-break: break-word !important;
      }
      .total-section {
        margin-top: 20px;
        display: flex;
        justify-content: flex-end;
        gap: 20px;
        font-weight: bold;
        font-size: 15px;
        border-top: 2px solid #cbd5e1;
        padding-top: 12px;
      }
      .total-box {
        background-color: #f1f5f9;
        padding: 10px 20px;
        border-radius: 6px;
        border: 1px solid #cbd5e1;
      }
      .footer-note {
        text-align: center;
        margin-top: 30px;
        padding-top: 10px;
        border-top: 1px solid #cbd5e1;
        font-size: 11px;
        color: #64748b;
      }
      .no-print-btn {
        display: block;
        text-align: center;
        margin-bottom: 20px;
        padding: 12px;
        background-color: #f0f9ff;
        border: 1px solid #bae6fd;
        border-radius: 12px;
      }
      .print-btn {
        background-color: #0284c7;
        color: white;
        border: none;
        padding: 10px 24px;
        border-radius: 8px;
        font-size: 14px;
        font-weight: bold;
        cursor: pointer;
        font-family: 'Cairo', sans-serif;
        box-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1);
        transition: background-color 0.2s;
      }
      .print-btn:hover {
        background-color: #0369a1;
      }
    </style>
  </head>
  <body>
    <div class="no-print-btn">
      <button class="print-btn" onclick="window.print()">اضغط هنا لبدء الطباعة أو الحفظ كـ PDF 🖨️</button>
    </div>
    
    ${headerHtml}
    ${printPreview.htmlContent}
    ${footerCustomHtml}
    
    <script>
      window.onload = function() {
        setTimeout(function() {
          window.print();
        }, 500);
      }
    </script>
  </body>
</html>
    `;
    
    printWindow.document.write(fullHtml);
    printWindow.document.close();
    
    if ((window as any).showToast) {
      (window as any).showToast("📋 جاري تحضير وفتح نافذة الطباعة الرسمية وحفظ PDF...");
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-800" id="main-app-container">
      
      {/* Upper Navigation Header */}
      <header className="sticky top-0 z-40 w-full bg-slate-900 text-white shadow-md border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            
            {/* App Logo / Name */}
            <div className="flex items-center gap-2.5 sm:gap-3">
              <div className="w-12 h-9 rounded-lg p-0.5 bg-white shadow-md shrink-0 flex items-center justify-center border border-slate-700/50">
                <img src={companyLogo} alt="شعار الشركة" className="w-full h-full object-contain" />
              </div>
              <div>
                <h1 className="font-extrabold text-base tracking-tight leading-none text-white sm:text-lg">الحسابات وادارة المشاريع</h1>
                <span className="text-[10px] text-amber-300/90 font-medium">{companyName}</span>
              </div>

              {/* 🚪 Main Exit Button in Top Header */}
              <button
                onClick={() => setShowExitConfirmModal(true)}
                className="p-1.5 sm:px-3 sm:py-1.5 bg-slate-800 hover:bg-rose-900/60 text-rose-400 hover:text-rose-300 rounded-xl border border-rose-500/30 hover:border-rose-500/50 transition-all cursor-pointer shadow-2xs mr-1.5 sm:mr-3 flex items-center gap-1.5 text-xs font-bold shrink-0"
                title="الخروج النهائي من التطبيق"
              >
                <LogOut size={16} className="text-rose-400" />
                <span className="hidden sm:inline text-white font-extrabold">خروج</span>
              </button>

              {/* 📲 Android Install Button */}
              <button
                type="button"
                onClick={() => setShowAndroidInstallModal(true)}
                className="p-1.5 sm:px-3 sm:py-1.5 bg-emerald-600/25 hover:bg-emerald-600/40 text-emerald-300 hover:text-white rounded-xl border border-emerald-400/40 transition-all cursor-pointer shadow-2xs mr-1 sm:mr-2 flex items-center gap-1.5 text-xs font-bold shrink-0"
                title="تثبيت التطبيق على هاتف أندرويد واستخدامه بدون إنترنت (APK)"
                id="header-install-android-btn"
              >
                <Smartphone size={16} className="text-emerald-400" />
                <span className="hidden sm:inline font-extrabold text-white">تثبيت 📲</span>
              </button>

              {/* ↩️ Undo Button in Top Header */}
              <button
                type="button"
                onClick={handleOpenUndoModal}
                className={`p-1.5 sm:px-3 sm:py-1.5 rounded-xl border transition-all cursor-pointer shadow-2xs mr-1 sm:mr-2 flex items-center gap-1.5 text-xs font-bold shrink-0 ${
                  undoStack.length > 0
                    ? 'bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border-amber-400/50 shadow-amber-500/10'
                    : 'bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-slate-300 border-slate-700/60'
                }`}
                title={
                  undoStack.length > 0
                    ? `التراجع عن العمليات السابقة (${undoStack.length} عمليات متاحة)`
                    : 'التراجع عن العمليات (لا توجد عمليات سابقة)'
                }
                id="header-undo-action-btn"
              >
                <RotateCcw size={16} className={`stroke-[2.2] ${undoStack.length > 0 ? 'text-amber-400' : 'text-slate-400'}`} />
                <span className="hidden sm:inline font-extrabold text-white">تراجع</span>
                {undoStack.length > 0 && (
                  <span className="px-1.5 py-0.2 rounded-full text-[10px] font-black bg-amber-500 text-slate-950 leading-tight">
                    {undoStack.length}
                  </span>
                )}
              </button>

              {/* ☰ Dedicated Menu Icon Button in Top Header (Only icon with 3 lines, no text) */}
              <button
                type="button"
                onClick={() => setMobileMenuOpen(true)}
                className="p-2 bg-slate-800 hover:bg-slate-700 text-amber-400 hover:text-white rounded-xl border border-amber-500/30 transition-all cursor-pointer shadow-2xs mr-1 sm:mr-2 flex items-center justify-center shrink-0 active:scale-95"
                title="القائمة الرئيسية والتنقل الشامل"
                id="header-options-main-trigger-btn"
              >
                <Menu size={19} className="stroke-[2.2]" />
              </button>
            </div>

            {/* Desktop Navbar Menu */}
            <nav className="hidden md:flex space-x-reverse space-x-1">
              
              <button 
                onClick={() => handleTabChange('main_hub')}
                className={`px-3 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                  activeTab === 'main_hub' 
                    ? 'bg-amber-500 text-slate-950 shadow-xs font-black ring-1 ring-amber-400/60' 
                    : 'text-amber-300 hover:text-white hover:bg-slate-800/50'
                }`}
                title="النافذة الرئيسية للتطبيق - مركز القيادة والإدارة الشاملة"
              >
                <Building2 size={14} />
                النافذة الرئيسية للتطبيق
              </button>

              <button 
                onClick={() => handleTabChange('construction_projects')}
                className={`px-3 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                  activeTab === 'construction_projects' || activeTab === 'projects'
                    ? 'bg-sky-600 text-white shadow-xs ring-1 ring-sky-400/40' 
                    : 'text-sky-300 hover:text-white hover:bg-slate-800/50'
                }`}
                title="إدارة المشاريع الإنشائية - لوحة التحكم بالمشاريع والتنفيذ"
              >
                <Building2 size={14} />
                إدارة المشاريع الإنشائية ({projects.length})
              </button>

              <button 
                onClick={() => handleTabChange('dashboard')}
                className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                  activeTab === 'dashboard' 
                    ? 'bg-slate-800 text-sky-400 border border-slate-700 shadow-xs' 
                    : 'text-slate-300 hover:text-white hover:bg-slate-800/50'
                }`}
              >
                <LayoutDashboard size={14} />
                الرئيسية
              </button>

              <button 
                onClick={() => handleTabChange('expenses')}
                className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                  activeTab === 'expenses' 
                    ? 'bg-slate-800 text-rose-400 border border-slate-700 shadow-xs' 
                    : 'text-slate-300 hover:text-white hover:bg-slate-800/50'
                }`}
              >
                <TrendingUp size={14} />
                النفقات اليومية
              </button>

              <button 
                onClick={() => handleTabChange('boq')}
                className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                  activeTab === 'boq' || activeTab === 'contract_items'
                    ? 'bg-slate-800 text-teal-400 border border-slate-700 shadow-xs' 
                    : 'text-slate-300 hover:text-white hover:bg-slate-800/50'
                }`}
                title="جدول الكميات وبنود عقد المشروع - متابعة التكاليف والكميات ونسب الإنجاز"
              >
                <FileSpreadsheet size={14} />
                جدول الكميات
              </button>

              <button 
                onClick={() => handleTabChange('workers')}
                className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                  activeTab === 'workers' 
                    ? 'bg-slate-800 text-sky-400 border border-slate-700 shadow-xs' 
                    : 'text-slate-300 hover:text-white hover:bg-slate-800/50'
                }`}
              >
                <Users size={14} />
                العمال
              </button>

              <button 
                onClick={() => handleTabChange('employees')}
                className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                  activeTab === 'employees' 
                    ? 'bg-slate-800 text-indigo-400 border border-slate-700 shadow-xs' 
                    : 'text-slate-300 hover:text-white hover:bg-slate-800/50'
                }`}
              >
                <Briefcase size={14} />
                الموظفين
              </button>

              <button 
                onClick={() => handleTabChange('suppliers')}
                className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                  activeTab === 'suppliers' 
                    ? 'bg-slate-800 text-amber-400 border border-slate-700 shadow-xs' 
                    : 'text-slate-300 hover:text-white hover:bg-slate-800/50'
                }`}
              >
                <Truck size={14} />
                الموردين
              </button>

              <button 
                onClick={() => handleTabChange('budget')}
                className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                  activeTab === 'budget' 
                    ? 'bg-slate-800 text-emerald-400 border border-slate-700 shadow-xs' 
                    : 'text-slate-300 hover:text-white hover:bg-slate-800/50'
                }`}
              >
                <Wallet size={14} />
                الميزانية العامة
              </button>

              <button 
                onClick={() => handleTabChange('debts')}
                className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                  activeTab === 'debts' 
                    ? 'bg-slate-800 text-amber-400 border border-slate-700 shadow-xs' 
                    : 'text-slate-300 hover:text-white hover:bg-slate-800/50'
                }`}
              >
                <Coins size={14} />
                الديون والالتزامات
              </button>

              <button 
                onClick={() => handleTabChange('reports')}
                className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                  activeTab === 'reports' 
                    ? 'bg-slate-800 text-violet-400 border border-slate-700 shadow-xs' 
                    : 'text-slate-300 hover:text-white hover:bg-slate-800/50'
                }`}
              >
                <FileText size={14} />
                التقارير الشاملة
              </button>

              <button 
                onClick={() => handleTabChange('evaluations')}
                className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                  activeTab === 'evaluations' 
                    ? 'bg-slate-800 text-amber-400 border border-slate-700 shadow-xs' 
                    : 'text-slate-300 hover:text-white hover:bg-slate-800/50'
                }`}
              >
                <Award size={14} />
                تقييم الأداء
              </button>

              <button 
                onClick={() => handleTabChange('company_assets')}
                className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                  activeTab === 'company_assets' 
                    ? 'bg-slate-800 text-amber-400 border border-slate-700 shadow-xs' 
                    : 'text-slate-300 hover:text-white hover:bg-slate-800/50'
                }`}
              >
                <Boxes size={14} />
                أصول الشركة
              </button>

              <button 
                onClick={() => handleTabChange('backup')}
                className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                  activeTab === 'backup' 
                    ? 'bg-slate-800 text-amber-400 border border-slate-700 shadow-xs ring-1 ring-amber-500/30' 
                    : 'text-amber-300/90 hover:text-amber-200 hover:bg-slate-800/50'
                }`}
              >
                <Database size={14} />
                النسخ الاحتياطي
              </button>

            </nav>

          </div>
        </div>

      </header>

      {/* Sub-header Active Project Context Bar */}
      {activeTab !== 'main_hub' && activeTab !== 'projects' && activeTab !== 'construction_projects' && activeTab !== 'general_debts' && activeTab !== 'company_assets' && activeTab !== 'evaluations' && (() => {
        const activeProj = projects.find(p => p.id === activeProjectId);
        let statusLabel = 'نشط';
        let statusCls = 'bg-emerald-500/20 text-emerald-300 border-emerald-400/30';

        if (activeProj?.status === 'completed') {
          statusLabel = 'مكتمل ومسلم';
          statusCls = 'bg-sky-500/20 text-sky-300 border-sky-400/30';
        } else if (activeProj?.status === 'planning') {
          statusLabel = 'قيد التخطيط';
          statusCls = 'bg-amber-500/20 text-amber-300 border-amber-400/30';
        } else if (activeProj?.status === 'paused') {
          statusLabel = 'متوقف مؤقتاً';
          statusCls = 'bg-rose-500/20 text-rose-300 border-rose-400/30';
        } else if (activeProj?.status === 'active') {
          statusLabel = 'نشط';
          statusCls = 'bg-emerald-500/20 text-emerald-300 border-emerald-400/30';
        }

        return (
          <div className="bg-slate-800 border-b border-slate-700/80 text-white px-3 py-1.5 text-xs font-bold shadow-xs">
            <div className="max-w-7xl mx-auto flex items-center justify-between gap-2">
              <div className="flex items-center gap-2 truncate">
                <span className={`px-2 py-0.5 rounded-full border text-[10px] font-extrabold shrink-0 ${statusCls}`}>
                  {statusLabel}
                </span>
                <span className="text-white font-extrabold truncate text-xs sm:text-sm">
                  {projectName}
                </span>
                {activeProj?.location && (
                  <span className="hidden sm:inline text-slate-400 font-medium text-xs">
                    - {activeProj.location}
                  </span>
                )}
              </div>
              <button
                onClick={() => handleTabChange('construction_projects')}
                className="px-2.5 py-1 bg-slate-700 hover:bg-sky-600 text-sky-200 hover:text-white rounded-lg text-[11px] font-bold transition-colors shrink-0 flex items-center gap-1 cursor-pointer shadow-2xs"
              >
                <ArrowRight size={13} />
                <span>إدارة المشاريع</span>
              </button>
            </div>
          </div>
        );
      })()}

      {/* Main Container Content */}
      <main className="flex-1 max-w-7xl mx-auto w-full px-2.5 sm:px-4 lg:px-6 py-3.5 sm:py-5 pb-[calc(6rem+env(safe-area-inset-bottom,0px))] sm:pb-28">
        {renderTabContent()}
      </main>

      {/* Bottom Quick Navigation Bar (Active across all application windows & project tabs) */}
      <BottomNavigation activeTab={activeTab} onTabChange={handleTabChange} />

      {/* Humble professional credit footer */}
      <footer className="bg-white border-t border-slate-100 py-6 pb-28 sm:pb-32 mt-12 text-center text-xs text-slate-400">
        <div className="max-w-7xl mx-auto px-4">
          <p>© {new Date().getFullYear()} الحسابات وادارة المشاريع. جميع الحقوق محفوظة.</p>
          <p className="mt-1 text-[10px]">تطبيق مالي محلي متكامل لحفظ حسابات العمل والمشاريع في المتصفح أوفلاين.</p>
        </div>
      </footer>

      {/* User Name Form Prompt */}
      {promptUserName && (
        <div 
          className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-900/80 backdrop-blur-xs p-3 sm:p-4 overflow-y-auto overscroll-contain"
          onTouchMove={(e) => {
            if (e.target === e.currentTarget) e.preventDefault();
          }}
        >
          <div 
            className="bg-white p-5 sm:p-6 rounded-2xl border border-slate-200 shadow-xl max-w-md w-full space-y-4 text-right my-auto max-h-[90vh] overflow-y-auto overscroll-contain" 
            dir="rtl"
            onClick={(e) => e.stopPropagation()}
          >
            <h3 className="text-lg font-extrabold text-slate-800">الانضمام إلى كشف الحساب المشترك</h3>
            <p className="text-slate-500 text-xs leading-relaxed">
              أنت على وشك الدخول إلى كشف حساب مشترك. الرجاء كتابة اسمك (مثال: المهندس علي، أبو أحمد) ليتم وسم الحركات والبيانات التي تضيفها أو تعدلها باسمك.
            </p>
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-400">اسم المستخدم</label>
              <input 
                type="text"
                placeholder="اكتب اسمك هنا..."
                value={tempUserName}
                onChange={(e) => setTempUserName(e.target.value)}
                className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-700 focus:outline-hidden focus:border-sky-500"
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handleSaveUserName();
                }}
              />
            </div>
            <div className="space-y-2 pt-1">
              <button 
                onClick={handleSaveUserName}
                className="w-full bg-sky-600 hover:bg-sky-700 text-white font-bold py-2.5 px-4 rounded-xl text-xs transition-colors cursor-pointer"
              >
                دخول الحساب المشترك
              </button>

              <div className="pt-2 border-t border-slate-100 text-center">
                <button
                  type="button"
                  onClick={handleRestoreOwnerRole}
                  className="w-full py-2.5 px-3 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 font-extrabold text-xs rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <span>👑</span>
                  <span>أنا مالك المشروع (المهندس/ياسر عقيل) - دخول كمالك رئيسي</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Toast notifications */}
      {toastMessage && (
        <div className="fixed bottom-20 sm:bottom-24 left-5 z-50 max-w-sm bg-slate-900 text-white text-xs font-bold py-3.5 px-5 rounded-xl shadow-xl border border-slate-800 animate-fade-in flex items-center gap-2" dir="rtl">
          <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></div>
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Seamless Custom Print Preview Modal */}
      {printPreview && (
        <div 
          className="fixed inset-0 z-[100] flex flex-col bg-slate-950/70 backdrop-blur-sm p-3 sm:p-4 overflow-y-auto overscroll-contain" 
          id="print-preview-modal-bg"
          onTouchMove={(e) => {
            if (e.target === e.currentTarget) e.preventDefault();
          }}
        >
          <div 
            className="bg-white rounded-2xl max-w-4xl w-full mx-auto my-auto shadow-2xl flex flex-col border border-slate-200 max-h-[95vh] overflow-y-auto overscroll-contain" 
            id="print-preview-container-root"
            onClick={(e) => e.stopPropagation()}
          >
            
            {/* Header with actions */}
            <div className="flex items-center justify-between p-4 border-b border-slate-100 bg-slate-50 rounded-t-2xl no-print" id="print-preview-header">
              <div className="flex items-center gap-2 text-right" dir="rtl">
                <FileText className="text-sky-500" size={18} />
                <span className="font-extrabold text-sm text-slate-700">تخصيص وتصدير التقرير الرسمي</span>
              </div>
              <div className="flex gap-2 flex-wrap justify-end">
                <button
                  onClick={printInNewTab}
                  className="bg-sky-600 hover:bg-sky-700 text-white font-bold text-xs py-2 px-4 rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Printer size={14} />
                  طباعة وحفظ كـ PDF رسمي 🖨️
                </button>
                <button
                  onClick={() => {
                    if (!printPreview) return;
                    
                    const hasExistingHeader = printPreview.htmlContent.includes('report-header') || printPreview.htmlContent.includes('official-report-header') || printPreview.htmlContent.includes('pdf-report-root');

                    const headerHtml = hasExistingHeader ? '' : `
                      <div class="official-report-header" style="display: flex; justify-content: space-between; align-items: center; border-bottom: 3px double #002B49; padding-bottom: 12px; margin-bottom: 20px; page-break-after: avoid; direction: rtl;">
                        <div class="header-col-right" style="text-align: right; flex: 1.35;">
                          <h2 style="margin: 0; font-size: 15px; color: #002B49; font-weight: 800; font-family: 'Cairo', sans-serif; line-height: 1.25;">${companyName}</h2>
                          <div style="font-size: 13.5px; font-weight: 800; color: #E85D25; font-family: 'Segoe UI', Arial, sans-serif; letter-spacing: 0.3px; margin-top: 3px; direction: ltr; text-align: right; line-height: 1.25;">World of Elites for Trading & Contracting</div>
                          <p style="margin: 4px 0 0 0; font-size: 12px; font-weight: 700; color: #1e293b; line-height: 1.35;">الإدارة المالية والتنفيذية للمشاريع</p>
                          <p style="margin: 2px 0 0 0; font-size: 11.5px; font-weight: 600; color: #334155; line-height: 1.35;">قسم الحسابات والرقابة المالية</p>
                        </div>
                        <div class="header-col-center" style="text-align: center; flex: 1; display: flex; flex-direction: column; align-items: center; justify-content: center;">
                          <div style="width: 72px; height: 50px; border-radius: 8px; overflow: hidden; display: flex; align-items: center; justify-content: center; margin-bottom: 4px; background-color: #ffffff; padding: 2px;">
                            <img src="${companyLogo}" style="max-width: 100%; max-height: 100%; object-fit: contain;" alt="شعار الشركة" />
                          </div>
                          <h1 style="margin: 0; font-size: 16px; font-weight: 800; color: #002B49;">${printPreview.title}</h1>
                          <span style="font-size: 10px; color: #64748b; margin-top: 2px; font-weight: bold;">الإدارة المالية والتنفيذية للمشاريع</span>
                        </div>
                        <div class="header-col-left" style="text-align: left; flex: 1;">
                          <h3 style="margin: 0; font-size: 11px; color: #002B49; font-weight: bold;">الحسابات وإدارة المشاريع</h3>
                          <p style="margin: 2px 0 0 0; font-size: 10.5px; color: #E85D25; font-weight: bold;">المشروع: ${projectName || 'مشروع العمل الجاري'}</p>
                          <p style="margin: 2px 0 0 0; font-size: 9.5px; color: #64748b;">تاريخ استخراج التقرير: ${new Date().toLocaleDateString('ar-EG-u-nu-latn')}</p>
                          <p style="margin: 2px 0 0 0; font-size: 9.5px; color: #16a34a; font-weight: bold;">الحالة: كشف معتمد داخلياً</p>
                        </div>
                      </div>
                    `;

                    // Generate full self-contained print-ready HTML
                    const fullHtml = `
<!DOCTYPE html>
<html dir="rtl" lang="ar">
  <head>
    <title>${printPreview.title}</title>
    <meta charset="utf-8">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700;800&display=swap" rel="stylesheet">
    <style>
      @media print {
        @page {
          size: A4 portrait;
          margin: 10mm 10mm 12mm 10mm;
        }
        body {
          margin: 0 !important;
          padding: 0 !important;
          -webkit-print-color-adjust: exact !important;
          print-color-adjust: exact !important;
        }
        .no-print-btn { display: none !important; }
        thead.report-header {
          display: table-header-group !important;
        }
        tfoot.report-footer {
          display: table-footer-group !important;
        }
        h1, h2, h3, h4, h5, h6, .report-section-title, .report-heading {
          break-after: avoid !important;
          page-break-after: avoid !important;
        }
        table, .report-data-table {
          break-before: auto !important;
          page-break-before: auto !important;
        }
        tr {
          break-inside: avoid !important;
          page-break-inside: avoid !important;
        }
        .chart-single-page {
          break-inside: avoid !important;
          page-break-inside: avoid !important;
          max-height: 940px !important;
        }
      }
      body {
        font-family: 'Cairo', 'Segoe UI', Tahoma, sans-serif;
        padding: 24px;
        color: #334155;
        direction: rtl;
        background-color: #fff;
        line-height: 1.5;
        margin: 0;
      }
      .official-report-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        border-bottom: 3px double #0f172a;
        padding-bottom: 12px;
        margin-bottom: 20px;
        page-break-after: avoid;
      }
      .header-col-right {
        text-align: right;
        flex: 1;
      }
      .header-col-center {
        text-align: center;
        flex: 1;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
      }
      .header-col-left {
        text-align: left;
        flex: 1;
      }
      .badge {
        font-size: 10px;
        font-weight: bold;
        color: #0369a1;
        background-color: #f0f9ff;
        border: 1px solid #bae6fd;
        border-radius: 9999px;
        padding: 4px 10px;
        margin-bottom: 6px;
        display: inline-block;
      }
      .header {
        display: none !important;
      }
      table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 10px;
        font-size: 13px;
      }
      th {
        background-color: #1e293b !important;
        color: #ffffff !important;
        font-weight: bold;
        text-align: right;
        padding: 8px 10px;
        border: 1px solid #0f172a;
      }
      td {
        padding: 8px 10px;
        border: 1px solid #cbd5e1;
        text-align: right;
      }
      tr:nth-child(even) td {
        background-color: #f8fafc;
      }
      .total-section {
        margin-top: 20px;
        display: flex;
        justify-content: flex-end;
        gap: 20px;
        font-weight: bold;
        font-size: 15px;
        border-top: 2px solid #cbd5e1;
        padding-top: 12px;
      }
      .total-box {
        background-color: #f1f5f9;
        padding: 10px 20px;
        border-radius: 6px;
        border: 1px solid #cbd5e1;
      }
      .footer-note {
        text-align: center;
        margin-top: 30px;
        padding-top: 10px;
        border-top: 1px solid #cbd5e1;
        font-size: 11px;
        color: #64748b;
      }
      .no-print-btn {
        display: block;
        text-align: center;
        margin-bottom: 20px;
        padding: 12px;
        background-color: #f0f9ff;
        border: 1px solid #bae6fd;
        border-radius: 12px;
      }
      .print-btn {
        background-color: #0284c7;
        color: white;
        border: none;
        padding: 10px 24px;
        border-radius: 8px;
        font-size: 14px;
        font-weight: bold;
        cursor: pointer;
        font-family: 'Cairo', sans-serif;
        box-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1);
        transition: background-color 0.2s;
      }
      .print-btn:hover {
        background-color: #0369a1;
      }
    </style>
  </head>
  <body>
    <div class="no-print-btn">
      <button class="print-btn" onclick="window.print()">اضغط هنا لبدء الطباعة أو الحفظ كـ PDF 🖨️</button>
    </div>
    
    ${headerHtml}
    ${printPreview.htmlContent}
    ${!hasExistingHeader ? `
      <div style="border-top: 2px solid #002B49; padding-top: 10px; margin-top: 25px; font-size: 11.5px; color: #002B49; direction: rtl; line-height: 1.5; font-family: 'Cairo', 'Segoe UI', Tahoma, sans-serif; page-break-inside: avoid;">
        <div style="display: flex; justify-content: space-between; align-items: center; gap: 16px;">
          
          <!-- جهة اليمين: العنوان في سطر والبريد والموقع في سطر واحد يفصل بينهما الرمز التعبيري، في صفين فقط بدون نصوص توضيحية -->
          <div style="text-align: right; flex: 1.35; min-width: 0; display: flex; flex-direction: column; justify-content: center; gap: 7px;">
            <div style="display: flex; align-items: center; gap: 8px; white-space: nowrap;">
              <span style="display: inline-flex; align-items: center; justify-content: center; width: 22px; height: 22px; min-width: 22px; min-height: 22px; background-color: #E85D25; border-radius: 50%; vertical-align: middle;">
                <svg style="width: 12px; height: 12px;" viewBox="0 0 24 24" fill="none" stroke="#ffffff" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round">
                  <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                  <circle cx="12" cy="10" r="3"></circle>
                </svg>
              </span>
              <span style="color: #002B49; font-weight: 700; font-size: 11.5px; font-family: 'Cairo', 'Segoe UI', Tahoma, sans-serif;">${companyAddress}</span>
            </div>
            <div style="display: flex; align-items: center; gap: 7px; white-space: nowrap;">
              <span style="display: inline-flex; align-items: center; justify-content: center; width: 22px; height: 22px; min-width: 22px; min-height: 22px; background-color: #E85D25; border-radius: 50%; vertical-align: middle;">
                <svg style="width: 12px; height: 12px;" viewBox="0 0 24 24" fill="none" stroke="#ffffff" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round">
                  <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path>
                  <polyline points="22,6 12,13 2,6"></polyline>
                </svg>
              </span>
              <a href="mailto:Info@WorldofElites.com" style="direction: ltr; font-family: 'Segoe UI', Tahoma, sans-serif; font-weight: 700; font-size: 11.5px; color: #002B49; text-decoration: none;">Info@WorldofElites.com</a>
              
              <span style="display: inline-flex; align-items: center; justify-content: center; width: 22px; height: 22px; min-width: 22px; min-height: 22px; background-color: #E85D25; border-radius: 50%; vertical-align: middle; margin: 0 4px;">
                <svg style="width: 12px; height: 12px;" viewBox="0 0 24 24" fill="none" stroke="#ffffff" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round">
                  <circle cx="12" cy="12" r="10"></circle>
                  <line x1="2" y1="12" x2="22" y2="12"></line>
                  <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path>
                </svg>
              </span>
              <a href="https://www.WorldofElites.com" target="_blank" style="direction: ltr; font-family: 'Segoe UI', Tahoma, sans-serif; font-weight: 700; font-size: 11.5px; color: #002B49; text-decoration: none;">www.WorldofElites.com</a>
            </div>
          </div>

          <!-- خط عمودي فاصل بين الجهة اليمنى والجهة اليسرى -->
          <div style="width: 1.5px; min-height: 46px; background-color: #cbd5e1; align-self: stretch;"></div>

          <!-- جهة اليسار: أرقام التواصل في صفين فقط، بدون نصوص توضيحية، بأيقونات بيضاء داخل دوائر برتقالية من اليسار لليمين -->
          <div style="text-align: left; direction: ltr; flex: 1; min-width: 0; display: flex; flex-direction: column; justify-content: center; gap: 7px;">
            <div style="display: flex; align-items: center; gap: 8px; white-space: nowrap;">
              <span style="display: inline-flex; align-items: center; justify-content: center; width: 22px; height: 22px; min-width: 22px; min-height: 22px; background-color: #E85D25; border-radius: 50%; vertical-align: middle;">
                <svg style="width: 12px; height: 12px;" viewBox="0 0 24 24" fill="none" stroke="#ffffff" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round">
                  <rect x="5" y="2" width="14" height="20" rx="2" ry="2"></rect>
                  <line x1="12" y1="18" x2="12.01" y2="18"></line>
                </svg>
              </span>
              <span style="direction: ltr; display: inline-block; font-family: 'Segoe UI', Tahoma, monospace, sans-serif; font-weight: 700; font-size: 12px; color: #002B49; letter-spacing: 0.2px;">+967 782 222 877 | +967 779 992 996</span>
            </div>
            <div style="display: flex; align-items: center; gap: 8px; white-space: nowrap;">
              <span style="display: inline-flex; align-items: center; justify-content: center; width: 22px; height: 22px; min-width: 22px; min-height: 22px; background-color: #E85D25; border-radius: 50%; vertical-align: middle;">
                <svg style="width: 12px; height: 12px;" viewBox="0 0 24 24" fill="none" stroke="#ffffff" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round">
                  <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
                </svg>
              </span>
              <span style="direction: ltr; display: inline-block; font-family: 'Segoe UI', Tahoma, monospace, sans-serif; font-weight: 700; font-size: 12px; color: #002B49; letter-spacing: 0.2px;">+967 101915558 | +967 1-699888</span>
            </div>
          </div>

        </div>
      </div>
    ` : ''}
    <div class="footer-note">تم توليد هذا التقرير تلقائياً بواسطة تطبيق الحسابات وادارة المشاريع - ${companyName} - تاريخ الطباعة: ${new Date().toLocaleDateString('ar-EG-u-nu-latn')}</div>
    <script>
      // Auto-trigger print modal on loading
      window.onload = function() {
        setTimeout(function() {
          window.print();
        }, 300);
      }
    </script>
  </body>
</html>
                    `;
                    
                    const blob = new Blob([fullHtml], { type: 'text/html;charset=utf-8;' });
                    const url = URL.createObjectURL(blob);
                    const link = document.createElement('a');
                    link.href = url;
                    const safeTitle = ensureDateInFilename(printPreview.title);
                    link.download = safeTitle.toLowerCase().endsWith('.html') ? safeTitle : `${safeTitle}.html`;
                    document.body.appendChild(link);
                    link.click();
                    document.body.removeChild(link);
                    
                    // Show a helpful user toast instruction
                    if ((window as any).showToast) {
                      (window as any).showToast("تم تحميل ملف التقرير مجهزاً للطباعة! افتحه للطباعة أو الحفظ كـ PDF.");
                    }
                  }}
                  className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs py-2 px-4 rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Download size={14} />
                  تحميل ملف HTML للطباعة 🌐
                </button>
                <button
                  onClick={() => {
                    window.print();
                  }}
                  className="bg-slate-700 hover:bg-slate-800 text-white font-bold text-xs py-2 px-4 rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Printer size={14} />
                  طباعة المتصفح التقليدية 🖨️
                </button>
                <button
                  onClick={() => setPrintPreview(null)}
                  className="bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold text-xs py-2 px-4 rounded-xl transition-colors cursor-pointer"
                >
                  إغلاق
                </button>
              </div>
            </div>

            {/* Configurable Report Metadata Control Panel */}
            <div className="p-4 bg-slate-50 border-b border-slate-200 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 no-print text-right" dir="rtl">
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-600 block">اسم الشركة (الترويسة الرسمية):</label>
                <input
                  type="text"
                  value={companyName}
                  onChange={(e) => {
                    setCompanyName(e.target.value);
                    localStorage.setItem('site_company_name', e.target.value);
                  }}
                  placeholder="ورلد أوف إيليتس للتجارة والمقاولات"
                  className="w-full p-2 bg-white border border-slate-200 rounded-lg text-xs font-bold focus:outline-hidden focus:border-sky-500"
                />
              </div>
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-600 block">اسم المشروع (الترويسة الرسمية):</label>
                <input
                  type="text"
                  value={projectName}
                  onChange={(e) => {
                    setProjectName(e.target.value);
                    localStorage.setItem('site_project_name', e.target.value);
                  }}
                  placeholder="مشروع المقاولات والإنشاءات الرئيسي"
                  className="w-full p-2 bg-white border border-slate-200 rounded-lg text-xs font-bold focus:outline-hidden focus:border-sky-500"
                />
              </div>
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-600 block">عنوان الشركة (التذييل الرسمي):</label>
                <input
                  type="text"
                  value={companyAddress}
                  onChange={(e) => {
                    setCompanyAddress(e.target.value);
                    localStorage.setItem('site_company_address', e.target.value);
                  }}
                  placeholder="صنعاء - بيت بوس - شارع الخمسين - 50 St - Bait Boos - Sana'a"
                  className="w-full p-2 bg-white border border-slate-200 rounded-lg text-xs font-bold focus:outline-hidden focus:border-sky-500"
                />
              </div>
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-600 block">أرقام التواصل (التذييل الرسمي):</label>
                <input
                  type="text"
                  value={companyPhone}
                  onChange={(e) => {
                    setCompanyPhone(e.target.value);
                    localStorage.setItem('site_company_phone', e.target.value);
                  }}
                  placeholder="+967 782 222 877 | +967 779 992 996"
                  className="w-full p-2 bg-white border border-slate-200 rounded-lg text-xs font-bold focus:outline-hidden focus:border-sky-500"
                />
              </div>
            </div>

            {/* Info notice for sandbox */}
            <div className="p-3 bg-sky-50 border-b border-sky-100 text-sky-800 text-[11px] leading-relaxed no-print text-right" dir="rtl" id="print-preview-info">
              💡 <strong>تنبيه تصدير PDF:</strong> لتفادي قيود حماية المتصفح، تم تزويد التطبيق بميزة <strong className="text-sky-700">"تصدير كـ PDF فوري"</strong> التي تقوم بتجميع التقرير وتنزيله مباشرة كملف PDF مجهز تماماً! يمكنك تعديل بيانات الشركة والمشروع أعلاه وسيتم تحديثها في التقرير فوراً!
            </div>

            {/* Sheet view */}
            <div className="p-8 overflow-x-auto bg-white" dir="rtl">
              {(() => {
                const showHeader = localStorage.getItem('site_show_report_header') !== 'false';
                const showSignatures = localStorage.getItem('site_show_signature_blocks') !== 'false';
                const showAttribution = localStorage.getItem('site_show_designer_attribution') !== 'false';
                const footerNotes = (localStorage.getItem('site_report_footer_notes') || '').trim();
                const hasExistingHeader = printPreview.htmlContent.includes('report-header') || printPreview.htmlContent.includes('official-report-header') || printPreview.htmlContent.includes('pdf-report-root');

                return (
                  <div id="print-preview-document-body" className="bg-white p-2">
                    <style dangerouslySetInnerHTML={{ __html: `
                      #print-preview-document-body {
                        font-family: 'Cairo', sans-serif !important;
                        color: #334155;
                        direction: rtl;
                      }
                      #print-preview-document-body .header {
                        display: none !important;
                      }
                    `}} />
                    
                    {showHeader && !hasExistingHeader && (
                      <div className="flex justify-between items-center border-b-2 border-[#002B49] pb-3 mb-5 text-right">
                        <div className="flex-1.35">
                          <h2 className="font-extrabold text-[15px] text-[#002B49] leading-snug">{companyName}</h2>
                          <div className="text-[13.5px] font-bold text-[#E85D25] text-right tracking-tight mt-0.5" dir="ltr">World of Elites for Trading & Contracting</div>
                          <p className="text-[12px] text-slate-800 font-bold mt-1">الإدارة المالية والتنفيذية للمشاريع</p>
                          <p className="text-[11.5px] text-slate-700 font-semibold mt-0.5">قسم الحسابات والرقابة المالية</p>
                        </div>
                        <div className="text-center flex flex-col items-center flex-1">
                          <div className="w-18 h-12 rounded-lg overflow-hidden border border-slate-300 shadow-2xs mb-1 bg-white flex items-center justify-center p-1">
                            <img src={companyLogo} className="w-full h-full object-contain" alt="شعار الشركة" />
                          </div>
                          <h1 className="font-black text-lg text-[#002B49]">{printPreview.title}</h1>
                          <span className="text-[10px] text-slate-500 font-bold">الإدارة المالية والتنفيذية للمشاريع</span>
                        </div>
                        <div className="text-left flex-1">
                          <h3 className="font-bold text-xs text-[#002B49]">الحسابات وإدارة المشاريع</h3>
                          <p className="text-xs text-[#E85D25] font-bold mt-0.5">المشروع: {projectName || 'مشروع العمل الجاري'}</p>
                          <p className="text-xs text-slate-500 mt-0.5">تاريخ استخراج التقرير: {new Date().toLocaleDateString('ar-EG-u-nu-latn')}</p>
                          <p className="text-[10px] text-emerald-600 font-bold mt-0.5">الحالة: كشف معتمد داخلياً</p>
                        </div>
                      </div>
                    )}

                    <div dangerouslySetInnerHTML={{ __html: printPreview.htmlContent }} />

                    {footerNotes && (
                      <div className="mt-5 p-3.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-700 leading-relaxed">
                        <strong className="text-[#002B49] block mb-1">📌 الملاحظات الختامية والشروط:</strong>
                        <div className="whitespace-pre-wrap">{footerNotes}</div>
                      </div>
                    )}

                    {showSignatures && (
                      <div className="mt-8 pt-5 border-t border-dashed border-slate-300 grid grid-cols-3 gap-4 text-center text-xs font-bold text-[#002B49]">
                        <div>
                          <p className="mb-6">توقيع المستلم</p>
                          <p className="text-slate-300">.................................</p>
                        </div>
                        <div>
                          <p className="mb-6">توقيع المحاسب المسئول</p>
                          <p className="text-slate-300">.................................</p>
                        </div>
                        <div>
                          <p className="mb-6">توقيع واعتماد المدير</p>
                          <p className="text-slate-300">.................................</p>
                        </div>
                      </div>
                    )}

                    {!hasExistingHeader && (
                      <div className="mt-6 pt-3 border-t-2 border-[#002B49] text-[11.5px] text-[#002B49] flex justify-between items-center gap-4" dir="rtl">
                        {/* جهة اليمين: العنوان في سطر والبريد والموقع في سطر واحد يفصل بينهما الرمز التعبيري، في صفين فقط بدون نصوص توضيحية */}
                        <div className="text-right flex-1.35 min-w-0 flex flex-col justify-center gap-1.5">
                          <div className="flex items-center gap-2 whitespace-nowrap">
                            <span className="inline-flex items-center justify-center w-[22px] h-[22px] min-w-[22px] min-h-[22px] bg-[#E85D25] rounded-full text-white">
                              <MapPin size={12} strokeWidth={2.3} />
                            </span>
                            <span className="font-bold text-[11.5px] text-[#002B49]">{companyAddress}</span>
                          </div>
                          <div className="flex items-center gap-2 whitespace-nowrap">
                            <span className="inline-flex items-center justify-center w-[22px] h-[22px] min-w-[22px] min-h-[22px] bg-[#E85D25] rounded-full text-white">
                              <Mail size={12} strokeWidth={2.3} />
                            </span>
                            <a href="mailto:Info@WorldofElites.com" className="font-bold text-[11.5px] text-[#002B49]" dir="ltr">Info@WorldofElites.com</a>
                            
                            <span className="inline-flex items-center justify-center w-[22px] h-[22px] min-w-[22px] min-h-[22px] bg-[#E85D25] rounded-full text-white mx-1">
                              <Globe size={12} strokeWidth={2.3} />
                            </span>
                            <a href="https://www.WorldofElites.com" target="_blank" className="font-bold text-[11.5px] text-[#002B49]" dir="ltr">www.WorldofElites.com</a>
                          </div>
                        </div>

                        {/* خط عمودي فاصل بين الجهة اليمنى والجهة اليسرى */}
                        <div className="w-[1.5px] min-h-[46px] bg-slate-300 self-stretch"></div>

                        {/* جهة اليسار: أرقام التواصل في صفين فقط، بدون نصوص توضيحية، بأيقونات بيضاء داخل دوائر برتقالية من اليسار لليمين */}
                        <div className="text-left flex-1 min-w-0 flex flex-col justify-center gap-1.5" dir="ltr">
                          <div className="flex items-center gap-2 whitespace-nowrap">
                            <span className="inline-flex items-center justify-center w-[22px] h-[22px] min-w-[22px] min-h-[22px] bg-[#E85D25] rounded-full text-white">
                              <Smartphone size={12} strokeWidth={2.3} />
                            </span>
                            <span dir="ltr" className="font-bold text-[12px] text-[#002B49] tracking-tight">{companyPhone || '+967 782 222 877 | +967 779 992 996'}</span>
                          </div>
                          <div className="flex items-center gap-2 whitespace-nowrap">
                            <span className="inline-flex items-center justify-center w-[22px] h-[22px] min-w-[22px] min-h-[22px] bg-[#E85D25] rounded-full text-white">
                              <Phone size={12} strokeWidth={2.3} />
                            </span>
                            <span dir="ltr" className="font-bold text-[12px] text-[#002B49] tracking-tight">+967 101915558 | +967 1-699888</span>
                          </div>
                        </div>
                      </div>
                    )}

                    <div className="mt-6 pt-3 border-t border-slate-100 text-center text-[11px] text-slate-400">
                      {showAttribution ? (
                        <span>تم توليد هذا التقرير تلقائياً بواسطة تطبيق الحسابات وادارة المشاريع - {companyName} | توقيع المهندس/المصمم ومطور النظام المعتمد</span>
                      ) : (
                        <span>{companyName} - تاريخ الطباعة: ${new Date().toLocaleDateString('ar-EG-u-nu-latn')}</span>
                      )}
                    </div>
                  </div>
                );
              })()}
            </div>

          </div>
        </div>
      )}

      {/* Exit Confirmation Modal for Phone Back Button */}
      {showExitConfirmModal && (
        <div 
          className="fixed inset-0 z-[200] flex items-center justify-center bg-slate-900/80 backdrop-blur-xs p-4 dir-rtl text-right overscroll-contain"
          onTouchMove={(e) => {
            if (e.target === e.currentTarget) e.preventDefault();
          }}
        >
          <div 
            className="bg-white rounded-3xl border border-slate-200 shadow-2xl max-w-sm w-full p-6 space-y-4 text-center animate-scale-up overscroll-contain"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="w-16 h-16 bg-rose-100 text-rose-600 rounded-full flex items-center justify-center mx-auto mb-2">
              <LogOut size={32} />
            </div>

            <h3 className="text-lg font-black text-slate-900">تأكيد الخروج من التطبيق</h3>

            <p className="text-xs text-slate-600 leading-relaxed">
              هل أنت تأكد من رغبتك في الخروج من التطبيق؟ ستبقى جميع بياناتك وتحديثات الحسابات محفوظة بأمان.
            </p>

            <div className="flex flex-col gap-2 pt-2">
              <button
                onClick={handleExitApp}
                className="w-full bg-rose-600 hover:bg-rose-700 text-white font-extrabold text-xs py-3 px-4 rounded-xl shadow-md transition-all cursor-pointer flex items-center justify-center gap-2"
              >
                <LogOut size={16} />
                تأكيد الخروج من التطبيق
              </button>

              <button
                onClick={() => setShowExitConfirmModal(false)}
                className="w-full bg-slate-100 hover:bg-slate-200 text-slate-700 font-extrabold text-xs py-2.5 px-4 rounded-xl transition-all cursor-pointer"
              >
                إلغاء والبقاء في التطبيق
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Disabled Sync / Access Cancelled Modal */}
      {isSyncDisabled && (
        <div 
          className="fixed inset-0 bg-slate-900/85 backdrop-blur-md z-[300] flex items-center justify-center p-4 dir-rtl text-right overscroll-contain"
          onTouchMove={(e) => {
            if (e.target === e.currentTarget) e.preventDefault();
          }}
        >
          <div 
            className="bg-white rounded-3xl p-6 sm:p-8 max-w-md w-full text-center space-y-5 shadow-2xl border border-rose-100 overscroll-contain"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="w-16 h-16 bg-rose-100 text-rose-600 rounded-2xl flex items-center justify-center mx-auto shadow-inner">
              <Lock size={32} />
            </div>
            <div className="space-y-2">
              <h3 className="text-xl font-black text-slate-800">
                تم إلغاء المزامنة السحابية
              </h3>
              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed font-semibold">
                {syncDisabledMessage || 'تم إلغاء المزامنة السحابية لهذا المشروع من قبل المالك الرئيسي، ولم يعد الوصول أو الاطلاع عبر هذا الرابط متاحاً نهائياً.'}
              </p>
            </div>
            <button
              onClick={() => {
                setIsSyncDisabled(false);
                setProjects(prev => prev.map(p => p.syncProjectId === projectId ? { ...p, syncProjectId: null } : p));
                setProjectId(null);
                window.history.replaceState({}, '', window.location.pathname);
              }}
              className="w-full bg-slate-800 hover:bg-slate-900 text-white font-bold text-xs sm:text-sm py-3 px-6 rounded-xl transition-all shadow-md cursor-pointer"
            >
              متابعة بالوضع المحلي الشخصي
            </button>
          </div>
        </div>
      )}

      {/* ⚙️ Global Settings Modal */}
      <SettingsModal
        isOpen={showSettingsModal}
        onClose={() => setShowSettingsModal(false)}
        currency={currency}
        onCurrencyChange={(newCurr) => {
          setCurrency(newCurr);
          localStorage.setItem('site_currency', newCurr);
        }}
        companyName={companyName}
        onCompanyNameChange={(name) => {
          setCompanyName(name);
          localStorage.setItem('site_company_name', name);
        }}
        companyAddress={companyAddress}
        onCompanyAddressChange={(addr) => {
          setCompanyAddress(addr);
          localStorage.setItem('site_company_address', addr);
        }}
        companyPhone={companyPhone}
        onCompanyPhoneChange={(ph) => {
          setCompanyPhone(ph);
          localStorage.setItem('site_company_phone', ph);
        }}
        userName={userName}
        onUserNameChange={(uName) => {
          setUserName(uName);
          localStorage.setItem('site_user_name', uName);
        }}
        companyLogo={companyLogo}
        onCompanyLogoChange={(newLogo) => {
          setCompanyLogo(newLogo);
          if (newLogo && newLogo !== COMPANY_LOGO_BASE64) {
            localStorage.setItem('site_company_custom_logo', newLogo);
          } else {
            localStorage.removeItem('site_company_custom_logo');
          }
        }}
        onOpenBackupModal={() => setShowGlobalBackupModal(true)}
        onOpenAndroidInstall={() => setShowAndroidInstallModal(true)}
        onResetAllData={handleResetAllData}
        sharedRole={sharedRole}
        onRestoreOwnerRole={handleRestoreOwnerRole}
        theme={theme}
        onThemeChange={setTheme}
      />

      {/* ☰ Global Organized Options Drawer Menu */}
      <AppHeaderDrawerMenu
        isOpen={mobileMenuOpen}
        onClose={() => setMobileMenuOpen(false)}
        activeTab={activeTab}
        onNavigate={handleTabChange}
        projects={projects}
        activeProjectId={activeProjectId}
        onSelectProject={handleSelectProject}
        companyAssets={companyAssets}
        generalDebts={generalDebts}
        companyName={companyName}
        onOpenSettings={() => setShowSettingsModal(true)}
        onOpenAppInfo={() => setShowAppInfoModal(true)}
        onOpenAndroidInstall={() => setShowAndroidInstallModal(true)}
        onExitApp={() => setShowExitConfirmModal(true)}
        theme={theme}
        onToggleTheme={handleToggleTheme}
        onOpenGlobalBackup={() => setShowGlobalBackupModal(true)}
        onOpenUndo={handleOpenUndoModal}
        undoCount={undoStack.length}
      />

      {/* 📲 Android Install & APK Guide Modal */}
      <AndroidInstallModal
        isOpen={showAndroidInstallModal}
        onClose={() => setShowAndroidInstallModal(false)}
      />

      {/* 🌐 Real-time Offline Connectivity Status Toast */}
      <OfflineIndicator />

      {/* ℹ️ App & Company & Designer Info Modal */}
      <AppInfoModal
        isOpen={showAppInfoModal}
        onClose={() => setShowAppInfoModal(false)}
        companyName={companyName}
        companyAddress={companyAddress}
        companyPhone={companyPhone}
        companyLogo={companyLogo}
        designerName="م/ ياسر عقيل"
        designerPhone="771999911"
      />

      {/* 💾 Global Comprehensive Application Backup & Restore Modal */}
      <LocalStorageBackupModal
        isOpen={showGlobalBackupModal}
        onClose={() => setShowGlobalBackupModal(false)}
        onRestoreSuccess={() => {
          if (typeof window !== 'undefined') {
            if ((window as any).showToast) {
              (window as any).showToast('✅ تم استعادة كافة بيانات ومشاريع التطبيق بنجاح! جاري التحديث...');
            }
            setTimeout(() => {
              window.location.reload();
            }, 800);
          }
        }}
      />

      {/* ↩️ Undo Confirmation & History Modal */}
      <UndoModal
        isOpen={showUndoModal}
        onClose={() => setShowUndoModal(false)}
        undoStack={undoStack}
        onConfirmUndo={handleExecuteUndo}
        onClearUndoStack={handleClearUndoStack}
      />

      {/* 📍 Global Modal Draggable Scroll Indicator & Instant Jump Buttons for All Popups */}
      <GlobalModalScrollIndicator />

    </div>
  );
}
