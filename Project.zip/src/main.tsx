import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { ErrorBoundary } from './components/ErrorBoundary.tsx';
import { sanitizeStorageOnStartup } from './utils/safeStorage.ts';

// Immediate self-healing recovery before mounting to rescue devices stuck in storage quota overflow
try {
  sanitizeStorageOnStartup();
} catch (e) {
  console.warn('[Bootstrap] Non-fatal storage initialization warning:', e);
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <ErrorBoundary>
      <App />
    </ErrorBoundary>
  </StrictMode>,
);

