/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Capacitor } from '@capacitor/core';
import { Filesystem, Directory, Encoding } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';

export interface LocalStorageBackupPayload {
  backupFormatVersion: string;
  createdAt: string;
  appVersion: string;
  storageType: string;
  checksum: string;
  metadata: {
    totalKeysCount: number;
    keys: string[];
    approximateSizeBytes: number;
    approximateSizeKb: number;
    checksum: string;
    platform: string;
    appId?: string;
  };
  data: Record<string, string | null>;
}

export interface BackupExecutionResult {
  success: boolean;
  message: string;
  fileName: string;
  fileUri?: string;
  savedLocation?: string;
  sizeKb: number;
  keysCount: number;
  checksum: string;
  jsonString: string;
  platform: 'android' | 'ios' | 'web';
  isNative: boolean;
  error?: string;
}

export interface RestoreValidationResult {
  isValid: boolean;
  message: string;
  parsedData?: LocalStorageBackupPayload;
  keysCount: number;
  createdAt?: string;
  appVersion?: string;
  checksumMatch?: boolean;
  sizeKb: number;
  error?: string;
}

/**
 * Calculates a fast 32-bit FNV-1a checksum hash for data integrity verification
 */
export function calculateChecksum(str: string): string {
  let hash = 2166136261;
  for (let i = 0; i < str.length; i++) {
    hash ^= str.charCodeAt(i);
    hash += (hash << 1) + (hash << 4) + (hash << 7) + (hash << 8) + (hash << 24);
  }
  return (hash >>> 0).toString(16).padStart(8, '0');
}

/**
 * Generates formatted backup filename: YaserAqelApp_Backup_YYYY-MM-DD_HH-mm-ss.json
 */
export function generateBackupFileName(): string {
  const now = new Date();
  const pad = (n: number) => String(n).padStart(2, '0');
  const year = now.getFullYear();
  const month = pad(now.getMonth() + 1);
  const day = pad(now.getDate());
  const hours = pad(now.getHours());
  const minutes = pad(now.getMinutes());
  const seconds = pad(now.getSeconds());

  return `YaserAqelApp_Backup_${year}-${month}-${day}_${hours}-${minutes}-${seconds}.json`;
}

/**
 * Checks if current runtime is a native Capacitor environment (Android/iOS)
 */
export function isNativePlatform(): boolean {
  try {
    return Capacitor.isNativePlatform();
  } catch {
    return false;
  }
}

/**
 * Get current platform name
 */
export function getRuntimePlatform(): 'android' | 'ios' | 'web' {
  try {
    const platform = Capacitor.getPlatform();
    if (platform === 'android') return 'android';
    if (platform === 'ios') return 'ios';
    return 'web';
  } catch {
    return 'web';
  }
}

/**
 * Step 1: Pure READ-ONLY extraction of all localStorage keys and values.
 * Strictly guarantees ZERO mutation, ZERO deletion, and ZERO alterations.
 */
export function extractRawLocalStorageData(): {
  payload: LocalStorageBackupPayload;
  jsonString: string;
  fileName: string;
  sizeKb: number;
} {
  if (typeof window === 'undefined' || !window.localStorage) {
    throw new Error('بيئة التخزين المحلي (localStorage) غير متوفرة.');
  }

  // 1. Read all keys dynamically
  const allKeys = Object.keys(localStorage);
  const data: Record<string, string | null> = {};
  let totalChars = 0;

  for (const key of allKeys) {
    const val = localStorage.getItem(key);
    data[key] = val;
    totalChars += key.length + (val ? val.length : 0);
  }

  const fileName = generateBackupFileName();
  const rawDataJson = JSON.stringify(data);
  const checksum = calculateChecksum(rawDataJson);
  const platform = getRuntimePlatform();

  const payload: LocalStorageBackupPayload = {
    backupFormatVersion: '1.0',
    createdAt: new Date().toISOString(),
    appVersion: '2.0',
    storageType: 'localStorage',
    checksum: checksum,
    metadata: {
      totalKeysCount: allKeys.length,
      keys: allKeys,
      approximateSizeBytes: totalChars,
      approximateSizeKb: parseFloat((totalChars / 1024).toFixed(2)),
      checksum: checksum,
      platform: platform,
      appId: 'com.worldofelites.accounts'
    },
    data: data
  };

  const jsonString = JSON.stringify(payload, null, 2);
  const sizeKb = parseFloat((new Blob([jsonString]).size / 1024).toFixed(2));

  return {
    payload,
    jsonString,
    fileName,
    sizeKb
  };
}

/**
 * Step 2: Creates a real backup file on the current platform.
 * - On Android/Capacitor: Writes a physical file to device storage using Capacitor Filesystem.
 * - On Web/Chrome: Initiates direct file download via Blob.
 */
export async function createBackupFile(): Promise<BackupExecutionResult> {
  const { payload, jsonString, fileName, sizeKb } = extractRawLocalStorageData();
  const isNative = isNativePlatform();
  const platform = getRuntimePlatform();

  if (isNative) {
    // 📱 NATIVE ANDROID / CAPACITOR FLOW
    try {
      let savedLocation = 'Documents/YaserAqelApp_Backups';
      let fileUri: string | undefined;

      try {
        // 1. Try writing directly to Documents directory (User accessible in Android File Manager)
        const writeRes = await Filesystem.writeFile({
          path: `YaserAqelApp_Backups/${fileName}`,
          data: jsonString,
          directory: Directory.Documents,
          encoding: Encoding.UTF8,
          recursive: true
        });

        fileUri = writeRes.uri;
        savedLocation = `المستندات (Documents) > YaserAqelApp_Backups > ${fileName}`;
      } catch (docError) {
        console.warn('Writing to Documents directory failed, trying Data directory fallback:', docError);

        // 2. Fallback to app Data directory
        const fallbackRes = await Filesystem.writeFile({
          path: fileName,
          data: jsonString,
          directory: Directory.Data,
          encoding: Encoding.UTF8,
          recursive: true
        });

        fileUri = fallbackRes.uri;
        savedLocation = `ذاكرة التطبيق (Data) > ${fileName}`;
      }

      // Also ensure a copy exists in Cache for instant native sharing without permission hurdles
      try {
        const cacheRes = await Filesystem.writeFile({
          path: fileName,
          data: jsonString,
          directory: Directory.Cache,
          encoding: Encoding.UTF8,
          recursive: true
        });
        if (!fileUri) fileUri = cacheRes.uri;
      } catch (cacheErr) {
        console.warn('Cache copy failed:', cacheErr);
      }

      return {
        success: true,
        message: 'تم إنشاء وحفظ ملف النسخة الاحتياطية في ذاكرة الهاتف بنجاح.',
        fileName,
        fileUri,
        savedLocation,
        sizeKb,
        keysCount: payload.metadata.totalKeysCount,
        checksum: payload.checksum,
        jsonString,
        platform,
        isNative: true
      };
    } catch (nativeErr: any) {
      console.error('Capacitor native filesystem write error:', nativeErr);
      return {
        success: false,
        message: `فشل حفظ الملف في ذاكرة الهاتف: ${nativeErr?.message || 'خطأ في نظام الملفات'}`,
        fileName,
        sizeKb,
        keysCount: payload.metadata.totalKeysCount,
        checksum: payload.checksum,
        jsonString,
        platform,
        isNative: true,
        error: nativeErr?.message
      };
    }
  } else {
    // 🌐 WEB BROWSER FLOW (Chrome / Edge / Safari / Preview)
    try {
      const blob = new Blob([jsonString], { type: 'application/json;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = fileName;
      document.body.appendChild(link);
      link.click();

      setTimeout(() => {
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
      }, 200);

      return {
        success: true,
        message: 'تم إنشاء وتنزيل ملف النسخة الاحتياطية في مجلد التنزيلات (Downloads) بنجاح.',
        fileName,
        savedLocation: 'مجلد التنزيلات (Downloads)',
        sizeKb,
        keysCount: payload.metadata.totalKeysCount,
        checksum: payload.checksum,
        jsonString,
        platform: 'web',
        isNative: false
      };
    } catch (webErr: any) {
      console.error('Web download error:', webErr);
      return {
        success: false,
        message: `فشل تنزيل الملف في المتصفح: ${webErr?.message || 'خطأ غير متوقع'}`,
        fileName,
        sizeKb,
        keysCount: payload.metadata.totalKeysCount,
        checksum: payload.checksum,
        jsonString,
        platform: 'web',
        isNative: false,
        error: webErr?.message
      };
    }
  }
}

/**
 * Step 3: Shares the backup file natively.
 * - On Android/Capacitor: Invokes native Android Share Plugin using the real file URI.
 * - On Web: Uses Web Share API if supported, or prompts download.
 */
export async function shareBackup(
  backupResult?: BackupExecutionResult | null
): Promise<{ success: boolean; message: string }> {
  try {
    let currentBackup = backupResult;

    // If no existing backup result is provided, generate it now
    if (!currentBackup || !currentBackup.jsonString) {
      currentBackup = await createBackupFile();
      if (!currentBackup.success) {
        return { success: false, message: currentBackup.message };
      }
    }

    const isNative = isNativePlatform();

    if (isNative) {
      // 📱 NATIVE ANDROID SHARE FLOW
      let targetUri = currentBackup.fileUri;

      // Ensure file exists in Cache directory for optimal sharing
      if (!targetUri) {
        const cacheWrite = await Filesystem.writeFile({
          path: currentBackup.fileName,
          data: currentBackup.jsonString,
          directory: Directory.Cache,
          encoding: Encoding.UTF8,
          recursive: true
        });
        targetUri = cacheWrite.uri;
      }

      await Share.share({
        title: 'نسخة احتياطية لبيانات التطبيق',
        text: `نسخة احتياطية شاملة لتطبيق الحسابات (${currentBackup.fileName})`,
        url: targetUri,
        dialogTitle: 'اختر مكان حفظ الملف أو التطبيق الذي تريد مشاركة النسخة معه'
      });

      return {
        success: true,
        message: 'تم فتح نافذة المشاركة بنجاح. اختر التطبيق المطلوب (Google Drive، WhatsApp، مدير الملفات، إلخ).'
      };
    } else {
      // 🌐 WEB SHARE FLOW
      if (typeof navigator !== 'undefined' && navigator.share) {
        try {
          const file = new File([currentBackup.jsonString], currentBackup.fileName, {
            type: 'application/json'
          });

          if (navigator.canShare && navigator.canShare({ files: [file] })) {
            await navigator.share({
              files: [file],
              title: 'نسخة احتياطية لبيانات التطبيق',
              text: 'اختر مكان حفظ الملف أو التطبيق الذي تريد مشاركة النسخة معه.'
            });
            return { success: true, message: 'تم فتح نافذة المشاركة بنجاح.' };
          }
        } catch (shareErr: any) {
          if (shareErr?.name === 'AbortError') {
            return { success: true, message: 'تم إلغاء المشاركة من قبل المستخدم.' };
          }
        }
      }

      // Fallback on web: trigger direct download
      downloadBackupFileDirect(currentBackup.fileName, currentBackup.jsonString);
      return {
        success: true,
        message: 'تم تنزيل ملف النسخة الاحتياطية بنجاح إلى مجلد التنزيلات (Downloads).'
      };
    }
  } catch (err: any) {
    if (err?.name === 'AbortError') {
      return { success: true, message: 'تم إلغاء المشاركة.' };
    }
    console.error('Error in shareBackup:', err);
    return {
      success: false,
      message: err?.message || 'حدث خطأ أثناء محاولة مشاركة النسخة الاحتياطية.'
    };
  }
}

/**
 * Direct file download helper for Web environments
 */
export function downloadBackupFileDirect(fileName: string, jsonString: string): boolean {
  try {
    const blob = new Blob([jsonString], { type: 'application/json;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = fileName;
    document.body.appendChild(link);
    link.click();
    setTimeout(() => {
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    }, 200);
    return true;
  } catch (err) {
    console.error('downloadBackupFileDirect failed:', err);
    return false;
  }
}

/**
 * Step 4: Validates a backup file before performing Restore.
 */
export function validateBackupFileContent(rawContent: string): RestoreValidationResult {
  try {
    if (!rawContent || typeof rawContent !== 'string') {
      return { isValid: false, message: 'ملف النسخة الاحتياطية فارغ أو غير صالح.', keysCount: 0, sizeKb: 0 };
    }

    const parsed = JSON.parse(rawContent);
    const sizeKb = parseFloat((new Blob([rawContent]).size / 1024).toFixed(2));

    // Case 1: Standard structured LocalStorageBackupPayload
    if (parsed && typeof parsed === 'object' && parsed.data && typeof parsed.data === 'object') {
      const keysCount = Object.keys(parsed.data).length;
      if (keysCount === 0) {
        return { isValid: false, message: 'النسخة الاحتياطية لا تحتوي على أي مفاتيح تخزين.', keysCount: 0, sizeKb };
      }

      // Checksum verification if available
      let checksumMatch = true;
      if (parsed.checksum) {
        const calculated = calculateChecksum(JSON.stringify(parsed.data));
        checksumMatch = calculated === parsed.checksum;
      }

      return {
        isValid: true,
        message: 'تم التحقق من صحة ملف النسخة الاحتياطية بنجاح.',
        parsedData: parsed as LocalStorageBackupPayload,
        keysCount,
        createdAt: parsed.createdAt,
        appVersion: parsed.appVersion || '1.0',
        checksumMatch,
        sizeKb
      };
    }

    // Case 2: Legacy raw dictionary format (direct key-value map)
    if (parsed && typeof parsed === 'object' && !parsed.data) {
      const keysCount = Object.keys(parsed).length;
      if (keysCount === 0) {
        return { isValid: false, message: 'ملف النسخة الاحتياطية فارغ.', keysCount: 0, sizeKb };
      }

      const syntheticPayload: LocalStorageBackupPayload = {
        backupFormatVersion: '0.9',
        createdAt: new Date().toISOString(),
        appVersion: 'Legacy',
        storageType: 'localStorage',
        checksum: calculateChecksum(JSON.stringify(parsed)),
        metadata: {
          totalKeysCount: keysCount,
          keys: Object.keys(parsed),
          approximateSizeBytes: rawContent.length,
          approximateSizeKb: sizeKb,
          checksum: calculateChecksum(JSON.stringify(parsed)),
          platform: 'unknown'
        },
        data: parsed
      };

      return {
        isValid: true,
        message: 'تم التحقق من صحة ملف النسخة الاحتياطية (تنسيق مباشر).',
        parsedData: syntheticPayload,
        keysCount,
        appVersion: 'Legacy',
        checksumMatch: true,
        sizeKb
      };
    }

    return { isValid: false, message: 'بنية ملف النسخة الاحتياطية غير متوافقة.', keysCount: 0, sizeKb: 0 };
  } catch (parseErr: any) {
    return {
      isValid: false,
      message: `فشل قراءة الملف (ليس بتنسيق JSON صالح): ${parseErr?.message || ''}`,
      keysCount: 0,
      sizeKb: 0
    };
  }
}

/**
 * Step 5: Executes Safe Restore.
 * CRITICAL SAFETY FEATURE: Automatically creates an internal safety checkpoint backup
 * of current localStorage BEFORE applying any restore, guaranteeing zero permanent data loss!
 */
export async function executeRestore(
  backupPayload: LocalStorageBackupPayload
): Promise<{ success: boolean; message: string; restoredKeysCount: number }> {
  try {
    if (!backupPayload || !backupPayload.data || typeof backupPayload.data !== 'object') {
      throw new Error('بيانات الاستعادة غير صالحة.');
    }

    // 1. SAFETY FIRST: Take an automated backup of current localStorage state before touching anything
    try {
      const currentBackup = extractRawLocalStorageData();
      localStorage.setItem('_pre_restore_safety_backup', currentBackup.jsonString);
      localStorage.setItem('_pre_restore_safety_backup_time', new Date().toISOString());
      
      // On native platform, also save safety backup file to disk
      if (isNativePlatform()) {
        try {
          await Filesystem.writeFile({
            path: `YaserAqelApp_Backups/AutoSafetyBackup_BeforeRestore_${Date.now()}.json`,
            data: currentBackup.jsonString,
            directory: Directory.Documents,
            encoding: Encoding.UTF8,
            recursive: true
          });
        } catch (saveErr) {
          console.warn('Could not save safety backup to disk, but local checkpoint exists:', saveErr);
        }
      }
    } catch (safetyErr) {
      console.warn('Safety backup generation note:', safetyErr);
    }

    // 2. Safely apply all keys from backup.data to localStorage
    const dataToRestore = backupPayload.data;
    const targetKeys = Object.keys(dataToRestore);
    let restoredCount = 0;

    for (const key of targetKeys) {
      const val = dataToRestore[key];
      if (val !== null && val !== undefined) {
        localStorage.setItem(key, val);
        restoredCount++;
      }
    }

    return {
      success: true,
      message: `تم استعادة البيانات بنجاح (${restoredCount} مفتاح).`,
      restoredKeysCount: restoredCount
    };
  } catch (err: any) {
    console.error('Error during executeRestore:', err);
    return {
      success: false,
      message: `فشلت عملية استعادة البيانات: ${err?.message || 'خطأ غير متوقع'}`,
      restoredKeysCount: 0
    };
  }
}

/**
 * Helper to copy full JSON to clipboard
 */
export async function copyJsonToClipboard(jsonString: string): Promise<boolean> {
  try {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      await navigator.clipboard.writeText(jsonString);
      return true;
    }
    const textArea = document.createElement('textarea');
    textArea.value = jsonString;
    textArea.style.position = 'fixed';
    textArea.style.left = '-999999px';
    document.body.appendChild(textArea);
    textArea.focus();
    textArea.select();
    const successful = document.execCommand('copy');
    document.body.removeChild(textArea);
    return successful;
  } catch {
    return false;
  }
}
