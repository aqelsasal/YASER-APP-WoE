/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import PageHeaderCard from './PageHeaderCard';
import { isOwnerUser } from './AttributionBadge';
import { AmountInWords } from './AmountInWords';
import { 
  PlusCircle, 
  Trash2, 
  UserPlus, 
  FileSpreadsheet, 
  FileText, 
  Calendar, 
  Briefcase, 
  ChevronLeft, 
  ArrowLeft, 
  ArrowRight,
  Coins, 
  Receipt,
  User,
  Clock,
  Search,
  Filter,
  Info,
  Pencil,
  DollarSign,
  ArrowRightLeft,
  Copy,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  RotateCcw,
  RefreshCcw,
  RefreshCw,
  AlertCircle,
  Utensils,
  X,
  Link2,
  ExternalLink,
  Sparkles
} from 'lucide-react';
import * as XLSX from 'xlsx';
import AttributionBadge from './AttributionBadge';
import Calculator from './Calculator';
import ShareMenu from './ShareMenu';
import OptionsMenu from './OptionsMenu';
import PhoneNumbersInput, { PhoneNumbersDisplay } from './PhoneNumbersInput';
import ExcelColumnFilter, { ColumnFilterConfig, ActiveColumnFilter, ColumnSortState } from './ExcelColumnFilter';
import CopyMoveLedgerModal from './CopyMoveLedgerModal';
import { useBodyScrollLock } from '../utils/modalScrollLock';
import { 
  Worker,
  Employee, 
  Supplier,
  LedgerEntry, 
  NutritionPeriod,
  calculateDaysOfWork, 
  calculateActualDaysOfWork,
  calculateNutritionDays,
  calculateEmployeeMonthlySalaries,
  syncEmployeeNutritionLedger,
  syncEmployeeWageLedger,
  syncEmployeeAllLedgers,
  getPersonWorkStatus,
  formatCurrency, 
  formatDateArabic,
  cleanLedgerDescription,
  exportToCSV,
  exportMultiSheetXLSX,
  printPDF
} from '../types';
import { 
  generateSvgDonutChart, 
  generateSvgHorizontalBars, 
  generateSvgBalanceComparison, 
  generateMetricCardsGrid 
} from '../utils/reportCharts';

interface EmployeesProps {
  employees: Employee[];
  workers?: Worker[];
  suppliers?: Supplier[];
  onAddEmployee: (employee: Omit<Employee, 'id' | 'ledger'>) => void;
  onDeleteEmployee: (id: string) => void;
  onUpdateEmployee?: (id: string, updatedData: Partial<Omit<Employee, 'id' | 'ledger' | 'createdBy'>>) => void;
  onAddEmployeeLedgerEntry: (employeeId: string, entry: Omit<LedgerEntry, 'id'> & { id?: string }) => void;
  onDeleteEmployeeLedgerEntry: (employeeId: string, entryId: string, isUserAction?: boolean) => void;
  onUpdateEmployeeLedgerEntry?: (employeeId: string, entryId: string, updatedEntry: Omit<LedgerEntry, 'id' | 'createdBy'>) => void;
  onAddEmployeeExtraPeriod?: (employeeId: string, startDate: string, endDate: string) => void;
  onUpdateEmployeeExtraPeriod?: (employeeId: string, periodId: string, startDate: string, endDate: string) => void;
  onDeleteEmployeeExtraPeriod?: (employeeId: string, periodId: string) => void;
  onAddEmployeeNutritionPeriod?: (employeeId: string, nutrition: Omit<NutritionPeriod, 'id'>) => void;
  onUpdateEmployeeNutritionPeriod?: (employeeId: string, nutritionId: string, updatedNutrition: Partial<Omit<NutritionPeriod, 'id'>>) => void;
  onDeleteEmployeeNutritionPeriod?: (employeeId: string, nutritionId: string) => void;
  onTransferEmployeeToWorker?: (employee: Employee) => void;
  onCopyLedgerEntry?: (sourceType: 'worker' | 'employee' | 'supplier', sourceId: string, entry: LedgerEntry, targetType: 'worker' | 'employee' | 'supplier', targetId: string) => void;
  onMoveLedgerEntry?: (sourceType: 'worker' | 'employee' | 'supplier', sourceId: string, entry: LedgerEntry, targetType: 'worker' | 'employee' | 'supplier', targetId: string) => void;
  setActiveTab?: (tab: string) => void;
  currency?: string;
  sharedRole?: 'owner' | 'read' | 'add' | 'full';
}

export interface CurrencyBalance {
  currency: string;
  forHim: number;
  onHim: number;
  net: number;
}

export const getEmployeeBalancesByCurrency = (emp: Employee, defaultCurrency: string = 'YER'): CurrencyBalance[] => {
  const map = new Map<string, { forHim: number; onHim: number }>();
  const baseCurrency = emp.dailyWageCurrency || defaultCurrency || 'YER';

  emp.ledger.forEach(entry => {
    const cur = entry.currency || baseCurrency;
    if (!map.has(cur)) {
      map.set(cur, { forHim: 0, onHim: 0 });
    }
    const rec = map.get(cur)!;
    rec.forHim += entry.amountForHim || 0;
    rec.onHim += entry.amountOnHim || 0;
  });

  if (map.size === 0) {
    return [{ currency: baseCurrency, forHim: 0, onHim: 0, net: 0 }];
  }

  return Array.from(map.entries()).map(([cur, val]) => ({
    currency: cur,
    forHim: val.forHim,
    onHim: val.onHim,
    net: val.forHim - val.onHim
  }));
};

export const getEmployeeTotalDays = (e: Employee, isOwner: boolean = true) => {
  const mainDays = calculateDaysOfWork(e.startDate, e.endDate, isOwner);
  const extraDays = (e.extraPeriods || []).reduce((sum, p) => sum + calculateDaysOfWork(p.startDate, p.endDate, isOwner), 0);
  return mainDays + extraDays;
};

export const getEmployeeActualDays = (e: Employee, isOwner: boolean = true) => {
  const mainActualDays = calculateActualDaysOfWork(e.startDate, e.endDate, isOwner);
  const extraActualDays = (e.extraPeriods || []).reduce((sum, p) => sum + calculateActualDaysOfWork(p.startDate, p.endDate, isOwner), 0);
  return mainActualDays + extraActualDays;
};

export default function Employees({
  employees,
  workers = [],
  suppliers = [],
  onAddEmployee,
  onDeleteEmployee,
  onUpdateEmployee,
  onAddEmployeeLedgerEntry,
  onDeleteEmployeeLedgerEntry,
  onUpdateEmployeeLedgerEntry,
  onAddEmployeeExtraPeriod,
  onUpdateEmployeeExtraPeriod,
  onDeleteEmployeeExtraPeriod,
  onAddEmployeeNutritionPeriod,
  onUpdateEmployeeNutritionPeriod,
  onDeleteEmployeeNutritionPeriod,
  onTransferEmployeeToWorker,
  onCopyLedgerEntry,
  onMoveLedgerEntry,
  setActiveTab,
  currency = 'YER',
  sharedRole = 'owner'
}: EmployeesProps) {
  
  // Selection & Form states
  const [selectedEmployeeId, setSelectedEmployeeId] = useState<string | null>(null);

  // Edit states
  const [editingEmployee, setEditingEmployee] = useState<Employee | null>(null);
  const [editingEmployeeLedger, setEditingEmployeeLedger] = useState<{ employeeId: string; entry: LedgerEntry } | null>(null);

  // Quick Edit modals & interaction states for linked Wage & Periods
  const [showQuickWageModal, setShowQuickWageModal] = useState(false);
  const [quickWageType, setQuickWageType] = useState<'daily' | 'monthly'>('daily');
  const [quickWageValue, setQuickWageValue] = useState('');
  const [quickMonthlySalaryValue, setQuickMonthlySalaryValue] = useState('');
  const [quickWageCurrency, setQuickWageCurrency] = useState(currency || 'YER');

  const [showQuickBasicPeriodModal, setShowQuickBasicPeriodModal] = useState(false);
  const [quickBasicStartDate, setQuickBasicStartDate] = useState('');
  const [quickBasicEndDate, setQuickBasicEndDate] = useState('');

  const [editingExtraPeriodId, setEditingExtraPeriodId] = useState<string | null>(null);
  const [editExtraStart, setEditExtraStart] = useState('');
  const [editExtraEnd, setEditExtraEnd] = useState('');
  const [editExtraError, setEditExtraError] = useState('');

  const [highlightedEntryId, setHighlightedEntryId] = useState<string | null>(null);
  const [syncToastMessage, setSyncToastMessage] = useState<string | null>(null);

  // Nutrition Modal State
  const [showNutritionModal, setShowNutritionModal] = useState(false);
  const [editingNutritionPeriod, setEditingNutritionPeriod] = useState<NutritionPeriod | null>(null);
  const [nutrWorkerName, setNutrWorkerName] = useState('');
  const [nutrDailyAmount, setNutrDailyAmount] = useState('');
  const [nutrStartDate, setNutrStartDate] = useState('');
  const [nutrEndDate, setNutrEndDate] = useState('');
  const [nutrNotes, setNutrNotes] = useState('');
  const [nutrFormError, setNutrFormError] = useState('');

  // Copy / Move Ledger Entry modal state
  const [copyMoveModalState, setCopyMoveModalState] = useState<{
    isOpen: boolean;
    mode: 'copy' | 'move';
    entry: LedgerEntry | null;
    employeeId: string;
    employeeName: string;
  }>({
    isOpen: false,
    mode: 'copy',
    entry: null,
    employeeId: '',
    employeeName: ''
  });

  // Lock background scroll when modal is open
  useBodyScrollLock(Boolean(editingEmployee || editingEmployeeLedger || showNutritionModal || copyMoveModalState.isOpen || showQuickWageModal || showQuickBasicPeriodModal));

  // Add Employee form
  const [showAddEmployeeForm, setShowAddEmployeeForm] = useState(false);
  const [newEmployeeName, setNewEmployeeName] = useState('');
  const [newEmployeeProfession, setNewEmployeeProfession] = useState('');
  const [newEmployeeStartDate, setNewEmployeeStartDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [newEmployeeEndDate, setNewEmployeeEndDate] = useState('');
  const [newEmployeeWageType, setNewEmployeeWageType] = useState<'daily' | 'monthly'>('daily');
  const [newEmployeeDailyWage, setNewEmployeeDailyWage] = useState('');
  const [newEmployeeMonthlySalary, setNewEmployeeMonthlySalary] = useState('');
  const [newEmployeeDailyWageCurrency, setNewEmployeeDailyWageCurrency] = useState(currency || 'YER');
  const [newEmployeePhoneNumbers, setNewEmployeePhoneNumbers] = useState<string[]>(['']);
  const [newEmployeeNotes, setNewEmployeeNotes] = useState('');

  // Extra Work Period form states
  const [showExtraForm, setShowExtraForm] = useState(false);
  const [extraStart, setExtraStart] = useState('');
  const [extraEnd, setExtraEnd] = useState('');
  const [extraFormError, setExtraFormError] = useState('');

  // Nutrition Card collapsible state (hidden by default)
  const [showNutritionSection, setShowNutritionSection] = useState(false);

  // Add Employee Ledger Entry form
  const [ledgerDate, setLedgerDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [ledgerAmountOnHim, setLedgerAmountOnHim] = useState(''); // عليه (سلفة / دفعة)
  const [ledgerAmountForHim, setLedgerAmountForHim] = useState(''); // له (إضافة / مكافأة)
  const [ledgerDescription, setLedgerDescription] = useState('');
  const [ledgerNotes, setLedgerNotes] = useState('');
  const [ledgerCurrency, setLedgerCurrency] = useState(currency);
  const [showAddLedgerForm, setShowAddLedgerForm] = useState(false);

  // Search filter & sort filters
  const [searchQuery, setSearchQuery] = useState('');
  const [employeeSortOrder, setEmployeeSortOrder] = useState<'asc' | 'desc'>('desc'); // Default desc: newest first
  
  // Ledger filters state
  const [isLedgerFiltersOpen, setIsLedgerFiltersOpen] = useState(false);
  const [ledgerSearchTerm, setLedgerSearchTerm] = useState('');
  const [ledgerStartDate, setLedgerStartDate] = useState('');
  const [ledgerEndDate, setLedgerEndDate] = useState('');
  const [ledgerTypeFilter, setLedgerTypeFilter] = useState<'all' | 'onHim' | 'forHim'>('all');
  const [ledgerSortOption, setLedgerSortOption] = useState<'date-desc' | 'date-asc' | 'desc-alpha' | 'amountOnHim-desc' | 'amountForHim-desc'>('date-desc');

  // Error/Success alerts
  const [employeeError, setEmployeeError] = useState('');
  const [ledgerError, setLedgerError] = useState('');

  useEffect(() => {
    setLedgerCurrency(currency);
    setNewEmployeeDailyWageCurrency(currency || 'YER');
  }, [currency]);

  // Find active employee details
  const activeEmployee = employees.find(e => e.id === selectedEmployeeId);

  // Sync quick edit states with activeEmployee
  useEffect(() => {
    if (activeEmployee) {
      setQuickWageType(activeEmployee.wageType || 'daily');
      setQuickWageValue(String(activeEmployee.dailyWage || ''));
      setQuickMonthlySalaryValue(String(activeEmployee.monthlySalary || ''));
      setQuickWageCurrency(activeEmployee.dailyWageCurrency || currency || 'YER');
      setQuickBasicStartDate(activeEmployee.startDate || '');
      setQuickBasicEndDate(activeEmployee.endDate || '');
    }
  }, [activeEmployee?.id, activeEmployee?.dailyWage, activeEmployee?.monthlySalary, activeEmployee?.startDate, activeEmployee?.endDate, activeEmployee?.dailyWageCurrency, currency]);

  // Filter and sort employees list
  const sortedEmployees = useMemo(() => {
    let list = employees.filter(emp => 
      emp.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      emp.profession.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (emp.phoneNumbers && emp.phoneNumbers.some(p => p.includes(searchQuery)))
    );
    return list.sort((a, b) => {
      const dateA = a.startDate || '';
      const dateB = b.startDate || '';
      return employeeSortOrder === 'desc' 
        ? dateB.localeCompare(dateA)
        : dateA.localeCompare(dateB);
    });
  }, [employees, searchQuery, employeeSortOrder]);

  // Excel Column Filter State for Employee Ledger
  const [employeeLedgerColumnFilters, setEmployeeLedgerColumnFilters] = useState<Record<string, ActiveColumnFilter>>({});
  const [employeeLedgerColumnSort, setEmployeeLedgerColumnSort] = useState<ColumnSortState | null>(null);

  const handleEmployeeLedgerFilterChange = (key: string, filter: ActiveColumnFilter | null) => {
    setEmployeeLedgerColumnFilters(prev => {
      const next = { ...prev };
      if (!filter) {
        delete next[key];
      } else {
        next[key] = filter;
      }
      return next;
    });
  };

  const handleEmployeeLedgerSortChange = (sort: ColumnSortState | null) => {
    setEmployeeLedgerColumnSort(sort);
  };

  const handleClearEmployeeLedgerFilters = () => {
    setEmployeeLedgerColumnFilters({});
    setEmployeeLedgerColumnSort(null);
  };

  const employeeLedgerColumnConfigs: Record<string, ColumnFilterConfig<LedgerEntry>> = {
    date: {
      key: 'date',
      title: 'التاريخ',
      sortType: 'date',
      getValue: (e) => e.date,
      getDisplayValue: (val) => formatDateArabic(String(val))
    },
    description: {
      key: 'description',
      title: 'البيان',
      sortType: 'string',
      getValue: (e) => cleanLedgerDescription(e.description)
    },
    amountOnHim: {
      key: 'amountOnHim',
      title: 'عليه (سلفة/دفعة)',
      sortType: 'number',
      getValue: (e) => e.amountOnHim,
      getDisplayValue: (val) => Number(val) > 0 ? String(val) : '-'
    },
    amountForHim: {
      key: 'amountForHim',
      title: 'له (أجور/استحقاق)',
      sortType: 'number',
      getValue: (e) => e.amountForHim,
      getDisplayValue: (val) => Number(val) > 0 ? String(val) : '-'
    },
    currency: {
      key: 'currency',
      title: 'العملة',
      sortType: 'string',
      getValue: (e) => e.currency || activeEmployee?.dailyWageCurrency || currency || 'YER'
    },
    notes: {
      key: 'notes',
      title: 'ملاحظات',
      sortType: 'string',
      getValue: (e) => e.notes || ''
    }
  };

  // Base filtered employee ledger entries (matching top search, date, type filters)
  const baseFilteredLedger = useMemo(() => {
    if (!activeEmployee) return [];
    return activeEmployee.ledger.filter(entry => {
      if (ledgerSearchTerm.trim()) {
        const term = ledgerSearchTerm.trim().toLowerCase();
        const matchDesc = entry.description.toLowerCase().includes(term);
        const matchNotes = (entry.notes || '').toLowerCase().includes(term);
        if (!matchDesc && !matchNotes) return false;
      }
      if (ledgerStartDate && entry.date < ledgerStartDate) return false;
      if (ledgerEndDate && entry.date > ledgerEndDate) return false;
      if (ledgerTypeFilter === 'onHim' && !(entry.amountOnHim > 0)) return false;
      if (ledgerTypeFilter === 'forHim' && !(entry.amountForHim > 0)) return false;
      return true;
    });
  }, [activeEmployee, ledgerSearchTerm, ledgerStartDate, ledgerEndDate, ledgerTypeFilter]);

  // Active employee filtered & sorted ledger entries (cascading with column filters)
  const sortedLedger = useMemo(() => {
    // Filter
    const filtered = baseFilteredLedger.filter(entry => {
      // Apply column filters
      for (const [colKey, filter] of Object.entries(employeeLedgerColumnFilters) as [string, ActiveColumnFilter][]) {
        const config = employeeLedgerColumnConfigs[colKey];
        if (!config || !filter || !filter.selectedValues) continue;

        const allowedSet = new Set(filter.selectedValues);
        const raw = config.getValue(entry);

        if (Array.isArray(raw)) {
          if (raw.length === 0) {
            if (!allowedSet.has('(فارغ)')) return false;
          } else {
            const hasAny = raw.some(val => {
              const strVal = val !== null && val !== undefined && String(val).trim() !== '' ? String(val) : '(فارغ)';
              return allowedSet.has(strVal);
            });
            if (!hasAny) return false;
          }
        } else {
          const strVal = raw !== null && raw !== undefined && String(raw).trim() !== '' ? String(raw) : '(فارغ)';
          if (!allowedSet.has(strVal)) return false;
        }
      }

      return true;
    });

    // Sort
    return filtered.sort((a, b) => {
      if (employeeLedgerColumnSort) {
        const config = employeeLedgerColumnConfigs[employeeLedgerColumnSort.key];
        if (config) {
          const rawA = config.getValue(a);
          const rawB = config.getValue(b);

          if (rawA === rawB) return 0;
          if (rawA === null || rawA === undefined || rawA === '') return 1;
          if (rawB === null || rawB === undefined || rawB === '') return -1;

          let comp = 0;
          if (config.sortType === 'number') {
            const numA = typeof rawA === 'number' ? rawA : parseFloat(String(rawA)) || 0;
            const numB = typeof rawB === 'number' ? rawB : parseFloat(String(rawB)) || 0;
            comp = numA - numB;
          } else if (config.sortType === 'date') {
            comp = String(rawA).localeCompare(String(rawB));
          } else {
            const strA = config.getDisplayValue ? config.getDisplayValue(String(rawA)) : String(rawA);
            const strB = config.getDisplayValue ? config.getDisplayValue(String(rawB)) : String(rawB);
            comp = strA.localeCompare(strB, 'ar');
          }

          return employeeLedgerColumnSort.direction === 'asc' ? comp : -comp;
        }
      }

      if (ledgerSortOption === 'date-asc') {
        return (a.date || '').localeCompare(b.date || '');
      } else if (ledgerSortOption === 'desc-alpha') {
        return (a.description || '').localeCompare(b.description || '', 'ar');
      } else if (ledgerSortOption === 'amountOnHim-desc') {
        return b.amountOnHim - a.amountOnHim;
      } else if (ledgerSortOption === 'amountForHim-desc') {
        return b.amountForHim - a.amountForHim;
      }
      return (b.date || '').localeCompare(a.date || '');
    });
  }, [activeEmployee, ledgerSearchTerm, ledgerStartDate, ledgerEndDate, ledgerTypeFilter, ledgerSortOption, employeeLedgerColumnFilters, employeeLedgerColumnSort]);

  const hasActiveEmployeeLedgerColumnFilters = Object.keys(employeeLedgerColumnFilters).length > 0 || employeeLedgerColumnSort !== null;

  const isLedgerFilterActive = Boolean(
    ledgerSearchTerm || ledgerStartDate || ledgerEndDate || ledgerTypeFilter !== 'all' || ledgerSortOption !== 'date-desc' || hasActiveEmployeeLedgerColumnFilters
  );

  // Calculate sum of filtered ledger entries grouped by currency
  const ledgerTotalsByCurrency = sortedLedger.reduce((acc, curr) => {
    const code = curr.currency || activeEmployee?.dailyWageCurrency || currency || 'YER';
    if (!acc[code]) {
      acc[code] = { onHim: 0, forHim: 0 };
    }
    acc[code].onHim += curr.amountOnHim || 0;
    acc[code].forHim += curr.amountForHim || 0;
    return acc;
  }, {} as Record<string, { onHim: number; forHim: number }>);

  // Form submit for new employee
  const handleAddEmployeeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setEmployeeError('');

    if (!newEmployeeName.trim()) {
      setEmployeeError('الرجاء إدخال اسم الموظف.');
      return;
    }
    if (!newEmployeeProfession.trim()) {
      setEmployeeError('الرجاء إدخال المسمى الوظيفي.');
      return;
    }
    if (!newEmployeeStartDate) {
      setEmployeeError('الرجاء اختيار تاريخ البدء.');
      return;
    }
    if (newEmployeeEndDate && new Date(newEmployeeStartDate) > new Date(newEmployeeEndDate)) {
      setEmployeeError('تاريخ البدء يجب أن يكون قبل أو يساوي تاريخ الانتهاء.');
      return;
    }

    if (newEmployeePhoneNumbers.some(p => p.trim().length > 0 && p.trim().length < 9)) {
      setEmployeeError('رقم الهاتف يجب أن يتكون من 9 أرقام (مثال: 771234567).');
      return;
    }

    const validPhones = newEmployeePhoneNumbers.map(p => p.trim()).filter(p => p.length === 9);

    onAddEmployee({
      name: newEmployeeName.trim(),
      profession: newEmployeeProfession.trim(),
      startDate: newEmployeeStartDate,
      endDate: newEmployeeEndDate || '',
      wageType: newEmployeeWageType,
      dailyWage: newEmployeeWageType === 'daily' ? (Number(newEmployeeDailyWage) || 0) : 0,
      monthlySalary: newEmployeeWageType === 'monthly' ? (Number(newEmployeeMonthlySalary) || 0) : 0,
      dailyWageCurrency: newEmployeeDailyWageCurrency || currency || 'YER',
      phoneNumbers: validPhones,
      notes: newEmployeeNotes.trim()
    });

    // Reset Form
    setNewEmployeeName('');
    setNewEmployeeProfession('');
    setNewEmployeeStartDate(new Date().toISOString().split('T')[0]);
    setNewEmployeeEndDate('');
    setNewEmployeeWageType('daily');
    setNewEmployeeDailyWage('');
    setNewEmployeeMonthlySalary('');
    setNewEmployeeDailyWageCurrency(currency || 'YER');
    setNewEmployeePhoneNumbers(['']);
    setNewEmployeeNotes('');
    setShowAddEmployeeForm(false);
  };

  const handleResetAddEmployeeForm = () => {
    setNewEmployeeName('');
    setNewEmployeeProfession('');
    setNewEmployeeStartDate(new Date().toISOString().split('T')[0]);
    setNewEmployeeEndDate('');
    setNewEmployeeWageType('daily');
    setNewEmployeeDailyWage('');
    setNewEmployeeMonthlySalary('');
    setNewEmployeeDailyWageCurrency(currency || 'YER');
    setNewEmployeePhoneNumbers(['']);
    setNewEmployeeNotes('');
    setEmployeeError('');
  };

  const handleResetAddLedgerForm = () => {
    setLedgerDate(new Date().toISOString().split('T')[0]);
    setLedgerAmountOnHim('');
    setLedgerAmountForHim('');
    setLedgerDescription('');
    setLedgerNotes('');
    setLedgerCurrency(currency);
    setLedgerError('');
  };

  // Submit handler for editing employee
  const handleEditEmployeeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingEmployee) return;

    const rawPhones = editingEmployee.phoneNumbers || [];
    if (rawPhones.some(p => p.trim().length > 0 && p.trim().length < 9)) {
      alert('رقم الهاتف يجب أن يتكون من 9 أرقام (مثال: 771234567)');
      return;
    }
    const cleanPhones = rawPhones.map(p => p.trim()).filter(p => p.length === 9);

    if (onUpdateEmployee) {
      onUpdateEmployee(editingEmployee.id, {
        name: editingEmployee.name,
        profession: editingEmployee.profession,
        startDate: editingEmployee.startDate,
        endDate: editingEmployee.endDate || '',
        wageType: editingEmployee.wageType || 'daily',
        dailyWage: (editingEmployee.wageType || 'daily') === 'daily' ? (Number(editingEmployee.dailyWage) || 0) : 0,
        monthlySalary: (editingEmployee.wageType || 'daily') === 'monthly' ? (Number(editingEmployee.monthlySalary) || 0) : 0,
        dailyWageCurrency: editingEmployee.dailyWageCurrency || currency || 'YER',
        phoneNumbers: cleanPhones,
        notes: editingEmployee.notes || '',
        excludedSalaryMonthKeys: [],
        disableAutoSalaryCalculation: false
      });
    }
    setEditingEmployee(null);
  };

  // Submit handler for editing ledger entry
  const handleEditEmployeeLedgerSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingEmployeeLedger) return;
    if (onUpdateEmployeeLedgerEntry) {
      onUpdateEmployeeLedgerEntry(editingEmployeeLedger.employeeId, editingEmployeeLedger.entry.id, {
        date: editingEmployeeLedger.entry.date,
        amountOnHim: editingEmployeeLedger.entry.amountOnHim,
        amountForHim: editingEmployeeLedger.entry.amountForHim,
        description: editingEmployeeLedger.entry.description,
        notes: editingEmployeeLedger.entry.notes,
        currency: editingEmployeeLedger.entry.currency || activeEmployee?.dailyWageCurrency || currency || 'YER'
      });
    }
    setEditingEmployeeLedger(null);
  };

  // Nutrition modal handlers
  const handleOpenAddNutritionModal = () => {
    if (!activeEmployee) return;
    setEditingNutritionPeriod(null);
    setNutrWorkerName(activeEmployee.name);
    setNutrDailyAmount('');
    setNutrStartDate(activeEmployee.startDate || new Date().toISOString().split('T')[0]);
    setNutrEndDate(activeEmployee.endDate || '');
    setNutrNotes('');
    setNutrFormError('');
    setShowNutritionModal(true);
  };

  const handleOpenEditNutritionModal = (period: NutritionPeriod) => {
    setEditingNutritionPeriod(period);
    setNutrWorkerName(period.workerName);
    setNutrDailyAmount(String(period.dailyAmount));
    setNutrStartDate(period.startDate);
    setNutrEndDate(period.endDate || '');
    setNutrNotes(period.notes || '');
    setNutrFormError('');
    setShowNutritionModal(true);
  };

  const handleNutritionSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeEmployee) return;

    const trimmedName = nutrWorkerName.trim();
    const amountVal = parseFloat(nutrDailyAmount);

    if (!trimmedName) {
      setNutrFormError('يرجى إدخال اسم الموظف أو المستفيد من التغذية');
      return;
    }
    if (isNaN(amountVal) || amountVal <= 0) {
      setNutrFormError('يرجى إدخال مبلغ تغذية يومي صحيح وأكبر من الصفر');
      return;
    }
    if (!nutrStartDate) {
      setNutrFormError('يرجى تحديد تاريخ البدء');
      return;
    }
    if (nutrEndDate && nutrEndDate < nutrStartDate) {
      setNutrFormError('تاريخ الانتهاء لا يمكن أن يكون قبل تاريخ البدء');
      return;
    }

    if (editingNutritionPeriod) {
      onUpdateEmployeeNutritionPeriod?.(activeEmployee.id, editingNutritionPeriod.id, {
        workerName: trimmedName,
        dailyAmount: amountVal,
        startDate: nutrStartDate,
        endDate: nutrEndDate || undefined,
        notes: nutrNotes.trim() || undefined
      });
    } else {
      onAddEmployeeNutritionPeriod?.(activeEmployee.id, {
        workerName: trimmedName,
        dailyAmount: amountVal,
        startDate: nutrStartDate,
        endDate: nutrEndDate || undefined,
        notes: nutrNotes.trim() || undefined
      });
    }

    setShowNutritionModal(false);
  };

  // Bulk Excel import for new employees list
  const handleAllEmployeesExcelImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const bstr = evt.target?.result;
        const wb = XLSX.read(bstr, { type: 'binary' });
        const wsname = wb.SheetNames[0];
        const ws = wb.Sheets[wsname];
        const data = XLSX.utils.sheet_to_json<any>(ws);

        if (!data || data.length === 0) {
          alert('ملف Excel فارغ أو غير صالح.');
          return;
        }

        let count = 0;
        data.forEach(row => {
          const name = row['الاسم'] || row['اسم الموظف'] || row['الموظف'] || row['Name'] || row['name'];
          const profession = row['المسمى الوظيفي'] || row['المهنة'] || row['التخصص'] || row['Profession'] || 'موظف';
          const dailyWage = Number(row['الأجر اليومي'] || row['الراتب اليومي'] || row['DailyWage'] || 0);
          const wageCurrency = row['العملة'] || row['عملة الأجر'] || row['Currency'] || currency || 'YER';
          const startDate = row['تاريخ البدء'] || row['تاريخ المباشرة'] || row['StartDate'] || new Date().toISOString().split('T')[0];
          const endDate = row['تاريخ الانتهاء'] || row['EndDate'] || '';
          const phoneRaw = row['رقم الهاتف'] || row['الهاتف'] || row['رقم الجوال'] || row['الجوال'] || row['Phone'] || row['phone'] || '';

          const phoneNumbers: string[] = [];
          if (phoneRaw) {
            String(phoneRaw).split(/[,;/\n]+/).forEach(p => {
              const digits = p.replace(/\D/g, '').slice(0, 9);
              if (digits.length === 9) phoneNumbers.push(digits);
            });
          }

          if (name && String(name).trim()) {
            const parseDate = (d: any) => {
              if (typeof d === 'number') {
                const dateObj = XLSX.SSF.parse_date_code(d);
                return `${dateObj.y}-${String(dateObj.m).padStart(2, '0')}-${String(dateObj.d).padStart(2, '0')}`;
              }
              const stringDate = String(d).trim();
              const parsed = Date.parse(stringDate);
              if (!isNaN(parsed)) {
                return new Date(parsed).toISOString().split('T')[0];
              }
              return stringDate;
            };

            onAddEmployee({
              name: String(name).trim(),
              profession: String(profession).trim(),
              dailyWage: isNaN(dailyWage) ? 0 : dailyWage,
              dailyWageCurrency: String(wageCurrency).trim(),
              startDate: parseDate(startDate),
              endDate: endDate ? parseDate(endDate) : '',
              phoneNumbers
            });
            count++;
          }
        });

        alert(`تم استيراد ${count} موظف بنجاح من ملف Excel!`);
      } catch (err) {
        console.error("Error reading Excel for employees:", err);
        alert('حدث خطأ أثناء قراءة ملف Excel. يرجى التأكد من مطابقة اسم العامود (الاسم، المسمى الوظيفي، الأجر اليومي، تاريخ البدء).');
      }
    };
    reader.readAsBinaryString(file);
    e.target.value = '';
  };

  // Export all employees summary and detailed ledgers to Multi-sheet Excel
  const handleExportAllEmployeesExcel = () => {
    const summaryHeaders = [
      'م', 
      'اسم الموظف', 
      'الحالة (مستمر/متوقف)',
      'المسمى الوظيفي', 
      'نوع الأجر/الراتب',
      'الأجر / الراتب', 
      'عملة الأجر/الراتب',
      'رقم الهاتف',
      'تاريخ البدء', 
      'تاريخ الانتهاء', 
      'أيام العمل', 
      'إجمالي له (أجور)', 
      'إجمالي عليه (سلف)', 
      'صافي المستحق', 
      'العملة', 
      'حالة الرصيد'
    ];

    const totalsByCurrency: Record<string, { forHim: number; onHim: number }> = {};
    const summaryRows: (string | number)[][] = [];
    let rowIdx = 1;

    sortedEmployees.forEach(emp => {
      const days = getEmployeeTotalDays(emp, sharedRole === 'owner');
      const balances = getEmployeeBalancesByCurrency(emp, currency);
      const workStatus = getPersonWorkStatus(emp.endDate);
      const isMonthly = emp.wageType === 'monthly' || (Boolean(emp.monthlySalary && Number(emp.monthlySalary) > 0) && !emp.dailyWage);
      const wageAmount = isMonthly ? (Number(emp.monthlySalary) || 0) : (Number(emp.dailyWage) || 0);
      const wageTypeLabel = isMonthly ? 'راتب شهري' : 'أجر يومي';
      const empCurrency = emp.dailyWageCurrency || currency;

      balances.forEach((b, bIdx) => {
        if (!totalsByCurrency[b.currency]) {
          totalsByCurrency[b.currency] = { forHim: 0, onHim: 0 };
        }
        totalsByCurrency[b.currency].forHim += b.forHim;
        totalsByCurrency[b.currency].onHim += b.onHim;

        let status = 'خالص الطرفين';
        if (b.net > 0) status = 'له مستحقات';
        else if (b.net < 0) status = 'عليه سلفة';

        summaryRows.push([
          bIdx === 0 ? rowIdx : '',
          bIdx === 0 ? emp.name : '',
          bIdx === 0 ? workStatus.statusText : '',
          bIdx === 0 ? emp.profession : '',
          bIdx === 0 ? wageTypeLabel : '',
          bIdx === 0 ? wageAmount : '',
          bIdx === 0 ? empCurrency : '',
          bIdx === 0 ? (emp.phoneNumbers?.join(' - ') || '-') : '',
          bIdx === 0 ? emp.startDate : '',
          bIdx === 0 ? (emp.endDate || 'مستمر') : '',
          bIdx === 0 ? days : '',
          b.forHim,
          b.onHim,
          b.net,
          b.currency,
          status
        ]);
      });
      rowIdx++;
    });

    summaryRows.push(['', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '']);
    Object.entries(totalsByCurrency).forEach(([cur, totals]) => {
      const totalNet = totals.forHim - totals.onHim;
      summaryRows.push([
        `الإجمالي العام (${cur})`,
        '',
        '',
        '',
        '',
        '',
        '',
        '',
        '',
        '',
        '',
        totals.forHim,
        totals.onHim,
        totalNet,
        cur,
        totalNet > 0 ? 'له مستحقات' : totalNet < 0 ? 'عليه سلف' : 'متوازن'
      ]);
    });

    // Sheet 2: Detailed ledger entries for ALL employees
    const ledgerHeaders = [
      'اسم الموظف',
      'المسمى الوظيفي',
      'تاريخ الحركة',
      'البيان / الوصف التفصيلي',
      'مبلغ له (رواتب ومستحقات)',
      'مبلغ عليه (سلف ومسحوبات)',
      'العملة',
      'الملاحظات',
      'بواسطة'
    ];

    const ledgerRows: (string | number)[][] = [];
    sortedEmployees.forEach(e => {
      e.ledger.forEach(entry => {
        ledgerRows.push([
          e.name,
          e.profession,
          entry.date,
          entry.description,
          entry.amountForHim || 0,
          entry.amountOnHim || 0,
          entry.currency || e.dailyWageCurrency || currency,
          entry.notes || '-',
          (entry.createdBy && !isOwnerUser(entry.createdBy)) ? entry.createdBy : '-'
        ]);
      });
    });
    ledgerRows.sort((a, b) => (b[2] as string).localeCompare(a[2] as string));

    exportMultiSheetXLSX(`كشف_الموظفين_التفصيلي_الشامل_${new Date().toISOString().split('T')[0]}`, [
      { sheetName: 'سجل الموظفين العام', headers: summaryHeaders, rows: summaryRows },
      { sheetName: 'تفاصيل حركات كشف الموظفين', headers: ledgerHeaders, rows: ledgerRows }
    ]);
  };

  // Print All Employees PDF with Summary and Detailed Ledgers
  const handlePrintAllEmployeesPDF = () => {
    const totalsByCurrency: Record<string, { forHim: number; onHim: number }> = {};
    const professionCounts: Record<string, { count: number; totalWages: number }> = {};

    const summaryRowsHtml = sortedEmployees.map((emp, idx) => {
      const days = getEmployeeTotalDays(emp, sharedRole === 'owner');
      const balances = getEmployeeBalancesByCurrency(emp, currency);
      const workStatus = getPersonWorkStatus(emp.endDate);
      const isMonthly = emp.wageType === 'monthly' || (Boolean(emp.monthlySalary && Number(emp.monthlySalary) > 0) && !emp.dailyWage);
      const empCurrency = emp.dailyWageCurrency || currency;

      let wageOrSalaryDisplay = '';
      if (isMonthly && emp.monthlySalary && Number(emp.monthlySalary) > 0) {
        wageOrSalaryDisplay = `
          <div style="font-weight: bold; color: #047857;">${formatCurrency(Number(emp.monthlySalary), empCurrency)}</div>
          <div style="font-size: 9.5px; color: #64748b;">(راتب شهري)</div>
        `;
      } else if (emp.dailyWage && Number(emp.dailyWage) > 0) {
        wageOrSalaryDisplay = `
          <div style="font-weight: bold; color: #0369a1;">${formatCurrency(Number(emp.dailyWage), empCurrency)}</div>
          <div style="font-size: 9.5px; color: #64748b;">(أجر يومي)</div>
        `;
      } else if (emp.monthlySalary && Number(emp.monthlySalary) > 0) {
        wageOrSalaryDisplay = `
          <div style="font-weight: bold; color: #047857;">${formatCurrency(Number(emp.monthlySalary), empCurrency)}</div>
          <div style="font-size: 9.5px; color: #64748b;">(راتب شهري)</div>
        `;
      } else {
        wageOrSalaryDisplay = `<span style="color: #94a3b8;">${formatCurrency(0, empCurrency)}</span>`;
      }

      const prof = emp.profession?.trim() || 'موظف';
      if (!professionCounts[prof]) {
        professionCounts[prof] = { count: 0, totalWages: 0 };
      }
      professionCounts[prof].count += 1;

      balances.forEach(b => {
        if (!totalsByCurrency[b.currency]) {
          totalsByCurrency[b.currency] = { forHim: 0, onHim: 0 };
        }
        totalsByCurrency[b.currency].forHim += b.forHim;
        totalsByCurrency[b.currency].onHim += b.onHim;
        if (b.currency === currency) {
          professionCounts[prof].totalWages += b.forHim;
        }
      });

      const forHimHtml = balances.map(b => `<div style="color: #10b981; font-weight: bold;">${formatCurrency(b.forHim, b.currency)}</div>`).join('');
      const onHimHtml = balances.map(b => `<div style="color: #e11d48; font-weight: bold;">${formatCurrency(b.onHim, b.currency)}</div>`).join('');
      const netHtml = balances.map(b => `
        <div style="font-weight: bold; color: ${b.net >= 0 ? '#10b981' : '#e11d48'};">
          ${b.net === 0 ? `خالص (${b.currency})` : b.net > 0 ? `له (${formatCurrency(b.net, b.currency)})` : `عليه (${formatCurrency(Math.abs(b.net), b.currency)})`}
        </div>
      `).join('');

      return `
        <tr style="background-color: ${idx % 2 === 0 ? '#ffffff' : '#f8fafc'};">
          <td style="padding: 8px; border: 1px solid #e2e8f0; text-align: center;">${idx + 1}</td>
          <td style="padding: 8px; border: 1px solid #e2e8f0; font-weight: bold;">${emp.name}</td>
          <td style="padding: 8px; border: 1px solid #e2e8f0; text-align: center;">
            <span style="display: inline-block; padding: 2.5px 8px; border-radius: 6px; font-size: 10.5px; font-weight: bold; background-color: ${workStatus.isStopped ? '#fee2e2' : '#dcfce7'}; color: ${workStatus.isStopped ? '#991b1b' : '#166534'}; border: 1px solid ${workStatus.isStopped ? '#fca5a5' : '#86efac'};">
              ${workStatus.statusText}
            </span>
          </td>
          <td style="padding: 8px; border: 1px solid #e2e8f0;">${emp.profession}</td>
          <td style="padding: 8px; border: 1px solid #e2e8f0; text-align: center;">${wageOrSalaryDisplay}</td>
          <td style="padding: 8px; border: 1px solid #e2e8f0; text-align: center;">${days} يوم</td>
          <td style="padding: 8px; border: 1px solid #e2e8f0; text-align: center;">${forHimHtml}</td>
          <td style="padding: 8px; border: 1px solid #e2e8f0; text-align: center;">${onHimHtml}</td>
          <td style="padding: 8px; border: 1px solid #e2e8f0; text-align: center;">${netHtml}</td>
        </tr>
      `;
    }).join('');

    let employeesDetailedLedgersHtml = '';
    sortedEmployees.forEach(emp => {
      const days = getEmployeeTotalDays(emp, sharedRole === 'owner');
      const balances = getEmployeeBalancesByCurrency(emp, currency);
      const workStatus = getPersonWorkStatus(emp.endDate);
      const isMonthly = emp.wageType === 'monthly' || (Boolean(emp.monthlySalary && Number(emp.monthlySalary) > 0) && !emp.dailyWage);
      const empCurrency = emp.dailyWageCurrency || currency;
      const wageSubtitle = isMonthly
        ? `راتب شهري: ${formatCurrency(Number(emp.monthlySalary) || 0, empCurrency)} / شهر`
        : `أجر يومي: ${formatCurrency(Number(emp.dailyWage) || 0, empCurrency)} / يوم`;

      let ledgerRowsHtml = '';
      emp.ledger.forEach(e => {
        const cur = e.currency || emp.dailyWageCurrency || currency;
        ledgerRowsHtml += `
          <tr>
            <td style="font-family: monospace; padding: 6px 8px; border: 1px solid #cbd5e1; width: 14%;">${formatDateArabic(e.date)}</td>
            <td style="font-weight: bold; padding: 6px 8px; border: 1px solid #cbd5e1; width: 38%;" class="col-statement">${e.description}</td>
            <td style="color: #dc2626; font-family: monospace; padding: 6px 8px; border: 1px solid #cbd5e1; width: 17%; text-align: center;">${e.amountOnHim > 0 ? formatCurrency(e.amountOnHim, cur) : '-'}</td>
            <td style="color: #10b981; font-family: monospace; padding: 6px 8px; border: 1px solid #cbd5e1; width: 17%; text-align: center;">${e.amountForHim > 0 ? formatCurrency(e.amountForHim, cur) : '-'}</td>
            <td style="font-size: 9.5px; color: #64748b; line-height: 1.35; padding: 6px 8px; border: 1px solid #cbd5e1; width: 14%;" class="col-notes">${e.notes || '-'}</td>
          </tr>
        `;
      });

      const balanceBadges = balances.map(b => `
        <span style="color: #f87171; margin-left: 6px;">عليه: ${formatCurrency(b.onHim, b.currency)}</span> | 
        <span style="color: #34d399; margin-left: 6px;">له: ${formatCurrency(b.forHim, b.currency)}</span> | 
        <span style="color: #818cf8; margin-left: 10px;">الصافي: ${b.net >= 0 ? formatCurrency(b.net, b.currency) : `-${formatCurrency(Math.abs(b.net), b.currency)}`}</span>
      `).join(' • ');

      employeesDetailedLedgersHtml += `
        <div style="margin-top: 14px; margin-bottom: 18px; border: 1px solid #cbd5e1; border-radius: 8px; overflow: hidden; break-inside: auto;">
          <div style="background-color: #1e1b4b; color: #ffffff; padding: 8px 12px; display: flex; justify-content: space-between; align-items: center; break-after: avoid; page-break-after: avoid;">
            <div>
              <span style="font-weight: bold; font-size: 13.5px;">👔 الموظف: ${emp.name}</span>
              <span style="display: inline-block; padding: 2px 7px; border-radius: 4px; font-size: 11px; font-weight: bold; margin-right: 6px; background-color: ${workStatus.isStopped ? '#dc2626' : '#15803d'}; color: #ffffff;">${workStatus.statusText}</span>
              <span style="font-size: 11.5px; color: #a5b4fc; margin-right: 8px;">(${emp.profession} - ${days} يوم عمل - ${wageSubtitle})</span>
            </div>
            <div style="font-size: 11.5px; font-weight: bold;">
              ${balanceBadges}
            </div>
          </div>
          <table class="report-data-table" style="margin: 0; width: 100%; border-collapse: collapse; font-size: 11.5px;">
            <thead>
              <tr style="background-color: #f1f5f9; color: #1e293b; break-inside: avoid; page-break-inside: avoid;">
                <th style="padding: 6px 8px; border: 1px solid #cbd5e1; width: 14%;">التاريخ</th>
                <th style="padding: 6px 8px; border: 1px solid #cbd5e1; width: 38%;" class="col-statement">البيان / الوصف</th>
                <th style="padding: 6px 8px; border: 1px solid #cbd5e1; width: 17%; text-align: center;">عليه (سلف)</th>
                <th style="padding: 6px 8px; border: 1px solid #cbd5e1; width: 17%; text-align: center;">له (راتب)</th>
                <th style="padding: 6px 8px; border: 1px solid #cbd5e1; width: 14%;" class="col-notes">ملاحظات</th>
              </tr>
            </thead>
            <tbody>
              ${emp.ledger.length === 0 ? '<tr><td colspan="5" style="text-align: center; color: #94a3b8; padding: 10px; border: 1px solid #cbd5e1;">لا توجد معاملات مسجلة لهذا الموظف حالياً.</td></tr>' : ledgerRowsHtml}
            </tbody>
          </table>
        </div>
      `;
    });

    const primaryTotals = totalsByCurrency[currency] || Object.values(totalsByCurrency)[0] || { forHim: 0, onHim: 0 };
    const primaryNet = primaryTotals.forHim - primaryTotals.onHim;

    // Professions Donut Chart Data
    const profColors = ['#6366f1', '#0284c7', '#059669', '#d97706', '#8b5cf6', '#ec4899', '#14b8a6'];
    const sortedProfessions = Object.entries(professionCounts).sort((a, b) => b[1].count - a[1].count);
    const profChartData = sortedProfessions.map(([name, data], idx) => ({
      label: name,
      value: data.count,
      color: profColors[idx % profColors.length],
      formattedValue: `${data.count} موظف`,
      subText: data.totalWages > 0 ? formatCurrency(data.totalWages, currency) : undefined
    }));

    const profDonutChartHtml = generateSvgDonutChart({
      data: profChartData,
      size: 140,
      centerTitle: `${sortedEmployees.length}`,
      centerSubtitle: 'إجمالي الموظفين',
      showLegend: true
    });

    const employeeMetricCardsHtml = generateMetricCardsGrid([
      {
        title: 'إجمالي عدد الموظفين',
        value: `${sortedEmployees.length} موظف`,
        badge: 'الكادر الإداري',
        bgColor: '#eff6ff',
        borderColor: '#bfdbfe',
        textColor: '#1d4ed8'
      },
      {
        title: 'إجمالي المستحقات (له)',
        value: formatCurrency(primaryTotals.forHim, currency),
        badge: 'رواتب ومستحقات',
        bgColor: '#f0fdf4',
        borderColor: '#bbf7d0',
        textColor: '#15803d'
      },
      {
        title: 'إجمالي المسدد والسلف (عليه)',
        value: formatCurrency(primaryTotals.onHim, currency),
        badge: 'مدفوعات وسلف',
        bgColor: '#fef2f2',
        borderColor: '#fecaca',
        textColor: '#b91c1c'
      },
      {
        title: 'صافي الرصيد المستحق',
        value: formatCurrency(Math.abs(primaryNet), currency),
        badge: primaryNet >= 0 ? 'مستحق للموظفين' : 'سلف مستردة',
        bgColor: primaryNet >= 0 ? '#f0fdf4' : '#fffbeb',
        borderColor: primaryNet >= 0 ? '#bbf7d0' : '#fde68a',
        textColor: primaryNet >= 0 ? '#15803d' : '#b45309'
      }
    ], 4);

    const balanceComparisonHtml = generateSvgBalanceComparison({
      forHim: primaryTotals.forHim,
      onHim: primaryTotals.onHim,
      forHimLabel: 'إجمالي الرواتب والاستحقاقات (له)',
      onHimLabel: 'إجمالي السلف والمدفوعات (عليه)',
      forHimFormatted: formatCurrency(primaryTotals.forHim, currency),
      onHimFormatted: formatCurrency(primaryTotals.onHim, currency),
      netFormatted: primaryNet >= 0 ? `له (${formatCurrency(primaryNet, currency)})` : `عليه (${formatCurrency(Math.abs(primaryNet), currency)})`,
      isPositive: primaryNet >= 0
    });

    const totalsBoxesHtml = Object.entries(totalsByCurrency).map(([cur, totals]) => {
      const netSum = totals.forHim - totals.onHim;
      return `
        <div style="background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 8px 12px; margin-bottom: 6px; display: flex; justify-content: space-between; font-size: 11.5px;">
          <div><strong>العملة:</strong> ${cur}</div>
          <div><strong>إجمالي الاستحقاقات (له):</strong> <span style="color: #10b981; font-weight: bold;">${formatCurrency(totals.forHim, cur)}</span></div>
          <div><strong>إجمالي السلف والمدفوعات (عليه):</strong> <span style="color: #e11d48; font-weight: bold;">${formatCurrency(totals.onHim, cur)}</span></div>
          <div><strong>صافي الرصيد:</strong> <span style="font-weight: bold; color: ${netSum >= 0 ? '#10b981' : '#e11d48'};">${netSum >= 0 ? `له (${formatCurrency(netSum, cur)})` : `عليه (${formatCurrency(Math.abs(netSum), cur)})`}</span></div>
        </div>
      `;
    }).join('');

    const htmlContent = `
      <div style="direction: rtl; font-family: sans-serif; padding: 10px;">
        
        <!-- Header -->
        <div style="border-bottom: 2px solid #6366f1; padding-bottom: 12px; margin-bottom: 16px; display: flex; justify-content: space-between; align-items: center;">
          <div>
            <h1 style="margin: 0; color: #1e293b; font-size: 19px;">📊 تقرير حسابات الموظفين والكادر الإداري الشامل</h1>
            <p style="margin: 4px 0 0 0; color: #64748b; font-size: 12px;">ورلد أوف إيليتس للتجارة والمقاولات</p>
          </div>
          <div style="text-align: left; font-size: 11.5px; color: #64748b;">
            تاريخ التقرير: ${new Date().toLocaleDateString('ar-EG-u-nu-latn')}
          </div>
        </div>

        <!-- 📊 PAGE 1: EXECUTIVE ANALYTICS DASHBOARD -->
        <div style="margin-bottom: 20px; page-break-inside: avoid;">
          
          <div style="background: linear-gradient(135deg, #1e1b4b 0%, #312e81 100%); color: #ffffff; padding: 10px 14px; border-radius: 8px; margin-bottom: 12px; display: flex; justify-content: space-between; align-items: center; border-right: 4px solid #6366f1;">
            <div>
              <h2 style="margin: 0; font-size: 14px; font-weight: 800; color: #ffffff;">لوحة التحليلات والمؤشرات البيانية لحسابات الموظفين</h2>
              <div style="font-size: 9.5px; color: #c7d2fe; margin-top: 2px;">ملخص هيكل الرواتب، توزيع التخصصات، وموازين السلف والمستحقات</div>
            </div>
            <span style="font-size: 10.5px; background-color: #4f46e5; color: #ffffff; padding: 3px 8px; border-radius: 10px; font-weight: bold;">العملة: ${currency}</span>
          </div>

          <!-- KPI Metric Cards Grid -->
          ${employeeMetricCardsHtml}

          <!-- Balance Comparison & Gauge -->
          ${balanceComparisonHtml}

          <!-- Visual Breakdown: Professions Donut & Currency Totals -->
          <div style="display: grid; grid-template-columns: 1.25fr 1fr; gap: 10px; margin-bottom: 12px;">
            
            <div style="background-color: #ffffff; border: 1px solid #cbd5e1; border-radius: 8px; padding: 10px;">
              <div style="font-size: 11px; font-weight: bold; color: #1e1b4b; border-bottom: 1px solid #e2e8f0; padding-bottom: 4px; margin-bottom: 8px;">
                🍩 توزيع الكادر الوظيفي حسب التخصصات والمسميات
              </div>
              ${profDonutChartHtml}
            </div>

            <div style="background-color: #ffffff; border: 1px solid #cbd5e1; border-radius: 8px; padding: 10px; display: flex; flex-direction: column; justify-content: space-between;">
              <div>
                <div style="font-size: 11px; font-weight: bold; color: #1e1b4b; border-bottom: 1px solid #e2e8f0; padding-bottom: 4px; margin-bottom: 8px;">
                  💰 إجماليات حسابات الموظفين حسب العملات
                </div>
                ${totalsBoxesHtml}
              </div>
              <div style="font-size: 9px; color: #64748b; background: #f8fafc; padding: 4px 6px; border-radius: 4px; border: 1px solid #e2e8f0;">
                يشمل كشف الحساب الأجور اليومية، الرواتب الشهرية، السلف النقدية ومصروفات التغذية.
              </div>
            </div>

          </div>

        </div>

        <!-- PAGE BREAK AFTER DASHBOARD -->
        <div style="page-break-before: always;"></div>

        <!-- SECTION 1: SUMMARY TABLE -->
        <div style="margin-bottom: 25px;">
          <h3 style="font-size: 14px; font-weight: bold; color: #1e293b; border-bottom: 2px solid #6366f1; padding-bottom: 6px; margin-bottom: 12px;">
            أولاً: جدول ملخص حسابات وأرصدة الموظفين
          </h3>
          <table style="width: 100%; border-collapse: collapse; font-size: 11.5px; margin-bottom: 20px;">
            <thead>
              <tr style="background-color: #6366f1; color: white;">
                <th style="padding: 8px; border: 1px solid #cbd5e1; text-align: center; width: 35px;">#</th>
                <th style="padding: 8px; border: 1px solid #cbd5e1; text-align: right;">اسم الموظف</th>
                <th style="padding: 8px; border: 1px solid #cbd5e1; text-align: center; width: 85px;">الحالة</th>
                <th style="padding: 8px; border: 1px solid #cbd5e1; text-align: right;">المسمى الوظيفي</th>
                <th style="padding: 8px; border: 1px solid #cbd5e1; text-align: center;">الأجر / الراتب</th>
                <th style="padding: 8px; border: 1px solid #cbd5e1; text-align: center;">أيام العمل</th>
                <th style="padding: 8px; border: 1px solid #cbd5e1; text-align: center;">المستحق له</th>
                <th style="padding: 8px; border: 1px solid #cbd5e1; text-align: center;">المدفوع عليه</th>
                <th style="padding: 8px; border: 1px solid #cbd5e1; text-align: center;">الرصيد الصافي</th>
              </tr>
            </thead>
            <tbody>
              ${sortedEmployees.length === 0 ? '<tr><td colspan="9" style="text-align: center; color: #94a3b8; padding: 12px;">لا يوجد موظفين مسجلين.</td></tr>' : summaryRowsHtml}
            </tbody>
          </table>
        </div>

        <!-- SECTION 2: DETAILED LEDGERS FOR ALL EMPLOYEES -->
        <div style="margin-bottom: 25px;">
          <h3 style="font-size: 14px; font-weight: bold; color: #1e293b; border-bottom: 2px solid #6366f1; padding-bottom: 6px; margin-top: 20px; margin-bottom: 12px; break-after: avoid; page-break-after: avoid; break-before: auto;">
            ثانياً: كشوفات تفصيلية بكافة الحركات والعمليات المالية لكل موظف
          </h3>
          ${sortedEmployees.length === 0 ? '<p style="text-align: center; color: #94a3b8;">لا توجد بيانات تفصيلية.</p>' : employeesDetailedLedgersHtml}
        </div>
      </div>
    `;

    printPDF('تقرير الموظفين الشامل التفصيلي', htmlContent);
  };

  // Excel File upload/import handler for active employee's ledger
  const handleEmployeeLedgerExcelImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !selectedEmployeeId) return;

    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const bstr = evt.target?.result;
        const wb = XLSX.read(bstr, { type: 'binary' });
        const wsname = wb.SheetNames[0];
        const ws = wb.Sheets[wsname];
        const data = XLSX.utils.sheet_to_json<any>(ws);

        if (!data || data.length === 0) {
          alert('ملف Excel فارغ أو غير صالح.');
          return;
        }

        let count = 0;
        data.forEach(row => {
          const dateVal = row['التاريخ'] || row['تاريخ'] || row['Date'] || row['date'] || new Date().toISOString().split('T')[0];
          const desc = row['البيان'] || row['الوصف'] || row['Description'] || row['description'] || 'حركة مستوردة من Excel';
          const onHim = Number(row['المبلغ عليه'] || row['عليه'] || row['OnHim'] || row['amountOnHim'] || 0);
          const forHim = Number(row['المبلغ له'] || row['له'] || row['ForHim'] || row['amountForHim'] || 0);
          const notes = row['ملاحظات'] || row['Notes'] || '';
          const cur = row['العملة'] || row['Currency'] || activeEmployee?.dailyWageCurrency || currency;

          if (onHim > 0 || forHim > 0 || desc) {
            const parseDate = (d: any) => {
              if (typeof d === 'number') {
                const dateObj = XLSX.SSF.parse_date_code(d);
                return `${dateObj.y}-${String(dateObj.m).padStart(2, '0')}-${String(dateObj.d).padStart(2, '0')}`;
              }
              const stringDate = String(d).trim();
              const parsed = Date.parse(stringDate);
              if (!isNaN(parsed)) {
                return new Date(parsed).toISOString().split('T')[0];
              }
              return stringDate;
            };

            onAddEmployeeLedgerEntry(selectedEmployeeId, {
              date: parseDate(dateVal),
              amountOnHim: onHim,
              amountForHim: forHim,
              description: String(desc).trim(),
              notes: String(notes).trim(),
              currency: String(cur).trim()
            });
            count++;
          }
        });

        alert(`تم استيراد ${count} حركة بنجاح من ملف Excel!`);
      } catch (err) {
        console.error("Error reading Excel for employee ledger:", err);
        alert('حدث خطأ أثناء قراءة ملف Excel. يرجى التأكد من أن الأعمدة مطابقة (التاريخ، البيان، مبلغ عليه، مبلغ له).');
      }
    };
    reader.readAsBinaryString(file);
    e.target.value = '';
  };

  // Form submit for adding manual ledger entry
  const handleAddLedgerSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLedgerError('');

    if (!selectedEmployeeId) return;

    const onHim = Number(ledgerAmountOnHim) || 0;
    const forHim = Number(ledgerAmountForHim) || 0;

    if (onHim <= 0 && forHim <= 0) {
      setLedgerError('يجب إدخال مبلغ في خانة "عليه" أو "له".');
      return;
    }
    if (!ledgerDescription.trim()) {
      setLedgerError('الرجاء إدخال بيان الحركة.');
      return;
    }
    if (!ledgerDate) {
      setLedgerError('الرجاء اختيار تاريخ الحركة.');
      return;
    }

    onAddEmployeeLedgerEntry(selectedEmployeeId, {
      date: ledgerDate,
      amountOnHim: onHim,
      amountForHim: forHim,
      description: ledgerDescription.trim(),
      notes: ledgerNotes.trim(),
      currency: ledgerCurrency
    });

    // Reset ledger form
    setLedgerAmountOnHim('');
    setLedgerAmountForHim('');
    setLedgerDescription('');
    setLedgerNotes('');
  };

  // Form submit for extra work period
  const handleAddExtraPeriodSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setExtraFormError('');

    if (!selectedEmployeeId || !onAddEmployeeExtraPeriod) return;
    if (!extraStart) {
      setExtraFormError('الرجاء تحديد تاريخ بدء الفترة الإضافية.');
      return;
    }
    if (extraEnd && new Date(extraStart) > new Date(extraEnd)) {
      setExtraFormError('تاريخ البدء يجب أن يكون قبل أو يساوي تاريخ الانتهاء.');
      return;
    }

    onAddEmployeeExtraPeriod(selectedEmployeeId, extraStart, extraEnd || '');

    // Reset
    setExtraStart('');
    setExtraEnd('');
    setShowExtraForm(false);
    setSyncToastMessage('تمت إضافة فترة العمل الإضافية وتحديث العملية المالية في الكشف تلقائياً!');
    setTimeout(() => setSyncToastMessage(null), 3500);
  };

  // Handle start editing extra period
  const handleStartEditExtraPeriod = (p: { id: string; startDate: string; endDate?: string }) => {
    setEditingExtraPeriodId(p.id);
    setEditExtraStart(p.startDate || '');
    setEditExtraEnd(p.endDate || '');
    setEditExtraError('');
  };

  // Handle save editing extra period
  const handleSaveExtraPeriodEdit = (periodId: string) => {
    setEditExtraError('');
    if (!selectedEmployeeId || !onUpdateEmployeeExtraPeriod) return;
    if (!editExtraStart) {
      setEditExtraError('الرجاء تحديد تاريخ بدء الفترة الإضافية.');
      return;
    }
    if (editExtraEnd && new Date(editExtraStart) > new Date(editExtraEnd)) {
      setEditExtraError('تاريخ البدء يجب أن يكون قبل أو يساوي تاريخ الانتهاء.');
      return;
    }

    onUpdateEmployeeExtraPeriod(selectedEmployeeId, periodId, editExtraStart, editExtraEnd || '');
    setEditingExtraPeriodId(null);
    setEditExtraStart('');
    setEditExtraEnd('');
    setSyncToastMessage('تم تعديل الفترة الإضافية وتحديث العملية المالية في الكشف تلقائياً!');
    setTimeout(() => setSyncToastMessage(null), 3500);
  };

  // Quick wage form submit
  const handleQuickWageSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeEmployee || !onUpdateEmployee) return;
    const numWage = Number(quickWageValue) || 0;
    const numSalary = Number(quickMonthlySalaryValue) || 0;

    onUpdateEmployee(activeEmployee.id, {
      wageType: quickWageType,
      dailyWage: quickWageType === 'daily' ? numWage : 0,
      monthlySalary: quickWageType === 'monthly' ? numSalary : 0,
      dailyWageCurrency: quickWageCurrency,
      disableAutoSalaryCalculation: false,
      excludedSalaryMonthKeys: []
    });

    setShowQuickWageModal(false);
    setSyncToastMessage('تم تحديث الراتب/الأجر وإظهار العملية المالية في كشف الحساب تلقائياً بنجاح!');
    setTimeout(() => setSyncToastMessage(null), 3500);
  };

  // Quick basic work period submit
  const handleQuickBasicPeriodSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeEmployee || !onUpdateEmployee) return;
    if (!quickBasicStartDate) {
      alert('الرجاء تحديد تاريخ بدء العمل الأساسي.');
      return;
    }
    if (quickBasicEndDate && new Date(quickBasicStartDate) > new Date(quickBasicEndDate)) {
      alert('تاريخ بدء العمل يجب أن يكون قبل أو يساوي تاريخ الانتهاء.');
      return;
    }

    onUpdateEmployee(activeEmployee.id, {
      startDate: quickBasicStartDate,
      endDate: quickBasicEndDate,
      disableAutoSalaryCalculation: false,
      excludedSalaryMonthKeys: []
    });

    setShowQuickBasicPeriodModal(false);
    setSyncToastMessage('تم تحديث فترة العمل الأساسية وإظهار العملية المالية المرتبطة بنجاح!');
    setTimeout(() => setSyncToastMessage(null), 3500);
  };

  // Manual instant sync trigger
  const handleManualSyncWage = () => {
    if (!activeEmployee || !onUpdateEmployee) return;
    onUpdateEmployee(activeEmployee.id, {
      dailyWage: activeEmployee.dailyWage,
      monthlySalary: activeEmployee.monthlySalary,
      startDate: activeEmployee.startDate,
      endDate: activeEmployee.endDate,
      wageType: activeEmployee.wageType,
      dailyWageCurrency: activeEmployee.dailyWageCurrency,
      disableAutoSalaryCalculation: false,
      excludedSalaryMonthKeys: []
    });
    setSyncToastMessage('تمت استعادة وتحديث العملية المالية في كشف الحساب بنجاح!');
    setTimeout(() => setSyncToastMessage(null), 3500);
  };

  // Scroll to and highlight auto wage entry
  const handleScrollToWageEntry = () => {
    if (!activeEmployee) return;
    const autoEntry = activeEmployee.ledger.find(
      entry => entry.isAutoDailyWage || entry.id === `auto_wage_${activeEmployee.id}` || entry.id.startsWith('auto_wage_') || entry.isAutoMonthlySalary
    );
    if (!autoEntry) {
      handleManualSyncWage();
      return;
    }
    setHighlightedEntryId(autoEntry.id);
    const element = document.getElementById(`ledger-row-${autoEntry.id}`);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
    setTimeout(() => {
      setHighlightedEntryId(null);
    }, 4500);
  };

  // Export Employee Ledger to CSV
  const handleExportLedgerCSV = (employee: Employee) => {
    const headers = ['التاريخ', 'البيان', 'المبلغ عليه (دفعة/سلفة)', 'المبلغ له (أجور)', 'العملة', 'ملاحظات', 'تم الترحيل'];
    const sortedLedger = [...employee.ledger].sort((a, b) => b.date.localeCompare(a.date));
    const data = sortedLedger.map(entry => [
      formatDateArabic(entry.date),
      entry.description,
      entry.amountOnHim,
      entry.amountForHim,
      entry.currency || employee.dailyWageCurrency || currency,
      entry.notes || '-',
      entry.isPosted ? 'نعم (من النفقات)' : 'لا'
    ]);

    const balances = getEmployeeBalancesByCurrency(employee, currency);

    data.push(['', '', '', '', '', '', '']);
    balances.forEach(b => {
      data.push([`الإجمالي له (${b.currency})`, '', '', b.forHim, b.currency, '', '']);
      data.push([`الإجمالي عليه (${b.currency})`, '', b.onHim, '', b.currency, '', '']);
      data.push([`صافي الرصيد المستحق (${b.currency})`, '', '', b.net, b.currency, b.net > 0 ? 'له مستحقات' : b.net < 0 ? 'عليه سلفة' : 'خالص', '']);
    });

    const stringData: string[][] = data.map(row => row.map(cell => String(cell)));
    exportToCSV(`كشف_حساب_الموظف_${employee.name.replace(/\s+/g, '_')}`, headers, stringData);
  };

  // Print Employee PDF
  const handlePrintEmployeePDF = (employee: Employee) => {
    const totalDays = getEmployeeTotalDays(employee, sharedRole === 'owner');
    const balances = getEmployeeBalancesByCurrency(employee, currency);
    const primaryBalance = balances.find(b => b.currency === (employee.dailyWageCurrency || currency)) || balances[0] || { currency, forHim: 0, onHim: 0, net: 0 };
    const empCurrency = primaryBalance.currency;

    const metricCardsHtml = generateMetricCardsGrid([
      {
        title: 'إجمالي المستحق (له)',
        value: formatCurrency(primaryBalance.forHim, empCurrency),
        badge: 'رواتب واستحقاقات',
        bgColor: '#f0fdf4',
        borderColor: '#bbf7d0',
        textColor: '#15803d'
      },
      {
        title: 'إجمالي المسدد (عليه)',
        value: formatCurrency(primaryBalance.onHim, empCurrency),
        badge: 'سلف ومدفوعات',
        bgColor: '#fef2f2',
        borderColor: '#fecaca',
        textColor: '#b91c1c'
      },
      {
        title: 'صافي الرصيد المستحق',
        value: formatCurrency(Math.abs(primaryBalance.net), empCurrency),
        badge: primaryBalance.net >= 0 ? 'مستحق للموظف' : 'سلفة مستردة',
        bgColor: primaryBalance.net >= 0 ? '#f0fdf4' : '#fffbeb',
        borderColor: primaryBalance.net >= 0 ? '#bbf7d0' : '#fde68a',
        textColor: primaryBalance.net >= 0 ? '#15803d' : '#b45309'
      }
    ], 3);

    const balanceGaugeHtml = generateSvgBalanceComparison({
      forHim: primaryBalance.forHim,
      onHim: primaryBalance.onHim,
      forHimLabel: 'المستحق له (أجور)',
      onHimLabel: 'المسدد عليه (سلف)',
      forHimFormatted: formatCurrency(primaryBalance.forHim, empCurrency),
      onHimFormatted: formatCurrency(primaryBalance.onHim, empCurrency),
      netFormatted: primaryBalance.net >= 0 ? `له (${formatCurrency(primaryBalance.net, empCurrency)})` : `عليه (${formatCurrency(Math.abs(primaryBalance.net), empCurrency)})`,
      isPositive: primaryBalance.net >= 0
    });

    const balancesHtml = balances.map(b => `
      <div style="margin-bottom: 4px; padding-bottom: 4px; border-bottom: 1px dashed #cbd5e1; display: flex; justify-content: space-between; font-size: 12px;">
        <span>العملة: <strong>${b.currency}</strong></span>
        <span>إجمالي له: <strong style="color:#10b981;">${formatCurrency(b.forHim, b.currency)}</strong></span>
        <span>إجمالي عليه: <strong style="color:#e11d48;">${formatCurrency(b.onHim, b.currency)}</strong></span>
        <span>صافي المستحق: <strong>${formatCurrency(b.net, b.currency)} (${b.net >= 0 ? 'له' : 'عليه'})</strong></span>
      </div>
    `).join('');

    const empStatus = getPersonWorkStatus(employee.endDate);
    const isMonthlyEmp = employee.wageType === 'monthly' || (Boolean(employee.monthlySalary && Number(employee.monthlySalary) > 0) && !employee.dailyWage);
    const wageOrSalaryEmpText = isMonthlyEmp
      ? (employee.monthlySalary ? `${formatCurrency(Number(employee.monthlySalary), empCurrency)} / شهر (راتب شهري)` : `${formatCurrency(0, empCurrency)} (راتب شهري)`)
      : (employee.dailyWage ? `${formatCurrency(Number(employee.dailyWage), empCurrency)} / يوم (أجر يومي)` : `${formatCurrency(0, empCurrency)} (أجر يومي)`);

    const htmlContent = `
      <div style="direction: rtl; font-family: sans-serif; padding: 15px;">
        
        <!-- Header -->
        <div style="border-bottom: 2px solid #6366f1; padding-bottom: 12px; margin-bottom: 16px; display: flex; justify-content: space-between; align-items: center;">
          <div>
            <h1 style="margin: 0; color: #1e293b; font-size: 19px;">📋 كشف حساب تفصيلي للموظف</h1>
            <p style="margin: 4px 0 0 0; color: #64748b; font-size: 12px;">تطبيق إدارة مشاريع المقاولات والإنشاءات</p>
          </div>
          <div style="text-align: left; font-size: 11.5px; color: #64748b;">
            تاريخ الطباعة: ${new Date().toLocaleDateString('ar-EG-u-nu-latn')}
          </div>
        </div>

        <!-- Employee Info Card -->
        <div style="background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 12px 16px; margin-bottom: 16px;">
          <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; font-size: 12px;">
            <div><strong>اسم الموظف:</strong> ${employee.name}</div>
            <div><strong>المسمى الوظيفي:</strong> ${employee.profession}</div>
            <div><strong>الحالة:</strong> <span style="display: inline-block; padding: 1.5px 8px; border-radius: 4px; font-size: 11px; font-weight: bold; background-color: ${empStatus.isStopped ? '#fee2e2' : '#dcfce7'}; color: ${empStatus.isStopped ? '#991b1b' : '#166534'}; border: 1px solid ${empStatus.isStopped ? '#fecaca' : '#bbf7d0'};">${empStatus.statusText}</span></div>
            <div><strong>الأجر / الراتب:</strong> ${wageOrSalaryEmpText}</div>
            <div><strong>تاريخ البدء:</strong> ${formatDateArabic(employee.startDate)}</div>
            <div><strong>تاريخ الانتهاء:</strong> ${employee.endDate ? formatDateArabic(employee.endDate) : 'مستمر'}</div>
            <div><strong>إجمالي أيام العمل:</strong> ${totalDays} يوم</div>
          </div>
        </div>

        <!-- Analytics Visuals -->
        <div style="margin-bottom: 16px; page-break-inside: avoid;">
          ${metricCardsHtml}
          ${balanceGaugeHtml}
        </div>

        <!-- Detailed Table -->
        <table class="report-data-table" style="width: 100%; border-collapse: collapse; font-size: 11.5px; margin-bottom: 20px;">
          <thead>
            <tr style="background-color: #6366f1; color: white;">
              <th style="padding: 8px; border: 1px solid #cbd5e1; text-align: right; width: 14%;">التاريخ</th>
              <th style="padding: 8px; border: 1px solid #cbd5e1; text-align: right; width: 38%;" class="col-statement">البيان التفصيلي</th>
              <th style="padding: 8px; border: 1px solid #cbd5e1; text-align: center; width: 17%;">المبلغ عليه (سلف)</th>
              <th style="padding: 8px; border: 1px solid #cbd5e1; text-align: center; width: 17%;">المبلغ له (أجور)</th>
              <th style="padding: 8px; border: 1px solid #cbd5e1; width: 14%;" class="col-notes">ملاحظات</th>
            </tr>
          </thead>
          <tbody>
            ${[...employee.ledger].sort((a, b) => b.date.localeCompare(a.date)).map((e, idx) => {
              const rowCurrency = e.currency || employee.dailyWageCurrency || currency;
              return `
                <tr style="background-color: ${idx % 2 === 0 ? '#ffffff' : '#f8fafc'};">
                  <td style="padding: 8px; border: 1px solid #e2e8f0; font-family: monospace; width: 14%;">${formatDateArabic(e.date)}</td>
                  <td style="padding: 8px; border: 1px solid #e2e8f0; width: 38%; font-weight: bold;" class="col-statement">${e.description} ${e.isPosted ? '<span style="color:#6366f1;">(مرحّل)</span>' : ''}</td>
                  <td style="padding: 8px; border: 1px solid #e2e8f0; text-align: center; color: #e11d48; font-weight: bold; width: 17%;">${e.amountOnHim ? formatCurrency(e.amountOnHim, rowCurrency) : '-'}</td>
                  <td style="padding: 8px; border: 1px solid #e2e8f0; text-align: center; color: #10b981; font-weight: bold; width: 17%;">${e.amountForHim ? formatCurrency(e.amountForHim, rowCurrency) : '-'}</td>
                  <td style="padding: 8px; border: 1px solid #e2e8f0; font-size: 9.5px; color: #64748b; line-height: 1.35; width: 14%;" class="col-notes">${e.notes || '-'}</td>
                </tr>
              `;
            }).join('')}
          </tbody>
        </table>

        <!-- Balances Summary -->
        <div style="background-color: #f1f5f9; border-radius: 8px; padding: 12px; font-weight: bold; border: 1px solid #cbd5e1;">
          <div style="font-size: 12px; margin-bottom: 6px; color: #1e293b;">ملخص الأرصدة الإجمالية:</div>
          ${balancesHtml}
        </div>
      </div>
    `;

    printPDF(`كشف_حساب_الموظف_${employee.name}`, htmlContent);
  };

  return (
    <div className="space-y-4 animate-fade-in" id="employees-section">
      {/* Detail View of a Selected Employee */}
      {activeEmployee ? (
        <div className="space-y-4">
          
          {/* Detail Header / Nav back */}
          <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-100 shadow-xs space-y-3">
            <div className="flex items-start justify-between gap-4 w-full">
              <div className="flex items-center gap-3">
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <h2 className="text-xl font-bold text-slate-800">{activeEmployee.name}</h2>
                    <span className="text-xs bg-indigo-100 text-indigo-700 px-2.5 py-0.5 rounded-full font-bold">{activeEmployee.profession}</span>
                    {(() => {
                      const status = getPersonWorkStatus(activeEmployee.endDate);
                      return (
                        <span className={`text-[11px] px-2.5 py-0.5 rounded-full font-bold border ${status.badgeClass} flex items-center gap-1`}>
                          <span className={`w-1.5 h-1.5 rounded-full ${status.isStopped ? 'bg-rose-500' : 'bg-emerald-500'}`}></span>
                          {status.statusText}
                        </span>
                      );
                    })()}
                    {activeEmployee.wageType === 'monthly' ? (
                      (activeEmployee.monthlySalary || 0) > 0 && (
                        <span className="text-xs bg-emerald-100 text-emerald-800 font-extrabold px-2.5 py-0.5 rounded-full border border-emerald-200">
                          الراتب الشهري: {formatCurrency(activeEmployee.monthlySalary || 0, activeEmployee.dailyWageCurrency || currency)} / شهر
                        </span>
                      )
                    ) : (
                      activeEmployee.dailyWage > 0 && (
                        <span className="text-xs bg-emerald-100 text-emerald-800 font-extrabold px-2.5 py-0.5 rounded-full border border-emerald-200">
                          الأجر اليومي: {formatCurrency(activeEmployee.dailyWage, activeEmployee.dailyWageCurrency || currency)} / يوم
                        </span>
                      )
                    )}
                    <AttributionBadge createdBy={activeEmployee.createdBy} updatedBy={activeEmployee.updatedBy} />
                  </div>
                  <p className="text-slate-400 text-xs mt-1 flex items-center gap-1.5">
                    <Calendar size={13} />
                    تاريخ العمل: {formatDateArabic(activeEmployee.startDate)} إلى {activeEmployee.endDate ? formatDateArabic(activeEmployee.endDate) : 'الآن (مستمر)'}
                  </p>
                  <PhoneNumbersDisplay phoneNumbers={activeEmployee.phoneNumbers} className="mt-2" />
                </div>
              </div>

              <div className="flex flex-col items-end gap-1.5 shrink-0">
                {setActiveTab && (
                  <button 
                    onClick={() => setActiveTab('dashboard')}
                    className="h-8 px-3 bg-white hover:bg-slate-50 text-slate-800 font-bold text-[11px] border border-slate-200/90 rounded-lg shadow-2xs hover:shadow-xs transition-all duration-200 flex items-center gap-1.5 cursor-pointer shrink-0 w-full justify-center"
                    title="الرجوع للرئيسية"
                  >
                    <ArrowLeft size={14} className="text-slate-700 shrink-0" />
                    <span>الرجوع للرئيسية</span>
                  </button>
                )}

                <button 
                  onClick={() => { setSelectedEmployeeId(null); setLedgerError(''); }}
                  className="h-8 px-3 bg-white hover:bg-slate-50 text-slate-800 font-bold text-[11px] border border-slate-200/90 rounded-lg shadow-2xs hover:shadow-xs transition-all duration-200 flex items-center gap-1.5 cursor-pointer shrink-0 w-full justify-center"
                  title="الرجوع لقائمة الموظفين"
                >
                  <ArrowLeft size={14} className="text-slate-700 shrink-0" />
                  <span>الرجوع لقائمة الموظفين</span>
                </button>

                <OptionsMenu 
                  onExportExcel={() => handleExportLedgerCSV(activeEmployee)}
                  onExportPDF={() => handlePrintEmployeePDF(activeEmployee)}
                  onImportExcel={sharedRole !== 'read' ? handleEmployeeLedgerExcelImport : undefined}
                  shareTitle={`كشف حساب الموظف: ${activeEmployee.name}`}
                  shareText={(() => {
                    const days = getEmployeeTotalDays(activeEmployee, sharedRole === 'owner');
                    const balances = getEmployeeBalancesByCurrency(activeEmployee, currency);
                    const balancesSummary = balances.map(b => {
                      const status = b.net === 0 ? 'متوازن' : b.net > 0 ? `له: ${formatCurrency(b.net, b.currency)}` : `عليه: ${formatCurrency(Math.abs(b.net), b.currency)}`;
                      return `• عملة ${b.currency}:\n  - إجمالي الأجور المستحقة (له): ${formatCurrency(b.forHim, b.currency)}\n  - إجمالي السلف/المدفوعات (عليه): ${formatCurrency(b.onHim, b.currency)}\n  - الصافي: ${status}`;
                    }).join('\n');

                    return `👔 كشف حساب الموظف التفصيلي: ${activeEmployee.name}\n💼 المسمى: ${activeEmployee.profession}\n📅 فترة العمل: من ${activeEmployee.startDate} إلى ${activeEmployee.endDate || 'الآن'}\n⏱️ أيام العمل المحتسبة: ${days} يوم\n💰 الأجر اليومي: ${formatCurrency(activeEmployee.dailyWage, activeEmployee.dailyWageCurrency || currency)}\n\n${balancesSummary}\n\n*تم استخراجه ومشاركته من كشوفات المقاولات*`;
                  })()}
                />
              </div>
            </div>

            {/* Actions for active employee */}
            {(sharedRole !== 'read' || onTransferEmployeeToWorker) && (
              <div className="flex items-center gap-2.5 flex-wrap w-full pt-1">
                {sharedRole !== 'read' && (
                  <button 
                    onClick={() => setEditingEmployee(activeEmployee)}
                    className="h-9 px-3.5 bg-white hover:bg-amber-50 text-amber-800 font-bold text-xs border border-slate-200/90 rounded-xl shadow-xs hover:shadow-md transition-all flex items-center gap-2 cursor-pointer shrink-0"
                    title="تعديل بيانات وتواريخ الموظف"
                  >
                    <Pencil size={15} className="text-amber-600 shrink-0" />
                    <span>تعديل</span>
                  </button>
                )}

                {sharedRole !== 'read' && ((activeEmployee.excludedSalaryMonthKeys?.length || 0) > 0 || activeEmployee.disableAutoSalaryCalculation) && onUpdateEmployee && (
                  <button 
                    onClick={() => {
                      if (confirm(`هل ترغب في إعادة تفعيل واسترجاع كافة قيود الرواتب والأجور التلقائية المحذوفة للموظف "${activeEmployee.name}"؟`)) {
                        onUpdateEmployee(activeEmployee.id, {
                          ...activeEmployee,
                          excludedSalaryMonthKeys: [],
                          disableAutoSalaryCalculation: false
                        });
                      }
                    }}
                    className="h-9 px-3.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 font-bold text-xs border border-emerald-200 rounded-xl shadow-xs hover:shadow-md transition-all flex items-center gap-2 cursor-pointer shrink-0"
                    title="إعادة احتساب وتوليد الرواتب والأجور التلقائية المحذوفة"
                  >
                    <RefreshCcw size={15} className="text-emerald-600 shrink-0" />
                    <span>إعادة احتساب الرواتب التلقائية {activeEmployee.excludedSalaryMonthKeys?.length ? `(${activeEmployee.excludedSalaryMonthKeys.length} مستبعد)` : ''}</span>
                  </button>
                )}

                {sharedRole !== 'read' && onTransferEmployeeToWorker && (
                  <button 
                    onClick={() => {
                      if (confirm(`هل ترغب بنقل كافة بيانات الموظف "${activeEmployee.name}" إلى نافذة العمال؟`)) {
                        onTransferEmployeeToWorker(activeEmployee);
                      }
                    }}
                    className="h-9 px-3.5 bg-amber-50 hover:bg-amber-100 text-amber-800 font-bold text-xs border border-amber-200 rounded-xl shadow-xs hover:shadow-md transition-all flex items-center gap-2 cursor-pointer shrink-0"
                    title="نقل الي العمال"
                  >
                    <ArrowRightLeft size={15} className="text-amber-600 shrink-0" />
                    <span>نقل الي العمال</span>
                  </button>
                )}
              </div>
            )}
          </div>

          {/* Ledger Section (Grid layout: Left = Work Info & Nutrition & Add Form, Right = Transactions Table) */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 items-start">
            
            {/* Left Col: Basic Info Metrics, Nutrition Periods & Add Transaction Form */}
            <div className="space-y-4">
              
              {/* Metrics Box (بيانات وحالة العمل) */}
              <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-xs space-y-3">
                <h3 className="font-bold text-slate-800 text-sm flex items-center justify-between pb-2 border-b border-slate-50">
                  <span className="flex items-center gap-2">
                    <Info size={16} className="text-sky-500" />
                    <span>بيانات وحالة العمل</span>
                  </span>
                  <span className={`text-[10px] px-2 py-0.5 rounded-md font-bold ${activeEmployee.endDate ? 'bg-amber-50 text-amber-700 border border-amber-200' : 'bg-emerald-50 text-emerald-700 border border-emerald-200'}`}>
                    {activeEmployee.endDate ? 'منتهي العمل' : 'على رأس العمل'}
                  </span>
                </h3>

                {/* Daily Wage / Salary row with edit trigger */}
                <div className="flex items-center justify-between p-3 bg-slate-50 rounded-xl border border-slate-100">
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-1.5 text-xs text-slate-700 font-bold">
                      <Coins size={13} className="text-amber-500" />
                      <span>{activeEmployee.wageType === 'monthly' ? 'الراتب الشهري:' : 'الأجر اليومي:'}</span>
                    </div>
                    <div className="text-[10px] text-slate-400">
                      {activeEmployee.wageType === 'monthly' ? 'راتب مقطوع شهرياً' : 'أجر يومي لكل يوم عمل'}
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="font-black text-slate-800 text-sm bg-white border border-slate-200/80 px-2.5 py-1 rounded-lg shadow-2xs font-mono">
                      {activeEmployee.wageType === 'monthly'
                        ? formatCurrency(activeEmployee.monthlySalary || 0, activeEmployee.dailyWageCurrency || currency)
                        : formatCurrency(activeEmployee.dailyWage || 0, activeEmployee.dailyWageCurrency || currency)}
                    </span>
                    {sharedRole !== 'read' && onUpdateEmployee && (
                      <button
                        type="button"
                        onClick={() => setShowQuickWageModal(true)}
                        className="p-1.5 text-slate-400 hover:text-amber-600 hover:bg-amber-50 rounded-lg transition-colors cursor-pointer"
                        title="تعديل الأجر اليومي / الراتب (ينعكس فوراً على الكشف)"
                      >
                        <Pencil size={13} />
                      </button>
                    )}
                  </div>
                </div>
                
                {/* Days of work block */}
                <div className="flex items-center justify-between p-3 bg-slate-50 rounded-xl border border-slate-100">
                  <div className="space-y-0.5">
                    <span className="text-xs text-slate-700 font-bold block">إجمالي أيام العمل:</span>
                    <span className="text-[10px] text-slate-400 block font-mono">
                      أساسية: {calculateDaysOfWork(activeEmployee.startDate, activeEmployee.endDate, sharedRole === 'owner')} + إضافية: {((activeEmployee.extraPeriods || []).reduce((sum, p) => sum + calculateDaysOfWork(p.startDate, p.endDate, sharedRole === 'owner'), 0))}
                    </span>
                  </div>
                  <span className="font-black text-slate-800 text-sm bg-white border border-slate-200/80 px-3 py-1 rounded-lg shadow-2xs font-mono">
                    {getEmployeeTotalDays(activeEmployee, sharedRole === 'owner')} يوم عمل
                  </span>
                </div>

                {/* Automatically Linked Calculation in Ledger */}
                {(() => {
                  const autoEntry = activeEmployee.ledger.find(
                    entry => entry.isAutoDailyWage || entry.id === `auto_wage_${activeEmployee.id}` || entry.id.startsWith('auto_wage_') || entry.isAutoMonthlySalary
                  );
                  const isAutoMissing = !autoEntry;

                  if (isAutoMissing) {
                    return (
                      <div className="p-3 bg-amber-50/90 rounded-xl border border-amber-200 space-y-2">
                        <div className="flex items-center justify-between gap-2">
                          <span className="text-[11px] font-bold text-amber-950 flex items-center gap-1.5">
                            <AlertCircle size={14} className="text-amber-600 shrink-0" />
                            <span>العملية المالية التلقائية محذوفة من الكشف</span>
                          </span>
                          {sharedRole !== 'read' && onUpdateEmployee && (
                            <button
                              type="button"
                              onClick={handleManualSyncWage}
                              className="px-2.5 py-1 bg-amber-600 hover:bg-amber-700 text-white font-bold text-[10px] rounded-lg shadow-2xs transition-colors flex items-center gap-1 cursor-pointer shrink-0"
                              title="إعادة إدراج وتوليد العملية المالية للأجر في كشف الحساب فوراً"
                            >
                              <RefreshCw size={11} />
                              <span>إعادة إدراج العملية الآن</span>
                            </button>
                          )}
                        </div>
                        <div className="flex items-center justify-between text-[11px] text-amber-900/80 font-mono bg-amber-100/60 p-1.5 rounded-lg border border-amber-200/50">
                          <span>المستحق المحسوب:</span>
                          <span className="font-bold font-mono text-amber-950">
                            {activeEmployee.wageType === 'monthly'
                              ? formatCurrency(activeEmployee.monthlySalary || 0, activeEmployee.dailyWageCurrency || currency)
                              : formatCurrency(
                                  getEmployeeTotalDays(activeEmployee, sharedRole === 'owner') * (activeEmployee.dailyWage || 0),
                                  activeEmployee.dailyWageCurrency || currency
                                )}
                          </span>
                        </div>
                        <p className="text-[10px] text-amber-800/90 leading-relaxed">
                          تم حذف العملية المالية سابقاً. ستظهر العملية تلقائياً بمجرد إجرائك أي تعديل في الأجر/الراتب أو فترة العمل، أو بالنقر على زر إعادة الإدراج أعلاه.
                        </p>
                      </div>
                    );
                  }

                  return (
                    <div className="p-3 bg-indigo-50/70 rounded-xl border border-indigo-100 space-y-1.5">
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] font-bold text-indigo-950 flex items-center gap-1">
                          <Receipt size={13} className="text-indigo-600" />
                          <span>العملية المالية التلقائية بالكشف:</span>
                        </span>
                        <button
                          type="button"
                          onClick={handleScrollToWageEntry}
                          className="text-[10px] text-indigo-700 hover:text-indigo-900 font-bold underline flex items-center gap-0.5 cursor-pointer"
                          title="الانتقال إلى العملية في جدول كشف الحساب وإبرازها"
                        >
                          <ExternalLink size={11} />
                          <span>عرض بالكشف</span>
                        </button>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] text-indigo-800 font-mono">
                          {activeEmployee.wageType === 'monthly'
                            ? 'مستحق الراتب الشهري'
                            : `${getEmployeeTotalDays(activeEmployee, sharedRole === 'owner')} يوم × ${formatCurrency(activeEmployee.dailyWage || 0, activeEmployee.dailyWageCurrency || currency)}`}
                        </span>
                        <span className="font-mono font-black text-emerald-700 text-xs bg-white px-2 py-0.5 rounded-md border border-indigo-200/60 shadow-2xs">
                          له: {activeEmployee.wageType === 'monthly'
                            ? formatCurrency(activeEmployee.monthlySalary || 0, activeEmployee.dailyWageCurrency || currency)
                            : formatCurrency(
                                getEmployeeTotalDays(activeEmployee, sharedRole === 'owner') * (activeEmployee.dailyWage || 0),
                                activeEmployee.dailyWageCurrency || currency
                              )}
                        </span>
                      </div>
                      <div className="text-[10px] text-indigo-700/80 flex items-center gap-1 pt-1 border-t border-indigo-100/70">
                        <Sparkles size={11} className="text-indigo-600 shrink-0" />
                        <span>مربوطة تلقائياً: أي تعديل بالأجر أو أيام العمل يتحدث هنا وبالكشف فوراً.</span>
                      </div>
                    </div>
                  );
                })()}

                {/* Work Periods List & Add Extra Period Inline Form */}
                <div className="pt-3 border-t border-slate-100 text-right">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-700">فترات العمل المسجلة:</span>
                    {sharedRole !== 'read' && (
                      <button
                        type="button"
                        onClick={() => {
                          setShowExtraForm(!showExtraForm);
                          setExtraFormError('');
                        }}
                        className="text-[11px] bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 px-2.5 py-1 rounded-lg font-bold flex items-center gap-1 cursor-pointer transition-colors shadow-2xs"
                      >
                        <PlusCircle size={12} />
                        إضافة فترة عمل إضافية
                      </button>
                    )}
                  </div>

                  {/* List of Periods */}
                  <div className="space-y-1.5 mt-2 max-h-56 overflow-y-auto">
                    {/* Main Period */}
                    <div className="flex items-center justify-between bg-slate-50 p-2 rounded-lg text-[11px] text-slate-600 font-medium border border-slate-200/50">
                      <div className="flex items-center gap-1.5 min-w-0">
                        <span className="w-1.5 h-1.5 rounded-full bg-sky-500 shrink-0"></span>
                        <span className="truncate">الأساسية: {formatDateArabic(activeEmployee.startDate)} إلى {activeEmployee.endDate ? formatDateArabic(activeEmployee.endDate) : 'الآن'}</span>
                      </div>
                      <div className="flex items-center gap-1.5 shrink-0 font-mono">
                        <span className="bg-slate-200/70 px-1.5 py-0.5 rounded text-slate-800 font-bold">{calculateDaysOfWork(activeEmployee.startDate, activeEmployee.endDate, sharedRole === 'owner')} يوم</span>
                        {sharedRole !== 'read' && onUpdateEmployee && (
                          <button
                            type="button"
                            onClick={() => setShowQuickBasicPeriodModal(true)}
                            className="p-1 text-slate-400 hover:text-sky-600 hover:bg-sky-50 rounded-md transition-colors cursor-pointer"
                            title="تعديل فترة العمل الأساسية"
                          >
                            <Pencil size={12} />
                          </button>
                        )}
                      </div>
                    </div>

                    {/* Extra Periods */}
                    {(activeEmployee.extraPeriods || []).map((p, idx) => {
                      const pDays = calculateDaysOfWork(p.startDate, p.endDate, sharedRole === 'owner');
                      const isEditing = editingExtraPeriodId === p.id;

                      if (isEditing) {
                        return (
                          <div key={p.id} className="p-2.5 bg-indigo-50/70 border border-indigo-200 rounded-xl space-y-2 text-right animate-fade-in">
                            <div className="flex items-center justify-between text-[11px] font-bold text-indigo-900">
                              <span>تعديل الفترة الإضافية {idx + 1}</span>
                              <span className="text-[10px] text-indigo-600">ينعكس فوراً على الكشف</span>
                            </div>
                            <div className="grid grid-cols-2 gap-2">
                              <div>
                                <label className="text-[10px] font-bold text-slate-500 block mb-0.5">تاريخ البدء</label>
                                <input
                                  type="date"
                                  value={editExtraStart}
                                  onChange={(e) => setEditExtraStart(e.target.value)}
                                  className="w-full p-1 bg-white border border-slate-200 rounded text-[11px]"
                                  required
                                />
                              </div>
                              <div>
                                <label className="text-[10px] font-bold text-slate-500 block mb-0.5">تاريخ الانتهاء</label>
                                <input
                                  type="date"
                                  value={editExtraEnd}
                                  onChange={(e) => setEditExtraEnd(e.target.value)}
                                  className="w-full p-1 bg-white border border-slate-200 rounded text-[11px]"
                                />
                              </div>
                            </div>
                            {editExtraError && <p className="text-[10px] text-rose-500">{editExtraError}</p>}
                            <div className="flex justify-end gap-1.5 pt-1">
                              <button
                                type="button"
                                onClick={() => {
                                  setEditingExtraPeriodId(null);
                                  setEditExtraStart('');
                                  setEditExtraEnd('');
                                  setEditExtraError('');
                                }}
                                className="px-2 py-0.5 text-[10px] text-slate-600 hover:bg-slate-200 bg-white rounded border border-slate-200 cursor-pointer"
                              >
                                إلغاء
                              </button>
                              <button
                                type="button"
                                onClick={() => handleSaveExtraPeriodEdit(p.id)}
                                className="px-2.5 py-0.5 text-[10px] font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded cursor-pointer"
                              >
                                حفظ التعديل
                              </button>
                            </div>
                          </div>
                        );
                      }

                      return (
                        <div key={p.id} className="flex items-center justify-between bg-sky-50/50 p-2 rounded-lg text-[11px] text-slate-600 font-medium border border-sky-100/30">
                          <div className="flex items-center gap-1.5 min-w-0">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 shrink-0"></span>
                            <span className="truncate">فترة {idx + 1}: {formatDateArabic(p.startDate)} إلى {p.endDate ? formatDateArabic(p.endDate) : 'الآن'}</span>
                          </div>
                          <div className="flex items-center gap-1.5 font-mono shrink-0">
                            <span className="bg-sky-100/60 text-sky-800 px-1.5 py-0.5 rounded font-bold">{pDays} يوم</span>
                            {sharedRole !== 'read' && onUpdateEmployeeExtraPeriod && (
                              <button
                                type="button"
                                onClick={() => handleStartEditExtraPeriod(p)}
                                className="p-1 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-md transition-colors cursor-pointer"
                                title="تعديل هذه الفترة الإضافية"
                              >
                                <Pencil size={12} />
                              </button>
                            )}
                            {sharedRole !== 'read' && sharedRole !== 'add' && (
                              <button
                                type="button"
                                onClick={() => onDeleteEmployeeExtraPeriod?.(activeEmployee.id, p.id)}
                                className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-md transition-colors cursor-pointer"
                                title="حذف هذه الفترة"
                              >
                                <Trash2 size={12} />
                              </button>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  {/* Extra Period Form */}
                  {showExtraForm && (
                    <form onSubmit={handleAddExtraPeriodSubmit} className="mt-3 p-3 bg-slate-50 border border-slate-200/60 rounded-xl space-y-2.5 animate-fade-in text-right">
                      <div className="grid grid-cols-2 gap-2">
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold text-slate-500 block">تاريخ البدء</label>
                          <input
                            type="date"
                            value={extraStart}
                            onChange={(e) => setExtraStart(e.target.value)}
                            className="w-full p-1.5 bg-white border border-slate-200 rounded-lg text-xs text-slate-700"
                            required
                          />
                        </div>
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold text-slate-500 block">تاريخ الانتهاء</label>
                          <input
                            type="date"
                            value={extraEnd}
                            onChange={(e) => setExtraEnd(e.target.value)}
                            className="w-full p-1.5 bg-white border border-slate-200 rounded-lg text-xs text-slate-700"
                          />
                        </div>
                      </div>
                      {extraFormError && <p className="text-[10px] text-rose-500">{extraFormError}</p>}
                      <div className="flex justify-end gap-1.5 pt-1">
                        <button
                          type="button"
                          onClick={() => { setShowExtraForm(false); setExtraStart(''); setExtraEnd(''); setExtraFormError(''); }}
                          className="px-2.5 py-1 text-[10px] font-bold text-slate-500 hover:bg-slate-200/50 rounded-lg border border-slate-200 bg-white flex items-center gap-1 cursor-pointer"
                        >
                          <RotateCcw size={11} />
                          <span>إلغاء / تنظيف</span>
                        </button>
                        <button
                          type="submit"
                          className="px-2.5 py-1 text-[10px] font-bold text-white bg-sky-600 hover:bg-sky-700 rounded-lg cursor-pointer"
                        >
                          حفظ الفترة
                        </button>
                      </div>
                    </form>
                  )}
                </div>

                {/* Ledger balances summary grouped by currency */}
                <div className="space-y-3 pt-2 border-t border-slate-50">
                  {['YER', 'SAR', 'USD'].map(cur => {
                    const totalOnHim = activeEmployee.ledger.filter(e => (e.currency || 'YER') === cur).reduce((sum, e) => sum + e.amountOnHim, 0);
                    const totalForHim = activeEmployee.ledger.filter(e => (e.currency || 'YER') === cur).reduce((sum, e) => sum + e.amountForHim, 0);
                    const balance = totalForHim - totalOnHim;
                    
                    if (totalOnHim === 0 && totalForHim === 0) return null;
                    
                    return (
                      <div key={cur} className="bg-slate-50 p-2.5 rounded-xl border border-slate-100 space-y-1.5 font-mono">
                        <div className="flex justify-between items-center text-[11px] font-bold text-slate-700">
                          <span>العملة:</span>
                          <span className="bg-slate-200 text-slate-800 px-1.5 py-0.5 rounded-md text-[10px]">{cur}</span>
                        </div>
                        <div className="flex justify-between text-[10px] text-slate-500">
                          <span>عليه (سلف):</span>
                          <span className="font-semibold text-rose-600">{formatCurrency(totalOnHim, cur)}</span>
                        </div>
                        <div className="flex justify-between text-[10px] text-slate-500">
                          <span>له (أجور):</span>
                          <span className="font-semibold text-emerald-600">{formatCurrency(totalForHim, cur)}</span>
                        </div>
                        <div className="flex justify-between text-[11px] font-bold border-t border-slate-200/50 pt-1.5 mt-1">
                          <span>صافي الرصيد:</span>
                          <span className={balance < 0 ? 'text-rose-600' : balance > 0 ? 'text-emerald-600' : 'text-slate-400'}>
                            {balance === 0 ? 'خالص' : balance > 0 ? `له: ${formatCurrency(balance, cur)}` : `عليه: ${formatCurrency(Math.abs(balance), cur)}`}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                  {activeEmployee.ledger.length === 0 && (
                    <p className="text-xs text-slate-400 text-center py-2 animate-pulse">لا توجد حركات مالية مسجلة بعد</p>
                  )}
                </div>
              </div>
              
              {/* Nutrition Periods Card (بيانات التغذية) - Collapsible by default */}
              <div className="bg-white p-3.5 sm:p-4 rounded-2xl border border-slate-100 shadow-xs transition-all duration-300 space-y-3">
                <button
                  type="button"
                  onClick={() => setShowNutritionSection(!showNutritionSection)}
                  className="w-full flex items-center justify-between text-right font-bold text-slate-800 text-sm hover:text-emerald-700 transition-colors cursor-pointer select-none"
                >
                  <div className="flex items-center gap-2.5">
                    <div className="p-1.5 bg-emerald-50 text-emerald-600 rounded-lg shrink-0">
                      <Utensils size={16} />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="font-bold text-slate-800 text-sm">بيانات التغذية</h3>
                        {activeEmployee.nutritionPeriods && activeEmployee.nutritionPeriods.length > 0 && (
                          <span className="text-[10px] bg-emerald-100 text-emerald-800 font-extrabold px-2 py-0.5 rounded-full">
                            {activeEmployee.nutritionPeriods.length} فترات
                          </span>
                        )}
                      </div>
                      <p className="text-[10px] text-slate-400 font-normal">خاصة ببيانات وأسعار التغذية للموظفين والمساعدين</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5 text-xs font-bold text-slate-600 bg-slate-100 hover:bg-slate-200 px-3 py-1.5 rounded-xl transition-colors shrink-0">
                    <span>{showNutritionSection ? 'طي البيانات' : 'إظهار التغذية'}</span>
                    {showNutritionSection ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
                  </div>
                </button>

                {showNutritionSection && (
                  <div className="space-y-3 pt-2.5 border-t border-slate-100 animate-fade-in">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-semibold text-slate-500">سجل فترات التغذية المسجلة:</span>
                      {sharedRole !== 'read' && (
                        <button
                          type="button"
                          onClick={handleOpenAddNutritionModal}
                          className="text-[11px] bg-emerald-600 hover:bg-emerald-700 text-white px-3 py-1.5 rounded-xl font-bold flex items-center gap-1.5 transition-colors cursor-pointer shadow-xs active:scale-95"
                          title="إضافة فترة تغذية جديدة"
                        >
                          <PlusCircle size={13} />
                          <span>+ فترة جديدة</span>
                        </button>
                      )}
                    </div>

                    {/* Nutrition Periods List */}
                    {(!activeEmployee.nutritionPeriods || activeEmployee.nutritionPeriods.length === 0) ? (
                      <div className="text-center py-4 bg-slate-50/70 rounded-xl border border-dashed border-slate-200 p-3 space-y-1.5">
                        <p className="text-xs text-slate-400">لا توجد فترات تغذية مسجلة لهذا الموظف حالياً</p>
                        {sharedRole !== 'read' && (
                          <button
                            type="button"
                            onClick={handleOpenAddNutritionModal}
                            className="text-xs text-emerald-600 hover:text-emerald-700 font-bold underline inline-block cursor-pointer"
                          >
                            + إضافة التغذية
                          </button>
                        )}
                      </div>
                    ) : (
                      <div className="space-y-2.5 max-h-80 overflow-y-auto pr-0.5">
                        {activeEmployee.nutritionPeriods.map((period) => {
                          const days = calculateNutritionDays(period.startDate, period.endDate);
                          const total = period.dailyAmount * days;
                          const isOpen = !period.endDate;

                          return (
                            <div key={period.id} className="p-3 bg-slate-50 border border-slate-200/80 rounded-xl space-y-2 relative transition-all hover:border-emerald-200">
                              <div className="flex items-center justify-between gap-2">
                                <div className="flex items-center gap-2">
                                  <span className="font-bold text-slate-800 text-xs">{period.workerName}</span>
                                  <span className={`text-[10px] px-2 py-0.5 rounded-full font-extrabold flex items-center gap-1 ${
                                    isOpen 
                                      ? 'bg-emerald-100 text-emerald-800 border border-emerald-200' 
                                      : 'bg-sky-100 text-sky-800 border border-sky-200'
                                  }`}>
                                    {isOpen ? '🟢 مستمرة' : '🔵 مكتملة'}
                                  </span>
                                </div>

                                {sharedRole !== 'read' && (
                                  <div className="flex items-center gap-1">
                                    <button
                                      type="button"
                                      onClick={() => handleOpenEditNutritionModal(period)}
                                      className="p-1 text-slate-400 hover:text-amber-600 hover:bg-amber-50 rounded-lg transition-colors cursor-pointer"
                                      title="تعديل بيانات التغذية"
                                    >
                                      <Pencil size={13} />
                                    </button>
                                    <button
                                      type="button"
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        const confirmText = `هل أنت متأكد من حذف فترة التغذية الخاصة بـ "${period.workerName}"؟`;
                                        if (typeof window === 'undefined' || !window.confirm || window.confirm(confirmText)) {
                                          onDeleteEmployeeNutritionPeriod?.(activeEmployee.id, period.id);
                                        }
                                      }}
                                      className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                                      title="حذف فترة التغذية"
                                    >
                                      <Trash2 size={13} />
                                    </button>
                                  </div>
                                )}
                              </div>

                              <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-600">
                                <div>
                                  <span className="text-slate-400 block text-[10px]">مبلغ التغذية اليومية:</span>
                                  <span className="font-bold text-slate-700">{formatCurrency(period.dailyAmount, currency)}</span>
                                </div>
                                <div>
                                  <span className="text-slate-400 block text-[10px]">عدد أيام التغذية:</span>
                                  <span className="font-bold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-100">{days} يوم</span>
                                </div>
                              </div>

                              <div className="flex items-center justify-between text-[11px] pt-1.5 border-t border-slate-200/60">
                                <span className="text-slate-400 text-[10px]">
                                  {formatDateArabic(period.startDate)} {period.endDate ? `إلى ${formatDateArabic(period.endDate)}` : 'إلى الآن (مستمر)'}
                                </span>
                                <div className="text-left font-mono">
                                  <span className="text-[10px] text-slate-400 block">إجمالي التغذية:</span>
                                  <span className="font-black text-rose-600 text-xs">{formatCurrency(total, currency)}</span>
                                </div>
                              </div>

                              {period.notes && (
                                <p className="text-[10px] text-slate-500 italic bg-white/60 p-1.5 rounded border border-slate-100">
                                  📝 {period.notes}
                                </p>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Add Transaction Form */}
              {sharedRole !== 'read' && (
                <div className="bg-white p-3.5 sm:p-4 rounded-2xl border border-emerald-100 shadow-xs transition-all duration-300">
                  <button
                    type="button"
                    onClick={() => setShowAddLedgerForm(!showAddLedgerForm)}
                    className="w-full bg-gradient-to-r from-emerald-600 via-emerald-600 to-emerald-700 hover:from-emerald-700 hover:to-emerald-800 text-white font-extrabold text-sm sm:text-base p-3.5 rounded-xl shadow-md shadow-emerald-600/20 flex items-center justify-between transition-all cursor-pointer select-none active:scale-[0.99] border border-emerald-500/50 text-right"
                  >
                    <div className="flex items-center gap-2.5">
                      <div className="p-1.5 bg-white/20 rounded-lg text-white shrink-0">
                        <PlusCircle size={18} />
                      </div>
                      <span className="font-extrabold tracking-wide">إضافة حركة مالية جديدة للكشف</span>
                    </div>
                    <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-950 bg-white/90 hover:bg-white px-3 py-1.5 rounded-lg transition-colors shadow-xs shrink-0">
                      <span>{showAddLedgerForm ? 'طي النموذج ▲' : 'فتح النموذج ▼'}</span>
                    </div>
                  </button>

                  {showAddLedgerForm && (
                    <form onSubmit={handleAddLedgerSubmit} className="space-y-3.5 mt-4 pt-3.5 border-t border-slate-100 animate-fade-in">
                      {/* Date */}
                      <div className="space-y-1">
                        <label className="text-[11px] font-bold text-slate-500">التاريخ</label>
                        <input 
                          type="date"
                          value={ledgerDate}
                          onChange={(e) => setLedgerDate(e.target.value)}
                          className="w-full h-[42px] px-3 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 text-xs focus:outline-hidden focus:border-sky-500"
                          required
                        />
                      </div>

                      {/* Amounts row & Currency selector */}
                      <div className="grid grid-cols-3 gap-2">
                        <div className="space-y-1 col-span-1">
                          <label className="text-[10px] font-bold text-slate-500 block text-rose-600 truncate">مبلغ عليه</label>
                          <div className="flex gap-1 items-center">
                            <input 
                              type="number"
                              placeholder="0"
                              value={ledgerAmountOnHim}
                              onChange={(e) => setLedgerAmountOnHim(e.target.value)}
                              className="w-full h-[42px] px-3 bg-rose-50/20 border border-slate-200 rounded-lg text-slate-700 text-xs focus:outline-hidden focus:border-rose-500 min-w-0"
                            />
                            <Calculator onApply={(val) => setLedgerAmountOnHim(String(val))} buttonTitle="حسابة مبلغ عليه" />
                          </div>
                          <AmountInWords amount={ledgerAmountOnHim} currency={ledgerCurrency} />
                        </div>
                        <div className="space-y-1 col-span-1">
                          <label className="text-[10px] font-bold text-slate-500 block text-emerald-600 truncate">مبلغ له</label>
                          <div className="flex gap-1 items-center">
                            <input 
                              type="number"
                              placeholder="0"
                              value={ledgerAmountForHim}
                              onChange={(e) => setLedgerAmountForHim(e.target.value)}
                              className="w-full h-[42px] px-3 bg-emerald-50/20 border border-slate-200 rounded-lg text-slate-700 text-xs focus:outline-hidden focus:border-emerald-500 min-w-0"
                            />
                            <Calculator onApply={(val) => setLedgerAmountForHim(String(val))} buttonTitle="حسابة مبلغ له" />
                          </div>
                          <AmountInWords amount={ledgerAmountForHim} currency={ledgerCurrency} />
                        </div>
                        <div className="space-y-1 col-span-1">
                          <label className="text-[10px] font-bold text-slate-500 block truncate">العملة</label>
                          <select
                            value={ledgerCurrency}
                            onChange={(e) => setLedgerCurrency(e.target.value)}
                            className="w-full h-[42px] px-3 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 text-xs focus:outline-hidden focus:border-sky-500 cursor-pointer"
                          >
                            <option value="YER">YER</option>
                            <option value="SAR">SAR</option>
                            <option value="USD">USD</option>
                          </select>
                        </div>
                      </div>

                      {/* Statement */}
                      <div className="space-y-1">
                        <label className="text-[11px] font-bold text-slate-500">البيان (نوع الحركة)</label>
                        <input 
                          type="text"
                          placeholder="مثال: سلفة أسبوعية / راتب شهر حزيران"
                          value={ledgerDescription}
                          onChange={(e) => setLedgerDescription(e.target.value)}
                          className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 text-xs focus:outline-hidden focus:border-sky-500"
                          required
                        />
                      </div>

                      {/* Notes */}
                      <div className="space-y-1">
                        <label className="text-[11px] font-bold text-slate-500">ملاحظات إضافية</label>
                        <textarea 
                          placeholder="أي ملاحظات حول العملية..."
                          value={ledgerNotes}
                          onChange={(e) => setLedgerNotes(e.target.value)}
                          rows={2}
                          className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 text-xs focus:outline-hidden focus:border-sky-500 resize-none"
                        />
                      </div>

                      {ledgerError && (
                        <p className="text-[11px] text-rose-600 font-semibold bg-rose-50 p-2 rounded-lg">{ledgerError}</p>
                      )}

                      <div className="flex gap-2 pt-1">
                        <button 
                          type="submit"
                          className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs py-2.5 px-4 rounded-xl shadow-md shadow-emerald-600/20 transition-colors flex items-center justify-center gap-1.5 cursor-pointer active:scale-98"
                        >
                          <PlusCircle size={15} />
                          حفظ في كشف الحساب
                        </button>
                        <button 
                          type="button"
                          onClick={handleResetAddLedgerForm}
                          className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold text-xs rounded-lg transition-colors flex items-center justify-center gap-1 cursor-pointer"
                          title="إلغاء وتنظيف الحقول"
                        >
                          <RotateCcw size={13} />
                          <span>إلغاء / تنظيف</span>
                        </button>
                      </div>
                    </form>
                  )}
                </div>
              )}
            </div>

            {/* Right Col: Ledger Transactions Log Table */}
            <div className={`space-y-3 ${sharedRole === 'read' ? 'lg:col-span-3' : 'lg:col-span-2'}`}>
              {/* Ledger Filters Card */}
              <div className="bg-white p-3.5 sm:p-4 rounded-2xl border border-slate-100 shadow-xs transition-all" id="employee-ledger-filters">
                <button
                  type="button"
                  onClick={() => setIsLedgerFiltersOpen(!isLedgerFiltersOpen)}
                  className="w-full flex items-center justify-between text-right font-bold text-slate-700 text-xs sm:text-sm hover:text-slate-900 cursor-pointer select-none"
                >
                  <div className="flex items-center gap-2">
                    <Filter size={16} className="text-indigo-500" />
                    <span>أدوات البحث والتصفية (سجل الكشوفات والحركات التفصيلي)</span>
                    {isLedgerFilterActive && (
                      <span className="text-[10px] font-extrabold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded-full border border-indigo-200">
                        فلتر نشط ({sortedLedger.length} حركات)
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-1.5 text-slate-400 text-xs font-normal">
                    <span className="text-slate-400 text-xs hidden sm:inline">{isLedgerFiltersOpen ? 'إخفاء' : 'عرض الخيارات'}</span>
                    {isLedgerFiltersOpen ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
                  </div>
                </button>
                
                {isLedgerFiltersOpen && (
                  <div className="pt-3 space-y-3 border-t border-slate-100 mt-3 animate-fade-in">
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                      
                      {/* Search text */}
                      <div className="relative col-span-1 sm:col-span-2 lg:col-span-1">
                        <input 
                          type="text"
                          value={ledgerSearchTerm}
                          onChange={(e) => setLedgerSearchTerm(e.target.value)}
                          placeholder="بحث في البيان، الملاحظات..."
                          className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 text-xs pr-8 pl-8 focus:outline-hidden focus:border-indigo-500 transition-colors"
                        />
                        <Search size={14} className="absolute top-1/2 -translate-y-1/2 right-2.5 text-slate-400 pointer-events-none" />
                        {ledgerSearchTerm && (
                          <button
                            type="button"
                            onClick={() => setLedgerSearchTerm('')}
                            className="absolute top-1/2 -translate-y-1/2 left-2 p-1 text-slate-400 hover:text-slate-600 hover:bg-slate-200/70 rounded-full transition-colors cursor-pointer"
                            title="إلغاء البحث ومسح النص"
                          >
                            <X size={13} className="stroke-[2.5]" />
                          </button>
                        )}
                      </div>

                      {/* Start Date */}
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-slate-500 shrink-0">من:</span>
                        <input 
                          type="date"
                          value={ledgerStartDate}
                          onChange={(e) => setLedgerStartDate(e.target.value)}
                          className="w-full h-8 px-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 text-xs focus:outline-hidden focus:border-indigo-500"
                        />
                      </div>

                      {/* End Date */}
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-slate-500 shrink-0">إلى:</span>
                        <input 
                          type="date"
                          value={ledgerEndDate}
                          onChange={(e) => setLedgerEndDate(e.target.value)}
                          className="w-full h-8 px-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 text-xs focus:outline-hidden focus:border-indigo-500"
                        />
                      </div>

                      {/* Sort Order Filter */}
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-slate-500 shrink-0">الترتيب:</span>
                        <select
                          value={ledgerSortOption}
                          onChange={(e) => setLedgerSortOption(e.target.value as any)}
                          className="w-full h-8 px-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 text-xs font-bold focus:outline-hidden focus:border-indigo-500 cursor-pointer"
                        >
                          <option value="date-desc">الأحدث أولاً ⬇️ (افتراضي)</option>
                          <option value="date-asc">الأقدم أولاً ⬆️</option>
                          <option value="desc-alpha">أبجدياً حسب البيان (أ - ي) 🔤</option>
                          <option value="amountOnHim-desc">حسب مبلغ عليه (الأعلى أولاً) 🔴</option>
                          <option value="amountForHim-desc">حسب مبلغ له (الأعلى أولاً) 🟢</option>
                        </select>
                      </div>

                      {/* Transaction Type Filter */}
                      <div className="flex items-center gap-2 sm:col-span-2 lg:col-span-2">
                        <span className="text-xs text-slate-500 shrink-0">نوع الحركة:</span>
                        <select
                          value={ledgerTypeFilter}
                          onChange={(e) => setLedgerTypeFilter(e.target.value as 'all' | 'onHim' | 'forHim')}
                          className="w-full h-8 px-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 text-xs font-bold focus:outline-hidden focus:border-indigo-500 cursor-pointer"
                        >
                          <option value="all">كافة الحركات المالية (له وعليه)</option>
                          <option value="onHim">مبالغ عليه فقط (سلف / مسحوبات)</option>
                          <option value="forHim">مبالغ له فقط (أجور / مستحقات)</option>
                        </select>
                      </div>

                    </div>

                    {/* Clear filters shortcut */}
                    {isLedgerFilterActive && (
                      <div className="flex justify-end pt-1">
                        <button 
                          type="button"
                          onClick={() => {
                            setLedgerSearchTerm('');
                            setLedgerStartDate('');
                            setLedgerEndDate('');
                            setLedgerTypeFilter('all');
                            setLedgerSortOption('date-desc');
                          }}
                          className="text-[11px] text-indigo-600 hover:text-indigo-800 hover:underline font-bold cursor-pointer"
                        >
                          إلغاء التصفية وإعادة الضبط 🔄
                        </button>
                      </div>
                    )}
                  </div>
                )}
              </div>

              <div className="bg-white rounded-2xl border border-slate-100 shadow-xs overflow-hidden">
                <div className="p-4 border-b border-slate-100 bg-slate-50/40 flex items-center justify-between gap-3 flex-wrap">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className="font-bold text-slate-800 text-sm">سجل الكشوفات والحركات التفصيلي للموظف</h3>
                    {hasActiveEmployeeLedgerColumnFilters && (
                      <div className="flex items-center gap-1.5 bg-indigo-50 border border-indigo-200 text-indigo-800 px-2 py-0.5 rounded-lg text-xs font-bold">
                        <Filter size={12} className="fill-current text-indigo-600" />
                        <span>تصفية مخصصة للأعمدة</span>
                        <button
                          type="button"
                          onClick={handleClearEmployeeLedgerFilters}
                          className="text-[10px] text-indigo-600 hover:text-indigo-800 hover:underline mr-1 cursor-pointer font-bold"
                        >
                          إلغاء فلاتر الأعمدة ✕
                        </button>
                      </div>
                    )}
                    <span className="text-[10px] text-slate-400 font-bold bg-slate-100 px-2 py-0.5 rounded-md">
                      عدد العمليات: {sortedLedger.length}
                    </span>
                  </div>

                  <div className="text-slate-700 text-xs font-bold flex flex-wrap items-center gap-2 bg-white px-3 py-1.5 rounded-xl border border-slate-100">
                    <span>إجمالي المصفى:</span>
                    {Object.keys(ledgerTotalsByCurrency).length === 0 ? (
                      <span className="text-slate-400">0</span>
                    ) : (
                      (Object.entries(ledgerTotalsByCurrency) as [string, { onHim: number; forHim: number }][]).map(([cur, totals]) => (
                        <div key={cur} className="flex items-center gap-1.5 font-mono text-xs">
                          {totals.forHim > 0 && (
                            <span className="bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded-lg border border-emerald-100 font-extrabold" title="إجمالي له (أجور ومستحقات)">
                              له: {formatCurrency(totals.forHim, cur)}
                            </span>
                          )}
                          {totals.onHim > 0 && (
                            <span className="bg-rose-50 text-rose-700 px-2 py-0.5 rounded-lg border border-rose-100 font-extrabold" title="إجمالي عليه (سلف ومسحوبات)">
                              عليه: {formatCurrency(totals.onHim, cur)}
                            </span>
                          )}
                          {totals.forHim === 0 && totals.onHim === 0 && (
                            <span className="bg-slate-50 text-slate-500 px-2 py-0.5 rounded-lg border border-slate-100 font-extrabold">
                              0 {cur}
                            </span>
                          )}
                        </div>
                      ))
                    )}
                  </div>
                </div>

                <div className="overflow-x-auto">
                  {sortedLedger.length === 0 ? (
                    <div className="text-center py-12 px-4 space-y-2">
                      <p className="text-slate-400 text-sm font-medium">كشف الحساب فارغ حالياً</p>
                      <p className="text-xs text-slate-300">قم بإضافة حركة مالية جديدة أو تحديد الأجر اليومي للموظف</p>
                    </div>
                  ) : (
                    <table className="w-full text-right text-xs">
                      <thead>
                        <tr className="bg-slate-50 text-slate-500 font-bold border-b border-slate-100">
                          <th className="p-3 whitespace-nowrap">
                            <div className="flex items-center justify-between gap-1">
                              <span>التاريخ</span>
                              <ExcelColumnFilter
                                config={employeeLedgerColumnConfigs.date}
                                data={baseFilteredLedger}
                                allColumnFilters={employeeLedgerColumnFilters}
                                allConfigs={employeeLedgerColumnConfigs}
                                activeFilter={employeeLedgerColumnFilters.date}
                                onFilterChange={handleEmployeeLedgerFilterChange}
                                activeSort={employeeLedgerColumnSort}
                                onSortChange={handleEmployeeLedgerSortChange}
                                accentColor="indigo"
                              />
                            </div>
                          </th>
                          <th className="p-3 min-w-[280px] sm:min-w-[360px] w-2/5">
                            <div className="flex items-center justify-between gap-1">
                              <span>البيان</span>
                              <ExcelColumnFilter
                                config={employeeLedgerColumnConfigs.description}
                                data={baseFilteredLedger}
                                allColumnFilters={employeeLedgerColumnFilters}
                                allConfigs={employeeLedgerColumnConfigs}
                                activeFilter={employeeLedgerColumnFilters.description}
                                onFilterChange={handleEmployeeLedgerFilterChange}
                                activeSort={employeeLedgerColumnSort}
                                onSortChange={handleEmployeeLedgerSortChange}
                                accentColor="indigo"
                              />
                            </div>
                          </th>
                          <th className="p-3 text-rose-600 whitespace-nowrap">
                            <div className="flex items-center justify-between gap-1">
                              <span>عليه (سلفة/دفعة)</span>
                              <ExcelColumnFilter
                                config={employeeLedgerColumnConfigs.amountOnHim}
                                data={baseFilteredLedger}
                                allColumnFilters={employeeLedgerColumnFilters}
                                allConfigs={employeeLedgerColumnConfigs}
                                activeFilter={employeeLedgerColumnFilters.amountOnHim}
                                onFilterChange={handleEmployeeLedgerFilterChange}
                                activeSort={employeeLedgerColumnSort}
                                onSortChange={handleEmployeeLedgerSortChange}
                                accentColor="rose"
                              />
                            </div>
                          </th>
                          <th className="p-3 text-emerald-600 whitespace-nowrap">
                            <div className="flex items-center justify-between gap-1">
                              <span>له (أجور/استحقاق)</span>
                              <ExcelColumnFilter
                                config={employeeLedgerColumnConfigs.amountForHim}
                                data={baseFilteredLedger}
                                allColumnFilters={employeeLedgerColumnFilters}
                                allConfigs={employeeLedgerColumnConfigs}
                                activeFilter={employeeLedgerColumnFilters.amountForHim}
                                onFilterChange={handleEmployeeLedgerFilterChange}
                                activeSort={employeeLedgerColumnSort}
                                onSortChange={handleEmployeeLedgerSortChange}
                                accentColor="emerald"
                              />
                            </div>
                          </th>
                          <th className="p-3">
                            <div className="flex items-center justify-between gap-1">
                              <span>ملاحظات</span>
                              <ExcelColumnFilter
                                config={employeeLedgerColumnConfigs.notes}
                                data={baseFilteredLedger}
                                allColumnFilters={employeeLedgerColumnFilters}
                                allConfigs={employeeLedgerColumnConfigs}
                                activeFilter={employeeLedgerColumnFilters.notes}
                                onFilterChange={handleEmployeeLedgerFilterChange}
                                activeSort={employeeLedgerColumnSort}
                                onSortChange={handleEmployeeLedgerSortChange}
                                accentColor="indigo"
                              />
                            </div>
                          </th>
                          {sharedRole !== 'read' && <th className="p-3 text-center whitespace-nowrap">إجراءات</th>}
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-50">
                        {sortedLedger.map((e) => (
                          <tr 
                            key={e.id} 
                            id={`ledger-row-${e.id}`}
                            className={`transition-all duration-500 ${
                              highlightedEntryId === e.id ? 'ring-4 ring-indigo-500 bg-indigo-100/95 shadow-md scale-[1.005]' : ''
                            } ${e.isAutoMonthlySalary ? 'bg-emerald-50/40 hover:bg-emerald-50/70' : e.isAutoDailyWage ? 'bg-indigo-50/40 hover:bg-indigo-50/70' : 'hover:bg-slate-50/50'}`}
                          >
                            <td className="p-3 whitespace-nowrap text-slate-500">{formatDateArabic(e.date)}</td>
                            <td className="p-3 font-semibold text-slate-800 min-w-[280px] sm:min-w-[360px]">
                              <div className="flex items-center gap-1.5 flex-wrap">
                              <span>{cleanLedgerDescription(e.description)}</span>
                              {e.isAutoDailyWage && (
                                <span className="text-[10px] bg-indigo-100 text-indigo-800 font-extrabold px-2 py-0.5 rounded-md border border-indigo-200 flex items-center gap-1 shadow-2xs">
                                  <Link2 size={11} className="text-indigo-600 shrink-0" />
                                  <span>مرتبطة تلقائياً بالأجر وأيام العمل ⚙️</span>
                                </span>
                              )}
                              {e.isAutoMonthlySalary && (
                                <span className="text-[10px] bg-emerald-100 text-emerald-800 font-extrabold px-2 py-0.5 rounded-md border border-emerald-200 flex items-center gap-1 shadow-2xs">
                                  <Link2 size={11} className="text-emerald-600 shrink-0" />
                                  <span>مرتبطة تلقائياً بالراتب الشهري 📅</span>
                                </span>
                              )}
                              {e.isNutrition && (
                                <span className="text-[9px] bg-emerald-50 text-emerald-700 border border-emerald-200 font-bold px-1.5 py-0.5 rounded-sm flex items-center gap-0.5">
                                  <Utensils size={10} />
                                  <span>تغذية مرحلة تلقائياً</span>
                                </span>
                              )}
                              {e.isPosted && (
                                <span className="text-[9px] bg-rose-50 text-rose-700 border border-rose-100 font-bold px-1.5 py-0.5 rounded-sm">
                                  مرحلة تلقائياً من النفقات اليومية
                                </span>
                              )}
                              </div>
                            </td>
                            <td className="p-3 font-bold text-rose-600 font-mono">
                              {e.amountOnHim > 0 ? formatCurrency(e.amountOnHim, e.currency || currency) : '-'}
                            </td>
                            <td className="p-3 font-bold text-emerald-600 font-mono">
                              {e.amountForHim > 0 ? formatCurrency(e.amountForHim, e.currency || currency) : '-'}
                            </td>
                            <td className="p-3 text-slate-400 max-w-[150px] truncate">{e.notes || '-'}</td>
                            {sharedRole !== 'read' && (
                              <td className="p-3 text-center">
                                <div className="flex items-center justify-center gap-1">
                                  <button 
                                    onClick={() => {
                                      setCopyMoveModalState({
                                        isOpen: true,
                                        mode: 'copy',
                                        entry: e,
                                        employeeId: activeEmployee.id,
                                        employeeName: activeEmployee.name
                                      });
                                    }}
                                    className="p-1 text-slate-400 hover:text-emerald-600 hover:bg-emerald-50 rounded-md transition-colors cursor-pointer"
                                    title="نسخ الحركة المالية إلى حساب آخر"
                                  >
                                    <Copy size={14} />
                                  </button>
                                  <button 
                                    onClick={() => {
                                      setCopyMoveModalState({
                                        isOpen: true,
                                        mode: 'move',
                                        entry: e,
                                        employeeId: activeEmployee.id,
                                        employeeName: activeEmployee.name
                                      });
                                    }}
                                    className="p-1 text-slate-400 hover:text-amber-600 hover:bg-amber-50 rounded-md transition-colors cursor-pointer"
                                    title="نقل الحركة المالية إلى حساب آخر"
                                  >
                                    <ArrowRightLeft size={14} />
                                  </button>
                                  {onUpdateEmployeeLedgerEntry && (
                                    <button 
                                      onClick={() => setEditingEmployeeLedger({ employeeId: activeEmployee.id, entry: e })}
                                      className="p-1 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-md transition-colors cursor-pointer"
                                      title="تعديل الحركة المالية"
                                    >
                                      <Pencil size={14} />
                                    </button>
                                  )}
                                  {sharedRole !== 'add' && onDeleteEmployeeLedgerEntry && (
                                    <button 
                                      onClick={() => {
                                        if (confirm(`هل أنت متأكد من حذف الحركة المالية (${e.description}) من كشف حساب الموظف؟`)) {
                                          onDeleteEmployeeLedgerEntry(activeEmployee.id, e.id, true);
                                        }
                                      }}
                                      className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-md transition-colors cursor-pointer"
                                      title="حذف الحركة المالية"
                                    >
                                      <Trash2 size={14} />
                                    </button>
                                  )}
                                </div>
                              </td>
                            )}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  )}
                </div>
              </div>
            </div>

          </div>

        </div>
      ) : (
        /* List View of All Employees */
        <div className="space-y-3 sm:space-y-5">
          
          {/* Main Header Card */}
          <PageHeaderCard
            title="سجل الموظفين والمهندسين والإداريين"
            description="إدارة الكادر الفني والإداري والمهندسين وتتبع أجورهم وسلفهم ومستحقاتهم بدقة."
            icon={<Briefcase size={20} />}
            onBack={setActiveTab ? () => setActiveTab('dashboard') : undefined}
            optionsMenu={
              <OptionsMenu 
                onExportExcel={handleExportAllEmployeesExcel}
                onExportPDF={handlePrintAllEmployeesPDF}
                onImportExcel={sharedRole !== 'read' ? handleAllEmployeesExcelImport : undefined}
                shareTitle="كشوفات حسابات الموظفين - التقرير الشامل"
                shareText={(() => {
                  const currencyTotals: Record<string, { wages: number; advances: number }> = {};
                  employees.forEach(emp => {
                    const balances = getEmployeeBalancesByCurrency(emp, currency);
                    balances.forEach(b => {
                      if (!currencyTotals[b.currency]) {
                        currencyTotals[b.currency] = { wages: 0, advances: 0 };
                      }
                      currencyTotals[b.currency].wages += b.forHim;
                      currencyTotals[b.currency].advances += b.onHim;
                    });
                  });

                  const currencyKeys = Object.keys(currencyTotals);
                  const currenciesSummary = currencyKeys.length === 0 
                    ? `• عملة ${currency}: لا توجد حركات مسجلة`
                    : currencyKeys.map(c => {
                        const w = currencyTotals[c].wages;
                        const a = currencyTotals[c].advances;
                        const net = w - a;
                        const status = net === 0 ? 'متوازن' : net > 0 ? `صافي مستحقات للموظفين: ${formatCurrency(net, c)}` : `صافي سلف على الموظفين: ${formatCurrency(Math.abs(net), c)}`;
                        return `• عملة ${c}:\n  - إجمالي الاستحقاقات (له): ${formatCurrency(w, c)}\n  - إجمالي السلف/المدفوعات (عليه): ${formatCurrency(a, c)}\n  - الصافي: ${status}`;
                      }).join('\n\n');

                  return `📋 ملخص كشوفات حسابات الموظفين:\n👥 إجمالي عدد الموظفين: ${employees.length} موظف\n\n${currenciesSummary}\n\n*تم استخراجه ومشاركته من كشوفات المقاولات*`;
                })()}
              />
            }
          />

          {/* Main Content Grid: Left = Add Employee Form, Right = Employees Cards Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-2.5 sm:gap-4 items-start">
            
            {/* Column 1: Add Employee Form */}
            {sharedRole !== 'read' && (
              <div className="bg-white p-2.5 sm:p-3.5 rounded-xl sm:rounded-2xl border border-slate-100 shadow-xs space-y-2">
                <button
                  type="button"
                  onClick={() => setShowAddEmployeeForm(!showAddEmployeeForm)}
                  className="w-full bg-gradient-to-r from-emerald-600 via-emerald-600 to-emerald-700 hover:from-emerald-700 hover:to-emerald-800 text-white font-extrabold text-xs sm:text-sm py-2 px-2.5 sm:py-2.5 sm:px-3.5 rounded-lg sm:rounded-xl shadow-xs flex items-center justify-between transition-all cursor-pointer select-none border border-emerald-500/50"
                >
                  <div className="flex items-center gap-2">
                    <div className="p-1 bg-white/20 rounded-md text-white shrink-0">
                      <UserPlus size={15} />
                    </div>
                    <span className="font-extrabold tracking-wide">تسجيل موظف جديد</span>
                  </div>
                  <span className="text-[10px] sm:text-xs px-2 py-0.5 sm:px-2.5 sm:py-1 rounded-md font-bold flex items-center gap-1 transition-all bg-white/90 text-emerald-950 shadow-xs">
                    {showAddEmployeeForm ? 'إخفاء البيانات ▲' : '+ تسجيل موظف جديد ▼'}
                  </span>
                </button>

                {showAddEmployeeForm && (
                  <div className="pt-2.5 border-t border-slate-100 animate-slide-up space-y-2.5">
                    {employeeError && (
                      <p className="text-xs font-bold text-rose-600 bg-rose-50 p-2.5 rounded-xl border border-rose-100">
                        {employeeError}
                      </p>
                    )}

                    <form onSubmit={handleAddEmployeeSubmit} className="space-y-4">
                      <div className="space-y-1">
                        <label className="text-xs font-bold text-slate-600 block">اسم الموظف الثلاثي</label>
                        <input 
                          type="text"
                          value={newEmployeeName}
                          onChange={(e) => setNewEmployeeName(e.target.value)}
                          placeholder="مثال: محمد علي حسن"
                          className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-xs focus:outline-hidden focus:border-indigo-500"
                          required
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="text-xs font-bold text-slate-600 block">المسمى الوظيفي / القسم</label>
                        <input 
                          type="text"
                          value={newEmployeeProfession}
                          onChange={(e) => setNewEmployeeProfession(e.target.value)}
                          placeholder="مثال: مهندس موقع، مشرف، محاسب..."
                          className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-xs focus:outline-hidden focus:border-indigo-500"
                          required
                        />
                      </div>

                      <PhoneNumbersInput 
                        phoneNumbers={newEmployeePhoneNumbers} 
                        onChange={setNewEmployeePhoneNumbers} 
                      />

                      {/* Wage Type Selector: Daily Wage vs Monthly Salary */}
                      <div className="space-y-1.5">
                        <label className="text-xs font-bold text-slate-700 block">نظام المستحقات المالية</label>
                        <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100/90 rounded-2xl border border-slate-200/80">
                          <button
                            type="button"
                            onClick={() => setNewEmployeeWageType('daily')}
                            className={`py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                              newEmployeeWageType === 'daily'
                                ? 'bg-white text-indigo-700 shadow-xs border border-indigo-100'
                                : 'text-slate-500 hover:text-slate-800'
                            }`}
                          >
                            <Clock size={14} />
                            <span>الأجر اليومي</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => setNewEmployeeWageType('monthly')}
                            className={`py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                              newEmployeeWageType === 'monthly'
                                ? 'bg-white text-emerald-700 shadow-xs border border-emerald-100'
                                : 'text-slate-500 hover:text-slate-800'
                            }`}
                          >
                            <Calendar size={14} />
                            <span>الراتب الشهري</span>
                          </button>
                        </div>
                      </div>

                      {newEmployeeWageType === 'daily' ? (
                        <div className="space-y-1">
                          <label className="text-xs font-bold text-indigo-700 block">الأجر اليومي (اختياري)</label>
                          <div className="flex gap-2">
                            <input 
                              type="number"
                              step="any"
                              value={newEmployeeDailyWage}
                              onChange={(e) => setNewEmployeeDailyWage(e.target.value)}
                              placeholder="مثال: 5000 (سيتم احتساب مجموع الأجور تلقائياً)"
                              className="flex-1 p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 text-xs font-bold focus:outline-hidden focus:border-indigo-500"
                            />
                            <select
                              value={newEmployeeDailyWageCurrency}
                              onChange={(e) => setNewEmployeeDailyWageCurrency(e.target.value)}
                              className="w-24 p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-xs font-bold focus:outline-hidden focus:border-indigo-500 cursor-pointer shrink-0"
                            >
                              <option value="YER">YER</option>
                              <option value="SAR">SAR</option>
                              <option value="USD">USD</option>
                            </select>
                          </div>
                          <AmountInWords amount={newEmployeeDailyWage} currency={newEmployeeDailyWageCurrency} />
                        </div>
                      ) : (
                        <div className="space-y-1">
                          <label className="text-xs font-bold text-emerald-700 block">مبلغ الراتب الشهري (المعتمد)</label>
                          <div className="flex gap-2">
                            <input 
                              type="number"
                              step="any"
                              value={newEmployeeMonthlySalary}
                              onChange={(e) => setNewEmployeeMonthlySalary(e.target.value)}
                              placeholder="مثال: 150000 (يقسم على أيام الشهر ويضرب بأيام العمل)"
                              className="flex-1 p-2.5 bg-emerald-50/40 border border-emerald-200 rounded-xl text-emerald-900 text-xs font-bold focus:outline-hidden focus:border-emerald-500"
                            />
                            <select
                              value={newEmployeeDailyWageCurrency}
                              onChange={(e) => setNewEmployeeDailyWageCurrency(e.target.value)}
                              className="w-24 p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-xs font-bold focus:outline-hidden focus:border-emerald-500 cursor-pointer shrink-0"
                            >
                              <option value="YER">YER</option>
                              <option value="SAR">SAR</option>
                              <option value="USD">USD</option>
                            </select>
                          </div>
                          <AmountInWords amount={newEmployeeMonthlySalary} currency={newEmployeeDailyWageCurrency} />
                          <p className="text-[11px] text-emerald-700/80 font-medium">
                            💡 يقسم الراتب على أيام كل شهر ويضرب بعدد أيام العمل الفعلية لكل شهر على حدة.
                          </p>
                        </div>
                      )}

                      <div className="grid grid-cols-2 gap-3">
                        <div className="space-y-1">
                          <label className="text-xs font-bold text-slate-600 block">تاريخ البدء</label>
                          <input 
                            type="date"
                            value={newEmployeeStartDate}
                            onChange={(e) => setNewEmployeeStartDate(e.target.value)}
                            className="w-full h-[42px] px-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-xs focus:outline-hidden focus:border-indigo-500"
                            required
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-xs font-bold text-slate-600 block">تاريخ الانتهاء (اختياري)</label>
                          <input 
                            type="date"
                            value={newEmployeeEndDate}
                            onChange={(e) => setNewEmployeeEndDate(e.target.value)}
                            className="w-full h-[42px] px-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-xs focus:outline-hidden focus:border-indigo-500"
                          />
                        </div>
                      </div>

                      {/* Notes */}
                      <div className="space-y-1">
                        <label className="text-xs font-bold text-slate-600 block">ملاحظات (اختياري)</label>
                        <textarea 
                          value={newEmployeeNotes}
                          onChange={(e) => setNewEmployeeNotes(e.target.value)}
                          placeholder="أي ملاحظات تفصيلية حول الموظف..."
                          rows={2}
                          className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-xs focus:outline-hidden focus:border-indigo-500 resize-none"
                        />
                      </div>

                      {newEmployeeStartDate && newEmployeeWageType === 'daily' && (
                        <div className="p-3 bg-indigo-50 border border-indigo-100 rounded-xl space-y-1 text-xs text-slate-600">
                          <div className="flex justify-between items-center font-semibold">
                            <span>أيام العمل المحتسبة:</span>
                            <span className="font-bold text-indigo-700 text-sm">
                              {calculateDaysOfWork(newEmployeeStartDate, newEmployeeEndDate, sharedRole === 'owner')} يوم
                            </span>
                          </div>
                          {Number(newEmployeeDailyWage) > 0 && (
                            <div className="flex justify-between items-center text-emerald-700 font-extrabold pt-1 border-t border-indigo-100">
                              <span>إجمالي الأجر التلقائي:</span>
                              <span>{formatCurrency(calculateDaysOfWork(newEmployeeStartDate, newEmployeeEndDate, sharedRole === 'owner') * Number(newEmployeeDailyWage), newEmployeeDailyWageCurrency)}</span>
                            </div>
                          )}
                        </div>
                      )}

                      {newEmployeeStartDate && newEmployeeWageType === 'monthly' && Number(newEmployeeMonthlySalary) > 0 && (
                        <div className="p-3 bg-emerald-50/80 border border-emerald-200 rounded-xl space-y-2 text-xs">
                          <div className="flex justify-between items-center font-bold text-emerald-900">
                            <span>معاينة احتساب الرواتب المستحقة حسب الأشهر:</span>
                          </div>
                          {(() => {
                            const tempEmp: Employee = {
                              id: 'temp',
                              name: newEmployeeName || 'موظف',
                              profession: newEmployeeProfession || '',
                              startDate: newEmployeeStartDate,
                              endDate: newEmployeeEndDate,
                              wageType: 'monthly',
                              dailyWage: 0,
                              monthlySalary: Number(newEmployeeMonthlySalary),
                              dailyWageCurrency: newEmployeeDailyWageCurrency,
                              ledger: []
                            };
                            const breakdowns = calculateEmployeeMonthlySalaries(tempEmp, sharedRole === 'owner');
                            const totalSalaryDue = breakdowns.reduce((acc, curr) => acc + curr.amountDue, 0);
                            return (
                              <div className="space-y-1.5 pt-1 border-t border-emerald-200">
                                {breakdowns.map(b => (
                                  <div key={b.monthKey} className="bg-white/90 p-2 rounded-lg border border-emerald-100 flex items-center justify-between">
                                    <div>
                                      <span className="font-bold text-emerald-900 block">{b.monthName} {b.year} ({b.workedDaysInMonth} / {b.totalDaysInMonth} يوم)</span>
                                      <span className="text-[10px] text-slate-500">من {formatDateArabic(b.startDateInMonth)} إلى {formatDateArabic(b.endDateInMonth)}</span>
                                    </div>
                                    <div className="text-left font-mono font-bold text-emerald-700">
                                      {formatCurrency(b.amountDue, newEmployeeDailyWageCurrency)}
                                    </div>
                                  </div>
                                ))}
                                <div className="flex justify-between items-center font-extrabold text-emerald-900 pt-1 border-t border-emerald-200">
                                  <span>إجمالي الرواتب المستحقة:</span>
                                  <span className="font-mono text-sm">{formatCurrency(totalSalaryDue, newEmployeeDailyWageCurrency)}</span>
                                </div>
                              </div>
                            );
                          })()}
                        </div>
                      )}

                      <div className="flex gap-2">
                        <button 
                          type="submit"
                          className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs sm:text-sm py-3 px-4 rounded-xl shadow-md shadow-emerald-600/20 transition-colors cursor-pointer flex items-center justify-center gap-2 active:scale-98"
                        >
                          <PlusCircle size={16} />
                          حفظ الموظف الجديد
                        </button>
                        <button 
                          type="button"
                          onClick={handleResetAddEmployeeForm}
                          className="px-4 py-3 bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold text-xs rounded-xl transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                          title="إلغاء وتنظيف الحقول"
                        >
                          <RotateCcw size={15} />
                          <span>إلغاء / تنظيف</span>
                        </button>
                      </div>
                    </form>
                  </div>
                )}
              </div>
            )}

            {/* Column 2 & 3: Employees list cards */}
            <div className={sharedRole === 'read' ? 'lg:col-span-3 space-y-2.5 sm:space-y-4' : 'lg:col-span-2 space-y-2.5 sm:space-y-4'}>
              
              {/* Search Card & Sort Filter */}
              <div className="bg-white p-2.5 sm:p-4 rounded-xl sm:rounded-2xl border border-slate-100 shadow-xs flex flex-col sm:flex-row items-center gap-2 sm:gap-3">
                <div className="relative flex-1 w-full">
                  <input 
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="ابحث عن موظف بالاسم أو المسمى الوظيفي..."
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-xs pr-8 pl-8 focus:outline-hidden focus:border-indigo-500 transition-colors"
                  />
                  <Search size={14} className="absolute top-1/2 -translate-y-1/2 right-2.5 text-slate-400 pointer-events-none" />
                  {searchQuery && (
                    <button
                      type="button"
                      onClick={() => setSearchQuery('')}
                      className="absolute top-1/2 -translate-y-1/2 left-2 p-1 text-slate-400 hover:text-slate-600 hover:bg-slate-200/70 rounded-full transition-colors cursor-pointer"
                      title="إلغاء البحث ومسح النص"
                    >
                      <X size={13} className="stroke-[2.5]" />
                    </button>
                  )}
                </div>
                
                {/* Employees Sort Filter */}
                <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-xs shrink-0 w-full sm:w-auto">
                  <span className="text-slate-400 font-medium">الترتيب:</span>
                  <select
                    value={employeeSortOrder}
                    onChange={(e) => setEmployeeSortOrder(e.target.value as 'asc' | 'desc')}
                    className="bg-transparent text-slate-700 font-bold focus:outline-none cursor-pointer text-xs"
                  >
                    <option value="desc">تاريخ البدء: الأحدث أولاً ⬇️ (افتراضي)</option>
                    <option value="asc">تاريخ البدء: الأقدم أولاً ⬆️</option>
                  </select>
                </div>
              </div>

              {/* Employees Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5 sm:gap-3.5">
                {sortedEmployees.length === 0 ? (
                  <div className="bg-white p-12 text-center rounded-2xl border border-slate-100 shadow-xs md:col-span-2">
                    <p className="text-slate-400 text-sm font-medium">لا يوجد موظفون يطابقون البحث</p>
                    <p className="text-xs text-slate-300 mt-1">أدخل موظفين جدداً للبدء في التتبع</p>
                  </div>
                ) : (
                  sortedEmployees.map(emp => {
                    const days = getEmployeeTotalDays(emp, sharedRole === 'owner');
                    const balances = getEmployeeBalancesByCurrency(emp, currency);
                    
                    return (
                      <div 
                        key={emp.id}
                        className="bg-white p-3 sm:p-4 rounded-xl sm:rounded-2xl border border-slate-100 shadow-xs hover:border-indigo-200 transition-all group flex flex-col justify-between"
                      >
                        <div className="space-y-1.5 sm:space-y-2">
                          
                          {/* Header: Name & Profession */}
                          <div className="flex items-start justify-between gap-2 border-b border-slate-100 pb-1.5 sm:pb-2">
                            <div className="space-y-0.5">
                              <h3 className="font-bold text-slate-800 text-xs sm:text-sm group-hover:text-indigo-600 transition-colors flex items-center gap-1.5 flex-wrap">
                                <User size={14} className="text-indigo-500 shrink-0" />
                                <span>{emp.name}</span>
                                {(() => {
                                  const status = getPersonWorkStatus(emp.endDate);
                                  return (
                                    <span className={`text-[9px] sm:text-[10px] px-1.5 py-0.2 sm:px-2 sm:py-0.5 rounded-full font-bold border ${status.badgeClass} inline-flex items-center gap-1 shrink-0`}>
                                      <span className={`w-1.5 h-1.5 rounded-full ${status.isStopped ? 'bg-rose-500' : 'bg-emerald-500'}`}></span>
                                      {status.statusText}
                                    </span>
                                  );
                                })()}
                              </h3>
                              <span className="text-[10px] sm:text-[11px] text-indigo-700 font-bold bg-indigo-50 px-1.5 py-0.2 sm:px-2 sm:py-0.5 rounded-md inline-block">
                                {emp.profession}
                              </span>
                            </div>
                            <AttributionBadge createdBy={emp.createdBy} updatedBy={emp.updatedBy} />
                          </div>

                          {/* Daily wage or Monthly salary & dates */}
                          <div className="space-y-1 text-xs text-slate-500">
                            {emp.wageType === 'monthly' ? (
                              (emp.monthlySalary || 0) > 0 && (
                                <div className="flex items-center justify-between font-bold text-emerald-700 bg-emerald-50/70 px-2 py-0.5 rounded-lg text-[11px] sm:text-xs">
                                  <span>الراتب الشهري:</span>
                                  <span>{formatCurrency(emp.monthlySalary || 0, emp.dailyWageCurrency || currency)} / شهر</span>
                                </div>
                              )
                            ) : (
                              emp.dailyWage > 0 && (
                                <div className="flex items-center justify-between font-bold text-emerald-700 bg-emerald-50/70 px-2 py-0.5 rounded-lg text-[11px] sm:text-xs">
                                  <span>الأجر اليومي:</span>
                                  <span>{formatCurrency(emp.dailyWage, emp.dailyWageCurrency || currency)} / يوم</span>
                                </div>
                              )
                            )}
                            <div className="flex items-center justify-between text-[10px] sm:text-[11px]">
                              <span>تاريخ العمل:</span>
                              <span className="font-semibold text-slate-700">{formatDateArabic(emp.startDate)}</span>
                            </div>
                            <div className="flex items-center justify-between text-[10px] sm:text-[11px]">
                              <span>أيام العمل المحتسبة:</span>
                              <span className="font-bold text-indigo-600">{days} يوم</span>
                            </div>
                            <PhoneNumbersDisplay phoneNumbers={emp.phoneNumbers} className="pt-0.5" />
                          </div>

                          {/* Account Summary breakdown by currency */}
                          <div className="mt-2 pt-2 border-t border-slate-100 space-y-1 text-xs">
                            {balances.map(b => (
                              <div key={b.currency} className="p-1.5 bg-slate-50/80 rounded-lg space-y-0.5 border border-slate-100 text-[11px] sm:text-xs">
                                {balances.length > 1 && (
                                  <span className="text-[9px] sm:text-[10px] font-black text-indigo-700 block mb-0.5">عملة ({b.currency}):</span>
                                )}
                                <div className="flex justify-between items-center text-slate-500 text-[10px] sm:text-[11px]">
                                  <span>له (مستحقات أجور):</span>
                                  <span className="font-bold text-emerald-600 font-mono">{formatCurrency(b.forHim, b.currency)}</span>
                                </div>
                                <div className="flex justify-between items-center text-slate-500 text-[10px] sm:text-[11px]">
                                  <span>عليه (سلف نقدية):</span>
                                  <span className="font-bold text-rose-600 font-mono">{formatCurrency(b.onHim, b.currency)}</span>
                                </div>
                                <div className="flex justify-between items-center font-bold text-slate-800 pt-0.5 border-t border-slate-200/60 text-[10px] sm:text-[11px]">
                                  <span>الصافي الحالي:</span>
                                  <span className={`font-mono ${b.net > 0 ? 'text-emerald-600 font-black' : b.net < 0 ? 'text-rose-600 font-black' : 'text-slate-400'}`}>
                                    {b.net === 0 ? 'خالص الطرفين' : b.net > 0 ? `له: ${formatCurrency(b.net, b.currency)}` : `عليه: ${formatCurrency(Math.abs(b.net), b.currency)}`}
                                  </span>
                                </div>
                              </div>
                            ))}
                          </div>

                          {emp.notes && (
                            <div className="mt-1 text-[10px] sm:text-[11px] text-slate-600 bg-slate-50 border border-slate-100 p-1.5 rounded-lg text-right font-medium">
                              <span className="font-bold text-slate-400 text-[9px] block mb-0.5">ملاحظات:</span>
                              {emp.notes}
                            </div>
                          )}

                        </div>

                        {/* Action section footer */}
                        <div className="flex items-center justify-between mt-2.5 pt-2 border-t border-slate-100">
                          <span className="text-[11px] sm:text-xs font-bold text-slate-400">كشف الحساب:</span>
                          
                          <div className="flex items-center gap-1 sm:gap-1.5">
                            <button 
                              onClick={() => setSelectedEmployeeId(emp.id)}
                              className="bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold text-[11px] sm:text-xs py-1 px-2.5 sm:py-1.5 sm:px-3 rounded-lg border border-indigo-200 transition-colors cursor-pointer flex items-center gap-1"
                            >
                              عرض الكشف
                              <ChevronLeft size={13} className="rotate-180" />
                            </button>
                            {sharedRole !== 'read' && (
                              <button 
                                onClick={() => setEditingEmployee(emp)}
                                className="p-1 sm:p-1.5 hover:bg-slate-50 text-slate-400 hover:text-slate-700 rounded-lg transition-colors cursor-pointer"
                                title="تعديل بيانات وتواريخ الموظف"
                              >
                                <Pencil size={13} />
                              </button>
                            )}
                            {sharedRole !== 'read' && onTransferEmployeeToWorker && (
                              <button 
                                onClick={() => {
                                  if (confirm(`هل ترغب بنقل الموظف "${emp.name}" إلى نافذة العمال؟`)) {
                                    onTransferEmployeeToWorker(emp);
                                  }
                                }}
                                className="p-1 sm:p-1.5 hover:bg-amber-50 text-slate-500 hover:text-amber-700 rounded-lg transition-colors cursor-pointer"
                                title="نقل الي العمال"
                              >
                                <ArrowRightLeft size={13} />
                              </button>
                            )}
                            {sharedRole !== 'read' && sharedRole !== 'add' && (
                              <button 
                                onClick={() => {
                                  if (confirm(`هل أنت متأكد من حذف الموظف ${emp.name}؟ سيتم حذف كافة سجلات كشف حسابه تلقائياً.`)) {
                                    onDeleteEmployee(emp.id);
                                  }
                                }}
                                className="p-1 sm:p-1.5 hover:bg-rose-50 text-slate-300 hover:text-rose-600 rounded-lg transition-colors cursor-pointer"
                                title="حذف الموظف"
                              >
                                <Trash2 size={13} />
                              </button>
                            )}
                          </div>
                        </div>

                      </div>
                    );
                  })
                )}
              </div>
            </div>

          </div>

        </div>
      )}

      {/* Edit Employee Modal */}
      {editingEmployee && (
        <div 
          className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-2.5 sm:p-4 overflow-y-auto dir-rtl text-right overscroll-contain"
          onTouchMove={(e) => {
            if (e.target === e.currentTarget) e.preventDefault();
          }}
        >
          <div 
            className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-md w-full animate-scale-up my-auto max-h-[88vh] sm:max-h-[90vh] flex flex-col overflow-hidden overscroll-contain"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-4 border-b border-slate-100 flex items-center justify-between shrink-0 bg-white">
              <h3 className="font-bold text-slate-800 text-base sm:text-lg">تعديل بيانات الموظف</h3>
              <button
                type="button"
                onClick={() => setEditingEmployee(null)}
                className="p-1 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100 cursor-pointer"
              >
                ✕
              </button>
            </div>
            <form onSubmit={handleEditEmployeeSubmit} className="flex flex-col flex-1 overflow-hidden min-h-0">
              <div className="p-4 overflow-y-auto space-y-4 flex-1 min-h-0 overscroll-contain touch-pan-y custom-scrollbar modal-scroll-area">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-600 block">اسم الموظف</label>
                  <input 
                    type="text" 
                    value={editingEmployee.name}
                    onChange={(e) => setEditingEmployee({ ...editingEmployee, name: e.target.value })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-sm focus:outline-hidden focus:border-indigo-500"
                    required
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-600 block">المسمى الوظيفي / التخصص</label>
                  <input 
                    type="text" 
                    value={editingEmployee.profession}
                    onChange={(e) => setEditingEmployee({ ...editingEmployee, profession: e.target.value })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-sm focus:outline-hidden focus:border-indigo-500"
                    required
                  />
                </div>

                <PhoneNumbersInput 
                  phoneNumbers={editingEmployee.phoneNumbers || ['']} 
                  onChange={(phones) => setEditingEmployee({ ...editingEmployee, phoneNumbers: phones })} 
                />
                {/* Wage Type Selector: Daily Wage vs Monthly Salary */}
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-700 block">نظام المستحقات المالية</label>
                  <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100/90 rounded-2xl border border-slate-200/80">
                    <button
                      type="button"
                      onClick={() => setEditingEmployee({ ...editingEmployee, wageType: 'daily' })}
                      className={`py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                        (editingEmployee.wageType || 'daily') === 'daily'
                          ? 'bg-white text-indigo-700 shadow-xs border border-indigo-100'
                          : 'text-slate-500 hover:text-slate-800'
                      }`}
                    >
                      <Clock size={14} />
                      <span>الأجر اليومي</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setEditingEmployee({ ...editingEmployee, wageType: 'monthly' })}
                      className={`py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                        editingEmployee.wageType === 'monthly'
                          ? 'bg-white text-emerald-700 shadow-xs border border-emerald-100'
                          : 'text-slate-500 hover:text-slate-800'
                      }`}
                    >
                      <Calendar size={14} />
                      <span>الراتب الشهري</span>
                    </button>
                  </div>
                </div>

                {(editingEmployee.wageType || 'daily') === 'daily' ? (
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-indigo-700 block">الأجر اليومي (اختياري)</label>
                    <div className="flex gap-2">
                      <input 
                        type="number" 
                        step="any"
                        value={editingEmployee.dailyWage || ''}
                        onChange={(e) => setEditingEmployee({ ...editingEmployee, dailyWage: Number(e.target.value) || 0 })}
                        placeholder="0"
                        className="flex-1 p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 text-sm font-bold focus:outline-hidden focus:border-indigo-500"
                      />
                      <select
                        value={editingEmployee.dailyWageCurrency || editingEmployee.currency || currency || 'YER'}
                        onChange={(e) => setEditingEmployee({ ...editingEmployee, dailyWageCurrency: e.target.value, currency: e.target.value })}
                        className="w-24 p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-xs font-bold focus:outline-hidden focus:border-indigo-500 cursor-pointer shrink-0"
                      >
                        <option value="YER">YER</option>
                        <option value="SAR">SAR</option>
                        <option value="USD">USD</option>
                      </select>
                    </div>
                    <AmountInWords amount={editingEmployee.dailyWage} currency={editingEmployee.dailyWageCurrency || editingEmployee.currency || currency || 'YER'} />
                  </div>
                ) : (
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-emerald-700 block">مبلغ الراتب الشهري (المعتمد)</label>
                    <div className="flex gap-2">
                      <input 
                        type="number" 
                        step="any"
                        value={editingEmployee.monthlySalary || ''}
                        onChange={(e) => setEditingEmployee({ ...editingEmployee, monthlySalary: Number(e.target.value) || 0 })}
                        placeholder="0"
                        className="flex-1 p-2.5 bg-emerald-50/40 border border-emerald-200 rounded-xl text-emerald-900 text-sm font-bold focus:outline-hidden focus:border-emerald-500"
                      />
                      <select
                        value={editingEmployee.dailyWageCurrency || editingEmployee.currency || currency || 'YER'}
                        onChange={(e) => setEditingEmployee({ ...editingEmployee, dailyWageCurrency: e.target.value, currency: e.target.value })}
                        className="w-24 p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-xs font-bold focus:outline-hidden focus:border-emerald-500 cursor-pointer shrink-0"
                      >
                        <option value="YER">YER</option>
                        <option value="SAR">SAR</option>
                        <option value="USD">USD</option>
                      </select>
                    </div>
                    <AmountInWords amount={editingEmployee.monthlySalary || 0} currency={editingEmployee.dailyWageCurrency || editingEmployee.currency || currency || 'YER'} />
                    <p className="text-[11px] text-emerald-700/80 font-medium">
                      💡 يقسم الراتب على أيام كل شهر ويضرب بعدد أيام العمل الفعلية لكل شهر على حدة.
                    </p>
                  </div>
                )}

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-600 block">تاريخ بدء العمل</label>
                  <input 
                    type="date" 
                    value={editingEmployee.startDate}
                    onChange={(e) => setEditingEmployee({ ...editingEmployee, startDate: e.target.value })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-sm focus:outline-hidden focus:border-indigo-500"
                    required
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-600 block">تاريخ الانتهاء (اختياري)</label>
                  <input 
                    type="date" 
                    value={editingEmployee.endDate || ''}
                    onChange={(e) => setEditingEmployee({ ...editingEmployee, endDate: e.target.value })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-sm focus:outline-hidden focus:border-indigo-500"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-600 block">ملاحظات (اختياري)</label>
                  <textarea 
                    value={editingEmployee.notes || ''}
                    onChange={(e) => setEditingEmployee({ ...editingEmployee, notes: e.target.value })}
                    rows={2}
                    placeholder="أي ملاحظات..."
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-xs focus:outline-hidden focus:border-indigo-500 resize-none"
                  />
                </div>

                {editingEmployee.startDate && (editingEmployee.wageType || 'daily') === 'daily' && (
                  <div className="p-3 bg-indigo-50 border border-indigo-100 rounded-xl space-y-1 text-xs text-slate-700">
                    <div className="flex justify-between items-center font-semibold">
                      <span>المدة الإجمالية:</span>
                      <span className="font-bold text-indigo-700 text-sm">
                        {calculateDaysOfWork(editingEmployee.startDate, editingEmployee.endDate, sharedRole === 'owner')} {editingEmployee.endDate ? 'يوم عمل' : 'يوم عمل حتى اليوم'}
                      </span>
                    </div>
                    {editingEmployee.dailyWage > 0 && (
                      <div className="flex justify-between items-center font-bold text-indigo-700 pt-1 border-t border-indigo-100">
                        <span>إجمالي الأجر اليومي المحتسب:</span>
                        <span>{formatCurrency(calculateDaysOfWork(editingEmployee.startDate, editingEmployee.endDate, sharedRole === 'owner') * editingEmployee.dailyWage, editingEmployee.dailyWageCurrency || editingEmployee.currency || currency)}</span>
                      </div>
                    )}
                  </div>
                )}

                {editingEmployee.startDate && editingEmployee.wageType === 'monthly' && Number(editingEmployee.monthlySalary) > 0 && (
                  <div className="p-3 bg-emerald-50/80 border border-emerald-200 rounded-xl space-y-2 text-xs">
                    <div className="flex justify-between items-center font-bold text-emerald-900">
                      <span>معاينة احتساب الرواتب المستحقة حسب الأشهر:</span>
                    </div>
                    {editingEmployee.excludedSalaryMonthKeys && editingEmployee.excludedSalaryMonthKeys.length > 0 && (
                      <div className="flex items-center justify-between p-2 bg-amber-50 rounded-lg border border-amber-200">
                        <span className="text-amber-800 text-[11px] font-bold">
                          تم استبعاد ({editingEmployee.excludedSalaryMonthKeys.length}) أشهر من الاحتساب بسبب الحذف اليدوي.
                        </span>
                        <button
                          type="button"
                          onClick={() => setEditingEmployee({ ...editingEmployee, excludedSalaryMonthKeys: [] })}
                          className="px-2 py-1 bg-white hover:bg-emerald-50 text-emerald-700 hover:text-emerald-800 border border-emerald-300 rounded text-[10px] font-extrabold cursor-pointer transition-colors shadow-2xs"
                        >
                          استعادة واحتساب كافة الأشهر
                        </button>
                      </div>
                    )}
                    {(() => {
                      const breakdowns = calculateEmployeeMonthlySalaries(editingEmployee, sharedRole === 'owner');
                      const totalSalaryDue = breakdowns.reduce((acc, curr) => acc + curr.amountDue, 0);
                      return (
                        <div className="space-y-1.5 pt-1 border-t border-emerald-200">
                          {breakdowns.map(b => (
                            <div key={b.monthKey} className="bg-white/90 p-2 rounded-lg border border-emerald-100 flex items-center justify-between">
                              <div>
                                <span className="font-bold text-emerald-900 block">{b.monthName} {b.year} ({b.workedDaysInMonth} / {b.totalDaysInMonth} يوم)</span>
                                <span className="text-[10px] text-slate-500">من {formatDateArabic(b.startDateInMonth)} إلى {formatDateArabic(b.endDateInMonth)}</span>
                              </div>
                              <div className="text-left font-mono font-bold text-emerald-700">
                                {formatCurrency(b.amountDue, editingEmployee.dailyWageCurrency || editingEmployee.currency || currency)}
                              </div>
                            </div>
                          ))}
                          <div className="flex justify-between items-center font-extrabold text-emerald-900 pt-1 border-t border-emerald-200">
                            <span>إجمالي الرواتب المستحقة:</span>
                            <span className="font-mono text-sm">{formatCurrency(totalSalaryDue, editingEmployee.dailyWageCurrency || editingEmployee.currency || currency)}</span>
                          </div>
                        </div>
                      );
                    })()}
                  </div>
                )}
              </div>

              <div className="flex justify-end gap-2 p-3.5 bg-slate-50 border-t border-slate-100 shrink-0">
                <button 
                  type="button" 
                  onClick={() => setEditingEmployee(null)}
                  className="px-4 py-2 bg-slate-100 text-slate-600 font-bold text-xs rounded-xl hover:bg-slate-200 transition-colors cursor-pointer"
                >
                  إلغاء
                </button>
                <button 
                  type="submit" 
                  className="px-4 py-2 bg-indigo-600 text-white font-bold text-xs rounded-xl hover:bg-indigo-700 transition-colors cursor-pointer"
                >
                  حفظ التعديلات
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Ledger Entry Modal */}
      {editingEmployeeLedger && (
        <div 
          className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-2.5 sm:p-4 overflow-y-auto dir-rtl text-right overscroll-contain"
          onTouchMove={(e) => {
            if (e.target === e.currentTarget) e.preventDefault();
          }}
        >
          <div 
            className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-md w-full animate-scale-up my-auto max-h-[88vh] sm:max-h-[90vh] flex flex-col overflow-hidden overscroll-contain"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-4 border-b border-slate-100 flex items-center justify-between shrink-0 bg-white">
              <h3 className="font-bold text-slate-800 text-base sm:text-lg">تعديل الحركة المالية</h3>
              <button
                type="button"
                onClick={() => setEditingEmployeeLedger(null)}
                className="p-1 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100 cursor-pointer"
              >
                ✕
              </button>
            </div>
            <form onSubmit={handleEditEmployeeLedgerSubmit} className="flex flex-col flex-1 overflow-hidden min-h-0">
              <div className="p-4 overflow-y-auto space-y-4 flex-1 min-h-0 overscroll-contain touch-pan-y custom-scrollbar modal-scroll-area">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-600 block">التاريخ</label>
                  <input 
                    type="date" 
                    value={editingEmployeeLedger.entry.date}
                    onChange={(e) => setEditingEmployeeLedger({
                      ...editingEmployeeLedger,
                      entry: { ...editingEmployeeLedger.entry, date: e.target.value }
                    })}
                    className="w-full h-[42px] px-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-sm focus:outline-hidden focus:border-indigo-500"
                    required
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-rose-600 block">المبلغ عليه (سلفة/دفعة)</label>
                    <input 
                      type="number" 
                      step="any"
                      value={editingEmployeeLedger.entry.amountOnHim}
                      onChange={(e) => setEditingEmployeeLedger({
                        ...editingEmployeeLedger,
                        entry: { ...editingEmployeeLedger.entry, amountOnHim: Number(e.target.value) || 0 }
                      })}
                      className="w-full h-[42px] px-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 text-sm font-bold focus:outline-hidden focus:border-rose-500"
                    />
                    <AmountInWords amount={editingEmployeeLedger.entry.amountOnHim} currency={editingEmployeeLedger.entry.currency || 'YER'} />
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-emerald-600 block">المبلغ له (أجور)</label>
                    <input 
                      type="number" 
                      step="any"
                      value={editingEmployeeLedger.entry.amountForHim}
                      onChange={(e) => setEditingEmployeeLedger({
                        ...editingEmployeeLedger,
                        entry: { ...editingEmployeeLedger.entry, amountForHim: Number(e.target.value) || 0 }
                      })}
                      className="w-full h-[42px] px-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 text-sm font-bold focus:outline-hidden focus:border-emerald-500"
                    />
                    <AmountInWords amount={editingEmployeeLedger.entry.amountForHim} currency={editingEmployeeLedger.entry.currency || 'YER'} />
                  </div>
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-600 block">البيان</label>
                  <input 
                    type="text" 
                    value={editingEmployeeLedger.entry.description}
                    onChange={(e) => setEditingEmployeeLedger({
                      ...editingEmployeeLedger,
                      entry: { ...editingEmployeeLedger.entry, description: e.target.value }
                    })}
                    className="w-full h-[42px] px-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-sm focus:outline-hidden focus:border-indigo-500"
                    required
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-600 block">العملة</label>
                  <select
                    value={editingEmployeeLedger.entry.currency || currency || 'YER'}
                    onChange={(e) => setEditingEmployeeLedger({
                      ...editingEmployeeLedger,
                      entry: { ...editingEmployeeLedger.entry, currency: e.target.value }
                    })}
                    className="w-full h-[42px] px-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-sm font-bold focus:outline-hidden focus:border-indigo-500 cursor-pointer"
                  >
                    <option value="YER">ريال يمني (YER)</option>
                    <option value="SAR">ريال سعودي (SAR)</option>
                    <option value="USD">دولار أمريكي (USD)</option>
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-600 block">ملاحظات</label>
                  <input 
                    type="text" 
                    value={editingEmployeeLedger.entry.notes || ''}
                    onChange={(e) => setEditingEmployeeLedger({
                      ...editingEmployeeLedger,
                      entry: { ...editingEmployeeLedger.entry, notes: e.target.value }
                    })}
                    className="w-full h-[42px] px-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-sm focus:outline-hidden focus:border-indigo-500"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 p-3.5 bg-slate-50 border-t border-slate-100 shrink-0">
                <button 
                  type="button" 
                  onClick={() => setEditingEmployeeLedger(null)}
                  className="px-4 py-2 bg-slate-100 text-slate-600 font-bold text-xs rounded-xl hover:bg-slate-200 transition-colors cursor-pointer"
                >
                  إلغاء
                </button>
                <button 
                  type="submit" 
                  className="px-4 py-2 bg-indigo-600 text-white font-bold text-xs rounded-xl hover:bg-indigo-700 transition-colors cursor-pointer"
                >
                  حفظ التعديل
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Nutrition Period Modal */}
      {showNutritionModal && activeEmployee && (
        <div 
          className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-3 sm:p-4 overflow-y-auto dir-rtl text-right overscroll-contain"
          onTouchMove={(e) => {
            if (e.target === e.currentTarget) e.preventDefault();
          }}
        >
          <div 
            className="bg-white rounded-3xl shadow-2xl border border-slate-100 max-w-lg w-full overflow-hidden my-auto animate-scale-up overscroll-contain max-h-[88vh] sm:max-h-[90vh] flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="bg-gradient-to-r from-emerald-700 to-teal-800 text-white p-4 sm:p-5 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-white/10 rounded-xl">
                  <Utensils size={20} className="text-emerald-200" />
                </div>
                <div>
                  <h3 className="font-extrabold text-base">بيانات التغذية</h3>
                  <p className="text-xs text-emerald-100">للموظف الرئيسي أو المساعدين التابعين له</p>
                </div>
              </div>
              <button 
                type="button"
                onClick={() => setShowNutritionModal(false)}
                className="p-1.5 text-emerald-200 hover:text-white hover:bg-white/10 rounded-xl transition-colors cursor-pointer"
              >
                <X size={20} />
              </button>
            </div>

            {/* Modal Form */}
            <form onSubmit={handleNutritionSubmit} className="flex flex-col flex-1 overflow-hidden min-h-0">
              <div className="p-4 sm:p-5 space-y-4 flex-1 overflow-y-auto min-h-0 overscroll-contain touch-pan-y custom-scrollbar modal-scroll-area">
              
              {/* Employee/Beneficiary Name */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 block">
                  اسم الموظف / المساعد <span className="text-rose-500">*</span>
                </label>
                <input 
                  type="text" 
                  value={nutrWorkerName}
                  onChange={(e) => setNutrWorkerName(e.target.value)}
                  placeholder="أدخل اسم الموظف أو المساعد"
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 text-xs focus:outline-hidden focus:border-emerald-500 focus:bg-white transition-all"
                  required
                />
              </div>

              {/* Daily Amount */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 block">
                  مبلغ التغذية اليومية ({currency}) <span className="text-rose-500">*</span>
                </label>
                <div className="flex gap-1.5 items-center">
                  <input 
                    type="number" 
                    value={nutrDailyAmount}
                    onChange={(e) => setNutrDailyAmount(e.target.value)}
                    placeholder="مثال: 5000"
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 text-xs font-mono font-bold focus:outline-hidden focus:border-emerald-500 focus:bg-white transition-all min-w-0"
                    required
                  />
                  <Calculator onApply={(val) => setNutrDailyAmount(String(val))} buttonTitle="حسابة المبلغ اليومي" />
                </div>
                <AmountInWords amount={nutrDailyAmount} currency={currency} />
              </div>

              {/* Dates Row */}
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700 block">
                    تاريخ البدء <span className="text-rose-500">*</span>
                  </label>
                  <input 
                    type="date" 
                    value={nutrStartDate}
                    onChange={(e) => setNutrStartDate(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 text-xs focus:outline-hidden focus:border-emerald-500 focus:bg-white transition-all"
                    required
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700 block">
                    تاريخ الانتهاء <span className="text-slate-400 font-normal">(اختياري)</span>
                  </label>
                  <input 
                    type="date" 
                    value={nutrEndDate}
                    onChange={(e) => setNutrEndDate(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 text-xs focus:outline-hidden focus:border-emerald-500 focus:bg-white transition-all"
                  />
                  <span className="text-[10px] text-slate-400 block">* اتركه فارغاً إذا كانت الفترة مستمرة.</span>
                </div>
              </div>

              {/* Dynamic Real-Time Calculation Box */}
              {(() => {
                const calcDays = calculateNutritionDays(nutrStartDate, nutrEndDate);
                const dailyVal = parseFloat(nutrDailyAmount) || 0;
                const calcTotal = dailyVal * calcDays;
                const isOngoing = !nutrEndDate;

                return (
                  <div className="p-3.5 bg-emerald-50/70 border border-emerald-200/80 rounded-2xl space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-bold text-emerald-900">حالة فترة التغذية:</span>
                      <span className={`px-2.5 py-0.5 rounded-full text-xs font-extrabold ${
                        isOngoing 
                          ? 'bg-emerald-100 text-emerald-800 border border-emerald-300' 
                          : 'bg-sky-100 text-sky-800 border border-sky-300'
                      }`}>
                        {isOngoing ? '🟢 مستمرة (غير محددة بنهاية)' : '🔵 مكتملة'}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-xs pt-1 border-t border-emerald-200/50">
                      <div className="bg-white p-2 rounded-xl border border-emerald-100 text-center">
                        <span className="text-[10px] text-slate-500 block">عدد أيام التغذية:</span>
                        <span className="font-black text-emerald-800 text-sm">{calcDays} يوم</span>
                      </div>
                      <div className="bg-white p-2 rounded-xl border border-emerald-100 text-center">
                        <span className="text-[10px] text-slate-500 block">إجمالي التغذية المحتسب:</span>
                        <span className="font-black text-rose-600 text-sm">{formatCurrency(calcTotal, currency)}</span>
                      </div>
                    </div>
                  </div>
                );
              })()}

              {/* Notes */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 block">ملاحظات</label>
                <textarea 
                  value={nutrNotes}
                  onChange={(e) => setNutrNotes(e.target.value)}
                  placeholder="أي ملاحظات إضافية حول التغذية..."
                  rows={2}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 text-xs focus:outline-hidden focus:border-emerald-500 focus:bg-white resize-none"
                />
              </div>

              {nutrFormError && (
                <p className="text-xs font-bold text-rose-600 bg-rose-50 p-2.5 rounded-xl border border-rose-200">{nutrFormError}</p>
              )}
              </div>

              {/* Modal Action Buttons */}
              <div className="flex items-center justify-between gap-2 p-3.5 sm:p-4 bg-slate-50 border-t border-slate-100 shrink-0">
                {editingNutritionPeriod && sharedRole !== 'read' ? (
                  <button
                    type="button"
                    onClick={() => {
                      const confirmText = `هل أنت متأكد من حذف فترة التغذية الخاصة بـ "${editingNutritionPeriod.workerName}"؟`;
                      if (typeof window === 'undefined' || !window.confirm || window.confirm(confirmText)) {
                        onDeleteEmployeeNutritionPeriod?.(activeEmployee.id, editingNutritionPeriod.id);
                        setShowNutritionModal(false);
                      }
                    }}
                    className="px-3.5 py-2 text-xs font-bold text-rose-600 bg-rose-50 hover:bg-rose-100 rounded-xl transition-colors cursor-pointer flex items-center gap-1.5"
                  >
                    <Trash2 size={13} />
                    <span>حذف الفترة</span>
                  </button>
                ) : <div />}

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setShowNutritionModal(false)}
                    className="px-4 py-2 text-xs font-bold text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors cursor-pointer"
                  >
                    إلغاء
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl transition-colors shadow-xs cursor-pointer flex items-center gap-1.5"
                  >
                    <Utensils size={14} />
                    <span>{editingNutritionPeriod ? 'حفظ التعديلات' : 'إضافة التغذية وحفظ الكشف'}</span>
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Copy / Move Ledger Entry Modal */}
      <CopyMoveLedgerModal
        isOpen={copyMoveModalState.isOpen}
        mode={copyMoveModalState.mode}
        entry={copyMoveModalState.entry}
        sourceType="employee"
        sourceId={copyMoveModalState.employeeId}
        sourceName={copyMoveModalState.employeeName}
        workers={workers}
        employees={employees}
        suppliers={suppliers}
        currency={currency}
        onClose={() => setCopyMoveModalState(prev => ({ ...prev, isOpen: false }))}
        onConfirm={(mode, sType, sId, entry, tType, tId) => {
          if (mode === 'copy') {
            onCopyLedgerEntry?.(sType, sId, entry, tType, tId);
          } else {
            onMoveLedgerEntry?.(sType, sId, entry, tType, tId);
          }
        }}
      />

      {/* Quick Edit Wage & Financial Operation Modal */}
      {showQuickWageModal && activeEmployee && (
        <div 
          className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-3 sm:p-4 overflow-y-auto dir-rtl text-right overscroll-contain"
          onTouchMove={(e) => {
            if (e.target === e.currentTarget) e.preventDefault();
          }}
        >
          <div 
            className="bg-white rounded-3xl shadow-2xl border border-slate-100 max-w-md w-full overflow-hidden my-auto animate-scale-up overscroll-contain"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="bg-gradient-to-r from-indigo-700 via-indigo-800 to-slate-900 text-white p-4 sm:p-5 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-white/10 rounded-xl">
                  <Coins size={20} className="text-amber-300" />
                </div>
                <div>
                  <h3 className="font-extrabold text-base">تعديل الراتب / الأجر اليومي</h3>
                  <p className="text-xs text-indigo-200">المرتبط مباشرة بالعملية المالية في كشف الحساب</p>
                </div>
              </div>
              <button 
                type="button"
                onClick={() => setShowQuickWageModal(false)}
                className="text-white/70 hover:text-white p-1 cursor-pointer transition-colors"
              >
                <X size={20} />
              </button>
            </div>

            <form onSubmit={handleQuickWageSubmit} className="p-4 sm:p-5 space-y-4">
              <div className="p-3 bg-indigo-50/70 border border-indigo-100 rounded-xl text-xs text-indigo-900 flex items-start gap-2">
                <Sparkles size={16} className="text-indigo-600 shrink-0 mt-0.5" />
                <p>
                  أي تعديل هنا سينعكس فوراً وتلقائياً على العملية المالية المسجلة للأجر في كشف حساب الموظف <strong>{activeEmployee.name}</strong>.
                </p>
              </div>

              {/* Wage Type Selector */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 block">نظام الأجر / الراتب</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setQuickWageType('daily')}
                    className={`py-2 px-3 rounded-xl font-bold text-xs border transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                      quickWageType === 'daily'
                        ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
                        : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    <span>أجر يومي</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setQuickWageType('monthly')}
                    className={`py-2 px-3 rounded-xl font-bold text-xs border transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                      quickWageType === 'monthly'
                        ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
                        : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    <span>راتب شهري مقطوع</span>
                  </button>
                </div>
              </div>

              {/* Value Input */}
              {quickWageType === 'daily' ? (
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700 block">
                    الأجر اليومي ({quickWageCurrency}) <span className="text-rose-500">*</span>
                  </label>
                  <div className="flex gap-1.5 items-center">
                    <input
                      type="number"
                      value={quickWageValue}
                      onChange={(e) => setQuickWageValue(e.target.value)}
                      placeholder="أدخل الأجر لليوم الواحد"
                      className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 text-xs font-mono font-bold focus:outline-hidden focus:border-indigo-500 focus:bg-white transition-all min-w-0"
                      required
                    />
                    <Calculator onApply={(val) => setQuickWageValue(String(val))} buttonTitle="حسابة الأجر" />
                  </div>
                  <AmountInWords amount={quickWageValue} currency={quickWageCurrency} />
                </div>
              ) : (
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700 block">
                    الراتب الشهري ({quickWageCurrency}) <span className="text-rose-500">*</span>
                  </label>
                  <div className="flex gap-1.5 items-center">
                    <input
                      type="number"
                      value={quickMonthlySalaryValue}
                      onChange={(e) => setQuickMonthlySalaryValue(e.target.value)}
                      placeholder="أدخل الراتب الشهري المقطوع"
                      className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 text-xs font-mono font-bold focus:outline-hidden focus:border-indigo-500 focus:bg-white transition-all min-w-0"
                      required
                    />
                    <Calculator onApply={(val) => setQuickMonthlySalaryValue(String(val))} buttonTitle="حسابة الراتب" />
                  </div>
                  <AmountInWords amount={quickMonthlySalaryValue} currency={quickWageCurrency} />
                </div>
              )}

              {/* Currency Selector */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 block">عملة الأجر</label>
                <div className="flex gap-2">
                  {['YER', 'SAR', 'USD'].map((cur) => (
                    <button
                      key={cur}
                      type="button"
                      onClick={() => setQuickWageCurrency(cur)}
                      className={`flex-1 py-1.5 rounded-lg text-xs font-bold border transition-colors cursor-pointer ${
                        quickWageCurrency === cur
                          ? 'bg-slate-800 text-white border-slate-800'
                          : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      {cur}
                    </button>
                  ))}
                </div>
              </div>

              {/* Modal Actions */}
              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowQuickWageModal(false)}
                  className="px-4 py-2 text-xs font-bold text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors cursor-pointer"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl transition-colors shadow-xs cursor-pointer flex items-center gap-1.5"
                >
                  <CheckCircle2 size={14} />
                  <span>حفظ وتحديث الكشف</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Quick Edit Basic Period Modal */}
      {showQuickBasicPeriodModal && activeEmployee && (
        <div 
          className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-3 sm:p-4 overflow-y-auto dir-rtl text-right overscroll-contain"
          onTouchMove={(e) => {
            if (e.target === e.currentTarget) e.preventDefault();
          }}
        >
          <div 
            className="bg-white rounded-3xl shadow-2xl border border-slate-100 max-w-md w-full overflow-hidden my-auto animate-scale-up overscroll-contain"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="bg-gradient-to-r from-sky-700 via-sky-800 to-indigo-900 text-white p-4 sm:p-5 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-white/10 rounded-xl">
                  <Calendar size={20} className="text-sky-200" />
                </div>
                <div>
                  <h3 className="font-extrabold text-base">تعديل فترة العمل الأساسية</h3>
                  <p className="text-xs text-sky-100">وتحديث العملية المالية للأجر في كشف الحساب</p>
                </div>
              </div>
              <button 
                type="button"
                onClick={() => setShowQuickBasicPeriodModal(false)}
                className="text-white/70 hover:text-white p-1 cursor-pointer transition-colors"
              >
                <X size={20} />
              </button>
            </div>

            <form onSubmit={handleQuickBasicPeriodSubmit} className="p-4 sm:p-5 space-y-4">
              <div className="p-3 bg-sky-50 border border-sky-100 rounded-xl text-xs text-sky-900 flex items-start gap-2">
                <Sparkles size={16} className="text-sky-600 shrink-0 mt-0.5" />
                <p>
                  تعديل فترة العمل الأساسية يقوم بإعادة احتساب أيام العمل تلقائياً وتعديل العملية المالية في كشف حساب الموظف فوراً.
                </p>
              </div>

              <div className="space-y-3">
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    تاريخ بدء العمل الأساسي <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="date"
                    value={quickBasicStartDate}
                    onChange={(e) => setQuickBasicStartDate(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 text-xs focus:outline-hidden focus:border-sky-500 focus:bg-white transition-all"
                    required
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    تاريخ انتهاء العمل <span className="text-slate-400 font-normal">(اتركه فارغاً إذا كان مستمراً حتى الآن)</span>
                  </label>
                  <input
                    type="date"
                    value={quickBasicEndDate}
                    onChange={(e) => setQuickBasicEndDate(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 text-xs focus:outline-hidden focus:border-sky-500 focus:bg-white transition-all"
                  />
                </div>

                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/70 flex items-center justify-between text-xs">
                  <span className="text-slate-600 font-bold">أيام الفترة الأساسية المحسوبة:</span>
                  <span className="font-mono font-black text-sky-700 bg-white px-2.5 py-1 rounded-lg border border-slate-200 shadow-2xs">
                    {quickBasicStartDate ? `${calculateDaysOfWork(quickBasicStartDate, quickBasicEndDate, sharedRole === 'owner')} يوم عمل` : '-'}
                  </span>
                </div>
              </div>

              {/* Modal Actions */}
              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowQuickBasicPeriodModal(false)}
                  className="px-4 py-2 text-xs font-bold text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors cursor-pointer"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold text-white bg-sky-600 hover:bg-sky-700 rounded-xl transition-colors shadow-xs cursor-pointer flex items-center gap-1.5"
                >
                  <CheckCircle2 size={14} />
                  <span>حفظ وتحديث الكشف</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
