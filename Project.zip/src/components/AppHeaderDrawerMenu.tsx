/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Building2, 
  TrendingUp, 
  Users, 
  Briefcase, 
  Truck, 
  Wallet, 
  Coins, 
  FileText, 
  FileSpreadsheet,
  Award, 
  Boxes, 
  Database, 
  Settings, 
  LogOut, 
  Info, 
  ChevronDown, 
  ChevronLeft, 
  ChevronUp, 
  X, 
  FolderKanban,
  Search,
  Sun,
  Moon,
  RotateCcw,
  Smartphone
} from 'lucide-react';
import { Project, CompanyAsset, GeneralDebt } from '../types';
import { useBodyScrollLock } from '../utils/modalScrollLock';

interface AppHeaderDrawerMenuProps {
  isOpen: boolean;
  onClose: () => void;
  activeTab: string;
  onNavigate: (tab: string) => void;
  projects: Project[];
  activeProjectId: string;
  onSelectProject: (id: string) => void;
  companyAssets?: CompanyAsset[];
  generalDebts?: GeneralDebt[];
  companyName: string;
  onOpenSettings: () => void;
  onOpenAppInfo: () => void;
  onOpenAndroidInstall?: () => void;
  onExitApp: () => void;
  theme?: 'light' | 'dark';
  onToggleTheme?: () => void;
  onOpenGlobalBackup?: () => void;
  onOpenUndo?: () => void;
  undoCount?: number;
}

export default function AppHeaderDrawerMenu({
  isOpen,
  onClose,
  activeTab,
  onNavigate,
  projects,
  activeProjectId,
  onSelectProject,
  companyAssets = [],
  generalDebts = [],
  companyName,
  onOpenSettings,
  onOpenAppInfo,
  onOpenAndroidInstall,
  onExitApp,
  theme = 'light',
  onToggleTheme,
  onOpenGlobalBackup,
  onOpenUndo,
  undoCount = 0
}: AppHeaderDrawerMenuProps) {
  // State for expanding/collapsing projects list
  const [isProjectsGroupExpanded, setIsProjectsGroupExpanded] = useState<boolean>(true);
  
  // State for which individual project has its quick-access sub-list expanded (null by default so only project names appear)
  const [expandedProjectId, setExpandedProjectId] = useState<string | null>(null);

  // Search filter for projects
  const [projectSearchQuery, setProjectSearchQuery] = useState<string>('');

  useBodyScrollLock(isOpen);

  if (!isOpen) return null;

  const filteredProjects = projects.filter(p => 
    p.name.toLowerCase().includes(projectSearchQuery.toLowerCase()) ||
    (p.client && p.client.toLowerCase().includes(projectSearchQuery.toLowerCase())) ||
    (p.location && p.location.toLowerCase().includes(projectSearchQuery.toLowerCase()))
  );

  const handleProjectClick = (projectId: string) => {
    onSelectProject(projectId);
    onNavigate('dashboard');
    onClose();
  };

  const handleProjectQuickNav = (projectId: string, tab: string) => {
    onSelectProject(projectId);
    onNavigate(tab);
    onClose();
  };

  const toggleProjectQuickAccess = (projectId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setExpandedProjectId(prev => prev === projectId ? null : projectId);
  };

  const getProjectStatusBadge = (status?: string) => {
    switch (status) {
      case 'completed':
        return <span className="text-[10px] bg-sky-950/80 text-sky-300 font-bold px-1.5 py-0.5 rounded-sm">مكتمل</span>;
      case 'planning':
        return <span className="text-[10px] bg-amber-950/80 text-amber-300 font-bold px-1.5 py-0.5 rounded-sm">تخطيط</span>;
      case 'paused':
        return <span className="text-[10px] bg-rose-950/80 text-rose-300 font-bold px-1.5 py-0.5 rounded-sm">متوقف</span>;
      case 'active':
      default:
        return <span className="text-[10px] bg-emerald-950/80 text-emerald-300 font-bold px-1.5 py-0.5 rounded-sm">نشط</span>;
    }
  };

  // Base uniform button styling across all items
  const getItemClassName = (isActive: boolean) => `
    w-full px-3 py-2.5 rounded-xl text-right flex items-center justify-between gap-3 transition-colors cursor-pointer text-xs sm:text-sm font-semibold
    ${isActive ? 'bg-amber-500 text-slate-950 font-bold shadow-xs' : 'text-slate-200 hover:text-white hover:bg-slate-800/70'}
  `;

  return (
    <div 
      className="fixed inset-0 z-[100] flex justify-end bg-slate-950/70 backdrop-blur-xs overscroll-contain transition-opacity duration-300"
      id="app-options-drawer-backdrop"
      onClick={onClose}
    >
      <div 
        className="w-full max-w-sm sm:max-w-md bg-slate-900 text-slate-100 h-full shadow-2xl flex flex-col border-r border-slate-800 text-right dir-rtl animate-slide-in-right overflow-hidden"
        onClick={(e) => e.stopPropagation()}
        id="app-options-drawer-panel"
      >
        
        {/* Drawer Header */}
        <div className="p-3.5 sm:p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-slate-800 text-amber-400 flex items-center justify-center font-bold shrink-0">
              <FolderKanban size={18} />
            </div>
            <div>
              <h3 className="font-bold text-sm text-white leading-tight">القائمة الرئيسية</h3>
              <span className="text-[10px] text-slate-400 block truncate max-w-[200px]">
                {companyName}
              </span>
            </div>
          </div>

          <button 
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
            title="إغلاق القائمة"
            id="close-app-options-drawer-btn"
          >
            <X size={18} />
          </button>
        </div>

        {/* Drawer Scrollable Content */}
        <div className="flex-1 overflow-y-auto p-2 sm:p-3 space-y-1 custom-scrollbar">

          {/* 1: النافذة الرئيسية للتطبيق */}
          <button
            type="button"
            onClick={() => {
              onNavigate('main_hub');
              onClose();
            }}
            className={getItemClassName(activeTab === 'main_hub')}
            id="drawer-group-1-main-hub-btn"
          >
            <div className="flex items-center gap-2.5">
              <Building2 size={17} className={activeTab === 'main_hub' ? 'text-slate-950' : 'text-amber-400'} />
              <span>النافذة الرئيسية للتطبيق</span>
            </div>
            <ChevronLeft size={15} className={activeTab === 'main_hub' ? 'text-slate-950' : 'text-slate-500'} />
          </button>

          {/* 2: إدارة المشاريع الإنشائية */}
          <div className="rounded-xl overflow-hidden">
            <div className="flex items-center justify-between">
              <button
                type="button"
                onClick={() => {
                  onNavigate('construction_projects');
                  onClose();
                }}
                className={`flex-1 px-3 py-2.5 rounded-r-xl text-right flex items-center justify-between gap-2 transition-colors cursor-pointer text-xs sm:text-sm font-semibold ${
                  activeTab === 'construction_projects' || activeTab === 'projects'
                    ? 'bg-amber-500 text-slate-950 font-bold shadow-xs'
                    : 'text-slate-200 hover:text-white hover:bg-slate-800/70'
                }`}
                id="drawer-group-2-projects-main-btn"
              >
                <div className="flex items-center gap-2.5">
                  <FolderKanban size={17} className={activeTab === 'construction_projects' || activeTab === 'projects' ? 'text-slate-950' : 'text-amber-400'} />
                  <span>إدارة المشاريع الإنشائية</span>
                </div>
              </button>

              <button
                type="button"
                onClick={() => setIsProjectsGroupExpanded(!isProjectsGroupExpanded)}
                className="px-2.5 py-2.5 rounded-l-xl text-slate-400 hover:text-white hover:bg-slate-800/70 transition-colors cursor-pointer shrink-0"
                title={isProjectsGroupExpanded ? 'طي قائمة المشاريع' : 'عرض قائمة المشاريع'}
                id="toggle-projects-group-btn"
              >
                {isProjectsGroupExpanded ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
              </button>
            </div>

            {/* Collapsible Projects List */}
            {isProjectsGroupExpanded && (
              <div className="mr-3 pr-2.5 border-r border-slate-800 my-1 space-y-1">
                {projects.length > 3 && (
                  <div className="relative mb-1.5">
                    <Search size={12} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
                    <input
                      type="text"
                      placeholder="بحث عن مشروع..."
                      value={projectSearchQuery}
                      onChange={(e) => setProjectSearchQuery(e.target.value)}
                      className="w-full pr-7 pl-2.5 py-1 bg-slate-800/60 rounded-lg text-xs text-white placeholder-slate-400 focus:outline-hidden focus:bg-slate-800"
                    />
                  </div>
                )}

                {filteredProjects.length === 0 ? (
                  <div className="text-center py-2 text-[11px] text-slate-400">
                    لا توجد مشاريع
                  </div>
                ) : (
                  filteredProjects.map((proj) => {
                    const isActive = proj.id === activeProjectId;
                    const isExpanded = expandedProjectId === proj.id;

                    return (
                      <div key={proj.id} className="rounded-lg overflow-hidden">
                        <div className={`p-2 rounded-lg flex items-center justify-between gap-1.5 transition-colors ${
                          isActive ? 'bg-slate-800 text-amber-300' : 'hover:bg-slate-800/50 text-slate-300'
                        }`}>
                          <button
                            type="button"
                            onClick={() => handleProjectClick(proj.id)}
                            className="flex items-center gap-1.5 flex-1 text-right truncate cursor-pointer"
                            title={`الانتقال لواجهة ${proj.name}`}
                          >
                            <span className="text-xs truncate font-medium">{proj.name}</span>
                            {getProjectStatusBadge(proj.status)}
                          </button>

                          <button
                            type="button"
                            onClick={(e) => toggleProjectQuickAccess(proj.id, e)}
                            className="p-1 text-slate-400 hover:text-white rounded-md transition-colors cursor-pointer shrink-0"
                            title={isExpanded ? 'طي النوافذ السريعة' : 'عرض النوافذ السريعة'}
                          >
                            {isExpanded ? <ChevronUp size={13} /> : <ChevronDown size={13} />}
                          </button>
                        </div>

                        {/* Nested Quick Access Sub-List */}
                        {isExpanded && (
                          <div className="mr-3 pr-2 border-r border-slate-800/60 my-1 space-y-0.5 text-xs">
                            <button
                              type="button"
                              onClick={() => handleProjectQuickNav(proj.id, 'expenses')}
                              className="w-full px-2 py-1.5 rounded-md text-right flex items-center justify-between text-slate-300 hover:text-white hover:bg-slate-800/60 transition-colors cursor-pointer"
                            >
                              <div className="flex items-center gap-2">
                                <TrendingUp size={13} className="text-amber-400" />
                                <span>النفقات اليومية</span>
                              </div>
                              <ChevronLeft size={12} className="text-slate-500" />
                            </button>

                            <button
                              type="button"
                              onClick={() => handleProjectQuickNav(proj.id, 'boq')}
                              className="w-full px-2 py-1.5 rounded-md text-right flex items-center justify-between text-slate-300 hover:text-white hover:bg-slate-800/60 transition-colors cursor-pointer"
                            >
                              <div className="flex items-center gap-2">
                                <FileSpreadsheet size={13} className="text-teal-400" />
                                <span>جدول الكميات وبنود العقد</span>
                              </div>
                              <ChevronLeft size={12} className="text-slate-500" />
                            </button>

                            <button
                              type="button"
                              onClick={() => handleProjectQuickNav(proj.id, 'workers')}
                              className="w-full px-2 py-1.5 rounded-md text-right flex items-center justify-between text-slate-300 hover:text-white hover:bg-slate-800/60 transition-colors cursor-pointer"
                            >
                              <div className="flex items-center gap-2">
                                <Users size={13} className="text-amber-400" />
                                <span>العمال وكشف الحساب</span>
                              </div>
                              <ChevronLeft size={12} className="text-slate-500" />
                            </button>

                            <button
                              type="button"
                              onClick={() => handleProjectQuickNav(proj.id, 'employees')}
                              className="w-full px-2 py-1.5 rounded-md text-right flex items-center justify-between text-slate-300 hover:text-white hover:bg-slate-800/60 transition-colors cursor-pointer"
                            >
                              <div className="flex items-center gap-2">
                                <Briefcase size={13} className="text-amber-400" />
                                <span>الموظفين والأجور</span>
                              </div>
                              <ChevronLeft size={12} className="text-slate-500" />
                            </button>

                            <button
                              type="button"
                              onClick={() => handleProjectQuickNav(proj.id, 'suppliers')}
                              className="w-full px-2 py-1.5 rounded-md text-right flex items-center justify-between text-slate-300 hover:text-white hover:bg-slate-800/60 transition-colors cursor-pointer"
                            >
                              <div className="flex items-center gap-2">
                                <Truck size={13} className="text-amber-400" />
                                <span>الموردين والمشتريات</span>
                              </div>
                              <ChevronLeft size={12} className="text-slate-500" />
                            </button>

                            <button
                              type="button"
                              onClick={() => handleProjectQuickNav(proj.id, 'budget')}
                              className="w-full px-2 py-1.5 rounded-md text-right flex items-center justify-between text-slate-300 hover:text-white hover:bg-slate-800/60 transition-colors cursor-pointer"
                            >
                              <div className="flex items-center gap-2">
                                <Wallet size={13} className="text-amber-400" />
                                <span>الميزانية العامة والصندوق</span>
                              </div>
                              <ChevronLeft size={12} className="text-slate-500" />
                            </button>

                            <button
                              type="button"
                              onClick={() => handleProjectQuickNav(proj.id, 'debts')}
                              className="w-full px-2 py-1.5 rounded-md text-right flex items-center justify-between text-slate-300 hover:text-white hover:bg-slate-800/60 transition-colors cursor-pointer"
                            >
                              <div className="flex items-center gap-2">
                                <Coins size={13} className="text-amber-400" />
                                <span>الديون والالتزامات المستحقة</span>
                              </div>
                              <ChevronLeft size={12} className="text-slate-500" />
                            </button>

                            <button
                              type="button"
                              onClick={() => handleProjectQuickNav(proj.id, 'reports')}
                              className="w-full px-2 py-1.5 rounded-md text-right flex items-center justify-between text-slate-300 hover:text-white hover:bg-slate-800/60 transition-colors cursor-pointer"
                            >
                              <div className="flex items-center gap-2">
                                <FileText size={13} className="text-amber-400" />
                                <span>التقارير المالية الشاملة</span>
                              </div>
                              <ChevronLeft size={12} className="text-slate-500" />
                            </button>

                            <button
                              type="button"
                              onClick={() => handleProjectQuickNav(proj.id, 'backup')}
                              className="w-full px-2 py-1.5 rounded-md text-right flex items-center justify-between text-slate-300 hover:text-white hover:bg-slate-800/60 transition-colors cursor-pointer"
                            >
                              <div className="flex items-center gap-2">
                                <Database size={13} className="text-amber-400" />
                                <span>النسخ الاحتياطي للمشروع</span>
                              </div>
                              <ChevronLeft size={12} className="text-slate-500" />
                            </button>
                          </div>
                        )}
                      </div>
                    );
                  })
                )}
              </div>
            )}
          </div>

          {/* 3: مواد وأصول الشركة */}
          <button
            type="button"
            onClick={() => {
              onNavigate('company_assets');
              onClose();
            }}
            className={getItemClassName(activeTab === 'company_assets')}
            id="drawer-group-3-company-assets-btn"
          >
            <div className="flex items-center gap-2.5">
              <Boxes size={17} className={activeTab === 'company_assets' ? 'text-slate-950' : 'text-amber-400'} />
              <span>مواد وأصول الشركة</span>
            </div>
            <ChevronLeft size={15} className={activeTab === 'company_assets' ? 'text-slate-950' : 'text-slate-500'} />
          </button>

          {/* 4: الديون والالتزامات العامة للشركة */}
          <button
            type="button"
            onClick={() => {
              onNavigate('general_debts');
              onClose();
            }}
            className={getItemClassName(activeTab === 'general_debts')}
            id="drawer-group-4-general-debts-btn"
          >
            <div className="flex items-center gap-2.5">
              <Coins size={17} className={activeTab === 'general_debts' ? 'text-slate-950' : 'text-amber-400'} />
              <span>الديون والالتزامات العامة للشركة</span>
            </div>
            <ChevronLeft size={15} className={activeTab === 'general_debts' ? 'text-slate-950' : 'text-slate-500'} />
          </button>

          {/* 5: تقييم الأداء */}
          <button
            type="button"
            onClick={() => {
              onNavigate('evaluations');
              onClose();
            }}
            className={getItemClassName(activeTab === 'evaluations')}
            id="drawer-group-5-evaluations-btn"
          >
            <div className="flex items-center gap-2.5">
              <Award size={17} className={activeTab === 'evaluations' ? 'text-slate-950' : 'text-amber-400'} />
              <span>تقييم الأداء والتميز</span>
            </div>
            <ChevronLeft size={15} className={activeTab === 'evaluations' ? 'text-slate-950' : 'text-slate-500'} />
          </button>

          {/* 6: إدارة النسخ الاحتياطي الشامل واستعادة كافة بيانات التطبيق */}
          <button
            type="button"
            onClick={() => {
              if (onOpenGlobalBackup) {
                onOpenGlobalBackup();
              } else {
                onNavigate('backup');
              }
              onClose();
            }}
            className={getItemClassName(false)}
            id="drawer-group-6-backup-btn"
          >
            <div className="flex items-center gap-2.5">
              <Database size={17} className="text-amber-400" />
              <span>إدارة النسخ الاحتياطي الشامل واستعادة كافة بيانات التطبيق</span>
            </div>
            <ChevronLeft size={15} className="text-slate-500" />
          </button>

          {/* 6.5: التراجع واسترجاع العمليات السابقة */}
          {onOpenUndo && (
            <button
              type="button"
              onClick={() => {
                onOpenUndo();
                onClose();
              }}
              className={getItemClassName(false)}
              id="drawer-group-undo-btn"
            >
              <div className="flex items-center gap-2.5">
                <RotateCcw size={17} className="text-amber-400" />
                <span>سجل التراجع واسترجاع العمليات</span>
              </div>
              <div className="flex items-center gap-2">
                {undoCount > 0 && (
                  <span className="text-[10px] font-black bg-amber-500 text-slate-950 px-2 py-0.5 rounded-full">
                    {undoCount}
                  </span>
                )}
                <ChevronLeft size={15} className="text-slate-500" />
              </div>
            </button>
          )}

          {/* 7: التبديل بين الوضع الداكن والفاتح */}
          {onToggleTheme && (
            <button
              type="button"
              onClick={() => {
                onToggleTheme();
              }}
              className={getItemClassName(false)}
              id="drawer-group-theme-toggle-btn"
            >
              <div className="flex items-center gap-2.5">
                {theme === 'dark' ? (
                  <Sun size={17} className="text-amber-400 animate-spin-slow" />
                ) : (
                  <Moon size={17} className="text-amber-300" />
                )}
                <span>{theme === 'dark' ? 'التبديل إلى الوضع الفاتح' : 'التبديل إلى الوضع الداكن'}</span>
              </div>
              <span className={`text-[11px] font-bold px-2 py-0.5 rounded-md ${theme === 'dark' ? 'bg-amber-400/20 text-amber-300' : 'bg-slate-800 text-slate-300'}`}>
                {theme === 'dark' ? '☀️ فعال' : '🌙 غير مفعّل'}
              </span>
            </button>
          )}

          {/* تثبيت التطبيق على هاتف أندرويد */}
          {onOpenAndroidInstall && (
            <button
              type="button"
              onClick={() => {
                onOpenAndroidInstall();
                onClose();
              }}
              className="w-full px-3 py-2.5 rounded-xl text-right flex items-center justify-between gap-3 bg-emerald-950/40 text-emerald-300 hover:bg-emerald-900/50 hover:text-white border border-emerald-500/30 transition-colors cursor-pointer text-xs sm:text-sm font-bold shadow-xs"
              id="drawer-group-android-install-btn"
            >
              <div className="flex items-center gap-2.5">
                <Smartphone size={17} className="text-emerald-400" />
                <span>تثبيت التطبيق على هاتف أندرويد (APK)</span>
              </div>
              <span className="text-[10px] bg-emerald-500 text-slate-950 font-black px-2 py-0.5 rounded-full">
                بدون نت 📲
              </span>
            </button>
          )}

          {/* 8: ضبط وإعدادات التطبيق */}
          <button
            type="button"
            onClick={() => {
              onOpenSettings();
              onClose();
            }}
            className={getItemClassName(false)}
            id="drawer-group-7-settings-btn"
          >
            <div className="flex items-center gap-2.5">
              <Settings size={17} className="text-amber-400" />
              <span>ضبط وإعدادات التطبيق</span>
            </div>
            <ChevronLeft size={15} className="text-slate-500" />
          </button>

          {/* 9: معلومات عن التطبيق */}
          <button
            type="button"
            onClick={() => {
              onOpenAppInfo();
              onClose();
            }}
            className={getItemClassName(false)}
            id="drawer-group-9-app-info-btn"
          >
            <div className="flex items-center gap-2.5">
              <Info size={17} className="text-amber-400" />
              <span>معلومات التطبيق والمصمم</span>
            </div>
            <ChevronLeft size={15} className="text-slate-500" />
          </button>

          {/* 9: الخروج النهائي (Distinct rose styling) */}
          <div className="pt-2 border-t border-slate-800 mt-2">
            <button
              type="button"
              onClick={() => {
                onExitApp();
                onClose();
              }}
              className="w-full px-3 py-2.5 rounded-xl text-right flex items-center justify-between gap-3 text-rose-400 hover:bg-rose-950/40 hover:text-rose-300 transition-colors cursor-pointer text-xs sm:text-sm font-bold"
              id="drawer-group-8-exit-app-btn"
            >
              <div className="flex items-center gap-2.5">
                <LogOut size={17} className="text-rose-400" />
                <span>الخروج النهائي من التطبيق</span>
              </div>
              <ChevronLeft size={15} className="text-rose-500/70" />
            </button>
          </div>

        </div>

        {/* Drawer Footer info */}
        <div className="p-3 bg-slate-950 border-t border-slate-800 text-center text-xs text-slate-400 shrink-0">
          <div className="flex items-center justify-between text-[11px]">
            <span className="text-slate-400 font-medium">الحسابات وإدارة المشاريع</span>
            <span className="text-amber-400 font-mono font-bold">v3.5</span>
          </div>
        </div>

      </div>
    </div>
  );
}
