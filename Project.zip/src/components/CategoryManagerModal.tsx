/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  X, 
  Plus, 
  Pencil, 
  Trash2, 
  Check, 
  RotateCcw, 
  Tag, 
  AlertCircle,
  FolderCog
} from 'lucide-react';
import { useBodyScrollLock } from '../utils/modalScrollLock';

export interface ManagedCategoryItem {
  id: string;
  name: string;
  isDefault?: boolean;
  color?: string;
  count?: number;
}

interface CategoryManagerModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  subtitle?: string;
  categories: ManagedCategoryItem[];
  onAddCategory: (name: string, color?: string) => { success: boolean; message?: string };
  onEditCategory: (item: ManagedCategoryItem, newName: string, color?: string) => { success: boolean; message?: string };
  onDeleteCategory: (item: ManagedCategoryItem) => { success: boolean; message?: string };
  onResetDefaults?: () => void;
  showColorPicker?: boolean;
  colorPalette?: string[];
  entityUnitLabel?: string; // e.g. "عملية", "صنف", "مصروف"
}

const DEFAULT_PALETTE = [
  '#0284c7', '#059669', '#d97706', '#b91c1c', '#7c3aed',
  '#ea580c', '#4f46e5', '#06b6d4', '#ec4899', '#14b8a6',
  '#64748b', '#84cc16'
];

export const CategoryManagerModal: React.FC<CategoryManagerModalProps> = ({
  isOpen,
  onClose,
  title,
  subtitle,
  categories,
  onAddCategory,
  onEditCategory,
  onDeleteCategory,
  onResetDefaults,
  showColorPicker = false,
  colorPalette = DEFAULT_PALETTE,
  entityUnitLabel = 'سجل'
}) => {
  useBodyScrollLock(isOpen);

  // Add state
  const [newName, setNewName] = useState('');
  const [newColor, setNewColor] = useState(colorPalette[0] || '#0284c7');
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  // Edit state
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editName, setEditName] = useState('');
  const [editColor, setEditColor] = useState('');

  // Delete & Reset confirmations (no window.confirm, 100% iframe-safe)
  const [deletingCat, setDeletingCat] = useState<ManagedCategoryItem | null>(null);
  const [confirmReset, setConfirmReset] = useState(false);

  if (!isOpen) return null;

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');
    setDeletingCat(null);

    if (!newName.trim()) {
      setErrorMsg('الرجاء كتابة اسم الفئة أو الخيار.');
      return;
    }

    const res = onAddCategory(newName.trim(), showColorPicker ? newColor : undefined);
    if (!res.success) {
      setErrorMsg(res.message || 'تعذر إضافة الفئة.');
    } else {
      setNewName('');
      setSuccessMsg('تمت إضافة الفئة بنجاح.');
      setTimeout(() => setSuccessMsg(''), 3000);
    }
  };

  const startEdit = (cat: ManagedCategoryItem) => {
    setEditingId(cat.id);
    setEditName(cat.name);
    setEditColor(cat.color || colorPalette[0] || '#0284c7');
    setErrorMsg('');
    setSuccessMsg('');
    setDeletingCat(null);
  };

  const cancelEdit = () => {
    setEditingId(null);
    setEditName('');
    setEditColor('');
  };

  const saveEdit = (cat: ManagedCategoryItem) => {
    setErrorMsg('');
    setSuccessMsg('');

    if (!editName.trim()) {
      setErrorMsg('الرجاء كتابة اسم الفئة الجديد.');
      return;
    }

    const res = onEditCategory(cat, editName.trim(), showColorPicker ? editColor : undefined);
    if (!res.success) {
      setErrorMsg(res.message || 'تعذر تعديل الفئة.');
    } else {
      setEditingId(null);
      setSuccessMsg('تم حفظ التعديل وتحديث السجلات المرتبطة بنجاح.');
      setTimeout(() => setSuccessMsg(''), 3000);
    }
  };

  const promptDelete = (cat: ManagedCategoryItem) => {
    setErrorMsg('');
    setSuccessMsg('');
    setEditingId(null);
    setDeletingCat(cat);
  };

  const confirmDelete = () => {
    if (!deletingCat) return;
    const cat = deletingCat;
    setErrorMsg('');
    setSuccessMsg('');

    const res = onDeleteCategory(cat);
    if (!res.success) {
      setErrorMsg(res.message || 'تعذر حذف الفئة.');
    } else {
      setDeletingCat(null);
      setSuccessMsg(`تم حذف "${cat.name}" بنجاح.`);
      setTimeout(() => setSuccessMsg(''), 3000);
    }
  };

  return (
    <div 
      className="fixed inset-0 z-[160] bg-slate-950/75 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto dir-rtl text-right animate-fade-in"
      onClick={onClose}
    >
      <div 
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-lg bg-white rounded-3xl border border-slate-200 shadow-2xl overflow-hidden my-auto flex flex-col max-h-[92vh] sm:max-h-[88vh]"
      >
        {/* Header */}
        <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 px-5 py-4 text-white flex items-center justify-between shrink-0 shadow-sm border-b border-slate-700">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-amber-500/20 text-amber-400 rounded-xl border border-amber-500/30">
              <FolderCog size={20} />
            </div>
            <div>
              <h3 className="text-base font-black tracking-tight">{title}</h3>
              {subtitle && <p className="text-[11px] text-slate-300 mt-0.5">{subtitle}</p>}
            </div>
          </div>
          <button 
            type="button" 
            onClick={onClose}
            className="p-1.5 text-white/70 hover:text-white rounded-xl hover:bg-white/10 transition-colors cursor-pointer"
            title="إغلاق"
          >
            <X size={18} />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 overflow-y-auto space-y-4 flex-1 custom-scrollbar">

          {/* Messages */}
          {errorMsg && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 text-xs font-bold flex items-center gap-2 animate-fade-in">
              <AlertCircle size={15} className="shrink-0 text-rose-600" />
              <span>{errorMsg}</span>
            </div>
          )}

          {successMsg && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 text-xs font-bold flex items-center gap-2 animate-fade-in">
              <Check size={15} className="shrink-0 text-emerald-600" />
              <span>{successMsg}</span>
            </div>
          )}

          {/* Add Section */}
          <form onSubmit={handleAdd} className="p-3.5 bg-slate-50 border border-slate-200 rounded-2xl space-y-2.5">
            <label className="text-xs font-extrabold text-slate-700 flex items-center gap-1.5">
              <Plus size={14} className="text-amber-600" />
              <span>إضافة خيار / فئة جديدة</span>
            </label>

            <div className="flex items-center gap-2">
              <input 
                type="text"
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                placeholder="اكتب اسم الفئة الجديدة هنا..."
                className="flex-1 h-10 px-3 bg-white border border-slate-200 rounded-xl text-xs sm:text-sm font-bold text-slate-800 focus:outline-hidden focus:border-amber-500 shadow-2xs"
                maxLength={60}
              />

              <button
                type="submit"
                className="h-10 px-4 bg-amber-600 hover:bg-amber-700 active:scale-95 text-white rounded-xl text-xs font-black shadow-xs transition-all flex items-center gap-1 cursor-pointer shrink-0"
              >
                <Plus size={14} />
                <span>إضافة</span>
              </button>
            </div>

            {/* Optional Color Picker for categories */}
            {showColorPicker && (
              <div className="pt-2 border-t border-slate-200/60 flex items-center gap-2 flex-wrap">
                <span className="text-[11px] text-slate-500 font-bold shrink-0">اللون المميز:</span>
                <div className="flex items-center gap-1.5 flex-wrap">
                  {colorPalette.map(c => (
                    <button
                      key={c}
                      type="button"
                      onClick={() => setNewColor(c)}
                      className={`w-5 h-5 rounded-full transition-transform cursor-pointer border ${
                        newColor === c ? 'ring-2 ring-slate-800 ring-offset-1 scale-110 border-white' : 'border-black/10'
                      }`}
                      style={{ backgroundColor: c }}
                    />
                  ))}
                </div>
              </div>
            )}
          </form>

          {/* Inline Delete Confirmation Banner */}
          {deletingCat && (
            <div className="p-3 bg-rose-50 border-2 border-rose-300 rounded-2xl space-y-2 animate-fade-in shadow-xs">
              <div className="flex items-start gap-2 text-xs font-bold text-rose-900">
                <AlertCircle size={16} className="text-rose-600 shrink-0 mt-0.5" />
                <div className="flex-1 leading-relaxed">
                  هل أنت متأكد من حذف الفئة <span className="font-black text-rose-950 underline">"{deletingCat.name}"</span>؟
                  {deletingCat.count !== undefined && deletingCat.count > 0 && (
                    <span className="block mt-1 text-[11px] text-rose-700 font-extrabold">
                      ⚠️ تنبيه: يوجد ({deletingCat.count} {entityUnitLabel}) مرتبط بهذه الفئة حالياً في السجلات.
                    </span>
                  )}
                </div>
              </div>
              <div className="flex items-center justify-end gap-2 pt-1 border-t border-rose-200">
                <button
                  type="button"
                  onClick={() => setDeletingCat(null)}
                  className="px-3 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold text-xs rounded-xl cursor-pointer transition-colors"
                >
                  إلغاء
                </button>
                <button
                  type="button"
                  onClick={confirmDelete}
                  className="px-3.5 py-1.5 bg-rose-600 hover:bg-rose-700 text-white font-extrabold text-xs rounded-xl shadow-xs cursor-pointer transition-colors flex items-center gap-1.5 active:scale-95"
                >
                  <Trash2 size={13} />
                  <span>نعم، تأكيد الحذف</span>
                </button>
              </div>
            </div>
          )}

          {/* Existing Categories List */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs font-extrabold text-slate-700 px-1">
              <span className="flex items-center gap-1.5">
                <Tag size={13} className="text-slate-500" />
                <span>الفئات والخيارات الحالية ({categories.length})</span>
              </span>
              <span className="text-[10px] text-slate-400 font-normal">
                (يمكنك تعديل المسمى أو الحذف)
              </span>
            </div>

            <div className="border border-slate-200 rounded-2xl overflow-hidden divide-y divide-slate-100 max-h-72 overflow-y-auto bg-white shadow-2xs custom-scrollbar">
              {categories.length === 0 ? (
                <div className="p-6 text-center text-xs text-slate-400">
                  لا توجد فئات حالياً، يمكنك إضافة فئة جديدة بالأعلى.
                </div>
              ) : (
                categories.map((cat) => {
                  const isEditing = editingId === cat.id;

                  return (
                    <div 
                      key={cat.id}
                      className={`p-3 transition-colors ${
                        isEditing ? 'bg-amber-50/70' : 'hover:bg-slate-50/70'
                      }`}
                    >
                      {isEditing ? (
                        <div className="space-y-2">
                          <div className="flex items-center gap-2">
                            <input 
                              type="text"
                              value={editName}
                              onChange={(e) => setEditName(e.target.value)}
                              className="flex-1 h-9 px-2.5 bg-white border border-amber-400 rounded-lg text-xs font-bold text-slate-800 focus:outline-hidden"
                              autoFocus
                            />

                            <button
                              type="button"
                              onClick={() => saveEdit(cat)}
                              className="h-9 px-3 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white rounded-lg text-xs font-bold flex items-center gap-1 shadow-2xs cursor-pointer"
                              title="حفظ التعديل"
                            >
                              <Check size={14} />
                              <span>حفظ</span>
                            </button>

                            <button
                              type="button"
                              onClick={cancelEdit}
                              className="h-9 px-2.5 bg-slate-200 hover:bg-slate-300 active:scale-95 text-slate-700 rounded-lg text-xs font-bold flex items-center gap-1 cursor-pointer"
                              title="إلغاء التعديل"
                            >
                              <X size={14} />
                            </button>
                          </div>

                          {showColorPicker && (
                            <div className="flex items-center gap-1.5 flex-wrap pt-1">
                              <span className="text-[10px] text-slate-500 font-bold">تغيير اللون:</span>
                              {colorPalette.map(c => (
                                <button
                                  key={c}
                                  type="button"
                                  onClick={() => setEditColor(c)}
                                  className={`w-4 h-4 rounded-full transition-transform cursor-pointer border ${
                                    editColor === c ? 'ring-2 ring-slate-800 ring-offset-1 scale-110 border-white' : 'border-black/10'
                                  }`}
                                  style={{ backgroundColor: c }}
                                />
                              ))}
                            </div>
                          )}
                        </div>
                      ) : (
                        <div className="flex items-center justify-between gap-2">
                          <div className="flex items-center gap-2 min-w-0">
                            {cat.color && (
                              <span 
                                className="w-2.5 h-2.5 rounded-full shrink-0 shadow-2xs" 
                                style={{ backgroundColor: cat.color }} 
                              />
                            )}
                            <span className="font-extrabold text-xs text-slate-800 truncate">
                              {cat.name}
                            </span>
                            {cat.count !== undefined && (
                              <span className="text-[10px] font-bold px-1.5 py-0.2 rounded-md bg-slate-100 text-slate-600 shrink-0">
                                {cat.count} {entityUnitLabel}
                              </span>
                            )}
                          </div>

                          <div className="flex items-center gap-1 shrink-0">
                            <button
                              type="button"
                              onClick={() => startEdit(cat)}
                              className="p-1.5 text-slate-500 hover:text-amber-700 hover:bg-amber-100/60 rounded-lg transition-colors cursor-pointer"
                              title="تعديل اسم الفئة"
                            >
                              <Pencil size={13} />
                            </button>

                            <button
                              type="button"
                              onClick={() => promptDelete(cat)}
                              className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                              title="حذف الفئة"
                            >
                              <Trash2 size={13} />
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })
              )}
            </div>
          </div>

        </div>

        {/* Footer */}
        <div className="bg-slate-50 px-5 py-3 border-t border-slate-200 flex items-center justify-between shrink-0">
          {onResetDefaults ? (
            confirmReset ? (
              <div className="flex items-center gap-2 animate-fade-in">
                <span className="text-[11px] font-bold text-slate-700">استعادة الافتراضي؟</span>
                <button
                  type="button"
                  onClick={() => {
                    onResetDefaults();
                    setConfirmReset(false);
                    setSuccessMsg('تمت استعادة الفئات الافتراضية بنجاح.');
                    setTimeout(() => setSuccessMsg(''), 3000);
                  }}
                  className="px-2.5 py-1 bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs rounded-lg cursor-pointer"
                >
                  تأكيد
                </button>
                <button
                  type="button"
                  onClick={() => setConfirmReset(false)}
                  className="px-2 py-1 bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold text-xs rounded-lg cursor-pointer"
                >
                  إلغاء
                </button>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => setConfirmReset(true)}
                className="text-xs font-bold text-slate-500 hover:text-slate-800 flex items-center gap-1.5 cursor-pointer transition-colors"
                title="استعادة القائمة الأساسية الافتراضية"
              >
                <RotateCcw size={13} />
                <span>استعادة الافتراضي</span>
              </button>
            )
          ) : <div />}

          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold text-xs rounded-xl transition-colors cursor-pointer"
          >
            إغلاق
          </button>
        </div>

      </div>
    </div>
  );
};

export default CategoryManagerModal;
