/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo, useCallback } from 'react';
import PageHeaderCard from './PageHeaderCard';
import { AmountInWords } from './AmountInWords';
import { 
  PlusCircle, 
  Trash2, 
  Wallet, 
  TrendingUp, 
  ArrowUpRight, 
  Search, 
  Calendar,
  DollarSign,
  AlertTriangle,
  FileSpreadsheet,
  FileText,
  ArrowLeft,
  Pencil,
  RotateCcw,
  Filter,
  X,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { 
  BudgetItem, 
  Expense, 
  Worker,
  Employee,
  Supplier,
  formatCurrency, 
  formatDateArabic,
  exportToCSV,
  exportToXLSX,
  printPDF
} from '../types';
import * as XLSX from 'xlsx';
import AttributionBadge from './AttributionBadge';
import Calculator from './Calculator';
import ShareMenu from './ShareMenu';
import OptionsMenu from './OptionsMenu';
import { useBodyScrollLock } from '../utils/modalScrollLock';
import ExcelColumnFilter, { ColumnFilterConfig, ActiveColumnFilter, ColumnSortState } from './ExcelColumnFilter';

interface BudgetProps {
  budget: BudgetItem[];
  expenses: Expense[];
  onAddBudgetItem: (item: Omit<BudgetItem, 'id'>) => void;
  onDeleteBudgetItem: (id: string) => void;
  onUpdateBudgetItem?: (id: string, updatedData: Omit<BudgetItem, 'id' | 'createdBy'>) => void;
  setActiveTab?: (tab: string) => void;
  currency?: string;
  workers?: Worker[];
  employees?: Employee[];
  suppliers?: Supplier[];
  sharedRole?: string;
}

export default function Budget({
  budget,
  expenses,
  onAddBudgetItem,
  onDeleteBudgetItem,
  onUpdateBudgetItem,
  setActiveTab,
  currency = 'YER',
  workers = [],
  employees = [],
  suppliers = [],
  sharedRole = 'admin'
}: BudgetProps) {
  
  // Local states for add form
  const [date, setDate] = useState(() => {
    const today = new Date();
    return today.toISOString().split('T')[0];
  });

  // Edit states for budget item
  const [editingBudgetItem, setEditingBudgetItem] = useState<BudgetItem | null>(null);

  // Lock background scroll when budget modal is open
  useBodyScrollLock(Boolean(editingBudgetItem));

  // Submit handler for edit budget item
  const handleEditBudgetItemSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingBudgetItem) return;
    if (onUpdateBudgetItem) {
      onUpdateBudgetItem(editingBudgetItem.id, {
        date: editingBudgetItem.date,
        description: editingBudgetItem.description,
        amount: editingBudgetItem.amount,
        currency: editingBudgetItem.currency || 'YER',
        notes: editingBudgetItem.notes || ''
      });
    }
    setEditingBudgetItem(null);
  };
  const [showAddFundingForm, setShowAddFundingForm] = useState(false);
  const [amount, setAmount] = useState('');
  const [description, setDescription] = useState('');
  const [notes, setNotes] = useState('');
  const [itemCurrency, setItemCurrency] = useState(currency);

  // Search filter & advanced filters
  const [searchTerm, setSearchTerm] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [currencyFilter, setCurrencyFilter] = useState('all');
  const [sortOption, setSortOption] = useState<'date-desc' | 'date-asc' | 'amount-desc' | 'amount-asc' | 'desc-alpha'>('date-desc');
  const [isFiltersExpanded, setIsFiltersExpanded] = useState(false);

  // Column filters & column sort
  const [columnFilters, setColumnFilters] = useState<Record<string, ActiveColumnFilter>>({});
  const [columnSort, setColumnSort] = useState<ColumnSortState | null>(null);

  // Alerts
  const [errorMsg, setErrorMsg] = useState('');

  // Keep item currency in sync with global currency selection when prop changes
  useEffect(() => {
    setItemCurrency(currency);
  }, [currency]);

  // Totals calculations per currency
  const activeCurrencies = ['YER', 'SAR', 'USD'];

  const fundingByCurrency = budget.reduce((acc, item) => {
    const cur = item.currency || 'YER';
    acc[cur] = (acc[cur] || 0) + item.amount;
    return acc;
  }, {} as Record<string, number>);

  const expensesByCurrency = expenses.reduce((acc, exp) => {
    const cur = exp.currency || 'YER';
    acc[cur] = (acc[cur] || 0) + exp.amount;
    return acc;
  }, {} as Record<string, number>);

  // Company Debts = Workers Net (For - On) + Employees Net (For - On) + Suppliers Net (For - On) + External Debts
  const workerDebtsByCurrency = workers.reduce((acc, w) => {
    const balances = w.ledger.reduce((lAcc, entry) => {
      const cur = entry.currency || 'YER';
      if (!lAcc[cur]) lAcc[cur] = { onHim: 0, forHim: 0 };
      lAcc[cur].onHim += entry.amountOnHim || 0;
      lAcc[cur].forHim += entry.amountForHim || 0;
      return lAcc;
    }, {} as Record<string, { onHim: number; forHim: number }>);

    Object.entries(balances).forEach(([cur, val]) => {
      const net = val.forHim - val.onHim;
      if (net > 0) {
        acc[cur] = (acc[cur] || 0) + net;
      }
    });
    return acc;
  }, {} as Record<string, number>);

  const employeeDebtsByCurrency = employees.reduce((acc, e) => {
    const balances = e.ledger.reduce((lAcc, entry) => {
      const cur = entry.currency || 'YER';
      if (!lAcc[cur]) lAcc[cur] = { onHim: 0, forHim: 0 };
      lAcc[cur].onHim += entry.amountOnHim || 0;
      lAcc[cur].forHim += entry.amountForHim || 0;
      return lAcc;
    }, {} as Record<string, { onHim: number; forHim: number }>);

    Object.entries(balances).forEach(([cur, val]) => {
      const net = val.forHim - val.onHim;
      if (net > 0) {
        acc[cur] = (acc[cur] || 0) + net;
      }
    });
    return acc;
  }, {} as Record<string, number>);

  const supplierDebtsByCurrency = suppliers.reduce((acc, s) => {
    const balances = s.ledger.reduce((lAcc, entry) => {
      const cur = entry.currency || 'YER';
      if (!lAcc[cur]) lAcc[cur] = { onHim: 0, forHim: 0 };
      lAcc[cur].onHim += entry.amountOnHim || 0;
      lAcc[cur].forHim += entry.amountForHim || 0;
      return lAcc;
    }, {} as Record<string, { onHim: number; forHim: number }>);

    Object.entries(balances).forEach(([cur, val]) => {
      const net = val.forHim - val.onHim;
      if (net > 0) {
        acc[cur] = (acc[cur] || 0) + net;
      }
    });
    return acc;
  }, {} as Record<string, number>);

  const externalDebtsByCurrency = (() => {
    try {
      const saved = localStorage.getItem('site_external_debts');
      if (!saved) return {};
      const extAccounts = JSON.parse(saved);
      if (!Array.isArray(extAccounts)) return {};
      return extAccounts.reduce((acc: Record<string, number>, ext: any) => {
        const balances: Record<string, { forHim: number; onHim: number }> = {};
        (ext.ledger || []).forEach((entry: any) => {
          const cur = entry.currency || 'YER';
          if (!balances[cur]) balances[cur] = { forHim: 0, onHim: 0 };
          balances[cur].forHim += entry.amountForHim || 0;
          balances[cur].onHim += entry.amountOnHim || 0;
        });
        Object.entries(balances).forEach(([cur, val]) => {
          const net = val.forHim - val.onHim;
          if (net > 0) {
            acc[cur] = (acc[cur] || 0) + net;
          }
        });
        return acc;
      }, {});
    } catch (e) {
      return {};
    }
  })();

  const debtsByCurrency = {} as Record<string, number>;
  activeCurrencies.forEach(cur => {
    const totalDebts = (workerDebtsByCurrency[cur] || 0) + 
                       (employeeDebtsByCurrency[cur] || 0) + 
                       (supplierDebtsByCurrency[cur] || 0) + 
                       (externalDebtsByCurrency[cur] || 0);
    if (totalDebts > 0) {
      debtsByCurrency[cur] = totalDebts;
    }
  });

  const remainingByCurrency = {} as Record<string, number>;
  activeCurrencies.forEach(cur => {
    remainingByCurrency[cur] = (fundingByCurrency[cur] || 0) - (expensesByCurrency[cur] || 0);
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    const parsedAmount = parseFloat(amount);
    if (isNaN(parsedAmount) || parsedAmount <= 0) {
      setErrorMsg('الرجاء إدخال مبلغ تمويل صحيح أكبر من الصفر.');
      return;
    }

    if (!description.trim()) {
      setErrorMsg('الرجاء إدخال بيان عملية التمويل.');
      return;
    }

    onAddBudgetItem({
      date,
      amount: parsedAmount,
      description: description.trim(),
      notes: notes.trim(),
      currency: itemCurrency
    });

    // Reset Form
    setAmount('');
    setDescription('');
    setNotes('');
    setShowAddFundingForm(false);
  };

  const handleResetAddFundingForm = () => {
    setDate(new Date().toISOString().split('T')[0]);
    setAmount('');
    setDescription('');
    setNotes('');
    setItemCurrency(currency);
    setErrorMsg('');
  };

  // Column filter configs for the budget table
  const columnConfigs: Record<string, ColumnFilterConfig<BudgetItem>> = useMemo(() => ({
    date: {
      key: 'date',
      title: 'التاريخ',
      sortType: 'date',
      getValue: (item) => item.date,
      getDisplayValue: (val) => formatDateArabic(String(val))
    },
    description: {
      key: 'description',
      title: 'البيان (المصدر)',
      sortType: 'string',
      getValue: (item) => item.description
    },
    amount: {
      key: 'amount',
      title: 'المبلغ والعملة',
      sortType: 'number',
      getValue: (item) => item.amount,
      getDisplayValue: (val) => formatCurrency(Number(val), currency)
    },
    notes: {
      key: 'notes',
      title: 'ملاحظات',
      sortType: 'string',
      getValue: (item) => item.notes || ''
    }
  }), [currency]);

  const handleColumnFilterChange = useCallback((colKey: string, filter: ActiveColumnFilter | null) => {
    setColumnFilters(prev => {
      const next = { ...prev };
      if (!filter || !filter.selectedValues || filter.selectedValues.length === 0) {
        delete next[colKey];
      } else {
        next[colKey] = filter;
      }
      return next;
    });
  }, []);

  const handleColumnSortChange = useCallback((sort: ColumnSortState | null) => {
    setColumnSort(sort);
  }, []);

  const handleClearAllColumnFilters = useCallback(() => {
    setColumnFilters({});
    setColumnSort(null);
  }, []);

  const handleResetAllFilters = useCallback(() => {
    setSearchTerm('');
    setStartDate('');
    setEndDate('');
    setCurrencyFilter('all');
    setSortOption('date-desc');
    setColumnFilters({});
    setColumnSort(null);
  }, []);

  // 1. Base filtered by search, date range, and currency dropdown
  const baseFilteredBudget = useMemo(() => {
    return budget.filter(item => {
      // Search term
      if (searchTerm.trim()) {
        const term = searchTerm.trim().toLowerCase();
        const matchDesc = (item.description || '').toLowerCase().includes(term);
        const matchNotes = (item.notes || '').toLowerCase().includes(term);
        const matchAmt = String(item.amount).includes(term);
        if (!matchDesc && !matchNotes && !matchAmt) return false;
      }
      // Date range
      if (startDate && item.date < startDate) return false;
      if (endDate && item.date > endDate) return false;
      // Currency filter
      if (currencyFilter !== 'all') {
        const cur = item.currency || currency || 'YER';
        if (cur !== currencyFilter) return false;
      }
      return true;
    });
  }, [budget, searchTerm, startDate, endDate, currencyFilter, currency]);

  // 2. Filtered by ExcelColumnFilter column filters
  const filteredBudget = useMemo(() => {
    let result = baseFilteredBudget;
    Object.entries(columnFilters).forEach(([colKey, activeFilter]) => {
      if (!activeFilter || !activeFilter.selectedValues || activeFilter.selectedValues.length === 0) return;
      const cfg = columnConfigs[colKey];
      if (!cfg) return;
      result = result.filter(item => {
        const rawVal = cfg.getValue(item);
        const valStr = rawVal === null || rawVal === undefined ? '' : String(rawVal);
        return activeFilter.selectedValues.includes(valStr);
      });
    });
    return result;
  }, [baseFilteredBudget, columnFilters, columnConfigs]);

  // 3. Sorted budget items (supports column header click sorting or toolbar sorting)
  const sortedBudget = useMemo(() => {
    const list = [...filteredBudget];
    if (columnSort) {
      const cfg = columnConfigs[columnSort.key];
      if (cfg) {
        list.sort((a, b) => {
          const valA = cfg.getValue(a);
          const valB = cfg.getValue(b);
          let cmp = 0;
          if (cfg.sortType === 'number') {
            cmp = (Number(valA) || 0) - (Number(valB) || 0);
          } else if (cfg.sortType === 'date') {
            cmp = String(valA || '').localeCompare(String(valB || ''));
          } else {
            cmp = String(valA || '').localeCompare(String(valB || ''), 'ar');
          }
          return columnSort.direction === 'asc' ? cmp : -cmp;
        });
        return list;
      }
    }

    list.sort((a, b) => {
      if (sortOption === 'date-asc') return a.date.localeCompare(b.date);
      if (sortOption === 'amount-desc') return b.amount - a.amount;
      if (sortOption === 'amount-asc') return a.amount - b.amount;
      if (sortOption === 'desc-alpha') return a.description.localeCompare(b.description, 'ar');
      return b.date.localeCompare(a.date); // 'date-desc' default
    });
    return list;
  }, [filteredBudget, columnSort, columnConfigs, sortOption]);

  // Totals of filtered funding operations grouped by currency
  const filteredTotalsByCurrency = useMemo(() => {
    return sortedBudget.reduce((acc, item) => {
      const cur = item.currency || currency || 'YER';
      acc[cur] = (acc[cur] || 0) + item.amount;
      return acc;
    }, {} as Record<string, number>);
  }, [sortedBudget, currency]);

  const hasActiveColumnFilters = Object.keys(columnFilters).length > 0;
  const isFilterActive = searchTerm.trim() !== '' || 
                         startDate !== '' || 
                         endDate !== '' || 
                         currencyFilter !== 'all' || 
                         hasActiveColumnFilters ||
                         columnSort !== null;

  // Export Budget Logs to Excel
  const handleExportExcel = () => {
    const headers = [
      'التاريخ',
      'البيان (مصدر التمويل)',
      'المبلغ',
      'العملة',
      'ملاحظات'
    ];

    const rows = sortedBudget.map(item => [
      item.date,
      item.description,
      item.amount.toString(),
      item.currency || currency || 'YER',
      item.notes || ''
    ]);

    exportToXLSX('سجل_تمويل_الميزانية_المشروع', headers, rows);
  };

  // Import Budget Logs from Excel File (.xlsx, .xls)
  const handleBudgetExcelImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const data = event.target?.result;
        const workbook = XLSX.read(data, { type: 'binary' });
        const sheetName = workbook.SheetNames[0];
        const sheet = workbook.Sheets[sheetName];
        const rows = XLSX.utils.sheet_to_json<any>(sheet);

        let count = 0;
        rows.forEach((row: any) => {
          const dateVal = row['التاريخ'] || row['تاريخ'] || row['Date'] || row['date'];
          const desc = row['البيان'] || row['مصدر التمويل'] || row['الجهة المموله'] || row['الوصف'] || row['Description'] || row['description'] || row['statement'];
          const amt = parseFloat(row['المبلغ'] || row['القيمة'] || row['Amount'] || row['amount']);
          const cur = row['العملة'] || row['currency'] || row['Currency'] || currency || 'YER';
          const noteVal = row['الملاحظات'] || row['ملاحظات'] || row['Notes'] || row['notes'] || '';

          if (dateVal && desc && !isNaN(amt) && amt > 0) {
            const parseDate = (d: any) => {
              if (!d) return new Date().toISOString().split('T')[0];
              if (typeof d === 'number') {
                const dateObj = new Date((d - 25569) * 86400 * 1000);
                return dateObj.toISOString().split('T')[0];
              }
              const stringDate = String(d).trim();
              const parsed = Date.parse(stringDate);
              if (!isNaN(parsed)) {
                return new Date(parsed).toISOString().split('T')[0];
              }
              return stringDate;
            };

            onAddBudgetItem({
              date: parseDate(dateVal),
              amount: amt,
              description: String(desc).trim(),
              notes: String(noteVal).trim(),
              currency: String(cur).trim().toUpperCase()
            });
            count++;
          }
        });

        if (count > 0) {
          if (typeof window !== 'undefined' && (window as any).showToast) {
            (window as any).showToast(`تم استيراد ${count} دفعة تمويل من ملف Excel بنجاح!`);
          }
        } else {
          if (typeof window !== 'undefined' && (window as any).showToast) {
            (window as any).showToast('لم يتم العثور على بيانات تمويل صالحة في ملف Excel. تأكد من وجود أعمدة: التاريخ، البيان، المبلغ.');
          }
        }
      } catch (err) {
        console.error('Budget Excel import error:', err);
        if (typeof window !== 'undefined' && (window as any).showToast) {
          (window as any).showToast('حدث خطأ أثناء قراءة ملف Excel. يرجى التأكد من صيغة الملف.');
        }
      }
    };
    reader.readAsBinaryString(file);
    e.target.value = '';
  };

  // Export/Print Budget PDF Report with Summary and Detailed Transaction Log
  const handlePrintBudgetPDF = () => {
    // 1. Group by currency for summary table
    const fundingByCurrencyMap: Record<string, { totalAmount: number; count: number }> = {};
    // Group by source description for summary
    const fundingBySourceMap: Record<string, { totalAmount: number; currency: string; count: number }> = {};

    sortedBudget.forEach(b => {
      const cur = b.currency || currency || 'YER';
      if (!fundingByCurrencyMap[cur]) {
        fundingByCurrencyMap[cur] = { totalAmount: 0, count: 0 };
      }
      fundingByCurrencyMap[cur].totalAmount += b.amount;
      fundingByCurrencyMap[cur].count += 1;

      const sourceKey = `${b.description.trim()}___${cur}`;
      if (!fundingBySourceMap[sourceKey]) {
        fundingBySourceMap[sourceKey] = { totalAmount: 0, currency: cur, count: 0 };
      }
      fundingBySourceMap[sourceKey].totalAmount += b.amount;
      fundingBySourceMap[sourceKey].count += 1;
    });

    // Summary Rows HTML
    let summarySourceRowsHtml = '';
    Object.entries(fundingBySourceMap).forEach(([key, val], idx) => {
      const descName = key.split('___')[0];
      summarySourceRowsHtml += `
        <tr>
          <td style="text-align: center; padding: 6px 8px; border: 1px solid #cbd5e1; width: 35px;">${idx + 1}</td>
          <td style="font-weight: bold; padding: 6px 8px; border: 1px solid #cbd5e1;" class="col-statement">${descName}</td>
          <td style="text-align: center; padding: 6px 8px; border: 1px solid #cbd5e1; width: 20%;">${val.count} دفعة</td>
          <td style="font-weight: bold; color: #15803d; font-family: monospace; padding: 6px 8px; border: 1px solid #cbd5e1; width: 25%;">${formatCurrency(val.totalAmount, val.currency)}</td>
        </tr>
      `;
    });

    // Detailed Log Rows HTML
    let rowsHtml = '';
    sortedBudget.forEach(b => {
      rowsHtml += `
        <tr>
          <td style="font-family: monospace; padding: 6px 8px; border: 1px solid #cbd5e1; width: 14%;">${formatDateArabic(b.date)}</td>
          <td style="font-weight: bold; padding: 6px 8px; border: 1px solid #cbd5e1; width: 42%;" class="col-statement">${b.description}</td>
          <td style="font-weight: bold; color: #15803d; font-family: monospace; padding: 6px 8px; border: 1px solid #cbd5e1; width: 26%;">${formatCurrency(b.amount, b.currency || currency || 'YER')}</td>
          <td style="font-size: 9.5px; color: #64748b; line-height: 1.35; padding: 6px 8px; border: 1px solid #cbd5e1; width: 18%;" class="col-notes">${b.notes || '-'}</td>
        </tr>
      `;
    });

    const fundingText = Object.entries(fundingByCurrencyMap)
      .map(([cur, val]) => `<strong>${formatCurrency(val.totalAmount, cur)}</strong> (${val.count} عملية)`)
      .join(' | ');

    const htmlContent = `
      <div style="font-family: 'Cairo', sans-serif; direction: rtl; text-align: right; padding: 10px;">
        <style>
          th.col-statement, td.col-statement {
            min-width: 32% !important;
            width: auto !important;
            white-space: normal !important;
            word-break: break-word !important;
          }
          th.col-notes, td.col-notes {
            max-width: 18% !important;
            width: 18% !important;
            font-size: 9.5px !important;
            color: #64748b !important;
            line-height: 1.35 !important;
            white-space: normal !important;
            word-break: break-word !important;
          }
        </style>
        <h2 style="color: #1e293b; text-align: center; border-bottom: 2px solid #cbd5e1; padding-bottom: 10px; margin-bottom: 15px; font-size: 20px;">
          💰 كشف الميزانية العامة وتغذية الخزينة والصندوق الشامل التفصيلي
        </h2>
        <div style="display: flex; justify-content: space-between; margin-bottom: 20px; font-size: 12px; color: #475569;">
          <div><strong>إجمالي عمليات التمويل:</strong> ${sortedBudget.length} دفعة تمويلية</div>
          <div><strong>تاريخ استخراج التقرير:</strong> ${new Date().toLocaleDateString('ar-EG-u-nu-latn')}</div>
        </div>

        <div style="background-color: #f0fdf4; border: 1px solid #bbf7d0; padding: 12px; border-radius: 8px; margin-bottom: 20px;">
          <div style="font-size: 13px; font-weight: bold; color: #166534; margin-bottom: 4px;">إجمالي الميزانية والتمويل المستلم للصندوق:</div>
          <div style="font-size: 16px; font-weight: bold; color: #15803d;">${fundingText || '0'}</div>
        </div>

        <!-- SECTION 1: SUMMARY TABLE BY SOURCE -->
        <div style="margin-bottom: 25px;">
          <h3 style="font-size: 15px; font-weight: bold; color: #0f172a; border-bottom: 2px solid #16a34a; padding-bottom: 6px; margin-bottom: 12px;">
            أولاً: ملخص إجمالي التمويل المودع حسب المصدر والجهة
          </h3>
          <table style="width: 100%; border-collapse: collapse; font-size: 12px;">
            <thead>
              <tr style="background-color: #14532d; color: white;">
                <th style="padding: 8px; border: 1px solid #166534; text-align: center; width: 35px;">#</th>
                <th style="padding: 8px; border: 1px solid #166534;" class="col-statement">البيان / جهة التمويل</th>
                <th style="padding: 8px; border: 1px solid #166534; text-align: center; width: 20%;">عدد الدفعات</th>
                <th style="padding: 8px; border: 1px solid #166534; width: 25%;">إجمالي التمويل</th>
              </tr>
            </thead>
            <tbody>
              ${Object.keys(fundingBySourceMap).length === 0 ? '<tr><td colspan="4" style="text-align: center; color: #94a3b8; padding: 10px;">لا توجد مصادر تمويل مضافه.</td></tr>' : summarySourceRowsHtml}
            </tbody>
          </table>
        </div>

        <!-- SECTION 2: DETAILED TRANSACTION LOG -->
        <div style="margin-bottom: 25px;">
          <h3 style="font-size: 14px; font-weight: bold; color: #0f172a; border-bottom: 2px solid #16a34a; padding-bottom: 6px; margin-top: 20px; margin-bottom: 12px; break-after: avoid; page-break-after: avoid; break-before: auto;">
            ثانياً: سجل تفصيلي بكافة دفعات وإيداعات التمويل المقيدة بالخزينة
          </h3>
          <table style="width: 100%; border-collapse: collapse; margin-top: 10px; font-size: 12px;">
            <thead>
              <tr style="background-color: #0f172a; color: white;">
                <th style="padding: 8px; border: 1px solid #334155; width: 14%;">التاريخ</th>
                <th style="padding: 8px; border: 1px solid #334155; width: 42%;" class="col-statement">البيان (مصدر التمويل / إيداع)</th>
                <th style="padding: 8px; border: 1px solid #334155; width: 26%;">المبلغ التمويلي</th>
                <th style="padding: 8px; border: 1px solid #334155; width: 18%;" class="col-notes">ملاحظات</th>
              </tr>
            </thead>
            <tbody>
              ${sortedBudget.length === 0 ? '<tr><td colspan="4" style="text-align: center; color: #94a3b8; padding: 12px;">لا توجد دفعات تمويل مقيدة حالياً.</td></tr>' : rowsHtml}
            </tbody>
          </table>
        </div>
      </div>
    `;

    printPDF('كشف الميزانية العامة وتغذية الخزينة الشامل التفصيلي', htmlContent);
  };

  return (
    <div className="space-y-4 animate-fade-in" id="budget-section">
      
      {/* Header */}
      <PageHeaderCard
        title="الميزانية العامة وتغذية الصندوق"
        description="إدارة ميزانية المشروع وتغذية الصندوق الاستثماري لتغطية كافة أجور العمال والمصاريف."
        icon={<Wallet size={20} />}
        onBack={setActiveTab ? () => setActiveTab('dashboard') : undefined}
        optionsMenu={
          <OptionsMenu 
            onExportExcel={handleExportExcel}
            onExportPDF={handlePrintBudgetPDF}
            onImportExcel={sharedRole !== 'read' ? handleBudgetExcelImport : undefined}
            shareTitle="الميزانية العامة وصندوق الموقع"
            shareText={(() => {
              const fundingStr = Object.entries(fundingByCurrency)
                .map(([cur, val]) => `${formatCurrency(val, cur)}`)
                .join(' | ') || '0';

              const expensesStr = Object.entries(expensesByCurrency)
                .map(([cur, val]) => `${formatCurrency(val, cur)}`)
                .join(' | ') || '0';

              const remainingStr = Object.entries(remainingByCurrency)
                .map(([cur, val]) => `${formatCurrency(val, cur)}`)
                .join(' | ') || '0';

              const debtsStr = Object.entries(debtsByCurrency)
                .map(([cur, val]) => `${formatCurrency(val, cur)}`)
                .join(' | ') || '0';

              const lastEntries = filteredBudget.slice(-10);
              const entriesText = lastEntries.length > 0
                ? '\n📋 آخر دفعات التمويل المقيدة:\n' + lastEntries.map(b => 
                    `- ${b.date} | ${b.description} ⟸ ${formatCurrency(b.amount, b.currency || currency)}`
                  ).join('\n')
                : '\n(لا توجد عمليات تمويل مقيدة)';

              return `💰 الميزانية العامة وصندوق موقع المقاولات\n📅 تاريخ الاستخراج: ${new Date().toLocaleDateString('ar-EG-u-nu-latn')}\n\n📊 الحالة المالية للموقع:\n🟢 إجمالي التمويل المستلم: ${fundingStr}\n🔴 إجمالي النفقات والمصاريف: ${expensesStr}\n💳 الرصيد المتبقي بالخزينة: ${remainingStr}\n⚠️ إجمالي ديون الموقع للغير: ${debtsStr}\n${entriesText}\n\n*تم استخراجه ومشاركته من كشوفات المقاولات*`;
            })()}
          />
        }
      />

      {/* Budget Summary Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
        
        {/* Total Funding */}
        <div className="bg-gradient-to-br from-emerald-50 to-white p-4 rounded-2xl border border-emerald-100 shadow-xs">
          <div className="flex items-center justify-between text-emerald-700">
            <span className="text-slate-600 font-medium text-xs">إجمالي التمويل المتوفر</span>
            <Wallet size={18} />
          </div>
          <div className="mt-3 space-y-1">
            {activeCurrencies.map(cur => {
              const val = fundingByCurrency[cur] || 0;
              return (
                <div key={cur} className="flex justify-between items-center border-b border-dashed border-emerald-100/50 pb-0.5 last:border-0 last:pb-0">
                  <span className="text-[10px] text-slate-400 font-mono font-bold">{cur}</span>
                  <span className="text-sm font-bold text-slate-800 font-mono">{formatCurrency(val, cur)}</span>
                </div>
              );
            })}
            <span className="text-[9px] text-slate-400 block mt-1.5 pt-1 border-t border-slate-50">مجموع رأس المال المسجل كمدخلات</span>
          </div>
        </div>

        {/* Total Expenses */}
        <div className="bg-gradient-to-br from-rose-50 to-white p-5 rounded-2xl border border-rose-100 shadow-xs">
          <div className="flex items-center justify-between text-rose-700">
            <span className="text-slate-600 font-medium text-xs">إجمالي المصروفات</span>
            <TrendingUp size={18} />
          </div>
          <div className="mt-3 space-y-1">
            {activeCurrencies.map(cur => {
              const val = expensesByCurrency[cur] || 0;
              return (
                <div key={cur} className="flex justify-between items-center border-b border-dashed border-rose-100/50 pb-0.5 last:border-0 last:pb-0">
                  <span className="text-[10px] text-slate-400 font-mono font-bold">{cur}</span>
                  <span className="text-sm font-bold text-slate-800 font-mono">{formatCurrency(val, cur)}</span>
                </div>
              );
            })}
            <span className="text-[9px] text-slate-400 block mt-1.5 pt-1 border-t border-slate-50">مجموع النفقات اليومية المقتطعة</span>
          </div>
        </div>

        {/* Company Debts */}
        <div className="bg-gradient-to-br from-purple-50 to-white p-5 rounded-2xl border border-purple-100 shadow-xs">
          <div className="flex items-center justify-between text-purple-700">
            <span className="text-slate-600 font-medium text-xs">ديون الشركة المستحقة</span>
            <AlertTriangle size={18} className="text-purple-500" />
          </div>
          <div className="mt-3 space-y-1">
            {activeCurrencies.map(cur => {
              const val = debtsByCurrency[cur] || 0;
              return (
                <div key={cur} className="flex justify-between items-center border-b border-dashed border-purple-100/50 pb-0.5 last:border-0 last:pb-0">
                  <span className="text-[10px] text-slate-400 font-mono font-bold">{cur}</span>
                  <span className="text-sm font-bold text-purple-700 font-mono">{formatCurrency(val, cur)}</span>
                </div>
              );
            })}
            <span className="text-[9px] text-slate-400 block mt-1.5 pt-1 border-t border-slate-50">مستحقات العمال والموردين المتبقية</span>
          </div>
        </div>

        {/* Net Treasury */}
        <div className="bg-gradient-to-br from-blue-50 to-white p-5 rounded-2xl border border-blue-100 shadow-xs">
          <div className="flex items-center justify-between text-blue-700">
            <span className="text-slate-600 font-medium text-xs">الرصيد الفعلي (الخزينة)</span>
            <DollarSign size={18} className="text-blue-500" />
          </div>
          <div className="mt-3 space-y-1">
            {activeCurrencies.map(cur => {
              const val = remainingByCurrency[cur] || 0;
              const isNegative = val < 0;
              return (
                <div key={cur} className="flex justify-between items-center border-b border-dashed border-blue-100/30 pb-0.5 last:border-0 last:pb-0">
                  <span className="text-[10px] text-slate-400 font-mono font-bold">{cur}</span>
                  <span className={`text-sm font-bold font-mono ${isNegative ? 'text-rose-600' : 'text-slate-800'}`}>
                    {formatCurrency(val, cur)}
                  </span>
                </div>
              );
            })}
            <span className="text-[9px] text-slate-400 block mt-1.5 pt-1 border-t border-slate-50">رصيد الخزينة إيجابي وآمن</span>
          </div>
        </div>

      </div>

      {/* Main Split Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        
        {/* Left Col: Add Funding Form */}
        <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-xs h-fit" id="funding-form-container">
          {sharedRole === 'read' ? (
            <div className="text-center py-8 space-y-3">
              <div className="mx-auto w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center text-slate-400">
                <Wallet size={24} />
              </div>
              <h3 className="font-bold text-slate-800 text-sm">وضع عرض الحساب المشترك</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                تمت دعوتك بصلاحية (عرض فقط). لا يمكنك إضافة تمويل جديد أو تعديل بيانات ميزانية المشروع.
              </p>
            </div>
          ) : (
            <>
              <button
                type="button"
                onClick={() => setShowAddFundingForm(!showAddFundingForm)}
                className="w-full bg-gradient-to-r from-emerald-600 via-emerald-600 to-emerald-700 hover:from-emerald-700 hover:to-emerald-800 text-white font-extrabold text-xs sm:text-sm py-2 px-2.5 sm:py-2.5 sm:px-3.5 rounded-lg sm:rounded-xl shadow-xs flex items-center justify-between transition-all cursor-pointer select-none border border-emerald-500/50"
              >
                <div className="flex items-center gap-2">
                  <div className="p-1 bg-white/20 rounded-md text-white shrink-0">
                    <PlusCircle size={15} />
                  </div>
                  <span className="font-extrabold tracking-wide">تغذية الصندوق / تمويل جديد</span>
                </div>
                <span className="text-[10px] sm:text-xs px-2 py-0.5 sm:px-2.5 sm:py-1 rounded-md font-bold flex items-center gap-1 transition-all bg-white/90 text-emerald-950 shadow-xs">
                  {showAddFundingForm ? 'إخفاء البيانات ▲' : '+ إضافة تمويل جديد ▼'}
                </span>
              </button>

              {showAddFundingForm && (
                <div className="pt-4 mt-3 border-t border-slate-100 animate-slide-up">
                  <form onSubmit={handleSubmit} className="space-y-4">
                    
                    {/* Date */}
                    <div className="space-y-1">
                      <label className="text-xs font-bold text-slate-600 block">التاريخ</label>
                      <div className="relative">
                        <input 
                          type="date"
                          value={date}
                          onChange={(e) => setDate(e.target.value)}
                          className="w-full h-[42px] px-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-sm focus:outline-hidden focus:border-emerald-500"
                          required
                        />
                        <Calendar size={16} className="absolute top-1/2 -translate-y-1/2 right-3 text-slate-400 pointer-events-none" />
                      </div>
                    </div>

                    {/* Amount & Currency */}
                    <div className="grid grid-cols-3 gap-3">
                      <div className="col-span-2 space-y-1">
                        <label className="text-xs font-bold text-slate-600 block">مبلغ التغذية</label>
                        <div className="flex gap-1.5 items-center">
                          <input 
                            type="number"
                            value={amount}
                            onChange={(e) => setAmount(e.target.value)}
                            placeholder="مثال: 10000000"
                            className="w-full h-[42px] px-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-sm focus:outline-hidden focus:border-emerald-500"
                            required
                            min="1"
                          />
                          <Calculator onApply={(val) => setAmount(String(val))} />
                        </div>
                        <AmountInWords amount={amount} currency={itemCurrency} />
                      </div>
                      <div className="space-y-1">
                        <label className="text-xs font-bold text-slate-600 block">العملة</label>
                        <select
                          value={itemCurrency}
                          onChange={(e) => setItemCurrency(e.target.value)}
                          className="w-full h-[42px] px-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-sm focus:outline-hidden focus:border-emerald-500 cursor-pointer"
                        >
                          <option value="YER">﷼ يمني</option>
                          <option value="SAR">﷼ سعودي</option>
                          <option value="USD">$ دولار</option>
                        </select>
                      </div>
                    </div>

                    {/* Description */}
                    <div className="space-y-1">
                      <label className="text-xs font-bold text-slate-600 block">البيان (مصدر التمويل)</label>
                      <input 
                        type="text"
                        value={description}
                        onChange={(e) => setDescription(e.target.value)}
                        placeholder="مثال: دفعة المستثمر الأولى / تمويل جيب ذاتي"
                        className="w-full h-[42px] px-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-sm focus:outline-hidden focus:border-emerald-500"
                        required
                      />
                    </div>

                    {/* Notes */}
                    <div className="space-y-1">
                      <label className="text-xs font-bold text-slate-600 block">ملاحظات</label>
                      <textarea 
                        value={notes}
                        onChange={(e) => setNotes(e.target.value)}
                        placeholder="تفاصيل إضافية حول دفعة التمويل..."
                        rows={2}
                        className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-sm focus:outline-hidden focus:border-emerald-500 resize-none"
                      />
                    </div>

                    {errorMsg && (
                      <p className="text-xs text-rose-600 font-bold bg-rose-50 p-2.5 rounded-xl">{errorMsg}</p>
                    )}

                    <div className="flex gap-2">
                      <button 
                        type="submit"
                        className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm py-2.5 px-4 rounded-xl shadow-xs transition-colors flex items-center justify-center gap-2 cursor-pointer"
                      >
                        <PlusCircle size={18} />
                        إضافة مبلغ التمويل
                      </button>
                      <button 
                        type="button"
                        onClick={handleResetAddFundingForm}
                        className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold text-xs rounded-xl transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                        title="إلغاء وتنظيف الحقول"
                      >
                        <RotateCcw size={15} />
                        <span>إلغاء / تنظيف</span>
                      </button>
                    </div>

                  </form>
                </div>
              )}
            </>
          )}
        </div>

        {/* Right Col: Funding Logs List */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Funding Filters Card */}
          <div className="bg-white p-3.5 sm:p-4 rounded-2xl border border-slate-100 shadow-xs transition-all" id="budget-funding-filters">
            <div className="flex items-center justify-between gap-2">
              <div className="relative flex-1">
                <input 
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="بحث في البيان، المبلغ، أو الملاحظات..."
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-xs pr-8 pl-8 focus:outline-hidden focus:border-emerald-500 transition-colors"
                />
                <Search size={14} className="absolute top-1/2 -translate-y-1/2 right-2.5 text-slate-400 pointer-events-none" />
                {searchTerm && (
                  <button
                    type="button"
                    onClick={() => setSearchTerm('')}
                    className="absolute top-1/2 -translate-y-1/2 left-2 p-1 text-slate-400 hover:text-slate-600 hover:bg-slate-200/70 rounded-full transition-colors cursor-pointer"
                    title="مسح نص البحث"
                  >
                    <X size={13} className="stroke-[2.5]" />
                  </button>
                )}
              </div>

              <button
                type="button"
                onClick={() => setIsFiltersExpanded(!isFiltersExpanded)}
                className={`px-3 py-2 rounded-xl text-xs font-bold border transition-all flex items-center gap-1.5 cursor-pointer shrink-0 ${
                  isFilterActive || isFiltersExpanded
                    ? 'bg-emerald-50 text-emerald-800 border-emerald-200 hover:bg-emerald-100'
                    : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                }`}
              >
                <Filter size={14} className={isFilterActive ? 'text-emerald-600 fill-emerald-600' : 'text-slate-500'} />
                <span className="hidden sm:inline">أدوات الفلترة</span>
                {isFilterActive && (
                  <span className="w-2 h-2 rounded-full bg-emerald-600"></span>
                )}
                {isFiltersExpanded ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
              </button>
            </div>

            {/* Expanded Advanced Filters */}
            {isFiltersExpanded && (
              <div className="pt-3 space-y-3 border-t border-slate-100 mt-3">
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                  
                  {/* Start Date */}
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-slate-500 shrink-0 font-bold">من:</span>
                    <input 
                      type="date"
                      value={startDate}
                      onChange={(e) => setStartDate(e.target.value)}
                      className="w-full h-8 px-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 text-xs focus:outline-hidden focus:border-emerald-500"
                    />
                  </div>

                  {/* End Date */}
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-slate-500 shrink-0 font-bold">إلى:</span>
                    <input 
                      type="date"
                      value={endDate}
                      onChange={(e) => setEndDate(e.target.value)}
                      className="w-full h-8 px-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 text-xs focus:outline-hidden focus:border-emerald-500"
                    />
                  </div>

                  {/* Currency Filter */}
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-slate-500 shrink-0 font-bold">العملة:</span>
                    <select
                      value={currencyFilter}
                      onChange={(e) => setCurrencyFilter(e.target.value)}
                      className="w-full h-8 px-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 text-xs font-bold focus:outline-hidden focus:border-emerald-500 cursor-pointer"
                    >
                      <option value="all">كافة العملات</option>
                      <option value="YER">﷼ يمني (YER)</option>
                      <option value="SAR">﷼ سعودي (SAR)</option>
                      <option value="USD">$ دولار (USD)</option>
                    </select>
                  </div>

                  {/* Sort Order */}
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-slate-500 shrink-0 font-bold">الترتيب:</span>
                    <select
                      value={sortOption}
                      onChange={(e) => setSortOption(e.target.value as any)}
                      className="w-full h-8 px-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 text-xs font-bold focus:outline-hidden focus:border-emerald-500 cursor-pointer"
                    >
                      <option value="date-desc">الأحدث أولاً ⬇️ (افتراضي)</option>
                      <option value="date-asc">الأقدم أولاً ⬆️</option>
                      <option value="amount-desc">مبلغ التمويل (الأعلى أولاً) 💰</option>
                      <option value="amount-asc">مبلغ التمويل (الأقل أولاً)</option>
                      <option value="desc-alpha">أبجدياً حسب البيان (أ - ي) 🔤</option>
                    </select>
                  </div>

                </div>

                {/* Reset filters shortcut */}
                {isFilterActive && (
                  <div className="flex justify-end pt-1">
                    <button 
                      type="button"
                      onClick={handleResetAllFilters}
                      className="text-[11px] text-emerald-700 hover:text-emerald-900 hover:underline font-bold cursor-pointer flex items-center gap-1"
                    >
                      <RotateCcw size={12} />
                      <span>إلغاء التصفية وإعادة الضبط</span>
                    </button>
                  </div>
                )}
              </div>
            )}

            {/* Filtered Summary Bar in Filter Card */}
            <div className={`mt-3 pt-2.5 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 text-xs transition-all ${
              isFilterActive ? 'bg-emerald-50/70 p-2.5 rounded-xl border border-emerald-200/70' : ''
            }`}>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="font-bold text-slate-700">
                  {isFilterActive ? 'نتائج التصفية:' : 'إجمالي العمليات:'}
                </span>
                <span className="bg-emerald-100 text-emerald-800 px-2.5 py-0.5 rounded-full font-mono font-extrabold text-[11px]">
                  {sortedBudget.length} {sortedBudget.length === 1 ? 'عملية' : 'عمليات'}
                </span>
                {isFilterActive && (
                  <span className="text-slate-500 text-[11px] font-medium">
                    (مفلترة من إجمالي {budget.length} مسجلة)
                  </span>
                )}
              </div>

              <div className="flex items-center gap-1.5 flex-wrap">
                <span className="text-slate-600 font-bold">
                  {isFilterActive ? 'إجمالي المبالغ المفلترة:' : 'إجمالي المبالغ:'}
                </span>
                {Object.keys(filteredTotalsByCurrency).length === 0 ? (
                  <span className="text-slate-400 font-mono font-bold">0</span>
                ) : (
                  Object.entries(filteredTotalsByCurrency).map(([cur, val]) => (
                    <span key={cur} className="bg-white text-emerald-800 border border-emerald-300 px-2.5 py-0.5 rounded-lg font-mono font-extrabold text-xs shadow-2xs">
                      {formatCurrency(Number(val), cur)}
                    </span>
                  ))
                )}
              </div>
            </div>
          </div>

          {/* Table */}
          <div className="bg-white rounded-2xl border border-slate-100 shadow-xs overflow-hidden" id="budget-table-card">
            <div className="p-4 sm:p-5 border-b border-slate-100 bg-slate-50/50 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 flex-wrap">
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="font-bold text-slate-800 text-sm sm:text-base">أرشيف عمليات تمويل صندوق المشروع</h3>
                <span className="text-xs bg-emerald-100 text-emerald-800 font-extrabold px-2.5 py-0.5 rounded-full">
                  {sortedBudget.length} عمليات
                </span>
                {hasActiveColumnFilters && (
                  <div className="flex items-center gap-1.5 bg-emerald-50 border border-emerald-200 text-emerald-800 px-2 py-0.5 rounded-lg text-xs font-bold">
                    <Filter size={12} className="fill-current text-emerald-600" />
                    <span>تصفية مخصصة للأعمدة</span>
                    <button
                      type="button"
                      onClick={handleClearAllColumnFilters}
                      className="text-[10px] text-emerald-600 hover:text-emerald-800 hover:underline mr-1 cursor-pointer font-bold"
                    >
                      إلغاء فلاتر الأعمدة ✕
                    </button>
                  </div>
                )}
              </div>

              {/* Total amounts for filtered operations badge */}
              <div className="text-slate-700 text-xs font-bold flex flex-wrap items-center gap-2 bg-white px-3 py-1.5 rounded-xl border border-slate-200/80 shadow-2xs">
                <span className="text-slate-500 font-bold">
                  {isFilterActive ? 'إجمالي المبالغ المفلترة:' : 'إجمالي مبالغ التمويل:'}
                </span>
                {Object.keys(filteredTotalsByCurrency).length === 0 ? (
                  <span className="text-slate-400 font-mono">0</span>
                ) : (
                  Object.entries(filteredTotalsByCurrency).map(([cur, val]) => (
                    <span key={cur} className="bg-emerald-50 text-emerald-800 px-2.5 py-0.5 rounded-lg border border-emerald-200 text-xs font-extrabold font-mono shadow-2xs">
                      {formatCurrency(Number(val), cur)}
                    </span>
                  ))
                )}
              </div>
            </div>

            <div className="overflow-x-auto">
              {sortedBudget.length === 0 ? (
                <div className="text-center py-12 px-4 space-y-2">
                  <p className="text-slate-400 text-sm font-medium">لا توجد عمليات تمويل مطابقة لخيارات البحث والتصفية</p>
                  <p className="text-xs text-slate-300">
                    {isFilterActive ? 'جرب تغيير أو إلغاء فلاتر البحث لعرض السجلات' : 'أضف دفعات تمويل لتتمكن من تغطية مصاريف المشروع'}
                  </p>
                  {isFilterActive && (
                    <button
                      type="button"
                      onClick={handleResetAllFilters}
                      className="mt-2 inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 rounded-lg text-xs font-bold transition-colors cursor-pointer"
                    >
                      <RotateCcw size={13} />
                      <span>إلغاء كافة الفلاتر والبحث</span>
                    </button>
                  )}
                </div>
              ) : (
                <table className="w-full text-right text-xs">
                  <thead>
                    <tr className="bg-slate-50/70 border-b border-slate-100 text-slate-500 font-bold">
                      <th className="p-3 whitespace-nowrap">
                        <div className="flex items-center justify-between gap-1">
                          <span>التاريخ</span>
                          <ExcelColumnFilter
                            config={columnConfigs.date}
                            data={baseFilteredBudget}
                            allColumnFilters={columnFilters}
                            allConfigs={columnConfigs}
                            activeFilter={columnFilters.date}
                            onFilterChange={handleColumnFilterChange}
                            activeSort={columnSort}
                            onSortChange={handleColumnSortChange}
                            accentColor="emerald"
                          />
                        </div>
                      </th>
                      <th className="p-3">
                        <div className="flex items-center justify-between gap-1">
                          <span>البيان (المصدر)</span>
                          <ExcelColumnFilter
                            config={columnConfigs.description}
                            data={baseFilteredBudget}
                            allColumnFilters={columnFilters}
                            allConfigs={columnConfigs}
                            activeFilter={columnFilters.description}
                            onFilterChange={handleColumnFilterChange}
                            activeSort={columnSort}
                            onSortChange={handleColumnSortChange}
                            accentColor="emerald"
                          />
                        </div>
                      </th>
                      <th className="p-3 whitespace-nowrap">
                        <div className="flex items-center justify-between gap-1">
                          <span>المبلغ والعملة</span>
                          <ExcelColumnFilter
                            config={columnConfigs.amount}
                            data={baseFilteredBudget}
                            allColumnFilters={columnFilters}
                            allConfigs={columnConfigs}
                            activeFilter={columnFilters.amount}
                            onFilterChange={handleColumnFilterChange}
                            activeSort={columnSort}
                            onSortChange={handleColumnSortChange}
                            accentColor="emerald"
                          />
                        </div>
                      </th>
                      <th className="p-3">
                        <div className="flex items-center justify-between gap-1">
                          <span>ملاحظات</span>
                          <ExcelColumnFilter
                            config={columnConfigs.notes}
                            data={baseFilteredBudget}
                            allColumnFilters={columnFilters}
                            allConfigs={columnConfigs}
                            activeFilter={columnFilters.notes}
                            onFilterChange={handleColumnFilterChange}
                            activeSort={columnSort}
                            onSortChange={handleColumnSortChange}
                            accentColor="emerald"
                          />
                        </div>
                      </th>
                      <th className="p-3 text-center whitespace-nowrap">العمليات</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {sortedBudget.map((item) => (
                      <tr key={item.id} className="hover:bg-slate-50/50 transition-colors text-slate-700">
                        <td className="p-3 whitespace-nowrap text-slate-500">{formatDateArabic(item.date)}</td>
                        <td className="p-3 font-semibold text-slate-800 flex items-center gap-1.5 flex-wrap">
                          <span>{item.description}</span>
                          <AttributionBadge createdBy={item.createdBy} />
                        </td>
                        <td className="p-3 font-extrabold text-emerald-600">{formatCurrency(item.amount, item.currency || 'YER')}</td>
                        <td className="p-3 text-slate-400 max-w-xs truncate" title={item.notes}>{item.notes || '-'}</td>
                        <td className="p-3 text-center flex items-center justify-center gap-1.5">
                          {sharedRole !== 'read' && (
                            <button 
                              onClick={() => setEditingBudgetItem(item)}
                              className="p-1 hover:bg-slate-50 text-slate-300 hover:text-sky-600 rounded-sm cursor-pointer"
                              title="تعديل التمويل"
                            >
                              <Pencil size={13} />
                            </button>
                          )}
                          {sharedRole !== 'read' && sharedRole !== 'add' && (
                            <button 
                              onClick={() => {
                                if (confirm('هل أنت متأكد من حذف دفعة التمويل هذه؟ سيتم اقتطاعها من إجمالي الميزانية.')) {
                                  onDeleteBudgetItem(item.id);
                                }
                              }}
                              className="p-1 hover:bg-rose-50 text-slate-300 hover:text-rose-500 rounded-sm cursor-pointer"
                              title="حذف"
                            >
                              <Trash2 size={13} />
                            </button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                  {sortedBudget.length > 0 && (
                    <tfoot className="bg-slate-50/90 border-t-2 border-slate-200 font-bold">
                      <tr className="text-slate-700 text-xs">
                        <td colSpan={2} className="p-3">
                          <div className="flex items-center gap-2">
                            <span className="font-extrabold">
                              {isFilterActive ? 'إجمالي العمليات المفلترة' : 'إجمالي كافة العمليات'}:
                            </span>
                            <span className="bg-emerald-100 text-emerald-800 text-[11px] px-2.5 py-0.5 rounded-full font-mono font-bold">
                              {sortedBudget.length} عملية
                            </span>
                          </div>
                        </td>
                        <td className="p-3">
                          <div className="flex flex-wrap gap-1.5 items-center">
                            {Object.entries(filteredTotalsByCurrency).map(([cur, val]) => (
                              <span key={cur} className="bg-emerald-100/70 text-emerald-900 border border-emerald-300/80 px-2 py-0.5 rounded-md font-mono font-extrabold text-xs">
                                {formatCurrency(Number(val), cur)}
                              </span>
                            ))}
                          </div>
                        </td>
                        <td colSpan={2} className="p-3 text-slate-400 text-[11px]">
                          {isFilterActive ? 'مجموع المبالغ والعمليات بعد تطبيق التصفية' : 'إجمالي كافة دفعات التمويل المقيدة'}
                        </td>
                      </tr>
                    </tfoot>
                  )}
                </table>
              )}
            </div>
          </div>

        </div>

      </div>

      {/* Edit Budget Item Modal */}
      {editingBudgetItem && (
        <div 
          className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-2.5 sm:p-4 overflow-y-auto dir-rtl text-right overscroll-contain"
          onTouchMove={(e) => {
            if (e.target === e.currentTarget) e.preventDefault();
          }}
        >
          <div 
            className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-md w-full animate-scale-up my-auto max-h-[88vh] sm:max-h-[90vh] flex flex-col overflow-hidden overscroll-contain"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-4 border-b border-slate-100 flex items-center justify-between shrink-0 bg-white">
              <h3 className="font-bold text-slate-800 text-base sm:text-lg">تعديل دفعة التمويل</h3>
              <button
                type="button"
                onClick={() => setEditingBudgetItem(null)}
                className="p-1 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100 cursor-pointer"
              >
                ✕
              </button>
            </div>
            <form onSubmit={handleEditBudgetItemSubmit} className="flex flex-col flex-1 overflow-hidden min-h-0">
              <div className="p-4 overflow-y-auto space-y-4 flex-1 min-h-0 overscroll-contain touch-pan-y custom-scrollbar modal-scroll-area">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-600 block">التاريخ</label>
                  <input 
                    type="date" 
                    value={editingBudgetItem.date}
                    onChange={(e) => setEditingBudgetItem({ ...editingBudgetItem, date: e.target.value })}
                    className="w-full h-[42px] px-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-sm focus:outline-hidden focus:border-emerald-500"
                    required
                  />
                </div>
                <div className="grid grid-cols-3 gap-3">
                  <div className="col-span-2 space-y-1">
                    <label className="text-xs font-bold text-slate-600 block">المبلغ</label>
                    <div className="flex gap-1.5 items-center">
                      <input 
                        type="number" 
                        value={editingBudgetItem.amount}
                        onChange={(e) => setEditingBudgetItem({ ...editingBudgetItem, amount: parseFloat(e.target.value) || 0 })}
                        className="w-full h-[42px] px-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-sm focus:outline-hidden focus:border-emerald-500 font-mono text-left"
                        required
                        min="1"
                      />
                      <Calculator onApply={(val) => setEditingBudgetItem({ ...editingBudgetItem, amount: val })} />
                    </div>
                    <AmountInWords amount={editingBudgetItem.amount} currency={editingBudgetItem.currency || 'YER'} />
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-600 block">العملة</label>
                    <select 
                      value={editingBudgetItem.currency || 'YER'}
                      onChange={(e) => setEditingBudgetItem({ ...editingBudgetItem, currency: e.target.value })}
                      className="w-full h-[42px] px-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-sm focus:outline-hidden focus:border-emerald-500 cursor-pointer"
                    >
                      <option value="YER">﷼ يمني</option>
                      <option value="SAR">﷼ سعودي</option>
                      <option value="USD">$ دولار</option>
                    </select>
                  </div>
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-600 block">البيان (المصدر)</label>
                  <input 
                    type="text" 
                    value={editingBudgetItem.description}
                    onChange={(e) => setEditingBudgetItem({ ...editingBudgetItem, description: e.target.value })}
                    className="w-full h-[42px] px-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-sm focus:outline-hidden focus:border-emerald-500"
                    required
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-600 block">ملاحظات</label>
                  <textarea 
                    value={editingBudgetItem.notes || ''}
                    onChange={(e) => setEditingBudgetItem({ ...editingBudgetItem, notes: e.target.value })}
                    rows={2}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-sm focus:outline-hidden focus:border-emerald-500 resize-none"
                  />
                </div>
              </div>
              <div className="flex justify-end gap-2 p-3.5 bg-slate-50 border-t border-slate-100 shrink-0">
                <button 
                  type="button" 
                  onClick={() => setEditingBudgetItem(null)}
                  className="bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold text-xs py-2 px-4 rounded-xl transition-colors cursor-pointer"
                >
                  إلغاء
                </button>
                <button 
                  type="submit"
                  className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs py-2 px-4 rounded-xl shadow-xs transition-colors cursor-pointer"
                >
                  حفظ التعديلات
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
