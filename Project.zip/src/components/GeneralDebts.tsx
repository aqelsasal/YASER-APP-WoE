/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import PageHeaderCard from './PageHeaderCard';
import { AmountInWords } from './AmountInWords';
import { DraggableScrollIndicator } from './DraggableScrollIndicator';
import { 
  Building2, 
  Search, 
  PlusCircle, 
  Calendar, 
  AlertCircle, 
  Phone, 
  Trash2, 
  Pencil, 
  X, 
  ArrowUpRight, 
  ArrowDownLeft, 
  Receipt, 
  ChevronLeft,
  RotateCcw,
  Landmark,
  FolderGit2,
  Printer,
  Layers,
  Coins,
  FileSpreadsheet,
  CheckCheck
} from 'lucide-react';
import { 
  GeneralDebt, 
  GeneralDebtPayment, 
  GeneralDebtEntry,
  Project,
  formatCurrency, 
  formatDateArabic, 
  exportToXLSX, 
  printPDF 
} from '../types';
import OptionsMenu from './OptionsMenu';
import { useBodyScrollLock } from '../utils/modalScrollLock';

interface GeneralDebtsProps {
  generalDebts: GeneralDebt[];
  projects?: Project[];
  onAddGeneralDebt: (debt: Omit<GeneralDebt, 'id' | 'payments' | 'createdAt' | 'updatedAt' | 'status'>) => void;
  onUpdateGeneralDebt: (id: string, updatedData: Partial<GeneralDebt>) => void;
  onDeleteGeneralDebt: (id: string) => void;
  onAddPayment: (debtId: string, payment: Omit<GeneralDebtPayment, 'id' | 'createdAt'>) => void;
  onDeletePayment: (debtId: string, paymentId: string) => void;
  onAddDebtEntry?: (debtId: string, entry: Omit<GeneralDebtEntry, 'id' | 'createdAt'>) => void;
  onDeleteDebtEntry?: (debtId: string, entryId: string) => void;
  setActiveTab?: (tab: string) => void;
  sharedRole?: string;
  currentUser?: string;
}

export interface CurrencyDebtBreakdown {
  currency: 'YER' | 'SAR' | 'USD';
  totalDebt: number;
  totalPaid: number;
  remaining: number;
  percentage: number;
}

// Helper to extract synthesized or actual entries list
export const getDebtEntriesList = (debt: GeneralDebt): GeneralDebtEntry[] => {
  if (debt.entries && debt.entries.length > 0) {
    return debt.entries;
  }
  return [{
    id: `${debt.id}_entry_initial`,
    amount: Number(debt.totalAmount) || 0,
    currency: debt.currency || 'YER',
    date: debt.startDate || debt.createdAt?.split('T')[0] || new Date().toISOString().split('T')[0],
    description: debt.description || (debt.type === 'receivable' ? 'مستحق للشركة' : 'التزام على الشركة'),
    projectScope: debt.projectScope || (debt.projectName ? 'project' : 'general'),
    projectId: debt.projectId,
    projectName: debt.projectName,
    notes: debt.notes,
    createdBy: debt.createdBy,
    createdAt: debt.createdAt
  }];
};

// Comprehensive multi-currency & multi-entry calculation helper
export const getComprehensiveDebtCalculations = (debt: GeneralDebt) => {
  const entries = getDebtEntriesList(debt);
  const payments = debt.payments || [];
  const currencies: ('YER' | 'SAR' | 'USD')[] = ['YER', 'SAR', 'USD'];

  const perCurrency: Record<'YER' | 'SAR' | 'USD', CurrencyDebtBreakdown> = {
    YER: { currency: 'YER', totalDebt: 0, totalPaid: 0, remaining: 0, percentage: 0 },
    SAR: { currency: 'SAR', totalDebt: 0, totalPaid: 0, remaining: 0, percentage: 0 },
    USD: { currency: 'USD', totalDebt: 0, totalPaid: 0, remaining: 0, percentage: 0 },
  };

  entries.forEach(e => {
    const c = (e.currency || debt.currency || 'YER') as 'YER' | 'SAR' | 'USD';
    if (perCurrency[c]) {
      perCurrency[c].totalDebt += Number(e.amount) || 0;
    }
  });

  payments.forEach(p => {
    const c = (p.currency || debt.currency || 'YER') as 'YER' | 'SAR' | 'USD';
    if (perCurrency[c]) {
      perCurrency[c].totalPaid += Number(p.amount) || 0;
    }
  });

  currencies.forEach(c => {
    perCurrency[c].remaining = Math.max(0, perCurrency[c].totalDebt - perCurrency[c].totalPaid);
    perCurrency[c].percentage = perCurrency[c].totalDebt > 0 
      ? Math.min(100, Math.round((perCurrency[c].totalPaid / perCurrency[c].totalDebt) * 100))
      : 0;
  });

  // Active currencies: currencies with debt or payments
  let activeCurrencies = currencies.filter(c => perCurrency[c].totalDebt > 0 || perCurrency[c].totalPaid > 0);
  if (activeCurrencies.length === 0) {
    activeCurrencies = [debt.currency || 'YER'];
  }

  // Check settlement
  const hasRemaining = activeCurrencies.some(c => perCurrency[c].remaining > 0);
  const hasAnyPayment = activeCurrencies.some(c => perCurrency[c].totalPaid > 0);

  let status: 'active' | 'partially_paid' | 'settled' = 'active';
  if (!hasRemaining && hasAnyPayment) {
    status = 'settled';
  } else if (hasAnyPayment) {
    status = 'partially_paid';
  }

  // Overdue check
  const isOverdue = debt.dueDate && status !== 'settled' && new Date(debt.dueDate) < new Date(new Date().setHours(0,0,0,0));

  // Projects involved
  const distinctProjects = Array.from(new Set(
    entries.map(e => {
      if (e.projectScope === 'project' && e.projectName?.trim()) {
        return e.projectName.trim();
      }
      return 'دين عام للشركة';
    })
  ));

  return {
    entries,
    payments,
    perCurrency,
    activeCurrencies,
    status,
    isOverdue,
    distinctProjects,
    primaryCurrency: debt.currency || 'YER',
    primaryTotalDebt: perCurrency[debt.currency || 'YER']?.totalDebt || 0,
    primaryTotalPaid: perCurrency[debt.currency || 'YER']?.totalPaid || 0,
    primaryRemaining: perCurrency[debt.currency || 'YER']?.remaining || 0,
    primaryPercentage: perCurrency[debt.currency || 'YER']?.percentage || 0
  };
};

export const GeneralDebts: React.FC<GeneralDebtsProps> = ({
  generalDebts,
  projects = [],
  onAddGeneralDebt,
  onUpdateGeneralDebt,
  onDeleteGeneralDebt,
  onAddPayment,
  onDeletePayment,
  onAddDebtEntry,
  onDeleteDebtEntry,
  setActiveTab,
  sharedRole,
  currentUser = 'المدير'
}) => {
  // Filters & State
  const [searchQuery, setSearchQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState<'all' | 'receivable' | 'payable'>('all');
  const [currencyFilter, setCurrencyFilter] = useState<string>('all');
  const [projectFilter, setProjectFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [showOverdueOnly, setShowOverdueOnly] = useState(false);
  const [sortOrder, setSortOrder] = useState<'newest' | 'oldest' | 'highest_remaining' | 'due_date'>('newest');

  // Modals state
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedDebtId, setSelectedDebtId] = useState<string | null>(null);
  const [editingDebt, setEditingDebt] = useState<GeneralDebt | null>(null);

  // Lock body scroll when any modal is open
  useBodyScrollLock(showAddModal || !!selectedDebtId || !!editingDebt);

  // New Debt Form State
  const [newPersonName, setNewPersonName] = useState('');
  const [newType, setNewType] = useState<'receivable' | 'payable'>('receivable');
  const [newDescription, setNewDescription] = useState('');
  const [newTotalAmount, setNewTotalAmount] = useState('');
  const [newCurrency, setNewCurrency] = useState<'YER' | 'SAR' | 'USD'>('YER');
  const [newProjectScope, setNewProjectScope] = useState<'general' | 'project'>('general');
  const [newProjectId, setNewProjectId] = useState<string>('');
  const [newProjectCustomName, setNewProjectCustomName] = useState<string>('');
  const [newStartDate, setNewStartDate] = useState(new Date().toISOString().split('T')[0]);
  const [newDueDate, setNewDueDate] = useState('');
  const [newPhone, setNewPhone] = useState('');
  const [newNotes, setNewNotes] = useState('');
  const [formError, setFormError] = useState('');

  // Selected Debt Item
  const selectedDebt = useMemo(() => {
    return generalDebts.find(d => d.id === selectedDebtId) || null;
  }, [generalDebts, selectedDebtId]);

  // Selected Debt Calculations
  const selectedDebtCalcs = useMemo(() => {
    if (!selectedDebt) return null;
    return getComprehensiveDebtCalculations(selectedDebt);
  }, [selectedDebt]);

  // Details Modal Sub-Forms State
  const [activeDetailsTab, setActiveDetailsTab] = useState<'overview' | 'add_debt' | 'add_payment'>('overview');

  // Add Debt Entry Form inside details modal
  const [entryAmount, setEntryAmount] = useState('');
  const [entryCurrency, setEntryCurrency] = useState<'YER' | 'SAR' | 'USD'>('YER');
  const [entryDate, setEntryDate] = useState(new Date().toISOString().split('T')[0]);
  const [entryProjectScope, setEntryProjectScope] = useState<'general' | 'project'>('general');
  const [entryProjectId, setEntryProjectId] = useState<string>('');
  const [entryProjectCustomName, setEntryProjectCustomName] = useState<string>('');
  const [entryDescription, setEntryDescription] = useState('');
  const [entryNotes, setEntryNotes] = useState('');
  const [entryError, setEntryError] = useState('');

  // Payment Form State inside Details Modal
  const [paymentAmount, setPaymentAmount] = useState('');
  const [paymentCurrency, setPaymentCurrency] = useState<'YER' | 'SAR' | 'USD'>('YER');
  const [paymentDate, setPaymentDate] = useState(new Date().toISOString().split('T')[0]);
  const [paymentReceipt, setPaymentReceipt] = useState('');
  const [paymentNotes, setPaymentNotes] = useState('');
  const [paymentError, setPaymentError] = useState('');

  // Sync default currency for payments whenever selected debt changes
  React.useEffect(() => {
    if (selectedDebt) {
      setEntryCurrency(selectedDebt.currency || 'YER');
      setPaymentCurrency(selectedDebt.currency || 'YER');
      setActiveDetailsTab('overview');
    }
  }, [selectedDebtId]);

  // Financial Summaries grouped strictly by currency across ALL debts
  const currencySummaries = useMemo(() => {
    const result: Record<'YER' | 'SAR' | 'USD', {
      receivableTotal: number;
      receivablePaid: number;
      receivableRemaining: number;
      payableTotal: number;
      payablePaid: number;
      payableRemaining: number;
    }> = {
      YER: { receivableTotal: 0, receivablePaid: 0, receivableRemaining: 0, payableTotal: 0, payablePaid: 0, payableRemaining: 0 },
      SAR: { receivableTotal: 0, receivablePaid: 0, receivableRemaining: 0, payableTotal: 0, payablePaid: 0, payableRemaining: 0 },
      USD: { receivableTotal: 0, receivablePaid: 0, receivableRemaining: 0, payableTotal: 0, payablePaid: 0, payableRemaining: 0 }
    };

    generalDebts.forEach(debt => {
      const { perCurrency } = getComprehensiveDebtCalculations(debt);
      (['YER', 'SAR', 'USD'] as const).forEach(curr => {
        const stats = perCurrency[curr];
        if (debt.type === 'receivable') {
          result[curr].receivableTotal += stats.totalDebt;
          result[curr].receivablePaid += stats.totalPaid;
          result[curr].receivableRemaining += stats.remaining;
        } else {
          result[curr].payableTotal += stats.totalDebt;
          result[curr].payablePaid += stats.totalPaid;
          result[curr].payableRemaining += stats.remaining;
        }
      });
    });

    return result;
  }, [generalDebts]);

  // Distinct Project Names for Filtering
  const availableFilterProjects = useMemo(() => {
    const set = new Set<string>();
    // From projects prop
    projects.forEach(p => {
      if (p.name?.trim()) set.add(p.name.trim());
    });
    // From general debts entries
    generalDebts.forEach(d => {
      const { entries } = getComprehensiveDebtCalculations(d);
      entries.forEach(e => {
        if (e.projectScope === 'project' && e.projectName?.trim()) {
          set.add(e.projectName.trim());
        }
      });
    });
    return Array.from(set).sort();
  }, [projects, generalDebts]);

  // Distinct Person Names for Datalist Autocomplete
  const existingPersonNames = useMemo(() => {
    return Array.from(new Set(generalDebts.map(d => d.personOrEntityName?.trim()).filter(Boolean)));
  }, [generalDebts]);

  // Filtered & Sorted Debts
  const filteredDebts = useMemo(() => {
    return generalDebts.filter(debt => {
      const calcs = getComprehensiveDebtCalculations(debt);

      // Search
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const matchName = debt.personOrEntityName?.toLowerCase().includes(q);
        const matchDesc = debt.description?.toLowerCase().includes(q);
        const matchNotes = debt.notes?.toLowerCase().includes(q);
        const matchPhone = debt.phone?.includes(q);
        const matchProject = calcs.distinctProjects.some(p => p.toLowerCase().includes(q));
        const matchEntries = calcs.entries.some(e => e.description?.toLowerCase().includes(q) || e.notes?.toLowerCase().includes(q));
        if (!matchName && !matchDesc && !matchNotes && !matchPhone && !matchProject && !matchEntries) return false;
      }

      // Type Filter
      if (typeFilter !== 'all' && debt.type !== typeFilter) return false;

      // Currency Filter
      if (currencyFilter !== 'all') {
        const hasCurr = calcs.activeCurrencies.includes(currencyFilter as any) &&
          (calcs.perCurrency[currencyFilter as 'YER' | 'SAR' | 'USD']?.totalDebt > 0 ||
           calcs.perCurrency[currencyFilter as 'YER' | 'SAR' | 'USD']?.totalPaid > 0);
        if (!hasCurr) return false;
      }

      // Project Filter
      if (projectFilter !== 'all') {
        if (projectFilter === 'general_only') {
          const isPureGeneral = calcs.entries.every(e => e.projectScope !== 'project' || !e.projectName);
          if (!isPureGeneral) return false;
        } else if (projectFilter === 'project_linked') {
          const hasProject = calcs.entries.some(e => e.projectScope === 'project' && !!e.projectName);
          if (!hasProject) return false;
        } else {
          // Specific project name
          const hasSpecificProject = calcs.entries.some(e => 
            e.projectScope === 'project' && e.projectName?.trim().toLowerCase() === projectFilter.trim().toLowerCase()
          );
          if (!hasSpecificProject) return false;
        }
      }

      // Status & Overdue Filter
      if (statusFilter !== 'all' && calcs.status !== statusFilter) return false;
      if (showOverdueOnly && !calcs.isOverdue) return false;

      return true;
    }).sort((a, b) => {
      const calcA = getComprehensiveDebtCalculations(a);
      const calcB = getComprehensiveDebtCalculations(b);

      if (sortOrder === 'newest') {
        return new Date(b.startDate || b.createdAt || 0).getTime() - new Date(a.startDate || a.createdAt || 0).getTime();
      }
      if (sortOrder === 'oldest') {
        return new Date(a.startDate || a.createdAt || 0).getTime() - new Date(b.startDate || b.createdAt || 0).getTime();
      }
      if (sortOrder === 'highest_remaining') {
        const remA = calcA.perCurrency.YER.remaining + calcA.perCurrency.SAR.remaining + calcA.perCurrency.USD.remaining;
        const remB = calcB.perCurrency.YER.remaining + calcB.perCurrency.SAR.remaining + calcB.perCurrency.USD.remaining;
        return remB - remA;
      }
      if (sortOrder === 'due_date') {
        if (!a.dueDate) return 1;
        if (!b.dueDate) return -1;
        return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
      }
      return 0;
    });
  }, [generalDebts, searchQuery, typeFilter, currencyFilter, projectFilter, statusFilter, showOverdueOnly, sortOrder]);

  // Resolve project name from selection
  const resolveProjectInfo = (
    scope: 'general' | 'project',
    projId: string,
    customName: string
  ): { projectId?: string; projectName?: string } => {
    if (scope === 'general') {
      return { projectId: undefined, projectName: undefined };
    }
    if (projId && projId !== 'custom') {
      const found = projects.find(p => p.id === projId);
      return {
        projectId: projId,
        projectName: found ? found.name : customName.trim()
      };
    }
    return {
      projectId: undefined,
      projectName: customName.trim() || undefined
    };
  };

  // Submit New Debt
  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');

    if (!newPersonName.trim()) {
      setFormError('يرجى إدخال اسم الشخص أو الجهة');
      return;
    }

    const amountNum = Number(newTotalAmount);
    if (!amountNum || amountNum <= 0) {
      setFormError('يرجى إدخال مبلغ صحيح أكبر من الصفر');
      return;
    }

    if (!newStartDate) {
      setFormError('يرجى تحديد تاريخ التسجيل');
      return;
    }

    const { projectId, projectName } = resolveProjectInfo(newProjectScope, newProjectId, newProjectCustomName);

    if (newProjectScope === 'project' && !projectName) {
      setFormError('يرجى تحديد المشروع أو كتابة اسمه');
      return;
    }

    // Check if person already exists with the same debt type (e.g. receivable/payable)
    const existingDebt = generalDebts.find(d => 
      d.personOrEntityName.trim().toLowerCase() === newPersonName.trim().toLowerCase() &&
      d.type === newType
    );

    if (existingDebt) {
      // Append as a new debt entry to their existing ledger
      const newEntry: Omit<GeneralDebtEntry, 'id' | 'createdAt'> = {
        amount: amountNum,
        currency: newCurrency,
        date: newStartDate,
        description: newDescription.trim() || (newProjectScope === 'project' ? `استدانة / دفعة دين - ${projectName}` : 'دفعة دين عام'),
        projectScope: newProjectScope,
        projectId,
        projectName,
        notes: newNotes.trim() || undefined,
        createdBy: currentUser
      };

      if (onAddDebtEntry) {
        onAddDebtEntry(existingDebt.id, newEntry);
      } else {
        // Fallback update
        const existingEntries = getDebtEntriesList(existingDebt);
        const updatedEntries = [...existingEntries, { ...newEntry, id: 'entry_' + Date.now(), createdAt: new Date().toISOString() }];
        onUpdateGeneralDebt(existingDebt.id, {
          entries: updatedEntries,
          updatedAt: new Date().toISOString()
        });
      }

      handleResetAddDebtForm();
      setShowAddModal(false);
      return;
    }

    // New debt record creation
    const initialEntry: GeneralDebtEntry = {
      id: 'entry_' + Date.now() + '_1',
      amount: amountNum,
      currency: newCurrency,
      date: newStartDate,
      description: newDescription.trim() || (newType === 'receivable' ? 'مستحق للشركة' : 'التزام على الشركة'),
      projectScope: newProjectScope,
      projectId,
      projectName,
      notes: newNotes.trim() || undefined,
      createdBy: currentUser,
      createdAt: new Date().toISOString()
    };

    onAddGeneralDebt({
      personOrEntityName: newPersonName.trim(),
      type: newType,
      description: newDescription.trim() || (newType === 'receivable' ? 'مستحق للشركة' : 'التزام على الشركة'),
      totalAmount: amountNum,
      currency: newCurrency,
      projectScope: newProjectScope,
      projectId,
      projectName,
      startDate: newStartDate,
      dueDate: newDueDate || undefined,
      phone: newPhone.trim() || undefined,
      notes: newNotes.trim() || undefined,
      entries: [initialEntry],
      createdBy: currentUser
    });

    handleResetAddDebtForm();
    setShowAddModal(false);
  };

  const handleResetAddDebtForm = () => {
    setNewPersonName('');
    setNewDescription('');
    setNewTotalAmount('');
    setNewCurrency('YER');
    setNewProjectScope('general');
    setNewProjectId('');
    setNewProjectCustomName('');
    setNewStartDate(new Date().toISOString().split('T')[0]);
    setNewDueDate('');
    setNewPhone('');
    setNewNotes('');
    setFormError('');
  };

  // Submit Add Debt Entry (استدانة إضافية لشخص معين)
  const handleAddDebtEntrySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedDebt) return;

    setEntryError('');
    const amt = Number(entryAmount);
    if (!amt || amt <= 0) {
      setEntryError('يرجى إدخال مبلغ صحيح أكبر من الصفر');
      return;
    }

    const { projectId, projectName } = resolveProjectInfo(entryProjectScope, entryProjectId, entryProjectCustomName);

    if (entryProjectScope === 'project' && !projectName) {
      setEntryError('يرجى اختيار المشروع أو كتابة اسمه');
      return;
    }

    const entryData: Omit<GeneralDebtEntry, 'id' | 'createdAt'> = {
      amount: amt,
      currency: entryCurrency,
      date: entryDate,
      description: entryDescription.trim() || (entryProjectScope === 'project' ? `دفعة دين - ${projectName}` : 'دفعة دين عام'),
      projectScope: entryProjectScope,
      projectId,
      projectName,
      notes: entryNotes.trim() || undefined,
      createdBy: currentUser
    };

    if (onAddDebtEntry) {
      onAddDebtEntry(selectedDebt.id, entryData);
    } else {
      const existingEntries = getDebtEntriesList(selectedDebt);
      const updatedEntries = [...existingEntries, { ...entryData, id: 'entry_' + Date.now(), createdAt: new Date().toISOString() }];
      onUpdateGeneralDebt(selectedDebt.id, {
        entries: updatedEntries,
        updatedAt: new Date().toISOString()
      });
    }

    // Reset entry form
    setEntryAmount('');
    setEntryDescription('');
    setEntryNotes('');
    setEntryProjectScope('general');
    setEntryProjectId('');
    setEntryProjectCustomName('');
    setActiveDetailsTab('overview');
  };

  // Submit Payment
  const handlePaymentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedDebt || !selectedDebtCalcs) return;

    setPaymentError('');
    const amt = Number(paymentAmount);
    if (!amt || amt <= 0) {
      setPaymentError('يرجى إدخال مبلغ دفعة صحيح أكبر من الصفر');
      return;
    }

    const currencyRemaining = selectedDebtCalcs.perCurrency[paymentCurrency]?.remaining || 0;
    if (amt > currencyRemaining) {
      setPaymentError(`مبلغ الدفعة (${formatCurrency(amt, paymentCurrency)}) يتجاوز الرصيد المتبقي المطلوب سداده لهذه العملة (${formatCurrency(currencyRemaining, paymentCurrency)})`);
      return;
    }

    onAddPayment(selectedDebt.id, {
      date: paymentDate,
      amount: amt,
      currency: paymentCurrency,
      receiptNumber: paymentReceipt.trim() || undefined,
      notes: paymentNotes.trim() || undefined,
      createdBy: currentUser
    });

    // Reset payment form
    setPaymentAmount('');
    setPaymentReceipt('');
    setPaymentNotes('');
    setActiveDetailsTab('overview');
  };

  // Submit Edit Debt
  const handleEditSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingDebt) return;

    onUpdateGeneralDebt(editingDebt.id, {
      personOrEntityName: editingDebt.personOrEntityName,
      type: editingDebt.type,
      startDate: editingDebt.startDate,
      dueDate: editingDebt.dueDate || undefined,
      phone: editingDebt.phone || undefined,
      description: editingDebt.description,
      notes: editingDebt.notes || undefined,
      projectScope: editingDebt.projectScope,
      projectId: editingDebt.projectId,
      projectName: editingDebt.projectName,
      updatedBy: currentUser,
      updatedAt: new Date().toISOString()
    });

    setEditingDebt(null);
  };

  // Export to Excel
  const handleExportExcel = () => {
    const headers = [
      'اسم الشخص / الجهة',
      'نوع الالتزام',
      'المشروع / الارتباط',
      'العملة',
      'إجمالي الدين',
      'المسدد',
      'المتبقي',
      'حالة السداد',
      'عدد دفعات الدين',
      'عدد دفعات السداد',
      'تاريخ البدء',
      'تاريخ الاستحقاق',
      'رقم الهاتف',
      'الوصف العام',
      'ملاحظات'
    ];

    const rows: (string | number)[][] = [];

    filteredDebts.forEach(d => {
      const calcs = getComprehensiveDebtCalculations(d);
      const projLabel = calcs.distinctProjects.join('، ');

      calcs.activeCurrencies.forEach(curr => {
        const stats = calcs.perCurrency[curr];
        if (stats.totalDebt > 0 || stats.totalPaid > 0) {
          rows.push([
            d.personOrEntityName,
            d.type === 'receivable' ? 'لنا (مستحق للشركة)' : 'علينا (مستحق على الشركة)',
            projLabel,
            curr,
            stats.totalDebt,
            stats.totalPaid,
            stats.remaining,
            stats.remaining === 0 ? 'مسدد بالكامل' : stats.totalPaid > 0 ? 'مسدد جزئياً' : 'غير مسدد',
            calcs.entries.filter(e => (e.currency || d.currency) === curr).length,
            (d.payments || []).filter(p => (p.currency || d.currency) === curr).length,
            d.startDate,
            d.dueDate || 'غير محدد',
            d.phone || '-',
            d.description,
            d.notes || '-'
          ]);
        }
      });
    });

    exportToXLSX('كشف_الديون_والالتزامات_العامة_والمشاريع', headers, rows, 'الديون والالتزامات');
  };

  // Print PDF for the whole filtered list
  const handlePrintPDF = () => {
    let rowsHtml = '';
    filteredDebts.forEach(d => {
      const calcs = getComprehensiveDebtCalculations(d);
      const statusText = calcs.status === 'settled' ? 'مسدد بالكامل' : calcs.status === 'partially_paid' ? 'مسدد جزئياً' : 'غير مسدد';
      const typeText = d.type === 'receivable' ? 'لنا' : 'علينا';
      const typeColor = d.type === 'receivable' ? '#16a34a' : '#e11d48';
      const projText = calcs.distinctProjects.map(p => `<span style="background: #f1f5f9; padding: 2px 6px; border-radius: 4px; font-size: 11px;">${p}</span>`).join(' ');

      calcs.activeCurrencies.forEach(curr => {
        const stats = calcs.perCurrency[curr];
        if (stats.totalDebt > 0 || stats.totalPaid > 0) {
          rowsHtml += `
            <tr>
              <td class="col-statement">
                <strong>${d.personOrEntityName}</strong>
                ${d.description ? `<br><small style="color: #64748b;">${d.description}</small>` : ''}
              </td>
              <td><span style="color: ${typeColor}; font-weight: bold;">${typeText}</span></td>
              <td>${projText}</td>
              <td>${curr}</td>
              <td>${formatCurrency(stats.totalDebt, curr)}</td>
              <td>${formatCurrency(stats.totalPaid, curr)}</td>
              <td><strong>${formatCurrency(stats.remaining, curr)}</strong></td>
              <td>${statusText}</td>
              <td>${formatDateArabic(d.startDate)}</td>
            </tr>
          `;
        }
      });
    });

    const summaryHtml = `
      <div style="display: flex; justify-content: space-around; margin-bottom: 20px; background: #f8fafc; padding: 15px; border-radius: 8px; border: 1px solid #cbd5e1;">
        <div>
          <h4 style="margin: 0 0 5px 0; color: #16a34a;">إجمالي مستحقات لنا (حسب العملة):</h4>
          <div>ريال يمني: <strong>${formatCurrency(currencySummaries.YER.receivableRemaining, 'YER')}</strong> (من ${formatCurrency(currencySummaries.YER.receivableTotal, 'YER')})</div>
          <div>ريال سعودي: <strong>${formatCurrency(currencySummaries.SAR.receivableRemaining, 'SAR')}</strong> (من ${formatCurrency(currencySummaries.SAR.receivableTotal, 'SAR')})</div>
          <div>دولار أمريكي: <strong>${formatCurrency(currencySummaries.USD.receivableRemaining, 'USD')}</strong> (من ${formatCurrency(currencySummaries.USD.receivableTotal, 'USD')})</div>
        </div>
        <div>
          <h4 style="margin: 0 0 5px 0; color: #e11d48;">إجمالي التزامات علينا (حسب العملة):</h4>
          <div>ريال يمني: <strong>${formatCurrency(currencySummaries.YER.payableRemaining, 'YER')}</strong> (من ${formatCurrency(currencySummaries.YER.payableTotal, 'YER')})</div>
          <div>ريال سعودي: <strong>${formatCurrency(currencySummaries.SAR.payableRemaining, 'SAR')}</strong> (من ${formatCurrency(currencySummaries.SAR.payableTotal, 'SAR')})</div>
          <div>دولار أمريكي: <strong>${formatCurrency(currencySummaries.USD.payableRemaining, 'USD')}</strong> (من ${formatCurrency(currencySummaries.USD.payableTotal, 'USD')})</div>
        </div>
      </div>
    `;

    const fullHtml = `
      ${summaryHtml}
      <table>
        <thead>
          <tr>
            <th class="col-statement">الاسم / الجهة / البيان</th>
            <th>النوع</th>
            <th>المشروع / الارتباط</th>
            <th>العملة</th>
            <th>إجمالي الدين</th>
            <th>المسدد</th>
            <th>المتبقي</th>
            <th>الحالة</th>
            <th>تاريخ البدء</th>
          </tr>
        </thead>
        <tbody>
          ${rowsHtml}
        </tbody>
      </table>
    `;

    printPDF('كشف الديون والالتزامات العامة والمشاريع', fullHtml);
  };

  // Print PDF statement for a single person
  const handlePrintPersonStatement = (debt: GeneralDebt) => {
    const calcs = getComprehensiveDebtCalculations(debt);
    const typeTitle = debt.type === 'receivable' ? 'مستحق للشركة (لنا لدى الطرف)' : 'التزام على الشركة (علينا للطرف)';

    let currenciesSummaryHtml = '';
    calcs.activeCurrencies.forEach(curr => {
      const stats = calcs.perCurrency[curr];
      currenciesSummaryHtml += `
        <div style="background: #ffffff; padding: 12px; border-radius: 8px; border: 1px solid #e2e8f0; text-align: center; flex: 1; margin: 4px;">
          <div style="font-size: 13px; font-weight: bold; color: #334155; margin-bottom: 4px;">عملة ${curr}</div>
          <div style="font-size: 11px; color: #64748b;">إجمالي الدين: <strong>${formatCurrency(stats.totalDebt, curr)}</strong></div>
          <div style="font-size: 11px; color: #16a34a;">المسدد: <strong>${formatCurrency(stats.totalPaid, curr)}</strong></div>
          <div style="font-size: 13px; font-weight: bold; color: #e11d48; margin-top: 4px;">المتبقي: ${formatCurrency(stats.remaining, curr)}</div>
        </div>
      `;
    });

    let entriesRows = '';
    calcs.entries.forEach((e, idx) => {
      const pLabel = e.projectScope === 'project' && e.projectName ? e.projectName : 'دين عام للشركة';
      entriesRows += `
        <tr>
          <td>${idx + 1}</td>
          <td>${formatDateArabic(e.date)}</td>
          <td>${e.description || '-'}</td>
          <td><span style="background: #f1f5f9; padding: 2px 6px; border-radius: 4px;">${pLabel}</span></td>
          <td style="font-weight: bold;">${formatCurrency(e.amount, e.currency || debt.currency)}</td>
          <td>${e.currency || debt.currency}</td>
          <td>${e.notes || '-'}</td>
        </tr>
      `;
    });

    let paymentsRows = '';
    if ((debt.payments || []).length === 0) {
      paymentsRows = `<tr><td colspan="6" style="text-align: center; color: #94a3b8;">لا توجد دفعات سداد مسجلة حتى الآن</td></tr>`;
    } else {
      (debt.payments || []).forEach((p, idx) => {
        paymentsRows += `
          <tr>
            <td>${idx + 1}</td>
            <td>${formatDateArabic(p.date)}</td>
            <td style="font-weight: bold; color: #16a34a;">${formatCurrency(p.amount, p.currency || debt.currency)}</td>
            <td>${p.currency || debt.currency}</td>
            <td>${p.receiptNumber || '-'}</td>
            <td>${p.notes || '-'}</td>
          </tr>
        `;
      });
    }

    const fullHtml = `
      <div style="margin-bottom: 20px; border-bottom: 2px solid #0f172a; padding-bottom: 12px;">
        <div style="display: flex; justify-content: space-between; align-items: center;">
          <div>
            <h2 style="margin: 0; font-size: 20px; color: #0f172a;">كشف حساب مالي تفصيلي: ${debt.personOrEntityName}</h2>
            <div style="font-size: 13px; color: #475569; margin-top: 4px;">نوع الحساب: <strong>${typeTitle}</strong> | الهاتف: <strong>${debt.phone || 'غير مسجل'}</strong></div>
          </div>
          <div style="text-align: left; font-size: 12px; color: #64748b;">
            تاريخ التقرير: ${formatDateArabic(new Date().toISOString().split('T')[0])}
          </div>
        </div>
      </div>

      <div style="display: flex; justify-content: space-between; margin-bottom: 20px; flex-wrap: wrap;">
        ${currenciesSummaryHtml}
      </div>

      <h3 style="font-size: 14px; color: #0f172a; margin-top: 20px; margin-bottom: 8px;">أولاً: سجل دفعات الدين والاستدانات (${calcs.entries.length}):</h3>
      <table>
        <thead>
          <tr>
            <th>#</th>
            <th>التاريخ</th>
            <th>البيان / الغرض</th>
            <th>المشروع / الارتباط</th>
            <th>المبلغ</th>
            <th>العملة</th>
            <th>ملاحظات</th>
          </tr>
        </thead>
        <tbody>
          ${entriesRows}
        </tbody>
      </table>

      <h3 style="font-size: 14px; color: #0f172a; margin-top: 25px; margin-bottom: 8px;">ثانياً: سجل دفعات السداد (${(debt.payments || []).length}):</h3>
      <table>
        <thead>
          <tr>
            <th>#</th>
            <th>التاريخ</th>
            <th>مبلغ السداد</th>
            <th>العملة</th>
            <th>رقم السند</th>
            <th>ملاحظات</th>
          </tr>
        </thead>
        <tbody>
          ${paymentsRows}
        </tbody>
      </table>
    `;

    printPDF(`كشف حساب تفصيلي - ${debt.personOrEntityName}`, fullHtml);
  };

  // Share text for WhatsApp/Messaging
  const shareSummaryText = useMemo(() => {
    const lines = [
      '🏢 *تقرير الديون والالتزامات العامة والمشاريع:*',
      `📅 التاريخ: ${formatDateArabic(new Date().toISOString().split('T')[0])}`,
      '',
      '🟢 *المستحقات للشركة (لنا لدى الغير):*',
      `• ريال يمني: متبقي ${formatCurrency(currencySummaries.YER.receivableRemaining, 'YER')} (من إجمالي ${formatCurrency(currencySummaries.YER.receivableTotal, 'YER')})`,
      `• ريال سعودي: متبقي ${formatCurrency(currencySummaries.SAR.receivableRemaining, 'SAR')} (من إجمالي ${formatCurrency(currencySummaries.SAR.receivableTotal, 'SAR')})`,
      `• دولار أمريكي: متبقي ${formatCurrency(currencySummaries.USD.receivableRemaining, 'USD')} (من إجمالي ${formatCurrency(currencySummaries.USD.receivableTotal, 'USD')})`,
      '',
      '🔴 *الالتزامات على الشركة (علينا للغير):*',
      `• ريال يمني: متبقي ${formatCurrency(currencySummaries.YER.payableRemaining, 'YER')} (من إجمالي ${formatCurrency(currencySummaries.YER.payableTotal, 'YER')})`,
      `• ريال سعودي: متبقي ${formatCurrency(currencySummaries.SAR.payableRemaining, 'SAR')} (من إجمالي ${formatCurrency(currencySummaries.SAR.payableTotal, 'SAR')})`,
      `• دولار أمريكي: متبقي ${formatCurrency(currencySummaries.USD.payableRemaining, 'USD')} (من إجمالي ${formatCurrency(currencySummaries.USD.payableTotal, 'USD')})`
    ];
    return lines.join('\n');
  }, [currencySummaries]);

  return (
    <div className="space-y-4 animate-fade-in dir-rtl text-right pb-12">
      
      {/* 1. Header Card */}
      <PageHeaderCard
        title="الديون والالتزامات العامة والمشاريع"
        description="سجل الالتزامات والمستحقات المالية للشركة، مع ربط كل دين بدين عام أو بمشروع محدد وإمكانية تعدد دفعات الدين والعملات لكل شخص"
        icon={<Building2 size={24} className="text-indigo-600" />}
        onBack={setActiveTab ? () => setActiveTab('projects') : undefined}
        optionsMenu={
          <OptionsMenu
            onExportExcel={handleExportExcel}
            onExportPDF={handlePrintPDF}
            shareTitle="كشف الديون والالتزامات العامة والمشاريع"
            shareText={shareSummaryText}
          />
        }
      />

      {/* 2. Financial Summary Cards per Currency */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        
        {/* Card 1: لنا (Receivables) */}
        <div className="bg-white p-4 rounded-2xl border border-emerald-100 shadow-xs space-y-3">
          <div className="flex items-center justify-between border-b border-emerald-50 pb-2">
            <div className="flex items-center gap-2">
              <div className="p-2 bg-emerald-50 text-emerald-600 rounded-xl">
                <ArrowDownLeft size={18} />
              </div>
              <div>
                <h3 className="font-extrabold text-slate-800 text-sm">مستحقات للشركة (لنا لدى الغير)</h3>
                <span className="text-[10px] text-slate-400">مبالغ نطالب بها أطرافاً خارجية</span>
              </div>
            </div>
            <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-lg">
              لنا
            </span>
          </div>

          <div className="grid grid-cols-3 gap-2">
            {(['YER', 'SAR', 'USD'] as const).map(curr => (
              <div key={curr} className="p-2.5 bg-emerald-50/40 rounded-xl border border-emerald-100/60 space-y-1">
                <span className="text-[10px] font-black text-emerald-800 block">عملة ({curr})</span>
                <div className="text-xs font-mono font-black text-emerald-700">
                  {formatCurrency(currencySummaries[curr].receivableRemaining, curr)}
                </div>
                <div className="text-[10px] text-slate-400 flex justify-between">
                  <span>المسدد:</span>
                  <span className="font-mono">{formatCurrency(currencySummaries[curr].receivablePaid, curr)}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Card 2: علينا (Payables) */}
        <div className="bg-white p-4 rounded-2xl border border-rose-100 shadow-xs space-y-3">
          <div className="flex items-center justify-between border-b border-rose-50 pb-2">
            <div className="flex items-center gap-2">
              <div className="p-2 bg-rose-50 text-rose-600 rounded-xl">
                <ArrowUpRight size={18} />
              </div>
              <div>
                <h3 className="font-extrabold text-slate-800 text-sm">التزامات على الشركة (علينا للغير)</h3>
                <span className="text-[10px] text-slate-400">مبالغ تطالبنا بها أطراف خارجية</span>
              </div>
            </div>
            <span className="text-xs font-bold text-rose-700 bg-rose-50 px-2.5 py-1 rounded-lg">
              علينا
            </span>
          </div>

          <div className="grid grid-cols-3 gap-2">
            {(['YER', 'SAR', 'USD'] as const).map(curr => (
              <div key={curr} className="p-2.5 bg-rose-50/40 rounded-xl border border-rose-100/60 space-y-1">
                <span className="text-[10px] font-black text-rose-800 block">عملة ({curr})</span>
                <div className="text-xs font-mono font-black text-rose-700">
                  {formatCurrency(currencySummaries[curr].payableRemaining, curr)}
                </div>
                <div className="text-[10px] text-slate-400 flex justify-between">
                  <span>المسدد:</span>
                  <span className="font-mono">{formatCurrency(currencySummaries[curr].payablePaid, curr)}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>

      {/* 3. Action Toolbar & Search & Filters */}
      <div className="bg-white p-3.5 rounded-2xl border border-slate-100 shadow-xs space-y-3">
        
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          
          {/* Search Box */}
          <div className="relative flex-1">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="ابحث بالاسم، المشروع، الوصف، رقم الهاتف، أو الملاحظات..."
              className="w-full p-2.5 pr-9 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 text-xs focus:outline-hidden focus:border-indigo-500 transition-colors"
            />
            <Search size={15} className="absolute top-1/2 -translate-y-1/2 right-3 text-slate-400" />
            {searchQuery && (
              <button 
                onClick={() => setSearchQuery('')}
                className="absolute top-1/2 -translate-y-1/2 left-3 text-slate-400 hover:text-slate-600"
              >
                <X size={14} />
              </button>
            )}
          </div>

          {/* Add New Debt Button */}
          {sharedRole !== 'read' && (
            <button
              onClick={() => setShowAddModal(true)}
              className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs py-2.5 px-4 rounded-xl shadow-xs transition-colors flex items-center justify-center gap-1.5 cursor-pointer shrink-0"
            >
              <PlusCircle size={16} />
              <span>إضافة دين جديد</span>
            </button>
          )}

        </div>

        {/* Filter Pills */}
        <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-slate-100 text-xs">
          
          {/* Type Filter */}
          <div className="flex items-center gap-1 bg-slate-50 p-1 rounded-xl border border-slate-200">
            <button
              onClick={() => setTypeFilter('all')}
              className={`px-2.5 py-1 rounded-lg font-bold transition-colors cursor-pointer ${
                typeFilter === 'all' ? 'bg-white text-slate-800 shadow-xs' : 'text-slate-500 hover:text-slate-700'
              }`}
            >
              الكل ({generalDebts.length})
            </button>
            <button
              onClick={() => setTypeFilter('receivable')}
              className={`px-2.5 py-1 rounded-lg font-bold transition-colors cursor-pointer ${
                typeFilter === 'receivable' ? 'bg-emerald-600 text-white shadow-xs' : 'text-emerald-700 hover:bg-emerald-50'
              }`}
            >
              لنا
            </button>
            <button
              onClick={() => setTypeFilter('payable')}
              className={`px-2.5 py-1 rounded-lg font-bold transition-colors cursor-pointer ${
                typeFilter === 'payable' ? 'bg-rose-600 text-white shadow-xs' : 'text-rose-700 hover:bg-rose-50'
              }`}
            >
              علينا
            </button>
          </div>

          {/* Project Filter */}
          <div className="flex items-center gap-1">
            <FolderGit2 size={14} className="text-slate-400" />
            <select
              value={projectFilter}
              onChange={(e) => setProjectFilter(e.target.value)}
              className="p-1.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 font-bold focus:outline-hidden cursor-pointer"
            >
              <option value="all">كل المشاريع والارتباطات</option>
              <option value="general_only">ديون عامة فقط (للشركة)</option>
              <option value="project_linked">مرتبطة بمشاريع فقط</option>
              {availableFilterProjects.length > 0 && (
                <optgroup label="المشاريع المحددة">
                  {availableFilterProjects.map(pName => (
                    <option key={pName} value={pName}>{pName}</option>
                  ))}
                </optgroup>
              )}
            </select>
          </div>

          {/* Currency Filter */}
          <select
            value={currencyFilter}
            onChange={(e) => setCurrencyFilter(e.target.value)}
            className="p-1.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 font-bold focus:outline-hidden cursor-pointer"
          >
            <option value="all">كل العملات</option>
            <option value="YER">YER (ريال يمني)</option>
            <option value="SAR">SAR (ريال سعودي)</option>
            <option value="USD">USD (دولار)</option>
          </select>

          {/* Status Filter */}
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="p-1.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 font-bold focus:outline-hidden cursor-pointer"
          >
            <option value="all">كل الحالات</option>
            <option value="active">غير مسدد (نشط)</option>
            <option value="partially_paid">مسدد جزئياً</option>
            <option value="settled">مسدد بالكامل</option>
          </select>

          {/* Overdue Checkbox Filter */}
          <button
            onClick={() => setShowOverdueOnly(!showOverdueOnly)}
            className={`px-3 py-1.5 rounded-xl font-bold border transition-colors flex items-center gap-1 cursor-pointer ${
              showOverdueOnly 
                ? 'bg-amber-500 text-white border-amber-600' 
                : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
            }`}
          >
            <AlertCircle size={13} />
            <span>متأخرات فقط</span>
          </button>

          {/* Sort Order */}
          <div className="mr-auto flex items-center gap-1 text-[11px] text-slate-400">
            <span>الترتيب:</span>
            <select
              value={sortOrder}
              onChange={(e) => setSortOrder(e.target.value as any)}
              className="bg-transparent text-slate-700 font-bold focus:outline-hidden cursor-pointer"
            >
              <option value="newest">الأحدث أولاً</option>
              <option value="oldest">الأقدم أولاً</option>
              <option value="highest_remaining">الأعلى متبقياً</option>
              <option value="due_date">تاريخ الاستحقاق</option>
            </select>
          </div>

        </div>

      </div>

      {/* 4. Debts Cards Grid */}
      {filteredDebts.length === 0 ? (
        <div className="bg-white p-12 text-center rounded-2xl border border-slate-100 shadow-xs space-y-2">
          <Building2 size={36} className="mx-auto text-slate-300" />
          <p className="text-slate-500 font-bold text-sm">لا توجد ديون أو التزامات تطابق البحث والتصفية</p>
          <p className="text-xs text-slate-400">
            {generalDebts.length === 0 
              ? 'انقر على "إضافة دين جديد" لتسجيل أول حركة' 
              : 'جرّب تغيير خيارات البحث أو التصفية'}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredDebts.map(debt => {
            const calcs = getComprehensiveDebtCalculations(debt);
            const isReceivable = debt.type === 'receivable';

            return (
              <div
                key={debt.id}
                className="bg-white p-4 rounded-2xl border border-slate-100 hover:border-indigo-200 shadow-xs hover:shadow-md transition-all flex flex-col justify-between space-y-3 group"
              >
                <div className="space-y-2.5">
                  
                  {/* Card Header */}
                  <div className="flex items-start justify-between gap-2 border-b border-slate-50 pb-2.5">
                    <div className="space-y-1 flex-1 min-w-0">
                      <h4 className="font-extrabold text-slate-800 text-sm group-hover:text-indigo-600 transition-colors truncate">
                        {debt.personOrEntityName}
                      </h4>
                      <div className="flex flex-wrap items-center gap-1.5">
                        {debt.sourceEntityType && (
                          <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-md flex items-center gap-1 bg-teal-50 text-teal-800 border border-teal-200">
                            <CheckCheck size={10} className="text-teal-600" />
                            <span>مرحّل من كشف المشروع</span>
                          </span>
                        )}
                        {calcs.distinctProjects.map((pName, pIdx) => (
                          <span
                            key={pIdx}
                            className={`text-[10px] font-bold px-2 py-0.5 rounded-md flex items-center gap-1 ${
                              pName === 'دين عام للشركة'
                                ? 'bg-slate-100 text-slate-700'
                                : 'bg-sky-50 text-sky-800 border border-sky-100'
                            }`}
                          >
                            {pName === 'دين عام للشركة' ? <Building2 size={10} /> : <FolderGit2 size={10} />}
                            <span className="truncate max-w-[140px]">{pName}</span>
                          </span>
                        ))}
                      </div>
                    </div>

                    <div className="flex flex-col items-end gap-1 shrink-0">
                      <span className={`text-[11px] font-black px-2 py-0.5 rounded-md ${
                        isReceivable ? 'bg-emerald-50 text-emerald-700' : 'bg-rose-50 text-rose-700'
                      }`}>
                        {isReceivable ? 'لنا' : 'علينا'}
                      </span>
                      <span className="text-[10px] text-slate-400 font-mono">
                        {calcs.entries.length} استدانة | {(debt.payments || []).length} سداد
                      </span>
                    </div>
                  </div>

                  {/* Financial Breakdown per Active Currency */}
                  <div className="space-y-2">
                    {calcs.activeCurrencies.map(curr => {
                      const stats = calcs.perCurrency[curr];
                      return (
                        <div key={curr} className="bg-slate-50/70 p-2 rounded-xl border border-slate-100 space-y-1 text-xs">
                          <div className="flex items-center justify-between text-slate-600 font-bold">
                            <span className="flex items-center gap-1">
                              <Coins size={12} className="text-amber-500" />
                              <span>عملة ({curr}):</span>
                            </span>
                            <span className="font-mono text-slate-800">
                              {formatCurrency(stats.totalDebt, curr)}
                            </span>
                          </div>

                          <div className="flex justify-between text-[11px] text-slate-500">
                            <span>المسدد:</span>
                            <span className="font-mono font-bold text-emerald-600">
                              {formatCurrency(stats.totalPaid, curr)} ({stats.percentage}%)
                            </span>
                          </div>

                          <div className="flex justify-between font-extrabold text-[11px] pt-1 border-t border-slate-200/60">
                            <span className="text-slate-700">المتبقي:</span>
                            <span className={`font-mono ${
                              stats.remaining === 0 
                                ? 'text-emerald-600' 
                                : isReceivable 
                                  ? 'text-emerald-700 font-black' 
                                  : 'text-rose-700 font-black'
                            }`}>
                              {formatCurrency(stats.remaining, curr)}
                            </span>
                          </div>

                          {/* Progress */}
                          <div className="w-full bg-slate-200/60 h-1.5 rounded-full overflow-hidden mt-1">
                            <div 
                              className={`h-full transition-all duration-500 ${
                                stats.remaining === 0 ? 'bg-emerald-500' : isReceivable ? 'bg-emerald-600' : 'bg-rose-500'
                              }`}
                              style={{ width: `${stats.percentage}%` }}
                            />
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  {/* Dates & Status Badge */}
                  <div className="flex flex-wrap items-center justify-between gap-1 text-[11px] pt-1 text-slate-400">
                    <span>تاريخ: {formatDateArabic(debt.startDate)}</span>
                    
                    {debt.dueDate && (
                      <span className={`flex items-center gap-1 font-bold ${
                        calcs.isOverdue ? 'text-amber-600' : 'text-slate-500'
                      }`}>
                        <Calendar size={11} />
                        استحقاق: {formatDateArabic(debt.dueDate)}
                        {calcs.isOverdue && '(متأخر)'}
                      </span>
                    )}
                  </div>

                  {/* Phone */}
                  {debt.phone && (
                    <div className="flex items-center gap-1 text-[11px] text-slate-500">
                      <Phone size={12} className="text-slate-400" />
                      <span dir="ltr">{debt.phone}</span>
                    </div>
                  )}

                  {/* Notes */}
                  {debt.notes && (
                    <p className="text-[11px] text-slate-500 bg-slate-50 p-1.5 rounded-lg line-clamp-1">
                      {debt.notes}
                    </p>
                  )}

                </div>

                {/* Card Action Buttons */}
                <div className="flex items-center justify-between pt-2.5 border-t border-slate-50 text-xs">
                  
                  <button
                    onClick={() => setSelectedDebtId(debt.id)}
                    className="bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold py-1.5 px-3 rounded-xl border border-indigo-200 transition-colors flex items-center gap-1.5 cursor-pointer"
                  >
                    <span>كشف الحساب والعمليات</span>
                    <ChevronLeft size={14} className="rotate-180" />
                  </button>

                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => handlePrintPersonStatement(debt)}
                      className="p-1.5 text-slate-400 hover:text-indigo-600 hover:bg-slate-50 rounded-lg transition-colors cursor-pointer"
                      title="طباعة كشف حساب تفصيلي"
                    >
                      <Printer size={14} />
                    </button>

                    {sharedRole !== 'read' && (
                      <button
                        onClick={() => setEditingDebt(debt)}
                        className="p-1.5 text-slate-400 hover:text-indigo-600 hover:bg-slate-50 rounded-lg transition-colors cursor-pointer"
                        title="تعديل بيانات الحساب"
                      >
                        <Pencil size={14} />
                      </button>
                    )}

                    {sharedRole !== 'read' && sharedRole !== 'add' && (
                      <button
                        onClick={() => {
                          const isMigrated = Boolean(debt.sourceEntityType && debt.sourceEntityId);
                          const confirmMsg = isMigrated
                            ? `هذا الدين مرحل من كشف حسابات مشروع (${debt.projectName || 'المشروع'}).\n\nهل تريد إلغاء ترحيله وحذفه من الديون العامة للشركة؟\n(ملاحظة: لن يتأثر حساب الشخص داخل المشروع، ويمكنك إعادة ترحيله في أي وقت من نافذة ديون المشروع).`
                            : `هل أنت متأكد من حذف حساب دين "${debt.personOrEntityName}" بالكامل؟ سيتم حذف كافة الدفعات والاستدانات المسجلة له.`;
                          if (confirm(confirmMsg)) {
                            onDeleteGeneralDebt(debt.id);
                          }
                        }}
                        className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                        title={debt.sourceEntityType ? "إلغاء الترحيل وحذف الدين من الديون العامة" : "حذف الدين"}
                      >
                        <Trash2 size={14} />
                      </button>
                    )}
                  </div>

                </div>

              </div>
            );
          })}
        </div>
      )}

      {/* 5. Add Debt Modal */}
      {showAddModal && (
        <div 
          className="fixed inset-0 z-[100] bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto animate-fade-in dir-rtl text-right overscroll-contain"
          onTouchMove={(e) => {
            if (e.target === e.currentTarget) e.preventDefault();
          }}
        >
          <div 
            className="bg-white rounded-3xl shadow-2xl border border-slate-100 max-w-lg w-full overflow-hidden my-auto animate-scale-up overscroll-contain max-h-[90vh] flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="bg-gradient-to-r from-teal-700 to-slate-900 text-white p-4 sm:p-5 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-white/10 rounded-xl">
                  <Landmark size={20} className="text-teal-200" />
                </div>
                <div>
                  <h3 className="font-extrabold text-base">إضافة دين / التزام مالي</h3>
                  <p className="text-xs text-teal-100">سجل دين عام للشركة أو اربطه بمشروع محدد</p>
                </div>
              </div>
              <button 
                type="button"
                onClick={() => setShowAddModal(false)}
                className="p-1.5 text-teal-200 hover:text-white hover:bg-white/10 rounded-xl transition-colors cursor-pointer"
              >
                <X size={20} />
              </button>
            </div>

            {/* Scrollable Form Body */}
            <div className="flex-1 overflow-hidden flex flex-row min-h-0 relative">
              <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4 overscroll-contain touch-pan-y custom-scrollbar modal-scroll-area">
                <form id="add-general-debt-form" onSubmit={handleAddSubmit} className="space-y-4">
                
                {formError && (
                  <div className="p-3 bg-rose-50 text-rose-700 border border-rose-200 rounded-2xl text-xs font-bold">
                    {formError}
                  </div>
                )}

                {/* Type: لنا / علينا */}
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700 block">نوع الالتزام <span className="text-rose-500">*</span></label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setNewType('receivable')}
                      className={`p-3 rounded-2xl border text-xs font-extrabold flex items-center justify-center gap-2 transition-all cursor-pointer ${
                        newType === 'receivable'
                          ? 'bg-emerald-600 text-white border-emerald-600 shadow-sm'
                          : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      <ArrowDownLeft size={16} />
                      <span>لنا (مستحق للشركة)</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setNewType('payable')}
                      className={`p-3 rounded-2xl border text-xs font-extrabold flex items-center justify-center gap-2 transition-all cursor-pointer ${
                        newType === 'payable'
                          ? 'bg-rose-600 text-white border-rose-600 shadow-sm'
                          : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      <ArrowUpRight size={16} />
                      <span>علينا (مستحق على الشركة)</span>
                    </button>
                  </div>
                </div>

                {/* Person or Entity Name */}
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700 block">اسم الشخص / الجهة <span className="text-rose-500">*</span></label>
                  <input
                    type="text"
                    list="person-names-datalist"
                    value={newPersonName}
                    onChange={(e) => setNewPersonName(e.target.value)}
                    placeholder="مثال: شركة النور، م/ أحمد علي، مقاول الباطن..."
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 text-xs focus:outline-hidden focus:border-teal-500 focus:bg-white transition-all font-bold"
                    required
                  />
                  <datalist id="person-names-datalist">
                    {existingPersonNames.map((name, idx) => (
                      <option key={idx} value={name} />
                    ))}
                  </datalist>
                  {existingPersonNames.includes(newPersonName.trim()) && (
                    <span className="text-[11px] text-teal-600 font-bold block">
                      💡 هذا الطرف مسجل مسبقاً، سيتم إضافة هذا الدين كدفعة دين إضافية في حسابه المالي
                    </span>
                  )}
                </div>

                {/* Project Scope Association (دين عام أو مرتبط بمشروع) */}
                <div className="space-y-2 p-3 bg-slate-50 rounded-2xl border border-slate-200">
                  <label className="text-xs font-extrabold text-slate-800 block flex items-center gap-1.5">
                    <FolderGit2 size={15} className="text-teal-600" />
                    <span>ارتباط الدين (عام أو بمشروع محدد): <span className="text-rose-500">*</span></span>
                  </label>

                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        setNewProjectScope('general');
                        setNewProjectId('');
                        setNewProjectCustomName('');
                      }}
                      className={`p-2.5 rounded-xl border text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                        newProjectScope === 'general'
                          ? 'bg-teal-700 text-white border-teal-700 shadow-xs'
                          : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      <Building2 size={14} />
                      <span>دين عام للشركة</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setNewProjectScope('project')}
                      className={`p-2.5 rounded-xl border text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                        newProjectScope === 'project'
                          ? 'bg-teal-700 text-white border-teal-700 shadow-xs'
                          : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      <FolderGit2 size={14} />
                      <span>مرتبط بمشروع محدد</span>
                    </button>
                  </div>

                  {newProjectScope === 'project' && (
                    <div className="space-y-2 pt-2 border-t border-slate-200 animate-fade-in">
                      <div className="space-y-1">
                        <label className="text-[11px] font-bold text-slate-700 block">اختر المشروع أو اكتب اسمه:</label>
                        <select
                          value={newProjectId}
                          onChange={(e) => setNewProjectId(e.target.value)}
                          className="w-full p-2.5 bg-white border border-slate-200 rounded-xl text-slate-700 text-xs font-bold focus:outline-hidden focus:border-teal-500 cursor-pointer"
                        >
                          <option value="">-- اختر من مشاريع التطبيق المسجلة --</option>
                          {projects.map(p => (
                            <option key={p.id} value={p.id}>{p.name}</option>
                          ))}
                          <option value="custom">✏️ مشروع آخر (كتابة الاسم يدوياً)</option>
                        </select>
                      </div>

                      {(newProjectId === 'custom' || (!newProjectId && projects.length === 0)) && (
                        <div className="space-y-1 animate-fade-in">
                          <label className="text-[11px] font-bold text-slate-700 block">اكتب اسم المشروع غير الموجود بالتطبيق: <span className="text-rose-500">*</span></label>
                          <input
                            type="text"
                            value={newProjectCustomName}
                            onChange={(e) => setNewProjectCustomName(e.target.value)}
                            placeholder="مثال: مشروع مدرسة الفلاح، فيلا الحزام..."
                            className="w-full p-2.5 bg-white border border-slate-200 rounded-xl text-slate-800 text-xs focus:outline-hidden focus:border-teal-500"
                            required={newProjectScope === 'project'}
                          />
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {/* Amount & Currency */}
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700 block">مبلغ الدين والعملة <span className="text-rose-500">*</span></label>
                  <div className="flex gap-2">
                    <input
                      type="number"
                      step="any"
                      value={newTotalAmount}
                      onChange={(e) => setNewTotalAmount(e.target.value)}
                      placeholder="0.00"
                      className="flex-1 p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 text-xs font-bold font-mono focus:outline-hidden focus:border-teal-500 focus:bg-white transition-all"
                      required
                    />
                    <select
                      value={newCurrency}
                      onChange={(e) => setNewCurrency(e.target.value as any)}
                      className="w-32 p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-xs font-bold focus:outline-hidden cursor-pointer"
                    >
                      <option value="YER">YER (ريال يمني)</option>
                      <option value="SAR">SAR (ريال سعودي)</option>
                      <option value="USD">USD (دولار)</option>
                    </select>
                  </div>
                  <AmountInWords amount={newTotalAmount} currency={newCurrency} />
                </div>

                {/* Start Date & Due Date */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-700 block">تاريخ التسجيل <span className="text-rose-500">*</span></label>
                    <input
                      type="date"
                      value={newStartDate}
                      onChange={(e) => setNewStartDate(e.target.value)}
                      className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 text-xs focus:outline-hidden focus:border-teal-500 focus:bg-white transition-all"
                      required
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-700 block">تاريخ الاستحقاق <span className="text-slate-400 font-normal">(اختياري)</span></label>
                    <input
                      type="date"
                      value={newDueDate}
                      onChange={(e) => setNewDueDate(e.target.value)}
                      className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 text-xs focus:outline-hidden focus:border-teal-500 focus:bg-white transition-all"
                    />
                  </div>
                </div>

                {/* Description & Phone */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-700 block">بيان / غرض الدين</label>
                    <input
                      type="text"
                      value={newDescription}
                      onChange={(e) => setNewDescription(e.target.value)}
                      placeholder="مثال: سلفة نقدية، شراء مواد، قرض..."
                      className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 text-xs focus:outline-hidden focus:border-teal-500 focus:bg-white transition-all"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-700 block">رقم الهاتف <span className="text-slate-400 font-normal">(اختياري)</span></label>
                    <input
                      type="tel"
                      value={newPhone}
                      onChange={(e) => setNewPhone(e.target.value)}
                      placeholder="770000000"
                      dir="ltr"
                      className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 text-xs text-right focus:outline-hidden focus:border-teal-500 focus:bg-white transition-all"
                    />
                  </div>
                </div>

                {/* Notes */}
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700 block">ملاحظات إضافية <span className="text-slate-400 font-normal">(اختياري)</span></label>
                  <textarea
                    value={newNotes}
                    onChange={(e) => setNewNotes(e.target.value)}
                    placeholder="أي شروط أو تفاصيل متعلقة بالدين..."
                    rows={2}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 text-xs focus:outline-hidden focus:border-teal-500 focus:bg-white resize-none"
                  />
                </div>
              </form>
            </div>

            <DraggableScrollIndicator
              variant="teal"
              title="مسار السحب والتنقل الفوري في استمارة الدين"
              className="border-r border-slate-200/80 bg-slate-50/80 py-2"
            />
          </div>

            {/* Modal Action Buttons */}
            <div className="p-4 sm:p-5 bg-slate-50 border-t border-slate-100 flex items-center justify-end gap-2 shrink-0">
              <button
                type="button"
                onClick={() => { handleResetAddDebtForm(); setShowAddModal(false); }}
                className="px-4 py-2 text-xs font-bold text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors cursor-pointer"
              >
                إلغاء
              </button>
              <button
                type="button"
                onClick={handleResetAddDebtForm}
                className="px-3.5 py-2 text-xs font-bold text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors cursor-pointer flex items-center gap-1.5"
                title="تنظيف الحقول"
              >
                <RotateCcw size={13} />
                <span>تنظيف</span>
              </button>
              <button
                type="submit"
                form="add-general-debt-form"
                className="px-5 py-2 text-xs font-bold text-white bg-teal-600 hover:bg-teal-700 rounded-xl transition-colors shadow-xs cursor-pointer flex items-center gap-1.5"
              >
                <Landmark size={14} />
                <span>حفظ الدين</span>
              </button>
            </div>

          </div>
        </div>
      )}

      {/* 6. View Details, Debt Entries & Payments Modal */}
      {selectedDebt && selectedDebtCalcs && (
        <div 
          className="fixed inset-0 z-[100] bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto animate-fade-in dir-rtl text-right overscroll-contain"
          onTouchMove={(e) => {
            if (e.target === e.currentTarget) e.preventDefault();
          }}
        >
          <div 
            className="bg-white rounded-3xl shadow-2xl border border-slate-100 max-w-3xl w-full max-h-[92vh] flex flex-col overflow-hidden my-auto animate-scale-up overscroll-contain"
            onClick={(e) => e.stopPropagation()}
          >
            
            {/* Modal Header */}
            <div className="bg-gradient-to-r from-teal-700 to-slate-900 text-white p-4 sm:p-5 flex items-center justify-between shrink-0">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <h3 className="font-extrabold text-base text-white">
                    {selectedDebt.personOrEntityName}
                  </h3>
                  <span className={`text-xs font-black px-2.5 py-0.5 rounded-full ${
                    selectedDebt.type === 'receivable' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' : 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                  }`}>
                    {selectedDebt.type === 'receivable' ? 'لنا (مستحق للشركة)' : 'علينا (التزام على الشركة)'}
                  </span>
                </div>
                <div className="flex flex-wrap items-center gap-2 text-xs text-teal-100">
                  <span>{selectedDebt.description || 'كشف الحساب والعمليات المالية'}</span>
                  {selectedDebt.phone && <span>• هاتف: <strong dir="ltr">{selectedDebt.phone}</strong></span>}
                </div>
              </div>

              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => handlePrintPersonStatement(selectedDebt)}
                  className="p-2 text-teal-200 hover:text-white hover:bg-white/10 rounded-xl transition-colors cursor-pointer"
                  title="طباعة كشف الحساب (PDF)"
                >
                  <Printer size={18} />
                </button>
                <button 
                  type="button"
                  onClick={() => setSelectedDebtId(null)}
                  className="p-1.5 text-teal-200 hover:text-white hover:bg-white/10 rounded-xl transition-colors cursor-pointer"
                >
                  <X size={20} />
                </button>
              </div>
            </div>

            {/* Sub-Tabs Action Bar */}
            <div className="bg-slate-100/80 px-4 py-2 border-b border-slate-200 flex items-center justify-between gap-2 shrink-0">
              <div className="flex items-center gap-1.5 text-xs font-bold">
                <button
                  type="button"
                  onClick={() => setActiveDetailsTab('overview')}
                  className={`px-3 py-1.5 rounded-xl transition-all cursor-pointer flex items-center gap-1.5 ${
                    activeDetailsTab === 'overview'
                      ? 'bg-white text-teal-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-800'
                  }`}
                >
                  <Layers size={14} />
                  <span>كشف العمليات والأرصدة</span>
                </button>

                {sharedRole !== 'read' && (
                  <button
                    type="button"
                    onClick={() => setActiveDetailsTab('add_debt')}
                    className={`px-3 py-1.5 rounded-xl transition-all cursor-pointer flex items-center gap-1.5 ${
                      activeDetailsTab === 'add_debt'
                        ? 'bg-teal-700 text-white shadow-xs'
                        : 'text-teal-800 bg-teal-50 hover:bg-teal-100'
                    }`}
                  >
                    <PlusCircle size={14} />
                    <span>➕ إضافة دفعة دين (استدانة إضافية)</span>
                  </button>
                )}

                {sharedRole !== 'read' && (
                  <button
                    type="button"
                    onClick={() => setActiveDetailsTab('add_payment')}
                    className={`px-3 py-1.5 rounded-xl transition-all cursor-pointer flex items-center gap-1.5 ${
                      activeDetailsTab === 'add_payment'
                        ? 'bg-emerald-600 text-white shadow-xs'
                        : 'text-emerald-800 bg-emerald-50 hover:bg-emerald-100'
                    }`}
                  >
                    <Receipt size={14} />
                    <span>💵 تسجيل دفعة سداد</span>
                  </button>
                )}
              </div>
            </div>

            {/* Modal Body with Draggable Scroll Rail */}
            <div className="flex-1 overflow-hidden flex flex-row min-h-0 relative">
              <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-5 overscroll-contain touch-pan-y custom-scrollbar modal-scroll-area">
                
                {/* 1. Multi-Currency Summary Cards */}
                <div className="space-y-2">
                  <h4 className="text-xs font-extrabold text-slate-700 flex items-center gap-1.5">
                    <Coins size={15} className="text-amber-500" />
                    <span>الأرصدة المالية حسب العملة:</span>
                  </h4>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                    {selectedDebtCalcs.activeCurrencies.map(curr => {
                      const stats = selectedDebtCalcs.perCurrency[curr];
                      return (
                        <div key={curr} className="p-3 bg-slate-50 rounded-2xl border border-slate-200 space-y-1.5">
                          <div className="flex justify-between items-center border-b border-slate-200/60 pb-1">
                            <span className="text-[11px] font-black text-slate-800">عملة ({curr})</span>
                            <span className={`text-[10px] font-bold px-1.5 py-0.2 rounded-md ${
                              stats.remaining === 0 ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-700'
                            }`}>
                              {stats.remaining === 0 ? 'مسدد' : stats.totalPaid > 0 ? 'مسدد جزئياً' : 'غير مسدد'}
                            </span>
                          </div>

                          <div className="flex justify-between text-[11px] text-slate-500">
                            <span>إجمالي الدين:</span>
                            <span className="font-mono font-bold text-slate-800">{formatCurrency(stats.totalDebt, curr)}</span>
                          </div>

                          <div className="flex justify-between text-[11px] text-slate-500">
                            <span>إجمالي المسدد:</span>
                            <span className="font-mono font-bold text-emerald-600">{formatCurrency(stats.totalPaid, curr)}</span>
                          </div>

                          <div className="flex justify-between text-xs font-extrabold pt-1 border-t border-slate-200">
                            <span className="text-slate-700">المتبقي:</span>
                            <span className={`font-mono ${
                              stats.remaining === 0 ? 'text-emerald-600' : selectedDebt.type === 'receivable' ? 'text-emerald-700' : 'text-rose-600'
                            }`}>
                              {formatCurrency(stats.remaining, curr)}
                            </span>
                          </div>

                          <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden mt-1">
                            <div 
                              className="h-full bg-teal-600 transition-all duration-500" 
                              style={{ width: `${stats.percentage}%` }}
                            />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* 2. Sub-Form: Add Debt Entry (استدانة إضافية) */}
                {activeDetailsTab === 'add_debt' && sharedRole !== 'read' && (
                  <div className="p-4 bg-teal-50/70 border border-teal-200 rounded-2xl space-y-3 animate-fade-in">
                    <div className="flex items-center justify-between border-b border-teal-200/60 pb-2">
                      <h4 className="font-extrabold text-teal-950 text-xs flex items-center gap-1.5">
                        <PlusCircle size={15} className="text-teal-600" />
                        <span>إضافة دفعة دين جديدة (استدانة إضافية) لحساب {selectedDebt.personOrEntityName}</span>
                      </h4>
                      <button
                        type="button"
                        onClick={() => setActiveDetailsTab('overview')}
                        className="text-slate-400 hover:text-slate-600"
                      >
                        <X size={15} />
                      </button>
                    </div>

                    {entryError && (
                      <div className="p-2.5 bg-rose-50 text-rose-700 border border-rose-200 rounded-xl text-xs font-bold">
                        {entryError}
                      </div>
                    )}

                    <form onSubmit={handleAddDebtEntrySubmit} className="space-y-3">
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                        
                        {/* Amount */}
                        <div className="space-y-1">
                          <label className="text-[11px] font-bold text-slate-700 block">مبلغ الدين الإضافي *</label>
                          <input
                            type="number"
                            step="any"
                            value={entryAmount}
                            onChange={(e) => setEntryAmount(e.target.value)}
                            placeholder="0.00"
                            className="w-full p-2.5 bg-white border border-slate-200 rounded-xl text-xs font-bold font-mono text-slate-800 focus:outline-hidden focus:border-teal-500"
                            required
                          />
                        </div>

                        {/* Currency */}
                        <div className="space-y-1">
                          <label className="text-[11px] font-bold text-slate-700 block">العملة *</label>
                          <select
                            value={entryCurrency}
                            onChange={(e) => setEntryCurrency(e.target.value as any)}
                            className="w-full p-2.5 bg-white border border-slate-200 rounded-xl text-xs font-bold text-slate-700 focus:outline-hidden focus:border-teal-500 cursor-pointer"
                          >
                            <option value="YER">YER (ريال يمني)</option>
                            <option value="SAR">SAR (ريال سعودي)</option>
                            <option value="USD">USD (دولار)</option>
                          </select>
                        </div>

                        {/* Date */}
                        <div className="space-y-1">
                          <label className="text-[11px] font-bold text-slate-700 block">تاريخ الدفعة *</label>
                          <input
                            type="date"
                            value={entryDate}
                            onChange={(e) => setEntryDate(e.target.value)}
                            className="w-full p-2.5 bg-white border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-hidden focus:border-teal-500"
                            required
                          />
                        </div>
                      </div>

                      <AmountInWords amount={entryAmount} currency={entryCurrency} />

                      {/* Project Scope Association */}
                      <div className="space-y-2 p-3 bg-white rounded-xl border border-slate-200">
                        <label className="text-[11px] font-extrabold text-slate-800 block flex items-center gap-1.5">
                          <FolderGit2 size={13} className="text-teal-600" />
                          <span>ارتباط هذه الدفعة:</span>
                        </label>

                        <div className="grid grid-cols-2 gap-2">
                          <button
                            type="button"
                            onClick={() => {
                              setEntryProjectScope('general');
                              setEntryProjectId('');
                              setEntryProjectCustomName('');
                            }}
                            className={`p-2 rounded-lg border text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer ${
                              entryProjectScope === 'general'
                                ? 'bg-teal-700 text-white border-teal-700'
                                : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                            }`}
                          >
                            <Building2 size={13} />
                            <span>دين عام للشركة</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => setEntryProjectScope('project')}
                            className={`p-2 rounded-lg border text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer ${
                              entryProjectScope === 'project'
                                ? 'bg-teal-700 text-white border-teal-700'
                                : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                            }`}
                          >
                            <FolderGit2 size={13} />
                            <span>مرتبط بمشروع</span>
                          </button>
                        </div>

                        {entryProjectScope === 'project' && (
                          <div className="space-y-2 pt-2 border-t border-slate-100 animate-fade-in">
                            <select
                              value={entryProjectId}
                              onChange={(e) => setEntryProjectId(e.target.value)}
                              className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 focus:outline-hidden"
                            >
                              <option value="">-- اختر المشروع من التطبيق --</option>
                              {projects.map(p => (
                                <option key={p.id} value={p.id}>{p.name}</option>
                              ))}
                              <option value="custom">✏️ كتابة اسم المشروع يدوياً</option>
                            </select>

                            {(entryProjectId === 'custom' || (!entryProjectId && projects.length === 0)) && (
                              <input
                                type="text"
                                value={entryProjectCustomName}
                                onChange={(e) => setEntryProjectCustomName(e.target.value)}
                                placeholder="اكتب اسم المشروع المرتبط..."
                                className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-hidden"
                                required={entryProjectScope === 'project'}
                              />
                            )}
                          </div>
                        )}
                      </div>

                      {/* Description & Notes */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                        <input
                          type="text"
                          value={entryDescription}
                          onChange={(e) => setEntryDescription(e.target.value)}
                          placeholder="البيان / الغرض من دفعة الدين..."
                          className="p-2.5 bg-white border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-hidden"
                        />
                        <input
                          type="text"
                          value={entryNotes}
                          onChange={(e) => setEntryNotes(e.target.value)}
                          placeholder="ملاحظات اختيارية..."
                          className="p-2.5 bg-white border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-hidden"
                        />
                      </div>

                      <div className="flex justify-end gap-2 pt-1">
                        <button
                          type="button"
                          onClick={() => setActiveDetailsTab('overview')}
                          className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold text-xs rounded-xl"
                        >
                          إلغاء
                        </button>
                        <button
                          type="submit"
                          className="px-5 py-2 bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs rounded-xl flex items-center gap-1.5"
                        >
                          <PlusCircle size={14} />
                          <span>إضافة الدفعة إلى الحساب</span>
                        </button>
                      </div>
                    </form>
                  </div>
                )}

                {/* 3. Sub-Form: Add Payment (سداد دفعة) */}
                {activeDetailsTab === 'add_payment' && sharedRole !== 'read' && (
                  <div className="p-4 bg-emerald-50/70 border border-emerald-200 rounded-2xl space-y-3 animate-fade-in">
                    <div className="flex items-center justify-between border-b border-emerald-200/60 pb-2">
                      <h4 className="font-extrabold text-emerald-950 text-xs flex items-center gap-1.5">
                        <Receipt size={15} className="text-emerald-600" />
                        <span>تسجيل دفعة سداد جديدة لحساب {selectedDebt.personOrEntityName}</span>
                      </h4>
                      <button
                        type="button"
                        onClick={() => setActiveDetailsTab('overview')}
                        className="text-slate-400 hover:text-slate-600"
                      >
                        <X size={15} />
                      </button>
                    </div>

                    {paymentError && (
                      <div className="p-2.5 bg-rose-50 text-rose-700 border border-rose-200 rounded-xl text-xs font-bold">
                        {paymentError}
                      </div>
                    )}

                    <form onSubmit={handlePaymentSubmit} className="space-y-3">
                      <div className="grid grid-cols-1 sm:grid-cols-4 gap-2.5">
                        
                        {/* Currency */}
                        <div className="space-y-1">
                          <label className="text-[11px] font-bold text-slate-700 block">عملة السداد *</label>
                          <select
                            value={paymentCurrency}
                            onChange={(e) => setPaymentCurrency(e.target.value as any)}
                            className="w-full p-2.5 bg-white border border-slate-200 rounded-xl text-xs font-bold text-slate-700 focus:outline-hidden cursor-pointer"
                          >
                            {selectedDebtCalcs.activeCurrencies.map(curr => {
                              const rem = selectedDebtCalcs.perCurrency[curr]?.remaining || 0;
                              return (
                                <option key={curr} value={curr}>
                                  {curr} (متبقي: {formatCurrency(rem, curr)})
                                </option>
                              );
                            })}
                          </select>
                        </div>

                        {/* Amount */}
                        <div className="space-y-1">
                          <label className="text-[11px] font-bold text-slate-700 block">مبلغ السداد *</label>
                          <input
                            type="number"
                            step="any"
                            value={paymentAmount}
                            onChange={(e) => setPaymentAmount(e.target.value)}
                            placeholder={`أقصى حد: ${selectedDebtCalcs.perCurrency[paymentCurrency]?.remaining || 0}`}
                            max={selectedDebtCalcs.perCurrency[paymentCurrency]?.remaining || 0}
                            className="w-full p-2.5 bg-white border border-slate-200 rounded-xl text-xs font-bold font-mono text-slate-800 focus:outline-hidden"
                            required
                          />
                        </div>

                        {/* Date */}
                        <div className="space-y-1">
                          <label className="text-[11px] font-bold text-slate-700 block">تاريخ السداد *</label>
                          <input
                            type="date"
                            value={paymentDate}
                            onChange={(e) => setPaymentDate(e.target.value)}
                            className="w-full p-2.5 bg-white border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-hidden"
                            required
                          />
                        </div>

                        {/* Receipt */}
                        <div className="space-y-1">
                          <label className="text-[11px] font-bold text-slate-700 block">رقم السند / الإيصال</label>
                          <input
                            type="text"
                            value={paymentReceipt}
                            onChange={(e) => setPaymentReceipt(e.target.value)}
                            placeholder="سند قبض / شيك..."
                            className="w-full p-2.5 bg-white border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-hidden"
                          />
                        </div>
                      </div>

                      <AmountInWords amount={paymentAmount} currency={paymentCurrency} />

                      {/* Notes */}
                      <div className="flex gap-2">
                        <input
                          type="text"
                          value={paymentNotes}
                          onChange={(e) => setPaymentNotes(e.target.value)}
                          placeholder="ملاحظات أو بيان على دفعة السداد..."
                          className="flex-1 p-2.5 bg-white border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-hidden"
                        />
                        <button
                          type="submit"
                          className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs px-4 py-2.5 rounded-xl transition-colors shrink-0 cursor-pointer flex items-center gap-1.5"
                        >
                          <Receipt size={14} />
                          <span>حفظ السداد</span>
                        </button>
                      </div>
                    </form>
                  </div>
                )}

                {/* 4. Table: Debt Entries (سجل دفعات الدين والاستدانات) */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <h4 className="font-extrabold text-slate-800 text-xs flex items-center gap-1.5">
                      <FolderGit2 size={15} className="text-teal-600" />
                      <span>سجل دفعات الدين والاستدانات ({selectedDebtCalcs.entries.length}):</span>
                    </h4>
                    {sharedRole !== 'read' && activeDetailsTab !== 'add_debt' && (
                      <button
                        type="button"
                        onClick={() => setActiveDetailsTab('add_debt')}
                        className="text-[11px] text-teal-700 hover:text-teal-900 font-bold flex items-center gap-1 cursor-pointer"
                      >
                        <PlusCircle size={13} />
                        <span>إضافة دفعة دين</span>
                      </button>
                    )}
                  </div>

                  <div className="overflow-x-auto border border-slate-200 rounded-2xl">
                    <table className="w-full text-xs text-right">
                      <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200">
                        <tr>
                          <th className="p-2.5">#</th>
                          <th className="p-2.5">التاريخ</th>
                          <th className="p-2.5">البيان / الغرض</th>
                          <th className="p-2.5">المشروع / الارتباط</th>
                          <th className="p-2.5">المبلغ</th>
                          <th className="p-2.5">العملة</th>
                          <th className="p-2.5">ملاحظات</th>
                          {sharedRole !== 'read' && sharedRole !== 'add' && <th className="p-2.5 text-center">إجراء</th>}
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {selectedDebtCalcs.entries.map((entry, idx) => {
                          const pLabel = entry.projectScope === 'project' && entry.projectName ? entry.projectName : 'دين عام للشركة';
                          return (
                            <tr key={entry.id || idx} className="hover:bg-slate-50/50">
                              <td className="p-2.5 text-slate-400 font-mono">{idx + 1}</td>
                              <td className="p-2.5 text-slate-700">{formatDateArabic(entry.date)}</td>
                              <td className="p-2.5 font-bold text-slate-800">{entry.description || '-'}</td>
                              <td className="p-2.5">
                                <span className={`inline-flex items-center gap-1 text-[11px] font-bold px-2 py-0.5 rounded-md ${
                                  entry.projectScope === 'project' && entry.projectName
                                    ? 'bg-sky-50 text-sky-800 border border-sky-100'
                                    : 'bg-slate-100 text-slate-700'
                                }`}>
                                  {entry.projectScope === 'project' && entry.projectName ? <FolderGit2 size={11} /> : <Building2 size={11} />}
                                  <span>{pLabel}</span>
                                </span>
                              </td>
                              <td className="p-2.5 font-mono font-black text-slate-800">
                                {formatCurrency(entry.amount, entry.currency || selectedDebt.currency)}
                              </td>
                              <td className="p-2.5 font-bold text-slate-600">{entry.currency || selectedDebt.currency}</td>
                              <td className="p-2.5 text-slate-500">{entry.notes || '-'}</td>
                              {sharedRole !== 'read' && sharedRole !== 'add' && (
                                <td className="p-2.5 text-center">
                                  {selectedDebtCalcs.entries.length > 1 && (
                                    <button
                                      type="button"
                                      onClick={() => {
                                        if (confirm(`هل أنت متأكد من حذف دفعة الدين بقيمة ${formatCurrency(entry.amount, entry.currency || selectedDebt.currency)}؟`)) {
                                          if (onDeleteDebtEntry) {
                                            onDeleteDebtEntry(selectedDebt.id, entry.id);
                                          } else {
                                            const updated = selectedDebtCalcs.entries.filter(e => e.id !== entry.id);
                                            onUpdateGeneralDebt(selectedDebt.id, { entries: updated });
                                          }
                                        }
                                      }}
                                      className="p-1 text-slate-300 hover:text-rose-600 rounded-md transition-colors cursor-pointer"
                                      title="حذف دفعة الدين"
                                    >
                                      <Trash2 size={13} />
                                    </button>
                                  )}
                                </td>
                              )}
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* 5. Table: Repayments History (سجل دفعات السداد) */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <h4 className="font-extrabold text-slate-800 text-xs flex items-center gap-1.5">
                      <Receipt size={15} className="text-emerald-600" />
                      <span>سجل دفعات السداد ({(selectedDebt.payments || []).length}):</span>
                    </h4>
                    {sharedRole !== 'read' && activeDetailsTab !== 'add_payment' && (
                      <button
                        type="button"
                        onClick={() => setActiveDetailsTab('add_payment')}
                        className="text-[11px] text-emerald-700 hover:text-emerald-900 font-bold flex items-center gap-1 cursor-pointer"
                      >
                        <PlusCircle size={13} />
                        <span>تسجيل سداد</span>
                      </button>
                    )}
                  </div>

                  {(selectedDebt.payments || []).length === 0 ? (
                    <div className="p-4 text-center bg-slate-50 rounded-2xl border border-slate-100 text-slate-400 text-xs">
                      لم يتم تسجيل أي دفعات سداد على هذا الحساب حتى الآن
                    </div>
                  ) : (
                    <div className="overflow-x-auto border border-slate-200 rounded-2xl">
                      <table className="w-full text-xs text-right">
                        <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200">
                          <tr>
                            <th className="p-2.5">#</th>
                            <th className="p-2.5">التاريخ</th>
                            <th className="p-2.5">المبلغ</th>
                            <th className="p-2.5">العملة</th>
                            <th className="p-2.5">رقم السند</th>
                            <th className="p-2.5">ملاحظات</th>
                            <th className="p-2.5">المسؤول</th>
                            {sharedRole !== 'read' && sharedRole !== 'add' && <th className="p-2.5 text-center">إجراء</th>}
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                          {selectedDebt.payments.map((p, idx) => (
                            <tr key={p.id || idx} className="hover:bg-slate-50/50">
                              <td className="p-2.5 text-slate-400 font-mono">{idx + 1}</td>
                              <td className="p-2.5 text-slate-700">{formatDateArabic(p.date)}</td>
                              <td className="p-2.5 font-bold font-mono text-emerald-600">
                                {formatCurrency(p.amount, p.currency || selectedDebt.currency)}
                              </td>
                              <td className="p-2.5 font-bold text-slate-600">{p.currency || selectedDebt.currency}</td>
                              <td className="p-2.5 text-slate-600">{p.receiptNumber || '-'}</td>
                              <td className="p-2.5 text-slate-500">{p.notes || '-'}</td>
                              <td className="p-2.5 text-slate-400 text-[11px]">{p.createdBy || '-'}</td>
                              {sharedRole !== 'read' && sharedRole !== 'add' && (
                                <td className="p-2.5 text-center">
                                  <button
                                    onClick={() => {
                                      if (confirm(`هل أنت متأكد من حذف هذه الدفعة بقيمة ${formatCurrency(p.amount, p.currency || selectedDebt.currency)}؟`)) {
                                        onDeletePayment(selectedDebt.id, p.id);
                                      }
                                    }}
                                    className="p-1 text-slate-300 hover:text-rose-600 rounded-md transition-colors cursor-pointer"
                                    title="حذف الدفعة"
                                  >
                                    <Trash2 size={13} />
                                  </button>
                                </td>
                              )}
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>

              </div>

              <DraggableScrollIndicator
                variant="teal"
                title="مسار السحب والتنقل الفوري في كشف الحساب"
                className="border-r border-slate-200/80 bg-slate-50/80 py-2"
              />
            </div>

            {/* Modal Footer */}
            <div className="p-4 sm:p-5 bg-slate-50 border-t border-slate-100 flex justify-between items-center shrink-0">
              <button
                type="button"
                onClick={() => handlePrintPersonStatement(selectedDebt)}
                className="px-4 py-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold text-xs rounded-xl transition-colors cursor-pointer flex items-center gap-1.5"
              >
                <Printer size={14} />
                <span>طباعة كشف الحساب التفصيلي</span>
              </button>

              <button
                type="button"
                onClick={() => setSelectedDebtId(null)}
                className="px-5 py-2 bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold text-xs rounded-xl transition-colors cursor-pointer"
              >
                إغلاق
              </button>
            </div>

          </div>
        </div>
      )}

      {/* 7. Edit Debt Basic Modal */}
      {editingDebt && (
        <div 
          className="fixed inset-0 z-[100] bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto animate-fade-in dir-rtl text-right overscroll-contain"
          onTouchMove={(e) => {
            if (e.target === e.currentTarget) e.preventDefault();
          }}
        >
          <div 
            className="bg-white rounded-3xl shadow-2xl border border-slate-100 max-w-lg w-full overflow-hidden my-auto animate-scale-up overscroll-contain max-h-[90vh] flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            
            {/* Modal Header */}
            <div className="bg-gradient-to-r from-teal-700 to-slate-900 text-white p-4 sm:p-5 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-white/10 rounded-xl">
                  <Landmark size={20} className="text-teal-200" />
                </div>
                <div>
                  <h3 className="font-extrabold text-base">تعديل بيانات الحساب والارتباط</h3>
                  <p className="text-xs text-teal-100">تحديث بيانات الطرف والارتباط بالمشروع</p>
                </div>
              </div>
              <button 
                type="button"
                onClick={() => setEditingDebt(null)}
                className="p-1.5 text-teal-200 hover:text-white hover:bg-white/10 rounded-xl transition-colors cursor-pointer"
              >
                <X size={20} />
              </button>
            </div>

            {/* Scrollable Form Body */}
            <div className="flex-1 overflow-hidden flex flex-row min-h-0 relative">
              <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4 min-h-0 touch-pan-y overscroll-contain custom-scrollbar modal-scroll-area">
                <form id="edit-general-debt-form" onSubmit={handleEditSubmit} className="space-y-4">
                
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700 block">اسم الشخص / الجهة <span className="text-rose-500">*</span></label>
                  <input
                    type="text"
                    value={editingDebt.personOrEntityName}
                    onChange={(e) => setEditingDebt({ ...editingDebt, personOrEntityName: e.target.value })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 text-xs focus:outline-hidden focus:border-teal-500 focus:bg-white transition-all font-bold"
                    required
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700 block">نوع الالتزام <span className="text-rose-500">*</span></label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setEditingDebt({ ...editingDebt, type: 'receivable' })}
                      className={`p-3 rounded-2xl border text-xs font-extrabold flex items-center justify-center gap-2 transition-all cursor-pointer ${
                        editingDebt.type === 'receivable'
                          ? 'bg-emerald-600 text-white border-emerald-600 shadow-sm'
                          : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      <ArrowDownLeft size={16} />
                      <span>لنا (مستحق للشركة)</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setEditingDebt({ ...editingDebt, type: 'payable' })}
                      className={`p-3 rounded-2xl border text-xs font-extrabold flex items-center justify-center gap-2 transition-all cursor-pointer ${
                        editingDebt.type === 'payable'
                          ? 'bg-rose-600 text-white border-rose-600 shadow-sm'
                          : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      <ArrowUpRight size={16} />
                      <span>علينا (مستحق على الشركة)</span>
                    </button>
                  </div>
                </div>

                {/* Project Scope Association */}
                <div className="space-y-2 p-3 bg-slate-50 rounded-2xl border border-slate-200">
                  <label className="text-xs font-extrabold text-slate-800 block">ارتباط الدين العام أو المشروع:</label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setEditingDebt({ ...editingDebt, projectScope: 'general', projectId: undefined, projectName: undefined })}
                      className={`p-2.5 rounded-xl border text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer ${
                        editingDebt.projectScope !== 'project'
                          ? 'bg-teal-700 text-white border-teal-700'
                          : 'bg-white text-slate-600 border-slate-200'
                      }`}
                    >
                      <Building2 size={14} />
                      <span>دين عام للشركة</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setEditingDebt({ ...editingDebt, projectScope: 'project' })}
                      className={`p-2.5 rounded-xl border text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer ${
                        editingDebt.projectScope === 'project'
                          ? 'bg-teal-700 text-white border-teal-700'
                          : 'bg-white text-slate-600 border-slate-200'
                      }`}
                    >
                      <FolderGit2 size={14} />
                      <span>مرتبط بمشروع</span>
                    </button>
                  </div>

                  {editingDebt.projectScope === 'project' && (
                    <div className="space-y-2 pt-2 border-t border-slate-200">
                      <select
                        value={editingDebt.projectId || (editingDebt.projectName ? 'custom' : '')}
                        onChange={(e) => {
                          const val = e.target.value;
                          if (val === 'custom') {
                            setEditingDebt({ ...editingDebt, projectId: undefined });
                          } else {
                            const found = projects.find(p => p.id === val);
                            setEditingDebt({ ...editingDebt, projectId: val, projectName: found?.name || '' });
                          }
                        }}
                        className="w-full p-2.5 bg-white border border-slate-200 rounded-xl text-slate-700 text-xs font-bold focus:outline-hidden"
                      >
                        <option value="">-- اختر من مشاريع التطبيق --</option>
                        {projects.map(p => (
                          <option key={p.id} value={p.id}>{p.name}</option>
                        ))}
                        <option value="custom">✏️ كتابة اسم المشروع يدوياً</option>
                      </select>

                      {(!editingDebt.projectId || editingDebt.projectId === 'custom') && (
                        <input
                          type="text"
                          value={editingDebt.projectName || ''}
                          onChange={(e) => setEditingDebt({ ...editingDebt, projectName: e.target.value })}
                          placeholder="اكتب اسم المشروع..."
                          className="w-full p-2.5 bg-white border border-slate-200 rounded-xl text-slate-800 text-xs focus:outline-hidden"
                        />
                      )}
                    </div>
                  )}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-700 block">تاريخ التسجيل <span className="text-rose-500">*</span></label>
                    <input
                      type="date"
                      value={editingDebt.startDate}
                      onChange={(e) => setEditingDebt({ ...editingDebt, startDate: e.target.value })}
                      className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 text-xs focus:outline-hidden focus:border-teal-500 focus:bg-white transition-all"
                      required
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-700 block">تاريخ الاستحقاق <span className="text-slate-400 font-normal">(اختياري)</span></label>
                    <input
                      type="date"
                      value={editingDebt.dueDate || ''}
                      onChange={(e) => setEditingDebt({ ...editingDebt, dueDate: e.target.value })}
                      className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 text-xs focus:outline-hidden focus:border-teal-500 focus:bg-white transition-all"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-700 block">الوصف</label>
                    <input
                      type="text"
                      value={editingDebt.description}
                      onChange={(e) => setEditingDebt({ ...editingDebt, description: e.target.value })}
                      className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 text-xs focus:outline-hidden focus:border-teal-500 focus:bg-white transition-all"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-700 block">رقم الهاتف <span className="text-slate-400 font-normal">(اختياري)</span></label>
                    <input
                      type="tel"
                      value={editingDebt.phone || ''}
                      onChange={(e) => setEditingDebt({ ...editingDebt, phone: e.target.value })}
                      dir="ltr"
                      className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 text-xs text-right focus:outline-hidden focus:border-teal-500 focus:bg-white transition-all"
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700 block">ملاحظات <span className="text-slate-400 font-normal">(اختياري)</span></label>
                  <textarea
                    value={editingDebt.notes || ''}
                    onChange={(e) => setEditingDebt({ ...editingDebt, notes: e.target.value })}
                    rows={2}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 text-xs focus:outline-hidden focus:border-teal-500 focus:bg-white resize-none"
                  />
                </div>
              </form>
            </div>

            <DraggableScrollIndicator
              variant="teal"
              title="مسار السحب والتنقل الفوري في تعديل الدين"
              className="border-r border-slate-200/80 bg-slate-50/80 py-2"
            />
          </div>

            {/* Modal Action Buttons */}
            <div className="p-4 sm:p-5 bg-slate-50 border-t border-slate-100 flex items-center justify-end gap-2 shrink-0">
              <button
                type="button"
                onClick={() => setEditingDebt(null)}
                className="px-4 py-2 text-xs font-bold text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors cursor-pointer"
              >
                إلغاء
              </button>
              <button
                type="submit"
                form="edit-general-debt-form"
                className="px-5 py-2 text-xs font-bold text-white bg-teal-600 hover:bg-teal-700 rounded-xl transition-colors shadow-xs cursor-pointer flex items-center gap-1.5"
              >
                <Landmark size={14} />
                <span>حفظ التعديلات</span>
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};

export default GeneralDebts;
