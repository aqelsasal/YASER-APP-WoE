/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { createPortal } from 'react-dom';
import { 
  X, 
  PlusCircle, 
  User, 
  Hammer, 
  Briefcase, 
  Truck, 
  Package, 
  Calendar, 
  Clock, 
  RotateCcw, 
  HardHat 
} from 'lucide-react';
import { 
  Worker, 
  Employee, 
  Supplier, 
  calculateDaysOfWork, 
  calculateActualDaysOfWork 
} from '../types';
import PhoneNumbersInput from './PhoneNumbersInput';
import { AmountInWords } from './AmountInWords';
import { useBodyScrollLock } from '../utils/modalScrollLock';

interface QuickAddAccountModalProps {
  isOpen: boolean;
  onClose: () => void;
  type: 'employee' | 'worker' | 'supplier';
  currency?: string;
  sharedRole?: string;
  onAddWorker?: (worker: Omit<Worker, 'id' | 'ledger'>) => Worker | void;
  onAddEmployee?: (employee: Omit<Employee, 'id' | 'ledger'>) => Employee | void;
  onAddSupplier?: (supplier: Omit<Supplier, 'id' | 'ledger'>) => Supplier | void;
  onSuccessCreated: (valueKey: string) => void;
}

export const QuickAddAccountModal: React.FC<QuickAddAccountModalProps> = ({
  isOpen,
  onClose,
  type,
  currency = 'YER',
  sharedRole = 'admin',
  onAddWorker,
  onAddEmployee,
  onAddSupplier,
  onSuccessCreated
}) => {
  useBodyScrollLock(isOpen);

  // Error state
  const [error, setError] = useState('');

  // Worker Form States
  const [workerName, setWorkerName] = useState('');
  const [workerProfession, setWorkerProfession] = useState('');
  const [workerStartDate, setWorkerStartDate] = useState(new Date().toISOString().split('T')[0]);
  const [workerEndDate, setWorkerEndDate] = useState('');
  const [workerPhoneNumbers, setWorkerPhoneNumbers] = useState<string[]>(['']);
  const [workerNotes, setWorkerNotes] = useState('');

  // Employee Form States
  const [employeeName, setEmployeeName] = useState('');
  const [employeeProfession, setEmployeeProfession] = useState('');
  const [employeeStartDate, setEmployeeStartDate] = useState(new Date().toISOString().split('T')[0]);
  const [employeeEndDate, setEmployeeEndDate] = useState('');
  const [employeeWageType, setEmployeeWageType] = useState<'daily' | 'monthly'>('daily');
  const [employeeDailyWage, setEmployeeDailyWage] = useState('');
  const [employeeMonthlySalary, setEmployeeMonthlySalary] = useState('');
  const [employeeDailyWageCurrency, setEmployeeDailyWageCurrency] = useState(currency || 'YER');
  const [employeePhoneNumbers, setEmployeePhoneNumbers] = useState<string[]>(['']);
  const [employeeNotes, setEmployeeNotes] = useState('');

  // Supplier Form States
  const [supplierName, setSupplierName] = useState('');
  const [supplierMaterialType, setSupplierMaterialType] = useState('');
  const [supplierPhoneNumbers, setSupplierPhoneNumbers] = useState<string[]>(['']);
  const [supplierNotes, setSupplierNotes] = useState('');

  if (!isOpen || typeof document === 'undefined') return null;

  // Handle Worker Submit
  const handleWorkerSubmit = (e?: React.FormEvent | React.MouseEvent) => {
    if (e) e.preventDefault();
    setError('');

    if (!workerName.trim()) {
      setError('الرجاء إدخال اسم العامل.');
      return;
    }
    if (!workerProfession.trim()) {
      setError('الرجاء إدخال مهنة العامل.');
      return;
    }
    if (!workerStartDate) {
      setError('الرجاء اختيار تاريخ البدء.');
      return;
    }
    if (workerEndDate && new Date(workerStartDate) > new Date(workerEndDate)) {
      setError('تاريخ البدء يجب أن يكون قبل أو يساوي تاريخ الانتهاء.');
      return;
    }

    if (workerPhoneNumbers.some(p => p.trim().length > 0 && p.trim().length < 9)) {
      setError('رقم الهاتف يجب أن يتكون من 9 أرقام (مثال: 771234567).');
      return;
    }

    const validPhones = workerPhoneNumbers.map(p => p.trim()).filter(p => p.length === 9);

    if (onAddWorker) {
      const created = onAddWorker({
        name: workerName.trim(),
        profession: workerProfession.trim(),
        startDate: workerStartDate,
        endDate: workerEndDate || '',
        phoneNumbers: validPhones,
        notes: workerNotes.trim()
      });

      const workerId = (created as any)?.id;
      if (workerId) {
        onSuccessCreated(`worker:${workerId}`);
      } else {
        onClose();
      }
    }
  };

  // Handle Employee Submit
  const handleEmployeeSubmit = (e?: React.FormEvent | React.MouseEvent) => {
    if (e) e.preventDefault();
    setError('');

    if (!employeeName.trim()) {
      setError('الرجاء إدخال اسم الموظف.');
      return;
    }
    if (!employeeProfession.trim()) {
      setError('الرجاء إدخال المسمى الوظيفي.');
      return;
    }
    if (!employeeStartDate) {
      setError('الرجاء اختيار تاريخ البدء.');
      return;
    }
    if (employeeEndDate && new Date(employeeStartDate) > new Date(employeeEndDate)) {
      setError('تاريخ البدء يجب أن يكون قبل أو يساوي تاريخ الانتهاء.');
      return;
    }

    if (employeePhoneNumbers.some(p => p.trim().length > 0 && p.trim().length < 9)) {
      setError('رقم الهاتف يجب أن يتكون من 9 أرقام (مثال: 771234567).');
      return;
    }

    const validPhones = employeePhoneNumbers.map(p => p.trim()).filter(p => p.length === 9);

    if (onAddEmployee) {
      const created = onAddEmployee({
        name: employeeName.trim(),
        profession: employeeProfession.trim(),
        startDate: employeeStartDate,
        endDate: employeeEndDate || '',
        wageType: employeeWageType,
        dailyWage: employeeWageType === 'daily' ? (Number(employeeDailyWage) || 0) : 0,
        monthlySalary: employeeWageType === 'monthly' ? (Number(employeeMonthlySalary) || 0) : 0,
        dailyWageCurrency: employeeDailyWageCurrency || currency || 'YER',
        phoneNumbers: validPhones,
        notes: employeeNotes.trim()
      });

      const empId = (created as any)?.id;
      if (empId) {
        onSuccessCreated(`employee:${empId}`);
      } else {
        onClose();
      }
    }
  };

  // Handle Supplier Submit
  const handleSupplierSubmit = (e?: React.FormEvent | React.MouseEvent) => {
    if (e) e.preventDefault();
    setError('');

    if (!supplierName.trim()) {
      setError('الرجاء إدخال اسم المورد أو الشركة.');
      return;
    }
    if (!supplierMaterialType.trim()) {
      setError('الرجاء إدخال نوع المواد الموردة.');
      return;
    }

    if (supplierPhoneNumbers.some(p => p.trim().length > 0 && p.trim().length < 9)) {
      setError('رقم الهاتف يجب أن يتكون من 9 أرقام (مثال: 771234567).');
      return;
    }

    const validPhones = supplierPhoneNumbers.map(p => p.trim()).filter(p => p.length === 9);

    if (onAddSupplier) {
      const created = onAddSupplier({
        name: supplierName.trim(),
        materialType: supplierMaterialType.trim(),
        phoneNumbers: validPhones,
        notes: supplierNotes.trim()
      });

      const supplierId = (created as any)?.id;
      if (supplierId) {
        onSuccessCreated(`supplier:${supplierId}`);
      } else {
        onClose();
      }
    }
  };

  // Unified submit handler
  const handleSubmit = (e?: React.FormEvent | React.MouseEvent) => {
    if (e) e.preventDefault();
    if (type === 'worker') handleWorkerSubmit(e);
    else if (type === 'employee') handleEmployeeSubmit(e);
    else if (type === 'supplier') handleSupplierSubmit(e);
  };

  // Keyboard shortcut: Enter to submit
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && (e.target as HTMLElement).tagName !== 'TEXTAREA') {
      e.preventDefault();
      handleSubmit();
    }
  };

  return createPortal(
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-xl w-full border border-slate-100 shadow-2xl overflow-hidden my-auto animate-scale-up text-right dir-rtl max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className={`p-4 border-b flex items-center justify-between shrink-0 ${
          type === 'employee' 
            ? 'bg-gradient-to-r from-indigo-50 to-white border-indigo-100' 
            : type === 'worker' 
            ? 'bg-gradient-to-r from-sky-50 to-white border-sky-100' 
            : 'bg-gradient-to-r from-amber-50 to-white border-amber-100'
        }`}>
          <div className="flex items-center gap-2.5">
            <div className={`w-10 h-10 rounded-2xl flex items-center justify-center shadow-xs ${
              type === 'employee' 
                ? 'bg-indigo-600 text-white shadow-indigo-600/20' 
                : type === 'worker' 
                ? 'bg-sky-600 text-white shadow-sky-600/20' 
                : 'bg-amber-600 text-white shadow-amber-600/20'
            }`}>
              {type === 'employee' && <Briefcase size={20} />}
              {type === 'worker' && <HardHat size={20} />}
              {type === 'supplier' && <Truck size={20} />}
            </div>
            <div>
              <h3 className="font-extrabold text-slate-800 text-base sm:text-lg">
                {type === 'employee' && 'إضافة موظف جديد واعتماده'}
                {type === 'worker' && 'إضافة عامل جديد للموقع واعتماده'}
                {type === 'supplier' && 'إضافة مورد مواد جديد واعتماده'}
              </h3>
              <p className="text-[11px] text-slate-500 font-medium">
                سيتم إضافة البيانات واعتمادها فوراً في خانة "الترحيل إلى حساب"
              </p>
            </div>
          </div>

          <button 
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 flex items-center justify-center transition-colors cursor-pointer"
          >
            <X size={16} />
          </button>
        </div>

        {/* Scrollable Form Body */}
        <div className="p-4 sm:p-5 overflow-y-auto space-y-4" onKeyDown={handleKeyDown}>
          {error && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-700 text-xs font-bold animate-shake">
              {error}
            </div>
          )}

          {/* 1. WORKER FORM */}
          {type === 'worker' && (
            <div className="space-y-4">
              {/* Full Name */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 block">
                  الاسم الكامل <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <input 
                    type="text" 
                    value={workerName}
                    onChange={(e) => setWorkerName(e.target.value)}
                    placeholder="مثال: علي جاسم محمد"
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 text-sm focus:outline-hidden focus:border-sky-500 transition-colors pr-9 font-bold"
                    required
                    autoFocus
                  />
                  <User size={16} className="absolute top-1/2 -translate-y-1/2 right-3 text-slate-400 pointer-events-none" />
                </div>
              </div>

              {/* Profession */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 block">
                  المهنة / الصفة <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <input 
                    type="text" 
                    value={workerProfession}
                    onChange={(e) => setWorkerProfession(e.target.value)}
                    placeholder="مثال: خلفة بناء / نجار مسلح / عامل يومي"
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 text-sm focus:outline-hidden focus:border-sky-500 transition-colors pr-9 font-bold"
                    required
                  />
                  <Hammer size={16} className="absolute top-1/2 -translate-y-1/2 right-3 text-slate-400 pointer-events-none" />
                </div>
              </div>

              {/* Phone Numbers */}
              <PhoneNumbersInput 
                phoneNumbers={workerPhoneNumbers} 
                onChange={setWorkerPhoneNumbers} 
              />

              {/* Dates */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700 block">
                    تاريخ مباشرة العمل <span className="text-rose-500">*</span>
                  </label>
                  <div className="relative">
                    <input 
                      type="date" 
                      value={workerStartDate}
                      onChange={(e) => setWorkerStartDate(e.target.value)}
                      className="w-full h-[42px] px-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 text-xs font-bold focus:outline-hidden focus:border-sky-500 transition-colors pr-9"
                      required
                    />
                    <Calendar size={16} className="absolute top-1/2 -translate-y-1/2 right-3 text-slate-400 pointer-events-none" />
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700 block">تاريخ الانتهاء (اختياري)</label>
                  <div className="relative">
                    <input 
                      type="date" 
                      value={workerEndDate}
                      onChange={(e) => setWorkerEndDate(e.target.value)}
                      className="w-full h-[42px] px-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 text-xs font-bold focus:outline-hidden focus:border-sky-500 transition-colors pr-9"
                    />
                    <Calendar size={16} className="absolute top-1/2 -translate-y-1/2 right-3 text-slate-400 pointer-events-none" />
                  </div>
                </div>
              </div>

              {/* Dynamic Work Days Box */}
              {workerStartDate && (
                <div className="p-3 bg-sky-50/80 border border-sky-200 rounded-2xl flex items-center justify-between text-xs text-sky-900">
                  <span className="font-bold flex items-center gap-1.5">
                    <Clock size={15} className="text-sky-600" />
                    المدة المحتسبة للعمل:
                  </span>
                  <span className="font-black text-sky-800 text-sm">
                    {calculateDaysOfWork(workerStartDate, workerEndDate, sharedRole === 'owner')} {workerEndDate ? 'يوم عمل' : 'يوم عمل حتى اليوم'}
                  </span>
                </div>
              )}

              {/* Notes */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 block">ملاحظات (اختياري)</label>
                <textarea 
                  value={workerNotes}
                  onChange={(e) => setWorkerNotes(e.target.value)}
                  placeholder="أي ملاحظات تفصيلية عن العامل أو الاتفاق..."
                  rows={2}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-xs focus:outline-hidden focus:border-sky-500 transition-colors resize-none"
                />
              </div>
            </div>
          )}

          {/* 2. EMPLOYEE FORM */}
          {type === 'employee' && (
            <div className="space-y-4">
              {/* Full Name */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 block">
                  اسم الموظف الثلاثي <span className="text-rose-500">*</span>
                </label>
                <input 
                  type="text"
                  value={employeeName}
                  onChange={(e) => setEmployeeName(e.target.value)}
                  placeholder="مثال: محمد علي حسن"
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 text-sm font-bold focus:outline-hidden focus:border-indigo-500"
                  required
                  autoFocus
                />
              </div>

              {/* Profession / Role */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 block">
                  المسمى الوظيفي / القسم <span className="text-rose-500">*</span>
                </label>
                <input 
                  type="text"
                  value={employeeProfession}
                  onChange={(e) => setEmployeeProfession(e.target.value)}
                  placeholder="مثال: مهندس موقع، مشرف، محاسب..."
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 text-sm font-bold focus:outline-hidden focus:border-indigo-500"
                  required
                />
              </div>

              {/* Phone Numbers */}
              <PhoneNumbersInput 
                phoneNumbers={employeePhoneNumbers} 
                onChange={setEmployeePhoneNumbers} 
              />

              {/* Wage Type Selector */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 block">نظام المستحقات المالية</label>
                <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100/90 rounded-2xl border border-slate-200/80">
                  <button
                    type="button"
                    onClick={() => setEmployeeWageType('daily')}
                    className={`py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                      employeeWageType === 'daily'
                        ? 'bg-white text-indigo-700 shadow-xs border border-indigo-100'
                        : 'text-slate-500 hover:text-slate-800'
                    }`}
                  >
                    <Clock size={14} />
                    <span>الأجر اليومي</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setEmployeeWageType('monthly')}
                    className={`py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                      employeeWageType === 'monthly'
                        ? 'bg-white text-emerald-700 shadow-xs border border-emerald-100'
                        : 'text-slate-500 hover:text-slate-800'
                    }`}
                  >
                    <Calendar size={14} />
                    <span>الراتب الشهري</span>
                  </button>
                </div>
              </div>

              {employeeWageType === 'daily' ? (
                <div className="space-y-1">
                  <label className="text-xs font-bold text-indigo-700 block">الأجر اليومي (اختياري)</label>
                  <div className="flex gap-2">
                    <input 
                      type="number"
                      step="any"
                      value={employeeDailyWage}
                      onChange={(e) => setEmployeeDailyWage(e.target.value)}
                      placeholder="مثال: 5000"
                      className="flex-1 p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 text-xs font-bold focus:outline-hidden focus:border-indigo-500"
                    />
                    <select
                      value={employeeDailyWageCurrency}
                      onChange={(e) => setEmployeeDailyWageCurrency(e.target.value)}
                      className="w-24 p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-xs font-bold focus:outline-hidden focus:border-indigo-500 cursor-pointer shrink-0"
                    >
                      <option value="YER">YER</option>
                      <option value="SAR">SAR</option>
                      <option value="USD">USD</option>
                    </select>
                  </div>
                  <AmountInWords amount={employeeDailyWage} currency={employeeDailyWageCurrency} />
                </div>
              ) : (
                <div className="space-y-1">
                  <label className="text-xs font-bold text-emerald-700 block">مبلغ الراتب الشهري (المعتمد)</label>
                  <div className="flex gap-2">
                    <input 
                      type="number"
                      step="any"
                      value={employeeMonthlySalary}
                      onChange={(e) => setEmployeeMonthlySalary(e.target.value)}
                      placeholder="مثال: 150000"
                      className="flex-1 p-2.5 bg-emerald-50/40 border border-emerald-200 rounded-xl text-emerald-900 text-xs font-bold focus:outline-hidden focus:border-emerald-500"
                    />
                    <select
                      value={employeeDailyWageCurrency}
                      onChange={(e) => setEmployeeDailyWageCurrency(e.target.value)}
                      className="w-24 p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-xs font-bold focus:outline-hidden focus:border-emerald-500 cursor-pointer shrink-0"
                    >
                      <option value="YER">YER</option>
                      <option value="SAR">SAR</option>
                      <option value="USD">USD</option>
                    </select>
                  </div>
                  <AmountInWords amount={employeeMonthlySalary} currency={employeeDailyWageCurrency} />
                  <p className="text-[11px] text-emerald-700/80 font-medium">
                    💡 يقسم الراتب على أيام كل شهر ويضرب بعدد أيام العمل الفعلية.
                  </p>
                </div>
              )}

              {/* Dates */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700 block">
                    تاريخ البدء <span className="text-rose-500">*</span>
                  </label>
                  <input 
                    type="date"
                    value={employeeStartDate}
                    onChange={(e) => setEmployeeStartDate(e.target.value)}
                    className="w-full h-[42px] px-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 text-xs font-bold focus:outline-hidden focus:border-indigo-500"
                    required
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700 block">تاريخ الانتهاء (اختياري)</label>
                  <input 
                    type="date"
                    value={employeeEndDate}
                    onChange={(e) => setEmployeeEndDate(e.target.value)}
                    className="w-full h-[42px] px-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 text-xs font-bold focus:outline-hidden focus:border-indigo-500"
                  />
                </div>
              </div>

              {/* Notes */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 block">ملاحظات (اختياري)</label>
                <textarea 
                  value={employeeNotes}
                  onChange={(e) => setEmployeeNotes(e.target.value)}
                  placeholder="أي ملاحظات تفصيلية حول الموظف..."
                  rows={2}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-xs focus:outline-hidden focus:border-indigo-500 resize-none"
                />
              </div>
            </div>
          )}

          {/* 3. SUPPLIER FORM */}
          {type === 'supplier' && (
            <div className="space-y-4">
              {/* Supplier Name */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 block">
                  اسم المورد / الشركة <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <input 
                    type="text" 
                    value={supplierName}
                    onChange={(e) => setSupplierName(e.target.value)}
                    placeholder="مثال: شركة الرافدين للمواد الإنشائية"
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 text-sm font-bold focus:outline-hidden focus:border-amber-500 transition-colors pr-9"
                    required
                    autoFocus
                  />
                  <Truck size={16} className="absolute top-1/2 -translate-y-1/2 right-3 text-slate-400 pointer-events-none" />
                </div>
              </div>

              {/* Material Type */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 block">
                  نوع المواد الموردة <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <input 
                    type="text" 
                    value={supplierMaterialType}
                    onChange={(e) => setSupplierMaterialType(e.target.value)}
                    placeholder="مثال: إسمنت، حديد، رمل، طابوق..."
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 text-sm font-bold focus:outline-hidden focus:border-amber-500 transition-colors pr-9"
                    required
                  />
                  <Package size={16} className="absolute top-1/2 -translate-y-1/2 right-3 text-slate-400 pointer-events-none" />
                </div>
              </div>

              {/* Phone Numbers */}
              <PhoneNumbersInput 
                phoneNumbers={supplierPhoneNumbers} 
                onChange={setSupplierPhoneNumbers} 
              />

              {/* Notes */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 block">ملاحظات (اختياري)</label>
                <textarea 
                  value={supplierNotes}
                  onChange={(e) => setSupplierNotes(e.target.value)}
                  placeholder="أي ملاحظات تفصيلية حول المورد أو شروط التوريد..."
                  rows={2}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-xs focus:outline-hidden focus:border-amber-500 transition-colors resize-none"
                />
              </div>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="p-4 bg-slate-50 border-t border-slate-100 flex items-center gap-2.5 shrink-0">
          <button 
            type="button"
            onClick={handleSubmit}
            className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-sm py-2.5 px-4 rounded-xl shadow-md shadow-emerald-600/20 transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-98"
          >
            <PlusCircle size={17} />
            <span>
              {type === 'employee' && 'تسجيل الموظف واعتماده فوراً'}
              {type === 'worker' && 'إضافة العامل واعتماده فوراً'}
              {type === 'supplier' && 'تسجيل المورد واعتماده فوراً'}
            </span>
          </button>
          
          <button 
            type="button"
            onClick={onClose}
            className="px-4 py-2.5 bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold text-xs rounded-xl transition-colors cursor-pointer"
          >
            إلغاء
          </button>
        </div>
      </div>
    </div>,
    document.body
  );
};

export default QuickAddAccountModal;
