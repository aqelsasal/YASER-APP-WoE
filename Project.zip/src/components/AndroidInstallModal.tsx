import React, { useState } from 'react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { Smartphone, Download, CheckCircle, WifiOff, HardDrive, ExternalLink, X, Copy, Check } from 'lucide-react';

interface AndroidInstallModalProps {
  isOpen: boolean;
  onClose: () => void;
  sharedUrl?: string;
}

export const AndroidInstallModal: React.FC<AndroidInstallModalProps> = ({
  isOpen,
  onClose,
  sharedUrl = 'https://ais-pre-pt2ysqhfdfw2gafyroqe7s-489965136865.europe-west2.run.app'
}) => {
  const { isInstallable, isInstalled, install } = usePWAInstall();
  const [copied, setCopied] = useState(false);
  const [activeTab, setActiveTab] = useState<'direct' | 'apk' | 'offline'>('direct');

  if (!isOpen) return null;

  const handleCopyUrl = () => {
    navigator.clipboard.writeText(sharedUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto animate-fade-in" dir="rtl">
      <div className="relative w-full max-w-lg bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-6">
        
        {/* Header */}
        <div className="bg-[#002B49] text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#E85D25] flex items-center justify-center shadow-md">
              <Smartphone className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="font-bold text-base leading-tight">تثبيت التطبيق على هاتف أندرويد (APK / تطبيق مستقل)</h3>
              <p className="text-xs text-slate-300 mt-0.5">يعمل 100% بدون إنترنت ويحفظ البيانات في ذاكرة الهاتف</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-300 hover:text-white hover:bg-white/10 rounded-lg transition-colors cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-slate-200 bg-slate-50 text-xs font-bold">
          <button
            onClick={() => setActiveTab('direct')}
            className={`flex-1 py-3 text-center transition-colors cursor-pointer ${
              activeTab === 'direct'
                ? 'bg-white text-[#002B49] border-b-2 border-[#E85D25]'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            📲 التثبيت المباشر (الأسهل والأسرع)
          </button>
          <button
            onClick={() => setActiveTab('apk')}
            className={`flex-1 py-3 text-center transition-colors cursor-pointer ${
              activeTab === 'apk'
                ? 'bg-white text-[#002B49] border-b-2 border-[#E85D25]'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            📦 تنزيل ملف APK
          </button>
          <button
            onClick={() => setActiveTab('offline')}
            className={`flex-1 py-3 text-center transition-colors cursor-pointer ${
              activeTab === 'offline'
                ? 'bg-white text-[#002B49] border-b-2 border-[#E85D25]'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            💾 العمل بدون نت والتخزين
          </button>
        </div>

        {/* Content */}
        <div className="p-5 max-h-[70vh] overflow-y-auto space-y-4 text-slate-700 text-sm">
          
          {/* TAB 1: Direct Install */}
          {activeTab === 'direct' && (
            <div className="space-y-4">
              <div className="bg-emerald-50 border border-emerald-200 p-3.5 rounded-xl text-emerald-900 text-xs leading-relaxed flex items-start gap-2.5">
                <CheckCircle className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                <div>
                  <strong>نظام أندرويد يدعم تثبيت التطبيقات الحديثة (WebAPK) تلقائياً:</strong>
                  <p className="mt-1">
                    بمجرد فتح الرابط في متصفح هاتفك (Chrome أو متصفح سامسونج) والضغط على "تثبيت"، يقوم نظام أندرويد تلقائياً بإنشاء حزمة أندرويد وتثبيت التطبيق كأي تطبيق أصلي مع أيقونة على شاشة هاتفك وقائمة التطبيقات وبدون شريط المتصفح!
                  </p>
                </div>
              </div>

              {isInstallable && (
                <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-center">
                  <p className="text-xs text-amber-900 font-bold mb-2">متصفحك الحالي جاهز للتثبيت الفوري!</p>
                  <button
                    onClick={async () => {
                      await install();
                    }}
                    className="w-full bg-[#E85D25] hover:bg-[#d44d18] text-white font-bold py-2.5 px-4 rounded-xl flex items-center justify-center gap-2 shadow-md transition-colors cursor-pointer text-sm"
                  >
                    <Download size={18} />
                    اضغط هنا لتثبيت التطبيق على الهاتف الآن 📲
                  </button>
                </div>
              )}

              {isInstalled && (
                <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-center text-xs text-emerald-800 font-bold flex items-center justify-center gap-2">
                  <CheckCircle size={16} />
                  التطبيق مثبت بالفعل ويعمل كتطبيق مستقل على هذا الجهاز!
                </div>
              )}

              <div>
                <h4 className="font-bold text-[#002B49] text-xs mb-2">طريقة التثبيت بـ 3 خطوات بسيطة من الهاتف:</h4>
                <ol className="list-decimal list-inside space-y-2 text-xs bg-slate-50 p-3.5 rounded-xl border border-slate-200 leading-relaxed font-medium">
                  <li>افتح متصفح <strong>Google Chrome</strong> أو <strong>متصفح Samsung</strong> على هاتفك الأندرويد.</li>
                  <li>افتح رابط التطبيق العام (يمكنك نسخه من الزر بالأسفل).</li>
                  <li>اضغط على <strong>النقاط الثلاث (⋮)</strong> في أعلى أو أسفل المتصفح، ثم اختر <strong>"تثبيت التطبيق" (Install App)</strong> أو <strong>"إضافة إلى الشاشة الرئيسية" (Add to Home screen)</strong>.</li>
                  <li>اضغط على <strong>"تثبيت"</strong> — ستجده فوراً في قائمة تطبيقات هاتفك كبرنامج مستقل بالكامل!</li>
                </ol>
              </div>

              <div className="bg-slate-100 p-3 rounded-xl border border-slate-200 flex items-center justify-between gap-2">
                <span className="text-[11px] font-mono text-slate-600 truncate dir-ltr">{sharedUrl}</span>
                <button
                  onClick={handleCopyUrl}
                  className="shrink-0 flex items-center gap-1.5 px-3 py-1.5 bg-[#002B49] text-white text-xs font-bold rounded-lg hover:bg-[#003860] transition-colors cursor-pointer"
                >
                  {copied ? <Check size={14} className="text-emerald-400" /> : <Copy size={14} />}
                  {copied ? 'تم النسخ!' : 'نسخ الرابط'}
                </button>
              </div>
            </div>
          )}

          {/* TAB 2: Standalone APK Generator */}
          {activeTab === 'apk' && (
            <div className="space-y-4 text-xs leading-relaxed">
              <div className="bg-blue-50 border border-blue-200 p-3.5 rounded-xl text-blue-900">
                <strong>هل تريد ملف بصيغة (APK) مستقل لتحميله وإرساله؟</strong>
                <p className="mt-1">
                  يمكنك تحويل التطبيق إلى ملف APK حقيقي وجاهز للتثبيت على أي هاتف أندرويد عبر أداة <strong>PWABuilder</strong> المعتمدة عالمياً من مايكروسوفت أو أدوات تحويل الروابط إلى APK مجاناً ومباشرة من الهاتف:
                </p>
              </div>

              <div className="space-y-2.5">
                <h4 className="font-bold text-[#002B49]">خطوات الحصول على APK عبر الهاتف:</h4>
                <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-2">
                  <p><strong>1. انسخ رابط التطبيق:</strong></p>
                  <div className="flex items-center justify-between gap-2 bg-white p-2 rounded-lg border border-slate-200">
                    <span className="text-[11px] font-mono text-slate-700 truncate dir-ltr">{sharedUrl}</span>
                    <button
                      onClick={handleCopyUrl}
                      className="shrink-0 flex items-center gap-1 px-2.5 py-1 bg-[#002B49] text-white text-[11px] font-bold rounded-md hover:bg-[#003860] transition-colors cursor-pointer"
                    >
                      {copied ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
                      {copied ? 'تم النسخ' : 'نسخ'}
                    </button>
                  </div>

                  <p className="pt-1"><strong>2. افتح موقع بناء ملفات APK من الهاتف:</strong></p>
                  <div className="flex flex-col gap-2">
                    <a
                      href="https://www.pwabuilder.com"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center justify-between p-2.5 bg-white border border-slate-200 rounded-lg hover:border-[#E85D25] text-[#002B49] font-bold text-xs group transition-colors"
                    >
                      <span className="flex items-center gap-2">
                        <span>🌐</span>
                        <span>PWABuilder (أداة رسمية مجانية تابعة لمايكروسوفت)</span>
                      </span>
                      <ExternalLink size={14} className="text-slate-400 group-hover:text-[#E85D25]" />
                    </a>
                    
                    <a
                      href="https://appmaker.xyz/pwa-to-apk"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center justify-between p-2.5 bg-white border border-slate-200 rounded-lg hover:border-[#E85D25] text-[#002B49] font-bold text-xs group transition-colors"
                    >
                      <span className="flex items-center gap-2">
                        <span>📲</span>
                        <span>PWA to APK Converter (تنزيل APK مباشر للهاتف)</span>
                      </span>
                      <ExternalLink size={14} className="text-slate-400 group-hover:text-[#E85D25]" />
                    </a>
                  </div>

                  <p className="pt-1"><strong>3. الصق الرابط واضغط على Build:</strong></p>
                  <p className="text-slate-600">
                    سيقوم الموقع بفحص التطبيق واكتشاف إعدادات الأندرويد والخدمة غير المتصلة بالإنترنت المجهزة فيه، وتنزيل ملف <strong>.apk</strong> جاهز للتثبيت على هاتفك مباشرة!
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: Offline & Local Storage */}
          {activeTab === 'offline' && (
            <div className="space-y-3.5 text-xs leading-relaxed">
              <div className="flex items-start gap-3 bg-amber-50 border border-amber-200 p-3.5 rounded-xl text-amber-950">
                <WifiOff className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-bold text-sm">كيف يعمل التطبيق بدون إنترنت (Offline)؟</h4>
                  <p className="mt-1 text-slate-700">
                    تم تضمين تقنية <strong>Service Worker</strong> و <strong>Cache Storage</strong> في التطبيق؛ بمجرد فتحه لمرة واحدة فقط، يقوم المتصفح تلقائياً بتحميل وحفظ جميع أكواد التطبيق والشاشات والخطوط والتقارير في ذاكرة الهاتف. بعدها يمكنك قطع الإنترنت أو وضع الطيران وسيفتح التطبيق ويعمل فوراً وبسرعة فائقة.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3 bg-blue-50 border border-blue-200 p-3.5 rounded-xl text-blue-950">
                <HardDrive className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-bold text-sm">أين وكيف يتم حفظ البيانات؟</h4>
                  <p className="mt-1 text-slate-700">
                    جميع السجلات والحسابات والقيود والعمال والموردين والمشاريع تُحفظ محلياً داخل <strong>ذاكرة الهاتف الداخلية الدائمة (Local Storage & IndexedDB)</strong> في مساحة التطبيق، ولا تتطلب وجود أي اتصال بالسيرفر أو بالإنترنت لإدخال أو تعديل أو استعراض البيانات.
                  </p>
                </div>
              </div>

              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                <h5 className="font-bold text-[#002B49] mb-1">💡 نصيحة أمان هامة لحفظ بياناتك:</h5>
                <p className="text-slate-600">
                  يمكنك في أي وقت الذهاب إلى <strong>الإعدادات ⚙️</strong> والضغط على <strong>"تصدير نسخة احتياطية (JSON أو Excel)"</strong> والاحتفاظ بملف النسخة الاحتياطية على هاتفك أو عبر واتساب لحماية بياناتك من الضياع في حال تغيير الهاتف أو مسح بيانات المتصفح.
                </p>
              </div>
            </div>
          )}

        </div>

        {/* Footer */}
        <div className="bg-slate-50 p-4 border-t border-slate-200 flex items-center justify-between">
          <span className="text-[11px] text-slate-500 font-medium">شركة ورلد أوف إيليتس للتجارة والمقاولات</span>
          <button
            onClick={onClose}
            className="px-5 py-2 bg-[#002B49] hover:bg-[#003d66] text-white text-xs font-bold rounded-xl transition-colors cursor-pointer"
          >
            إغلاق
          </button>
        </div>

      </div>
    </div>
  );
};
