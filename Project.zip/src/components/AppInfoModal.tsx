/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Info, 
  X, 
  Building2, 
  Phone, 
  MapPin, 
  UserCheck, 
  ShieldCheck, 
  CheckCircle2, 
  Copy, 
  Check, 
  MessageCircle, 
  Layers, 
  HardHat, 
  Cpu
} from 'lucide-react';
import { useBodyScrollLock } from '../utils/modalScrollLock';

import { COMPANY_LOGO_BASE64 } from '../companyLogo';

interface AppInfoModalProps {
  isOpen: boolean;
  onClose: () => void;
  companyName: string;
  companyAddress: string;
  companyPhone: string;
  companyLogo?: string;
  designerName?: string;
  designerPhone?: string;
}

export default function AppInfoModal({
  isOpen,
  onClose,
  companyName,
  companyAddress,
  companyPhone,
  companyLogo = COMPANY_LOGO_BASE64,
  designerName = 'م/ ياسر عقيل',
  designerPhone = '771999911'
}: AppInfoModalProps) {
  const [copiedField, setCopiedField] = useState<string | null>(null);

  useBodyScrollLock(isOpen);

  if (!isOpen) return null;

  const handleCopy = (text: string, fieldName: string) => {
    try {
      navigator.clipboard.writeText(text);
      setCopiedField(fieldName);
      setTimeout(() => setCopiedField(null), 2500);
      if (typeof window !== 'undefined' && (window as any).showToast) {
        (window as any).showToast(`📋 تم نسخ ${fieldName} بنجاح!`);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const cleanDesignerPhone = designerPhone.replace(/[^0-9+]/g, '');

  return (
    <div 
      className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-950/70 backdrop-blur-xs p-3 sm:p-4 overflow-y-auto overscroll-contain"
      id="app-info-modal-backdrop"
      onClick={onClose}
    >
      <div 
        className="bg-white rounded-3xl max-w-xl w-full mx-auto my-auto shadow-2xl border border-slate-200 overflow-hidden flex flex-col text-right dir-rtl animate-scale-up max-h-[92vh]"
        onClick={(e) => e.stopPropagation()}
        id="app-info-modal-card"
      >
        {/* Modal Header */}
        <div className="bg-gradient-to-l from-slate-900 via-slate-850 to-slate-900 text-white p-5 sm:p-6 relative shrink-0 border-b border-slate-800">
          <button
            type="button"
            onClick={onClose}
            className="absolute top-4 left-4 p-2 text-slate-400 hover:text-white bg-slate-800/80 hover:bg-slate-700 rounded-full transition-colors cursor-pointer"
            title="إغلاق النافذة"
            id="close-app-info-modal-btn"
          >
            <X size={18} />
          </button>

          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-500 via-amber-400 to-amber-300 flex items-center justify-center text-slate-950 font-black shadow-lg ring-2 ring-white/20 shrink-0">
              <HardHat size={26} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-black tracking-wider uppercase px-2 py-0.5 rounded-md bg-amber-500/20 text-amber-300 border border-amber-400/30">
                  الإصدار الاحترافي v3.5
                </span>
                <span className="text-[10px] text-emerald-400 font-bold flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                  نظام معتمد ومرخص
                </span>
              </div>
              <h2 className="text-lg sm:text-xl font-black text-white mt-1">
                تطبيق الحسابات وإدارة المشاريع الإنشائية
              </h2>
              <p className="text-xs text-slate-300 font-medium">
                النظام الشامل لإدارة المحاسبة والمقاولات والكوادر الميدانية
              </p>
            </div>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-5 custom-scrollbar">
          
          {/* Section 1: Company Profile */}
          <div className="bg-slate-50 rounded-2xl p-4 sm:p-4.5 border border-slate-200/80 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-200 pb-2">
              <div className="flex items-center gap-2 text-xs font-black text-slate-800">
                <Building2 size={16} className="text-sky-600 shrink-0" />
                <span>بيانات الشركة والمنشأة المالكة</span>
              </div>
              <div className="w-12 h-9 rounded-lg bg-white p-0.5 border border-slate-300 shadow-2xs flex items-center justify-center overflow-hidden">
                <img src={companyLogo} alt="شعار الشركة" className="max-w-full max-h-full object-contain" />
              </div>
            </div>

            <div className="space-y-2.5 text-xs">
              <div className="flex items-start justify-between gap-3">
                <span className="text-slate-500 font-bold shrink-0">اسم الشركة:</span>
                <div className="flex items-center gap-1.5 text-left">
                  <span className="font-extrabold text-slate-900">{companyName || 'ورلد أوف إيليتس للتجارة والمقاولات'}</span>
                  <button
                    type="button"
                    onClick={() => handleCopy(companyName, 'اسم الشركة')}
                    className="p-1 text-slate-400 hover:text-sky-600 rounded-md transition-colors cursor-pointer"
                    title="نسخ"
                  >
                    {copiedField === 'اسم الشركة' ? <Check size={13} className="text-emerald-600" /> : <Copy size={13} />}
                  </button>
                </div>
              </div>

              <div className="flex items-start justify-between gap-3">
                <span className="text-slate-500 font-bold shrink-0">عنوان ومقر الشركة:</span>
                <div className="flex items-center gap-1.5 text-left">
                  <MapPin size={13} className="text-rose-500 shrink-0 mt-0.5" />
                  <span className="font-semibold text-slate-800">{companyAddress || "صنعاء - بيت بوس - شارع الخمسين - 50 St - Bait Boos - Sana'a"}</span>
                </div>
              </div>

              <div className="flex items-start justify-between gap-3">
                <span className="text-slate-500 font-bold shrink-0">هاتف وتواصل الشركة:</span>
                <div className="flex items-center gap-1.5 text-left font-mono">
                  <Phone size={13} className="text-emerald-600 shrink-0" />
                  <span className="font-bold text-slate-900 dir-ltr">{companyPhone || '+967 782 222 877 | +967 779 992 996'}</span>
                  <button
                    type="button"
                    onClick={() => handleCopy(companyPhone, 'أرقام الشركة')}
                    className="p-1 text-slate-400 hover:text-sky-600 rounded-md transition-colors cursor-pointer"
                    title="نسخ"
                  >
                    {copiedField === 'أرقام الشركة' ? <Check size={13} className="text-emerald-600" /> : <Copy size={13} />}
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Section 2: Designer & System Developer Card */}
          <div className="bg-gradient-to-br from-indigo-50/90 via-sky-50/70 to-slate-50 rounded-2xl p-4 sm:p-5 border border-indigo-100/90 shadow-2xs space-y-3.5">
            <div className="flex items-center justify-between border-b border-indigo-100 pb-2">
              <div className="flex items-center gap-2 text-xs font-black text-indigo-950">
                <Cpu size={16} className="text-indigo-600 shrink-0" />
                <span>إعداد وتصميم وهندسة وتطوير النظام</span>
              </div>
              <span className="text-[10px] font-extrabold bg-indigo-100 text-indigo-800 px-2 py-0.5 rounded-full">
                Developer & Architect
              </span>
            </div>

            <div className="space-y-3 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-slate-600 font-bold">اسم المصمم والمطور:</span>
                <div className="flex items-center gap-1.5">
                  <UserCheck size={14} className="text-indigo-600 shrink-0" />
                  <span className="font-black text-slate-900 text-sm">{designerName}</span>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-slate-600 font-bold">رقم هاتف المصمم:</span>
                <div className="flex items-center gap-1.5 font-mono text-sm font-black text-indigo-900 dir-ltr">
                  <span>{designerPhone}</span>
                  <button
                    type="button"
                    onClick={() => handleCopy(designerPhone, 'رقم هاتف المصمم')}
                    className="p-1 text-slate-400 hover:text-indigo-600 rounded-md transition-colors cursor-pointer"
                    title="نسخ الرقم"
                  >
                    {copiedField === 'رقم هاتف المصمم' ? <Check size={13} className="text-emerald-600" /> : <Copy size={13} />}
                  </button>
                </div>
              </div>

              {/* Direct Quick Contact Buttons */}
              <div className="grid grid-cols-2 gap-2 pt-1">
                <a
                  href={`tel:${cleanDesignerPhone}`}
                  className="flex items-center justify-center gap-2 py-2.5 px-3 bg-white hover:bg-slate-50 text-slate-800 border border-slate-200 rounded-xl font-bold text-xs shadow-2xs transition-all cursor-pointer"
                >
                  <Phone size={14} className="text-emerald-600" />
                  <span>اتصال هاتفي مباشر</span>
                </a>
                <a
                  href={`https://wa.me/${cleanDesignerPhone.startsWith('0') ? '967' + cleanDesignerPhone.slice(1) : cleanDesignerPhone.startsWith('967') ? cleanDesignerPhone : '967' + cleanDesignerPhone}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center gap-2 py-2.5 px-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold text-xs shadow-2xs transition-all cursor-pointer"
                >
                  <MessageCircle size={14} />
                  <span>مراسلة عبر واتساب</span>
                </a>
              </div>
            </div>
          </div>

          {/* Section 3: App Features & Specs Highlight */}
          <div className="bg-slate-50/90 rounded-2xl p-4 border border-slate-200/70 space-y-2.5">
            <div className="flex items-center gap-2 text-xs font-black text-slate-800">
              <ShieldCheck size={16} className="text-emerald-600 shrink-0" />
              <span>مواصفات وخصائص التطبيق الفنية</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px] text-slate-600 font-medium pt-1">
              <div className="flex items-center gap-1.5">
                <CheckCircle2 size={13} className="text-emerald-600 shrink-0" />
                <span>إدارة مشاريع إنشائية متعددة ومستقلة</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 size={13} className="text-emerald-600 shrink-0" />
                <span>نظام الأجر اليومي والراتب الشهري التلقائي</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 size={13} className="text-emerald-600 shrink-0" />
                <span>مستودع متكامل لمواد وأصول الشركة والمخزون</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 size={13} className="text-emerald-600 shrink-0" />
                <span>الديون والالتزامات العامة والتقارير الشاملة</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 size={13} className="text-emerald-600 shrink-0" />
                <span>عمل دون اتصال بالإنترنت (Offline-first)</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 size={13} className="text-emerald-600 shrink-0" />
                <span>نسخ احتياطي سحابي ومحلي فوري ومشفر</span>
              </div>
            </div>
          </div>

        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-slate-100 border-t border-slate-200/80 flex items-center justify-between gap-3 shrink-0">
          <span className="text-[11px] text-slate-500 font-bold">
            جميع الحقوق محفوظة © {new Date().getFullYear()}
          </span>
          <button
            type="button"
            onClick={onClose}
            className="py-2 px-5 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl shadow-xs transition-all cursor-pointer"
            id="ok-app-info-modal-btn"
          >
            إغلاق
          </button>
        </div>

      </div>
    </div>
  );
}
