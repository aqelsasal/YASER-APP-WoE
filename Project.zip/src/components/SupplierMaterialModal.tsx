/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { 
  Package, 
  Plus, 
  Trash2, 
  Pencil, 
  X, 
  Check, 
  Layers, 
  AlertCircle, 
  Calculator,
  ArrowDownLeft,
  FileSpreadsheet,
  RotateCcw,
  FileText,
  Camera,
  Upload,
  Eye,
  Download,
  Receipt,
  Image as ImageIcon,
  Tag,
  ArrowUp,
  ArrowDown,
  Undo2,
  Printer,
  FolderPlus,
  FolderCog,
  Palette,
  Sparkles,
  Filter,
  Maximize2,
  Minimize2
} from 'lucide-react';
import { Supplier, SupplierMaterialItem, SUPPLIER_MATERIAL_CATEGORIES, formatCurrency, formatDateArabic, exportMultiSheetXLSX, printPDF } from '../types';
import { MATERIAL_CATEGORY_COLORS, generateMaterialCategoryAnalyticsHtml, generateSupplierItemsDetailedTableHtml } from '../utils/reportCharts';
import { useSupplierMaterialCategories, DYNAMIC_PALETTE } from '../utils/materialCategories';
import { AmountInWords } from './AmountInWords';
import { useBodyScrollLock } from '../utils/modalScrollLock';
import SupplierMaterialExcelModal from './SupplierMaterialExcelModal';
import CategoryManagerModal from './CategoryManagerModal';
import { compressInvoiceImage } from '../utils/safeStorage';
import DraggableScrollIndicator from './DraggableScrollIndicator';

interface SupplierMaterialModalProps {
  isOpen: boolean;
  onClose: () => void;
  items: SupplierMaterialItem[];
  onSave: (items: SupplierMaterialItem[], invoiceData?: { invoiceNumber?: string; invoiceImage?: string }, discount?: number) => void;
  currency?: string;
  invoiceNumber?: string;
  invoiceImage?: string;
  discount?: number;
  transactionInfo?: {
    supplierName?: string;
    date?: string;
    description?: string;
    amountForHim?: number;
    amountOnHim?: number;
  };
  readOnly?: boolean;
  onApplyTotalToAmount?: (total: number) => void;
}

const COMMON_UNITS = ['كيس', 'طن', 'متر', 'متر مربع', 'متر مكعب', 'حبة', 'سيارة', 'نقلة', 'رول', 'برميل', 'كيلو', 'لتر', 'شدة'];

export default function SupplierMaterialModal({
  isOpen,
  onClose,
  items,
  onSave,
  currency = 'YER',
  invoiceNumber = '',
  invoiceImage = '',
  discount = 0,
  transactionInfo,
  readOnly = false,
  onApplyTotalToAmount
}: SupplierMaterialModalProps) {
  useBodyScrollLock(isOpen);

  // Local state for items
  const [itemList, setItemList] = useState<SupplierMaterialItem[]>([]);

  // Local state for Invoice number, Invoice Image & Discount
  const [invoiceNumberState, setInvoiceNumberState] = useState('');
  const [invoiceImageState, setInvoiceImageState] = useState('');
  const [isCompressingImage, setIsCompressingImage] = useState(false);
  const [discountState, setDiscountState] = useState<string>('');
  const discountInputRef = useRef<HTMLInputElement>(null);
  const [isImageModalOpen, setIsImageModalOpen] = useState(false);
  const [isExcelModalOpen, setIsExcelModalOpen] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleExcelImport = (
    importedItems: SupplierMaterialItem[],
    options: { mode: 'append' | 'replace'; invoiceNumber?: string }
  ) => {
    if (options.mode === 'replace') {
      setItemList(importedItems);
    } else {
      setItemList(prev => [...prev, ...importedItems]);
    }

    if (options.invoiceNumber) {
      setInvoiceNumberState(options.invoiceNumber);
    }
  };

  // Dynamic categories hook
  const { 
    categories, 
    customCategories, 
    addCategory, 
    editCategory,
    deleteCategory, 
    resetDefaults,
    getCategoryColor 
  } = useSupplierMaterialCategories(itemList.map(i => i.category || ''));

  // Current item form states
  const [itemName, setItemName] = useState('');
  const [unit, setUnit] = useState('كيس');
  const [quantity, setQuantity] = useState('');
  const [unitPrice, setUnitPrice] = useState('');
  const [category, setCategory] = useState<string>('مواد كهرباء');
  const [notes, setNotes] = useState('');
  const [editingItemId, setEditingItemId] = useState<string | null>(null);
  const [formError, setFormError] = useState('');

  // Category Manager Modal State (Unified Add, Edit, Delete)
  const [showCategoryManagerModal, setShowCategoryManagerModal] = useState(false);
  const [categorySuccessToast, setCategorySuccessToast] = useState('');

  // Category Tab Filter for items table ("تبويب الفئات")
  const [activeCategoryTab, setActiveCategoryTab] = useState<string>('all');

  // Item edit popup state
  const [editModalItem, setEditModalItem] = useState<SupplierMaterialItem | null>(null);
  const [editModalError, setEditModalError] = useState('');

  // Item deletion confirmation state & Undo
  const [itemToDelete, setItemToDelete] = useState<SupplierMaterialItem | null>(null);
  const [lastDeletedItem, setLastDeletedItem] = useState<{ item: SupplierMaterialItem; index: number } | null>(null);

  // Auto-dismiss undo toast
  useEffect(() => {
    if (lastDeletedItem) {
      const timer = setTimeout(() => {
        setLastDeletedItem(null);
      }, 7000);
      return () => clearTimeout(timer);
    }
  }, [lastDeletedItem]);

  // Auto-dismiss category toast
  useEffect(() => {
    if (categorySuccessToast) {
      const timer = setTimeout(() => {
        setCategorySuccessToast('');
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [categorySuccessToast]);

  // Category summary calculations for tabs
  const categoryStats = React.useMemo(() => {
    const stats: Record<string, { count: number; totalCost: number }> = {};
    itemList.forEach(it => {
      const cat = it.category?.trim() || 'غير محدد';
      if (!stats[cat]) {
        stats[cat] = { count: 0, totalCost: 0 };
      }
      stats[cat].count += 1;
      stats[cat].totalCost += (it.total || (it.quantity * it.unitPrice) || 0);
    });
    return stats;
  }, [itemList]);

  // Filtered items for display according to activeCategoryTab
  const displayedItems = activeCategoryTab === 'all'
    ? itemList
    : itemList.filter(it => (it.category?.trim() || '') === activeCategoryTab);

  // Export active invoice items to Excel
  const handleExportItemsExcel = () => {
    if (itemList.length === 0) return;

    const itemsHeaders = [
      '#',
      'اسم الصنف / المادة',
      'الفئة',
      'الكمية',
      'الوحدة',
      'سعر الوحدة',
      'إجمالي البند',
      'العملة',
      'الملاحظات'
    ];

    const itemsRows = itemList.map((it, idx) => [
      idx + 1,
      it.itemName,
      it.category || 'غير محدد',
      it.quantity,
      it.unit || '-',
      it.unitPrice,
      it.total || (it.quantity * it.unitPrice) || 0,
      currency,
      it.notes || '-'
    ]);

    const catTotals: Record<string, { count: number; total: number }> = {};
    itemList.forEach(it => {
      const cat = it.category?.trim() || 'غير محدد';
      if (!catTotals[cat]) catTotals[cat] = { count: 0, total: 0 };
      catTotals[cat].count += 1;
      catTotals[cat].total += (it.total || (it.quantity * it.unitPrice) || 0);
    });

    const itemsSubtotalVal = itemList.reduce((s, it) => s + (it.total || (it.quantity * it.unitPrice) || 0), 0);
    const parsedDiscVal = Math.max(0, parseFloat(discountState) || 0);
    const netGrandTotalVal = Math.max(0, Math.round((itemsSubtotalVal - parsedDiscVal) * 100) / 100);

    const catSummaryHeaders = ['فئة المادة', 'عدد الأصناف', 'إجمالي القيمة المالية', 'النسبة المئوية %'];
    const catSummaryRows: (string | number)[][] = Object.entries(catTotals)
      .sort((a, b) => b[1].total - a[1].total)
      .map(([cat, d]) => [
        cat,
        d.count,
        d.total,
        itemsSubtotalVal > 0 ? `${((d.total / itemsSubtotalVal) * 100).toFixed(1)}%` : '0%'
      ]);

    const finalItemsRows: (string | number)[][] = [...itemsRows];
    if (parsedDiscVal > 0) {
      finalItemsRows.push(['', '', '', '', '', 'إجمالي الأصناف:', itemsSubtotalVal, currency, '']);
      finalItemsRows.push(['', '', '', '', '', 'الخصم / التخفيض المستبعد:', -parsedDiscVal, currency, 'مبلغ مخصوم']);
      finalItemsRows.push(['', '', '', '', '', 'الصافي النهائي لكشف المواد:', netGrandTotalVal, currency, 'صافي الفاتورة']);

      catSummaryRows.push(['---', '', '', '']);
      catSummaryRows.push(['إجمالي قيمة الأصناف', itemList.length, itemsSubtotalVal, '100%']);
      catSummaryRows.push(['الخصم / التخفيض المستبعد', '-', parsedDiscVal, `${((parsedDiscVal / (itemsSubtotalVal || 1)) * 100).toFixed(1)}%`]);
      catSummaryRows.push(['الصافي النهائي لكشف المواد', itemList.length, netGrandTotalVal, '']);
    }

    const filename = `كشف_أصناف_فاتورة_${invoiceNumberState || 'مواد'}_${new Date().toISOString().split('T')[0]}`;
    exportMultiSheetXLSX(filename, [
      { sheetName: 'كشف أصناف الفاتورة', headers: itemsHeaders, rows: finalItemsRows },
      { sheetName: 'ملخص فئات المواد', headers: catSummaryHeaders, rows: catSummaryRows }
    ]);
  };

  // Print PDF report of this material invoice
  const handlePrintItemsPDF = () => {
    if (itemList.length === 0) return;

    const invoiceItemsTotal = itemList.reduce((sum, item) => sum + (item.total || (item.quantity * item.unitPrice) || 0), 0);
    const parsedDiscVal = Math.max(0, parseFloat(discountState) || 0);
    const finalInvoiceTotal = Math.max(0, Math.round((invoiceItemsTotal - parsedDiscVal) * 100) / 100);

    const supplierMock: Supplier = {
      id: 'temp',
      name: transactionInfo?.supplierName || 'المورد',
      materialType: 'توريدات مواد',
      ledger: [
        {
          id: 'temp-entry',
          date: transactionInfo?.date || new Date().toISOString().split('T')[0],
          amountOnHim: transactionInfo?.amountOnHim || 0,
          amountForHim: finalInvoiceTotal,
          description: transactionInfo?.description || 'كشف تفاصيل المواد والأصناف الموردة',
          invoiceNumber: invoiceNumberState,
          materialItems: itemList,
          materialDiscount: parsedDiscVal > 0 ? parsedDiscVal : undefined,
          notes: ''
        }
      ]
    };

    const categoryAnalyticsHtml = generateMaterialCategoryAnalyticsHtml({
      suppliers: [supplierMock],
      currency,
      panelTitle: `لوحة تحليلات ورسم بياني لفئات المواد الموردة بالفاتورة`,
      panelSubtitle: `تحليل تفصيلي لتكاليف وأصناف الفئات (${itemList.length} صنف مسجل)`
    });

    const itemsTableHtml = generateSupplierItemsDetailedTableHtml(itemList, currency, invoiceNumberState, parsedDiscVal);

    const htmlContent = `
      <div style="direction: rtl; font-family: sans-serif; padding: 15px;">
        <div style="border-bottom: 2px solid #ea580c; padding-bottom: 12px; margin-bottom: 16px; display: flex; justify-content: space-between; align-items: center;">
          <div>
            <h1 style="margin: 0; color: #7c2d12; font-size: 19px;">📦 كشف تفاصيل المواد والأصناف الموردة</h1>
            <p style="margin: 4px 0 0 0; color: #64748b; font-size: 12px;">ورلد أوف إيليتس للتجارة والمقاولات</p>
          </div>
          <div style="text-align: left; font-size: 11.5px; color: #64748b;">
            تاريخ التقرير: ${new Date().toLocaleDateString('ar-EG-u-nu-latn')}
            ${invoiceNumberState ? `<br><strong style="color: #c2410c;">رقم الفاتورة: #${invoiceNumberState}</strong>` : ''}
          </div>
        </div>

        <div style="background-color: #fff7ed; border: 1px solid #fed7aa; border-radius: 8px; padding: 10px 14px; margin-bottom: 14px; display: flex; justify-content: space-between; font-size: 12px; flex-wrap: wrap; gap: 8px;">
          <div><strong>المورد:</strong> ${transactionInfo?.supplierName || 'غير محدد'}</div>
          <div><strong>التاريخ:</strong> ${transactionInfo?.date ? formatDateArabic(transactionInfo.date) : formatDateArabic(new Date().toISOString().split('T')[0])}</div>
          <div><strong>إجمالي الأصناف:</strong> <span style="font-family: monospace;">${formatCurrency(invoiceItemsTotal, currency)}</span></div>
          ${parsedDiscVal > 0 ? `<div><strong style="color: #b91c1c;">الخصم / التخفيض:</strong> <span style="color: #b91c1c; font-weight: bold; font-family: monospace;">-${formatCurrency(parsedDiscVal, currency)}</span></div>` : ''}
          <div><strong>الصافي النهائي لكشف المواد:</strong> <span style="font-weight: bold; color: #c2410c; font-family: monospace; font-size: 13px;">${formatCurrency(finalInvoiceTotal, currency)}</span></div>
        </div>

        ${categoryAnalyticsHtml}

        <div style="margin-top: 16px;">
          <h3 style="font-size: 13px; font-weight: bold; color: #9a3412; margin-bottom: 6px;">جدول الأصناف والمواد التفصيلي</h3>
          ${itemsTableHtml}
        </div>
      </div>
    `;

    printPDF(`كشف_تفاصيل_مواد_${invoiceNumberState || 'فاتورة'}`, htmlContent);
  };

  // Scroll tracking and quick navigation for modal body and items table
  const bodyScrollRef = useRef<HTMLDivElement>(null);
  const itemsTableRef = useRef<HTMLDivElement>(null);
  const tableScrollRef = useRef<HTMLDivElement>(null);
  const [tableExpanded, setTableExpanded] = useState(false);
  const [showScrollTop, setShowScrollTop] = useState(false);

  const handleBodyScroll = () => {
    if (bodyScrollRef.current) {
      setShowScrollTop(bodyScrollRef.current.scrollTop > 80);
    }
  };

  const scrollToTop = () => {
    bodyScrollRef.current?.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const scrollToBottom = () => {
    if (bodyScrollRef.current) {
      bodyScrollRef.current.scrollTo({ top: bodyScrollRef.current.scrollHeight, behavior: 'smooth' });
    }
  };

  const scrollToItemsTable = () => {
    if (itemsTableRef.current) {
      itemsTableRef.current.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  const scrollTableToTop = () => {
    tableScrollRef.current?.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const scrollTableToBottom = () => {
    if (tableScrollRef.current) {
      tableScrollRef.current.scrollTo({ top: tableScrollRef.current.scrollHeight, behavior: 'smooth' });
    }
  };

  // Sync with initial items when opened
  useEffect(() => {
    if (isOpen) {
      setItemList(items && Array.isArray(items) ? [...items] : []);
      setInvoiceNumberState(invoiceNumber || '');
      setInvoiceImageState(invoiceImage || '');
      setDiscountState(discount !== undefined && discount > 0 ? String(discount) : '');
      resetForm();
    }
  }, [isOpen, items, invoiceNumber, invoiceImage, discount]);

  if (!isOpen) return null;

  const resetForm = () => {
    setItemName('');
    setUnit('كيس');
    setQuantity('');
    setUnitPrice('');
    setCategory(SUPPLIER_MATERIAL_CATEGORIES[0]);
    setNotes('');
    setEditingItemId(null);
    setFormError('');
  };

  const parsedQty = parseFloat(quantity) || 0;
  const parsedPrice = parseFloat(unitPrice) || 0;
  const currentItemTotal = Math.round((parsedQty * parsedPrice) * 100) / 100;

  // Items Subtotal before discount
  const itemsSubtotal = itemList.reduce((sum, it) => sum + (it.total || 0), 0);
  // Parsed discount value
  const parsedDiscount = Math.max(0, parseFloat(discountState) || 0);
  // Final Net Grand Total (استبعاد مبلغ الخصم/التخفيض من الإجمالي النهائي لكشف المواد فقط)
  const grandTotal = Math.max(0, Math.round((itemsSubtotal - parsedDiscount) * 100) / 100);

  // Add or update item in list
  const handleAddOrUpdateItem = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');

    const trimmedName = itemName.trim();
    if (!trimmedName) {
      setFormError('الرجاء إدخال اسم الصنف / المادة.');
      return;
    }
    if (parsedQty <= 0) {
      setFormError('الكمية يجب أن تكون أكبر من الصفر.');
      return;
    }
    if (parsedPrice <= 0) {
      setFormError('سعر الوحدة يجب أن يكون أكبر من الصفر.');
      return;
    }

    const selectedCat = category.trim() || SUPPLIER_MATERIAL_CATEGORIES[0];

    if (editingItemId) {
      // Update existing item
      setItemList(prev => prev.map(item => {
        if (item.id === editingItemId) {
          return {
            ...item,
            itemName: trimmedName,
            category: selectedCat,
            unit: unit.trim() || 'وحدة',
            quantity: parsedQty,
            unitPrice: parsedPrice,
            total: currentItemTotal,
            notes: notes.trim()
          };
        }
        return item;
      }));
      setEditingItemId(null);
    } else {
      // Add new item
      const newItem: SupplierMaterialItem = {
        id: 'mat_' + Date.now().toString() + '_' + Math.random().toString(36).substring(2, 6),
        itemName: trimmedName,
        category: selectedCat,
        unit: unit.trim() || 'وحدة',
        quantity: parsedQty,
        unitPrice: parsedPrice,
        total: currentItemTotal,
        notes: notes.trim()
      };
      setItemList(prev => [...prev, newItem]);
    }

    // Reset item form
    setItemName('');
    setQuantity('');
    setUnitPrice('');
    setCategory(SUPPLIER_MATERIAL_CATEGORIES[0]);
    setNotes('');
  };

  // Open dedicated edit modal for item
  const handleOpenEditModal = (item: SupplierMaterialItem) => {
    setEditModalItem({ ...item });
    setEditModalError('');
  };

  // Save changes from edit modal
  const handleSaveEditModal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editModalItem) return;

    const trimmedName = editModalItem.itemName.trim();
    if (!trimmedName) {
      setEditModalError('الرجاء إدخال اسم الصنف / المادة.');
      return;
    }
    if (!editModalItem.quantity || editModalItem.quantity <= 0) {
      setEditModalError('الكمية يجب أن تكون أكبر من الصفر.');
      return;
    }
    if (!editModalItem.unitPrice || editModalItem.unitPrice <= 0) {
      setEditModalError('سعر الوحدة يجب أن يكون أكبر من الصفر.');
      return;
    }

    const calculatedTotal = Math.round((editModalItem.quantity * editModalItem.unitPrice) * 100) / 100;

    const updatedItem: SupplierMaterialItem = {
      ...editModalItem,
      itemName: trimmedName,
      unit: (editModalItem.unit || 'وحدة').trim(),
      category: editModalItem.category || SUPPLIER_MATERIAL_CATEGORIES[0],
      total: calculatedTotal,
      notes: (editModalItem.notes || '').trim()
    };

    setItemList(prev => prev.map(it => it.id === updatedItem.id ? updatedItem : it));
    setEditModalItem(null);
    setEditModalError('');
  };

  // Start editing item in the top form (and scroll smoothly to it)
  const handleStartEditItem = (item: SupplierMaterialItem) => {
    setEditingItemId(item.id);
    setItemName(item.itemName);
    setCategory(item.category || SUPPLIER_MATERIAL_CATEGORIES[0]);
    setUnit(item.unit || 'كيس');
    setQuantity(item.quantity.toString());
    setUnitPrice(item.unitPrice.toString());
    setNotes(item.notes || '');
    setFormError('');
    scrollToTop();
  };

  // Request delete item (opens confirmation dialog)
  const handleRequestDelete = (item: SupplierMaterialItem) => {
    setItemToDelete(item);
  };

  // Confirm delete item
  const handleConfirmDelete = () => {
    if (!itemToDelete) return;
    const index = itemList.findIndex(it => it.id === itemToDelete.id);
    if (index !== -1) {
      setLastDeletedItem({ item: itemToDelete, index });
    }
    setItemList(prev => prev.filter(it => it.id !== itemToDelete.id));
    if (editingItemId === itemToDelete.id) {
      resetForm();
    }
    setItemToDelete(null);
  };

  // Undo delete (restore deleted item)
  const handleUndoDelete = () => {
    if (!lastDeletedItem) return;
    setItemList(prev => {
      const newList = [...prev];
      if (lastDeletedItem.index >= 0 && lastDeletedItem.index <= newList.length) {
        newList.splice(lastDeletedItem.index, 0, lastDeletedItem.item);
      } else {
        newList.push(lastDeletedItem.item);
      }
      return newList;
    });
    setLastDeletedItem(null);
  };

  // Save all and close
  const handleSaveModal = () => {
    onSave(itemList, {
      invoiceNumber: invoiceNumberState.trim(),
      invoiceImage: invoiceImageState || undefined
    }, parsedDiscount > 0 ? parsedDiscount : undefined);
    onClose();
  };

  // Image Upload and Safe Compression Handler
  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      alert('الرجاء اختيار ملف صورة صالح (JPEG, PNG, WebP).');
      return;
    }

    try {
      setIsCompressingImage(true);
      const compressedDataUrl = await compressInvoiceImage(file);
      setInvoiceImageState(compressedDataUrl);
    } catch (err: any) {
      console.error('Error compressing invoice image:', err);
      alert(err.message || 'حدث خطأ أثناء معالجة الصورة، يرجى المحاولة مرة أخرى.');
    } finally {
      setIsCompressingImage(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  // Difference notice between transaction amount and materials total
  const txAmountForHim = transactionInfo?.amountForHim || 0;
  const hasAmountDifference = txAmountForHim > 0 && grandTotal > 0 && Math.abs(txAmountForHim - grandTotal) > 0.01;

  return (
    <div 
      className="fixed inset-0 z-[110] flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-2 sm:p-4 overflow-hidden dir-rtl text-right animate-fade-in"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
      id="supplier-material-modal-backdrop"
    >
      <div 
        className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-4xl w-full animate-scale-up my-auto max-h-[94vh] sm:max-h-[90vh] h-[94vh] sm:h-auto flex flex-col overflow-hidden relative"
        onClick={(e) => e.stopPropagation()}
        id="supplier-material-modal"
      >
        {/* Fixed Header */}
        <div className="p-3.5 sm:p-4 border-b border-slate-100 flex items-center justify-between shrink-0 bg-white">
          <div className="flex items-center gap-2.5 flex-wrap">
            <div className="w-9 h-9 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center border border-amber-100 shadow-xs shrink-0">
              <Package size={20} />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h3 
                  onClick={scrollToTop}
                  className="font-bold text-slate-800 text-sm sm:text-base cursor-pointer hover:text-amber-700 transition-colors"
                  title="انقر هنا للصعود لأعلى النافذة"
                >
                  كشف تفاصيل المواد والأصناف الموردة
                </h3>
                <span className="text-[11px] font-extrabold text-amber-700 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded-md font-mono">
                  العملة: {currency}
                </span>
                {itemList.length > 0 && (
                  <span className="text-[11px] font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded-md">
                    {itemList.length} {itemList.length === 1 ? 'صنف' : itemList.length === 2 ? 'صنفين' : 'أصناف'}
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-400">
                تسجيل وحساب جدول كميات وأسعار الأصناف المرتبطة بالحركة المالية
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {itemList.length > 0 && (
              <button
                type="button"
                onClick={scrollToItemsTable}
                className="hidden md:inline-flex items-center gap-1.5 text-[11px] font-bold bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200 px-2.5 py-1 rounded-lg transition-colors cursor-pointer shadow-2xs"
                title="الانتقال السريع إلى جدول الأصناف المقيدة"
              >
                <FileSpreadsheet size={13} className="text-amber-600" />
                <span>جدول الأصناف</span>
              </button>
            )}
            {showScrollTop && (
              <button
                type="button"
                onClick={scrollToTop}
                className="hidden sm:inline-flex items-center gap-1 text-[11px] font-bold bg-amber-100 hover:bg-amber-200 text-amber-900 px-2.5 py-1 rounded-lg transition-colors cursor-pointer shadow-2xs"
                title="العودة لأعلى الكشف"
              >
                <ArrowUp size={13} />
                <span>للأعلى</span>
              </button>
            )}
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-700 rounded-xl hover:bg-slate-100 cursor-pointer transition-colors"
              title="إغلاق"
            >
              <X size={20} />
            </button>
          </div>
        </div>

        {/* Main Content Area with Prominent Draggable Scroll & Navigation Rail */}
        <div className="flex-1 flex min-h-0 relative overflow-hidden bg-slate-50/20">
          {/* Scrollable Body */}
          <div 
            ref={bodyScrollRef}
            onScroll={handleBodyScroll}
            className="p-3.5 sm:p-5 overflow-y-auto space-y-4 flex-1 min-h-0 modal-scroll-area custom-scrollbar bg-slate-50/30 touch-pan-y relative"
            id="supplier-material-modal-scroll-body"
          >
          
          {/* Transaction Info Banner if available */}
          {transactionInfo && (
            <div className="bg-white p-3 rounded-xl border border-slate-200/80 shadow-xs grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
              {transactionInfo.supplierName && (
                <div>
                  <span className="text-slate-400 block text-[10px]">المورد:</span>
                  <span className="font-bold text-slate-700">{transactionInfo.supplierName}</span>
                </div>
              )}
              {transactionInfo.date && (
                <div>
                  <span className="text-slate-400 block text-[10px]">تاريخ الحركة:</span>
                  <span className="font-bold text-slate-700">{formatDateArabic(transactionInfo.date)}</span>
                </div>
              )}
              {transactionInfo.description && (
                <div className="col-span-2 sm:col-span-1 truncate">
                  <span className="text-slate-400 block text-[10px]">البيان:</span>
                  <span className="font-bold text-slate-700" title={transactionInfo.description}>
                    {transactionInfo.description}
                  </span>
                </div>
              )}
              <div>
                <span className="text-slate-400 block text-[10px]">مبلغ الحركة المسجل:</span>
                <span className="font-extrabold text-emerald-600 font-mono">
                  {txAmountForHim > 0 ? formatCurrency(txAmountForHim, currency) : (transactionInfo.amountOnHim && transactionInfo.amountOnHim > 0 ? `عليه: ${formatCurrency(transactionInfo.amountOnHim, currency)}` : '-')}
                </span>
              </div>
            </div>
          )}

          {/* Notice if transaction amount differs from material total */}
          {hasAmountDifference && (
            <div className="bg-amber-50/80 border border-amber-200/90 p-2.5 rounded-xl flex items-center justify-between gap-2 flex-wrap text-xs text-amber-900">
              <div className="flex items-center gap-2">
                <AlertCircle size={16} className="text-amber-600 shrink-0" />
                <span>
                  إجمالي كشف المواد{parsedDiscount > 0 ? ' الصافي' : ''} (<strong>{formatCurrency(grandTotal, currency)}</strong>) يختلف عن مبلغ الحركة المسجل (<strong>{formatCurrency(txAmountForHim, currency)}</strong>).
                </span>
              </div>
              {onApplyTotalToAmount && !readOnly && (
                <button
                  type="button"
                  onClick={() => onApplyTotalToAmount(grandTotal)}
                  className="bg-amber-600 hover:bg-amber-700 text-white text-[11px] font-bold px-2.5 py-1 rounded-lg transition-colors cursor-pointer flex items-center gap-1 shadow-xs"
                >
                  <ArrowDownLeft size={13} />
                  مطابقة مبلغ الحركة مع صافي المواد
                </button>
              )}
            </div>
          )}

          {/* Invoice Information Header Card (رقم الفاتورة وصورة الفاتورة) */}
          <div className="bg-white p-3.5 sm:p-4 rounded-xl border border-slate-200 shadow-xs space-y-3" id="invoice-info-section">
            <div className="flex items-center justify-between gap-2 border-b border-slate-100 pb-2">
              <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                <Receipt size={16} className="text-amber-600" />
                <span>بيانات ومستند الفاتورة المرفقة</span>
              </span>
              {invoiceNumberState.trim() && (
                <span className="text-[11px] font-mono font-bold text-amber-800 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded-md">
                  رقم الفاتورة: #{invoiceNumberState.trim()}
                </span>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 items-center">
              {/* رقم الفاتورة */}
              <div className="sm:col-span-4 space-y-1">
                <label className="text-[11px] font-bold text-slate-600 flex items-center gap-1">
                  <FileText size={13} className="text-slate-500" />
                  <span>رقم الفاتورة</span>
                  <span className="text-[10px] text-slate-400 font-normal">(أو رقم السند)</span>
                </label>
                {readOnly ? (
                  <div className="h-9 px-3 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 text-xs flex items-center font-mono font-bold">
                    {invoiceNumberState || 'غير مسجل'}
                  </div>
                ) : (
                  <div className="relative">
                    <input 
                      type="text"
                      placeholder="مثال: INV-10482 أو 4892..."
                      value={invoiceNumberState}
                      onChange={(e) => setInvoiceNumberState(e.target.value)}
                      className="w-full h-9 pr-8 pl-3 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 text-xs font-mono focus:outline-hidden focus:border-amber-500 transition-colors"
                    />
                    <Receipt size={14} className="absolute top-1/2 -translate-y-1/2 right-2.5 text-slate-400" />
                  </div>
                )}
              </div>

              {/* خانة الخصم / التخفيض الجديدة */}
              <div className="sm:col-span-4 space-y-1">
                <label className="text-[11px] font-bold text-slate-600 flex items-center justify-between">
                  <span className="flex items-center gap-1">
                    <Tag size={13} className="text-rose-600" />
                    <span>الخصم / التخفيض</span>
                  </span>
                  <span className="text-[10px] text-slate-400 font-normal">(يُستبعد من إجمالي المواد)</span>
                </label>
                {readOnly ? (
                  <div className="h-9 px-3 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 text-xs flex items-center font-mono font-bold justify-between">
                    <span className={parsedDiscount > 0 ? 'text-rose-700' : 'text-slate-600'}>
                      {parsedDiscount > 0 ? formatCurrency(parsedDiscount, currency) : '0'}
                    </span>
                    {parsedDiscount > 0 ? (
                      <span className="text-[10px] text-rose-600 font-sans font-bold bg-rose-50 px-1.5 py-0.5 rounded">مخصوم</span>
                    ) : (
                      <span className="text-[10px] text-slate-400 font-sans font-normal">لا يوجد خصم</span>
                    )}
                  </div>
                ) : (
                  <div className="relative">
                    <input 
                      ref={discountInputRef}
                      type="number"
                      min="0"
                      step="any"
                      placeholder="0.00"
                      value={discountState}
                      onChange={(e) => setDiscountState(e.target.value)}
                      className={`w-full h-9 pr-8 pl-12 bg-slate-50 border rounded-lg text-slate-800 text-xs font-mono font-bold focus:outline-hidden transition-colors ${
                        parsedDiscount > 0 
                          ? 'border-rose-300 bg-rose-50/40 focus:border-rose-500 text-rose-900' 
                          : 'border-slate-200 focus:border-amber-500'
                      }`}
                    />
                    <Tag size={14} className={`absolute top-1/2 -translate-y-1/2 right-2.5 ${parsedDiscount > 0 ? 'text-rose-600' : 'text-slate-400'}`} />
                    <div className="absolute top-1/2 -translate-y-1/2 left-2 flex items-center gap-1">
                      {parsedDiscount > 0 && (
                        <button
                          type="button"
                          onClick={() => setDiscountState('')}
                          className="text-slate-400 hover:text-rose-600 p-0.5 rounded transition-colors cursor-pointer"
                          title="مسح مبلغ الخصم"
                        >
                          <X size={12} />
                        </button>
                      )}
                      <span className="text-[10px] text-slate-400 font-bold">
                        {currency}
                      </span>
                    </div>
                  </div>
                )}
              </div>

              {/* صورة الفاتورة (زر إرفاق / رفع / معاينة) */}
              <div className="sm:col-span-4 space-y-1">
                <label className="text-[11px] font-bold text-slate-600 flex items-center gap-1">
                  <Camera size={13} className="text-amber-600" />
                  <span>صورة الفاتورة</span>
                  <span className="text-[10px] text-slate-400 font-normal">(إرفاق أو تصوير من الهاتف)</span>
                </label>

                {isCompressingImage ? (
                  <div className="h-9 px-3 bg-amber-50 border border-amber-300 rounded-lg text-amber-800 text-xs font-bold flex items-center justify-center gap-2 animate-pulse">
                    <Camera size={15} className="animate-spin text-amber-600" />
                    <span>جارٍ ضغط وتحسين صورة الفاتورة...</span>
                  </div>
                ) : invoiceImageState ? (
                  <div className="flex items-center gap-2">
                    {/* زر معاينة الصورة المرفقة */}
                    <button
                      type="button"
                      onClick={() => setIsImageModalOpen(true)}
                      className="flex-1 h-9 px-2.5 bg-amber-50 hover:bg-amber-100/90 border border-amber-200 text-amber-900 rounded-lg text-xs font-bold transition-all flex items-center justify-between gap-2 cursor-pointer shadow-2xs group"
                      title="معاينة صورة الفاتورة بالحجم الكامل"
                    >
                      <div className="flex items-center gap-2 truncate">
                        <div className="w-6 h-6 rounded-md overflow-hidden bg-slate-200 border border-amber-300 shrink-0">
                          <img src={invoiceImageState} alt="صورة الفاتورة" className="w-full h-full object-cover" />
                        </div>
                        <span className="truncate text-[11px]">معاينة صورة الفاتورة</span>
                      </div>
                      <Eye size={14} className="text-amber-700 group-hover:scale-110 transition-transform shrink-0" />
                    </button>

                    {!readOnly && (
                      <>
                        {/* زر تغيير الصورة */}
                        <button
                          type="button"
                          onClick={() => fileInputRef.current?.click()}
                          className="h-9 px-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 rounded-lg text-[11px] font-bold transition-colors cursor-pointer flex items-center gap-1 shrink-0"
                          title="تغيير أو إعادة تصوير الفاتورة من الهاتف"
                        >
                          <Upload size={13} />
                          <span>تغيير</span>
                        </button>

                        {/* زر حذف الصورة */}
                        <button
                          type="button"
                          onClick={() => setInvoiceImageState('')}
                          className="h-9 px-2.5 bg-rose-50 hover:bg-rose-100 text-rose-600 border border-rose-200 rounded-lg text-xs font-bold transition-colors cursor-pointer flex items-center justify-center shrink-0"
                          title="حذف صورة الفاتورة"
                        >
                          <Trash2 size={13} />
                        </button>
                      </>
                    )}
                  </div>
                ) : (
                  <div>
                    {readOnly ? (
                      <div className="h-9 px-3 bg-slate-50 border border-slate-200 rounded-lg text-slate-400 text-xs flex items-center">
                        لا توجد صورة فاتورة مرفقة
                      </div>
                    ) : (
                      <button
                        type="button"
                        onClick={() => fileInputRef.current?.click()}
                        className="w-full h-9 px-3 bg-slate-50 hover:bg-amber-50/80 border border-dashed border-slate-300 hover:border-amber-400 text-slate-700 hover:text-amber-800 rounded-lg text-xs font-bold transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-2xs"
                      >
                        <Camera size={15} className="text-amber-600" />
                        <span>صورة الفاتورة (إرفاق / رفع من الهاتف)</span>
                      </button>
                    )}
                  </div>
                )}

                {/* Hidden File Input supporting direct camera capture or gallery selection on phones */}
                <input 
                  type="file" 
                  ref={fileInputRef}
                  onChange={handleImageUpload}
                  accept="image/*"
                  className="hidden"
                />
              </div>
            </div>
          </div>

          {/* Form to add / edit items (only if not readOnly) */}
          {!readOnly && (
            <div className="bg-white p-3.5 sm:p-4 rounded-xl border border-slate-200 shadow-xs space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                  <Layers size={15} className="text-amber-500" />
                  {editingItemId ? 'تعديل بيانات الصنف المحدد' : 'إضافة صنف ومادة جديدة إلى الكشف'}
                </span>
                {editingItemId && (
                  <button
                    type="button"
                    onClick={resetForm}
                    className="text-[11px] text-slate-500 hover:text-rose-600 font-bold hover:underline cursor-pointer"
                  >
                    إلغاء التعديل والرجوع للإضافة ✕
                  </button>
                )}
              </div>

              <form onSubmit={handleAddOrUpdateItem} className="space-y-3">
                {/* Row 1: Item Basic Data */}
                <div className="grid grid-cols-1 sm:grid-cols-12 gap-2.5 items-end">
                  
                  {/* Item Name */}
                  <div className="sm:col-span-4 space-y-1">
                    <label className="text-[11px] font-bold text-slate-600">
                      الصنف / المادة <span className="text-rose-500">*</span>
                    </label>
                    <input 
                      type="text"
                      placeholder="مثال: إسمنت، حديد 12ملم، بلك أحمر..."
                      value={itemName}
                      onChange={(e) => setItemName(e.target.value)}
                      className="w-full h-9 px-3 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 text-xs focus:outline-hidden focus:border-amber-500 transition-colors"
                      required
                    />
                  </div>

                  {/* Unit */}
                  <div className="sm:col-span-2 space-y-1">
                    <label className="text-[11px] font-bold text-slate-600">الوحدة</label>
                    <div className="relative">
                      <input 
                        type="text"
                        placeholder="كيس / طن / حبة"
                        value={unit}
                        onChange={(e) => setUnit(e.target.value)}
                        className="w-full h-9 px-3 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 text-xs focus:outline-hidden focus:border-amber-500 transition-colors"
                        list="unit-suggestions"
                      />
                      <datalist id="unit-suggestions">
                        {COMMON_UNITS.map(u => (
                          <option key={u} value={u} />
                        ))}
                      </datalist>
                    </div>
                  </div>

                  {/* Quantity */}
                  <div className="sm:col-span-2 space-y-1">
                    <label className="text-[11px] font-bold text-slate-600">
                      الكمية <span className="text-rose-500">*</span>
                    </label>
                    <input 
                      type="number"
                      step="any"
                      placeholder="0"
                      value={quantity}
                      onChange={(e) => setQuantity(e.target.value)}
                      className="w-full h-9 px-2.5 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 text-xs font-mono text-left focus:outline-hidden focus:border-amber-500"
                      required
                    />
                  </div>

                  {/* Unit Price */}
                  <div className="sm:col-span-2 space-y-1">
                    <label className="text-[11px] font-bold text-slate-600">
                      سعر الوحدة <span className="text-rose-500">*</span>
                    </label>
                    <input 
                      type="number"
                      step="any"
                      placeholder="0"
                      value={unitPrice}
                      onChange={(e) => setUnitPrice(e.target.value)}
                      className="w-full h-9 px-2.5 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 text-xs font-mono text-left focus:outline-hidden focus:border-amber-500"
                      required
                    />
                  </div>

                  {/* Calculated Item Total Badge */}
                  <div className="sm:col-span-2">
                    <div className="h-9 px-2 bg-amber-50 border border-amber-200 rounded-lg flex flex-col justify-center text-center">
                      <span className="text-[9px] text-amber-700 font-bold leading-none">الإجمالي</span>
                      <span className="text-xs font-extrabold text-amber-800 font-mono leading-tight truncate">
                        {formatCurrency(currentItemTotal, currency)}
                      </span>
                    </div>
                  </div>

                </div>

                {/* Row 2: Category Grid List (قائمة شبكية لفئات المواد والأصناف) */}
                <div className="p-2.5 bg-gradient-to-b from-amber-50/60 to-slate-50/50 rounded-xl border border-amber-200/80 space-y-2">
                  <div className="flex flex-wrap items-center justify-between gap-1.5 text-[11px]">
                    <div className="flex items-center gap-1.5 font-extrabold text-slate-800">
                      <div className="p-1 bg-amber-100 text-amber-700 rounded-md">
                        <Tag size={13} />
                      </div>
                      <span>فئات الأصناف والمواد الموردة <span className="text-rose-500">*</span></span>
                      <span className="text-[10px] font-normal text-slate-500 hidden sm:inline">(اختر فئة واحدة بالضغط عليها)</span>
                    </div>

                    <div className="flex items-center gap-2">
                      {category && (
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-black bg-white text-slate-800 border border-amber-300 shadow-2xs">
                          <span 
                            className="w-2 h-2 rounded-full shrink-0" 
                            style={{ backgroundColor: getCategoryColor(category) }} 
                          />
                          <span className="text-slate-500 font-normal">الفئة المختارة:</span>
                          <span className="text-amber-800">{category}</span>
                        </span>
                      )}

                      <button
                        type="button"
                        onClick={() => setShowCategoryManagerModal(true)}
                        className="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-bold text-amber-800 bg-amber-50 hover:bg-amber-100/90 border border-amber-300/80 rounded-lg transition-all shadow-2xs hover:shadow-xs active:scale-95 cursor-pointer"
                        title="إدارة فئات الأصناف والمواد الموردة (إضافة - تعديل - حذف)"
                      >
                        <FolderCog size={13} className="text-amber-700 stroke-[2.2]" />
                        <span>إدارة الفئة</span>
                      </button>
                    </div>
                  </div>

                  {/* The Grid List */}
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-1.5 max-h-48 overflow-y-auto p-1 custom-scrollbar">
                    {categories.map(cat => {
                      const isSelected = category === cat;
                      const catColor = getCategoryColor(cat);
                      const isCustom = customCategories.includes(cat);
                      return (
                        <button
                          key={cat}
                          type="button"
                          onClick={() => setCategory(cat)}
                          className={`relative flex items-center justify-between px-2.5 py-2 rounded-lg text-xs font-extrabold transition-all border text-right cursor-pointer select-none active:scale-98 ${
                            isSelected
                              ? 'bg-amber-600 text-white border-amber-600 shadow-xs ring-2 ring-amber-500/25 scale-[1.01]'
                              : 'bg-white hover:bg-slate-50 text-slate-700 border-slate-200 hover:border-slate-300 shadow-2xs'
                          }`}
                        >
                          <div className="flex items-center gap-1.5 min-w-0">
                            <span 
                              className={`w-2.5 h-2.5 rounded-full shrink-0 transition-transform ${isSelected ? 'ring-2 ring-white scale-110' : ''}`}
                              style={{ backgroundColor: isSelected ? '#ffffff' : catColor }}
                            />
                            <span className="truncate">{cat}</span>
                            {isCustom && !isSelected && (
                              <span className="text-[9px] px-1 bg-amber-100 text-amber-800 rounded font-normal shrink-0">جديدة</span>
                            )}
                          </div>
                          {isSelected ? (
                            <Check size={13} className="shrink-0 text-white stroke-[3]" />
                          ) : (
                            <span className="w-1.5 h-1.5 rounded-full bg-slate-200 shrink-0" />
                          )}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Row 3: Notes + Add / Update Buttons */}
                <div className="grid grid-cols-1 sm:grid-cols-12 gap-2.5 items-end">
                  
                  {/* Notes */}
                  <div className="sm:col-span-8 space-y-1">
                    <label className="text-[11px] font-bold text-slate-600">ملاحظات الصنف (اختياري)</label>
                    <input 
                      type="text"
                      placeholder="تفاصيل المقاس، النوعية، رقم الفاتورة..."
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      className="w-full h-9 px-3 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 text-xs focus:outline-hidden focus:border-amber-500"
                    />
                  </div>

                  {/* Add / Update Button */}
                  <div className="sm:col-span-4 flex gap-1.5">
                    <button 
                      type="submit"
                      className={`flex-1 h-9 px-3 rounded-lg font-bold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer shadow-xs text-white ${
                        editingItemId 
                          ? 'bg-sky-600 hover:bg-sky-700 shadow-sky-600/20' 
                          : 'bg-emerald-600 hover:bg-emerald-700 shadow-emerald-600/20'
                      }`}
                    >
                      {editingItemId ? (
                        <>
                          <Check size={14} />
                          <span>حفظ التعديل</span>
                        </>
                      ) : (
                        <>
                          <Plus size={14} />
                          <span>إضافة الصنف للكشف</span>
                        </>
                      )}
                    </button>
                    <button
                      type="button"
                      onClick={resetForm}
                      className="h-9 px-3 bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold text-xs rounded-lg transition-colors flex items-center justify-center gap-1 cursor-pointer shrink-0"
                      title="إلغاء وتنظيف الحقول"
                    >
                      <RotateCcw size={13} />
                      <span>إلغاء</span>
                    </button>
                  </div>

                </div>

                {formError && (
                  <p className="text-[11px] text-rose-600 font-bold bg-rose-50 p-2 rounded-lg border border-rose-100">
                    {formError}
                  </p>
                )}

              </form>
            </div>
          )}

          {/* Table of items */}
          <div 
            ref={itemsTableRef}
            className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden"
            id="items-table-section"
          >
            <div className="p-3 border-b border-slate-100 bg-slate-50/70 flex items-center justify-between gap-2 flex-wrap">
              <div className="flex items-center gap-2">
                <span className="font-bold text-slate-800 text-xs flex items-center gap-1.5">
                  <FileSpreadsheet size={15} className="text-amber-600" />
                  <span>جدول الأصناف المقيدة في هذا الكشف</span>
                </span>
                <span className="text-xs font-bold text-slate-500 bg-slate-200/70 px-2 py-0.5 rounded-md">
                  إجمالي الأصناف: ({itemList.length})
                </span>
              </div>

              <div className="flex items-center gap-1.5 flex-wrap">
                {/* Table Quick Navigation & Scroll Controls */}
                {itemList.length > 3 && (
                  <div className="inline-flex items-center gap-1 bg-amber-50/80 border border-amber-200/80 rounded-xl p-0.5">
                    <button
                      type="button"
                      onClick={scrollTableToTop}
                      className="inline-flex items-center gap-0.5 text-[10px] font-bold text-amber-800 hover:bg-amber-100 px-2 py-1 rounded-lg transition-colors cursor-pointer"
                      title="الانتقال لأعلى جدول الأصناف"
                    >
                      <ArrowUp size={11} className="stroke-[2.5]" />
                      <span>أعلى الجدول</span>
                    </button>
                    <button
                      type="button"
                      onClick={scrollTableToBottom}
                      className="inline-flex items-center gap-0.5 text-[10px] font-bold text-amber-800 hover:bg-amber-100 px-2 py-1 rounded-lg transition-colors cursor-pointer"
                      title="الانتقال لأسفل جدول الأصناف"
                    >
                      <ArrowDown size={11} className="stroke-[2.5]" />
                      <span>أسفل الجدول</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setTableExpanded(!tableExpanded)}
                      className="inline-flex items-center gap-0.5 text-[10px] font-bold text-slate-700 hover:bg-white px-2 py-1 rounded-lg transition-colors cursor-pointer border border-transparent hover:border-slate-200"
                      title={tableExpanded ? "تبديل إلى نمط التمرير المدمج داخل الجدول" : "عرض الجدول كاملاً دون شريط تمرير داخلي"}
                    >
                      {tableExpanded ? (
                        <>
                          <Minimize2 size={11} />
                          <span>تمرير مدمج</span>
                        </>
                      ) : (
                        <>
                          <Maximize2 size={11} />
                          <span>عرض كامل</span>
                        </>
                      )}
                    </button>
                  </div>
                )}
                {itemList.length > 0 && (
                  <>
                    <button
                      type="button"
                      onClick={handleExportItemsExcel}
                      className="inline-flex items-center gap-1 text-[11px] font-bold bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 px-2.5 py-1.5 rounded-xl shadow-2xs transition-colors cursor-pointer"
                      title="تصدير جدول الأصناف وملخص الفئات إلى ملف Excel"
                    >
                      <Download size={13} className="text-emerald-600" />
                      <span className="hidden sm:inline">تصدير إكسل</span>
                    </button>
                    <button
                      type="button"
                      onClick={handlePrintItemsPDF}
                      className="inline-flex items-center gap-1 text-[11px] font-bold bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 px-2.5 py-1.5 rounded-xl shadow-2xs transition-colors cursor-pointer"
                      title="طباعة كشف الأصناف وتحليل الفئات PDF"
                    >
                      <Printer size={13} className="text-amber-600" />
                      <span className="hidden sm:inline">طباعة PDF</span>
                    </button>
                  </>
                )}

                {!readOnly && (
                  <button
                    type="button"
                    onClick={() => setIsExcelModalOpen(true)}
                    className="inline-flex items-center gap-1.5 text-xs font-bold bg-emerald-600 hover:bg-emerald-700 text-white px-3 py-1.5 rounded-xl shadow-xs transition-all duration-200 cursor-pointer hover:scale-102 active:scale-98"
                    title="استيراد وتوزيع الأصناف من جدول إكسل أو فاتورة خارجية"
                  >
                    <FileSpreadsheet size={14} />
                    <span>استيراد من ملف إكسل</span>
                  </button>
                )}
              </div>
            </div>

            {/* Category Tabs Bar (تبويب الفئات) */}
            {itemList.length > 0 && (
              <div className="p-2.5 bg-gradient-to-r from-amber-50/60 via-slate-50 to-orange-50/50 border-b border-slate-200">
                <div className="flex items-center justify-between gap-2 mb-1.5 px-1">
                  <div className="flex items-center gap-1.5 text-xs font-extrabold text-slate-700">
                    <Filter size={13} className="text-amber-600" />
                    <span>تبويب الفئات والتصفية السريعة للأصناف:</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setShowCategoryManagerModal(true)}
                    className="text-[11px] font-bold text-amber-800 hover:text-amber-900 flex items-center gap-1.5 bg-amber-50 hover:bg-amber-100/90 px-2.5 py-1 rounded-lg border border-amber-300/80 transition-all shadow-2xs hover:shadow-xs active:scale-95 cursor-pointer"
                    title="إدارة فئات الأصناف والمواد (إضافة - تعديل - حذف)"
                  >
                    <FolderCog size={13} className="text-amber-700 stroke-[2.2]" />
                    <span>إدارة الفئة</span>
                  </button>
                </div>

                <div className="flex items-center gap-1.5 overflow-x-auto pb-1 custom-scrollbar text-xs">
                  {/* All Categories Tab */}
                  <button
                    type="button"
                    onClick={() => setActiveCategoryTab('all')}
                    className={`shrink-0 flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-bold transition-all text-xs cursor-pointer ${
                      activeCategoryTab === 'all'
                        ? 'bg-amber-600 text-white shadow-xs scale-102'
                        : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    <span>كافة الفئات</span>
                    <span className={`px-1.5 py-0.2 rounded-full text-[10px] font-mono ${
                      activeCategoryTab === 'all' ? 'bg-amber-700 text-white' : 'bg-slate-100 text-slate-600'
                    }`}>
                      {itemList.length}
                    </span>
                  </button>

                  {/* Category Filter Tabs */}
                  {Array.from(new Set([...Object.keys(categoryStats), ...customCategories])).map(cat => {
                    const stats = categoryStats[cat] || { count: 0, totalCost: 0 };
                    const isSelected = activeCategoryTab === cat;
                    const catColor = getCategoryColor(cat);

                    return (
                      <button
                        key={cat}
                        type="button"
                        onClick={() => setActiveCategoryTab(cat)}
                        className={`shrink-0 flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl font-bold transition-all text-xs cursor-pointer ${
                          isSelected
                            ? 'bg-slate-800 text-white shadow-xs scale-102'
                            : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'
                        }`}
                      >
                        <span 
                          className="w-2.5 h-2.5 rounded-full shrink-0" 
                          style={{ backgroundColor: catColor }} 
                        />
                        <span className="truncate">{cat}</span>
                        {stats.count > 0 && (
                          <span className={`px-1.5 py-0.2 rounded-full text-[10px] font-mono ${
                            isSelected ? 'bg-slate-700 text-white' : 'bg-amber-50 text-amber-900 border border-amber-200'
                          }`}>
                            {stats.count}
                          </span>
                        )}
                        {stats.totalCost > 0 && (
                          <span className={`text-[10px] font-mono font-normal hidden sm:inline ${
                            isSelected ? 'text-amber-300' : 'text-slate-500'
                          }`}>
                            ({formatCurrency(stats.totalCost, currency)})
                          </span>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            <div className="flex relative">
              <div 
                ref={tableScrollRef}
                className={`overflow-x-auto overflow-y-auto ${
                  tableExpanded ? 'max-h-none' : 'max-h-[380px] sm:max-h-[460px]'
                } flex-1 touch-pan-x touch-pan-y custom-scrollbar material-table-scroll relative`}
              >
                {itemList.length === 0 ? (
                  <div className="text-center py-10 px-4 space-y-3">
                    <Package size={32} className="mx-auto text-slate-300 stroke-1" />
                    <p className="text-slate-400 text-xs font-medium">لا توجد مواد مضافة في هذا الكشف حتى الآن</p>
                    {!readOnly && (
                      <div className="space-y-2 pt-1">
                        <p className="text-[11px] text-slate-400">أدخل اسم الصنف والكمية وسعر الوحدة من النموذج أعلاه</p>
                        <button
                          type="button"
                          onClick={() => setIsExcelModalOpen(true)}
                          className="inline-flex items-center gap-1.5 text-xs font-bold bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 px-4 py-2 rounded-xl shadow-2xs transition-colors cursor-pointer"
                        >
                          <FileSpreadsheet size={15} className="text-emerald-600" />
                          <span>أو استيراد الأصناف مباشرة من ملف إكسل</span>
                        </button>
                      </div>
                    )}
                  </div>
                ) : displayedItems.length === 0 ? (
                  <div className="text-center py-8 px-4 space-y-2">
                    <Tag size={28} className="mx-auto text-slate-300" />
                    <p className="text-slate-500 text-xs font-bold">لا توجد أصناف مقيدة تحت فئة "{activeCategoryTab}"</p>
                    <p className="text-slate-400 text-[11px]">يمكنك إضافة صنف جديد بهذه الفئة أو النقر على "كافة الفئات" لعرض جميع الأصناف</p>
                    <button
                      type="button"
                      onClick={() => setActiveCategoryTab('all')}
                      className="text-xs font-bold text-amber-700 bg-amber-50 hover:bg-amber-100 px-3 py-1.5 rounded-lg border border-amber-200 transition-colors cursor-pointer"
                    >
                      عرض كافة الفئات ({itemList.length})
                    </button>
                  </div>
                ) : (
                  <table className="w-full text-right text-xs border-collapse">
                    <thead className="sticky top-0 z-10 bg-slate-100/95 backdrop-blur-xs shadow-2xs">
                      <tr className="bg-slate-100/95 text-slate-700 font-bold border-b border-slate-200 text-[11px]">
                        <th className="p-2.5 text-center w-10">#</th>
                        <th className="p-2.5 min-w-[140px]">الصنف / المادة</th>
                        <th className="p-2.5 text-center w-16">الوحدة</th>
                        <th className="p-2.5 text-center w-20">الكمية</th>
                        <th className="p-2.5 text-center w-24">سعر الوحدة</th>
                        <th className="p-2.5 text-center w-28 text-amber-900 bg-amber-50/50">الفئة</th>
                        <th className="p-2.5 text-center w-28 text-amber-700">الإجمالي</th>
                        <th className="p-2.5 min-w-[120px]">الملاحظات</th>
                        {!readOnly && (
                          <th className="p-2.5 text-center w-20">العمليات</th>
                        )}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {displayedItems.map((it, index) => (
                        <tr 
                          key={it.id || index}
                          className={`hover:bg-amber-50/30 transition-colors ${
                            editingItemId === it.id ? 'bg-amber-50/60 font-semibold' : ''
                          }`}
                        >
                          <td className="p-2.5 text-center text-slate-400 font-mono font-bold">
                            {index + 1}
                          </td>
                          <td className="p-2.5 font-bold text-slate-800">
                            {it.itemName}
                          </td>
                          <td className="p-2.5 text-center text-slate-600 font-medium">
                            {it.unit || '-'}
                          </td>
                          <td className="p-2.5 text-center font-mono font-bold text-slate-700">
                            {it.quantity}
                          </td>
                          <td className="p-2.5 text-center font-mono text-slate-700">
                            {formatCurrency(it.unitPrice, currency)}
                          </td>
                          <td className="p-2.5 text-center">
                            <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-amber-50 text-amber-900 border border-amber-200/80 whitespace-nowrap shadow-2xs">
                              <span 
                                className="w-2 h-2 rounded-full shrink-0" 
                                style={{ backgroundColor: getCategoryColor(it.category || '') }} 
                              />
                              <span>{it.category || 'غير محدد'}</span>
                            </span>
                          </td>
                          <td className="p-2.5 text-center font-mono font-extrabold text-amber-700">
                            {formatCurrency(it.total, currency)}
                          </td>
                          <td className="p-2.5 text-slate-500 max-w-xs truncate" title={it.notes}>
                            {it.notes || '-'}
                          </td>
                          {!readOnly && (
                            <td className="p-2.5 text-center">
                              <div className="flex items-center justify-center gap-1">
                                <button
                                  type="button"
                                  onClick={() => handleOpenEditModal(it)}
                                  className="p-1.5 text-slate-400 hover:text-sky-600 hover:bg-sky-50 rounded-lg transition-colors cursor-pointer"
                                  title="تعديل بيانات الصنف"
                                >
                                  <Pencil size={15} />
                                </button>
                                <button
                                  type="button"
                                  onClick={() => handleRequestDelete(it)}
                                  className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                                  title="حذف الصنف مع رسالة تأكيد"
                                >
                                  <Trash2 size={15} />
                                </button>
                              </div>
                            </td>
                          )}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
              </div>

              {/* Dedicated Draggable Scroll Track for the Table when scrollable and not expanded */}
              {!tableExpanded && displayedItems.length > 4 && (
                <DraggableScrollIndicator
                  targetRef={tableScrollRef}
                  title="مؤشر السحب والتنقل في جدول الأصناف"
                  variant="amber"
                  isCompact={true}
                  className="border-r border-slate-200/80 bg-slate-50/90 dark:bg-slate-800/90 py-1"
                />
              )}
            </div>

            {/* Subtotal Summary Bar */}
            {itemList.length > 0 && (
              <div className="p-3 bg-slate-50 border-t border-slate-200 flex items-center justify-between gap-3 flex-wrap">
                <div className="flex items-center gap-2 sm:gap-4 flex-wrap">
                  <span className="text-xs font-bold text-slate-600">
                    عدد الأصناف: <strong className="text-slate-800 font-mono">{itemList.length}</strong>
                  </span>
                  <span className="text-xs text-slate-600">
                    إجمالي الأصناف: <strong className="text-slate-800 font-mono font-bold">{formatCurrency(itemsSubtotal, currency)}</strong>
                  </span>
                  {parsedDiscount > 0 ? (
                    <span className="text-xs text-rose-700 bg-rose-50 border border-rose-200/80 px-2 py-0.5 rounded-lg flex items-center gap-1 font-bold">
                      <Tag size={12} className="text-rose-600" />
                      <span>الخصم / التخفيض:</span>
                      <strong className="font-mono">-{formatCurrency(parsedDiscount, currency)}</strong>
                    </span>
                  ) : !readOnly && (
                    <button
                      type="button"
                      onClick={() => {
                        discountInputRef.current?.focus();
                        discountInputRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
                      }}
                      className="text-[11px] font-bold text-amber-700 hover:text-amber-900 bg-amber-50 hover:bg-amber-100 border border-amber-200 px-2 py-0.5 rounded-md transition-colors cursor-pointer flex items-center gap-1"
                    >
                      <Plus size={12} />
                      <span>إضافة خصم / تخفيض</span>
                    </button>
                  )}
                </div>

                <div className="flex items-center gap-2 flex-wrap">
                  <div className="flex flex-col items-end">
                    <span className="text-xs font-bold text-slate-700 flex items-center gap-1">
                      <span>الإجمالي النهائي لكشف المواد{parsedDiscount > 0 ? ' (الصافي)' : ''}:</span>
                    </span>
                    {parsedDiscount > 0 && (
                      <span className="text-[10px] text-rose-600 font-medium">
                        (مستبعد منه الخصم {formatCurrency(parsedDiscount, currency)})
                      </span>
                    )}
                  </div>
                  <span className="bg-amber-100/90 text-amber-950 border border-amber-300 px-3.5 py-1 rounded-xl text-sm sm:text-base font-black font-mono shadow-2xs">
                    {formatCurrency(grandTotal, currency)}
                  </span>
                </div>
              </div>
            )}
          </div>

          {/* Amount In Words for Grand Total */}
          {grandTotal > 0 && (
            <div className="bg-white p-3 rounded-xl border border-slate-200 text-xs space-y-1">
              <div className="flex items-center justify-between gap-2 flex-wrap text-slate-600">
                <span className="font-bold">المبلغ كتابةً لكشف المواد:</span>
                {parsedDiscount > 0 && (
                  <span className="text-[11px] text-rose-700 bg-rose-50 border border-rose-200 px-2 py-0.5 rounded-md font-medium">
                    (الصافي النهائي بعد استبعاد خصم بقيمة {formatCurrency(parsedDiscount, currency)})
                  </span>
                )}
              </div>
              <AmountInWords amount={grandTotal} currency={currency} />
            </div>
          )}

          </div>

          {/* Prominent Draggable Scroll & Navigation Rail for the Window */}
          <DraggableScrollIndicator
            targetRef={bodyScrollRef}
            title="مؤشر السحب والتنقل في نافذة كشف المواد والأصناف"
            variant="amber"
            showJumpToSection={itemList.length > 0}
            onJumpToSection={scrollToItemsTable}
            sectionJumpTitle="الانتقال إلى جدول الأصناف"
            className="border-r border-slate-200/90 bg-slate-100/70 dark:bg-slate-800/70 py-2 shadow-xs"
          />
        </div>

        {/* Fixed Footer */}
        <div className="p-3.5 sm:p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between gap-3 shrink-0 flex-wrap">
          <button 
            type="button" 
            onClick={onClose}
            className="bg-white border border-slate-200 hover:bg-slate-100 text-slate-700 font-bold text-xs py-2 px-4 rounded-xl transition-colors cursor-pointer"
          >
            {readOnly ? 'إغلاق' : 'إلغاء'}
          </button>

          {!readOnly && (
            <div className="flex items-center gap-2">
              {onApplyTotalToAmount && grandTotal > 0 && (
                <button
                  type="button"
                  onClick={() => {
                    onApplyTotalToAmount(grandTotal);
                    handleSaveModal();
                  }}
                  className="bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 font-bold text-xs py-2 px-3 rounded-xl transition-colors cursor-pointer flex items-center gap-1 shadow-xs"
                  title="حفظ الكشف ومطابقة مبلغ الحركة مع إجمالي المواد"
                >
                  <Check size={14} />
                  <span>تطبيق الإجمالي والحفظ ({formatCurrency(grandTotal, currency)})</span>
                </button>
              )}
              <button 
                type="button" 
                onClick={handleSaveModal}
                className="bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs py-2 px-5 rounded-xl shadow-xs transition-colors cursor-pointer flex items-center gap-1.5"
              >
                <Check size={15} />
                <span>حفظ كشف المواد</span>
              </button>
            </div>
          )}
        </div>

        {/* Floating Quick Return to Top Button */}
        {showScrollTop && (
          <button
            type="button"
            onClick={scrollToTop}
            className="absolute bottom-16 sm:bottom-20 left-4 z-30 bg-slate-900/95 hover:bg-black text-white text-xs font-bold px-3.5 py-2.5 rounded-xl shadow-xl border border-slate-700/80 flex items-center gap-1.5 transition-all duration-200 animate-fade-in hover:scale-105 active:scale-95 cursor-pointer backdrop-blur-xs"
            title="العودة السريعة لأعلى الكشف"
          >
            <ArrowUp size={16} className="text-amber-400" />
            <span>العودة للأعلى</span>
          </button>
        )}

      </div>

      {/* Full Image Preview Lightbox Modal */}
      {isImageModalOpen && invoiceImageState && (
        <div 
          className="fixed inset-0 z-[130] flex items-center justify-center bg-slate-950/80 backdrop-blur-xs p-3 sm:p-6 animate-fade-in"
          onClick={() => setIsImageModalOpen(false)}
        >
          <div 
            className="bg-slate-900 rounded-2xl border border-slate-700 shadow-2xl max-w-3xl w-full overflow-hidden flex flex-col max-h-[92vh] animate-scale-up"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-3 bg-slate-900 border-b border-slate-800 text-white flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2">
                <Receipt size={18} className="text-amber-400" />
                <span className="font-bold text-xs sm:text-sm">
                  صورة الفاتورة {invoiceNumberState ? `(#${invoiceNumberState})` : ''}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <a
                  href={invoiceImageState}
                  download={`فاتورة_${invoiceNumberState || 'مورد'}_${Date.now()}.jpg`}
                  className="p-1.5 text-slate-300 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
                  title="تحميل وحفظ الصورة"
                >
                  <Download size={18} />
                </a>
                <button
                  type="button"
                  onClick={() => setIsImageModalOpen(false)}
                  className="p-1.5 text-slate-300 hover:text-white rounded-lg hover:bg-slate-800 cursor-pointer transition-colors"
                  title="إغلاق المعاينة"
                >
                  <X size={20} />
                </button>
              </div>
            </div>

            <div className="p-2 sm:p-4 overflow-auto flex-1 flex items-center justify-center bg-slate-950 min-h-[300px]">
              <img 
                src={invoiceImageState} 
                alt="صورة الفاتورة المرفقة" 
                className="max-w-full max-h-[75vh] object-contain rounded-lg shadow-lg"
              />
            </div>

            <div className="p-2.5 bg-slate-900 border-t border-slate-800 text-slate-400 text-xs flex items-center justify-between px-4">
              <span>{transactionInfo?.supplierName ? `المورد: ${transactionInfo.supplierName}` : 'مستند الفاتورة المرفق'}</span>
              <button
                type="button"
                onClick={() => setIsImageModalOpen(false)}
                className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-white font-bold rounded-lg text-xs transition-colors cursor-pointer"
              >
                إغلاق المعاينة ✕
              </button>
            </div>
          </div>
        </div>
      )}
      {/* Excel Import & Column Mapping Modal */}
      {isExcelModalOpen && (
        <SupplierMaterialExcelModal
          isOpen={isExcelModalOpen}
          onClose={() => setIsExcelModalOpen(false)}
          onImport={handleExcelImport}
          currency={currency}
          existingCount={itemList.length}
        />
      )}

      {/* Edit Item Modal */}
      {editModalItem && (
        <div 
          className="fixed inset-0 z-[130] flex items-center justify-center bg-slate-950/70 backdrop-blur-xs p-3 sm:p-4 overflow-hidden dir-rtl text-right animate-fade-in"
          onClick={() => setEditModalItem(null)}
          id="supplier-material-edit-modal-backdrop"
        >
          <div 
            className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-lg w-full overflow-hidden flex flex-col max-h-[92vh] animate-scale-up"
            onClick={(e) => e.stopPropagation()}
            id="supplier-material-edit-modal"
          >
            {/* Modal Header */}
            <div className="p-3.5 sm:p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/80">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-sky-100 text-sky-700 flex items-center justify-center font-bold">
                  <Pencil size={16} />
                </div>
                <div>
                  <h3 className="font-bold text-slate-800 text-sm">
                    تعديل بيانات الصنف
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    تعديل الاسم والكمية وسعر الوحدة وفئة الصنف
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setEditModalItem(null)}
                className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-200/60 transition-colors cursor-pointer"
                title="إغلاق"
              >
                <X size={18} />
              </button>
            </div>

            {/* Modal Form */}
            <form onSubmit={handleSaveEditModal} className="p-4 overflow-y-auto space-y-3.5 modal-scroll-area custom-scrollbar flex-1 min-h-0 touch-pan-y overscroll-contain">
              {editModalError && (
                <div className="p-2.5 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-700 font-bold flex items-center gap-1.5">
                  <AlertCircle size={15} />
                  <span>{editModalError}</span>
                </div>
              )}

              {/* Item Name */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700">
                  الصنف / المادة <span className="text-rose-500">*</span>
                </label>
                <input 
                  type="text"
                  value={editModalItem.itemName}
                  onChange={(e) => setEditModalItem({ ...editModalItem, itemName: e.target.value })}
                  className="w-full h-9 px-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:border-sky-500 focus:outline-hidden"
                  required
                />
              </div>

              {/* Quantity, Unit, Price, Total */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                {/* Quantity */}
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700">
                    الكمية <span className="text-rose-500">*</span>
                  </label>
                  <input 
                    type="number"
                    step="any"
                    value={editModalItem.quantity || ''}
                    onChange={(e) => setEditModalItem({ ...editModalItem, quantity: parseFloat(e.target.value) || 0 })}
                    className="w-full h-9 px-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono font-bold text-slate-800 text-left focus:border-sky-500 focus:outline-hidden"
                    required
                  />
                </div>

                {/* Unit */}
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700">الوحدة</label>
                  <input 
                    type="text"
                    value={editModalItem.unit || ''}
                    onChange={(e) => setEditModalItem({ ...editModalItem, unit: e.target.value })}
                    className="w-full h-9 px-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:border-sky-500 focus:outline-hidden"
                    list="unit-suggestions-edit"
                  />
                  <datalist id="unit-suggestions-edit">
                    {COMMON_UNITS.map(u => (
                      <option key={u} value={u} />
                    ))}
                  </datalist>
                </div>

                {/* Unit Price */}
                <div className="space-y-1 col-span-2 sm:col-span-1">
                  <label className="text-xs font-bold text-slate-700">
                    سعر الوحدة <span className="text-rose-500">*</span>
                  </label>
                  <input 
                    type="number"
                    step="any"
                    value={editModalItem.unitPrice || ''}
                    onChange={(e) => setEditModalItem({ ...editModalItem, unitPrice: parseFloat(e.target.value) || 0 })}
                    className="w-full h-9 px-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono font-bold text-slate-800 text-left focus:border-sky-500 focus:outline-hidden"
                    required
                  />
                </div>
              </div>

              {/* Calculated Total Badge */}
              <div className="p-2.5 bg-amber-50 border border-amber-200 rounded-xl flex items-center justify-between">
                <span className="text-xs font-bold text-amber-800">إجمالي الصنف:</span>
                <span className="text-sm font-extrabold text-amber-900 font-mono">
                  {formatCurrency(Math.round(((editModalItem.quantity || 0) * (editModalItem.unitPrice || 0)) * 100) / 100, currency)}
                </span>
              </div>

              {/* Category Selection Grid */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-slate-700">فئة الصنف</label>
                  <button
                    type="button"
                    onClick={() => setShowCategoryManagerModal(true)}
                    className="text-[11px] font-bold text-amber-800 hover:text-amber-900 flex items-center gap-1.5 bg-amber-50 hover:bg-amber-100/90 px-2 py-0.5 rounded-lg border border-amber-300/80 transition-all cursor-pointer"
                    title="إدارة فئات الأصناف والمواد (إضافة - تعديل - حذف)"
                  >
                    <FolderCog size={12} className="text-amber-700 stroke-[2.2]" />
                    <span>إدارة الفئة</span>
                  </button>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5 max-h-36 overflow-y-auto p-1 bg-slate-50 rounded-xl border border-slate-200 custom-scrollbar">
                  {categories.map(cat => {
                    const isSelected = editModalItem.category === cat;
                    const catColor = getCategoryColor(cat);
                    return (
                      <button
                        key={cat}
                        type="button"
                        onClick={() => setEditModalItem({ ...editModalItem, category: cat })}
                        className={`p-1.5 rounded-lg text-[11px] font-bold border text-right transition-colors cursor-pointer flex items-center justify-between ${
                          isSelected 
                            ? 'bg-amber-600 text-white border-amber-600' 
                            : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                        }`}
                      >
                        <div className="flex items-center gap-1.5 min-w-0">
                          <span 
                            className="w-2 h-2 rounded-full shrink-0" 
                            style={{ backgroundColor: isSelected ? '#ffffff' : catColor }} 
                          />
                          <span className="truncate">{cat}</span>
                        </div>
                        {isSelected && <Check size={12} className="shrink-0 stroke-[3]" />}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Notes */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700">الملاحظات (اختياري)</label>
                <input 
                  type="text"
                  value={editModalItem.notes || ''}
                  onChange={(e) => setEditModalItem({ ...editModalItem, notes: e.target.value })}
                  placeholder="ملاحظات الصنف..."
                  className="w-full h-9 px-3 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:border-sky-500 focus:outline-hidden"
                />
              </div>

              {/* Modal Actions */}
              <div className="pt-2 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setEditModalItem(null)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition-colors cursor-pointer"
                >
                  تراجع عن التعديل
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-sky-600 hover:bg-sky-700 text-white text-xs font-bold rounded-xl shadow-xs transition-colors cursor-pointer flex items-center gap-1.5"
                >
                  <Check size={14} />
                  <span>حفظ التعديلات</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {itemToDelete && (
        <div 
          className="fixed inset-0 z-[130] flex items-center justify-center bg-slate-950/70 backdrop-blur-xs p-3 sm:p-4 overflow-hidden dir-rtl text-right animate-fade-in"
          onClick={() => setItemToDelete(null)}
          id="supplier-material-delete-modal-backdrop"
        >
          <div 
            className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-md w-full overflow-hidden flex flex-col animate-scale-up"
            onClick={(e) => e.stopPropagation()}
            id="supplier-material-delete-modal"
          >
            {/* Header */}
            <div className="p-4 bg-rose-50/70 border-b border-rose-100 flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-rose-100 text-rose-600 flex items-center justify-center shrink-0">
                <Trash2 size={20} />
              </div>
              <div>
                <h3 className="font-bold text-rose-950 text-sm">
                  تأكيد حذف الصنف من الكشف
                </h3>
                <p className="text-xs text-rose-700">
                  هل أنت متأكد من رغبتك في حذف هذا الصنف نهائياً؟
                </p>
              </div>
            </div>

            {/* Item Details Card */}
            <div className="p-4 space-y-3">
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-2 text-xs">
                <div className="flex justify-between items-center pb-2 border-b border-slate-200/80">
                  <span className="text-slate-500">اسم الصنف:</span>
                  <span className="font-bold text-slate-800 text-sm">{itemToDelete.itemName}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-500">الكمية والوحدة:</span>
                  <span className="font-bold text-slate-700 font-mono">{itemToDelete.quantity} {itemToDelete.unit}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-500">سعر الوحدة:</span>
                  <span className="font-bold text-slate-700 font-mono">{formatCurrency(itemToDelete.unitPrice, currency)}</span>
                </div>
                <div className="flex justify-between items-center pt-2 border-t border-slate-200/80">
                  <span className="font-bold text-amber-900">إجمالي المبلغ:</span>
                  <span className="font-extrabold text-amber-700 text-sm font-mono">{formatCurrency(itemToDelete.total, currency)}</span>
                </div>
              </div>
            </div>

            {/* Actions: Cancel / Undo vs Confirm */}
            <div className="p-3.5 bg-slate-50 border-t border-slate-100 flex items-center justify-end gap-2.5">
              <button
                type="button"
                onClick={() => setItemToDelete(null)}
                className="px-4 py-2 bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 text-xs font-bold rounded-xl transition-colors cursor-pointer"
              >
                تراجع عن الحذف
              </button>
              <button
                type="button"
                onClick={handleConfirmDelete}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold rounded-xl shadow-xs transition-colors cursor-pointer flex items-center gap-1.5"
              >
                <Trash2 size={14} />
                <span>تأكيد الحذف</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Undo Toast Notification */}
      {lastDeletedItem && (
        <div className="fixed bottom-5 left-1/2 -translate-x-1/2 z-[140] bg-slate-900 text-white px-4 py-3 rounded-2xl shadow-2xl border border-slate-700 flex items-center gap-3 animate-fade-in text-xs max-w-sm w-full mx-4">
          <div className="flex-1 truncate">
            <span>تم حذف: </span>
            <strong className="text-amber-400">{lastDeletedItem.item.itemName}</strong>
          </div>
          <button
            type="button"
            onClick={handleUndoDelete}
            className="bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold px-3 py-1.5 rounded-xl text-xs transition-colors cursor-pointer flex items-center gap-1 shrink-0"
          >
            <Undo2 size={13} />
            <span>تراجع عن الحذف</span>
          </button>
          <button
            type="button"
            onClick={() => setLastDeletedItem(null)}
            className="text-slate-400 hover:text-white p-1 cursor-pointer"
            title="إغلاق"
          >
            <X size={14} />
          </button>
        </div>
      )}

      {/* Category Success Toast */}
      {categorySuccessToast && (
        <div className="fixed bottom-5 left-1/2 -translate-x-1/2 z-[140] bg-emerald-950 text-white px-4 py-3 rounded-2xl shadow-2xl border border-emerald-600/80 flex items-center gap-3 animate-fade-in text-xs max-w-md w-full mx-4">
          <div className="p-1 bg-emerald-500 text-white rounded-lg shrink-0">
            <Check size={14} className="stroke-[3]" />
          </div>
          <div className="flex-1 font-bold text-emerald-100">
            {categorySuccessToast}
          </div>
          <button
            type="button"
            onClick={() => setCategorySuccessToast('')}
            className="text-emerald-300 hover:text-white p-1 cursor-pointer"
            title="إغلاق"
          >
            <X size={14} />
          </button>
        </div>
      )}

      {/* Category Manager Modal for Supplier Material Categories */}
      <CategoryManagerModal
        isOpen={showCategoryManagerModal}
        onClose={() => setShowCategoryManagerModal(false)}
        title="إدارة فئات الأصناف والمواد الموردة"
        subtitle="إضافة وتعديل وحذف فئات المواد والأصناف وتحديث كافة الكشوفات والتقارير المرتبطة"
        categories={categories.map(cat => ({
          id: cat,
          name: cat,
          color: getCategoryColor(cat),
          isDefault: (SUPPLIER_MATERIAL_CATEGORIES as readonly string[]).includes(cat),
          count: itemList.filter(item => item.category === cat).length
        }))}
        showColorPicker={true}
        colorPalette={DYNAMIC_PALETTE}
        entityUnitLabel="صنف"
        onAddCategory={(name, color) => {
          const res = addCategory(name, color);
          if (res.success && res.category) {
            setCategory(res.category);
            if (editModalItem) {
              setEditModalItem(prev => prev ? { ...prev, category: res.category } : null);
            }
          }
          return res;
        }}
        onEditCategory={(item, newName, color) => {
          const res = editCategory(item.name, newName, color);
          if (res.success) {
            if (category === item.name) {
              setCategory(newName);
            }
            if (editModalItem && editModalItem.category === item.name) {
              setEditModalItem(prev => prev ? { ...prev, category: newName } : null);
            }
            setItemList(prev => prev.map(m => m.category === item.name ? { ...m, category: newName } : m));
          }
          return res;
        }}
        onDeleteCategory={(item) => {
          const res = deleteCategory(item.name);
          if (res.success) {
            if (category === item.name) {
              const remaining = categories.filter(c => c !== item.name);
              setCategory(remaining[0] || '');
            }
            if (editModalItem && editModalItem.category === item.name) {
              const remaining = categories.filter(c => c !== item.name);
              setEditModalItem(prev => prev ? { ...prev, category: remaining[0] || '' } : null);
            }
          }
          return res;
        }}
        onResetDefaults={resetDefaults}
      />
    </div>
  );
}
