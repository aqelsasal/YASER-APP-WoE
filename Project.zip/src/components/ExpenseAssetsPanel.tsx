/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { 
  Building2, 
  Search, 
  PlusCircle, 
  Calendar, 
  CheckCircle2, 
  Filter, 
  Check, 
  Boxes, 
  Truck, 
  ArrowUpRight, 
  MapPin, 
  User, 
  Activity, 
  Info, 
  Zap, 
  Layers, 
  FileSpreadsheet, 
  FileText, 
  FolderGit2, 
  ArrowRight, 
  ExternalLink,
  X
} from 'lucide-react';
import { 
  CompanyAsset, 
  Project, 
  Expense, 
  formatCurrency, 
  formatDateArabic, 
  exportToXLSX, 
  printPDF 
} from '../types';

export interface ExpenseAssetItem {
  expenseId: string;
  projectId: string;
  projectName: string;
  date: string;
  amount: number;
  currency: 'YER' | 'SAR' | 'USD';
  description: string;
  notes: string;
  recipientName: string;
  recipientType: string;
  category: string;
  categories: string[];
  createdBy: string;
  isAlreadyAdded: boolean;
  matchedAssetId?: string;
  matchedAsset?: CompanyAsset;
}

interface ExpenseAssetsPanelProps {
  projects?: Project[];
  expenses?: Expense[];
  assets: CompanyAsset[];
  onAddAsset: (asset: Omit<CompanyAsset, 'id' | 'movements' | 'createdAt' | 'updatedAt'>) => void;
  onOpenAddCustomModal: (item: ExpenseAssetItem) => void;
  onNavigateToAsset: (assetId: string) => void;
  currentUser?: string;
  sharedRole?: string;
}

export const ExpenseAssetsPanel: React.FC<ExpenseAssetsPanelProps> = ({
  projects = [],
  expenses = [],
  assets = [],
  onAddAsset,
  onOpenAddCustomModal,
  onNavigateToAsset,
  currentUser = 'المدير',
  sharedRole
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [projectFilter, setProjectFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | 'unadded' | 'added'>('all');
  const [currencyFilter, setCurrencyFilter] = useState<string>('all');
  const [sortOrder, setSortOrder] = useState<'newest' | 'oldest' | 'highest_amount'>('newest');

  // =========================================================================
  // 1. EXTRACT ALL EXPENSES CATEGORIZED UNDER "أصول مضافة"
  // =========================================================================
  const allExpenseAssets = useMemo(() => {
    const list: ExpenseAssetItem[] = [];
    const seenExpenseIds = new Set<string>();

    const checkAndPushExpense = (exp: Expense, projId: string, projName: string) => {
      if (!exp || !exp.id || seenExpenseIds.has(exp.id)) return;

      const cats = (exp.categories && exp.categories.length > 0)
        ? exp.categories
        : (exp.category ? [exp.category] : []);

      const isAddedAsset = cats.some(c => {
        const clean = (c || '').trim().toLowerCase();
        return clean.includes('اصول مضافة') || 
               clean.includes('أصول مضافة') || 
               clean.includes('اصول مضافه') || 
               clean.includes('أصول مضافه') ||
               clean === 'اصول مضافة' ||
               clean === 'أصول مضافة' ||
               clean === 'أصول' ||
               clean === 'اصول';
      });

      if (isAddedAsset) {
        seenExpenseIds.add(exp.id);
        const expCurr = (exp.currency as 'YER' | 'SAR' | 'USD') || 'YER';

        // Check matching with registered company assets
        const matched = assets.find(a => 
          a.sourceExpenseId === exp.id ||
          (a.notes && a.notes.includes(exp.id)) ||
          (a.name.trim() === exp.description.trim() && a.purchasePrice === exp.amount && a.projectId === projId)
        );

        list.push({
          expenseId: exp.id,
          projectId: projId,
          projectName: projName,
          date: exp.date || new Date().toISOString().split('T')[0],
          amount: Number(exp.amount) || 0,
          currency: expCurr,
          description: exp.description || 'بند أصل غير مسمى',
          notes: exp.notes || '',
          recipientName: exp.recipientName || '',
          recipientType: exp.recipientType || 'none',
          category: exp.category || 'اصول مضافة',
          categories: cats,
          createdBy: exp.createdBy || 'مسؤول النفقات',
          isAlreadyAdded: !!matched,
          matchedAssetId: matched?.id,
          matchedAsset: matched
        });
      }
    };

    // Scan all projects
    projects.forEach(project => {
      const projExpenses = project.expenses || [];
      projExpenses.forEach(exp => {
        checkAndPushExpense(exp, project.id, project.name || 'مشروع بدون اسم');
      });
    });

    // Scan top-level expenses if any not captured in projects
    expenses.forEach(exp => {
      if (!seenExpenseIds.has(exp.id)) {
        checkAndPushExpense(exp, '', 'المصروفات العامة للمشروع الحالي');
      }
    });

    return list;
  }, [projects, expenses, assets]);

  // =========================================================================
  // 2. FINANCIAL AND STATUS SUMMARIES
  // =========================================================================
  const summaries = useMemo(() => {
    let unaddedCount = 0;
    let addedCount = 0;
    const totals: Record<'YER' | 'SAR' | 'USD', number> = { YER: 0, SAR: 0, USD: 0 };

    allExpenseAssets.forEach(item => {
      if (item.isAlreadyAdded) {
        addedCount += 1;
      } else {
        unaddedCount += 1;
      }
      if (totals[item.currency] !== undefined) {
        totals[item.currency] += item.amount;
      }
    });

    return {
      totalCount: allExpenseAssets.length,
      unaddedCount,
      addedCount,
      totals
    };
  }, [allExpenseAssets]);

  // =========================================================================
  // 3. FILTER AND SORT LIST
  // =========================================================================
  const filteredList = useMemo(() => {
    return allExpenseAssets.filter(item => {
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const mDesc = item.description.toLowerCase().includes(q);
        const mProj = item.projectName.toLowerCase().includes(q);
        const mRecip = item.recipientName.toLowerCase().includes(q);
        const mNotes = item.notes.toLowerCase().includes(q);
        if (!mDesc && !mProj && !mRecip && !mNotes) return false;
      }

      if (projectFilter !== 'all' && item.projectId !== projectFilter) {
        return false;
      }

      if (statusFilter === 'unadded' && item.isAlreadyAdded) {
        return false;
      }
      if (statusFilter === 'added' && !item.isAlreadyAdded) {
        return false;
      }

      if (currencyFilter !== 'all' && item.currency !== currencyFilter) {
        return false;
      }

      return true;
    }).sort((a, b) => {
      if (sortOrder === 'newest') {
        return new Date(b.date).getTime() - new Date(a.date).getTime();
      }
      if (sortOrder === 'oldest') {
        return new Date(a.date).getTime() - new Date(b.date).getTime();
      }
      if (sortOrder === 'highest_amount') {
        return b.amount - a.amount;
      }
      return 0;
    });
  }, [allExpenseAssets, searchQuery, projectFilter, statusFilter, currencyFilter, sortOrder]);

  // =========================================================================
  // 4. INSTANT ADD SINGLE ASSET
  // =========================================================================
  const handleInstantAdd = (item: ExpenseAssetItem) => {
    const assetData: Omit<CompanyAsset, 'id' | 'movements' | 'createdAt' | 'updatedAt'> = {
      name: item.description,
      category: 'tools_equipment',
      purchaseDate: item.date || new Date().toISOString().split('T')[0],
      quantity: 1,
      unit: 'عدد',
      purchasePrice: item.amount,
      currency: item.currency,
      supplierName: item.recipientName || undefined,
      currentLocation: item.projectName ? `مشروع ${item.projectName}` : 'المخزن العام للشركة',
      projectId: item.projectId || undefined,
      condition: 'very_good',
      custodyPerson: '',
      notes: `${item.notes ? item.notes + ' - ' : ''}(أصل مضاف من نفقات مشروع: ${item.projectName}) [كود: ${item.expenseId}]`,
      sourceExpenseId: item.expenseId,
      sourceProjectId: item.projectId || undefined,
      createdBy: currentUser
    };

    onAddAsset(assetData);
    if (typeof window !== 'undefined' && (window as any).showToast) {
      (window as any).showToast(`✅ تمت إضافة "${item.description}" بنجاح إلى سجل أصول الشركة!`);
    }
  };

  // =========================================================================
  // 5. BATCH ADD ALL UNADDED ASSETS
  // =========================================================================
  const handleAddAllUnadded = () => {
    const unaddedItems = filteredList.filter(i => !i.isAlreadyAdded);
    if (unaddedItems.length === 0) return;

    if (!confirm(`هل أنت متأكد من إضافة كافة العمليات غير المضافة (${unaddedItems.length} صنف/عملية) إلى سجل أصول الشركة؟`)) {
      return;
    }

    unaddedItems.forEach(item => {
      onAddAsset({
        name: item.description,
        category: 'tools_equipment',
        purchaseDate: item.date || new Date().toISOString().split('T')[0],
        quantity: 1,
        unit: 'عدد',
        purchasePrice: item.amount,
        currency: item.currency,
        supplierName: item.recipientName || undefined,
        currentLocation: item.projectName ? `مشروع ${item.projectName}` : 'المخزن العام للشركة',
        projectId: item.projectId || undefined,
        condition: 'very_good',
        custodyPerson: '',
        notes: `${item.notes ? item.notes + ' - ' : ''}(أصل مضاف من نفقات مشروع: ${item.projectName}) [كود: ${item.expenseId}]`,
        sourceExpenseId: item.expenseId,
        sourceProjectId: item.projectId || undefined,
        createdBy: currentUser
      });
    });

    if (typeof window !== 'undefined' && (window as any).showToast) {
      (window as any).showToast(`✅ تم نسخ وإضافة ${unaddedItems.length} أصل إلى سجل الأصول بنجاح!`);
    }
  };

  // =========================================================================
  // 6. EXPORT EXCEL
  // =========================================================================
  const handleExportExcel = () => {
    const headers = [
      'المشروع المصدر',
      'التاريخ',
      'اسم وبيان الأصل / الصنف',
      'المبلغ / التكلفة',
      'العملة',
      'المورد / المستلم',
      'الملاحظات',
      'حالة الإضافة للأصول',
      'معرف العملية'
    ];

    const rows = filteredList.map(item => [
      item.projectName,
      item.date,
      item.description,
      item.amount,
      item.currency,
      item.recipientName || '-',
      item.notes || '-',
      item.isAlreadyAdded ? 'تمت الإضافة لسجل الأصول' : 'جديد / غير مضاف',
      item.expenseId
    ]);

    exportToXLSX('اصول_النفقات_اليومية_المضافة', headers, rows, 'أصول_النفقات');
  };

  // =========================================================================
  // 7. PRINT PDF
  // =========================================================================
  const handlePrintPDF = () => {
    const rowsHtml = filteredList.map((item, idx) => {
      const statusBadge = item.isAlreadyAdded
        ? '<span style="color: #059669; font-weight: bold;">✓ مضاف للأصول</span>'
        : '<span style="color: #d97706; font-weight: bold;">قيد الإضافة</span>';

      return `
        <tr>
          <td style="text-align: center; width: 4%;">${idx + 1}</td>
          <td style="width: 14%; text-align: center;">${item.projectName}</td>
          <td style="width: 8%; text-align: center;">${formatDateArabic(item.date)}</td>
          <td class="col-statement" style="width: 32%;"><strong>${item.description}</strong></td>
          <td style="width: 12%; text-align: left; font-weight: bold; color: #0284c7;">${formatCurrency(item.amount, item.currency)}</td>
          <td style="width: 14%; text-align: center;">${item.recipientName || '-'}</td>
          <td style="width: 10%; text-align: center;">${statusBadge}</td>
          <td style="width: 6%; text-align: center; font-size: 10px; color: #64748b;">${item.notes || '-'}</td>
        </tr>
      `;
    }).join('');

    const htmlContent = `
      <div style="margin-bottom: 20px;">
        <h2 style="font-size: 16px; font-weight: bold; color: #0f172a; margin-bottom: 6px;">كشف عمليات فئة «أصول مضافة» في النفقات اليومية</h2>
        <p style="font-size: 12px; color: #475569; margin: 0;">تقرير تجميعي شامل لكافة المشتريات والأصناف المسجلة كأصول مضافة في نفقات المشاريع اليومية وحالة إدراجها في سجل أصول الشركة.</p>
      </div>

      <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; margin-bottom: 20px; text-align: center;">
        <div style="border: 1px solid #cbd5e1; padding: 8px; border-radius: 8px; background-color: #f8fafc;">
          <small style="color: #64748b; font-weight: bold;">إجمالي العمليات</small>
          <div style="font-size: 14px; font-weight: bold; color: #0f172a;">${summaries.totalCount} عملية</div>
        </div>
        <div style="border: 1px solid #cbd5e1; padding: 8px; border-radius: 8px; background-color: #f8fafc;">
          <small style="color: #64748b; font-weight: bold;">مجموع الريال اليمني</small>
          <div style="font-size: 14px; font-weight: bold; color: #059669;">${formatCurrency(summaries.totals.YER, 'YER')}</div>
        </div>
        <div style="border: 1px solid #cbd5e1; padding: 8px; border-radius: 8px; background-color: #f8fafc;">
          <small style="color: #64748b; font-weight: bold;">مجموع الريال السعودي</small>
          <div style="font-size: 14px; font-weight: bold; color: #0d9488;">${formatCurrency(summaries.totals.SAR, 'SAR')}</div>
        </div>
        <div style="border: 1px solid #cbd5e1; padding: 8px; border-radius: 8px; background-color: #f8fafc;">
          <small style="color: #64748b; font-weight: bold;">مجموع الدولار</small>
          <div style="font-size: 14px; font-weight: bold; color: #0284c7;">${formatCurrency(summaries.totals.USD, 'USD')}</div>
        </div>
      </div>

      <table>
        <thead>
          <tr>
            <th style="width: 4%;">#</th>
            <th style="width: 14%;">المشروع المصدر</th>
            <th style="width: 8%;">التاريخ</th>
            <th style="width: 32%;" class="col-statement">بيان الأصل / الصنف</th>
            <th style="width: 12%;">المبلغ</th>
            <th style="width: 14%;">المورد / المستلم</th>
            <th style="width: 10%;">الحالة</th>
            <th style="width: 6%;">ملاحظات</th>
          </tr>
        </thead>
        <tbody>
          ${rowsHtml || '<tr><td colspan="8" style="text-align: center; padding: 20px;">لا توجد عمليات مسجلة تحت فئة أصول مضافة</td></tr>'}
        </tbody>
      </table>
    `;

    printPDF('تقرير_أصول_النفقات_المضافة', htmlContent);
  };

  return (
    <div className="space-y-4 animate-fade-in">
      
      {/* ======================= INFORMATIONAL GUIDE BANNER ======================= */}
      <div className="bg-gradient-to-r from-amber-500/10 via-amber-500/5 to-transparent border border-amber-200/90 rounded-2xl p-3.5 sm:p-4 text-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-2xs">
        <div className="flex items-start gap-3">
          <div className="p-2 bg-amber-500 text-white rounded-xl shadow-xs shrink-0 mt-0.5 sm:mt-0">
            <Boxes size={20} />
          </div>
          <div className="space-y-0.5">
            <h4 className="text-xs sm:text-sm font-black text-amber-950 flex items-center gap-2">
              <span>عمليات فئة «أصول مضافة» في النفقات اليومية بكافة المشاريع</span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-200/80 text-amber-900 font-bold">
                تكامل النفقات والأصول
              </span>
            </h4>
            <p className="text-[11px] sm:text-xs text-slate-600 leading-relaxed font-medium">
              تُجمع هذه اللوحة كافة المشتريات والمصروفات المصنفة تحت فئة <strong className="text-amber-900 font-bold">«أصول مضافة»</strong> من سجل النفقات اليومية عبر جميع المشاريع، وتتيح لك بنقرة واحدة زر <strong className="text-amber-800 font-bold">«إضافة إلى الأصول»</strong> لإدراج نسخة منها في سجل ومخزون أصول الشركة الرسمي.
            </p>
          </div>
        </div>

        {/* Quick Action export buttons */}
        <div className="flex items-center gap-1.5 shrink-0 self-end sm:self-center">
          <button
            type="button"
            onClick={handleExportExcel}
            className="px-2.5 py-1.5 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-xl text-xs font-bold flex items-center gap-1 transition-all shadow-2xs cursor-pointer"
            title="تصدير إكسيل"
          >
            <FileSpreadsheet size={14} className="text-emerald-600" />
            <span className="hidden sm:inline">إكسيل</span>
          </button>
          <button
            type="button"
            onClick={handlePrintPDF}
            className="px-2.5 py-1.5 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-xl text-xs font-bold flex items-center gap-1 transition-all shadow-2xs cursor-pointer"
            title="طباعة تقرير PDF"
          >
            <FileText size={14} className="text-sky-600" />
            <span className="hidden sm:inline">طباعة PDF</span>
          </button>
        </div>
      </div>

      {/* ======================= KPIS & FINANCIAL METRICS ======================= */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5 sm:gap-3.5">
        
        {/* Total Expense Assets Count */}
        <div className="bg-white rounded-2xl p-3 sm:p-4 border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-xs font-bold">إجمالي عمليات أصول النفقات</span>
            <div className="p-1.5 bg-amber-50 text-amber-600 rounded-lg">
              <Layers size={17} />
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-xl sm:text-2xl font-black text-slate-900">{summaries.totalCount}</span>
            <span className="text-[11px] font-bold text-slate-500">عملية مسجلة</span>
          </div>
          <div className="flex items-center gap-2 mt-1.5 text-[10px] font-bold">
            <span className="text-emerald-700 bg-emerald-50 px-1.5 py-0.2 rounded-md">
              ✓ {summaries.addedCount} مضاف للأصول
            </span>
            {summaries.unaddedCount > 0 && (
              <span className="text-amber-800 bg-amber-50 px-1.5 py-0.2 rounded-md">
                ⚡ {summaries.unaddedCount} جديد غير مضاف
              </span>
            )}
          </div>
        </div>

        {/* Total YER */}
        <div className="bg-white rounded-2xl p-3 sm:p-4 border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-xs font-bold">قيمة الأصول (ريال يمني)</span>
            <div className="p-1.5 bg-emerald-50 text-emerald-600 rounded-lg">
              <Building2 size={17} />
            </div>
          </div>
          <div className="text-base sm:text-lg font-black text-emerald-700 truncate">
            {formatCurrency(summaries.totals.YER, 'YER')}
          </div>
          <span className="text-[10px] text-slate-400 font-bold block mt-0.5">
            إجمالي مشتريات الأصول بالريال اليمني
          </span>
        </div>

        {/* Total SAR */}
        <div className="bg-white rounded-2xl p-3 sm:p-4 border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-xs font-bold">قيمة الأصول (ريال سعودي)</span>
            <div className="p-1.5 bg-teal-50 text-teal-600 rounded-lg">
              <Building2 size={17} />
            </div>
          </div>
          <div className="text-base sm:text-lg font-black text-teal-700 truncate">
            {formatCurrency(summaries.totals.SAR, 'SAR')}
          </div>
          <span className="text-[10px] text-slate-400 font-bold block mt-0.5">
            إجمالي مشتريات الأصول بالسعودي
          </span>
        </div>

        {/* Total USD */}
        <div className="bg-white rounded-2xl p-3 sm:p-4 border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-xs font-bold">قيمة الأصول (دولار أمريكي)</span>
            <div className="p-1.5 bg-sky-50 text-sky-600 rounded-lg">
              <Building2 size={17} />
            </div>
          </div>
          <div className="text-base sm:text-lg font-black text-sky-700 truncate">
            {formatCurrency(summaries.totals.USD, 'USD')}
          </div>
          <span className="text-[10px] text-slate-400 font-bold block mt-0.5">
            إجمالي مشتريات الأصول بالدولار
          </span>
        </div>

      </div>

      {/* ======================= FILTER & SEARCH BAR ======================= */}
      <div className="bg-white rounded-2xl p-3 sm:p-4 border border-slate-200/90 shadow-xs space-y-3">
        <div className="flex flex-col sm:flex-row gap-2.5 sm:items-center justify-between">
          
          {/* Search Input */}
          <div className="relative flex-1">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="ابحث باسم الصنف / البيان، المشروع، المستلم، الملاحظات..."
              className="w-full pl-3 pr-9 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm text-slate-800 placeholder-slate-400 focus:outline-hidden focus:border-amber-500 focus:bg-white transition-all"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
              >
                <X size={14} />
              </button>
            )}
          </div>

          {/* Quick Status Tabs */}
          <div className="flex items-center gap-1 shrink-0 overflow-x-auto pb-1 sm:pb-0">
            <button
              type="button"
              onClick={() => setStatusFilter('all')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                statusFilter === 'all'
                  ? 'bg-amber-600 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              الكل ({allExpenseAssets.length})
            </button>
            <button
              type="button"
              onClick={() => setStatusFilter('unadded')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                statusFilter === 'unadded'
                  ? 'bg-amber-800 text-white shadow-xs'
                  : 'bg-amber-50 text-amber-800 hover:bg-amber-100'
              }`}
            >
              <span>غير مضافة للأصول</span>
              <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-amber-700 text-white">
                {summaries.unaddedCount}
              </span>
            </button>
            <button
              type="button"
              onClick={() => setStatusFilter('added')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                statusFilter === 'added'
                  ? 'bg-emerald-700 text-white shadow-xs'
                  : 'bg-emerald-50 text-emerald-800 hover:bg-emerald-100'
              }`}
            >
              <span>مضافة للأصول</span>
              <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-emerald-600 text-white">
                {summaries.addedCount}
              </span>
            </button>
          </div>

        </div>

        {/* Secondary Filters */}
        <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-100 text-xs font-bold text-slate-600">
          <div className="flex flex-wrap items-center gap-2">
            <div className="flex items-center gap-1 text-slate-400">
              <Filter size={14} />
              <span className="font-normal">تصفية:</span>
            </div>

            {/* Project Filter */}
            <select
              value={projectFilter}
              onChange={(e) => setProjectFilter(e.target.value)}
              className="bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1 text-xs text-slate-700 focus:outline-hidden focus:border-amber-500 cursor-pointer"
            >
              <option value="all">كافة المشاريع</option>
              {projects.map(p => (
                <option key={p.id} value={p.id}>{p.name}</option>
              ))}
            </select>

            {/* Currency Filter */}
            <select
              value={currencyFilter}
              onChange={(e) => setCurrencyFilter(e.target.value)}
              className="bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1 text-xs text-slate-700 focus:outline-hidden focus:border-amber-500 cursor-pointer"
            >
              <option value="all">كافة العملات</option>
              <option value="YER">ريال يمني (YER)</option>
              <option value="SAR">ريال سعودي (SAR)</option>
              <option value="USD">دولار أمريكي (USD)</option>
            </select>

            {/* Sort Order */}
            <select
              value={sortOrder}
              onChange={(e) => setSortOrder(e.target.value as any)}
              className="bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1 text-xs text-slate-700 focus:outline-hidden focus:border-amber-500 cursor-pointer"
            >
              <option value="newest">الأحدث تاريخاً</option>
              <option value="oldest">الأقدم تاريخاً</option>
              <option value="highest_amount">الأعلى مبلغاً</option>
            </select>
          </div>

          {/* Batch Add All Unadded Button */}
          {sharedRole !== 'read' && summaries.unaddedCount > 0 && (
            <button
              type="button"
              onClick={handleAddAllUnadded}
              className="px-3 py-1.5 bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600 text-white rounded-xl text-xs font-black flex items-center gap-1.5 shadow-xs transition-all cursor-pointer mr-auto sm:mr-0"
            >
              <Zap size={14} className="text-amber-200" />
              <span>إضافة كافة العمليات غير المضافة ({summaries.unaddedCount})</span>
            </button>
          )}
        </div>
      </div>

      {/* ======================= LIST / TABLE CONTENT ======================= */}
      {filteredList.length === 0 ? (
        <div className="bg-white rounded-3xl p-10 border border-slate-200 text-center space-y-3">
          <div className="w-16 h-16 rounded-2xl bg-amber-50 text-amber-500 mx-auto flex items-center justify-center shadow-inner">
            <Boxes size={32} />
          </div>
          <h3 className="text-base font-extrabold text-slate-800">
            {allExpenseAssets.length === 0
              ? 'لا توجد عمليات مسجلة تحت فئة «أصول مضافة» في النفقات اليومية'
              : 'لا توجد نتائج مطابقة لخيارات البحث والتصفية'}
          </h3>
          <p className="text-xs text-slate-500 max-w-md mx-auto">
            {allExpenseAssets.length === 0
              ? 'عند إضافة أي مصروف جديد في النفقات اليومية لأي مشروع واختيار فئة «أصول مضافة»، ستظهر العملية هنا تلقائياً لتتمكن من إدراجها في سجل أصول ومعدات الشركة.'
              : 'جرب تغيير شروط البحث أو التصفية لعرض العمليات.'}
          </p>
        </div>
      ) : (
        <>
          {/* Desktop Table View */}
          <div className="hidden md:block bg-white rounded-2xl border border-slate-200/90 shadow-xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-right border-collapse">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-slate-700 text-xs font-bold">
                    <th className="py-3 px-3 w-10 text-center">#</th>
                    <th className="py-3 px-3">المشروع المصدر</th>
                    <th className="py-3 px-3">التاريخ</th>
                    <th className="py-3 px-3 col-statement">بيان الأصل / الصنف</th>
                    <th className="py-3 px-3">المبلغ / التكلفة</th>
                    <th className="py-3 px-3">المورد / المستلم</th>
                    <th className="py-3 px-3">الملاحظات</th>
                    <th className="py-3 px-3 text-center">الحالة في الأصول</th>
                    <th className="py-3 px-3 text-center">الإجراء</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-xs text-slate-800">
                  {filteredList.map((item, idx) => (
                    <tr 
                      key={item.expenseId} 
                      className={`hover:bg-slate-50/80 transition-colors ${
                        item.isAlreadyAdded ? 'bg-emerald-50/20' : ''
                      }`}
                    >
                      <td className="py-3 px-3 text-center text-slate-400 font-bold">{idx + 1}</td>
                      
                      {/* Project Name */}
                      <td className="py-3 px-3">
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-lg bg-slate-100 text-slate-700 font-bold text-[11px] border border-slate-200">
                          <MapPin size={11} className="text-amber-500" />
                          <span className="truncate max-w-[130px]">{item.projectName}</span>
                        </span>
                      </td>

                      {/* Date */}
                      <td className="py-3 px-3 font-medium text-slate-600 whitespace-nowrap">
                        {formatDateArabic(item.date)}
                      </td>

                      {/* Description */}
                      <td className="py-3 px-3 font-black text-slate-900 leading-snug">
                        {item.description}
                      </td>

                      {/* Amount */}
                      <td className="py-3 px-3 whitespace-nowrap">
                        <span className="text-sm font-black text-slate-900">
                          {formatCurrency(item.amount, item.currency)}
                        </span>
                      </td>

                      {/* Recipient / Supplier */}
                      <td className="py-3 px-3 font-semibold text-slate-700">
                        {item.recipientName ? (
                          <span className="inline-flex items-center gap-1">
                            <User size={12} className="text-sky-500" />
                            <span>{item.recipientName}</span>
                          </span>
                        ) : (
                          <span className="text-slate-400">-</span>
                        )}
                      </td>

                      {/* Notes */}
                      <td className="py-3 px-3 text-[11px] text-slate-500 max-w-[150px] truncate" title={item.notes}>
                        {item.notes || '-'}
                      </td>

                      {/* Status */}
                      <td className="py-3 px-3 text-center whitespace-nowrap">
                        {item.isAlreadyAdded ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 text-[11px] font-black">
                            <CheckCircle2 size={13} className="text-emerald-600" />
                            <span>مضاف للأصول</span>
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-amber-50 text-amber-800 border border-amber-200 text-[11px] font-bold">
                            <Zap size={12} className="text-amber-600" />
                            <span>جديد / غير مضاف</span>
                          </span>
                        )}
                      </td>

                      {/* Actions */}
                      <td className="py-3 px-3 text-center whitespace-nowrap">
                        {item.isAlreadyAdded ? (
                          item.matchedAssetId && (
                            <button
                              type="button"
                              onClick={() => onNavigateToAsset(item.matchedAssetId!)}
                              className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-bold inline-flex items-center gap-1 transition-colors cursor-pointer"
                              title="عرض الأصل في سجل الأصول"
                            >
                              <ExternalLink size={12} />
                              <span>عرض في السجل</span>
                            </button>
                          )
                        ) : (
                          sharedRole !== 'read' && (
                            <div className="inline-flex items-center gap-1">
                              <button
                                type="button"
                                onClick={() => handleInstantAdd(item)}
                                className="px-2.5 py-1 bg-amber-600 hover:bg-amber-500 text-white rounded-lg text-xs font-bold inline-flex items-center gap-1 transition-all shadow-xs cursor-pointer"
                                title="إضافة سريعة فورية للأصول"
                              >
                                <PlusCircle size={13} />
                                <span>إضافة إلى الأصول</span>
                              </button>

                              <button
                                type="button"
                                onClick={() => onOpenAddCustomModal(item)}
                                className="px-2 py-1 bg-slate-100 hover:bg-amber-50 text-slate-700 hover:text-amber-800 rounded-lg text-xs font-semibold transition-colors cursor-pointer"
                                title="تخصيص الفئة والبيانات قبل الإضافة"
                              >
                                تخصيص...
                              </button>
                            </div>
                          )
                        )}
                      </td>

                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Mobile Cards View */}
          <div className="md:hidden space-y-3">
            {filteredList.map(item => (
              <div
                key={item.expenseId}
                className={`bg-white rounded-2xl p-4 border shadow-xs space-y-3 transition-all ${
                  item.isAlreadyAdded ? 'border-emerald-200 bg-emerald-50/10' : 'border-slate-200'
                }`}
              >
                {/* Card Top: Project & Status */}
                <div className="flex items-center justify-between gap-2">
                  <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-lg bg-slate-100 text-slate-700 font-bold text-xs border border-slate-200 truncate">
                    <MapPin size={12} className="text-amber-500" />
                    <span>{item.projectName}</span>
                  </span>

                  {item.isAlreadyAdded ? (
                    <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 text-[10px] font-black">
                      <CheckCircle2 size={12} className="text-emerald-600" />
                      <span>مضاف للأصول</span>
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-amber-50 text-amber-800 border border-amber-200 text-[10px] font-bold">
                      <Zap size={11} className="text-amber-600" />
                      <span>جديد وغير مضاف</span>
                    </span>
                  )}
                </div>

                {/* Description & Amount */}
                <div className="space-y-1">
                  <h4 className="text-sm font-black text-slate-900 leading-snug">
                    {item.description}
                  </h4>
                  <div className="flex items-center justify-between pt-1">
                    <span className="text-base font-black text-slate-900">
                      {formatCurrency(item.amount, item.currency)}
                    </span>
                    <span className="text-xs text-slate-500 font-medium flex items-center gap-1">
                      <Calendar size={12} />
                      {formatDateArabic(item.date)}
                    </span>
                  </div>
                </div>

                {/* Recipient & Notes */}
                {(item.recipientName || item.notes) && (
                  <div className="bg-slate-50 rounded-xl p-2.5 space-y-1 text-xs text-slate-600 border border-slate-100">
                    {item.recipientName && (
                      <div className="flex items-center gap-1">
                        <span className="text-slate-400 font-normal">المورد / المستلم:</span>
                        <span className="font-bold text-slate-800">{item.recipientName}</span>
                      </div>
                    )}
                    {item.notes && (
                      <div className="text-[11px] text-slate-500 italic">
                        {item.notes}
                      </div>
                    )}
                  </div>
                )}

                {/* Action Footer */}
                <div className="pt-2 border-t border-slate-100 flex items-center justify-between gap-2">
                  {item.isAlreadyAdded ? (
                    item.matchedAssetId && (
                      <button
                        type="button"
                        onClick={() => onNavigateToAsset(item.matchedAssetId!)}
                        className="w-full py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                      >
                        <ExternalLink size={14} />
                        <span>عرض الأصل في سجل ومخزون الأصول</span>
                      </button>
                    )
                  ) : (
                    sharedRole !== 'read' && (
                      <div className="w-full flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => handleInstantAdd(item)}
                          className="flex-1 py-2 bg-amber-600 hover:bg-amber-500 text-white rounded-xl text-xs font-black flex items-center justify-center gap-1.5 transition-all shadow-xs cursor-pointer"
                        >
                          <PlusCircle size={15} />
                          <span>إضافة إلى الأصول</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => onOpenAddCustomModal(item)}
                          className="py-2 px-3 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition-colors cursor-pointer"
                        >
                          تخصيص...
                        </button>
                      </div>
                    )
                  )}
                </div>

              </div>
            ))}
          </div>
        </>
      )}

    </div>
  );
};

export default ExpenseAssetsPanel;
