/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Global Application Error Boundary.
 * Catches any unhandled crashes and provides immediate self-healing recovery.
 */

import React, { Component, ErrorInfo, ReactNode } from 'react';
import { AlertTriangle, RefreshCw, Wrench, ShieldCheck } from 'lucide-react';
import { sanitizeStorageOnStartup, cleanupDisposableStorageKeys } from '../utils/safeStorage';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
  errorInfo: ErrorInfo | null;
  repaired: boolean;
}

export class ErrorBoundary extends React.Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = {
      hasError: false,
      error: null,
      errorInfo: null,
      repaired: false
    };
  }

  public static getDerivedStateFromError(error: Error): Partial<State> {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('[GlobalErrorBoundary] Caught unexpected crash:', error, errorInfo);
    this.setState({ errorInfo });
    // Automatically attempt silent recovery on quota or storage errors
    if (error.name === 'QuotaExceededError' || error.message?.includes('quota') || error.message?.includes('storage')) {
      cleanupDisposableStorageKeys();
      sanitizeStorageOnStartup();
    }
  }

  private handleRepairAndResume = () => {
    try {
      // 1. Run deep self-healing storage sanitizer
      cleanupDisposableStorageKeys();
      sanitizeStorageOnStartup();

      this.setState({ repaired: true });

      setTimeout(() => {
        window.location.reload();
      }, 500);
    } catch (e) {
      window.location.reload();
    }
  };

  private handleReload = () => {
    window.location.reload();
  };

  public render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-slate-900 text-slate-100 flex items-center justify-center p-4 font-sans" dir="rtl">
          <div className="max-w-lg w-full bg-slate-800 border border-slate-700 rounded-2xl shadow-2xl p-6 sm:p-8 text-center">
            <div className="w-16 h-16 bg-amber-500/10 border border-amber-500/30 text-amber-400 rounded-2xl flex items-center justify-center mx-auto mb-5 shadow-inner">
              <AlertTriangle size={32} />
            </div>

            <h1 className="text-xl sm:text-2xl font-black text-white mb-2 tracking-wide">
              تنبيه في تشغيل التطبيق
            </h1>

            <p className="text-sm text-slate-300 mb-6 leading-relaxed">
              حدث توقف مؤقت أثناء تحميل الواجهة، غالباً بسبب تجاوز سعة ذاكرة التخزين المؤقت للصور أو المستندات المرفقة في الهاتف.
              <span className="block mt-2 font-semibold text-emerald-400 flex items-center justify-center gap-1">
                <ShieldCheck size={16} /> جميع سجلاتك المحاسبية والمالية محفوظة بالكامل بأمان.
              </span>
            </p>

            <div className="space-y-3">
              <button
                type="button"
                onClick={this.handleRepairAndResume}
                className="w-full py-3.5 px-5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold rounded-xl shadow-lg shadow-emerald-900/30 transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-98"
              >
                <Wrench size={18} />
                <span>{this.state.repaired ? 'جارٍ إعادة التشغيل...' : 'إصلاح الذاكرة واستئناف العمل فوراً'}</span>
              </button>

              <button
                type="button"
                onClick={this.handleReload}
                className="w-full py-2.5 px-4 bg-slate-700/80 hover:bg-slate-700 text-slate-200 font-semibold rounded-xl border border-slate-600 transition-colors flex items-center justify-center gap-2 cursor-pointer"
              >
                <RefreshCw size={16} />
                <span>إعادة تحديث الصفحة</span>
              </button>
            </div>

            {this.state.error && (
              <details className="mt-6 text-right">
                <summary className="text-xs text-slate-400 hover:text-slate-200 cursor-pointer select-none">
                  عرض التفاصيل التقنية للخطأ
                </summary>
                <div className="mt-2 p-3 bg-slate-950/80 border border-slate-800 rounded-lg text-[11px] font-mono text-rose-300 text-left overflow-x-auto whitespace-pre-wrap max-h-36">
                  {this.state.error.name}: {this.state.error.message}
                </div>
              </details>
            )}
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
