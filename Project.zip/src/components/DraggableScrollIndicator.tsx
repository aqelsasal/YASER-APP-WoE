import React, { useState, useEffect, useRef, useCallback } from 'react';
import { createPortal } from 'react-dom';
import { 
  ChevronUp, 
  ChevronDown, 
  ChevronsUp,
  ChevronsDown,
  GripVertical, 
  FileSpreadsheet,
  ChevronsUpDown,
  ArrowUp,
  ArrowDown
} from 'lucide-react';

export interface DraggableScrollIndicatorProps {
  targetRef?: React.RefObject<HTMLElement | null>;
  targetElement?: HTMLElement | null;
  title?: string;
  variant?: 'amber' | 'emerald' | 'slate' | 'teal' | 'indigo' | 'blue' | 'purple' | 'rose';
  showJumpToSection?: boolean;
  onJumpToSection?: () => void;
  sectionJumpTitle?: string;
  sectionJumpIcon?: React.ReactNode;
  className?: string;
  isCompact?: boolean;
}

export const DraggableScrollIndicator: React.FC<DraggableScrollIndicatorProps> = ({
  targetRef,
  targetElement,
  title = 'مسار السحب والتنقل الفوري',
  variant = 'amber',
  showJumpToSection = false,
  onJumpToSection,
  sectionJumpTitle = 'جدول الأصناف',
  sectionJumpIcon,
  className = '',
  isCompact = false
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const trackRef = useRef<HTMLDivElement>(null);
  const [scrollRatio, setScrollRatio] = useState<number>(0);
  const [canScroll, setCanScroll] = useState<boolean>(false);
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [isHovered, setIsHovered] = useState<boolean>(false);
  const [thumbHeight, setThumbHeight] = useState<number>(50);
  const [thumbTop, setThumbTop] = useState<number>(0);

  // Helper to dynamically resolve target element
  const getTarget = useCallback((): HTMLElement | null => {
    if (targetElement) return targetElement;
    if (targetRef && targetRef.current) return targetRef.current;
    
    // Auto-discovery from container position if no ref provided
    if (containerRef.current) {
      const parent = containerRef.current.parentElement;
      if (parent) {
        // Look for sibling with overflow-y-auto or modal-scroll-area
        const sibling = Array.from(parent.children).find(
          c => c !== containerRef.current && (c.classList.contains('overflow-y-auto') || c.classList.contains('modal-scroll-area'))
        ) as HTMLElement | undefined;
        if (sibling) return sibling;
      }
    }
    return null;
  }, [targetRef, targetElement]);

  // Measure and update thumb geometry from target element
  const updateMetrics = useCallback(() => {
    const el = getTarget();
    const track = trackRef.current;
    if (!el || !track) return;

    const { scrollTop, scrollHeight, clientHeight } = el;
    const maxScroll = scrollHeight - clientHeight;
    const hasScroll = maxScroll > 4;
    setCanScroll(hasScroll);

    const trackHeight = track.clientHeight;
    if (trackHeight <= 0) return;

    // Calculate thumb height proportionally, clamped between min and max
    const calculatedHeight = Math.max(isCompact ? 36 : 46, Math.min(110, (clientHeight / (scrollHeight || 1)) * trackHeight));
    setThumbHeight(calculatedHeight);

    const ratio = maxScroll > 0 ? Math.max(0, Math.min(1, scrollTop / maxScroll)) : 0;
    setScrollRatio(ratio);

    const availableTrack = Math.max(0, trackHeight - calculatedHeight);
    setThumbTop(ratio * availableTrack);
  }, [getTarget, isCompact]);

  // Listen to scroll events on target element
  useEffect(() => {
    const el = getTarget();
    if (!el) return;

    updateMetrics();

    const handleScroll = () => {
      updateMetrics();
    };

    el.addEventListener('scroll', handleScroll, { passive: true });

    // ResizeObserver on scroll container to adapt to dynamic content
    const ro = new ResizeObserver(() => {
      updateMetrics();
    });
    ro.observe(el);

    return () => {
      el.removeEventListener('scroll', handleScroll);
      ro.disconnect();
    };
  }, [getTarget, updateMetrics]);

  // Drag handling with Mouse and Touch
  const handleDragStart = (clientY: number) => {
    const el = getTarget();
    const track = trackRef.current;
    if (!el || !track) return;

    setIsDragging(true);

    const startY = clientY;
    const startScrollTop = el.scrollTop;
    const { scrollHeight, clientHeight } = el;
    const maxScroll = Math.max(0, scrollHeight - clientHeight);
    const trackHeight = track.clientHeight;
    const availableTrack = Math.max(1, trackHeight - thumbHeight);

    // Save previous scroll-behavior to make drag instant without latency
    const prevScrollBehavior = el.style.scrollBehavior;
    el.style.scrollBehavior = 'auto';

    const onMouseMove = (moveEvent: MouseEvent) => {
      moveEvent.preventDefault();
      const deltaY = moveEvent.clientY - startY;
      const newScrollTop = startScrollTop + (deltaY / availableTrack) * maxScroll;
      el.scrollTop = Math.max(0, Math.min(maxScroll, newScrollTop));
    };

    const onMouseUp = () => {
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onMouseUp);
      el.style.scrollBehavior = prevScrollBehavior;
      setIsDragging(false);
    };

    const onTouchMove = (touchEvent: TouchEvent) => {
      if (touchEvent.touches.length > 0) {
        touchEvent.preventDefault();
        const deltaY = touchEvent.touches[0].clientY - startY;
        const newScrollTop = startScrollTop + (deltaY / availableTrack) * maxScroll;
        el.scrollTop = Math.max(0, Math.min(maxScroll, newScrollTop));
      }
    };

    const onTouchEnd = () => {
      window.removeEventListener('touchmove', onTouchMove);
      window.removeEventListener('touchend', onTouchEnd);
      el.style.scrollBehavior = prevScrollBehavior;
      setIsDragging(false);
    };

    window.addEventListener('mousemove', onMouseMove, { passive: false });
    window.addEventListener('mouseup', onMouseUp);
    window.addEventListener('touchmove', onTouchMove, { passive: false });
    window.addEventListener('touchend', onTouchEnd);
  };

  // Click directly on the track to jump to position
  const handleTrackClick = (e: React.MouseEvent<HTMLDivElement>) => {
    const el = getTarget();
    const track = trackRef.current;
    if (!el || !track) return;

    // Check if clicked directly on track, not on thumb
    if ((e.target as HTMLElement).closest('[data-scroll-thumb]')) {
      return;
    }

    const trackRect = track.getBoundingClientRect();
    const clickY = e.clientY - trackRect.top;
    const clickRatio = Math.max(0, Math.min(1, (clickY - thumbHeight / 2) / (trackRect.height - thumbHeight)));
    const maxScroll = el.scrollHeight - el.clientHeight;
    el.scrollTo({
      top: clickRatio * maxScroll,
      behavior: 'smooth'
    });
  };

  // Instant Quick Navigation to Top (أول الكشف بنقرة واحدة)
  const handleScrollToTop = (e: React.MouseEvent) => {
    e.stopPropagation();
    const el = getTarget();
    if (!el) return;
    el.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Instant Quick Navigation to Bottom (نهاية الكشف بنقرة واحدة)
  const handleScrollToBottom = (e: React.MouseEvent) => {
    e.stopPropagation();
    const el = getTarget();
    if (!el) return;
    el.scrollTo({ top: el.scrollHeight, behavior: 'smooth' });
  };

  // Human-readable scroll section badge
  const percent = Math.round(scrollRatio * 100);
  const scrollPositionLabel = percent <= 5 
    ? 'أول الكشف' 
    : percent >= 95 
    ? 'نهاية الكشف' 
    : `${percent}%`;

  // Color classes mapping
  const colorStyles = {
    amber: {
      thumb: 'bg-gradient-to-b from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 active:from-amber-700 active:to-amber-800 text-white border-2 border-amber-200/90 shadow-md',
      track: 'bg-slate-200/90 hover:bg-slate-300/80 border border-slate-300/90 dark:bg-slate-800 dark:border-slate-700',
      btn: 'text-amber-800 hover:text-amber-950 bg-amber-50 hover:bg-amber-100 border border-amber-300/90 active:bg-amber-200 shadow-2xs',
      badge: 'bg-amber-600 text-white border border-amber-400 shadow-lg'
    },
    emerald: {
      thumb: 'bg-gradient-to-b from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700 active:from-emerald-700 active:to-emerald-800 text-white border-2 border-emerald-200/90 shadow-md',
      track: 'bg-emerald-100/70 hover:bg-emerald-200/70 border border-emerald-200/90 dark:bg-slate-800 dark:border-emerald-800',
      btn: 'text-emerald-800 hover:text-emerald-950 bg-emerald-50 hover:bg-emerald-100 border border-emerald-300/90 active:bg-emerald-200 shadow-2xs',
      badge: 'bg-emerald-600 text-white border border-emerald-400 shadow-lg'
    },
    teal: {
      thumb: 'bg-gradient-to-b from-teal-500 to-teal-600 hover:from-teal-600 hover:to-teal-700 active:from-teal-700 active:to-teal-800 text-white border-2 border-teal-200/90 shadow-md',
      track: 'bg-teal-100/70 hover:bg-teal-200/70 border border-teal-200/90 dark:bg-slate-800 dark:border-teal-800',
      btn: 'text-teal-800 hover:text-teal-950 bg-teal-50 hover:bg-teal-100 border border-teal-300/90 active:bg-teal-200 shadow-2xs',
      badge: 'bg-teal-700 text-white border border-teal-400 shadow-lg'
    },
    indigo: {
      thumb: 'bg-gradient-to-b from-indigo-500 to-indigo-600 hover:from-indigo-600 hover:to-indigo-700 active:from-indigo-700 active:to-indigo-800 text-white border-2 border-indigo-200/90 shadow-md',
      track: 'bg-indigo-100/70 hover:bg-indigo-200/70 border border-indigo-200/90 dark:bg-slate-800 dark:border-indigo-800',
      btn: 'text-indigo-800 hover:text-indigo-950 bg-indigo-50 hover:bg-indigo-100 border border-indigo-300/90 active:bg-indigo-200 shadow-2xs',
      badge: 'bg-indigo-600 text-white border border-indigo-400 shadow-lg'
    },
    blue: {
      thumb: 'bg-gradient-to-b from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 active:from-blue-700 active:to-blue-800 text-white border-2 border-blue-200/90 shadow-md',
      track: 'bg-blue-100/70 hover:bg-blue-200/70 border border-blue-200/90 dark:bg-slate-800 dark:border-blue-800',
      btn: 'text-blue-800 hover:text-blue-950 bg-blue-50 hover:bg-blue-100 border border-blue-300/90 active:bg-blue-200 shadow-2xs',
      badge: 'bg-blue-600 text-white border border-blue-400 shadow-lg'
    },
    purple: {
      thumb: 'bg-gradient-to-b from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700 active:from-purple-700 active:to-purple-800 text-white border-2 border-purple-200/90 shadow-md',
      track: 'bg-purple-100/70 hover:bg-purple-200/70 border border-purple-200/90 dark:bg-slate-800 dark:border-purple-800',
      btn: 'text-purple-800 hover:text-purple-950 bg-purple-50 hover:bg-purple-100 border border-purple-300/90 active:bg-purple-200 shadow-2xs',
      badge: 'bg-purple-600 text-white border border-purple-400 shadow-lg'
    },
    rose: {
      thumb: 'bg-gradient-to-b from-rose-500 to-rose-600 hover:from-rose-600 hover:to-rose-700 active:from-rose-700 active:to-rose-800 text-white border-2 border-rose-200/90 shadow-md',
      track: 'bg-rose-100/70 hover:bg-rose-200/70 border border-rose-200/90 dark:bg-slate-800 dark:border-rose-800',
      btn: 'text-rose-800 hover:text-rose-950 bg-rose-50 hover:bg-rose-100 border border-rose-300/90 active:bg-rose-200 shadow-2xs',
      badge: 'bg-rose-600 text-white border border-rose-400 shadow-lg'
    },
    slate: {
      thumb: 'bg-gradient-to-b from-slate-600 to-slate-700 hover:from-slate-700 hover:to-slate-800 active:from-slate-800 active:to-slate-900 text-white border-2 border-slate-300/90 shadow-md',
      track: 'bg-slate-200/90 hover:bg-slate-300/80 border border-slate-300/90 dark:bg-slate-800 dark:border-slate-700',
      btn: 'text-slate-800 hover:text-slate-950 bg-slate-100 hover:bg-slate-200 border border-slate-300/90 active:bg-slate-300 shadow-2xs',
      badge: 'bg-slate-800 text-white border border-slate-600 shadow-lg'
    }
  }[variant] || {
    thumb: 'bg-amber-500 text-white',
    track: 'bg-slate-200',
    btn: 'text-amber-800 bg-amber-50 border-amber-300',
    badge: 'bg-amber-600 text-white'
  };

  return (
    <div 
      ref={containerRef}
      data-scroll-indicator="true"
      className={`flex flex-col items-center select-none shrink-0 z-30 transition-opacity duration-200 ${
        canScroll ? 'opacity-100 visible py-1.5 px-1' : 'opacity-0 invisible pointer-events-none w-0 h-0 p-0 m-0 overflow-hidden'
      } ${className}`}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      title={title}
    >
      {/* 🚀 Top Quick Action Button: Instant Jump to Beginning / Top of Statement (أول الكشف) */}
      <div className="flex flex-col items-center gap-1 mb-1">
        <button
          type="button"
          onClick={handleScrollToTop}
          className={`w-7 sm:w-7.5 h-6.5 sm:h-7 rounded-lg flex items-center justify-center transition-all active:scale-90 cursor-pointer shadow-2xs hover:shadow-xs group ${colorStyles.btn}`}
          title="الانتقال الفوري إلى أول الكشف (بداية النافذة بنقرة واحدة)"
          aria-label="الانتقال إلى أول الكشف"
        >
          <ChevronsUp size={14} className="stroke-[2.5] group-hover:-translate-y-0.5 transition-transform" />
          <span className="sr-only">أول الكشف</span>
        </button>
      </div>

      {/* Optional Jump to Items Table Shortcut */}
      {showJumpToSection && onJumpToSection && (
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            onJumpToSection();
          }}
          className={`w-7 h-7 rounded-lg flex items-center justify-center mb-1 transition-transform active:scale-90 cursor-pointer shadow-2xs ${colorStyles.btn}`}
          title={`الانتقال السريع إلى: ${sectionJumpTitle}`}
          aria-label={sectionJumpTitle}
        >
          {sectionJumpIcon || <FileSpreadsheet size={13} className="stroke-[2.2]" />}
        </button>
      )}

      {/* 📍 Main Draggable Scroll Track */}
      <div 
        ref={trackRef}
        onClick={handleTrackClick}
        className={`relative w-6 sm:w-7 flex-1 rounded-xl cursor-pointer transition-colors flex justify-center ${colorStyles.track}`}
        title="مسار السحب: انقر هنا للانتقال، أو اسحب المؤشر للأعلى والأسفل"
      >
        {/* Draggable Thumb */}
        <div
          data-scroll-thumb="true"
          onMouseDown={(e) => {
            e.preventDefault();
            e.stopPropagation();
            handleDragStart(e.clientY);
          }}
          onTouchStart={(e) => {
            e.stopPropagation();
            if (e.touches.length > 0) {
              handleDragStart(e.touches[0].clientY);
            }
          }}
          style={{
            height: `${thumbHeight}px`,
            top: `${thumbTop}px`,
            position: 'absolute'
          }}
          className={`w-5 sm:w-5.5 rounded-lg flex flex-col items-center justify-center transition-shadow cursor-grab active:cursor-grabbing ${
            colorStyles.thumb
          } ${isDragging ? 'ring-2 ring-amber-400 ring-offset-1 scale-105' : ''}`}
        >
          {/* Grab ridges icon */}
          <ChevronsUpDown size={14} className="opacity-95 stroke-[2.5]" />

          {/* Floating Live Position Badge when Hovered or Dragging */}
          {(isHovered || isDragging) && (
            <div 
              className={`absolute -left-20 sm:-left-24 px-2 py-0.5 rounded-md text-[10px] font-bold whitespace-nowrap pointer-events-none transition-opacity ${colorStyles.badge}`}
            >
              {scrollPositionLabel}
            </div>
          )}
        </div>
      </div>

      {/* 🚀 Bottom Quick Action Button: Instant Jump to End / Bottom of Statement (نهاية الكشف) */}
      <div className="flex flex-col items-center gap-1 mt-1">
        <button
          type="button"
          onClick={handleScrollToBottom}
          className={`w-7 sm:w-7.5 h-6.5 sm:h-7 rounded-lg flex items-center justify-center transition-all active:scale-90 cursor-pointer shadow-2xs hover:shadow-xs group ${colorStyles.btn}`}
          title="الانتقال الفوري إلى نهاية الكشف (آخر النافذة بنقرة واحدة)"
          aria-label="الانتقال إلى نهاية الكشف"
        >
          <ChevronsDown size={14} className="stroke-[2.5] group-hover:translate-y-0.5 transition-transform" />
          <span className="sr-only">نهاية الكشف</span>
        </button>
      </div>
    </div>
  );
};

/**
 * AutoInjectedModalIndicatorItem:
 * Dedicated manager for an individual modal indicator portal.
 * Validates actual scrollability dynamically with ResizeObserver.
 * If content fits without scrolling, it renders null (no wrapper, no shadow, no faint ghost).
 */
const AutoInjectedModalIndicatorItem: React.FC<{
  id: string;
  modalEl: HTMLElement;
  scrollEl: HTMLElement;
}> = ({ id, modalEl, scrollEl }) => {
  const [canScroll, setCanScroll] = useState<boolean>(false);

  useEffect(() => {
    const checkOverflow = () => {
      if (!scrollEl) return;
      const { scrollHeight, clientHeight } = scrollEl;
      const overflow = scrollHeight - clientHeight;
      setCanScroll(overflow > 25);
    };

    checkOverflow();

    const t1 = setTimeout(checkOverflow, 80);
    const t2 = setTimeout(checkOverflow, 250);

    const ro = new ResizeObserver(checkOverflow);
    ro.observe(scrollEl);
    if (modalEl && modalEl !== scrollEl) {
      ro.observe(modalEl);
    }

    scrollEl.addEventListener('scroll', checkOverflow, { passive: true });

    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
      ro.disconnect();
      scrollEl.removeEventListener('scroll', checkOverflow);
    };
  }, [scrollEl, modalEl]);

  if (!canScroll) return null;

  return createPortal(
    <div
      key={id}
      data-scroll-indicator="true"
      data-auto-injected="true"
      className="absolute left-1.5 sm:left-2 top-14 bottom-14 z-50 flex items-center pointer-events-none transition-opacity duration-200"
      style={{ direction: 'rtl' }}
    >
      <div className="pointer-events-auto bg-white/95 dark:bg-slate-900/95 backdrop-blur-xs rounded-2xl shadow-xl border border-slate-200/90 dark:border-slate-700 py-1.5 px-0.5">
        <DraggableScrollIndicator
          targetElement={scrollEl}
          variant="amber"
          isCompact={true}
          title="الانتقال الفوري إلى أول أو نهاية الكشف ومسار السحب"
        />
      </div>
    </div>,
    modalEl
  );
};

/**
 * GlobalModalScrollIndicator:
 * Automatically monitors active large modal dialogs in the application.
 * Excludes dropdown menus, select popovers, and small dialogs.
 * Only attaches if modal has actual scrollable content.
 */
export const GlobalModalScrollIndicator: React.FC = () => {
  const [activeModals, setActiveModals] = useState<{ id: string; modalEl: HTMLElement; scrollEl: HTMLElement }[]>([]);

  useEffect(() => {
    let animFrameId: number | null = null;

    const scanModals = () => {
      // Find modal backdrops and dialog containers
      const backdrops = Array.from(document.querySelectorAll<HTMLElement>('.fixed.inset-0, [role="dialog"]'));
      const detected: { id: string; modalEl: HTMLElement; scrollEl: HTMLElement }[] = [];

      backdrops.forEach((backdrop, idx) => {
        // Skip hidden or invisible backdrops
        if (backdrop.offsetParent === null && getComputedStyle(backdrop).display === 'none') return;

        // Skip transparent click-away overlays (e.g. dropdown backdrop in OptionsMenu)
        if (backdrop.classList.contains('bg-transparent')) return;

        // Skip dropdown menus, context menus, toolbars, listboxes, navigation
        if (
          backdrop.closest('[role="menu"], [role="listbox"], .dropdown-menu, [data-dropdown], #bottom-navigation, nav') ||
          backdrop.getAttribute('role') === 'menu' ||
          backdrop.getAttribute('role') === 'listbox'
        ) {
          return;
        }

        // Skip if modal already has an explicit manual scroll indicator (not injected by us)
        const manualIndicator = backdrop.querySelector('[data-scroll-indicator="true"]:not([data-auto-injected="true"])');
        if (manualIndicator) return;

        // Find scrollable container inside modal card
        const scrollable = backdrop.querySelector<HTMLElement>(
          '.modal-scroll-area, .overflow-y-auto, [data-modal-scroll="true"]'
        );
        if (!scrollable) return;

        // Skip if scrollable belongs to a dropdown or nested menu
        if (scrollable.closest('[role="menu"], [role="listbox"], .dropdown-menu, [data-dropdown]')) {
          return;
        }

        // Find modal dialog card
        const modalCard = scrollable.closest<HTMLElement>(
          '.modal-dialog-card, .bg-white.rounded-3xl, .bg-white.rounded-2xl, .bg-white.w-full, [role="dialog"], [role="document"]'
        ) || (backdrop.classList.contains('overflow-y-auto') ? null : backdrop);

        if (!modalCard) return;

        // Ensure it's large enough to be an actual modal dialog (not a dropdown or tiny widget)
        const rect = modalCard.getBoundingClientRect();
        if (rect.width < 320 || rect.height < 240) return;

        // Ensure parent has position relative for absolute positioning
        if (modalCard !== backdrop && getComputedStyle(modalCard).position === 'static') {
          modalCard.style.position = 'relative';
        }

        let modalId = modalCard.getAttribute('data-modal-auto-id');
        if (!modalId) {
          modalId = `auto-modal-${idx}-${Math.random().toString(36).substring(2, 7)}`;
          modalCard.setAttribute('data-modal-auto-id', modalId);
        }

        detected.push({ id: modalId, modalEl: modalCard, scrollEl: scrollable });
      });

      setActiveModals(prev => {
        if (prev.length === detected.length && prev.every((p, i) => p.id === detected[i]?.id && p.scrollEl === detected[i]?.scrollEl)) {
          return prev;
        }
        return detected;
      });
    };

    const debouncedScan = () => {
      if (animFrameId !== null) cancelAnimationFrame(animFrameId);
      animFrameId = requestAnimationFrame(scanModals);
    };

    debouncedScan();

    const observer = new MutationObserver(debouncedScan);
    observer.observe(document.body, { childList: true, subtree: true, attributes: false });

    window.addEventListener('resize', debouncedScan);

    return () => {
      if (animFrameId !== null) cancelAnimationFrame(animFrameId);
      observer.disconnect();
      window.removeEventListener('resize', debouncedScan);
    };
  }, []);

  if (activeModals.length === 0) return null;

  return (
    <>
      {activeModals.map(({ id, modalEl, scrollEl }) => (
        <AutoInjectedModalIndicatorItem
          key={id}
          id={id}
          modalEl={modalEl}
          scrollEl={scrollEl}
        />
      ))}
    </>
  );
};

export default DraggableScrollIndicator;
