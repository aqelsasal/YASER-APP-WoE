/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  RotateCcw, 
  X, 
  Check, 
  Trash2, 
  Edit3, 
  Clock, 
  History, 
  Layers, 
  AlertTriangle, 
  Building2, 
  TrendingUp, 
  Users, 
  Briefcase, 
  Truck, 
  Coins, 
  Boxes, 
  FileSpreadsheet, 
  ChevronDown, 
  ChevronUp,
  Sparkles
} from 'lucide-react';
import { UndoItem, UndoCategory } from '../types/undo';
import { useBodyScrollLock } from '../utils/modalScrollLock';

interface UndoModalProps {
  isOpen: boolean;
  onClose: () => void;
  undoStack: UndoItem[];
  onConfirmUndo: (item: UndoItem) => void;
  onClearUndoStack?: () => void;
}

export default function UndoModal({
  isOpen,
  onClose,
  undoStack,
  onConfirmUndo,
  onClearUndoStack
}: UndoModalProps) {
  const [showFullHistory, setShowFullHistory] = useState(false);
  const [selectedItemIndex, setSelectedItemIndex] = useState(0);

  useBodyScrollLock(isOpen);

  if (!isOpen) return null;

  const currentItem = undoStack[selectedItemIndex] || undoStack[0];
  const hasItems = undoStack.length > 0;

  const getCategoryIcon = (category: UndoCategory) => {
    switch (category) {
      case 'expenses':
        return <TrendingUp size={16} className="text-rose-500" />;
      case 'workers':
        return <Users size={16} className="text-sky-500" />;
      case 'employees':
        return <Briefcase size={16} className="text-indigo-500" />;
      case 'suppliers':
        return <Truck size={16} className="text-amber-500" />;
      case 'general_debts':
        return <Coins size={16} className="text-amber-500" />;
      case 'company_assets':
        return <Boxes size={16} className="text-teal-500" />;
      case 'projects':
        return <Building2 size={16} className="text-blue-500" />;
      case 'boq':
        return <FileSpreadsheet size={16} className="text-emerald-500" />;
      default:
        return <Layers size={16} className="text-slate-500" />;
    }
  };

  const getActionBadge = (actionType: string) => {
    if (actionType === 'delete') {
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-extrabold bg-rose-100 text-rose-800 border border-rose-200">
          <Trash2 size={12} />
          <span>تراجع عن حذف</span>
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-extrabold bg-amber-100 text-amber-800 border border-amber-200">
        <Edit3 size={12} />
        <span>تراجع عن تعديل</span>
      </span>
    );
  };

  return (
    <div 
      className="fixed inset-0 z-[120] bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto dir-rtl text-right overscroll-contain animate-fade-in"
      onClick={onClose}
    >
      <div 
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-lg bg-white rounded-3xl border border-slate-200 shadow-2xl overflow-hidden my-auto flex flex-col max-h-[92vh] sm:max-h-[88vh]"
      >
        {/* Header */}
        <div className="bg-gradient-to-r from-amber-600 via-amber-700 to-amber-800 px-5 sm:px-6 py-4 text-white flex items-center justify-between shrink-0 shadow-sm">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-white/20 text-white rounded-2xl backdrop-blur-xs shadow-inner">
              <RotateCcw size={22} className="stroke-[2.5]" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-black tracking-tight">التراجع واسترجاع العمليات</h2>
                {hasItems && (
                  <span className="text-[11px] font-extrabold bg-white/25 text-white px-2.5 py-0.5 rounded-full border border-white/30">
                    {undoStack.length} {undoStack.length === 1 ? 'عملية متاحة' : 'عمليات متاحة'}
                  </span>
                )}
              </div>
              <p className="text-xs text-amber-100 font-medium">استعادة البيانات السابقة قبل التعديل أو الحذف بضغطة زر</p>
            </div>
          </div>
          <button 
            type="button" 
            onClick={onClose}
            className="p-1.5 text-white/80 hover:text-white rounded-xl hover:bg-white/10 transition-colors cursor-pointer"
            title="إغلاق"
          >
            <X size={20} />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-4 flex-1 overscroll-contain touch-pan-y modal-scroll-area">
          
          {!hasItems ? (
            <div className="text-center py-10 space-y-3">
              <div className="w-14 h-14 mx-auto rounded-full bg-slate-100 text-slate-400 flex items-center justify-center">
                <History size={26} />
              </div>
              <h3 className="text-sm font-bold text-slate-700">لا توجد عمليات سابقة للتراجع عنها حالياً</h3>
              <p className="text-xs text-slate-500 max-w-xs mx-auto leading-relaxed">
                يقوم النظام تلقائياً بتسجيل أي عملية حذف أو تعديل تجريها على المصروفات أو العمال أو الديون، لتتمكن من التراجع عنها فوراً في أي وقت.
              </p>
            </div>
          ) : (
            <>
              {/* Highlighted Item to Undo */}
              <div className="bg-gradient-to-b from-amber-50/60 to-white rounded-2xl p-4 sm:p-5 border-2 border-amber-300 shadow-sm space-y-3.5 relative overflow-hidden">
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <div className="flex items-center gap-2">
                    <span className="p-1.5 rounded-xl bg-white shadow-2xs border border-slate-200">
                      {getCategoryIcon(currentItem.category)}
                    </span>
                    <span className="text-xs font-black text-slate-700">{currentItem.categoryLabel}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    {getActionBadge(currentItem.actionType)}
                    <span className="text-[11px] text-slate-500 font-bold flex items-center gap-1 bg-slate-100 px-2 py-0.5 rounded-md">
                      <Clock size={11} />
                      <span>{currentItem.timeAgo || 'قبل لحظات'}</span>
                    </span>
                  </div>
                </div>

                {/* Operation Title */}
                <div>
                  <h3 className="text-sm sm:text-base font-black text-slate-900 leading-snug">
                    {currentItem.title}
                  </h3>
                  {currentItem.projectName && (
                    <span className="inline-block mt-1 text-[11px] font-bold text-sky-700 bg-sky-50 px-2 py-0.5 rounded-md border border-sky-200">
                      المشروع: {currentItem.projectName}
                    </span>
                  )}
                </div>

                {/* Details Grid */}
                {currentItem.details && currentItem.details.length > 0 && (
                  <div className="bg-white rounded-xl p-3 border border-amber-200/80 shadow-2xs grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                    {currentItem.details.map((det, idx) => (
                      <div key={idx} className="flex items-start justify-between gap-2 border-b border-slate-100 last:border-b-0 pb-1 last:pb-0">
                        <span className="text-slate-500 font-bold shrink-0">{det.label}:</span>
                        <span className="font-black text-slate-800 text-left dir-ltr truncate" title={det.value}>
                          {det.value}
                        </span>
                      </div>
                    ))}
                  </div>
                )}

                {/* Informative Note */}
                <div className="flex items-center gap-2 text-[11px] text-amber-900 bg-amber-100/70 p-2.5 rounded-xl border border-amber-200">
                  <Sparkles size={15} className="text-amber-700 shrink-0" />
                  <span>
                    عند تأكيد التراجع، سيتم استرجاع هذا السجل بحالته السابقة تماماً وتحديث الحسابات والجداول فورياً.
                  </span>
                </div>

                {/* Confirm Action Button */}
                <button
                  type="button"
                  onClick={() => onConfirmUndo(currentItem)}
                  className="w-full py-3 bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-700 hover:to-amber-800 active:scale-[0.98] text-white rounded-xl font-black text-xs sm:text-sm shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <RotateCcw size={16} className="stroke-[2.5]" />
                  <span>تأكيد التراجع واسترجاع هذه العملية الآن</span>
                </button>
              </div>

              {/* Multiple Undo / History Stack List */}
              {undoStack.length > 1 && (
                <div className="space-y-2 pt-1 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={() => setShowFullHistory(!showFullHistory)}
                    className="w-full flex items-center justify-between p-2.5 bg-slate-50 hover:bg-slate-100 text-slate-700 rounded-xl text-xs font-extrabold transition-colors cursor-pointer border border-slate-200"
                  >
                    <div className="flex items-center gap-2">
                      <History size={15} className="text-amber-600" />
                      <span>عرض سجل العمليات السابقة الأخرى ({undoStack.length} عمليات)</span>
                    </div>
                    {showFullHistory ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
                  </button>

                  {showFullHistory && (
                    <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
                      {undoStack.map((item, index) => (
                        <div
                          key={item.id}
                          onClick={() => setSelectedItemIndex(index)}
                          className={`p-2.5 rounded-xl border transition-all cursor-pointer flex items-center justify-between gap-2 text-xs ${
                            selectedItemIndex === index
                              ? 'bg-amber-50/80 border-amber-400 ring-1 ring-amber-300'
                              : 'bg-white border-slate-200 hover:bg-slate-50'
                          }`}
                        >
                          <div className="flex items-center gap-2 truncate">
                            <span className="text-[10px] font-black w-5 h-5 rounded-full bg-slate-200 text-slate-700 flex items-center justify-center shrink-0">
                              {index + 1}
                            </span>
                            <div className="truncate">
                              <div className="font-black text-slate-800 truncate">{item.title}</div>
                              <div className="text-[10px] text-slate-500 flex items-center gap-2 mt-0.5">
                                <span>{item.categoryLabel}</span>
                                <span>•</span>
                                <span>{item.timeAgo}</span>
                              </div>
                            </div>
                          </div>

                          <div className="flex items-center gap-1.5 shrink-0">
                            {getActionBadge(item.actionType)}
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                onConfirmUndo(item);
                              }}
                              className="px-2.5 py-1 bg-amber-600 hover:bg-amber-700 text-white rounded-lg font-bold text-[11px] transition-colors cursor-pointer flex items-center gap-1 shadow-2xs"
                              title="استرجاع هذه العملية مباشرة"
                            >
                              <RotateCcw size={11} />
                              <span>استرجاع</span>
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </>
          )}

        </div>

        {/* Footer */}
        <div className="bg-slate-50 px-5 sm:px-6 py-3 border-t border-slate-200 flex items-center justify-between shrink-0">
          <div>
            {hasItems && onClearUndoStack && (
              <button
                type="button"
                onClick={onClearUndoStack}
                className="text-[11px] text-slate-500 hover:text-rose-600 font-bold transition-colors cursor-pointer flex items-center gap-1"
              >
                <Trash2 size={13} />
                <span>مسح سجل التراجع</span>
              </button>
            )}
          </div>

          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 bg-slate-200 hover:bg-slate-300 active:scale-95 text-slate-800 rounded-xl font-extrabold text-xs transition-colors cursor-pointer"
          >
            إلغاء وإغلاق
          </button>
        </div>
      </div>
    </div>
  );
}
