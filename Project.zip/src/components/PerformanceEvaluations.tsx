/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo, useEffect } from 'react';
import { DraggableScrollIndicator } from './DraggableScrollIndicator';
import { 
  Award, 
  Star, 
  Users, 
  Briefcase, 
  Truck, 
  Plus, 
  Search, 
  Filter, 
  Download, 
  Printer, 
  Edit3, 
  Trash2, 
  RotateCcw, 
  Calendar, 
  CheckCircle2, 
  ChevronRight, 
  ChevronLeft,
  ArrowRight,
  Receipt,
  Building2,
  X,
  Layers,
  Sparkles,
  TrendingUp,
  Clock,
  FileSpreadsheet,
  Share2,
  Info,
  SlidersHorizontal,
  UserCheck,
  ExternalLink,
  ThumbsUp,
  ThumbsDown,
  HardHat,
  FileText,
  ShieldAlert,
  HelpCircle
} from 'lucide-react';
import { 
  PerformanceEvaluation, 
  EvaluationCategory, 
  PerformanceLevel, 
  RecommendationChoice,
  Employee, 
  Worker, 
  Supplier, 
  Project,
  EMPLOYEE_CRITERIA, 
  WORKER_CRITERIA, 
  SUPPLIER_CRITERIA, 
  RECOMMENDATION_CHOICES,
  getRecommendationQuestion,
  getRecommendationLabel,
  getCriterionLabel,
  getPerformanceLevelInfo,
  exportToXLSX,
  printPDF,
  getFormattedReportDate,
  ensureDateInFilename
} from '../types';
import { useBodyScrollLock } from '../utils/modalScrollLock';
import PageHeaderCard from './PageHeaderCard';
import OptionsMenu from './OptionsMenu';

interface PerformanceEvaluationsProps {
  evaluations: PerformanceEvaluation[];
  onAddEvaluation: (evaluation: Omit<PerformanceEvaluation, 'id' | 'createdAt' | 'updatedAt'>) => void;
  onUpdateEvaluation: (evaluation: PerformanceEvaluation) => void;
  onDeleteEvaluation: (id: string) => void;
  employees: Employee[];
  workers: Worker[];
  suppliers: Supplier[];
  projects?: Project[];
  activeProjectId?: string;
  projectName?: string;
  setActiveTab?: (tab: string) => void;
  onNavigateToEntityLedger?: (category: EvaluationCategory, entityId: string, projectId?: string) => void;
  currentUser?: string;
  sharedRole?: 'owner' | 'editor' | 'read' | 'full' | 'add' | string;
  companyName?: string;
  companyAddress?: string;
  companyPhone?: string;
}

export default function PerformanceEvaluations({
  evaluations,
  onAddEvaluation,
  onUpdateEvaluation,
  onDeleteEvaluation,
  employees,
  workers,
  suppliers,
  projects = [],
  activeProjectId,
  projectName = '',
  setActiveTab,
  onNavigateToEntityLedger,
  currentUser = 'المدير',
  sharedRole = 'owner',
  companyName = 'شركة الأفق للمقاولات العامة',
  companyAddress = '',
  companyPhone = ''
}: PerformanceEvaluationsProps) {
  // Main Category Tab Filter
  const [activeCategoryTab, setActiveCategoryTab] = useState<'all' | EvaluationCategory>('all');
  
  // Project Filter: 'all' (All Projects), 'general' (General/No Project), or specific projectId
  const [selectedProjectFilter, setSelectedProjectFilter] = useState<string>('all');

  // View Mode: 'people' (Aggregated Persons/Suppliers View) or 'history' (Full Chronological Log)
  const [viewMode, setViewMode] = useState<'people' | 'history'>('people');

  // Search and Advanced Filters
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedEntityId, setSelectedEntityId] = useState<string>('all');
  const [selectedPerformanceLevel, setSelectedPerformanceLevel] = useState<string>('all');
  const [startDateFilter, setStartDateFilter] = useState('');
  const [endDateFilter, setEndDateFilter] = useState('');
  const [showFilterDrawer, setShowFilterDrawer] = useState(false);

  // Modal State for Add / Edit
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingEvaluation, setEditingEvaluation] = useState<PerformanceEvaluation | null>(null);

  // Form State
  const [formCategory, setFormCategory] = useState<EvaluationCategory>('employee');
  const [formProjectId, setFormProjectId] = useState<string>('');
  const [formProjectName, setFormProjectName] = useState<string>('');
  const [formEntityId, setFormEntityId] = useState('');
  const [formEntityName, setFormEntityName] = useState('');
  const [formProfessionOrType, setFormProfessionOrType] = useState('');
  const [formDate, setFormDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [formPeriod, setFormPeriod] = useState('');
  const [formCriteria, setFormCriteria] = useState<Record<string, number>>({});
  const [formCustomRating, setFormCustomRating] = useState<number | null>(null);

  // Form: Evaluator / Supervisor
  const [formEvaluatorId, setFormEvaluatorId] = useState('');
  const [formEvaluatorName, setFormEvaluatorName] = useState('');
  const [formEvaluatorTitle, setFormEvaluatorTitle] = useState('');

  // Form: Recommendation Question & Strengths / Weaknesses / Other Notes
  const [formRecommendation, setFormRecommendation] = useState<RecommendationChoice | ''>('');
  const [formStrengths, setFormStrengths] = useState('');
  const [formWeaknesses, setFormWeaknesses] = useState('');
  const [formNotes, setFormNotes] = useState('');
  const [formError, setFormError] = useState('');

  // Selected Entity Detail Modal (to view history of one specific person)
  const [historyModalEntity, setHistoryModalEntity] = useState<{ id: string; name: string; category: EvaluationCategory; projectId?: string; projectName?: string } | null>(null);

  useBodyScrollLock(Boolean(isModalOpen || historyModalEntity));

  // Build entity repository across all projects for cross-project linking
  const allProjectEntities = useMemo(() => {
    const allEmps: Array<Employee & { projectId?: string; projectName?: string }> = [];
    const allWrks: Array<Worker & { projectId?: string; projectName?: string }> = [];
    const allSups: Array<Supplier & { projectId?: string; projectName?: string }> = [];

    // Add current active project entities
    employees.forEach(e => allEmps.push({ ...e, projectId: activeProjectId, projectName }));
    workers.forEach(w => allWrks.push({ ...w, projectId: activeProjectId, projectName }));
    suppliers.forEach(s => allSups.push({ ...s, projectId: activeProjectId, projectName }));

    // Add entities from all other projects if projects array is provided
    projects.forEach(p => {
      if (p.id !== activeProjectId) {
        (p.employees || []).forEach(e => allEmps.push({ ...e, projectId: p.id, projectName: p.name }));
        (p.workers || []).forEach(w => allWrks.push({ ...w, projectId: p.id, projectName: p.name }));
        (p.suppliers || []).forEach(s => allSups.push({ ...s, projectId: p.id, projectName: p.name }));
      }
    });

    return { allEmps, allWrks, allSups };
  }, [employees, workers, suppliers, projects, activeProjectId, projectName]);

  // List of qualifying Supervisors and Field Engineers for evaluator selection
  const qualifyingSupervisors = useMemo(() => {
    const result: Array<{ id: string; name: string; profession: string; projectName?: string }> = [];
    const seenIds = new Set<string>();

    const isSupervisorOrEngineer = (prof?: string) => {
      if (!prof) return false;
      const p = prof.toLowerCase().trim();
      return (
        p.includes('مشرف') ||
        p.includes('مهندس') ||
        p.includes('ميدان') ||
        p.includes('إشراف') ||
        p.includes('اشراف') ||
        p.includes('مدير') ||
        p.includes('موقع') ||
        p.includes('استشاري')
      );
    };

    // First add employees who match supervisor/field engineer roles
    allProjectEntities.allEmps.forEach(emp => {
      if (!seenIds.has(emp.id) && isSupervisorOrEngineer(emp.profession)) {
        seenIds.add(emp.id);
        result.push({
          id: emp.id,
          name: emp.name,
          profession: emp.profession || 'مهندس ومشرف ميداني',
          projectName: emp.projectName
        });
      }
    });

    // Then append any remaining employees as alternative evaluators
    allProjectEntities.allEmps.forEach(emp => {
      if (!seenIds.has(emp.id)) {
        seenIds.add(emp.id);
        result.push({
          id: emp.id,
          name: emp.name,
          profession: emp.profession || 'موظف',
          projectName: emp.projectName
        });
      }
    });

    return result;
  }, [allProjectEntities.allEmps]);

  // Determine criteria definitions based on selected category
  const activeCriteriaList = useMemo(() => {
    switch (formCategory) {
      case 'employee': return EMPLOYEE_CRITERIA;
      case 'worker': return WORKER_CRITERIA;
      case 'supplier': return SUPPLIER_CRITERIA;
      default: return EMPLOYEE_CRITERIA;
    }
  }, [formCategory]);

  // Calculate calculated rating from criteria
  const computedRating = useMemo(() => {
    if (formCustomRating !== null) return formCustomRating;
    const values = Object.values(formCriteria).filter((v): v is number => typeof v === 'number' && v > 0);
    if (values.length === 0) return 5;
    const sum = values.reduce((a: number, b: number) => a + b, 0);
    return Math.round((sum / values.length) * 10) / 10;
  }, [formCriteria, formCustomRating]);

  // Reset form handler
  const handleResetForm = () => {
    if (editingEvaluation) {
      setFormCategory(editingEvaluation.category);
      setFormProjectId(editingEvaluation.projectId || '');
      setFormProjectName(editingEvaluation.projectName || '');
      setFormEntityId(editingEvaluation.entityId);
      setFormEntityName(editingEvaluation.entityName);
      setFormProfessionOrType(editingEvaluation.professionOrType || '');
      setFormDate(editingEvaluation.date);
      setFormPeriod(editingEvaluation.period || '');
      setFormCriteria({ ...editingEvaluation.criteria });
      setFormCustomRating(editingEvaluation.rating);
      setFormEvaluatorId(editingEvaluation.evaluatorId || '');
      setFormEvaluatorName(editingEvaluation.evaluatorName || editingEvaluation.createdBy || currentUser || '');
      setFormEvaluatorTitle(editingEvaluation.evaluatorTitle || 'مهندس ومشرف ميداني');
      setFormRecommendation(editingEvaluation.recommendation || '');
      setFormStrengths(editingEvaluation.strengths || '');
      setFormWeaknesses(editingEvaluation.weaknesses || '');
      setFormNotes(editingEvaluation.notes || '');
      setFormError('');
    } else {
      setFormEntityId('');
      setFormEntityName('');
      setFormProfessionOrType('');
      setFormDate(new Date().toISOString().split('T')[0]);
      setFormPeriod('');
      
      const defaultProjId = selectedProjectFilter !== 'all' && selectedProjectFilter !== 'general' 
        ? selectedProjectFilter 
        : (activeProjectId || '');
      const defaultProj = projects.find(p => p.id === defaultProjId);
      setFormProjectId(defaultProjId);
      setFormProjectName(defaultProj ? defaultProj.name : projectName);

      // Default evaluator
      const defaultSupervisor = qualifyingSupervisors.find(s => s.name === currentUser) || qualifyingSupervisors[0];
      setFormEvaluatorId(defaultSupervisor ? defaultSupervisor.id : '');
      setFormEvaluatorName(defaultSupervisor ? defaultSupervisor.name : (currentUser || 'المهندس المشرف'));
      setFormEvaluatorTitle(defaultSupervisor ? defaultSupervisor.profession : 'مهندس ومشرف ميداني');

      // Initialize criteria default to 5 stars
      const initialCriteria: Record<string, number> = {};
      activeCriteriaList.forEach(c => {
        initialCriteria[c.key] = 5;
      });
      setFormCriteria(initialCriteria);
      setFormCustomRating(null);
      setFormRecommendation('strongly_agree');
      setFormStrengths('');
      setFormWeaknesses('');
      setFormNotes('');
      setFormError('');
    }
  };

  // Open modal for new evaluation
  const handleOpenAddModal = (
    defaultCategory?: EvaluationCategory, 
    entity?: { id: string; name: string; professionOrType?: string; projectId?: string; projectName?: string }
  ) => {
    const cat = defaultCategory || (activeCategoryTab !== 'all' ? activeCategoryTab : 'employee');
    setEditingEvaluation(null);
    setFormCategory(cat);
    
    // Choose criteria list for this category
    const critList = cat === 'employee' ? EMPLOYEE_CRITERIA : cat === 'worker' ? WORKER_CRITERIA : SUPPLIER_CRITERIA;
    const initCrit: Record<string, number> = {};
    critList.forEach(c => { initCrit[c.key] = 5; });
    setFormCriteria(initCrit);

    if (entity) {
      setFormEntityId(entity.id);
      setFormEntityName(entity.name);
      setFormProfessionOrType(entity.professionOrType || '');
      setFormProjectId(entity.projectId || (selectedProjectFilter !== 'all' && selectedProjectFilter !== 'general' ? selectedProjectFilter : (activeProjectId || '')));
      const proj = projects.find(p => p.id === (entity.projectId || formProjectId));
      setFormProjectName(entity.projectName || (proj ? proj.name : projectName));
    } else {
      setFormEntityId('');
      setFormEntityName('');
      setFormProfessionOrType('');
      const defaultProjId = selectedProjectFilter !== 'all' && selectedProjectFilter !== 'general' 
        ? selectedProjectFilter 
        : (activeProjectId || '');
      const defaultProj = projects.find(p => p.id === defaultProjId);
      setFormProjectId(defaultProjId);
      setFormProjectName(defaultProj ? defaultProj.name : projectName);
    }

    // Default evaluator
    const defaultSupervisor = qualifyingSupervisors.find(s => s.name === currentUser) || qualifyingSupervisors[0];
    setFormEvaluatorId(defaultSupervisor ? defaultSupervisor.id : '');
    setFormEvaluatorName(defaultSupervisor ? defaultSupervisor.name : (currentUser || 'المهندس المشرف'));
    setFormEvaluatorTitle(defaultSupervisor ? defaultSupervisor.profession : 'مهندس ومشرف ميداني');

    setFormDate(new Date().toISOString().split('T')[0]);
    setFormPeriod('');
    setFormCustomRating(null);
    setFormRecommendation('strongly_agree');
    setFormStrengths('');
    setFormWeaknesses('');
    setFormNotes('');
    setFormError('');
    setIsModalOpen(true);
  };

  // Open modal for editing
  const handleOpenEditModal = (evaluation: PerformanceEvaluation) => {
    setEditingEvaluation(evaluation);
    setFormCategory(evaluation.category);
    setFormProjectId(evaluation.projectId || '');
    setFormProjectName(evaluation.projectName || '');
    setFormEntityId(evaluation.entityId);
    setFormEntityName(evaluation.entityName);
    setFormProfessionOrType(evaluation.professionOrType || '');
    setFormDate(evaluation.date);
    setFormPeriod(evaluation.period || '');
    setFormCriteria({ ...evaluation.criteria });
    setFormCustomRating(evaluation.rating);
    setFormEvaluatorId(evaluation.evaluatorId || '');
    setFormEvaluatorName(evaluation.evaluatorName || evaluation.createdBy || currentUser || '');
    setFormEvaluatorTitle(evaluation.evaluatorTitle || 'مهندس ومشرف ميداني');
    setFormRecommendation(evaluation.recommendation || '');
    setFormStrengths(evaluation.strengths || '');
    setFormWeaknesses(evaluation.weaknesses || '');
    setFormNotes(evaluation.notes || '');
    setFormError('');
    setIsModalOpen(true);
  };

  // When changing category in form, update default criteria and clear entity selection if mismatched
  const handleCategoryChange = (newCat: EvaluationCategory) => {
    setFormCategory(newCat);
    setFormEntityId('');
    setFormEntityName('');
    setFormProfessionOrType('');
    const critList = newCat === 'employee' ? EMPLOYEE_CRITERIA : newCat === 'worker' ? WORKER_CRITERIA : SUPPLIER_CRITERIA;
    const initCrit: Record<string, number> = {};
    critList.forEach(c => { initCrit[c.key] = 5; });
    setFormCriteria(initCrit);
    setFormCustomRating(null);
  };

  // When selecting project in form
  const handleFormProjectChange = (projId: string) => {
    setFormProjectId(projId);
    if (!projId) {
      setFormProjectName('');
    } else {
      const p = projects.find(item => item.id === projId);
      setFormProjectName(p ? p.name : '');
    }
  };

  // When selecting an evaluator/supervisor from dropdown
  const handleSelectEvaluator = (empId: string) => {
    setFormEvaluatorId(empId);
    if (!empId) {
      return;
    }
    const found = allProjectEntities.allEmps.find(e => e.id === empId);
    if (found) {
      setFormEvaluatorName(found.name);
      setFormEvaluatorTitle(found.profession || 'مهندس ومشرف ميداني');
    }
  };

  // When selecting an entity from dropdown
  const handleSelectEntity = (id: string) => {
    setFormEntityId(id);
    if (!id) {
      setFormEntityName('');
      setFormProfessionOrType('');
      return;
    }

    if (formCategory === 'employee') {
      const emp = allProjectEntities.allEmps.find(e => e.id === id);
      if (emp) {
        setFormEntityName(emp.name);
        setFormProfessionOrType(emp.profession || 'موظف');
        if (emp.projectId && !formProjectId) {
          setFormProjectId(emp.projectId);
          setFormProjectName(emp.projectName || '');
        }
      }
    } else if (formCategory === 'worker') {
      const w = allProjectEntities.allWrks.find(item => item.id === id);
      if (w) {
        setFormEntityName(w.name);
        setFormProfessionOrType(w.profession || 'عامل');
        if (w.projectId && !formProjectId) {
          setFormProjectId(w.projectId);
          setFormProjectName(w.projectName || '');
        }
      }
    } else if (formCategory === 'supplier') {
      const s = allProjectEntities.allSups.find(item => item.id === id);
      if (s) {
        setFormEntityName(s.name);
        setFormProfessionOrType(s.materialType || 'توريد مواد');
        if (s.projectId && !formProjectId) {
          setFormProjectId(s.projectId);
          setFormProjectName(s.projectName || '');
        }
      }
    }
  };

  // Save evaluation (Add or Edit)
  const handleSubmitEvaluation = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formEntityName.trim()) {
      setFormError('الرجاء اختيار أو إدخال اسم الشخص أو المورد المراد تقييمه');
      return;
    }

    const ratingVal = computedRating;
    const levelInfo = getPerformanceLevelInfo(ratingVal);

    if (editingEvaluation) {
      const updated: PerformanceEvaluation = {
        ...editingEvaluation,
        category: formCategory,
        projectId: formProjectId.trim() || undefined,
        projectName: formProjectName.trim() || undefined,
        entityId: formEntityId || editingEvaluation.entityId || `custom_${Date.now()}`,
        entityName: formEntityName.trim(),
        professionOrType: formProfessionOrType.trim(),
        date: formDate,
        period: formPeriod.trim() || undefined,
        rating: ratingVal,
        performanceLevel: levelInfo.level,
        criteria: formCriteria,
        recommendation: formRecommendation || undefined,
        strengths: formStrengths.trim() || undefined,
        weaknesses: formWeaknesses.trim() || undefined,
        notes: formNotes.trim() || undefined,
        evaluatorId: formEvaluatorId || undefined,
        evaluatorName: formEvaluatorName.trim() || currentUser || 'المهندس المشرف',
        evaluatorTitle: formEvaluatorTitle.trim() || 'مهندس ومشرف ميداني',
        updatedAt: new Date().toISOString()
      };
      onUpdateEvaluation(updated);
    } else {
      const newEval: Omit<PerformanceEvaluation, 'id' | 'createdAt' | 'updatedAt'> = {
        category: formCategory,
        projectId: formProjectId.trim() || undefined,
        projectName: formProjectName.trim() || undefined,
        entityId: formEntityId || `custom_${Date.now()}`,
        entityName: formEntityName.trim(),
        professionOrType: formProfessionOrType.trim(),
        date: formDate,
        period: formPeriod.trim() || undefined,
        rating: ratingVal,
        performanceLevel: levelInfo.level,
        criteria: formCriteria,
        recommendation: formRecommendation || undefined,
        strengths: formStrengths.trim() || undefined,
        weaknesses: formWeaknesses.trim() || undefined,
        notes: formNotes.trim() || undefined,
        evaluatorId: formEvaluatorId || undefined,
        evaluatorName: formEvaluatorName.trim() || currentUser || 'المهندس المشرف',
        evaluatorTitle: formEvaluatorTitle.trim() || 'مهندس ومشرف ميداني',
        createdBy: currentUser
      };
      onAddEvaluation(newEval);
    }

    setIsModalOpen(false);
  };

  // Filtered evaluations calculation
  const filteredEvaluations = useMemo(() => {
    return evaluations.filter(item => {
      // Category filter
      if (activeCategoryTab !== 'all' && item.category !== activeCategoryTab) {
        return false;
      }
      // Project filter
      if (selectedProjectFilter !== 'all') {
        if (selectedProjectFilter === 'general') {
          if (item.projectId) return false;
        } else if (item.projectId !== selectedProjectFilter) {
          return false;
        }
      }
      // Specific entity filter
      if (selectedEntityId !== 'all' && item.entityId !== selectedEntityId) {
        return false;
      }
      // Performance Level filter
      if (selectedPerformanceLevel !== 'all' && item.performanceLevel !== selectedPerformanceLevel) {
        return false;
      }
      // Date range filter
      if (startDateFilter && item.date < startDateFilter) {
        return false;
      }
      if (endDateFilter && item.date > endDateFilter) {
        return false;
      }
      // Search term (name, profession, period, notes, creator, project)
      if (searchTerm.trim()) {
        const query = searchTerm.toLowerCase().trim();
        const matchName = item.entityName.toLowerCase().includes(query);
        const matchProf = (item.professionOrType || '').toLowerCase().includes(query);
        const matchPeriod = (item.period || '').toLowerCase().includes(query);
        const matchNotes = (item.notes || '').toLowerCase().includes(query);
        const matchCreator = (item.createdBy || '').toLowerCase().includes(query);
        const matchProj = (item.projectName || '').toLowerCase().includes(query);
        if (!matchName && !matchProf && !matchPeriod && !matchNotes && !matchCreator && !matchProj) {
          return false;
        }
      }
      return true;
    }).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [
    evaluations, 
    activeCategoryTab, 
    selectedProjectFilter,
    selectedEntityId, 
    selectedPerformanceLevel, 
    startDateFilter, 
    endDateFilter, 
    searchTerm
  ]);

  // Aggregated People / Suppliers list with their average ratings
  const aggregatedEntities = useMemo(() => {
    // Collect all entities from allProjectEntities AND custom ones from evaluations
    const list: Array<{
      id: string;
      name: string;
      category: EvaluationCategory;
      professionOrType: string;
      projectId?: string;
      projectName?: string;
      evaluationsCount: number;
      averageRating: number;
      lastEvaluation?: PerformanceEvaluation;
      performanceLevel: PerformanceLevel;
    }> = [];

    const map = new Map<string, typeof list[0]>();

    // 1. Add employees
    allProjectEntities.allEmps.forEach(emp => {
      const key = `employee_${emp.id}`;
      if (!map.has(key)) {
        map.set(key, {
          id: emp.id,
          name: emp.name,
          category: 'employee',
          professionOrType: emp.profession || 'موظف',
          projectId: emp.projectId,
          projectName: emp.projectName,
          evaluationsCount: 0,
          averageRating: 0,
          performanceLevel: 'good'
        });
      }
    });

    // 2. Add workers
    allProjectEntities.allWrks.forEach(w => {
      const key = `worker_${w.id}`;
      if (!map.has(key)) {
        map.set(key, {
          id: w.id,
          name: w.name,
          category: 'worker',
          professionOrType: w.profession || 'عامل',
          projectId: w.projectId,
          projectName: w.projectName,
          evaluationsCount: 0,
          averageRating: 0,
          performanceLevel: 'good'
        });
      }
    });

    // 3. Add suppliers
    allProjectEntities.allSups.forEach(s => {
      const key = `supplier_${s.id}`;
      if (!map.has(key)) {
        map.set(key, {
          id: s.id,
          name: s.name,
          category: 'supplier',
          professionOrType: s.materialType || 'مورد مواد',
          projectId: s.projectId,
          projectName: s.projectName,
          evaluationsCount: 0,
          averageRating: 0,
          performanceLevel: 'good'
        });
      }
    });

    // 4. Also register any evaluation entityId not in current lists
    evaluations.forEach(ev => {
      const key = `${ev.category}_${ev.entityId}`;
      if (!map.has(key)) {
        map.set(key, {
          id: ev.entityId,
          name: ev.entityName,
          category: ev.category,
          professionOrType: ev.professionOrType || '',
          projectId: ev.projectId,
          projectName: ev.projectName,
          evaluationsCount: 0,
          averageRating: 0,
          performanceLevel: 'good'
        });
      }
    });

    // 5. Calculate stats for each based on evaluations (honoring project filter if selected)
    map.forEach((item) => {
      const userEvals = evaluations
        .filter(ev => {
          const matchCategory = ev.category === item.category;
          const matchIdOrName = ev.entityId === item.id || ev.entityName === item.name;
          if (!matchCategory || !matchIdOrName) return false;
          if (selectedProjectFilter !== 'all') {
            if (selectedProjectFilter === 'general') {
              if (ev.projectId) return false;
            } else if (ev.projectId !== selectedProjectFilter) {
              return false;
            }
          }
          return true;
        })
        .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

      item.evaluationsCount = userEvals.length;
      if (userEvals.length > 0) {
        const sum = userEvals.reduce((acc, ev) => acc + ev.rating, 0);
        item.averageRating = Math.round((sum / userEvals.length) * 10) / 10;
        item.lastEvaluation = userEvals[0];
        item.performanceLevel = getPerformanceLevelInfo(item.averageRating).level;
      } else {
        item.averageRating = 0;
      }

      // If project filter is applied and item has no evaluations in this project and doesn't belong to it, filter out
      if (selectedProjectFilter !== 'all' && selectedProjectFilter !== 'general') {
        if (item.projectId !== selectedProjectFilter && item.evaluationsCount === 0) {
          return;
        }
      }

      list.push(item);
    });

    // Filter by active tab, performance level and search
    return list.filter(item => {
      if (activeCategoryTab !== 'all' && item.category !== activeCategoryTab) {
        return false;
      }
      if (selectedPerformanceLevel !== 'all') {
        if (item.evaluationsCount === 0) return false;
        if (item.performanceLevel !== selectedPerformanceLevel) return false;
      }
      if (searchTerm.trim()) {
        const q = searchTerm.toLowerCase().trim();
        const matchName = item.name.toLowerCase().includes(q);
        const matchProf = (item.professionOrType || '').toLowerCase().includes(q);
        const matchProj = (item.projectName || '').toLowerCase().includes(q);
        if (!matchName && !matchProf && !matchProj) return false;
      }
      return true;
    }).sort((a, b) => {
      if (b.evaluationsCount !== a.evaluationsCount) {
        return b.evaluationsCount - a.evaluationsCount;
      }
      return b.averageRating - a.averageRating;
    });
  }, [allProjectEntities, evaluations, activeCategoryTab, selectedProjectFilter, selectedPerformanceLevel, searchTerm]);

  // Filtered Stats Calculation
  const stats = useMemo(() => {
    const totalCount = filteredEvaluations.length;
    if (totalCount === 0) {
      return {
        totalCount: 0,
        averageRating: 0,
        excellentCount: 0,
        veryGoodCount: 0,
        goodCount: 0,
        poorCount: 0,
        veryPoorCount: 0,
        ratedEntitiesCount: 0
      };
    }
    const sum = filteredEvaluations.reduce((acc, ev) => acc + ev.rating, 0);
    const avg = Math.round((sum / totalCount) * 10) / 10;

    const excellentCount = filteredEvaluations.filter(e => e.performanceLevel === 'excellent').length;
    const veryGoodCount = filteredEvaluations.filter(e => e.performanceLevel === 'very_good').length;
    const goodCount = filteredEvaluations.filter(e => e.performanceLevel === 'good').length;
    const poorCount = filteredEvaluations.filter(e => e.performanceLevel === 'poor').length;
    const veryPoorCount = filteredEvaluations.filter(e => e.performanceLevel === 'very_poor').length;

    const uniqueEntities = new Set(filteredEvaluations.map(e => `${e.category}_${e.entityId}`));

    return {
      totalCount,
      averageRating: avg,
      excellentCount,
      veryGoodCount,
      goodCount,
      poorCount,
      veryPoorCount,
      ratedEntitiesCount: uniqueEntities.size
    };
  }, [filteredEvaluations]);

  // Export to Excel
  const handleExportXLSX = () => {
    if (filteredEvaluations.length === 0) {
      alert('لا توجد تقييمات لتصديرها وفق خيارات التصفية الحالية.');
      return;
    }

    const headers = [
      'التاريخ',
      'الفئة',
      'الاسم',
      'المشروع',
      'المسمى / نوع المواد',
      'فترة التقييم',
      'الدرجة (من 5)',
      'مستوى الأداء',
      'المشرف / المقيم',
      'صفة المشرف',
      'التوصية',
      'نقاط القوة / إيجابيات',
      'نقاط الضعف / سلبيات',
      'ملاحظات أخرى',
      'تفاصيل المعايير'
    ];

    const categoryArabic = {
      employee: 'موظف',
      worker: 'عامل',
      supplier: 'مورد'
    };

    const rows = filteredEvaluations.map(ev => {
      const levelInfo = getPerformanceLevelInfo(ev.rating);
      const criteriaStr = Object.entries(ev.criteria || {})
        .map(([k, v]) => `${getCriterionLabel(ev.category, k)}: ${v}/5`)
        .join(' | ');

      const recText = ev.recommendation ? getRecommendationLabel(ev.recommendation) : '-';

      return [
        ev.date,
        categoryArabic[ev.category] || ev.category,
        ev.entityName,
        ev.projectName || 'عام',
        ev.professionOrType || '-',
        ev.period || '-',
        ev.rating,
        levelInfo.label,
        ev.evaluatorName || ev.createdBy || '-',
        ev.evaluatorTitle || '-',
        recText,
        ev.strengths || '-',
        ev.weaknesses || '-',
        ev.notes || '-',
        criteriaStr || '-'
      ];
    });

    const dateStr = getFormattedReportDate();
    exportToXLSX(`تقرير_تقييم_الأداء_الشامل_${dateStr}`, headers, rows, 'تقييم الأداء');
  };

  // Print PDF Report
  const handlePrintPDF = () => {
    if (filteredEvaluations.length === 0) {
      alert('لا توجد تقييمات لطباعتها وفق خيارات التصفية الحالية.');
      return;
    }

    const categoryArabic = {
      employee: 'موظف',
      worker: 'عامل',
      supplier: 'مورد'
    };

    const rowsHtml = filteredEvaluations.map((ev, index) => {
      const levelInfo = getPerformanceLevelInfo(ev.rating);
      const starsHtml = '⭐'.repeat(Math.min(5, Math.max(1, Math.round(ev.rating))));
      const recText = ev.recommendation ? getRecommendationLabel(ev.recommendation) : '';
      
      // Detailed criteria breakdown
      let critDetails = '';
      if (ev.criteria && Object.keys(ev.criteria).length > 0) {
        const critList = ev.category === 'employee' ? EMPLOYEE_CRITERIA : ev.category === 'worker' ? WORKER_CRITERIA : SUPPLIER_CRITERIA;
        critDetails = critList.map(c => {
          const val = ev.criteria[c.key] || 0;
          return `<span style="display:inline-block; margin-left:6px; margin-bottom:3px; font-size:10px; background:#f1f5f9; padding:2px 5px; border-radius:4px;">${c.label}: <b>${val}/5</b></span>`;
        }).join(' ');
      }

      return `
        <tr style="border-bottom: 1px solid #e2e8f0;">
          <td style="padding: 6px; text-align: center; font-size: 11px;">${index + 1}</td>
          <td style="padding: 6px; font-size: 11px; white-space: nowrap;">${ev.date}</td>
          <td style="padding: 6px; font-size: 11px;">
            <b>${ev.entityName}</b>
            <div style="font-size: 10px; color: #64748b;">${categoryArabic[ev.category]} - ${ev.professionOrType || ''}</div>
            ${ev.projectName ? `<div style="font-size: 9px; color: #4338ca;">مشروع: ${ev.projectName}</div>` : ''}
          </td>
          <td style="padding: 6px; font-size: 11px; text-align: center;">${ev.period || '-'}</td>
          <td style="padding: 6px; font-size: 12px; text-align: center; font-weight: bold; color: #0284c7;">
            ${ev.rating} / 5
            <div style="font-size: 10px;">${starsHtml}</div>
          </td>
          <td style="padding: 6px; font-size: 11px; text-align: center;">
            <span style="font-weight: bold; padding: 2px 6px; border-radius: 4px; background: #f8fafc; border: 1px solid #cbd5e1;">${levelInfo.label}</span>
            ${recText ? `<div style="font-size: 9px; color: #059669; margin-top: 3px; font-weight: bold;">توصية: ${recText}</div>` : ''}
          </td>
          <td style="padding: 6px; font-size: 10px;">
            ${critDetails || '-'}
            ${ev.strengths ? `<div style="margin-top: 3px; color: #047857; font-size: 10px;"><b>👍 نقاط القوة:</b> ${ev.strengths}</div>` : ''}
            ${ev.weaknesses ? `<div style="margin-top: 2px; color: #b91c1c; font-size: 10px;"><b>⚠️ نقاط الضعف:</b> ${ev.weaknesses}</div>` : ''}
            ${ev.notes ? `<div style="margin-top: 2px; color: #475569; font-style: italic; font-size: 10px;"><b>📝 ملاحظات أخرى:</b> ${ev.notes}</div>` : ''}
          </td>
          <td style="padding: 6px; font-size: 10px; text-align: center; color: #334155;">
            <b>${ev.evaluatorName || ev.createdBy || '-'}</b>
            ${ev.evaluatorTitle ? `<div style="font-size: 9px; color: #64748b;">${ev.evaluatorTitle}</div>` : ''}
          </td>
        </tr>
      `;
    }).join('');

    const htmlContent = `
      <div style="margin-bottom: 20px;">
        <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 15px; margin-bottom: 20px;">
          <h3 style="margin: 0 0 10px 0; color: #1e293b; font-size: 16px;">ملخص إحصائيات تقييم الأداء</h3>
          <div style="display: flex; gap: 20px; flex-wrap: wrap; font-size: 13px;">
            <div>إجمالي عدد التقييمات: <b>${stats.totalCount}</b></div>
            <div>متوسط التقييم العام: <b style="color: #0284c7;">${stats.averageRating} / 5 ⭐</b></div>
            <div>عدد الأشخاص/الموردين المقيّمين: <b>${stats.ratedEntitiesCount}</b></div>
            <div>ممتاز (5 نجوم): <b style="color: #059669;">${stats.excellentCount}</b></div>
            <div>جيد جداً (4 نجوم): <b style="color: #0284c7;">${stats.veryGoodCount}</b></div>
            <div>جيد (3 نجوم): <b style="color: #d97706;">${stats.goodCount}</b></div>
            <div>ضعيف أو أقل: <b style="color: #dc2626;">${stats.poorCount + stats.veryPoorCount}</b></div>
          </div>
        </div>

        <table style="width: 100%; border-collapse: collapse; margin-top: 10px; font-family: 'Cairo', sans-serif;">
          <thead>
            <tr style="background-color: #1e293b; color: white;">
              <th style="padding: 8px; border: 1px solid #0f172a; text-align: center; width: 25px;">#</th>
              <th style="padding: 8px; border: 1px solid #0f172a; text-align: right; width: 75px;">التاريخ</th>
              <th style="padding: 8px; border: 1px solid #0f172a; text-align: right;">الاسم والفئة</th>
              <th style="padding: 8px; border: 1px solid #0f172a; text-align: center; width: 70px;">الفترة</th>
              <th style="padding: 8px; border: 1px solid #0f172a; text-align: center; width: 85px;">الدرجة</th>
              <th style="padding: 8px; border: 1px solid #0f172a; text-align: center; width: 85px;">المستوى والتوصية</th>
              <th style="padding: 8px; border: 1px solid #0f172a; text-align: right;">المعايير والنقاط والملاحظات</th>
              <th style="padding: 8px; border: 1px solid #0f172a; text-align: center; width: 85px;">المشرف / المقيم</th>
            </tr>
          </thead>
          <tbody>
            ${rowsHtml}
          </tbody>
        </table>
      </div>
    `;

    printPDF('تقرير تقييم الأداء الشامل', htmlContent);
  };

  // Render Star Rating Selector Component
  const renderStarInput = (val: number, onChange: (rating: number) => void, size = 20) => {
    return (
      <div className="flex items-center gap-1">
        {[1, 2, 3, 4, 5].map((star) => (
          <button
            key={star}
            type="button"
            onClick={() => onChange(star)}
            className={`p-1 rounded-lg transition-transform hover:scale-110 cursor-pointer ${
              val >= star ? 'text-amber-400' : 'text-slate-200 hover:text-amber-200'
            }`}
            title={`${star} نجوم`}
          >
            <Star size={size} fill={val >= star ? 'currentColor' : 'none'} />
          </button>
        ))}
        <span className="text-xs font-bold text-slate-700 mr-1.5 w-6 text-center">{val}/5</span>
      </div>
    );
  };

  return (
    <div className="space-y-4 pb-20 animate-fade-in text-slate-800">
      
      {/* 1. Standard Page Header Card */}
      <PageHeaderCard
        title="تقييم الأداء والجودة"
        description="نظام تقييم مركزي شامل للموظفين والعمال والموردين يربط كافة المشاريع بمعايير الجودة والانضباط"
        icon={<Award className="text-amber-500" size={24} />}
        onBack={setActiveTab ? () => {
          setActiveTab('main_hub');
          window.scrollTo({ top: 0, behavior: 'smooth' });
        } : undefined}
        optionsMenu={
          <OptionsMenu
            customActions={sharedRole !== 'read' ? [
              {
                label: 'إضافة تقييم جديد',
                icon: <Plus size={15} className="text-amber-600 shrink-0" />,
                onClick: () => handleOpenAddModal(),
                className: 'text-amber-700 bg-amber-50/70 hover:bg-amber-100 hover:text-amber-800'
              }
            ] : []}
            onExportExcel={handleExportXLSX}
            onExportPDF={handlePrintPDF}
            shareTitle="تقرير تقييم الأداء والجودة"
            shareText={() => {
              return `⭐ تقرير تقييم الأداء والجودة:\n📊 إجمالي التقييمات: ${evaluations.length}\n💼 الموظفون: ${evaluations.filter(e => e.category === 'employee').length}\n👷 العمال: ${evaluations.filter(e => e.category === 'worker').length}\n🚚 الموردون: ${evaluations.filter(e => e.category === 'supplier').length}\n\n*تم الاستخراج من نظام إدارة المشاريع*`;
            }}
          />
        }
      />

      {/* Category Tabs Bar */}
      <div className="bg-white p-2 rounded-2xl border border-slate-200/80 shadow-xs flex items-center gap-2 overflow-x-auto no-scrollbar">
        <button
          onClick={() => { setActiveCategoryTab('all'); setSelectedEntityId('all'); }}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 shrink-0 cursor-pointer ${
            activeCategoryTab === 'all'
              ? 'bg-amber-500 text-slate-950 shadow-xs font-black'
              : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
          }`}
        >
          <Layers size={14} />
          <span>الكل ({evaluations.length})</span>
        </button>

        <button
          onClick={() => { setActiveCategoryTab('employee'); setSelectedEntityId('all'); }}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 shrink-0 cursor-pointer ${
            activeCategoryTab === 'employee'
              ? 'bg-indigo-600 text-white shadow-xs font-black'
              : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
          }`}
        >
          <Briefcase size={14} />
          <span>الموظفون ({evaluations.filter(e => e.category === 'employee').length})</span>
        </button>

        <button
          onClick={() => { setActiveCategoryTab('worker'); setSelectedEntityId('all'); }}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 shrink-0 cursor-pointer ${
            activeCategoryTab === 'worker'
              ? 'bg-sky-600 text-white shadow-xs font-black'
              : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
          }`}
        >
          <Users size={14} />
          <span>العمال ({evaluations.filter(e => e.category === 'worker').length})</span>
        </button>

        <button
          onClick={() => { setActiveCategoryTab('supplier'); setSelectedEntityId('all'); }}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 shrink-0 cursor-pointer ${
            activeCategoryTab === 'supplier'
              ? 'bg-amber-500 text-slate-950 shadow-xs font-black'
              : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
          }`}
        >
          <Truck size={14} />
          <span>الموردون ({evaluations.filter(e => e.category === 'supplier').length})</span>
        </button>
      </div>

      {/* 2. Statistical Metric Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-4 gap-3">
        {/* Total Evaluations */}
        <div className="bg-white p-3.5 sm:p-4 rounded-2xl border border-slate-200/80 shadow-xs flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center shrink-0">
            <Award size={20} />
          </div>
          <div>
            <span className="text-[11px] font-bold text-slate-400 block">إجمالي التقييمات</span>
            <span className="text-lg font-black text-slate-800">{stats.totalCount} تقييم</span>
          </div>
        </div>

        {/* Average Rating */}
        <div className="bg-white p-3.5 sm:p-4 rounded-2xl border border-slate-200/80 shadow-xs flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center shrink-0">
            <Star size={20} />
          </div>
          <div>
            <span className="text-[11px] font-bold text-slate-400 block">متوسط التقييم العام</span>
            <div className="flex items-center gap-1.5">
              <span className="text-lg font-black text-slate-800">{stats.averageRating} / 5</span>
              <span className="text-amber-400 text-xs">⭐</span>
            </div>
          </div>
        </div>

        {/* Top Rated (Excellent) */}
        <div className="bg-white p-3.5 sm:p-4 rounded-2xl border border-slate-200/80 shadow-xs flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
            <TrendingUp size={20} />
          </div>
          <div>
            <span className="text-[11px] font-bold text-slate-400 block">تقييم ممتاز (5★)</span>
            <span className="text-lg font-black text-emerald-600">{stats.excellentCount} سجل</span>
          </div>
        </div>

        {/* Rated Entities Count */}
        <div className="bg-white p-3.5 sm:p-4 rounded-2xl border border-slate-200/80 shadow-xs flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-sky-50 text-sky-600 flex items-center justify-center shrink-0">
            <UserCheck size={20} />
          </div>
          <div>
            <span className="text-[11px] font-bold text-slate-400 block">الكوادر المقيمة</span>
            <span className="text-lg font-black text-slate-800">{stats.ratedEntitiesCount} شخص / جهة</span>
          </div>
        </div>
      </div>

      {/* 3. Search, View Switcher & Filters Bar */}
      <div className="bg-white p-3.5 rounded-2xl border border-slate-200/80 shadow-xs space-y-3">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5">
          
          {/* Search Box */}
          <div className="relative flex-1">
            <Search size={16} className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="ابحث بالاسم، المهنة، فترة التقييم، اسم المشروع، أو الملاحظات..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-3 pr-9 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-semibold text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500"
            />
            {searchTerm && (
              <button
                onClick={() => setSearchTerm('')}
                className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-0.5 cursor-pointer"
              >
                <X size={14} />
              </button>
            )}
          </div>

          {/* Project Filter Dropdown */}
          <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5 shrink-0">
            <Building2 size={14} className="text-indigo-600 shrink-0" />
            <span className="text-xs font-bold text-slate-600 shrink-0">المشروع:</span>
            <select
              value={selectedProjectFilter}
              onChange={(e) => setSelectedProjectFilter(e.target.value)}
              className="bg-transparent text-xs font-bold text-slate-800 focus:outline-none cursor-pointer max-w-[160px] truncate"
            >
              <option value="all">كافة المشاريع (الكل)</option>
              <option value="general">عام / بدون مشروع محدد</option>
              {projects.map(p => (
                <option key={p.id} value={p.id}>{p.name}</option>
              ))}
            </select>
          </div>

          {/* View Mode Toggle (People Cards vs History Log) */}
          <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-xl shrink-0">
            <button
              onClick={() => setViewMode('people')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                viewMode === 'people'
                  ? 'bg-white text-slate-800 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Users size={14} />
              <span>سجل الكوادر</span>
            </button>

            <button
              onClick={() => setViewMode('history')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                viewMode === 'history'
                  ? 'bg-white text-slate-800 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Clock size={14} />
              <span>سجل التقييمات التفصيلي</span>
            </button>
          </div>

          {/* Filter Drawer Toggle */}
          <button
            onClick={() => setShowFilterDrawer(!showFilterDrawer)}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold border transition-colors flex items-center justify-center gap-1.5 cursor-pointer shrink-0 ${
              showFilterDrawer || selectedPerformanceLevel !== 'all' || startDateFilter || endDateFilter || selectedProjectFilter !== 'all'
                ? 'bg-amber-50 border-amber-300 text-amber-800'
                : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
            }`}
          >
            <SlidersHorizontal size={14} />
            <span>تصفية متقدمة</span>
            {(selectedPerformanceLevel !== 'all' || startDateFilter || endDateFilter || selectedProjectFilter !== 'all') && (
              <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse"></span>
            )}
          </button>
        </div>

        {/* Expandable Advanced Filters */}
        {showFilterDrawer && (
          <div className="pt-3 border-t border-slate-100 grid grid-cols-1 sm:grid-cols-3 gap-2.5 animate-fade-in text-xs font-semibold">
            {/* Filter by Performance Level */}
            <div>
              <label className="block text-slate-600 font-bold mb-1">مستوى التقييم</label>
              <select
                value={selectedPerformanceLevel}
                onChange={(e) => setSelectedPerformanceLevel(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 focus:outline-none focus:border-amber-500 cursor-pointer"
              >
                <option value="all">جميع المستويات</option>
                <option value="excellent">ممتاز (5 نجوم ⭐⭐⭐⭐⭐)</option>
                <option value="very_good">جيد جداً (4 نجوم ⭐⭐⭐⭐)</option>
                <option value="good">جيد (3 نجوم ⭐⭐⭐)</option>
                <option value="poor">ضعيف (نجمتان ⭐⭐)</option>
                <option value="very_poor">ضعيف جداً (نجمة واحدة ⭐)</option>
              </select>
            </div>

            {/* Date From */}
            <div>
              <label className="block text-slate-600 font-bold mb-1">من تاريخ</label>
              <input
                type="date"
                value={startDateFilter}
                onChange={(e) => setStartDateFilter(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 focus:outline-none focus:border-amber-500"
              />
            </div>

            {/* Date To */}
            <div>
              <label className="block text-slate-600 font-bold mb-1">إلى تاريخ</label>
              <input
                type="date"
                value={endDateFilter}
                onChange={(e) => setEndDateFilter(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 focus:outline-none focus:border-amber-500"
              />
            </div>

            {/* Reset Filter Button */}
            {(selectedPerformanceLevel !== 'all' || startDateFilter || endDateFilter || selectedProjectFilter !== 'all') && (
              <div className="sm:col-span-3 flex justify-end">
                <button
                  onClick={() => {
                    setSelectedPerformanceLevel('all');
                    setSelectedProjectFilter('all');
                    setStartDateFilter('');
                    setEndDateFilter('');
                  }}
                  className="text-xs font-bold text-rose-600 hover:text-rose-700 hover:underline flex items-center gap-1 cursor-pointer"
                >
                  <RotateCcw size={12} />
                  <span>إلغاء وتفريغ فلاتر التصفية</span>
                </button>
              </div>
            )}
          </div>
        )}

        {/* Dynamic Filter Results Summary */}
        <div className="flex items-center justify-between text-xs text-slate-500 font-medium px-1 pt-1 border-t border-slate-100">
          <div className="flex items-center gap-2">
            <span>
              عدد النتائج المعروضة: <strong className="text-slate-800">{viewMode === 'people' ? aggregatedEntities.length : filteredEvaluations.length}</strong>
            </span>
            {selectedProjectFilter !== 'all' && (
              <span className="bg-indigo-50 text-indigo-700 text-[10px] font-bold px-2 py-0.5 rounded-md border border-indigo-200">
                مشروع: {selectedProjectFilter === 'general' ? 'عام' : (projects.find(p => p.id === selectedProjectFilter)?.name || selectedProjectFilter)}
              </span>
            )}
          </div>
          {stats.totalCount > 0 && (
            <span>
              متوسط التقييم للنتائج: <strong className="text-amber-600 font-bold">{stats.averageRating} / 5 ⭐</strong>
            </span>
          )}
        </div>
      </div>

      {/* 4. MAIN CONTENT AREA */}
      {viewMode === 'people' ? (
        /* ================= MODE 1: PEOPLE / SUPPLIERS CARDS ================= */
        <div>
          {aggregatedEntities.length === 0 ? (
            <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center space-y-3">
              <div className="w-14 h-14 bg-slate-100 text-slate-400 rounded-full flex items-center justify-center mx-auto">
                <Users size={24} />
              </div>
              <h3 className="text-sm font-bold text-slate-700">لا توجد سجلات مطابقة لخيارات البحث والتصفية</h3>
              <p className="text-xs text-slate-400">يمكنك البدء بإضافة تقييم جديد للموظفين أو العمال أو الموردين</p>
              {sharedRole !== 'read' && (
                <button
                  onClick={() => handleOpenAddModal()}
                  className="bg-amber-500 hover:bg-amber-600 text-slate-950 font-black text-xs py-2 px-4 rounded-xl transition-all inline-flex items-center gap-1.5 cursor-pointer shadow-xs"
                >
                  <Plus size={14} />
                  <span>إضافة أول تقييم الآن</span>
                </button>
              )}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
              {aggregatedEntities.map(item => {
                const levelInfo = item.evaluationsCount > 0 
                  ? getPerformanceLevelInfo(item.averageRating)
                  : { label: 'لم يقيّم بعد', color: 'text-slate-400', badgeBg: 'bg-slate-100 text-slate-500', badgeBorder: 'border-slate-200', stars: 0 };

                const categoryBadge = {
                  employee: { label: 'موظف', bg: 'bg-indigo-50 text-indigo-700 border-indigo-200' },
                  worker: { label: 'عامل', bg: 'bg-sky-50 text-sky-700 border-sky-200' },
                  supplier: { label: 'مورد', bg: 'bg-amber-50 text-amber-700 border-amber-200' }
                }[item.category];

                return (
                  <div 
                    key={`${item.category}_${item.id}`}
                    className="bg-white rounded-2xl border border-slate-200/90 shadow-xs hover:shadow-md transition-all p-4 flex flex-col justify-between space-y-3 relative group"
                  >
                    {/* Card Top */}
                    <div>
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-center gap-2.5">
                          <div className="w-10 h-10 rounded-xl bg-slate-100 border border-slate-200 flex items-center justify-center font-bold text-slate-700 text-sm shrink-0">
                            {item.name.charAt(0)}
                          </div>
                          <div>
                            <h3 className="font-extrabold text-slate-800 text-sm leading-tight">{item.name}</h3>
                            <span className="text-[11px] text-slate-400 font-semibold">{item.professionOrType || '-'}</span>
                          </div>
                        </div>

                        <div className="flex flex-col items-end gap-1">
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${categoryBadge.bg}`}>
                            {categoryBadge.label}
                          </span>
                          {item.projectName && (
                            <span className="text-[9px] font-bold px-1.5 py-0.5 rounded-md bg-slate-100 text-slate-600 border border-slate-200 flex items-center gap-1">
                              <Building2 size={10} className="text-slate-500" />
                              {item.projectName}
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Rating Score & Level */}
                      <div className="mt-3.5 p-2.5 bg-slate-50 rounded-xl border border-slate-100 flex items-center justify-between">
                        <div>
                          <span className="text-[10px] text-slate-400 font-bold block">متوسط الأداء:</span>
                          <div className="flex items-center gap-1.5 mt-0.5">
                            {item.evaluationsCount > 0 ? (
                              <>
                                <span className="text-base font-black text-slate-800">{item.averageRating}</span>
                                <span className="text-amber-400 text-xs font-bold">⭐</span>
                                <span className={`text-[10px] font-black px-2 py-0.5 rounded-md border ${levelInfo.badgeBg} ${levelInfo.badgeBorder}`}>
                                  {levelInfo.label}
                                </span>
                              </>
                            ) : (
                              <span className="text-xs text-slate-400 font-bold">لا يوجد تقييمات</span>
                            )}
                          </div>
                        </div>

                        <div className="text-left">
                          <span className="text-[10px] text-slate-400 font-bold block">عدد التقييمات:</span>
                          <span className="text-xs font-black text-slate-700 block mt-0.5">{item.evaluationsCount} سجل</span>
                        </div>
                      </div>

                      {/* Last Evaluation Note */}
                      {item.lastEvaluation && (
                        <div className="mt-2.5 text-[11px] text-slate-500 bg-slate-50/70 p-2 rounded-lg border border-slate-100">
                          <div className="flex items-center justify-between font-bold text-slate-600 mb-0.5">
                            <span>آخر تقييم: {item.lastEvaluation.date}</span>
                            <span>{item.lastEvaluation.rating}/5 ⭐</span>
                          </div>
                          {item.lastEvaluation.projectName && (
                            <span className="text-[10px] text-indigo-600 font-semibold block">
                              مشروع: {item.lastEvaluation.projectName}
                            </span>
                          )}
                          {item.lastEvaluation.notes && (
                            <p className="text-[10px] text-slate-500 line-clamp-1 italic mt-0.5">
                              "{item.lastEvaluation.notes}"
                            </p>
                          )}
                        </div>
                      )}
                    </div>

                    {/* Card Actions */}
                    <div className="pt-2 border-t border-slate-100 space-y-1.5">
                      <div className="flex items-center justify-between gap-1.5">
                        <button
                          onClick={() => setHistoryModalEntity({ id: item.id, name: item.name, category: item.category, projectId: item.projectId, projectName: item.projectName })}
                          className="text-xs font-bold text-indigo-600 hover:text-indigo-800 hover:bg-indigo-50 px-2 py-1.5 rounded-lg transition-colors cursor-pointer flex items-center gap-1"
                        >
                          <Clock size={13} />
                          <span>السجل التفصيلي ({item.evaluationsCount})</span>
                        </button>

                        {sharedRole !== 'read' && (
                          <button
                            onClick={() => handleOpenAddModal(item.category, { id: item.id, name: item.name, professionOrType: item.professionOrType, projectId: item.projectId, projectName: item.projectName })}
                            className="text-xs font-bold bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200 px-2.5 py-1.5 rounded-lg transition-colors cursor-pointer flex items-center gap-1 shadow-2xs"
                          >
                            <Plus size={13} />
                            <span>تقييم</span>
                          </button>
                        )}
                      </div>

                      {/* Direct Two-Way link to Worker/Employee/Supplier Ledger */}
                      {onNavigateToEntityLedger && (
                        <button
                          type="button"
                          onClick={() => onNavigateToEntityLedger(item.category, item.id, item.projectId)}
                          className="w-full text-[11px] font-bold text-slate-600 hover:text-indigo-700 bg-slate-50 hover:bg-indigo-50/70 p-1.5 rounded-lg border border-slate-200 transition-colors flex items-center justify-center gap-1 cursor-pointer"
                        >
                          <Receipt size={12} className="text-indigo-500" />
                          <span>فتح لوحة وكشف حساب {categoryBadge.label}</span>
                          <ExternalLink size={11} className="text-slate-400" />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      ) : (
        /* ================= MODE 2: DETAILED CHRONOLOGICAL HISTORY TABLE ================= */
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
          {filteredEvaluations.length === 0 ? (
            <div className="p-8 text-center space-y-3">
              <div className="w-14 h-14 bg-slate-100 text-slate-400 rounded-full flex items-center justify-center mx-auto">
                <Clock size={24} />
              </div>
              <h3 className="text-sm font-bold text-slate-700">لا توجد حركات تقييم مسجلة في هذا السجل</h3>
              <p className="text-xs text-slate-400">ابدأ بإضافة تقييم جديد لحفظ وتوثيق أداء الكوادر والموردين</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-right border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-900 text-white font-bold border-b border-slate-800">
                    <th className="py-3 px-3.5 text-right">التاريخ</th>
                    <th className="py-3 px-3.5 text-right">الاسم والفئة</th>
                    <th className="py-3 px-3.5 text-right">المشروع</th>
                    <th className="py-3 px-3.5 text-right">الفترة</th>
                    <th className="py-3 px-3.5 text-center">الدرجة</th>
                    <th className="py-3 px-3.5 text-center">المستوى والتوصية</th>
                    <th className="py-3 px-3.5 text-right">المعايير والنقاط والملاحظات</th>
                    <th className="py-3 px-3.5 text-center">المشرف / المُقيِّم</th>
                    {sharedRole !== 'read' && <th className="py-3 px-3.5 text-center">الإجراءات</th>}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-semibold text-slate-700">
                  {filteredEvaluations.map(ev => {
                    const levelInfo = getPerformanceLevelInfo(ev.rating);
                    const categoryArabic = {
                      employee: 'موظف',
                      worker: 'عامل',
                      supplier: 'مورد'
                    }[ev.category];

                    const recText = ev.recommendation ? getRecommendationLabel(ev.recommendation) : null;

                    return (
                      <tr key={ev.id} className="hover:bg-slate-50/80 transition-colors">
                        <td className="py-3 px-3.5 font-bold text-slate-800 whitespace-nowrap">{ev.date}</td>
                        <td className="py-3 px-3.5">
                          <div className="font-extrabold text-slate-900 flex items-center gap-1.5">
                            <span>{ev.entityName}</span>
                            {onNavigateToEntityLedger && (
                              <button
                                onClick={() => onNavigateToEntityLedger(ev.category, ev.entityId, ev.projectId)}
                                className="p-0.5 text-slate-400 hover:text-indigo-600 rounded cursor-pointer"
                                title="الانتقال إلى كشف الحساب"
                              >
                                <ExternalLink size={11} />
                              </button>
                            )}
                          </div>
                          <div className="text-[10px] text-slate-400 font-normal">
                            {categoryArabic} • {ev.professionOrType || '-'}
                          </div>
                        </td>
                        <td className="py-3 px-3.5 whitespace-nowrap">
                          {ev.projectName ? (
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-indigo-50 text-indigo-700 border border-indigo-200 flex items-center gap-1 w-fit">
                              <Building2 size={11} />
                              {ev.projectName}
                            </span>
                          ) : (
                            <span className="text-[10px] text-slate-400 font-medium">عام (غير مخصص)</span>
                          )}
                        </td>
                        <td className="py-3 px-3.5 whitespace-nowrap">{ev.period || '-'}</td>
                        <td className="py-3 px-3.5 text-center whitespace-nowrap">
                          <div className="font-black text-amber-600 text-sm">{ev.rating} / 5</div>
                          <div className="text-amber-400 text-[11px]">
                            {'⭐'.repeat(Math.min(5, Math.max(1, Math.round(ev.rating))))}
                          </div>
                        </td>
                        <td className="py-3 px-3.5 text-center whitespace-nowrap">
                          <span className={`px-2.5 py-1 rounded-full text-[10px] font-extrabold border ${levelInfo.badgeBg} ${levelInfo.badgeBorder}`}>
                            {levelInfo.label}
                          </span>
                          {recText && (
                            <div className="mt-1">
                              <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-700 border border-emerald-200 block truncate max-w-[130px] mx-auto">
                                توصية: {recText}
                              </span>
                            </div>
                          )}
                        </td>
                        <td className="py-3 px-3.5 max-w-sm">
                          {/* Criteria Tags */}
                          {ev.criteria && Object.keys(ev.criteria).length > 0 && (
                            <div className="flex flex-wrap gap-1 mb-1">
                              {Object.entries(ev.criteria).slice(0, 4).map(([k, v]) => (
                                <span key={k} className="text-[10px] bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded font-normal">
                                  {v}★
                                </span>
                              ))}
                              {Object.keys(ev.criteria).length > 4 && (
                                <span className="text-[10px] text-slate-400">+{Object.keys(ev.criteria).length - 4} معايير</span>
                              )}
                            </div>
                          )}
                          {ev.strengths && (
                            <div className="text-[10px] text-emerald-700 bg-emerald-50/70 px-1.5 py-0.5 rounded border border-emerald-100 mb-0.5 truncate">
                              <span className="font-bold">👍 نقاط القوة:</span> {ev.strengths}
                            </div>
                          )}
                          {ev.weaknesses && (
                            <div className="text-[10px] text-rose-700 bg-rose-50/70 px-1.5 py-0.5 rounded border border-rose-100 mb-0.5 truncate">
                              <span className="font-bold">⚠️ نقاط الضعف:</span> {ev.weaknesses}
                            </div>
                          )}
                          {ev.notes && (
                            <p className="text-[10px] text-slate-500 italic truncate">
                              <span className="font-bold">📝 ملاحظات:</span> {ev.notes}
                            </p>
                          )}
                        </td>
                        <td className="py-3 px-3.5 text-center text-[11px] whitespace-nowrap">
                          <div className="font-extrabold text-slate-800 flex items-center justify-center gap-1">
                            <HardHat size={12} className="text-amber-500" />
                            <span>{ev.evaluatorName || ev.createdBy || '-'}</span>
                          </div>
                          {ev.evaluatorTitle && (
                            <div className="text-[10px] text-slate-400 font-normal">
                              {ev.evaluatorTitle}
                            </div>
                          )}
                        </td>
                        {sharedRole !== 'read' && (
                          <td className="py-3 px-3.5 text-center whitespace-nowrap">
                            <div className="flex items-center justify-center gap-1.5">
                              <button
                                onClick={() => handleOpenEditModal(ev)}
                                className="p-1.5 text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors cursor-pointer"
                                title="تعديل التقييم"
                              >
                                <Edit3 size={14} />
                              </button>
                              <button
                                onClick={() => {
                                  if (confirm(`هل أنت متأكد من حذف تقييم (${ev.entityName}) بتاريخ ${ev.date}؟`)) {
                                    onDeleteEvaluation(ev.id);
                                  }
                                }}
                                className="p-1.5 text-slate-500 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                                title="حذف التقييم"
                              >
                                <Trash2 size={14} />
                              </button>
                            </div>
                          </td>
                        )}
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* ================= MODAL: ADD / EDIT EVALUATION ================= */}
      {isModalOpen && (
        <div 
          className="fixed inset-0 z-[120] bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-2.5 sm:p-4 animate-fade-in overflow-y-auto overscroll-contain"
          onClick={() => setIsModalOpen(false)}
          onTouchMove={(e) => {
            if (e.target === e.currentTarget) e.preventDefault();
          }}
        >
          <div 
            className="bg-white w-full max-w-2xl rounded-3xl shadow-2xl border border-slate-100 overflow-hidden flex flex-col max-h-[92vh] sm:max-h-[88vh] my-auto overscroll-contain touch-pan-y modal-dialog-card"
            onClick={(e) => e.stopPropagation()}
          >
            
            {/* Modal Header */}
            <div className="p-4 sm:p-5 bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-amber-500/20 text-amber-400 rounded-xl border border-amber-400/30">
                  <Award size={20} />
                </div>
                <div>
                  <h3 className="font-extrabold text-sm sm:text-base">
                    {editingEvaluation ? 'تعديل سجل تقييم الأداء' : 'إضافة تقييم أداء جديد'}
                  </h3>
                  <p className="text-[11px] text-slate-300 font-medium">
                    توثيق معايير الجودة، التوصية، نقاط القوة والضعف، والمشرف المسؤول
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
              >
                <X size={18} />
              </button>
            </div>

            {/* Modal Form Body */}
            <div className="flex-1 overflow-hidden flex flex-row min-h-0 relative">
              <form onSubmit={handleSubmitEvaluation} className="flex-1 min-h-0 overflow-y-auto p-4 sm:p-5 space-y-4 overscroll-contain touch-pan-y custom-scrollbar modal-scroll-area">
              {formError && (
                <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 text-xs font-bold rounded-xl flex items-center gap-2">
                  <X size={15} />
                  <span>{formError}</span>
                </div>
              )}

              {/* 1. Category Switcher */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">الفئة المستهدفة للتقييم</label>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => handleCategoryChange('employee')}
                    className={`py-2 px-3 rounded-xl text-xs font-bold border transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                      formCategory === 'employee'
                        ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
                        : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    <Briefcase size={14} />
                    <span>موظف</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleCategoryChange('worker')}
                    className={`py-2 px-3 rounded-xl text-xs font-bold border transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                      formCategory === 'worker'
                        ? 'bg-sky-600 text-white border-sky-600 shadow-xs'
                        : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    <Users size={14} />
                    <span>عامل</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleCategoryChange('supplier')}
                    className={`py-2 px-3 rounded-xl text-xs font-bold border transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                      formCategory === 'supplier'
                        ? 'bg-amber-500 text-slate-950 border-amber-500 font-black shadow-xs'
                        : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    <Truck size={14} />
                    <span>مورد</span>
                  </button>
                </div>
              </div>

              {/* Project Association Dropdown */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">المشروع المرتبط بالتقييم</label>
                <select
                  value={formProjectId}
                  onChange={(e) => handleFormProjectChange(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 focus:outline-none focus:border-amber-500 cursor-pointer"
                >
                  <option value="">-- عام (بدون مشروع محدد / تقييم عام) --</option>
                  {projects.map(p => (
                    <option key={p.id} value={p.id}>{p.name}</option>
                  ))}
                </select>
              </div>

              {/* 2. Entity Selection / Name Input */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    اختر من قائمة {formCategory === 'employee' ? 'الموظفين' : formCategory === 'worker' ? 'العمال' : 'الموردين'}
                  </label>
                  <select
                    value={formEntityId}
                    onChange={(e) => handleSelectEntity(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 focus:outline-none focus:border-amber-500 cursor-pointer"
                  >
                    <option value="">-- أو كتابة اسم يدوي --</option>
                    {formCategory === 'employee' && allProjectEntities.allEmps.map(emp => (
                      <option key={`${emp.projectId || 'gen'}_${emp.id}`} value={emp.id}>
                        {emp.name} ({emp.profession || 'موظف'}) {emp.projectName ? `[${emp.projectName}]` : ''}
                      </option>
                    ))}
                    {formCategory === 'worker' && allProjectEntities.allWrks.map(w => (
                      <option key={`${w.projectId || 'gen'}_${w.id}`} value={w.id}>
                        {w.name} ({w.profession || 'عامل'}) {w.projectName ? `[${w.projectName}]` : ''}
                      </option>
                    ))}
                    {formCategory === 'supplier' && allProjectEntities.allSups.map(s => (
                      <option key={`${s.projectId || 'gen'}_${s.id}`} value={s.id}>
                        {s.name} ({s.materialType || 'مورد'}) {s.projectName ? `[${s.projectName}]` : ''}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">الاسم الكامل *</label>
                  <input
                    type="text"
                    required
                    placeholder="مثال: المهندس أحمد، المعلم خليل..."
                    value={formEntityName}
                    onChange={(e) => setFormEntityName(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>

              {/* 3. Dates & Period */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">المسمى / نوع المواد</label>
                  <input
                    type="text"
                    placeholder="مهندس، نجار، توريد خرسانة..."
                    value={formProfessionOrType}
                    onChange={(e) => setFormProfessionOrType(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">تاريخ التقييم *</label>
                  <input
                    type="date"
                    required
                    value={formDate}
                    onChange={(e) => setFormDate(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">فترة التقييم (اختياري)</label>
                  <input
                    type="text"
                    placeholder="الربع الأول 2026، شهر مايو..."
                    value={formPeriod}
                    onChange={(e) => setFormPeriod(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>

              {/* ================= SECTION: المشرف / المُقيِّم ================= */}
              <div className="p-3.5 bg-gradient-to-r from-amber-500/10 via-amber-50 to-orange-50/40 rounded-2xl border border-amber-200/80 space-y-3">
                <div className="flex items-center justify-between border-b border-amber-200/60 pb-2">
                  <div className="flex items-center gap-2">
                    <div className="p-1.5 bg-amber-500 text-slate-950 rounded-lg font-bold">
                      <HardHat size={15} />
                    </div>
                    <div>
                      <span className="text-xs font-extrabold text-slate-900 block">
                        المشرف / المُقيِّم (المسؤول عن التقييم)
                      </span>
                      <span className="text-[10px] text-slate-500 font-medium">
                        تحديد المهندس المشرف أو مشرف الموقع القائم بالتقييم
                      </span>
                    </div>
                  </div>
                </div>

                {/* Supervisor quick selector */}
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    اختيار سريع من قائمة المهندسين ومشرفي المواقع المعتمدين:
                  </label>
                  <select
                    value={formEvaluatorId}
                    onChange={(e) => handleSelectEvaluator(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-amber-300/80 rounded-xl text-xs font-semibold text-slate-800 focus:outline-none focus:border-amber-500 cursor-pointer shadow-2xs"
                  >
                    <option value="">-- أو إدخال اسم وصفة المشرف يدوياً --</option>
                    {qualifyingSupervisors.map(sup => (
                      <option key={`sup_${sup.id}`} value={sup.id}>
                        {sup.name} — [{sup.profession}] {sup.projectName ? `(مشروع: ${sup.projectName})` : ''}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">اسم المشرف / المُقيِّم</label>
                    <input
                      type="text"
                      placeholder="مثال: م. خالد الصالح، مشرف الموقع..."
                      value={formEvaluatorName}
                      onChange={(e) => setFormEvaluatorName(e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 focus:outline-none focus:border-amber-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">المسمى الوظيفي / الصفة</label>
                    <input
                      type="text"
                      placeholder="مثال: مهندس ومشرف ميداني، مشرف موقع..."
                      value={formEvaluatorTitle}
                      onChange={(e) => setFormEvaluatorTitle(e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 focus:outline-none focus:border-amber-500"
                    />
                  </div>
                </div>
              </div>

              {/* 4. Detailed Evaluation Criteria */}
              <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200/80 space-y-3">
                <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                  <span className="text-xs font-extrabold text-slate-800 flex items-center gap-1.5">
                    <Sparkles size={14} className="text-amber-500" />
                    معايير التقييم التفصيلية (1 إلى 5 نجوم)
                  </span>
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-bold text-slate-600">المتوسط المحتسب:</span>
                    <span className="text-sm font-black text-amber-600">{computedRating} / 5 ⭐</span>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {activeCriteriaList.map(crit => {
                    const val = formCriteria[crit.key] || 5;
                    return (
                      <div key={crit.key} className="bg-white p-2.5 rounded-xl border border-slate-100 shadow-2xs flex items-center justify-between gap-2">
                        <span className="text-xs font-bold text-slate-700">{crit.label}</span>
                        {renderStarInput(val, (newVal) => {
                          setFormCriteria(prev => ({ ...prev, [crit.key]: newVal }));
                          setFormCustomRating(null);
                        }, 16)}
                      </div>
                    );
                  })}
                </div>

                {/* Performance Level Live Preview Box */}
                {(() => {
                  const levelInfo = getPerformanceLevelInfo(computedRating);
                  return (
                    <div className="mt-2 p-2.5 bg-white rounded-xl border border-slate-200 flex items-center justify-between">
                      <span className="text-xs font-bold text-slate-600">مستوى الأداء التلقائي:</span>
                      <div className="flex items-center gap-2">
                        <span className={`text-xs font-extrabold px-3 py-1 rounded-full border ${levelInfo.badgeBg} ${levelInfo.badgeBorder}`}>
                          {levelInfo.label} ({levelInfo.stars}★)
                        </span>
                      </div>
                    </div>
                  );
                })()}
              </div>

              {/* ================= SECTION: سؤال التوصية (Recommendation Question) ================= */}
              <div className="p-4 bg-gradient-to-br from-indigo-50/70 via-sky-50/50 to-emerald-50/40 rounded-2xl border border-indigo-200/80 space-y-3">
                <div className="flex items-start gap-2">
                  <div className="p-1.5 bg-indigo-600 text-white rounded-lg font-bold shrink-0 mt-0.5">
                    <HelpCircle size={15} />
                  </div>
                  <div>
                    <label className="block text-xs font-black text-slate-900 leading-snug">
                      سؤال التوصية: {getRecommendationQuestion(formCategory)}
                    </label>
                    <span className="text-[10px] text-slate-500 font-medium">
                      يرجى تحديد درجة التوصية المناسبة (اختيار واحد فقط)
                    </span>
                  </div>
                </div>

                {/* 5-Choice Options */}
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                  {RECOMMENDATION_CHOICES.map(choice => {
                    const isSelected = formRecommendation === choice.value;
                    return (
                      <button
                        key={choice.value}
                        type="button"
                        onClick={() => setFormRecommendation(choice.value)}
                        className={`py-2 px-2 rounded-xl text-xs font-bold border transition-all flex flex-col items-center justify-center gap-1 cursor-pointer text-center ${
                          isSelected
                            ? `${choice.activeBg} ${choice.activeText} ${choice.activeBorder} shadow-sm ring-2 ring-indigo-400/30 font-black scale-[1.02]`
                            : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                        }`}
                      >
                        <span className="text-sm">{choice.icon}</span>
                        <span className="text-[11px] whitespace-nowrap">{choice.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* ================= SECTION: نقاط القوة ونقاط الضعف ================= */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* نقاط القوة / إيجابية */}
                <div className="p-3 bg-emerald-50/60 rounded-2xl border border-emerald-200 space-y-1.5">
                  <label className="block text-xs font-extrabold text-emerald-900 flex items-center gap-1.5">
                    <ThumbsUp size={14} className="text-emerald-600" />
                    <span>نقاط القوة / إيجابية</span>
                  </label>
                  <textarea
                    rows={2}
                    placeholder="سجل أبرز نقاط التميز، المهارات العالية، سرعة التنفيذ، والإيجابيات..."
                    value={formStrengths}
                    onChange={(e) => setFormStrengths(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-emerald-200 rounded-xl text-xs font-medium text-slate-800 focus:outline-none focus:border-emerald-500 resize-none shadow-2xs"
                  />
                </div>

                {/* نقاط الضعف / سلبية */}
                <div className="p-3 bg-rose-50/60 rounded-2xl border border-rose-200 space-y-1.5">
                  <label className="block text-xs font-extrabold text-rose-900 flex items-center gap-1.5">
                    <ThumbsDown size={14} className="text-rose-600" />
                    <span>نقاط الضعف / سلبية</span>
                  </label>
                  <textarea
                    rows={2}
                    placeholder="سجل جوانب القصور، المشاكل أو السلبيات التي تحتاج لتلافي أو تدريب..."
                    value={formWeaknesses}
                    onChange={(e) => setFormWeaknesses(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-rose-200 rounded-xl text-xs font-medium text-slate-800 focus:outline-none focus:border-rose-500 resize-none shadow-2xs"
                  />
                </div>
              </div>

              {/* ================= SECTION: ملاحظات أخرى ================= */}
              <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 space-y-1.5">
                <label className="block text-xs font-extrabold text-slate-800 flex items-center gap-1.5">
                  <FileText size={14} className="text-slate-500" />
                  <span>ملاحظات أخرى</span>
                </label>
                <textarea
                  rows={2}
                  placeholder="أي ملاحظات أو توصيات إضافية أو شروط مستقبلية للعمل..."
                  value={formNotes}
                  onChange={(e) => setFormNotes(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 focus:outline-none focus:border-amber-500 resize-none shadow-2xs"
                />
              </div>

              {/* Form Actions (Save & Reset / Cancel) - Sticky for mobile visibility */}
              <div className="sticky bottom-0 bg-white/95 backdrop-blur-xs pt-3 pb-1 border-t border-slate-100 flex items-center justify-end gap-2 shrink-0 z-10">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="py-2.5 px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition-all cursor-pointer"
                >
                  إغلاق
                </button>

                <button
                  type="button"
                  onClick={handleResetForm}
                  className="py-2.5 px-3.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition-all cursor-pointer flex items-center gap-1.5"
                  title={editingEvaluation ? 'إلغاء التعديلات واستعادة البيانات الأصلية' : 'مسح كافة الحقول وإعادة ضبط النموذج'}
                >
                  <RotateCcw size={13} />
                  <span className="hidden sm:inline">{editingEvaluation ? 'استعادة الأصل' : 'إلغاء / تنظيف'}</span>
                </button>

                <button
                  type="submit"
                  className="py-2.5 px-5 bg-amber-500 hover:bg-amber-600 text-slate-950 font-black text-xs sm:text-sm rounded-xl transition-all shadow-md cursor-pointer flex items-center gap-1.5"
                >
                  <Award size={15} />
                  <span>{editingEvaluation ? 'حفظ التعديلات' : 'حفظ التقييم الآن'}</span>
                </button>
              </div>
            </form>

            <DraggableScrollIndicator
              variant="purple"
              title="مسار السحب والتنقل الفوري في تقييم الأداء"
              className="border-r border-slate-200/80 bg-slate-50/80 py-2"
            />
          </div>

          </div>
        </div>
      )}

      {/* ================= MODAL: SPECIFIC ENTITY EVALUATION HISTORY ================= */}
      {historyModalEntity && (
        <div 
          className="fixed inset-0 z-[120] bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-2.5 sm:p-4 animate-fade-in overflow-y-auto overscroll-contain"
          onClick={() => setHistoryModalEntity(null)}
          onTouchMove={(e) => {
            if (e.target === e.currentTarget) e.preventDefault();
          }}
        >
          <div 
            className="bg-white w-full max-w-2xl rounded-3xl shadow-2xl border border-slate-100 overflow-hidden flex flex-col max-h-[92vh] sm:max-h-[88vh] my-auto overscroll-contain touch-pan-y modal-dialog-card"
            onClick={(e) => e.stopPropagation()}
          >
            
            {/* Modal Header */}
            <div className="p-4 sm:p-5 bg-slate-900 text-white flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-indigo-500/20 text-indigo-400 rounded-xl border border-indigo-400/30">
                  <Clock size={20} />
                </div>
                <div>
                  <h3 className="font-extrabold text-sm sm:text-base">
                    سجل تقييمات: {historyModalEntity.name}
                  </h3>
                  <span className="text-[11px] text-slate-300">
                    كافة عمليات التقييم السابقة المسجلة في النظام {historyModalEntity.projectName ? `(مشروع: ${historyModalEntity.projectName})` : ''}
                  </span>
                </div>
              </div>
              <button
                onClick={() => setHistoryModalEntity(null)}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
              >
                <X size={18} />
              </button>
            </div>

            {/* Modal Body */}
            <div className="flex-1 overflow-hidden flex flex-row min-h-0 relative">
              <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-3 overscroll-contain touch-pan-y custom-scrollbar modal-scroll-area">
              {(() => {
                const userHistory = evaluations
                  .filter(e => e.category === historyModalEntity.category && (e.entityId === historyModalEntity.id || e.entityName === historyModalEntity.name))
                  .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

                if (userHistory.length === 0) {
                  return (
                    <div className="py-8 text-center text-slate-400 text-xs">
                      لا توجد تقييمات سابقة مسجلة لهذا الشخص حتى الآن.
                    </div>
                  );
                }

                return (
                  <div className="space-y-3">
                    {userHistory.map(ev => {
                      const levelInfo = getPerformanceLevelInfo(ev.rating);
                      const recText = ev.recommendation ? getRecommendationLabel(ev.recommendation) : null;
                      return (
                        <div key={ev.id} className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200/80 space-y-2.5">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <Calendar size={14} className="text-slate-400" />
                              <span className="text-xs font-bold text-slate-800">{ev.date}</span>
                              {ev.period && (
                                <span className="text-[10px] bg-slate-200 text-slate-700 px-2 py-0.5 rounded-md font-semibold">
                                  {ev.period}
                                </span>
                              )}
                              {ev.projectName && (
                                <span className="text-[10px] bg-indigo-50 text-indigo-700 border border-indigo-200 px-2 py-0.5 rounded-md font-bold flex items-center gap-1">
                                  <Building2 size={10} />
                                  {ev.projectName}
                                </span>
                              )}
                            </div>

                            <div className="flex items-center gap-2">
                              <span className="text-sm font-black text-amber-600">{ev.rating} / 5 ⭐</span>
                              <span className={`text-[10px] font-black px-2.5 py-0.5 rounded-full border ${levelInfo.badgeBg} ${levelInfo.badgeBorder}`}>
                                {levelInfo.label}
                              </span>
                            </div>
                          </div>

                          {/* Supervisor / Evaluator Badge */}
                          {(ev.evaluatorName || ev.createdBy) && (
                            <div className="flex items-center gap-1.5 text-xs bg-amber-50/70 text-amber-900 border border-amber-200/80 p-2 rounded-xl">
                              <HardHat size={14} className="text-amber-600 shrink-0" />
                              <span className="font-bold">المشرف / المُقيِّم:</span>
                              <span className="font-black text-slate-900">{ev.evaluatorName || ev.createdBy}</span>
                              {ev.evaluatorTitle && (
                                <span className="text-[11px] text-slate-600 bg-white/80 px-2 py-0.5 rounded-md border border-amber-200/60 font-semibold">
                                  ({ev.evaluatorTitle})
                                </span>
                              )}
                            </div>
                          )}

                          {/* Recommendation Question & Answer */}
                          {ev.recommendation && (
                            <div className="p-2.5 bg-gradient-to-r from-indigo-50/60 to-emerald-50/60 rounded-xl border border-indigo-100 flex items-center justify-between gap-2 text-xs">
                              <span className="font-bold text-slate-700 flex items-center gap-1">
                                <HelpCircle size={13} className="text-indigo-600" />
                                {getRecommendationQuestion(ev.category)}
                              </span>
                              <span className="font-black px-2.5 py-0.5 rounded-md bg-emerald-600 text-white shadow-2xs text-[11px] shrink-0">
                                {recText}
                              </span>
                            </div>
                          )}

                          {/* Criteria list */}
                          {ev.criteria && (
                            <div className="pt-1 border-t border-slate-200/60 grid grid-cols-2 sm:grid-cols-4 gap-1.5">
                              {Object.entries(ev.criteria).map(([k, v]) => (
                                <div key={k} className="bg-white p-1.5 rounded-lg border border-slate-100 text-[10px] flex items-center justify-between">
                                  <span className="text-slate-600 font-medium truncate" title={getCriterionLabel(ev.category, k)}>
                                    {getCriterionLabel(ev.category, k)}:
                                  </span>
                                  <span className="font-bold text-slate-800">{v}★</span>
                                </div>
                              ))}
                            </div>
                          )}

                          {/* Strengths & Weaknesses */}
                          {(ev.strengths || ev.weaknesses) && (
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                              {ev.strengths && (
                                <div className="p-2 bg-emerald-50 rounded-xl border border-emerald-200 text-xs text-emerald-900">
                                  <span className="font-extrabold flex items-center gap-1 mb-0.5 text-emerald-800">
                                    <ThumbsUp size={12} className="text-emerald-600" /> نقاط القوة:
                                  </span>
                                  <p className="font-medium text-[11px]">{ev.strengths}</p>
                                </div>
                              )}
                              {ev.weaknesses && (
                                <div className="p-2 bg-rose-50 rounded-xl border border-rose-200 text-xs text-rose-900">
                                  <span className="font-extrabold flex items-center gap-1 mb-0.5 text-rose-800">
                                    <ThumbsDown size={12} className="text-rose-600" /> نقاط الضعف:
                                  </span>
                                  <p className="font-medium text-[11px]">{ev.weaknesses}</p>
                                </div>
                              )}
                            </div>
                          )}

                          {/* Other Notes */}
                          {ev.notes && (
                            <div className="text-xs text-slate-700 bg-white p-2 rounded-xl border border-slate-100">
                              <span className="font-bold text-slate-500 block text-[10px]">ملاحظات أخرى:</span>
                              <p className="italic text-[11px]">{ev.notes}</p>
                            </div>
                          )}

                          <div className="flex items-center justify-between pt-1 text-[10px] text-slate-400">
                            <span>مسجل التقييم: {ev.createdBy || '-'}</span>
                            {sharedRole !== 'read' && (
                              <div className="flex items-center gap-2">
                                <button
                                  onClick={() => {
                                    setHistoryModalEntity(null);
                                    handleOpenEditModal(ev);
                                  }}
                                  className="text-indigo-600 hover:underline font-bold cursor-pointer"
                                >
                                  تعديل
                                </button>
                                <span>•</span>
                                <button
                                  onClick={() => {
                                    if (confirm('هل أنت متأكد من حذف هذا التقييم؟')) {
                                      onDeleteEvaluation(ev.id);
                                    }
                                  }}
                                  className="text-rose-600 hover:underline font-bold cursor-pointer"
                                >
                                  حذف
                                </button>
                              </div>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                );
              })()}
            </div>

            <DraggableScrollIndicator
              variant="indigo"
              title="مسار السحب والتنقل الفوري في سجل تقييمات الأداء"
              className="border-r border-slate-200/80 bg-slate-50/80 py-2"
            />
          </div>

            {/* Modal Footer */}
            <div className="p-4 bg-slate-50 border-t border-slate-100 flex justify-between items-center shrink-0">
              {sharedRole !== 'read' && (
                <button
                  onClick={() => {
                    const ent = historyModalEntity;
                    setHistoryModalEntity(null);
                    handleOpenAddModal(ent.category, { id: ent.id, name: ent.name, projectId: ent.projectId, projectName: ent.projectName });
                  }}
                  className="py-2 px-4 bg-amber-500 hover:bg-amber-600 text-slate-950 font-black text-xs rounded-xl transition-all cursor-pointer flex items-center gap-1.5 shadow-xs"
                >
                  <Plus size={14} />
                  <span>إضافة تقييم جديد لهذا الشخص</span>
                </button>
              )}
              
              {onNavigateToEntityLedger && historyModalEntity && (
                <button
                  onClick={() => {
                    const ent = historyModalEntity;
                    setHistoryModalEntity(null);
                    onNavigateToEntityLedger(ent.category, ent.id, ent.projectId);
                  }}
                  className="py-2 px-3 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold text-xs rounded-xl transition-all cursor-pointer flex items-center gap-1"
                >
                  <Receipt size={13} />
                  <span>كشف الحساب والبيانات</span>
                </button>
              )}

              <button
                onClick={() => setHistoryModalEntity(null)}
                className="py-2 px-4 bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold text-xs rounded-xl transition-all cursor-pointer mr-auto"
              >
                إغلاق
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
