/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { 
  X, 
  Download, 
  Share2, 
  Copy, 
  Check, 
  KeyRound, 
  FileJson, 
  ShieldCheck, 
  Smartphone, 
  HardDrive,
  Info,
  ChevronDown,
  ChevronUp,
  Upload,
  RefreshCw,
  AlertTriangle,
  FileCheck,
  RotateCcw
} from 'lucide-react';
import { useBodyScrollLock } from '../utils/modalScrollLock';
import { 
  extractRawLocalStorageData,
  createBackupFile,
  shareBackup,
  validateBackupFileContent,
  executeRestore,
  copyJsonToClipboard,
  isNativePlatform,
  getRuntimePlatform,
  BackupExecutionResult,
  RestoreValidationResult
} from '../services/backupService';

interface LocalStorageBackupModalProps {
  isOpen: boolean;
  onClose: () => void;
  onRestoreSuccess?: () => void;
}

export default function LocalStorageBackupModal({
  isOpen,
  onClose,
  onRestoreSuccess
}: LocalStorageBackupModalProps) {
  const [activeTab, setActiveTab] = useState<'backup' | 'restore'>('backup');
  
  // Backup states
  const [backupPreview, setBackupPreview] = useState<{
    fileName: string;
    keysCount: number;
    sizeKb: number;
    checksum: string;
    jsonString: string;
  } | null>(null);
  
  const [lastBackupResult, setLastBackupResult] = useState<BackupExecutionResult | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [copied, setCopied] = useState(false);
  const [showKeyList, setShowKeyList] = useState(false);
  const [statusMessage, setStatusMessage] = useState<{ text: string; type: 'success' | 'info' | 'error' } | null>(null);

  // Restore states
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [restoreValidation, setRestoreValidation] = useState<RestoreValidationResult | null>(null);
  const [selectedFileName, setSelectedFileName] = useState<string>('');
  const [showRestoreConfirm, setShowRestoreConfirm] = useState(false);
  const [restoreSuccessMessage, setRestoreSuccessMessage] = useState<string | null>(null);

  const isNative = isNativePlatform();
  const platform = getRuntimePlatform();

  useBodyScrollLock(isOpen);

  // Load preview metadata (READ-ONLY) whenever modal opens or switching to backup tab
  useEffect(() => {
    if (isOpen) {
      try {
        const { payload, jsonString, fileName, sizeKb } = extractRawLocalStorageData();
        setBackupPreview({
          fileName,
          keysCount: payload.metadata.totalKeysCount,
          sizeKb,
          checksum: payload.checksum,
          jsonString
        });
        setLastBackupResult(null);
        setCopied(false);
        setShowKeyList(false);
        setStatusMessage(null);
        setRestoreValidation(null);
        setSelectedFileName('');
        setShowRestoreConfirm(false);
        setRestoreSuccessMessage(null);
      } catch (err: any) {
        console.error('Error generating preview data:', err);
        setStatusMessage({ text: 'حدث خطأ أثناء قراءة بيانات التخزين المحلي.', type: 'error' });
      }
    }
  }, [isOpen, activeTab]);

  if (!isOpen) return null;

  // Handler: Create and Save Backup File (Native Filesystem or Web Download)
  const handleCreateAndSave = async () => {
    try {
      setIsProcessing(true);
      setStatusMessage({ text: 'جاري إنشاء وحفظ ملف النسخة الاحتياطية...', type: 'info' });

      const result = await createBackupFile();
      setLastBackupResult(result);

      if (result.success) {
        setStatusMessage({
          text: isNative 
            ? `✅ تم إنشاء وحفظ ملف النسخة الاحتياطية بنجاح في: ${result.savedLocation || 'ذاكرة الهاتف'}`
            : '✅ تم إنشاء وتنزيل ملف النسخة الاحتياطية بنجاح إلى مجلد التنزيلات (Downloads).',
          type: 'success'
        });
      } else {
        setStatusMessage({
          text: `⚠️ ${result.message || 'فشلت عملية حفظ الملف.'}`,
          type: 'error'
        });
      }
    } catch (err: any) {
      console.error('handleCreateAndSave error:', err);
      setStatusMessage({ text: `⚠️ حدث خطأ: ${err?.message || 'تعذر حفظ الملف'}`, type: 'error' });
    } finally {
      setIsProcessing(false);
    }
  };

  // Handler: Share Backup File (Capacitor Native Share Sheet or Web Share)
  const handleShareBackup = async () => {
    try {
      setIsProcessing(true);
      setStatusMessage({ text: 'جاري تجهيز وفتح نافذة المشاركة وحفظ الملف...', type: 'info' });

      const res = await shareBackup(lastBackupResult);
      if (res.success) {
        setStatusMessage({
          text: '✅ تم إنشاء ملف النسخة الاحتياطية. اختر مكان حفظ الملف أو التطبيق الذي تريد مشاركة النسخة معه (مثل Google Drive، مدير الملفات Files، أو WhatsApp).',
          type: 'success'
        });
      } else {
        setStatusMessage({ text: `⚠️ ${res.message}`, type: 'error' });
      }
    } catch (err: any) {
      console.error('handleShareBackup error:', err);
      setStatusMessage({ text: `⚠️ حدث خطأ: ${err?.message || 'تعذر المشاركة'}`, type: 'error' });
    } finally {
      setIsProcessing(false);
    }
  };

  // Handler: Copy Raw JSON to Clipboard
  const handleCopyJson = async () => {
    if (!backupPreview) return;
    const ok = await copyJsonToClipboard(backupPreview.jsonString);
    if (ok) {
      setCopied(true);
      setStatusMessage({ text: '✅ تم نسخ كود النسخة الاحتياطية بالكامل للحافظة.', type: 'success' });
      setTimeout(() => setCopied(false), 3000);
    } else {
      setStatusMessage({ text: '⚠️ تعذر النسخ إلى الحافظة.', type: 'error' });
    }
  };

  // Handler: File Selected for Restore
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setSelectedFileName(file.name);
    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      const validation = validateBackupFileContent(content);
      setRestoreValidation(validation);
      if (!validation.isValid) {
        setStatusMessage({ text: `⚠️ ${validation.message}`, type: 'error' });
      } else {
        setStatusMessage({ text: '✅ تم فحص الملف بنجاح وهو صالح للاستعادة.', type: 'success' });
      }
    };
    reader.onerror = () => {
      setStatusMessage({ text: '⚠️ فشل قراءة الملف المحدد.', type: 'error' });
    };
    reader.readAsText(file);
  };

  // Handler: Execute Restore after User Confirmation
  const handleConfirmRestore = async () => {
    if (!restoreValidation || !restoreValidation.parsedData) return;

    try {
      setIsProcessing(true);
      setShowRestoreConfirm(false);
      const res = await executeRestore(restoreValidation.parsedData);

      if (res.success) {
        setRestoreSuccessMessage(res.message);
        setStatusMessage({ text: `✅ ${res.message}`, type: 'success' });
        if (onRestoreSuccess) {
          onRestoreSuccess();
        }
      } else {
        setStatusMessage({ text: `⚠️ ${res.message}`, type: 'error' });
      }
    } catch (err: any) {
      console.error('handleConfirmRestore error:', err);
      setStatusMessage({ text: `⚠️ خطأ أثناء الاستعادة: ${err?.message}`, type: 'error' });
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div 
      className="fixed inset-0 z-[120] bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto dir-rtl text-right overscroll-contain"
      onClick={onClose}
    >
      <div 
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-lg bg-white rounded-3xl border border-slate-200/90 shadow-2xl overflow-hidden my-auto animate-scale-up"
      >
        {/* Modal Header */}
        <div className="bg-sky-600 px-6 py-4 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-white/15 rounded-2xl">
              <KeyRound size={22} className="text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-black">إدارة النسخ الاحتياطي للبيانات</h2>
                <span className="text-[10px] font-extrabold bg-white/20 text-white px-2 py-0.5 rounded-full border border-white/30">
                  {isNative ? '📱 Android Native' : '🌐 Web Browser'}
                </span>
              </div>
              <p className="text-[11px] text-sky-100 font-medium">حفظ، استعادة، ومشاركة كامل بيانات التخزين المحلي (Local Storage)</p>
            </div>
          </div>
          <button 
            type="button"
            onClick={onClose}
            className="p-1.5 bg-white/10 hover:bg-white/20 rounded-xl transition-colors cursor-pointer text-white"
          >
            <X size={18} />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex border-b border-slate-200 bg-slate-50/80 p-1.5 gap-1.5">
          <button
            type="button"
            onClick={() => {
              setActiveTab('backup');
              setStatusMessage(null);
            }}
            className={`flex-1 py-2.5 px-3 rounded-xl font-black text-xs transition-all flex items-center justify-center gap-2 cursor-pointer ${
              activeTab === 'backup'
                ? 'bg-white text-sky-700 shadow-xs border border-slate-200/80'
                : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
            }`}
          >
            <Download size={15} />
            <span>إنشاء ومشاركة نسخة احتياطية</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setActiveTab('restore');
              setStatusMessage(null);
            }}
            className={`flex-1 py-2.5 px-3 rounded-xl font-black text-xs transition-all flex items-center justify-center gap-2 cursor-pointer ${
              activeTab === 'restore'
                ? 'bg-white text-sky-700 shadow-xs border border-slate-200/80'
                : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
            }`}
          >
            <RotateCcw size={15} />
            <span>استعادة نسخة احتياطية</span>
          </button>
        </div>

        {/* Content Area */}
        <div className="p-5 sm:p-6 space-y-4 max-h-[75vh] overflow-y-auto">
          
          {/* Status Message Banner (if any) */}
          {statusMessage && (
            <div className={`p-3.5 border rounded-2xl text-xs font-semibold flex items-start gap-2.5 ${
              statusMessage.type === 'success'
                ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                : statusMessage.type === 'error'
                ? 'bg-rose-50 border-rose-200 text-rose-900'
                : 'bg-sky-50 border-sky-200 text-sky-900'
            }`}>
              <Info size={16} className="shrink-0 mt-0.5 text-current" />
              <div className="leading-relaxed">{statusMessage.text}</div>
            </div>
          )}

          {/* TAB 1: BACKUP & SHARE */}
          {activeTab === 'backup' && (
            <div className="space-y-4">
              
              {/* Instructions banner */}
              <div className="p-3.5 bg-sky-50/70 border border-sky-200 rounded-2xl flex items-start gap-3">
                <ShieldCheck size={20} className="text-sky-600 shrink-0 mt-0.5" />
                <div className="text-xs text-sky-950 leading-relaxed font-medium">
                  <span className="font-extrabold block mb-0.5">عملية آمنة للقراءة فقط (READ-ONLY)</span>
                  يتم حفظ كامل المفاتيح والقيم الحالية المخزنة في جهازك دون أي تعديل، لحمايتها ومشاركتها مع Google Drive أو الواتساب أو مدير الملفات.
                </div>
              </div>

              {/* Backup Details Card */}
              {backupPreview && (
                <div className="bg-slate-50 border border-slate-200/80 rounded-2xl p-4 space-y-2.5 text-xs text-slate-700">
                  <div className="flex items-center justify-between border-b border-slate-200/60 pb-2">
                    <span className="text-slate-500 font-bold flex items-center gap-1.5">
                      <FileJson size={15} className="text-sky-600" />
                      اسم الملف:
                    </span>
                    <span className="font-mono font-bold text-slate-900 text-[11px] dir-ltr text-left select-all bg-white px-2 py-0.5 rounded-lg border border-slate-200">
                      {backupPreview.fileName}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-2 pt-1 text-[11px]">
                    <div className="bg-white p-2.5 rounded-xl border border-slate-200/60 flex items-center justify-between">
                      <span className="text-slate-500">عدد المفاتيح:</span>
                      <span className="font-extrabold text-sky-700">{backupPreview.keysCount} مفتاح</span>
                    </div>
                    <div className="bg-white p-2.5 rounded-xl border border-slate-200/60 flex items-center justify-between">
                      <span className="text-slate-500">حجم البيانات:</span>
                      <span className="font-extrabold text-sky-700">{backupPreview.sizeKb} KB</span>
                    </div>
                  </div>

                  <div className="bg-white p-2.5 rounded-xl border border-slate-200/60 flex items-center justify-between text-[11px]">
                    <span className="text-slate-500">رمز التحقق (Checksum):</span>
                    <span className="font-mono font-bold text-slate-600 bg-slate-100 px-1.5 py-0.5 rounded text-[10px]">
                      {backupPreview.checksum}
                    </span>
                  </div>

                  {lastBackupResult && lastBackupResult.savedLocation && (
                    <div className="bg-emerald-50 border border-emerald-200 p-2.5 rounded-xl text-[11px] text-emerald-900">
                      <span className="font-bold block">مكان الحفظ:</span>
                      <span className="font-mono text-[10px] dir-ltr text-left block text-emerald-800 break-all">
                        {lastBackupResult.savedLocation}
                      </span>
                    </div>
                  )}
                </div>
              )}

              {/* Action Buttons */}
              <div className="space-y-2.5 pt-1">
                
                {/* 1. Main Action: Create & Save File (Native on Android / Direct Download on Web) */}
                <button
                  type="button"
                  onClick={handleCreateAndSave}
                  disabled={isProcessing}
                  className="w-full p-3.5 bg-sky-600 hover:bg-sky-700 active:scale-98 text-white rounded-2xl font-black text-xs sm:text-sm shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-3 cursor-pointer disabled:opacity-50"
                >
                  <div className="p-1.5 bg-white/20 rounded-xl shrink-0">
                    <Download size={18} />
                  </div>
                  <div className="text-right flex-1">
                    <span className="block font-black">
                      {isNative ? 'إنشاء وحفظ ملف النسخة في ذاكرة الهاتف' : 'إنشاء وتنزيل ملف النسخة (.json) مباشرة'}
                    </span>
                    <span className="block text-[10px] text-sky-100 font-normal">
                      {isNative ? 'حفظ حقيقي في مجلد المستندات (Documents) بالهاتف' : 'حفظ مباشر في مجلد التنزيلات (Downloads)'}
                    </span>
                  </div>
                </button>

                {/* 2. Main Action: Native Android Share Sheet / Web Share */}
                <button
                  type="button"
                  onClick={handleShareBackup}
                  disabled={isProcessing}
                  className="w-full p-3.5 bg-violet-600 hover:bg-violet-700 active:scale-98 text-white rounded-2xl font-black text-xs sm:text-sm shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-3 cursor-pointer disabled:opacity-50"
                >
                  <div className="p-1.5 bg-white/20 rounded-xl shrink-0">
                    <Share2 size={18} />
                  </div>
                  <div className="text-right flex-1">
                    <span className="block font-black">مشاركة النسخة (Google Drive / WhatsApp / Files / Gmail)</span>
                    <span className="block text-[10px] text-violet-100 font-normal">
                      فتح قائمة المشاركة الأصلية لنظام Android لاختيار التطبيق المطلوب
                    </span>
                  </div>
                </button>

                {/* 3. Action: Copy JSON String */}
                <button
                  type="button"
                  onClick={handleCopyJson}
                  className="w-full p-2.5 bg-slate-50 hover:bg-slate-100 active:scale-98 text-slate-700 rounded-xl font-bold text-xs transition-all flex items-center justify-between px-3.5 cursor-pointer border border-slate-200/80"
                >
                  <div className="flex items-center gap-2">
                    <Copy size={15} className="text-slate-500" />
                    <span>نسخ كود البيانات بالكامل للحافظة (نص JSON)</span>
                  </div>
                  {copied ? (
                    <span className="text-emerald-600 flex items-center gap-1 text-[11px] font-extrabold">
                      <Check size={13} /> تم النسخ!
                    </span>
                  ) : (
                    <span className="text-slate-400 text-[10px]">نسخ</span>
                  )}
                </button>
              </div>

              {/* Toggle Storage Keys List */}
              {backupPreview && (
                <div className="pt-2 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={() => setShowKeyList(!showKeyList)}
                    className="w-full flex items-center justify-between text-xs text-slate-500 hover:text-slate-800 font-semibold py-1.5 px-2 rounded-lg hover:bg-slate-50 cursor-pointer"
                  >
                    <span>استعراض قائمة مفاتيح الذاكرة ({backupPreview.keysCount} مفتاح)</span>
                    {showKeyList ? <ChevronUp size={15} /> : <ChevronDown size={15} />}
                  </button>

                  {showKeyList && (
                    <div className="mt-2 p-3 bg-slate-900 text-slate-200 rounded-xl text-[10px] font-mono max-h-40 overflow-y-auto space-y-1 dir-ltr text-left select-all">
                      {Object.keys(JSON.parse(backupPreview.jsonString).data || {}).map((k: string, idx: number) => (
                        <div key={idx} className="flex justify-between border-b border-slate-800 py-0.5">
                          <span className="text-sky-300">{k}</span>
                          <span className="text-slate-500">
                            {localStorage.getItem(k)?.length || 0} chars
                          </span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

            </div>
          )}

          {/* TAB 2: RESTORE */}
          {activeTab === 'restore' && (
            <div className="space-y-4">
              
              {/* Restore Success Screen (if finished) */}
              {restoreSuccessMessage ? (
                <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-5 text-center space-y-3">
                  <div className="w-12 h-12 bg-emerald-500 text-white rounded-full flex items-center justify-center mx-auto shadow-md">
                    <Check size={26} />
                  </div>
                  <h3 className="text-sm font-black text-emerald-950">تمت استعادة البيانات بنجاح!</h3>
                  <p className="text-xs text-emerald-800 leading-relaxed">
                    تم استيراد كافة سجلات التخزين المحلي بنجاح. يُفضل إعادة تحميل التطبيق لتحديث جميع الشاشات.
                  </p>
                  <button
                    type="button"
                    onClick={() => {
                      if (typeof window !== 'undefined') {
                        window.location.reload();
                      }
                    }}
                    className="py-2.5 px-6 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black rounded-xl shadow-xs cursor-pointer"
                  >
                    تحديث وإعادة تحميل التطبيق الآن
                  </button>
                </div>
              ) : (
                <>
                  {/* Safety Note */}
                  <div className="p-3.5 bg-amber-50 border border-amber-200 rounded-2xl flex items-start gap-3 text-xs text-amber-950">
                    <AlertTriangle size={20} className="text-amber-600 shrink-0 mt-0.5" />
                    <div className="leading-relaxed font-medium">
                      <span className="font-extrabold block mb-0.5">حماية تلقائية لبياناتك</span>
                      يقوم النظام بإنشاء نسخة احتياطية فورية لبياناتك الحالية تلقائياً قبل أي عملية استعادة لضمان عدم فقدان أي بيانات تحت أي ظرف.
                    </div>
                  </div>

                  {/* File Selector */}
                  <div 
                    onClick={() => fileInputRef.current?.click()}
                    className="p-6 border-2 border-dashed border-slate-300 hover:border-sky-500 bg-slate-50 hover:bg-sky-50/50 rounded-2xl text-center cursor-pointer transition-all space-y-2"
                  >
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept=".json,application/json"
                      onChange={handleFileChange}
                      className="hidden"
                    />
                    <div className="w-10 h-10 bg-sky-100 text-sky-700 rounded-xl flex items-center justify-center mx-auto">
                      <Upload size={20} />
                    </div>
                    <div className="text-xs font-extrabold text-slate-800">
                      {selectedFileName ? selectedFileName : 'اضغط لاختيار ملف النسخة الاحتياطية (.json)'}
                    </div>
                    <p className="text-[10px] text-slate-500">
                      اختر ملف النسخة الذي تم تصديره مسبقاً بصيغة JSON
                    </p>
                  </div>

                  {/* Validation Summary Card */}
                  {restoreValidation && restoreValidation.isValid && (
                    <div className="bg-slate-50 border border-slate-200/80 rounded-2xl p-4 space-y-3 text-xs">
                      <div className="flex items-center gap-2 text-emerald-700 font-extrabold border-b border-slate-200/60 pb-2">
                        <FileCheck size={16} />
                        <span>الملف سليم وتم التحقق من صحته بنجاح</span>
                      </div>

                      <div className="grid grid-cols-2 gap-2 text-[11px]">
                        <div className="bg-white p-2.5 rounded-xl border border-slate-200/60">
                          <span className="text-slate-500 block text-[10px]">تاريخ النسخة:</span>
                          <span className="font-bold text-slate-800">
                            {restoreValidation.createdAt 
                              ? new Date(restoreValidation.createdAt).toLocaleString('ar-EG') 
                              : 'غير محدد'}
                          </span>
                        </div>
                        <div className="bg-white p-2.5 rounded-xl border border-slate-200/60">
                          <span className="text-slate-500 block text-[10px]">عدد المفاتيح:</span>
                          <span className="font-extrabold text-sky-700">{restoreValidation.keysCount} مفتاح</span>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-2 text-[11px]">
                        <div className="bg-white p-2.5 rounded-xl border border-slate-200/60">
                          <span className="text-slate-500 block text-[10px]">حجم الملف:</span>
                          <span className="font-bold text-slate-800">{restoreValidation.sizeKb} KB</span>
                        </div>
                        <div className="bg-white p-2.5 rounded-xl border border-slate-200/60">
                          <span className="text-slate-500 block text-[10px]">رمز التحقق (Checksum):</span>
                          <span className="font-bold text-emerald-600 font-mono">
                            {restoreValidation.checksumMatch ? 'مطابق وسليم ✅' : 'تنسيق مباشر'}
                          </span>
                        </div>
                      </div>

                      {/* Restore Action Button */}
                      <button
                        type="button"
                        onClick={() => setShowRestoreConfirm(true)}
                        disabled={isProcessing}
                        className="w-full py-3 bg-amber-600 hover:bg-amber-700 active:scale-98 text-white rounded-xl font-black text-xs sm:text-sm shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                      >
                        <RotateCcw size={16} />
                        <span>تأكيد واستعادة هذه النسخة الآن</span>
                      </button>
                    </div>
                  )}

                  {/* Confirmation Modal */}
                  {showRestoreConfirm && (
                    <div className="fixed inset-0 z-[130] bg-slate-900/70 backdrop-blur-2xs flex items-center justify-center p-4">
                      <div className="bg-white rounded-2xl p-5 max-w-sm w-full space-y-4 text-right dir-rtl shadow-2xl border border-amber-200">
                        <div className="flex items-center gap-2.5 text-amber-700">
                          <AlertTriangle size={22} />
                          <h3 className="font-black text-sm text-slate-900">تأكيد استعادة البيانات</h3>
                        </div>
                        <p className="text-xs text-slate-600 leading-relaxed">
                          هل أنت متأكد من رغبتك في استعادة هذه النسخة؟
                          <br />
                          <strong className="text-slate-800">ملاحظة هامة:</strong> سيتم أخذ نسخة أمان تلقائية من بياناتك الحالية قبل التحديث.
                        </p>
                        <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
                          <button
                            type="button"
                            onClick={() => setShowRestoreConfirm(false)}
                            className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl cursor-pointer"
                          >
                            إلغاء
                          </button>
                          <button
                            type="button"
                            onClick={handleConfirmRestore}
                            disabled={isProcessing}
                            className="px-5 py-2 bg-amber-600 hover:bg-amber-700 text-white text-xs font-black rounded-xl shadow-xs cursor-pointer flex items-center gap-1.5"
                          >
                            {isProcessing ? <RefreshCw size={14} className="animate-spin" /> : <Check size={14} />}
                            <span>استعادة الآن</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  )}

                </>
              )}

            </div>
          )}

        </div>

        {/* Modal Footer */}
        <div className="bg-slate-50 px-6 py-3.5 border-t border-slate-200/80 flex items-center justify-between">
          <div className="text-[11px] text-slate-500 font-medium">
            نظام النسخ الاحتياطي الشامل v2.0
          </div>
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 bg-slate-200 hover:bg-slate-300 text-slate-800 rounded-xl font-bold text-xs transition-colors cursor-pointer"
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
}
