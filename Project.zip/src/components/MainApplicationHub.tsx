/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef } from 'react';
import { 
  Building2, 
  Boxes, 
  Landmark, 
  Award, 
  Database, 
  TrendingUp, 
  DollarSign, 
  Users, 
  ArrowRight, 
  User, 
  Phone, 
  Sparkles, 
  Layers, 
  Clock, 
  Briefcase, 
  CheckCircle2, 
  FileText,
  Wallet,
  Coins,
  ChevronLeft,
  Share2,
  Globe,
  Cloud,
  Lock,
  HardDrive,
  Download,
  Upload,
  FileJson,
  Check,
  AlertTriangle,
  Save,
  Copy,
  KeyRound
} from 'lucide-react';
import { Project, formatCurrency, COMPANY_LOGO_BASE64, GeneralDebt, CompanyAsset, getFormattedReportDate, ensureDateInFilename } from '../types';
import { useBodyScrollLock } from '../utils/modalScrollLock';

interface MainApplicationHubProps {
  projects: Project[];
  activeProjectId: string;
  onSelectProject: (id: string) => void;
  currency?: string;
  companyName?: string;
  companyAddress?: string;
  companyPhone?: string;
  companyLogo?: string;
  designerName?: string;
  designerPhone?: string;
  projectId?: string | null;
  sharedRole?: string | null;
  syncStatus?: 'idle' | 'loading' | 'success' | 'error';
  onCreateShareLink?: (role?: 'read' | 'add' | 'full') => Promise<string>;
  onSetProjectId?: (id: string) => void;
  onCancelCloudSync?: () => Promise<void> | void;
  onRestoreOwnerRole?: () => void;
  onRestoreAllProjects?: (
    data: {
      projects: Project[];
      settings?: any;
      externalDebts?: any[];
      generalDebts?: any[];
      companyAssets?: any[];
      evaluations?: any[];
    },
    mode: 'overwrite' | 'merge'
  ) => void;
  onOpenGlobalBackup?: () => void;
  setActiveTab: (tab: string) => void;
  generalDebts?: GeneralDebt[];
  companyAssets?: CompanyAsset[];
  currentUser?: string;
}

export default function MainApplicationHub({
  projects = [],
  activeProjectId,
  onSelectProject,
  currency = 'YER',
  companyName = 'ورلد أوف إيليتس للتجارة والمقاولات',
  companyAddress = '',
  companyPhone = '',
  companyLogo = COMPANY_LOGO_BASE64,
  designerName = 'م/ ياسر عقيل',
  designerPhone = '771999911',
  projectId,
  sharedRole,
  syncStatus = 'idle',
  onCreateShareLink,
  onSetProjectId,
  onCancelCloudSync,
  onRestoreOwnerRole,
  onRestoreAllProjects,
  onOpenGlobalBackup,
  setActiveTab,
  generalDebts = [],
  companyAssets = [],
  currentUser = 'المدير'
}: MainApplicationHubProps) {
  // Modal States
  const [showCloudShareModal, setShowCloudShareModal] = useState(false);
  const [showLocalModeModal, setShowLocalModeModal] = useState(false);
  const [showFullAppRestoreModal, setShowFullAppRestoreModal] = useState(false);
  const [fullAppRestoreModalData, setFullAppRestoreModalData] = useState<any>(null);
  const [fullAppRestoreMode, setFullAppRestoreMode] = useState<'overwrite' | 'merge'>('overwrite');

  // Sharing Links & Join State
  const [copiedRole, setCopiedRole] = useState<string | null>(null);
  const [generatingRole, setGeneratingRole] = useState<string | null>(null);
  const [shareInputId, setShareInputId] = useState('');
  const [shareInputError, setShareInputError] = useState('');

  // Ref for full application JSON upload
  const fullBackupFileInputRef = useRef<HTMLInputElement>(null);

  // Lock background scroll when any modal is open
  useBodyScrollLock(Boolean(showCloudShareModal || showLocalModeModal || (showFullAppRestoreModal && fullAppRestoreModalData)));

  // Handle Full App Backup Export
  const handleExportFullAppBackupJSON = () => {
    try {
      const externalDebtsRaw = localStorage.getItem('site_external_debts');
      const externalDebts = externalDebtsRaw ? JSON.parse(externalDebtsRaw) : [];

      const generalDebtsRaw = localStorage.getItem('site_general_debts');
      const generalDebtsList = generalDebts && generalDebts.length > 0 ? generalDebts : (generalDebtsRaw ? JSON.parse(generalDebtsRaw) : []);

      const companyAssetsRaw = localStorage.getItem('site_company_assets');
      const companyAssetsList = companyAssets && companyAssets.length > 0 ? companyAssets : (companyAssetsRaw ? JSON.parse(companyAssetsRaw) : []);

      const evaluationsRaw = localStorage.getItem('site_performance_evaluations');
      const evaluationsList = evaluationsRaw ? JSON.parse(evaluationsRaw) : [];

      const activeWorkersRaw = localStorage.getItem('site_workers');
      const activeEmployeesRaw = localStorage.getItem('site_employees');
      const activeSuppliersRaw = localStorage.getItem('site_suppliers');
      const activeExpensesRaw = localStorage.getItem('site_expenses');
      const activeBudgetRaw = localStorage.getItem('site_budget');

      const syncedProjects = projects.map(p => {
        if (p.id === activeProjectId) {
          return {
            ...p,
            budget: activeBudgetRaw ? JSON.parse(activeBudgetRaw) : (p.budget || []),
            workers: activeWorkersRaw ? JSON.parse(activeWorkersRaw) : (p.workers || []),
            employees: activeEmployeesRaw ? JSON.parse(activeEmployeesRaw) : (p.employees || []),
            suppliers: activeSuppliersRaw ? JSON.parse(activeSuppliersRaw) : (p.suppliers || []),
            expenses: activeExpensesRaw ? JSON.parse(activeExpensesRaw) : (p.expenses || []),
            updatedAt: new Date().toISOString()
          };
        }
        return p;
      });

      const fullBackupData = {
        app: 'نظام الحسابات وإدارة المشاريع',
        type: 'full_application_backup',
        version: '2.0',
        exportedAt: new Date().toISOString(),
        settings: {
          companyName,
          companyAddress: companyAddress || '',
          companyPhone: companyPhone || '',
          currency,
          activeProjectId
        },
        projectsCount: syncedProjects.length,
        projects: syncedProjects,
        externalDebts: externalDebts,
        generalDebts: generalDebtsList,
        companyAssets: companyAssetsList,
        evaluations: evaluationsList
      };

      const jsonStr = JSON.stringify(fullBackupData, null, 2);
      const blob = new Blob([jsonStr], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');

      const dateStr = getFormattedReportDate();
      link.href = url;
      link.download = ensureDateInFilename(`نسخة_احتياطية_شاملة_لكافة_المشاريع_${dateStr}.json`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      if (typeof window !== 'undefined' && (window as any).showToast) {
        (window as any).showToast('✅ تم تصدير النسخة الاحتياطية الشاملة لكافة مشاريع وبيانات التطبيق بنجاح!');
      }
    } catch (err) {
      console.error('Error exporting full application backup:', err);
      alert('⚠️ حدث خطأ أثناء إنشاء النسخة الاحتياطية لكافة المشاريع!');
    }
  };

  // Handle Full App JSON File Selection
  const handleFullAppJSONSelected = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const content = event.target?.result as string;
        const parsed = JSON.parse(content);

        let parsedProjects: Project[] = [];
        let parsedSettings = parsed.settings || {};
        let parsedDebts = parsed.externalDebts || [];
        let parsedGeneralDebts = parsed.generalDebts || [];
        let parsedCompanyAssets = parsed.companyAssets || [];
        let parsedEvaluations = parsed.evaluations || [];

        if (Array.isArray(parsed.projects) && parsed.projects.length > 0) {
          parsedProjects = parsed.projects;
        } else if (Array.isArray(parsed) && parsed.length > 0) {
          parsedProjects = parsed;
        } else if (parsed.data || parsed.expenses || parsed.workers || parsed.employees || parsed.suppliers || parsed.budget) {
          // Single project backup format converted to list
          const singleData = parsed.data || parsed;
          const singleProj: Project = {
            id: parsed.id || 'proj_imp_' + Date.now(),
            name: parsedSettings.projectName || parsed.projectName || parsed.name || 'مشروع مستورد',
            location: parsedSettings.companyAddress || parsed.location || '',
            client: parsed.client || '',
            status: parsed.status || 'active',
            startDate: parsed.startDate || new Date().toISOString().split('T')[0],
            endDate: parsed.endDate || '',
            notes: parsed.notes || 'مستورد من ملف نسخة احتياطية',
            createdAt: parsed.createdAt || new Date().toISOString(),
            updatedAt: parsed.updatedAt || new Date().toISOString(),
            budget: singleData.budget || parsed.budget || [],
            workers: singleData.workers || parsed.workers || [],
            employees: singleData.employees || parsed.employees || [],
            suppliers: singleData.suppliers || parsed.suppliers || [],
            expenses: singleData.expenses || parsed.expenses || []
          };
          parsedProjects = [singleProj];
          if (singleData.externalDebts || parsed.externalDebts) {
            parsedDebts = singleData.externalDebts || parsed.externalDebts;
          }
          if (singleData.generalDebts || parsed.generalDebts) {
            parsedGeneralDebts = singleData.generalDebts || parsed.generalDebts;
          }
        } else {
          alert('⚠️ الملف المحدد لا يحتوي على بيانات صالحة لمشاريع التطبيق!');
          return;
        }

        const totalExpensesCount = parsedProjects.reduce((acc, p) => acc + (p.expenses?.length || 0), 0);
        const totalWorkersCount = parsedProjects.reduce((acc, p) => acc + (p.workers?.length || 0), 0);
        const totalEmployeesCount = parsedProjects.reduce((acc, p) => acc + (p.employees?.length || 0), 0);
        const totalSuppliersCount = parsedProjects.reduce((acc, p) => acc + (p.suppliers?.length || 0), 0);

        setFullAppRestoreModalData({
          fileDate: parsed.exportedAt ? new Date(parsed.exportedAt).toLocaleString('ar-YE') : 'غير محدد',
          settings: parsedSettings,
          projects: parsedProjects,
          externalDebts: parsedDebts,
          generalDebts: parsedGeneralDebts,
          companyAssets: parsedCompanyAssets,
          evaluations: parsedEvaluations,
          projectsCount: parsedProjects.length,
          totalExpensesCount,
          totalWorkersCount,
          totalEmployeesCount,
          totalSuppliersCount
        });
        setShowFullAppRestoreModal(true);
      } catch (err) {
        console.error('Error parsing full app JSON backup:', err);
        alert('⚠️ الملف المحدد غير صالح أو تالف! يرجى التأكد من اختيار ملف JSON صحيح.');
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  // Confirm Full App Restore
  const handleConfirmFullAppRestore = () => {
    if (!fullAppRestoreModalData || !onRestoreAllProjects) return;
    onRestoreAllProjects(
      {
        projects: fullAppRestoreModalData.projects,
        settings: fullAppRestoreModalData.settings,
        externalDebts: fullAppRestoreModalData.externalDebts,
        generalDebts: fullAppRestoreModalData.generalDebts,
        companyAssets: fullAppRestoreModalData.companyAssets,
        evaluations: fullAppRestoreModalData.evaluations
      },
      fullAppRestoreMode
    );
    setShowFullAppRestoreModal(false);
    setFullAppRestoreModalData(null);
  };

  // Generate & Copy Link
  const handleCopyLink = async (role: 'read' | 'add' | 'full') => {
    if (!onCreateShareLink) return;
    setGeneratingRole(role);
    try {
      const link = await onCreateShareLink(role);
      if (link) {
        await navigator.clipboard.writeText(link);
        setCopiedRole(role);
        setTimeout(() => setCopiedRole(null), 3500);
        if (typeof window !== 'undefined' && (window as any).showToast) {
          (window as any).showToast(`تم نسخ رابط المشاركة بصلاحية (${role === 'read' ? 'قراءة فقط' : role === 'add' ? 'إضافة حركات' : 'صلاحية كاملة'}) بنجاح!`);
        }
      }
    } catch (err) {
      console.error(err);
    } finally {
      setGeneratingRole(null);
    }
  };

  // Join Project Submit
  const handleJoinProjectSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!shareInputId.trim()) {
      setShareInputError('يرجى إدخال رمز المشروع أو رابط المشاركة');
      return;
    }
    setShareInputError('');
    let id = shareInputId.trim();
    if (id.includes('project=')) {
      const match = id.match(/project=([^&]+)/);
      if (match) id = match[1];
    }
    if (onSetProjectId) {
      onSetProjectId(id);
      setShowCloudShareModal(false);
      if (typeof window !== 'undefined' && (window as any).showToast) {
        (window as any).showToast('جاري الاتصال بالمشروع السحابي...');
      }
    }
  };
  // Consolidated Metrics Calculations
  const totalProjectsCount = projects.length;
  const activeProjectsCount = projects.filter(p => p.status === 'active').length;
  const completedProjectsCount = projects.filter(p => p.status === 'completed').length;
  
  const consolidatedBudget = projects.reduce((sum, proj) => {
    return sum + (proj.budget || []).reduce((bSum, b) => bSum + b.amount, 0);
  }, 0);

  const consolidatedExpenses = projects.reduce((sum, proj) => {
    return sum + (proj.expenses || []).reduce((eSum, e) => eSum + e.amount, 0);
  }, 0);

  const consolidatedRemaining = consolidatedBudget - consolidatedExpenses;
  const totalWorkersCount = projects.reduce((sum, proj) => sum + (proj.workers || []).length, 0);
  const totalEmployeesCount = projects.reduce((sum, proj) => sum + (proj.employees || []).length, 0);
  const totalSuppliersCount = projects.reduce((sum, proj) => sum + (proj.suppliers || []).length, 0);

  // General Debts stats
  const activeGeneralDebtsCount = generalDebts.filter(d => d.status !== 'settled').length;
  const totalGeneralDebtsAmount = generalDebts.reduce((sum, d) => {
    const paid = (d.payments || []).reduce((pSum, p) => pSum + (Number(p.amount) || 0), 0);
    return sum + Math.max(0, (Number(d.totalAmount) || 0) - paid);
  }, 0);

  // Company Assets stats
  const totalAssetsCount = companyAssets.length;
  const totalAssetsValue = companyAssets.reduce((sum, a) => sum + (Number(a.purchasePrice) || 0), 0);

  // Active Project Reference
  const activeProject = projects.find(p => p.id === activeProjectId) || projects[0];

  return (
    <div className="space-y-6 dir-rtl text-right pb-12 animate-fade-in">
      
      {/* ======================= BRAND HEADER BANNER ======================= */}
      <div className="bg-gradient-to-r from-slate-900 via-sky-950 to-slate-900 rounded-3xl p-6 sm:p-8 text-white shadow-xl relative overflow-hidden border border-sky-500/30">
        <div className="absolute -left-12 -bottom-12 w-56 h-56 bg-sky-500/10 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute -right-12 -top-12 w-56 h-56 bg-amber-500/10 rounded-full blur-3xl pointer-events-none"></div>

        <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-6">
          
          {/* Logo & Company Title Box */}
          <div className="flex items-center gap-4 sm:gap-6 text-center md:text-right w-full flex-col sm:flex-row">
            <div className="w-24 h-18 sm:w-28 sm:h-20 rounded-xl p-1 bg-white shadow-xl shadow-slate-950/40 shrink-0 flex items-center justify-center group hover:scale-105 transition-transform ring-2 ring-white/20 border border-slate-700/50">
              <div className="w-full h-full rounded-lg overflow-hidden bg-white flex items-center justify-center p-1">
                <img 
                  src={companyLogo || localStorage.getItem('site_company_custom_logo') || COMPANY_LOGO_BASE64} 
                  alt="شعار الشركة" 
                  className="w-full h-full object-contain" 
                />
              </div>
            </div>

            <div className="space-y-2 flex-1">
              <h1 className="text-base sm:text-lg md:text-xl font-black text-white tracking-tight leading-snug whitespace-nowrap overflow-hidden text-ellipsis">
                {companyName}
              </h1>

              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 text-xs font-bold border border-amber-400/30">
                <Building2 size={14} className="animate-pulse text-amber-400" />
                <span>نظام الحسابات وإدارة المشاريع الإنشائية</span>
              </div>

              {/* Designer Details */}
              <div className="flex flex-wrap items-center justify-center md:justify-start gap-3 text-xs text-sky-200 font-bold pt-1">
                <span className="flex items-center gap-1 bg-slate-800/80 px-2.5 py-1 rounded-lg border border-slate-700">
                  <User size={13} className="text-sky-400" />
                  تصميم: {designerName}
                </span>
                <span className="flex items-center gap-1 bg-slate-800/80 px-2.5 py-1 rounded-lg border border-slate-700">
                  <Phone size={13} className="text-emerald-400" />
                  رقم الهاتف: {designerPhone}
                </span>
              </div>
            </div>
          </div>

        </div>
      </div>

      {/* ======================= CONSOLIDATED FINANCIAL SUMMARY CARDS ======================= */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-2 sm:gap-3">
        
        {/* Total Projects Card */}
        <div className="bg-white rounded-2xl p-2.5 sm:p-3 border border-slate-200/80 shadow-xs hover:shadow-md transition-all">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-[11px] font-bold">إجمالي المشاريع</span>
            <div className="p-1.5 bg-indigo-50 text-indigo-600 rounded-lg">
              <Building2 size={16} />
            </div>
          </div>
          <div className="flex items-baseline gap-1.5">
            <span className="text-lg sm:text-xl font-black text-slate-900">{totalProjectsCount}</span>
            <span className="text-[10px] font-bold text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded-full">
              {activeProjectsCount} نشط
            </span>
          </div>
        </div>

        {/* Consolidated Budget */}
        <div className="bg-white rounded-2xl p-2.5 sm:p-3 border border-slate-200/80 shadow-xs hover:shadow-md transition-all">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-[11px] font-bold">الميزانية المجمعة</span>
            <div className="p-1.5 bg-sky-50 text-sky-600 rounded-lg">
              <DollarSign size={16} />
            </div>
          </div>
          <div className="text-base sm:text-lg font-black text-sky-700 truncate">
            {formatCurrency(consolidatedBudget, currency)}
          </div>
        </div>

        {/* Consolidated Expenses */}
        <div className="bg-white rounded-2xl p-2.5 sm:p-3 border border-slate-200/80 shadow-xs hover:shadow-md transition-all">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-[11px] font-bold">المصروفات المجمعة</span>
            <div className="p-1.5 bg-rose-50 text-rose-600 rounded-lg">
              <TrendingUp size={16} />
            </div>
          </div>
          <div className="text-base sm:text-lg font-black text-rose-600 truncate">
            {formatCurrency(consolidatedExpenses, currency)}
          </div>
        </div>

        {/* Consolidated Remaining Balance */}
        <div className="bg-white rounded-2xl p-2.5 sm:p-3 border border-slate-200/80 shadow-xs hover:shadow-md transition-all col-span-1">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-[11px] font-bold">الرصيد الصافي المتبقي</span>
            <div className={`p-1.5 rounded-lg ${consolidatedRemaining >= 0 ? 'bg-emerald-50 text-emerald-600' : 'bg-rose-50 text-rose-600'}`}>
              <DollarSign size={16} />
            </div>
          </div>
          <div className={`text-base sm:text-lg font-black truncate ${consolidatedRemaining >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
            {formatCurrency(consolidatedRemaining, currency)}
          </div>
        </div>

        {/* Total Workforce */}
        <div className="bg-white rounded-2xl p-2.5 sm:p-3 border border-slate-200/80 shadow-xs hover:shadow-md transition-all col-span-2 lg:col-span-1">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-[11px] font-bold">إجمالي الكوادر والعمال</span>
            <div className="p-1.5 bg-violet-50 text-violet-600 rounded-lg">
              <Users size={16} />
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-base sm:text-lg font-black text-slate-900">{totalWorkersCount + totalEmployeesCount}</span>
            <span className="text-[10px] font-bold text-slate-500">
              ({totalWorkersCount} عمال / {totalEmployeesCount} موظف)
            </span>
          </div>
        </div>

      </div>

      {/* ======================= MAJOR SECTIONS GATEWAYS & NAVIGATION ======================= */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-slate-900 text-amber-400 rounded-xl shadow-xs">
              <Layers size={18} />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-black text-slate-900">
                بوابات وأقسام النظام الرئيسية
              </h2>
              <p className="text-xs text-slate-500 font-semibold">
                انتقل مباشرة إلى وحدات إدارة المشاريع، الأصول والمعدات، الديون العامة، والتقييم
              </p>
            </div>
          </div>
        </div>

        {/* 🗂️ 1. HERO GATEWAY: إدارة المشاريع الإنشائية */}
        <div className="bg-gradient-to-r from-slate-900 via-teal-950 to-slate-900 rounded-2xl p-4 sm:p-5 text-white border border-teal-800/80 shadow-md">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3.5">
              <div className="w-12 h-12 rounded-2xl bg-teal-500/20 text-teal-400 border border-teal-500/30 flex items-center justify-center shrink-0 shadow-inner">
                <Building2 size={24} />
              </div>
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <h3 className="text-base sm:text-lg font-extrabold text-white">
                    إدارة المشاريع الإنشائية
                  </h3>
                </div>
                <p className="text-xs text-slate-300 font-medium leading-relaxed">
                  لوحة التحكم بكافة المشاريع الإنشائية والتنفيذية وإضافة المشاريع ومتابعة الإنجاز والميزانيات،<br className="hidden sm:inline" />
                  ونقل الكوادر والعمال بين المشاريع وتصدير التقارير المجمعة.
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => {
                setActiveTab('construction_projects');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="bg-teal-500 hover:bg-teal-400 active:scale-[0.98] text-slate-950 font-black text-xs sm:text-sm py-2.5 px-5 rounded-xl transition-all flex items-center justify-center gap-2 cursor-pointer shadow-md shadow-teal-500/20 shrink-0 self-stretch sm:self-auto"
            >
              <Building2 size={16} />
              <span>فتح نافذة إدارة المشاريع الإنشائية</span>
            </button>
          </div>
        </div>

        {/* 📦 2. GATEWAY: مواد وأصول الشركة والمشاريع */}
        <div className="bg-gradient-to-r from-slate-900 via-teal-950/90 to-slate-900 rounded-2xl p-4 sm:p-5 border border-teal-800/80 shadow-md text-white">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3.5">
              <div className="w-12 h-12 rounded-2xl bg-teal-500/20 text-teal-400 border border-teal-500/30 flex items-center justify-center shrink-0 shadow-inner">
                <Boxes size={24} />
              </div>
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <h3 className="text-base sm:text-lg font-extrabold text-white">
                    مواد وأصول الشركة والمشاريع
                  </h3>
                </div>
                <p className="text-xs text-slate-300 font-medium leading-relaxed">
                  سجل وإدارة مشتريات الأصول الرأسمالية والمعدات والآليات ومواد المخزون وتتبع العهد ومواقعها وسجل التحويلات.
                </p>
                {totalAssetsCount > 0 && (
                  <div className="text-[11px] text-teal-300 font-bold">
                    مسجل حالياً: {totalAssetsCount} أصل / أداة بقيمة إجمالية تقديرية: {formatCurrency(totalAssetsValue, currency)}
                  </div>
                )}
              </div>
            </div>

            <button
              type="button"
              onClick={() => {
                setActiveTab('company_assets');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="bg-teal-500 hover:bg-teal-400 active:scale-[0.98] text-slate-950 font-black text-xs sm:text-sm py-2.5 px-5 rounded-xl transition-all flex items-center justify-center gap-2 cursor-pointer shadow-md shadow-teal-500/20 shrink-0 self-stretch sm:self-auto"
            >
              <Boxes size={16} />
              <span>فتح نافذة أصول ومواد الشركة</span>
            </button>
          </div>
        </div>

        {/* 💳 3. GATEWAY: الديون والالتزامات العامة للشركة */}
        <div className="bg-gradient-to-r from-teal-900 via-slate-900 to-teal-950 rounded-2xl p-4 sm:p-5 border border-teal-800/80 shadow-md text-white">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3.5">
              <div className="w-12 h-12 rounded-2xl bg-teal-500/20 text-teal-400 border border-teal-500/30 flex items-center justify-center shrink-0 shadow-inner">
                <Landmark size={24} />
              </div>
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <h3 className="text-base sm:text-lg font-extrabold text-white">
                    الديون والالتزامات العامة للشركة
                  </h3>
                </div>
                <p className="text-xs text-slate-300 font-medium leading-relaxed">
                  سجل الالتزامات والمستحقات والديون المالية العامة للشركة وإدارتها وسدادها بشكل منفصل.
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => {
                setActiveTab('general_debts');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="bg-teal-500 hover:bg-teal-400 active:scale-[0.98] text-slate-950 font-black text-xs sm:text-sm py-2.5 px-5 rounded-xl transition-all flex items-center justify-center gap-2 cursor-pointer shadow-md shadow-teal-500/20 shrink-0 self-stretch sm:self-auto"
            >
              <Landmark size={16} />
              <span>فتح نافذة الديون العامة</span>
            </button>
          </div>
        </div>

        {/* ⭐ 4. GATEWAY: تقييم الأداء الشامل */}
        <div className="bg-gradient-to-r from-slate-900 via-teal-950 to-slate-900 rounded-2xl p-4 sm:p-5 border border-teal-800/80 shadow-md text-white">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3.5">
              <div className="w-12 h-12 rounded-2xl bg-teal-500/20 text-teal-400 border border-teal-500/30 flex items-center justify-center shrink-0 shadow-inner">
                <Award size={24} />
              </div>
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <h3 className="text-base sm:text-lg font-extrabold text-white">
                    تقييم الأداء الشامل
                  </h3>
                </div>
                <p className="text-xs text-slate-300 font-medium leading-relaxed">
                  نظام تقييم أداء الموظفين - العمال - الموردين بحسب معايير الجودة، وإصدار تقارير الأداء الفردية والجماعية.
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => {
                setActiveTab('evaluations');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="bg-teal-500 hover:bg-teal-400 active:scale-[0.98] text-slate-950 font-black text-xs sm:text-sm py-2.5 px-5 rounded-xl transition-all flex items-center justify-center gap-2 cursor-pointer shadow-md shadow-teal-500/20 shrink-0 self-stretch sm:self-auto"
            >
              <Award size={16} />
              <span>فتح نافذة تقييم الأداء</span>
            </button>
          </div>
        </div>

      </div>

      {/* ======================= ACTIVE PROJECT QUICK STATUS & ENTER SECTION ======================= */}
      {activeProject && (
        <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200 shadow-sm space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
            <div className="flex items-center gap-2.5">
              <div className="p-2 bg-sky-50 text-sky-600 rounded-xl">
                <Building2 size={20} />
              </div>
              <div>
                <h3 className="font-extrabold text-sm sm:text-base text-slate-900">
                  المشروع الإنشائي النشط حالياً: {activeProject.name}
                </h3>
                <p className="text-xs text-slate-500 font-semibold">
                  الموقع: {activeProject.location || 'غير محدد'} • المالك: {activeProject.client || 'غير محدد'}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  onSelectProject(activeProject.id);
                  setActiveTab('dashboard');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="bg-sky-600 hover:bg-sky-700 text-white font-bold text-xs py-2 px-4 rounded-xl flex items-center gap-2 cursor-pointer transition-all shadow-xs"
              >
                <span>الدخول إلى حسابات المشروع</span>
                <ArrowRight size={14} />
              </button>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
            <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
              <span className="text-[10px] font-bold text-slate-500 block">ميزانية المشروع</span>
              <span className="text-xs sm:text-sm font-extrabold text-sky-700">
                {formatCurrency((activeProject.budget || []).reduce((s, b) => s + b.amount, 0), currency)}
              </span>
            </div>

            <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
              <span className="text-[10px] font-bold text-slate-500 block">مصروفات المشروع</span>
              <span className="text-xs sm:text-sm font-extrabold text-rose-600">
                {formatCurrency((activeProject.expenses || []).reduce((s, e) => s + e.amount, 0), currency)}
              </span>
            </div>

            <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
              <span className="text-[10px] font-bold text-slate-500 block">العمال والكوادر</span>
              <span className="text-xs sm:text-sm font-extrabold text-slate-800">
                {(activeProject.workers || []).length} عمال • {(activeProject.employees || []).length} موظف
              </span>
            </div>

            <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
              <span className="text-[10px] font-bold text-slate-500 block">الموردين المسجلين</span>
              <span className="text-xs sm:text-sm font-extrabold text-slate-800">
                {(activeProject.suppliers || []).length} مورد
              </span>
            </div>
          </div>
        </div>
      )}

      {/* ======================= CLOUD SYNC & LOCAL WORK HUB ======================= */}
      <div className="bg-gradient-to-r from-slate-900 via-teal-950 to-slate-900 rounded-2xl p-4 sm:p-5 text-white border border-teal-800/80 shadow-md">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-teal-500/20 text-teal-400 border border-teal-500/30 flex items-center justify-center shrink-0 shadow-inner">
              <Share2 size={24} />
            </div>
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <h3 className="text-base sm:text-lg font-extrabold text-white">
                  المشاركة السحابية للبيانات والعمل المحلي
                </h3>
              </div>
              <p className="text-xs text-slate-300 font-medium leading-relaxed">
                إدارة المزامنة اللحظية والعمل الجماعي مع المشرفين والمهندسين وتوليد روابط المشاركة بالصلاحيات المختلفة.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 flex-wrap sm:flex-nowrap shrink-0 self-stretch sm:self-auto">
            <button
              type="button"
              onClick={() => setShowCloudShareModal(true)}
              className="bg-teal-500 hover:bg-teal-400 active:scale-[0.98] text-slate-950 font-black text-xs sm:text-sm py-2.5 px-5 rounded-xl transition-all flex items-center justify-center gap-2 cursor-pointer shadow-md shadow-teal-500/20 w-full sm:w-auto"
            >
              <Share2 size={16} />
              <span>المشاركة السحابية والتعاون</span>
            </button>

            <button
              type="button"
              onClick={() => setShowLocalModeModal(true)}
              className="bg-slate-800 hover:bg-slate-700 active:scale-[0.98] text-slate-200 font-bold text-xs sm:text-sm py-2.5 px-4 rounded-xl transition-all flex items-center justify-center gap-2 cursor-pointer border border-slate-700 w-full sm:w-auto"
            >
              <HardDrive size={16} className="text-teal-400" />
              <span>الوضع المحلي</span>
            </button>
          </div>
        </div>
      </div>

      {/* ======================= COMPREHENSIVE FULL APPLICATION BACKUP & RESTORE ======================= */}
      <div className="bg-gradient-to-r from-slate-900 via-teal-950/90 to-slate-900 rounded-2xl p-4 sm:p-5 border border-teal-800/80 shadow-md text-white space-y-4">
        <div className="flex items-center justify-between gap-3.5 flex-wrap">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-teal-500/20 text-teal-400 border border-teal-500/30 flex items-center justify-center shrink-0 shadow-inner">
              <Database size={24} />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-extrabold text-white">
                إدارة النسخ الاحتياطي الشامل واستعادة كافة بيانات التطبيق
              </h3>
              <p className="text-xs text-slate-300 font-medium leading-relaxed">
                تصدير واستعادة ملف شامل لكافة المشاريع، الديون العامة، أصول وممتلكات الشركة، تقييم الأداء، والبيانات المالية دفعة واحدة.
              </p>
            </div>
          </div>
          {onOpenGlobalBackup && (
            <button
              type="button"
              onClick={onOpenGlobalBackup}
              className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs sm:text-sm py-2 px-4 rounded-xl transition-all flex items-center gap-2 cursor-pointer shadow-md"
            >
              <KeyRound size={16} />
              <span>مركز النسخ الشامل المتقدم</span>
            </button>
          )}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
          {/* Export Full App Backup */}
          <div className="bg-slate-950/60 rounded-xl p-3.5 border border-teal-900/60 flex flex-col justify-between gap-3">
            <div className="space-y-1">
              <div className="flex items-center gap-2 text-teal-300 font-bold text-xs sm:text-sm">
                <Download size={16} className="text-teal-400" />
                <span>تصدير نسخة شاملة لكافة بيانات التطبيق</span>
              </div>
              <p className="text-[11px] text-slate-300 leading-relaxed font-medium">
                توليد وتنزيل ملف JSON شامل ومؤمن لجميع المشاريع الإنشائية ({projects.length} مشاريع) والديون العامة وأصول الشركة وسجلات التقييم لحفظها بأمان.
              </p>
            </div>
            <button
              type="button"
              onClick={handleExportFullAppBackupJSON}
              className="bg-teal-600 hover:bg-teal-500 active:scale-[0.98] text-white font-extrabold text-xs sm:text-sm py-2.5 px-4 rounded-xl transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xs w-full"
            >
              <FileJson size={16} />
              <span>تنزيل ملف النسخة الاحتياطية الشاملة (JSON)</span>
            </button>
          </div>

          {/* Import Full App Backup */}
          <div className="bg-slate-950/60 rounded-xl p-3.5 border border-teal-900/60 flex flex-col justify-between gap-3">
            <div className="space-y-1">
              <div className="flex items-center gap-2 text-teal-300 font-bold text-xs sm:text-sm">
                <Upload size={16} className="text-teal-400" />
                <span>استعادة بيانات التطبيق من ملف شامل</span>
              </div>
              <p className="text-[11px] text-slate-300 leading-relaxed font-medium">
                استرجاع بيانات المشاريع والحسابات والموظفين والعمال والديون العامة والأصول من ملف شامل سابق مع إمكانية الدمج أو الاستبدال.
              </p>
            </div>
            <div>
              <input
                type="file"
                ref={fullBackupFileInputRef}
                onChange={handleFullAppJSONSelected}
                accept=".json"
                className="hidden"
              />
              <button
                type="button"
                onClick={() => fullBackupFileInputRef.current?.click()}
                className="bg-teal-500 hover:bg-teal-400 active:scale-[0.98] text-slate-950 font-black text-xs sm:text-sm py-2.5 px-4 rounded-xl transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xs w-full"
              >
                <Upload size={16} />
                <span>اختيار ملف النسخة الشاملة للاستعادة</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* ======================= MODAL 1: CLOUD SHARE MODAL ======================= */}
      {showCloudShareModal && (
        <div 
          className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 animate-fade-in overflow-y-auto overscroll-contain"
          onClick={() => setShowCloudShareModal(false)}
          onTouchMove={(e) => {
            if (e.target === e.currentTarget) e.preventDefault();
          }}
        >
          <div 
            className="bg-slate-900 border border-slate-700 rounded-3xl w-full max-w-lg overflow-hidden shadow-2xl text-white my-auto max-h-[92vh] sm:max-h-[88vh] flex flex-col modal-dialog-card overscroll-contain touch-pan-y"
            onClick={e => e.stopPropagation()}
          >
            {/* Header */}
            <div className="p-4 sm:p-5 bg-gradient-to-r from-sky-950 via-slate-900 to-slate-900 border-b border-slate-800 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-sky-500/20 text-sky-400 rounded-2xl border border-sky-400/30">
                  <Share2 size={22} />
                </div>
                <div>
                  <h3 className="font-black text-base sm:text-lg text-white">المشاركة السحابية والتعاون الحي</h3>
                  <p className="text-xs text-sky-200">العمل المشترك على كافة المشاريع ومزامنة البيانات</p>
                </div>
              </div>
              <button 
                onClick={() => setShowCloudShareModal(false)}
                className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* Content Body */}
            <div className="p-4 sm:p-6 space-y-5 overflow-y-auto flex-1 text-right overscroll-contain touch-pan-y custom-scrollbar modal-scroll-area">
              
              {/* If Current User is not owner (i.e. guest/participant via link) */}
              {sharedRole && sharedRole !== 'owner' ? (
                <div className="bg-amber-500/10 border border-amber-500/30 rounded-2xl p-4 space-y-3">
                  <div className="flex items-center gap-2 text-amber-300 font-bold text-sm">
                    <Lock size={18} />
                    <span>أنت تعمل حالياً بصلاحية مشاركة مقيدة ({sharedRole === 'read' ? 'قراءة فقط' : 'إضافة حركات'})</span>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed font-medium">
                    تم فتح التطبيق بواسطة رابط مشاركة سحابي. لا يمكنك توليد روابط جديدة إلا إذا كنت المالك الرئيسي للمشروع.
                  </p>
                  {onRestoreOwnerRole && (
                    <button
                      onClick={() => {
                        onRestoreOwnerRole();
                        setShowCloudShareModal(false);
                      }}
                      className="w-full bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs py-2.5 px-4 rounded-xl transition-all shadow-md cursor-pointer"
                    >
                      👑 استعادة صلاحية المالك الرئيسي (Owner Mode)
                    </button>
                  )}
                </div>
              ) : (
                <>
                  {/* Sync Status Badge */}
                  <div className="bg-slate-800/80 rounded-2xl p-3.5 border border-slate-700 flex items-center justify-between">
                    <div className="flex items-center gap-2 text-xs">
                      <span className="text-slate-400">حالة السحابة الحالية:</span>
                      <span className={`font-bold flex items-center gap-1.5 ${
                        syncStatus === 'loading' ? 'text-amber-400' :
                        syncStatus === 'success' ? 'text-emerald-400' :
                        syncStatus === 'error' ? 'text-rose-400' : 'text-sky-400'
                      }`}>
                        <span className={`w-2 h-2 rounded-full ${
                          syncStatus === 'loading' ? 'bg-amber-400 animate-ping' :
                          syncStatus === 'success' ? 'bg-emerald-400 animate-pulse' :
                          syncStatus === 'error' ? 'bg-rose-400' : 'bg-sky-400'
                        }`}></span>
                        {syncStatus === 'loading' ? 'جاري المزامنة...' :
                         syncStatus === 'success' ? 'متصل ومتزامن لحظياً' :
                         syncStatus === 'error' ? 'خطأ في الاتصال' : 'جاهز للمزامنة'}
                      </span>
                    </div>

                    {projectId && onCancelCloudSync && (
                      <button
                        onClick={async () => {
                          await onCancelCloudSync();
                          setShowCloudShareModal(false);
                        }}
                        className="text-[11px] font-bold text-rose-400 hover:text-rose-300 bg-rose-500/10 hover:bg-rose-500/20 px-3 py-1 rounded-lg border border-rose-500/20 cursor-pointer"
                      >
                        قطع الاتصال السحابي
                      </button>
                    )}
                  </div>

                  {/* Share Role Links Generation */}
                  <div className="space-y-3">
                    <label className="block text-xs font-black text-slate-300">
                      توليد روابط المشاركة بالصلاحيات المناسبة:
                    </label>

                    {/* 1. Full Control */}
                    <div className="bg-slate-800/60 rounded-2xl p-3.5 border border-slate-700/80 flex items-center justify-between gap-3">
                      <div className="space-y-0.5 text-right">
                        <div className="flex items-center gap-1.5 text-xs font-black text-emerald-400">
                          <span>رابط مشاركة بصلاحية كاملة (مشرف/محاسب رئيسي)</span>
                        </div>
                        <p className="text-[11px] text-slate-400 font-medium">يتيح الإضافة والتعديل والحذف لكافة سجلات ومشاريع التطبيق</p>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleCopyLink('full')}
                        disabled={generatingRole === 'full'}
                        className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs py-2 px-3.5 rounded-xl shrink-0 flex items-center gap-1.5 cursor-pointer shadow-xs disabled:opacity-50"
                      >
                        {copiedRole === 'full' ? <Check size={14} className="text-white" /> : <Copy size={14} />}
                        <span>{copiedRole === 'full' ? 'تم النسخ!' : 'نسخ الرابط'}</span>
                      </button>
                    </div>

                    {/* 2. Add Only */}
                    <div className="bg-slate-800/60 rounded-2xl p-3.5 border border-slate-700/80 flex items-center justify-between gap-3">
                      <div className="space-y-0.5 text-right">
                        <div className="flex items-center gap-1.5 text-xs font-black text-sky-400">
                          <span>رابط مشاركة بصلاحية إضافة حركات (مهندس موقع)</span>
                        </div>
                        <p className="text-[11px] text-slate-400 font-medium">يتيح تسجيل المصروفات واليوميات والعهد دون تعديل أو حذف البيانات السابقة</p>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleCopyLink('add')}
                        disabled={generatingRole === 'add'}
                        className="bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs py-2 px-3.5 rounded-xl shrink-0 flex items-center gap-1.5 cursor-pointer shadow-xs disabled:opacity-50"
                      >
                        {copiedRole === 'add' ? <Check size={14} className="text-white" /> : <Copy size={14} />}
                        <span>{copiedRole === 'add' ? 'تم النسخ!' : 'نسخ الرابط'}</span>
                      </button>
                    </div>

                    {/* 3. Read Only */}
                    <div className="bg-slate-800/60 rounded-2xl p-3.5 border border-slate-700/80 flex items-center justify-between gap-3">
                      <div className="space-y-0.5 text-right">
                        <div className="flex items-center gap-1.5 text-xs font-black text-amber-400">
                          <span>رابط مشاركة للقراءة والتقارير فقط (مالك / عميل)</span>
                        </div>
                        <p className="text-[11px] text-slate-400 font-medium">يتيح استعراض الحسابات وطباعة التقارير دون إمكانية التعديل</p>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleCopyLink('read')}
                        disabled={generatingRole === 'read'}
                        className="bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs py-2 px-3.5 rounded-xl shrink-0 flex items-center gap-1.5 cursor-pointer shadow-xs disabled:opacity-50"
                      >
                        {copiedRole === 'read' ? <Check size={14} className="text-white" /> : <Copy size={14} />}
                        <span>{copiedRole === 'read' ? 'تم النسخ!' : 'نسخ الرابط'}</span>
                      </button>
                    </div>
                  </div>

                  {/* Join Existing Cloud Project */}
                  <form onSubmit={handleJoinProjectSubmit} className="pt-2 border-t border-slate-800 space-y-2.5">
                    <label className="block text-xs font-black text-slate-300">
                      الانضمام إلى سحابة مشروع قائمة (إدخال رمز أو رابط):
                    </label>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={shareInputId}
                        onChange={(e) => setShareInputId(e.target.value)}
                        placeholder="أدخل رمز المشروع أو الصق رابط المشاركة هنا..."
                        className="flex-1 bg-slate-800 border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-sky-500"
                      />
                      <button
                        type="submit"
                        className="bg-sky-500 hover:bg-sky-400 text-slate-950 font-black text-xs px-4 py-2 rounded-xl transition-all cursor-pointer shadow-sm"
                      >
                        اتصال
                      </button>
                    </div>
                    {shareInputError && (
                      <p className="text-[11px] text-rose-400 font-bold">{shareInputError}</p>
                    )}
                  </form>
                </>
              )}

            </div>

            {/* Footer */}
            <div className="p-4 bg-slate-950 border-t border-slate-800 flex justify-end shrink-0">
              <button
                type="button"
                onClick={() => setShowCloudShareModal(false)}
                className="bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs py-2 px-5 rounded-xl transition-all cursor-pointer"
              >
                إغلاق
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ======================= MODAL 2: LOCAL MODE INFO MODAL ======================= */}
      {showLocalModeModal && (
        <div 
          className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 animate-fade-in overflow-y-auto overscroll-contain"
          onClick={() => setShowLocalModeModal(false)}
          onTouchMove={(e) => {
            if (e.target === e.currentTarget) e.preventDefault();
          }}
        >
          <div 
            className="bg-slate-900 border border-slate-700 rounded-3xl w-full max-w-md overflow-hidden shadow-2xl text-white my-auto flex flex-col modal-dialog-card overscroll-contain touch-pan-y max-h-[92vh] sm:max-h-[88vh]"
            onClick={e => e.stopPropagation()}
          >
            <div className="p-4 sm:p-5 bg-gradient-to-r from-amber-950 via-slate-900 to-slate-900 border-b border-slate-800 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-amber-500/20 text-amber-400 rounded-2xl border border-amber-400/30">
                  <HardDrive size={22} />
                </div>
                <div>
                  <h3 className="font-black text-base text-white">الوضع المحلي الفردي (أوفلاين)</h3>
                  <p className="text-xs text-amber-200">البيانات محفوظة على ذاكرة هذا الجهاز فقط</p>
                </div>
              </div>
              <button 
                onClick={() => setShowLocalModeModal(false)}
                className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="p-5 space-y-3.5 text-right text-xs leading-relaxed text-slate-300 overflow-y-auto flex-1 overscroll-contain touch-pan-y custom-scrollbar modal-scroll-area">
              <div className="p-3.5 bg-slate-800/80 rounded-2xl border border-slate-700 space-y-2">
                <div className="flex items-center gap-2 font-black text-white text-sm">
                  <Check size={16} className="text-emerald-400" />
                  <span>خصوصية تامة وسرعة فائقة</span>
                </div>
                <p className="text-slate-300 font-medium">
                  يعمل التطبيق بكامل وظائفه المحاسبية دون الحاجة لأي اتصال بالإنترنت، ويتم تخزين كافة البيانات بأمان على جهازك.
                </p>
              </div>

              <div className="p-3.5 bg-amber-500/10 rounded-2xl border border-amber-500/30 space-y-1.5">
                <div className="flex items-center gap-2 font-bold text-amber-300">
                  <AlertTriangle size={16} />
                  <span>نصيحة أمان هامة</span>
                </div>
                <p className="text-slate-300 font-medium">
                  يرجى تنزيل نسخة احتياطية JSON دورياً من زر "تنزيل ملف النسخة الاحتياطية الشاملة" لضمان عدم ضياع البيانات في حال مسح متصفحك أو تغيير الجهاز.
                </p>
              </div>
            </div>

            <div className="p-4 bg-slate-950 border-t border-slate-800 flex justify-end shrink-0">
              <button
                type="button"
                onClick={() => setShowLocalModeModal(false)}
                className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs py-2 px-5 rounded-xl transition-all cursor-pointer shadow-md"
              >
                فهمت ذلك
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ======================= MODAL 3: FULL APP RESTORE CONFIRMATION MODAL ======================= */}
      {showFullAppRestoreModal && fullAppRestoreModalData && (
        <div 
          className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 animate-fade-in overflow-y-auto overscroll-contain"
          onClick={() => setShowFullAppRestoreModal(false)}
          onTouchMove={(e) => {
            if (e.target === e.currentTarget) e.preventDefault();
          }}
        >
          <div 
            className="bg-white border border-slate-200 rounded-3xl w-full max-w-lg overflow-hidden shadow-2xl text-slate-900 my-auto max-h-[92vh] sm:max-h-[88vh] flex flex-col modal-dialog-card overscroll-contain touch-pan-y"
            onClick={e => e.stopPropagation()}
          >
            <div className="p-4 sm:p-5 bg-gradient-to-r from-emerald-600 via-teal-700 to-emerald-700 text-white flex items-center justify-between shrink-0">
              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-white/20 text-white rounded-2xl backdrop-blur-xs">
                  <Upload size={22} />
                </div>
                <div>
                  <h3 className="font-black text-base sm:text-lg text-white">تأكيد استعادة بيانات التطبيق</h3>
                  <p className="text-xs text-emerald-100">تاريخ النسخة الاحتياطية: {fullAppRestoreModalData.fileDate}</p>
                </div>
              </div>
              <button 
                onClick={() => setShowFullAppRestoreModal(false)}
                className="p-2 text-white/80 hover:text-white rounded-xl hover:bg-white/10 transition-colors cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="p-5 space-y-4 overflow-y-auto flex-1 text-right overscroll-contain touch-pan-y custom-scrollbar modal-scroll-area">
              {/* Summary Stats */}
              <div className="grid grid-cols-2 gap-2.5 text-center text-xs">
                <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200">
                  <span className="text-slate-500 font-bold block text-[11px]">عدد المشاريع</span>
                  <span className="font-black text-slate-900 text-base">{fullAppRestoreModalData.projectsCount}</span>
                </div>
                <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200">
                  <span className="text-slate-500 font-bold block text-[11px]">إجمالي سندات الصرف</span>
                  <span className="font-black text-rose-600 text-base">{fullAppRestoreModalData.totalExpensesCount}</span>
                </div>
                <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200">
                  <span className="text-slate-500 font-bold block text-[11px]">العمال المسجلون</span>
                  <span className="font-black text-sky-700 text-base">{fullAppRestoreModalData.totalWorkersCount}</span>
                </div>
                <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200">
                  <span className="text-slate-500 font-bold block text-[11px]">الموظفون والموردون</span>
                  <span className="font-black text-indigo-700 text-base">
                    {fullAppRestoreModalData.totalEmployeesCount + fullAppRestoreModalData.totalSuppliersCount}
                  </span>
                </div>
                {((fullAppRestoreModalData.generalDebts?.length || 0) > 0 || (fullAppRestoreModalData.companyAssets?.length || 0) > 0) && (
                  <>
                    <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200">
                      <span className="text-slate-500 font-bold block text-[11px]">الديون العامة</span>
                      <span className="font-black text-amber-700 text-base">{fullAppRestoreModalData.generalDebts?.length || 0}</span>
                    </div>
                    <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200">
                      <span className="text-slate-500 font-bold block text-[11px]">أصول وممتلكات الشركة</span>
                      <span className="font-black text-teal-700 text-base">{fullAppRestoreModalData.companyAssets?.length || 0}</span>
                    </div>
                  </>
                )}
              </div>

              {/* Restore Mode Choice */}
              <div className="space-y-2 pt-2">
                <label className="block text-xs font-black text-slate-800">اختر طريقة الاستعادة:</label>
                
                <div 
                  onClick={() => setFullAppRestoreMode('overwrite')}
                  className={`p-3 rounded-2xl border-2 transition-all cursor-pointer ${
                    fullAppRestoreMode === 'overwrite'
                      ? 'border-emerald-600 bg-emerald-50/50'
                      : 'border-slate-200 hover:border-slate-300 bg-slate-50/50'
                  }`}
                >
                  <div className="flex items-center gap-2 font-black text-xs text-slate-900">
                    <input 
                      type="radio" 
                      name="restoreMode" 
                      checked={fullAppRestoreMode === 'overwrite'} 
                      onChange={() => setFullAppRestoreMode('overwrite')}
                      className="text-emerald-600 cursor-pointer"
                    />
                    <span>استبدال شامل (مسح البيانات الحالية واستعادة النسخة بالكامل)</span>
                  </div>
                  <p className="text-[11px] text-slate-500 font-medium mt-1 mr-5">
                    الخيار الموصى به لاستعادة نسخة طبق الأصل من البيانات السابقة.
                  </p>
                </div>

                <div 
                  onClick={() => setFullAppRestoreMode('merge')}
                  className={`p-3 rounded-2xl border-2 transition-all cursor-pointer ${
                    fullAppRestoreMode === 'merge'
                      ? 'border-emerald-600 bg-emerald-50/50'
                      : 'border-slate-200 hover:border-slate-300 bg-slate-50/50'
                  }`}
                >
                  <div className="flex items-center gap-2 font-black text-xs text-slate-900">
                    <input 
                      type="radio" 
                      name="restoreMode" 
                      checked={fullAppRestoreMode === 'merge'} 
                      onChange={() => setFullAppRestoreMode('merge')}
                      className="text-emerald-600 cursor-pointer"
                    />
                    <span>دمج مع المشاريع الحالية (إضافة المشاريع غير الموجودة)</span>
                  </div>
                  <p className="text-[11px] text-slate-500 font-medium mt-1 mr-5">
                    يحافظ على مشاريعك الحالية ويضيف المشاريع الجديدة من ملف النسخة.
                  </p>
                </div>
              </div>

              <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-amber-900 text-xs flex items-center gap-2">
                <AlertTriangle size={18} className="text-amber-600 shrink-0" />
                <span>سيتم تطبيق الاستعادة فوراً وإعادة تحميل الصفحة لتحديث الجداول.</span>
              </div>
            </div>

            <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-end gap-2.5 shrink-0">
              <button
                type="button"
                onClick={() => setShowFullAppRestoreModal(false)}
                className="bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold text-xs py-2.5 px-4 rounded-xl transition-all cursor-pointer"
              >
                إلغاء
              </button>
              <button
                type="button"
                onClick={handleConfirmFullAppRestore}
                className="bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs py-2.5 px-5 rounded-xl transition-all cursor-pointer shadow-md"
              >
                تأكيد الاستعادة الآن
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
