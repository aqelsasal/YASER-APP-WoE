/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo, useRef } from 'react';
import { 
  FileSpreadsheet, 
  PlusCircle, 
  Search, 
  FolderPlus, 
  ChevronDown, 
  ChevronUp, 
  TrendingUp, 
  Wallet, 
  AlertTriangle, 
  CheckCircle2, 
  Clock, 
  Edit, 
  Trash2, 
  Eye, 
  Download, 
  Upload,
  Printer, 
  Layers, 
  Sparkles, 
  X, 
  Percent, 
  Check, 
  Coins,
  ArrowRight,
  Filter,
  BarChart3,
  Calendar,
  User,
  Info
} from 'lucide-react';
import * as XLSX from 'xlsx';
import PageHeaderCard from './PageHeaderCard';
import { 
  ContractItem, 
  Expense, 
  Supplier, 
  Worker, 
  formatCurrency, 
  formatDateArabic,
  getFormattedReportDate,
  ensureDateInFilename
} from '../types';
import { useBodyScrollLock } from '../utils/modalScrollLock';

interface ContractBOQProps {
  contractItems: ContractItem[];
  onAddContractItem: (item: Omit<ContractItem, 'id' | 'createdAt' | 'updatedAt'>) => void;
  onUpdateContractItem: (id: string, item: Partial<ContractItem>) => void;
  onDeleteContractItem: (id: string) => void;
  onImportContractItems?: (items: ContractItem[]) => void;
  expenses: Expense[];
  suppliers?: Supplier[];
  workers?: Worker[];
  currency: string;
  projectName: string;
  companyName: string;
  companyAddress?: string;
  companyPhone?: string;
  sharedRole?: string;
  currentUser?: string;
  setActiveTab?: (tab: string) => void;
}

export default function ContractBOQ({
  contractItems = [],
  onAddContractItem,
  onUpdateContractItem,
  onDeleteContractItem,
  onImportContractItems,
  expenses = [],
  currency,
  projectName,
  companyName,
  companyAddress = '',
  companyPhone = '',
  sharedRole = 'admin',
  currentUser = 'المدير',
  setActiveTab
}: ContractBOQProps) {
  // Filters & State
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedParentFilter, setSelectedParentFilter] = useState('ALL');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [collapsedMainItems, setCollapsedMainItems] = useState<Record<string, boolean>>({});

  // Modals state
  const [isItemModalOpen, setIsItemModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<ContractItem | null>(null);
  const [modalMode, setModalMode] = useState<'main' | 'sub'>('sub');
  
  // Ledger Modal state
  const [viewingLedgerItem, setViewingLedgerItem] = useState<ContractItem | null>(null);

  // Excel file input ref
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Form State
  const [itemNumber, setItemNumber] = useState('');
  const [name, setName] = useState('');
  const [parentItemNumber, setParentItemNumber] = useState('');
  const [parentName, setParentName] = useState('');
  const [unit, setUnit] = useState('م²');
  const [quantity, setQuantity] = useState('');
  const [unitPrice, setUnitPrice] = useState('');
  const [estimatedBudget, setEstimatedBudget] = useState('');
  const [notes, setNotes] = useState('');
  const [status, setStatus] = useState<'not_started' | 'in_progress' | 'completed' | 'paused'>('in_progress');
  const [completionPercentage, setCompletionPercentage] = useState('0');
  const [category, setCategory] = useState('أعمال إنشائية ومعمارية');

  useBodyScrollLock(isItemModalOpen || Boolean(viewingLedgerItem));

  // Extract list of existing main items
  const mainItems = useMemo(() => {
    return contractItems.filter(item => item.isMainItem || !item.parentItemNumber || item.parentItemNumber === '');
  }, [contractItems]);

  // Map expenses to contract items
  const expensesByItemId = useMemo(() => {
    const map = new Map<string, Expense[]>();
    expenses.forEach(exp => {
      if (exp.contractItemId) {
        const list = map.get(exp.contractItemId) || [];
        list.push(exp);
        map.set(exp.contractItemId, list);
      } else if (exp.contractItemNumber) {
        // Fallback match by item number
        const matched = contractItems.find(c => c.itemNumber === exp.contractItemNumber);
        if (matched) {
          const list = map.get(matched.id) || [];
          list.push(exp);
          map.set(matched.id, list);
        }
      }
    });
    return map;
  }, [expenses, contractItems]);

  // Compute stats for an individual item
  const getItemStats = (item: ContractItem) => {
    const directExpenses = expensesByItemId.get(item.id) || [];
    let actualCost = directExpenses.reduce((sum, e) => sum + (e.amount || 0), 0);
    
    // If it's a main item, aggregate costs and amounts of its sub-items
    let totalContractAmount = (item.quantity && item.unitPrice) 
      ? item.quantity * item.unitPrice 
      : (item.totalAmount || item.estimatedBudget || 0);

    let budget = item.estimatedBudget || totalContractAmount;

    if (item.isMainItem) {
      const subItems = contractItems.filter(sub => sub.parentItemNumber === item.itemNumber && !sub.isMainItem);
      if (subItems.length > 0) {
        let subContractTotal = 0;
        let subActualCost = 0;
        let subBudget = 0;
        subItems.forEach(sub => {
          const subDirect = expensesByItemId.get(sub.id) || [];
          const subCost = subDirect.reduce((s, e) => s + (e.amount || 0), 0);
          const subAmount = (sub.quantity && sub.unitPrice) ? sub.quantity * sub.unitPrice : (sub.totalAmount || 0);
          subContractTotal += subAmount;
          subActualCost += subCost;
          subBudget += (sub.estimatedBudget || subAmount);
        });
        totalContractAmount = subContractTotal;
        actualCost += subActualCost;
        budget = subBudget;
      }
    }

    const variance = budget - actualCost;
    const consumptionRate = budget > 0 ? (actualCost / budget) * 100 : 0;
    const isOverBudget = actualCost > budget && budget > 0;

    return {
      directExpenses,
      actualCost,
      totalContractAmount,
      budget,
      variance,
      consumptionRate,
      isOverBudget,
      txCount: directExpenses.length
    };
  };

  // Compute Overall Executive KPIs
  const overallKPIs = useMemo(() => {
    let totalContractBudget = 0;
    let totalActualCost = 0;
    let totalItemsCount = 0;
    let subItemsCount = 0;

    contractItems.forEach(item => {
      totalItemsCount++;
      if (item.isMainItem) {
        // If main item has no sub-items, count its budget
        const hasSub = contractItems.some(s => s.parentItemNumber === item.itemNumber && !s.isMainItem);
        if (!hasSub) {
          const stats = getItemStats(item);
          totalContractBudget += stats.budget;
        }
      } else {
        subItemsCount++;
        const stats = getItemStats(item);
        totalContractBudget += stats.budget;
      }
    });

    // Total actual expenses linked to any contract item
    const linkedExpenseIds = new Set<string>();
    expenses.forEach(e => {
      if (e.contractItemId || (e.contractItemNumber && contractItems.some(c => c.itemNumber === e.contractItemNumber))) {
        linkedExpenseIds.add(e.id);
      }
    });

    totalActualCost = expenses
      .filter(e => linkedExpenseIds.has(e.id))
      .reduce((sum, e) => sum + (e.amount || 0), 0);

    const remainingBudget = totalContractBudget - totalActualCost;
    const overallConsumption = totalContractBudget > 0 ? (totalActualCost / totalContractBudget) * 100 : 0;

    return {
      totalContractBudget,
      totalActualCost,
      remainingBudget,
      overallConsumption,
      totalItemsCount,
      subItemsCount,
      linkedExpensesCount: linkedExpenseIds.size
    };
  }, [contractItems, expenses]);

  // Group items by Main Item hierarchy
  const groupedHierarchy = useMemo(() => {
    // 1. Identify all main items
    const mainList = contractItems.filter(item => item.isMainItem || !item.parentItemNumber);
    
    // Sort main items by itemNumber
    mainList.sort((a, b) => a.itemNumber.localeCompare(b.itemNumber, undefined, { numeric: true }));

    const groups = mainList.map(main => {
      const subList = contractItems.filter(item => !item.isMainItem && item.parentItemNumber === main.itemNumber);
      subList.sort((a, b) => a.itemNumber.localeCompare(b.itemNumber, undefined, { numeric: true }));

      const mainStats = getItemStats(main);

      return {
        main,
        mainStats,
        subItems: subList
      };
    });

    // Also catch orphan sub-items without a matching main item
    const existingMainNums = new Set(mainList.map(m => m.itemNumber));
    const orphanSubItems = contractItems.filter(item => !item.isMainItem && item.parentItemNumber && !existingMainNums.has(item.parentItemNumber));
    if (orphanSubItems.length > 0) {
      orphanSubItems.sort((a, b) => a.itemNumber.localeCompare(b.itemNumber, undefined, { numeric: true }));
      const orphanMain: ContractItem = {
        id: 'orphan_group',
        itemNumber: 'فقرات إضافية',
        name: 'فقرات تعاقدية مستقلة / بدون تصنيف رئيسي',
        isMainItem: true
      };
      groups.push({
        main: orphanMain,
        mainStats: getItemStats(orphanMain),
        subItems: orphanSubItems
      });
    }

    return groups;
  }, [contractItems, expenses]);

  // Filtered Hierarchy based on search and filters
  const filteredGroups = useMemo(() => {
    return groupedHierarchy.map(group => {
      // Filter sub-items
      const filteredSubs = group.subItems.filter(sub => {
        const matchesSearch = 
          sub.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          sub.itemNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
          (sub.notes && sub.notes.toLowerCase().includes(searchQuery.toLowerCase()));

        const matchesStatus = statusFilter === 'ALL' || sub.status === statusFilter;

        return matchesSearch && matchesStatus;
      });

      const mainMatchesSearch = 
        group.main.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        group.main.itemNumber.toLowerCase().includes(searchQuery.toLowerCase());

      const matchesParent = selectedParentFilter === 'ALL' || group.main.itemNumber === selectedParentFilter;

      if (!matchesParent) {
        return null;
      }

      // If search query is present, show if main matches or if has filtered subs
      if (searchQuery.trim() !== '') {
        if (mainMatchesSearch || filteredSubs.length > 0) {
          return {
            ...group,
            subItems: filteredSubs
          };
        }
        return null;
      }

      return {
        ...group,
        subItems: filteredSubs
      };
    }).filter(Boolean) as typeof groupedHierarchy;
  }, [groupedHierarchy, searchQuery, selectedParentFilter, statusFilter]);

  // Toggle Collapse
  const toggleCollapse = (mainId: string) => {
    setCollapsedMainItems(prev => ({
      ...prev,
      [mainId]: !prev[mainId]
    }));
  };

  // Open Modal to Add Item
  const handleOpenAddModal = (mode: 'main' | 'sub', defaultParentNumber?: string) => {
    setEditingItem(null);
    setModalMode(mode);

    if (mode === 'main') {
      // Auto suggest next main number (e.g. 1, 2, 3...)
      const existingNums = mainItems
        .map(m => parseInt(m.itemNumber, 10))
        .filter(n => !isNaN(n));
      const nextNum = existingNums.length > 0 ? Math.max(...existingNums) + 1 : 1;
      setItemNumber(String(nextNum));
      setName('');
      setParentItemNumber('');
      setParentName('');
      setUnit('');
      setQuantity('');
      setUnitPrice('');
      setEstimatedBudget('');
    } else {
      const parentNum = defaultParentNumber || (mainItems[0]?.itemNumber || '1');
      const parentObj = mainItems.find(m => m.itemNumber === parentNum);
      setParentItemNumber(parentNum);
      setParentName(parentObj ? parentObj.name : '');

      // Auto suggest sub item number (e.g. 1.1, 1.2...)
      const subItemsOfParent = contractItems.filter(s => s.parentItemNumber === parentNum && !s.isMainItem);
      let nextSub = 1;
      subItemsOfParent.forEach(s => {
        const parts = s.itemNumber.split('.');
        if (parts.length > 1) {
          const val = parseInt(parts[1], 10);
          if (!isNaN(val) && val >= nextSub) {
            nextSub = val + 1;
          }
        }
      });
      setItemNumber(`${parentNum}.${nextSub}`);
      setName('');
      setUnit('م²');
      setQuantity('');
      setUnitPrice('');
      setEstimatedBudget('');
    }

    setNotes('');
    setStatus('in_progress');
    setCompletionPercentage('0');
    setCategory('أعمال إنشائية ومعمارية');
    setIsItemModalOpen(true);
  };

  // Open Modal to Edit Item
  const handleOpenEditModal = (item: ContractItem) => {
    setEditingItem(item);
    setModalMode(item.isMainItem ? 'main' : 'sub');
    setItemNumber(item.itemNumber);
    setName(item.name);
    setParentItemNumber(item.parentItemNumber || '');
    setParentName(item.parentName || '');
    setUnit(item.unit || 'م²');
    setQuantity(item.quantity !== undefined ? String(item.quantity) : '');
    setUnitPrice(item.unitPrice !== undefined ? String(item.unitPrice) : '');
    setEstimatedBudget(item.estimatedBudget !== undefined ? String(item.estimatedBudget) : '');
    setNotes(item.notes || '');
    setStatus(item.status || 'in_progress');
    setCompletionPercentage(item.completionPercentage !== undefined ? String(item.completionPercentage) : '0');
    setCategory(item.category || 'أعمال إنشائية ومعمارية');
    setIsItemModalOpen(true);
  };

  // Submit Add / Edit
  const handleSubmitItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !itemNumber.trim()) {
      alert('يرجى كتابة رقم واسم البند التعاقدي');
      return;
    }

    const parsedQty = quantity ? parseFloat(quantity) : undefined;
    const parsedPrice = unitPrice ? parseFloat(unitPrice) : undefined;
    const calcTotal = (parsedQty !== undefined && parsedPrice !== undefined) ? parsedQty * parsedPrice : undefined;
    const parsedBudget = estimatedBudget ? parseFloat(estimatedBudget) : calcTotal;

    const payload: Omit<ContractItem, 'id' | 'createdAt' | 'updatedAt'> = {
      itemNumber: itemNumber.trim(),
      name: name.trim(),
      isMainItem: modalMode === 'main',
      parentItemNumber: modalMode === 'sub' ? parentItemNumber.trim() : undefined,
      parentName: modalMode === 'sub' ? (mainItems.find(m => m.itemNumber === parentItemNumber.trim())?.name || parentName) : undefined,
      unit: modalMode === 'sub' ? unit.trim() : undefined,
      quantity: parsedQty,
      unitPrice: parsedPrice,
      totalAmount: calcTotal,
      estimatedBudget: parsedBudget,
      notes: notes.trim(),
      status,
      completionPercentage: parseFloat(completionPercentage) || 0,
      category,
      updatedBy: currentUser
    };

    if (editingItem) {
      onUpdateContractItem(editingItem.id, payload);
    } else {
      onAddContractItem({
        ...payload,
        createdBy: currentUser
      });
    }

    setIsItemModalOpen(false);
  };

  // Import Standard Template
  const handleImportStandardTemplate = () => {
    const confirmMsg = 'هل ترغب في استيراد نموذج قياسي متكامل لبنود العقد وجداول الكميات؟ (يشمل بنود التلييس، البناء والخرسانات، السباكة، والكهرباء)';
    if (!window.confirm(confirmMsg)) return;

    const standardItems: Omit<ContractItem, 'id' | 'createdAt' | 'updatedAt'>[] = [
      // Main Item 1
      {
        itemNumber: '1',
        name: 'أعمال التلييس والدهانات',
        isMainItem: true,
        category: 'تشطيبات ومعماري',
        status: 'in_progress',
        notes: 'تشمل جميع أعمال التلييس الداخلي والخارجي والدهانات'
      },
      {
        itemNumber: '1.1',
        name: 'تلييس داخلي للجدران والأسقف بمونة الأسمنت والرمل',
        isMainItem: false,
        parentItemNumber: '1',
        parentName: 'أعمال التلييس والدهانات',
        unit: 'م²',
        quantity: 1500,
        unitPrice: 1200,
        totalAmount: 1800000,
        estimatedBudget: 1500000,
        category: 'تشطيبات ومعماري',
        status: 'in_progress',
        completionPercentage: 40,
        notes: 'معالجة الشروخ واستخدام شبك الفايبر'
      },
      {
        itemNumber: '1.2',
        name: 'تلييس خارجي للواجهات وستائر السطح',
        isMainItem: false,
        parentItemNumber: '1',
        parentName: 'أعمال التلييس والدهانات',
        unit: 'م²',
        quantity: 800,
        unitPrice: 1800,
        totalAmount: 1440000,
        estimatedBudget: 1200000,
        category: 'تشطيبات ومعماري',
        status: 'not_started',
        completionPercentage: 0,
        notes: 'باستخدام السقالات المعدنية والمواد المقاومة للرطوبة'
      },
      {
        itemNumber: '1.3',
        name: 'دهانات داخلية أساس وسيلر ومعجون وبويه',
        isMainItem: false,
        parentItemNumber: '1',
        parentName: 'أعمال التلييس والدهانات',
        unit: 'م²',
        quantity: 1500,
        unitPrice: 900,
        totalAmount: 1350000,
        estimatedBudget: 1100000,
        category: 'تشطيبات ومعماري',
        status: 'not_started',
        completionPercentage: 0
      },

      // Main Item 2
      {
        itemNumber: '2',
        name: 'أعمال البناء والخرسانات',
        isMainItem: true,
        category: 'أعمال إنشائية',
        status: 'in_progress',
        notes: 'تشمل أعمال الخرسانة المسلحة والمباني'
      },
      {
        itemNumber: '2.1',
        name: 'مباني بلك أسمنتي مقاس 20×20×40 سم',
        isMainItem: false,
        parentItemNumber: '2',
        parentName: 'أعمال البناء والخرسانات',
        unit: 'م²',
        quantity: 1200,
        unitPrice: 1500,
        totalAmount: 1800000,
        estimatedBudget: 1600000,
        category: 'أعمال إنشائية',
        status: 'completed',
        completionPercentage: 100,
        notes: 'تشمل السقايات والربط بالأعمدة'
      },
      {
        itemNumber: '2.2',
        name: 'خرسانة مسلحة للأعمدة والقواعد وميدات الربط',
        isMainItem: false,
        parentItemNumber: '2',
        parentName: 'أعمال البناء والخرسانات',
        unit: 'م³',
        quantity: 120,
        unitPrice: 85000,
        totalAmount: 10200000,
        estimatedBudget: 9200000,
        category: 'أعمال إنشائية',
        status: 'completed',
        completionPercentage: 100,
        notes: 'إجهاد كسر لا يقل عن 300 كجم/سم²'
      },
      {
        itemNumber: '2.3',
        name: 'خرسانة مسلحة للأسقف والكمرات والجسور الساقطة',
        isMainItem: false,
        parentItemNumber: '2',
        parentName: 'أعمال البناء والخرسانات',
        unit: 'م³',
        quantity: 90,
        unitPrice: 90000,
        totalAmount: 8100000,
        estimatedBudget: 7500000,
        category: 'أعمال إنشائية',
        status: 'in_progress',
        completionPercentage: 65
      },

      // Main Item 3
      {
        itemNumber: '3',
        name: 'أعمال التمديدات والسباكة والصحي',
        isMainItem: true,
        category: 'كهروميكانيك',
        status: 'in_progress',
        notes: 'تشمل شبكات التغذية والصرف وخطوط التهوية'
      },
      {
        itemNumber: '3.1',
        name: 'تأسيس وتمديد شبكة الصرف الصحي ومياه التغذية',
        isMainItem: false,
        parentItemNumber: '3',
        parentName: 'أعمال التمديدات والسباكة والصحي',
        unit: 'مقطوعية',
        quantity: 1,
        unitPrice: 750000,
        totalAmount: 750000,
        estimatedBudget: 650000,
        category: 'كهروميكانيك',
        status: 'in_progress',
        completionPercentage: 50
      },
      {
        itemNumber: '3.2',
        name: 'توريد وتركيب أطقم الحمامات والمغاسل والإكسسوارات',
        isMainItem: false,
        parentItemNumber: '3',
        parentName: 'أعمال التمديدات والسباكة والصحي',
        unit: 'طقم',
        quantity: 8,
        unitPrice: 85000,
        totalAmount: 680000,
        estimatedBudget: 600000,
        category: 'كهروميكانيك',
        status: 'not_started',
        completionPercentage: 0
      }
    ];

    standardItems.forEach(item => {
      onAddContractItem({
        ...item,
        createdBy: currentUser
      });
    });
  };

  // Helper to extract clean numeric value from cell
  const cleanNumber = (val: any): number => {
    if (val === undefined || val === null || val === '') return 0;
    if (typeof val === 'number') return isNaN(val) ? 0 : val;
    const cleaned = String(val).replace(/[^0-9.-]/g, '');
    const parsed = parseFloat(cleaned);
    return isNaN(parsed) ? 0 : parsed;
  };

  // Import from Excel file
  const handleExcelImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Reset input value to allow re-importing the same file if needed
    e.target.value = '';

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const data = event.target?.result;
        const workbook = XLSX.read(data, { type: 'binary' });
        const sheetName = workbook.SheetNames[0];
        if (!sheetName) {
          alert('الملف لا يحتوي على أي أوراق عمل صالحة.');
          return;
        }

        const sheet = workbook.Sheets[sheetName];
        const rows = XLSX.utils.sheet_to_json<any>(sheet);

        if (!rows || rows.length === 0) {
          alert('ملف Excel فارغ أو لا يحتوي على صفوف بيانات.');
          return;
        }

        const parsedItems: Omit<ContractItem, 'id' | 'createdAt' | 'updatedAt'>[] = [];
        let autoCounter = 1;

        rows.forEach((row: any) => {
          // 1. Identify Item Number
          let rawItemNumber = String(
            row['رقم البند / الفقرة'] ?? 
            row['رقم البند'] ?? 
            row['رقم الفقرة'] ?? 
            row['الرقم'] ?? 
            row['رقم'] ?? 
            row['م'] ?? 
            row['تسلسل'] ?? 
            row['Item Number'] ?? 
            row['Item No'] ?? 
            row['Item #'] ?? 
            row['No'] ?? 
            row['No.'] ?? 
            row['Item'] ?? 
            ''
          ).trim();

          // 2. Identify Name / Description
          const rawName = String(
            row['اسم وتوصيف البند'] ?? 
            row['اسم البند'] ?? 
            row['بيان الأعمال'] ?? 
            row['البيان'] ?? 
            row['توصيف البند'] ?? 
            row['الوصف'] ?? 
            row['البند'] ?? 
            row['Description'] ?? 
            row['Item Description'] ?? 
            row['Name'] ?? 
            row['name'] ?? 
            ''
          ).trim();

          // Skip completely empty rows
          if (!rawItemNumber && !rawName) return;

          if (!rawItemNumber) {
            rawItemNumber = String(autoCounter++);
          }

          // 3. Identify Item Type (Main or Sub)
          const rawType = String(row['نوع البند'] ?? row['النوع'] ?? row['Type'] ?? '').trim().toLowerCase();
          const isMainExplicit = rawType.includes('رئيسي') || rawType.includes('main') || rawType === 'قسم';
          const isSubExplicit = rawType.includes('فرعي') || rawType.includes('تعاقدي') || rawType.includes('فقرة') || rawType.includes('sub');

          const hasUnitOrQtyOrPrice = Boolean(
            row['الوحدة'] || row['وحدة القياس'] || row['Unit'] || 
            row['الكمية التعاقدية'] || row['الكمية'] || row['Qty'] || 
            row['سعر الوحدة'] || row['السعر'] || row['الفئة'] || row['Unit Price']
          );

          let isMainItem = false;
          if (isMainExplicit) {
            isMainItem = true;
          } else if (isSubExplicit) {
            isMainItem = false;
          } else {
            // Smart heuristic:
            // Sub-items typically contain dot (e.g. 1.1, 1.2) or have unit/quantity/price
            if (rawItemNumber.includes('.') || rawItemNumber.includes('/') || rawItemNumber.includes('-')) {
              isMainItem = false;
            } else if (!hasUnitOrQtyOrPrice) {
              isMainItem = true;
            } else {
              isMainItem = false;
            }
          }

          // 4. Identify Parent Item
          let parentItemNumber = String(
            row['البند الرئيسي التابع له'] ?? 
            row['البند الرئيسي'] ?? 
            row['رقم البند الرئيسي'] ?? 
            row['القسم'] ?? 
            row['Parent Item Number'] ?? 
            row['Parent'] ?? 
            ''
          ).trim();

          if (!isMainItem && !parentItemNumber && rawItemNumber.includes('.')) {
            parentItemNumber = rawItemNumber.split('.')[0].trim();
          }

          let parentName = String(
            row['اسم البند الرئيسي'] ?? 
            row['عنوان القسم'] ?? 
            ''
          ).trim();

          // 5. Unit
          const unit = isMainItem ? undefined : String(
            row['الوحدة'] ?? 
            row['وحدة القياس'] ?? 
            row['وحدة'] ?? 
            row['Unit'] ?? 
            row['unit'] ?? 
            'م²'
          ).trim();

          // 6. Quantity & Unit Price
          const quantity = isMainItem ? undefined : cleanNumber(
            row['الكمية التعاقدية'] ?? 
            row['الكمية'] ?? 
            row['الكميه'] ?? 
            row['كمية'] ?? 
            row['Qty'] ?? 
            row['Quantity'] ?? 
            row['quantity']
          );

          const unitPrice = isMainItem ? undefined : cleanNumber(
            row['سعر الوحدة'] ?? 
            row['السعر'] ?? 
            row['الفئة'] ?? 
            row['سعر'] ?? 
            row['فئة'] ?? 
            row['Unit Price'] ?? 
            row['UnitPrice'] ?? 
            row['Price'] ?? 
            row['Rate']
          );

          // 7. Total Amount
          const rawTotal = cleanNumber(
            row['القيمة التعاقدية الإجمالية'] ?? 
            row['القيمة الإجمالية'] ?? 
            row['الإجمالي'] ?? 
            row['الاجمالي'] ?? 
            row['Total'] ?? 
            row['Total Amount']
          );
          const totalAmount = isMainItem ? undefined : (rawTotal > 0 ? rawTotal : (quantity && unitPrice ? quantity * unitPrice : 0));

          // 8. Estimated Budget
          const rawBudget = cleanNumber(
            row['الميزانية التقديرية'] ?? 
            row['ميزانية التكلفة'] ?? 
            row['التكلفة التقديرية'] ?? 
            row['الميزانية'] ?? 
            row['Estimated Budget'] ?? 
            row['Budget']
          );
          const estimatedBudget = isMainItem ? undefined : (rawBudget > 0 ? rawBudget : totalAmount || 0);

          // 9. Category
          const category = String(
            row['التصنيف الهندسي'] ?? 
            row['التصنيف'] ?? 
            row['الفئة'] ?? 
            row['Category'] ?? 
            (isMainItem ? 'أعمال إنشائية' : 'تشطيبات ومعماري')
          ).trim();

          // 10. Completion Percentage
          const rawCompletion = row['نسبة الإنجاز الموقعي %'] ?? 
            row['نسبة الإنجاز الموقعي'] ?? 
            row['نسبة الإنجاز'] ?? 
            row['نسبة الانجاز'] ?? 
            row['الإنجاز'] ?? 
            row['Completion'] ?? 
            row['Progress'];
          let completionPercentage = 0;
          if (rawCompletion !== undefined && rawCompletion !== null) {
            completionPercentage = Math.min(100, Math.max(0, cleanNumber(rawCompletion)));
          }

          // 11. Status
          const rawStatus = String(row['حالة التنفيذ'] ?? row['الحالة'] ?? row['Status'] ?? '').trim().toLowerCase();
          let status: 'not_started' | 'in_progress' | 'completed' | 'paused' = 'in_progress';
          if (rawStatus.includes('مكتمل') || rawStatus.includes('منتهي') || rawStatus.includes('complete')) {
            status = 'completed';
          } else if (rawStatus.includes('لم يبدأ') || rawStatus.includes('جديد') || rawStatus.includes('not_started')) {
            status = 'not_started';
          } else if (rawStatus.includes('متوقف') || rawStatus.includes('معلق') || rawStatus.includes('pause')) {
            status = 'paused';
          } else if (completionPercentage === 100) {
            status = 'completed';
          } else if (completionPercentage === 0) {
            status = 'not_started';
          }

          // 12. Notes
          const notes = String(
            row['ملاحظات'] ?? 
            row['الملاحظات'] ?? 
            row['المواصفات'] ?? 
            row['Notes'] ?? 
            row['Remarks'] ?? 
            ''
          ).trim();

          parsedItems.push({
            itemNumber: rawItemNumber,
            name: rawName,
            isMainItem,
            parentItemNumber: isMainItem ? undefined : (parentItemNumber || undefined),
            parentName: isMainItem ? undefined : (parentName || undefined),
            category,
            unit,
            quantity,
            unitPrice,
            totalAmount,
            estimatedBudget,
            notes,
            status,
            completionPercentage,
            createdBy: currentUser
          });
        });

        if (parsedItems.length === 0) {
          alert('لم يتم العثور على أي بنود صالحة في ملف Excel. يرجى التأكد من احتواء الملف على أعمدة: (رقم البند، اسم وتوصيف البند، الوحدة، الكمية، السعر).');
          return;
        }

        // Second pass: resolve parentName from parsed items or existing contract items
        parsedItems.forEach(item => {
          if (!item.isMainItem && item.parentItemNumber && !item.parentName) {
            const foundInParsed = parsedItems.find(p => p.isMainItem && p.itemNumber === item.parentItemNumber);
            if (foundInParsed) {
              item.parentName = foundInParsed.name;
            } else {
              const foundInExisting = contractItems.find(e => e.isMainItem && e.itemNumber === item.parentItemNumber);
              if (foundInExisting) {
                item.parentName = foundInExisting.name;
              } else {
                item.parentName = `بند رئيسي ${item.parentItemNumber}`;
              }
            }
          }
        });

        // Determine if we append or replace
        let shouldAppend = false;
        if (contractItems.length > 0) {
          shouldAppend = window.confirm(
            `تمت قراءة ${parsedItems.length} بند بنجاح من ملف Excel!\n\n` +
            `يوجد حالياً ${contractItems.length} بند مسجل في هذا المشروع.\n\n` +
            `• اضغط "موافق" (OK) لإضافة البنود الجديدة إلى البنود الحالية.\n` +
            `• اضغط "إلغاء الأمر" (Cancel) لاستبدال البنود الحالية بالكامل بالبنود المستوردة من الملف.`
          );
        }

        const now = new Date().toISOString();
        const newItemsWithId: ContractItem[] = parsedItems.map((item, idx) => ({
          ...item,
          id: 'boq_import_' + Date.now().toString() + '_' + idx + '_' + Math.random().toString(36).substring(2, 6),
          createdAt: now,
          updatedAt: now,
          createdBy: currentUser
        }));

        if (onImportContractItems) {
          const finalItems = shouldAppend ? [...contractItems, ...newItemsWithId] : newItemsWithId;
          onImportContractItems(finalItems);
        } else {
          // Fallback to onAddContractItem
          parsedItems.forEach(item => {
            onAddContractItem({
              ...item,
              createdBy: currentUser
            });
          });
        }

        alert(`تم استيراد ${parsedItems.length} بند بنجاح إلى جداول الكميات وبنود العقد!`);
      } catch (err) {
        console.error('Error importing Excel BOQ:', err);
        alert('حدث خطأ أثناء قراءة ملف Excel. يرجى التأكد من صيغة الملف وأسماء الأعمدة.');
      }
    };

    reader.readAsBinaryString(file);
  };

  // Export to Excel
  const handleExportExcel = () => {
    const reportDate = getFormattedReportDate();
    const dataRows: any[] = [];

    contractItems.forEach(item => {
      const stats = getItemStats(item);
      dataRows.push({
        'نوع البند': item.isMainItem ? 'بند رئيسي' : 'فقرة تعاقدية',
        'رقم البند / الفقرة': item.itemNumber,
        'اسم وتوصيف البند': item.name,
        'البند الرئيسي التابع له': item.parentName || item.parentItemNumber || '—',
        'الوحدة': item.unit || '—',
        'الكمية التعاقدية': item.quantity || 0,
        'سعر الوحدة': item.unitPrice || 0,
        'القيمة التعاقدية الإجمالية': stats.totalContractAmount,
        'الميزانية التقديرية': stats.budget,
        'التكلفة الفعلية المنفذة': stats.actualCost,
        'المتبقي / الانحراف': stats.variance,
        'نسبة استهلاك الميزانية %': stats.consumptionRate.toFixed(1) + '%',
        'نسبة الإنجاز الموقعي %': (item.completionPercentage || 0) + '%',
        'حالة التنفيذ': item.status === 'completed' ? 'مكتمل' : item.status === 'in_progress' ? 'قيد التنفيذ' : 'لم يبدأ',
        'ملاحظات': item.notes || ''
      });
    });

    const worksheet = XLSX.utils.json_to_sheet(dataRows);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'جدول الكميات والتكاليف');
    const safeName = ensureDateInFilename(`تقرير_جداول_الكميات_والتكاليف_${projectName}`);
    XLSX.writeFile(workbook, `${safeName}.xlsx`);
  };

  // Print Executive BOQ Report (PDF)
  const handlePrintBOQReport = () => {
    const reportDate = getFormattedReportDate();
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    let rowsHtml = '';
    groupedHierarchy.forEach(group => {
      // Main Item Header Row
      rowsHtml += `
        <tr style="background-color: #0f172a; color: #ffffff; font-weight: bold;">
          <td style="padding: 10px; border: 1px solid #334155; text-align: center; font-size: 14px;">${group.main.itemNumber}</td>
          <td colspan="3" style="padding: 10px; border: 1px solid #334155; font-size: 14px; text-align: right;">[بند رئيسي] ${group.main.name}</td>
          <td style="padding: 10px; border: 1px solid #334155; text-align: center; font-size: 13px;">${formatCurrency(group.mainStats.budget, currency)}</td>
          <td style="padding: 10px; border: 1px solid #334155; text-align: center; font-size: 13px; color: #38bdf8;">${formatCurrency(group.mainStats.actualCost, currency)}</td>
          <td style="padding: 10px; border: 1px solid #334155; text-align: center; font-size: 13px; color: ${group.mainStats.variance >= 0 ? '#4ade80' : '#f87171'};">
            ${formatCurrency(group.mainStats.variance, currency)}
          </td>
          <td style="padding: 10px; border: 1px solid #334155; text-align: center; font-size: 13px;">
            ${group.mainStats.consumptionRate.toFixed(1)}%
          </td>
          <td style="padding: 10px; border: 1px solid #334155; text-align: center; font-size: 12px;">مجمّع</td>
        </tr>
      `;

      // Sub-items
      group.subItems.forEach((sub, idx) => {
        const stats = getItemStats(sub);
        const bg = idx % 2 === 0 ? '#ffffff' : '#f8fafc';
        rowsHtml += `
          <tr style="background-color: ${bg};">
            <td style="padding: 8px; border: 1px solid #e2e8f0; text-align: center; font-weight: bold; color: #0284c7;">${sub.itemNumber}</td>
            <td style="padding: 8px; border: 1px solid #e2e8f0; text-align: right;">
              <div style="font-weight: 600; color: #1e293b;">${sub.name}</div>
              ${sub.notes ? `<div style="font-size: 11px; color: #64748b;">${sub.notes}</div>` : ''}
            </td>
            <td style="padding: 8px; border: 1px solid #e2e8f0; text-align: center;">${sub.unit || '—'}</td>
            <td style="padding: 8px; border: 1px solid #e2e8f0; text-align: center;">${sub.quantity ? sub.quantity.toLocaleString('en-US') : '—'}</td>
            <td style="padding: 8px; border: 1px solid #e2e8f0; text-align: center; font-weight: bold;">${formatCurrency(stats.budget, currency)}</td>
            <td style="padding: 8px; border: 1px solid #e2e8f0; text-align: center; font-weight: bold; color: #0284c7;">${formatCurrency(stats.actualCost, currency)}</td>
            <td style="padding: 8px; border: 1px solid #e2e8f0; text-align: center; font-weight: bold; color: ${stats.variance >= 0 ? '#16a34a' : '#dc2626'};">
              ${formatCurrency(stats.variance, currency)}
            </td>
            <td style="padding: 8px; border: 1px solid #e2e8f0; text-align: center;">${stats.consumptionRate.toFixed(1)}%</td>
            <td style="padding: 8px; border: 1px solid #e2e8f0; text-align: center;">${sub.completionPercentage || 0}%</td>
          </tr>
        `;
      });
    });

    const html = `
      <!DOCTYPE html>
      <html dir="rtl" lang="ar">
      <head>
        <meta charset="utf-8">
        <title>كشف جداول الكميات والتكاليف التنفيذية - ${projectName}</title>
        <style>
          @page { size: A4 landscape; margin: 12mm; }
          body { font-family: system-ui, -apple-system, sans-serif; margin: 0; padding: 20px; color: #0f172a; direction: rtl; }
          .header { border-bottom: 2px solid #0f172a; padding-bottom: 12px; margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center; }
          .header h1 { margin: 0; font-size: 20px; color: #0f172a; }
          .meta { font-size: 12px; color: #475569; }
          .kpi-box { display: flex; gap: 15px; margin-bottom: 20px; }
          .kpi-card { flex: 1; padding: 12px; border-radius: 8px; background: #f1f5f9; border: 1px solid #cbd5e1; text-align: center; }
          .kpi-val { font-size: 16px; font-weight: bold; margin-top: 4px; color: #0f172a; }
          table { width: 100%; border-collapse: collapse; font-size: 12px; }
          th { background: #1e293b; color: white; padding: 10px; border: 1px solid #334155; }
        </style>
      </head>
      <body>
        <div class="header">
          <div>
            <h1>${companyName || 'شركة المقاولات'}</h1>
            <div class="meta">المشروع: <strong>${projectName}</strong> ${companyAddress ? `| ${companyAddress}` : ''}</div>
          </div>
          <div style="text-align: left;">
            <div style="font-size: 16px; font-weight: bold; color: #0369a1;">تقرير جداول الكميات وتكاليف البنود</div>
            <div class="meta">تاريخ التقرير: ${reportDate}</div>
          </div>
        </div>

        <div class="kpi-box">
          <div class="kpi-card">
            <div style="font-size: 11px; color: #64748b;">إجمالي الميزانية التعاقدية</div>
            <div class="kpi-val">${formatCurrency(overallKPIs.totalContractBudget, currency)}</div>
          </div>
          <div class="kpi-card">
            <div style="font-size: 11px; color: #64748b;">التكلفة الفعلية المنفذة</div>
            <div class="kpi-val" style="color: #0284c7;">${formatCurrency(overallKPIs.totalActualCost, currency)}</div>
          </div>
          <div class="kpi-card">
            <div style="font-size: 11px; color: #64748b;">الرصيد المتبقي / الوفر</div>
            <div class="kpi-val" style="color: ${overallKPIs.remainingBudget >= 0 ? '#16a34a' : '#dc2626'};">
              ${formatCurrency(overallKPIs.remainingBudget, currency)}
            </div>
          </div>
          <div class="kpi-card">
            <div style="font-size: 11px; color: #64748b;">نسبة استهلاك الميزانية</div>
            <div class="kpi-val">${overallKPIs.overallConsumption.toFixed(1)}%</div>
          </div>
        </div>

        <table>
          <thead>
            <tr>
              <th style="width: 70px;">رقم البند</th>
              <th>بيان وتوصيف البند التعاقدي</th>
              <th style="width: 55px;">الوحدة</th>
              <th style="width: 65px;">الكمية</th>
              <th style="width: 120px;">الميزانية التقديرية</th>
              <th style="width: 120px;">التكلفة الفعلية</th>
              <th style="width: 120px;">المتبقي / الانحراف</th>
              <th style="width: 80px;">الاستهلاك %</th>
              <th style="width: 75px;">الإنجاز %</th>
            </tr>
          </thead>
          <tbody>
            ${rowsHtml}
          </tbody>
        </table>

        <div style="margin-top: 30px; display: flex; justify-content: space-between; font-size: 12px; color: #475569; border-top: 1px solid #cbd5e1; padding-top: 10px;">
          <div>المهندس المشرف: .......................................</div>
          <div>مدير المشروع: .......................................</div>
          <div>اعتماد الإدارة: .......................................</div>
        </div>

        <script>
          window.onload = function() {
            setTimeout(function() { window.print(); }, 400);
          };
        </script>
      </body>
      </html>
    `;

    printWindow.document.open();
    printWindow.document.write(html);
    printWindow.document.close();
  };

  // Print Specific Item Ledger
  const handlePrintItemLedger = (item: ContractItem) => {
    const stats = getItemStats(item);
    const reportDate = getFormattedReportDate();
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    let txRows = '';
    stats.directExpenses.forEach((exp, idx) => {
      txRows += `
        <tr style="background: ${idx % 2 === 0 ? '#fff' : '#f8fafc'};">
          <td style="padding: 8px; border: 1px solid #e2e8f0; text-align: center;">${formatDateArabic(exp.date)}</td>
          <td style="padding: 8px; border: 1px solid #e2e8f0; text-align: center; font-weight: bold; color: #0284c7;">${formatCurrency(exp.amount, currency)}</td>
          <td style="padding: 8px; border: 1px solid #e2e8f0; text-align: right;">${exp.description}</td>
          <td style="padding: 8px; border: 1px solid #e2e8f0; text-align: center;">${exp.recipientName || '—'}</td>
          <td style="padding: 8px; border: 1px solid #e2e8f0; text-align: center;">${exp.expenseType === 'direct' ? 'مباشرة' : 'غير مباشرة'}</td>
          <td style="padding: 8px; border: 1px solid #e2e8f0; text-align: right; color: #64748b;">${exp.notes || '—'}</td>
        </tr>
      `;
    });

    const html = `
      <!DOCTYPE html>
      <html dir="rtl" lang="ar">
      <head>
        <meta charset="utf-8">
        <title>كشف تكاليف البند [${item.itemNumber}] ${item.name}</title>
        <style>
          @page { size: A4 portrait; margin: 12mm; }
          body { font-family: system-ui, -apple-system, sans-serif; margin: 0; padding: 20px; color: #0f172a; direction: rtl; }
          .header { border-bottom: 2px solid #0f172a; padding-bottom: 12px; margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center; }
          table { width: 100%; border-collapse: collapse; font-size: 12px; }
          th { background: #1e293b; color: white; padding: 10px; border: 1px solid #334155; }
        </style>
      </head>
      <body>
        <div class="header">
          <div>
            <h2 style="margin:0;">${companyName}</h2>
            <div style="font-size: 13px; color: #475569;">المشروع: <strong>${projectName}</strong></div>
          </div>
          <div style="text-align: left;">
            <div style="font-size: 16px; font-weight: bold; color: #0369a1;">كشف حساب تفصيلي لتكاليف البند</div>
            <div style="font-size: 12px; color: #64748b;">تاريخ التقرير: ${reportDate}</div>
          </div>
        </div>

        <div style="background: #f8fafc; border: 1px solid #cbd5e1; border-radius: 8px; padding: 15px; margin-bottom: 20px;">
          <div style="font-size: 18px; font-weight: bold; color: #0f172a; margin-bottom: 8px;">
            بند [${item.itemNumber}]: ${item.name}
          </div>
          <div style="display: flex; gap: 20px; font-size: 13px; color: #334155; flex-wrap: wrap;">
            <div>البند الرئيسي: <strong>${item.parentName || item.parentItemNumber || '—'}</strong></div>
            <div>الوحدة: <strong>${item.unit || '—'}</strong></div>
            <div>الكمية: <strong>${item.quantity ? item.quantity.toLocaleString('en-US') : '—'}</strong></div>
            <div>الميزانية التقديرية: <strong>${formatCurrency(stats.budget, currency)}</strong></div>
            <div>التكلفة الفعلية المنفذة: <strong style="color: #0284c7;">${formatCurrency(stats.actualCost, currency)}</strong></div>
            <div>المتبقي / الانحراف: <strong style="color: ${stats.variance >= 0 ? '#16a34a' : '#dc2626'};">${formatCurrency(stats.variance, currency)}</strong></div>
            <div>نسبة الإنجاز الموقعي: <strong>${item.completionPercentage || 0}%</strong></div>
          </div>
        </div>

        <h3>سجل المصروفات والنفقات المقيدة على هذا البند (${stats.directExpenses.length} حركة)</h3>
        <table>
          <thead>
            <tr>
              <th style="width: 85px;">التاريخ</th>
              <th style="width: 100px;">المبلغ</th>
              <th>بيان النفقة</th>
              <th style="width: 120px;">المستلم / المرحل إليه</th>
              <th style="width: 80px;">النوع</th>
              <th>ملاحظات</th>
            </tr>
          </thead>
          <tbody>
            ${txRows || '<tr><td colspan="6" style="text-align: center; padding: 20px; color: #94a3b8;">لم يتم تسجيل أي مصاريف على هذا البند حتى الآن</td></tr>'}
          </tbody>
        </table>

        <script>
          window.onload = function() {
            setTimeout(function() { window.print(); }, 400);
          };
        </script>
      </body>
      </html>
    `;

    printWindow.document.open();
    printWindow.document.write(html);
    printWindow.document.close();
  };

  return (
    <div className="space-y-6 pb-20 max-w-7xl mx-auto" id="contract-boq-container">
      
      {/* Hidden File Input for Excel Import */}
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleExcelImport}
        accept=".xlsx, .xls, .csv"
        className="hidden"
        id="boq-excel-file-input"
      />

      {/* 1. Page Header */}
      <PageHeaderCard
        title="جداول الكميات وبنود العقد"
        description="إدارة بنود ومخططات عقد المشروع، وتتبع التكاليف الفعلية ومقارنتها بالميزانية التقديرية ونسب الإنجاز لكل فقرة تعاقدية"
        icon={<FileSpreadsheet size={24} className="text-teal-400" />}
        badgeText={`مشروع: ${projectName}`}
        extraActions={
          <div className="flex flex-wrap items-center gap-2">
            {contractItems.length === 0 && (
              <button
                type="button"
                onClick={handleImportStandardTemplate}
                className="px-3 py-2 bg-indigo-600/90 hover:bg-indigo-600 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shadow-sm cursor-pointer"
                title="استيراد نموذج قياسي جاهز للمقاولات"
              >
                <Sparkles size={14} className="text-indigo-200" />
                استيراد نموذج قياسي جاهز
              </button>
            )}

            {sharedRole !== 'read' && (
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="px-3 py-2 bg-teal-600/90 hover:bg-teal-600 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shadow-sm cursor-pointer"
                title="استيراد جداول الكميات وبنود العقد من ملف Excel"
              >
                <Upload size={14} />
                استيراد من ملف Excel
              </button>
            )}

            <button
              type="button"
              onClick={handleExportExcel}
              className="px-3 py-2 bg-emerald-600/90 hover:bg-emerald-600 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shadow-sm cursor-pointer"
              title="تصدير جداول الكميات إلى ملف Excel"
            >
              <Download size={14} />
              تصدير Excel
            </button>

            <button
              type="button"
              onClick={handlePrintBOQReport}
              className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white border border-slate-700 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer"
              title="طباعة كشف شامل لجداول الكميات والتكاليف"
            >
              <Printer size={14} />
              طباعة تقرير PDF
            </button>

            {sharedRole !== 'read' && (
              <>
                <button
                  type="button"
                  onClick={() => handleOpenAddModal('main')}
                  className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-amber-300 hover:text-amber-200 border border-amber-500/40 rounded-xl text-xs font-extrabold transition-all flex items-center gap-1.5 shadow-xs cursor-pointer"
                >
                  <FolderPlus size={15} />
                  إضافة بند رئيسي
                </button>

                <button
                  type="button"
                  onClick={() => handleOpenAddModal('sub')}
                  className="px-4 py-2 bg-gradient-to-r from-teal-500 to-emerald-600 hover:from-teal-600 hover:to-emerald-700 text-slate-950 font-black rounded-xl text-xs sm:text-sm transition-all flex items-center gap-2 shadow-md shadow-teal-500/20 cursor-pointer active:scale-95"
                >
                  <PlusCircle size={16} className="text-slate-950" />
                  إضافة فقرة تعاقدية
                </button>
              </>
            )}
          </div>
        }
      />

      {/* 2. Executive KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
        
        {/* KPI 1: Total Contract Budget */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500">إجمالي الميزانية التعاقدية</span>
            <div className="w-8 h-8 rounded-xl bg-teal-50 text-teal-600 flex items-center justify-center">
              <Wallet size={16} />
            </div>
          </div>
          <div className="mt-2 text-xl font-black text-slate-900">
            {formatCurrency(overallKPIs.totalContractBudget, currency)}
          </div>
          <div className="mt-1 text-[11px] text-slate-400">
            إجمالي {overallKPIs.totalItemsCount} بند وفقرة تعاقدية
          </div>
        </div>

        {/* KPI 2: Total Actual Incurred Cost */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500">التكلفة الفعلية المنفذة</span>
            <div className="w-8 h-8 rounded-xl bg-sky-50 text-sky-600 flex items-center justify-center">
              <TrendingUp size={16} />
            </div>
          </div>
          <div className="mt-2 text-xl font-black text-sky-700">
            {formatCurrency(overallKPIs.totalActualCost, currency)}
          </div>
          <div className="mt-1 text-[11px] text-slate-400">
            من واقع {overallKPIs.linkedExpensesCount} نفقة ومصروف موقعي
          </div>
        </div>

        {/* KPI 3: Remaining / Variance */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500">الرصيد المتبقي / الوفر</span>
            <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${overallKPIs.remainingBudget >= 0 ? 'bg-emerald-50 text-emerald-600' : 'bg-rose-50 text-rose-600'}`}>
              <Coins size={16} />
            </div>
          </div>
          <div className={`mt-2 text-xl font-black ${overallKPIs.remainingBudget >= 0 ? 'text-emerald-700' : 'text-rose-700'}`}>
            {formatCurrency(overallKPIs.remainingBudget, currency)}
          </div>
          <div className="mt-1 text-[11px] text-slate-400">
            {overallKPIs.remainingBudget >= 0 ? 'ضمن حدود الميزانية المعتمدة' : 'تجاوز في التكلفة عن المقدر!'}
          </div>
        </div>

        {/* KPI 4: Overall Consumption Progress */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500">نسبة استهلاك الميزانية</span>
            <div className="w-8 h-8 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center">
              <Percent size={16} />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-xl font-black text-slate-900">
              {overallKPIs.overallConsumption.toFixed(1)}%
            </span>
            <span className="text-[11px] text-slate-400">من الميزانية</span>
          </div>
          <div className="mt-2 w-full bg-slate-100 rounded-full h-2 overflow-hidden">
            <div 
              className={`h-full transition-all duration-500 ${
                overallKPIs.overallConsumption > 100 
                  ? 'bg-rose-500' 
                  : overallKPIs.overallConsumption > 85 
                    ? 'bg-amber-500' 
                    : 'bg-emerald-500'
              }`}
              style={{ width: `${Math.min(overallKPIs.overallConsumption, 100)}%` }}
            />
          </div>
        </div>

      </div>

      {/* 3. Search & Filter Bar */}
      <div className="bg-white p-3.5 rounded-2xl border border-slate-200/80 shadow-xs flex flex-wrap items-center justify-between gap-3">
        
        {/* Search Input */}
        <div className="relative flex-1 min-w-[240px]">
          <Search size={16} className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="بحث بالرقم أو اسم البند (مثال: 1.1 أو تلييس)..."
            className="w-full pr-10 pl-3 py-2 bg-slate-50 hover:bg-slate-100/70 focus:bg-white border border-slate-200 rounded-xl text-xs sm:text-sm font-semibold text-slate-800 placeholder-slate-400 focus:outline-hidden focus:border-teal-500 transition-colors"
          />
        </div>

        {/* Filter by Main Item */}
        <div className="flex items-center gap-2 shrink-0">
          <span className="text-xs font-bold text-slate-500 hidden sm:inline">البند الرئيسي:</span>
          <select
            value={selectedParentFilter}
            onChange={(e) => setSelectedParentFilter(e.target.value)}
            className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 focus:outline-hidden focus:border-teal-500 cursor-pointer"
          >
            <option value="ALL">جميع البنود الرئيسية ({mainItems.length})</option>
            {mainItems.map(m => (
              <option key={m.id} value={m.itemNumber}>
                [{m.itemNumber}] {m.name}
              </option>
            ))}
          </select>
        </div>

        {/* Filter by Execution Status */}
        <div className="flex items-center gap-2 shrink-0">
          <span className="text-xs font-bold text-slate-500 hidden sm:inline">الحالة:</span>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 focus:outline-hidden focus:border-teal-500 cursor-pointer"
          >
            <option value="ALL">جميع الحالات</option>
            <option value="in_progress">قيد التنفيذ</option>
            <option value="completed">مكتمل</option>
            <option value="not_started">لم يبدأ بعد</option>
            <option value="paused">متوقف مؤقتاً</option>
          </select>
        </div>

      </div>

      {/* 4. Empty State */}
      {contractItems.length === 0 ? (
        <div className="bg-white rounded-2xl border-2 border-dashed border-slate-200 p-10 text-center space-y-4">
          <div className="w-16 h-16 rounded-full bg-teal-50 text-teal-600 mx-auto flex items-center justify-center">
            <FileSpreadsheet size={32} />
          </div>
          <div className="max-w-md mx-auto">
            <h3 className="text-base font-bold text-slate-800">لا توجد بنود تعاقدية مضافة في هذا المشروع حتى الآن</h3>
            <p className="text-xs text-slate-500 mt-1 leading-relaxed">
              يمكنك تنظيم عقد المشروع إلى بنود رئيسية (مثل بند التلييس رقم 1 وبند البناء رقم 2) وفقرات فرعية (1.1، 1.2، 2.1) لربط المصاريف اليومية ومتابعة تكلفة كل بند بدقة متناهية.
            </p>
          </div>
          <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
            {sharedRole !== 'read' && (
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="px-4 py-2.5 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-2 shadow-md cursor-pointer"
                title="استيراد جداول الكميات وبنود العقد من ملف Excel"
              >
                <Upload size={16} />
                استيراد من ملف Excel
              </button>
            )}
            <button
              type="button"
              onClick={handleImportStandardTemplate}
              className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-2 shadow-md cursor-pointer"
            >
              <Sparkles size={16} />
              استيراد نموذج قياسي جاهز فوراً
            </button>
            <button
              type="button"
              onClick={() => handleOpenAddModal('main')}
              className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-amber-300 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer"
            >
              <FolderPlus size={16} />
              إضافة أول بند رئيسي يدوياً
            </button>
          </div>
        </div>
      ) : filteredGroups.length === 0 ? (
        <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center text-slate-500 text-xs font-bold">
          لا توجد نتائج تطابق معايير البحث والفلترة المحددة.
        </div>
      ) : (
        /* 5. Grouped Hierarchy Display */
        <div className="space-y-5">
          {filteredGroups.map(group => {
            const isCollapsed = Boolean(collapsedMainItems[group.main.id]);

            return (
              <div 
                key={group.main.id} 
                className="bg-white rounded-2xl border border-slate-200/90 shadow-xs overflow-hidden transition-all"
                id={`main-item-group-${group.main.itemNumber}`}
              >
                {/* Main Item Header Row */}
                <div 
                  onClick={() => toggleCollapse(group.main.id)}
                  className="p-3.5 sm:p-4 bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 text-white flex flex-wrap items-center justify-between gap-3 cursor-pointer select-none transition-colors hover:from-slate-800"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <button
                      type="button"
                      className="w-7 h-7 rounded-lg bg-slate-700/60 hover:bg-slate-700 text-slate-300 flex items-center justify-center shrink-0 transition-colors"
                      title={isCollapsed ? 'توسيع' : 'طي'}
                    >
                      {isCollapsed ? <ChevronDown size={16} /> : <ChevronUp size={16} />}
                    </button>

                    <div className="px-2.5 py-1 rounded-lg bg-amber-400 text-slate-950 font-black text-xs sm:text-sm tracking-wider shrink-0 shadow-xs">
                      بند [{group.main.itemNumber}]
                    </div>

                    <div className="min-w-0">
                      <h4 className="font-extrabold text-sm sm:text-base text-white truncate">
                        {group.main.name}
                      </h4>
                      {group.main.notes && (
                        <p className="text-[11px] text-slate-300 truncate mt-0.5">
                          {group.main.notes}
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Main Item Financial Summary Badges */}
                  <div className="flex flex-wrap items-center gap-2 sm:gap-3 text-xs">
                    
                    {/* Budget Badge */}
                    <div className="px-2.5 py-1 rounded-lg bg-slate-800/80 border border-slate-700 text-slate-200 flex items-center gap-1.5 font-bold">
                      <span className="text-[10px] text-slate-400 font-normal">الميزانية:</span>
                      <span className="text-teal-300">{formatCurrency(group.mainStats.budget, currency)}</span>
                    </div>

                    {/* Actual Cost Badge */}
                    <div className="px-2.5 py-1 rounded-lg bg-slate-800/80 border border-slate-700 text-slate-200 flex items-center gap-1.5 font-bold">
                      <span className="text-[10px] text-slate-400 font-normal">المصروف الفعلي:</span>
                      <span className="text-sky-300">{formatCurrency(group.mainStats.actualCost, currency)}</span>
                    </div>

                    {/* Variance Badge */}
                    <div className={`px-2.5 py-1 rounded-lg font-bold flex items-center gap-1.5 ${group.mainStats.variance >= 0 ? 'bg-emerald-950/60 text-emerald-300 border border-emerald-800/60' : 'bg-rose-950/60 text-rose-300 border border-rose-800/60'}`}>
                      <span className="text-[10px] font-normal">{group.mainStats.variance >= 0 ? 'الوفر:' : 'التجاوز:'}</span>
                      <span>{formatCurrency(Math.abs(group.mainStats.variance), currency)}</span>
                    </div>

                    {/* Quick Action Buttons for Main Item */}
                    {sharedRole !== 'read' && group.main.id !== 'orphan_group' && (
                      <div className="flex items-center gap-1 shrink-0" onClick={(e) => e.stopPropagation()}>
                        <button
                          type="button"
                          onClick={() => handleOpenAddModal('sub', group.main.itemNumber)}
                          className="p-1.5 rounded-lg bg-teal-500/20 hover:bg-teal-500 text-teal-300 hover:text-slate-950 transition-colors cursor-pointer"
                          title="إضافة فقرة تعاقدية تابعة لهذا البند"
                        >
                          <PlusCircle size={15} />
                        </button>

                        <button
                          type="button"
                          onClick={() => handleOpenEditModal(group.main)}
                          className="p-1.5 rounded-lg bg-slate-700/60 hover:bg-slate-600 text-slate-200 transition-colors cursor-pointer"
                          title="تعديل البند الرئيسي"
                        >
                          <Edit size={14} />
                        </button>

                        <button
                          type="button"
                          onClick={() => {
                            if (window.confirm(`هل أنت متأكد من حذف البند الرئيسي [${group.main.itemNumber}] وكافة بياناته؟`)) {
                              onDeleteContractItem(group.main.id);
                            }
                          }}
                          className="p-1.5 rounded-lg bg-rose-500/20 hover:bg-rose-600 text-rose-300 hover:text-white transition-colors cursor-pointer"
                          title="حذف البند الرئيسي"
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    )}

                  </div>
                </div>

                {/* Sub Items Table Body */}
                {!isCollapsed && (
                  <div className="overflow-x-auto">
                    {group.subItems.length === 0 ? (
                      <div className="p-6 text-center text-slate-400 text-xs">
                        لا توجد فقرات تعاقدية مسجلة تحت هذا البند حتى الآن.
                        {sharedRole !== 'read' && (
                          <button
                            type="button"
                            onClick={() => handleOpenAddModal('sub', group.main.itemNumber)}
                            className="text-teal-600 hover:underline font-bold mr-1 inline-flex items-center gap-1"
                          >
                            <PlusCircle size={13} />
                            إضافة فقرة الآن (مثل {group.main.itemNumber}.1)
                          </button>
                        )}
                      </div>
                    ) : (
                      <table className="w-full text-right border-collapse text-xs sm:text-sm">
                        <thead>
                          <tr className="bg-slate-50/90 text-slate-600 font-bold border-b border-slate-200 text-[11px] sm:text-xs select-none">
                            <th className="p-3 w-16 text-center">الرقم</th>
                            <th className="p-3">بيان وتوصيف الفقرة التعاقدية</th>
                            <th className="p-3 w-20 text-center">الوحدة والكمية</th>
                            <th className="p-3 w-28 text-center">سعر الوحدة</th>
                            <th className="p-3 w-32 text-center">الميزانية التعاقدية</th>
                            <th className="p-3 w-32 text-center">التكلفة الفعلية</th>
                            <th className="p-3 w-32 text-center">المتبقي / الوفر</th>
                            <th className="p-3 w-28 text-center">استهلاك الميزانية</th>
                            <th className="p-3 w-24 text-center">الإنجاز الموقعي</th>
                            <th className="p-3 w-24 text-center">إجراءات</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                          {group.subItems.map((sub, idx) => {
                            const stats = getItemStats(sub);

                            return (
                              <tr 
                                key={sub.id} 
                                className={`hover:bg-slate-50/80 transition-colors ${idx % 2 === 1 ? 'bg-slate-50/30' : 'bg-white'}`}
                              >
                                {/* Item Number */}
                                <td className="p-3 text-center font-black text-teal-700 font-mono text-xs">
                                  {sub.itemNumber}
                                </td>

                                {/* Name & Details */}
                                <td className="p-3">
                                  <div className="font-bold text-slate-900 text-xs sm:text-sm">
                                    {sub.name}
                                  </div>
                                  {sub.notes && (
                                    <div className="text-[11px] text-slate-400 mt-0.5 line-clamp-1">
                                      {sub.notes}
                                    </div>
                                  )}
                                  {stats.txCount > 0 && (
                                    <div className="mt-1 flex items-center gap-1 text-[10px] text-sky-600 font-semibold">
                                      <TrendingUp size={11} />
                                      <span>مرتبط بـ {stats.txCount} عملية صرف موقعي</span>
                                    </div>
                                  )}
                                </td>

                                {/* Unit & Qty */}
                                <td className="p-3 text-center">
                                  <div className="font-bold text-slate-800 text-xs">
                                    {sub.quantity ? sub.quantity.toLocaleString('en-US') : '—'}
                                  </div>
                                  <div className="text-[10px] text-slate-400">
                                    {sub.unit || '—'}
                                  </div>
                                </td>

                                {/* Unit Price */}
                                <td className="p-3 text-center text-xs font-semibold text-slate-600">
                                  {sub.unitPrice ? formatCurrency(sub.unitPrice, currency) : '—'}
                                </td>

                                {/* Budget Amount */}
                                <td className="p-3 text-center font-bold text-slate-900 text-xs">
                                  {formatCurrency(stats.budget, currency)}
                                </td>

                                {/* Actual Cost Incurred */}
                                <td className="p-3 text-center">
                                  <div className="font-black text-sky-700 text-xs">
                                    {formatCurrency(stats.actualCost, currency)}
                                  </div>
                                  {stats.txCount > 0 && (
                                    <button
                                      type="button"
                                      onClick={() => setViewingLedgerItem(sub)}
                                      className="text-[10px] text-sky-600 hover:text-sky-800 hover:underline font-bold mt-0.5 inline-block cursor-pointer"
                                    >
                                      عرض كشف الحساب 👁️
                                    </button>
                                  )}
                                </td>

                                {/* Variance / Remaining */}
                                <td className="p-3 text-center font-bold text-xs">
                                  <span className={stats.variance >= 0 ? 'text-emerald-700' : 'text-rose-600'}>
                                    {formatCurrency(stats.variance, currency)}
                                  </span>
                                </td>

                                {/* Budget Consumption Rate */}
                                <td className="p-3 text-center">
                                  <div className="flex items-center justify-center gap-1.5 text-xs font-bold">
                                    <span className={stats.isOverBudget ? 'text-rose-600 font-black' : 'text-slate-700'}>
                                      {stats.consumptionRate.toFixed(0)}%
                                    </span>
                                  </div>
                                  <div className="w-16 mx-auto bg-slate-200 rounded-full h-1.5 mt-1 overflow-hidden">
                                    <div 
                                      className={`h-full ${stats.isOverBudget ? 'bg-rose-500' : stats.consumptionRate > 85 ? 'bg-amber-500' : 'bg-emerald-500'}`}
                                      style={{ width: `${Math.min(stats.consumptionRate, 100)}%` }}
                                    />
                                  </div>
                                </td>

                                {/* Site Completion Percentage */}
                                <td className="p-3 text-center">
                                  <span className={`inline-flex items-center px-2 py-0.5 rounded-md text-[11px] font-bold ${
                                    (sub.completionPercentage || 0) === 100 
                                      ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' 
                                      : (sub.completionPercentage || 0) > 0 
                                        ? 'bg-sky-50 text-sky-700 border border-sky-200' 
                                        : 'bg-slate-100 text-slate-500'
                                  }`}>
                                    {(sub.completionPercentage || 0)}%
                                  </span>
                                </td>

                                {/* Actions */}
                                <td className="p-3 text-center">
                                  <div className="flex items-center justify-center gap-1">
                                    <button
                                      type="button"
                                      onClick={() => setViewingLedgerItem(sub)}
                                      className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors cursor-pointer"
                                      title="كشف حساب تفصيلي للفقرة"
                                    >
                                      <Eye size={14} />
                                    </button>

                                    {sharedRole !== 'read' && (
                                      <>
                                        <button
                                          type="button"
                                          onClick={() => handleOpenEditModal(sub)}
                                          className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors cursor-pointer"
                                          title="تعديل الفقرة التعاقدية"
                                        >
                                          <Edit size={14} />
                                        </button>

                                        <button
                                          type="button"
                                          onClick={() => {
                                            if (window.confirm(`هل أنت متأكد من حذف الفقرة [${sub.itemNumber}] ${sub.name}؟`)) {
                                              onDeleteContractItem(sub.id);
                                            }
                                          }}
                                          className="p-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-600 transition-colors cursor-pointer"
                                          title="حذف الفقرة"
                                        >
                                          <Trash2 size={14} />
                                        </button>
                                      </>
                                    )}
                                  </div>
                                </td>

                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    )}
                  </div>
                )}

              </div>
            );
          })}
        </div>
      )}

      {/* ========================================================================= */}
      {/* 6. MODAL: Add / Edit Contract Item (Main or Sub)                           */}
      {/* ========================================================================= */}
      {isItemModalOpen && (
        <div 
          className="fixed inset-0 z-[120] flex items-center justify-center bg-slate-950/70 backdrop-blur-xs p-2.5 sm:p-4 overflow-y-auto dir-rtl text-right overscroll-contain"
          onClick={() => setIsItemModalOpen(false)}
          onTouchMove={(e) => {
            if (e.target === e.currentTarget) e.preventDefault();
          }}
        >
          <div 
            className="bg-white text-slate-900 rounded-2xl max-w-xl w-full shadow-2xl border border-slate-100 my-auto text-right dir-rtl animate-in fade-in zoom-in duration-150 max-h-[90vh] sm:max-h-[88vh] flex flex-col overflow-hidden overscroll-contain"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="flex items-center justify-between p-4 sm:p-5 border-b border-slate-100 shrink-0 bg-white">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-teal-50 text-teal-600 flex items-center justify-center font-bold">
                  {modalMode === 'main' ? <FolderPlus size={18} /> : <FileSpreadsheet size={18} />}
                </div>
                <div>
                  <h3 className="font-extrabold text-slate-900 text-base">
                    {editingItem ? 'تعديل بند / فقرة تعاقدية' : modalMode === 'main' ? 'إضافة بند رئيسي جديد' : 'إضافة فقرة تعاقدية جديدة'}
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    {modalMode === 'main' ? 'بنود التلييس، أعمال البناء، السباكة، الكهرباء...' : 'الفقرات التفصيلية التابعة مثل 1.1، 1.2، 2.1...'}
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setIsItemModalOpen(false)}
                className="w-8 h-8 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-500 flex items-center justify-center transition-colors cursor-pointer"
              >
                <X size={16} />
              </button>
            </div>

            {/* Mode Switcher if creating new */}
            {!editingItem && (
              <div className="px-4 pt-3 shrink-0 bg-white">
                <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100 rounded-xl">
                  <button
                    type="button"
                    onClick={() => setModalMode('sub')}
                    className={`py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      modalMode === 'sub' 
                        ? 'bg-white text-teal-700 shadow-xs font-black' 
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    فقرة تعاقدية فرعية (مثال: 1.1، 1.2)
                  </button>
                  <button
                    type="button"
                    onClick={() => setModalMode('main')}
                    className={`py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      modalMode === 'main' 
                        ? 'bg-white text-teal-700 shadow-xs font-black' 
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    بند رئيسي / قسم (مثال: بند 1، بند 2)
                  </button>
                </div>
              </div>
            )}

            {/* Form */}
            <form onSubmit={handleSubmitItem} className="flex flex-col flex-1 overflow-hidden min-h-0">
              <div className="p-4 sm:p-5 space-y-3.5 flex-1 overflow-y-auto min-h-0 overscroll-contain touch-pan-y custom-scrollbar modal-scroll-area">
              
              {/* If Sub-item: Select Parent Main Item */}
              {modalMode === 'sub' && (
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    البند الرئيسي التابع له <span className="text-rose-500">*</span>
                  </label>
                  <select
                    value={parentItemNumber}
                    onChange={(e) => {
                      const selectedNum = e.target.value;
                      setParentItemNumber(selectedNum);
                      const parentObj = mainItems.find(m => m.itemNumber === selectedNum);
                      if (parentObj) {
                        setParentName(parentObj.name);
                      }
                      // Auto-update item number prefix if editing hasn't fixed it
                      if (!editingItem) {
                        const subItemsOfParent = contractItems.filter(s => s.parentItemNumber === selectedNum && !s.isMainItem);
                        const nextSub = subItemsOfParent.length + 1;
                        setItemNumber(`${selectedNum}.${nextSub}`);
                      }
                    }}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-semibold text-slate-800 focus:outline-hidden focus:border-teal-500 cursor-pointer"
                  >
                    {mainItems.map(m => (
                      <option key={m.id} value={m.itemNumber}>
                        بند [{m.itemNumber}] - {m.name}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              {/* Number and Name row */}
              <div className="grid grid-cols-3 gap-3">
                <div className="col-span-1">
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    رقم البند / الرمز <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={itemNumber}
                    onChange={(e) => setItemNumber(e.target.value)}
                    placeholder={modalMode === 'main' ? '1' : '1.1'}
                    required
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-black font-mono text-slate-900 focus:outline-hidden focus:border-teal-500 text-center"
                  />
                </div>

                <div className="col-span-2">
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    اسم وتوصيف البند التعاقدي <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder={modalMode === 'main' ? 'أعمال التلييس والدهانات' : 'تلييس داخلي للجدران والأسقف'}
                    required
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-bold text-slate-900 focus:outline-hidden focus:border-teal-500"
                  />
                </div>
              </div>

              {/* Sub-item specific quantities, unit, and prices */}
              {modalMode === 'sub' && (
                <>
                  <div className="grid grid-cols-3 gap-3">
                    <div>
                      <label className="text-xs font-bold text-slate-700 block mb-1">الوحدة</label>
                      <input
                        type="text"
                        value={unit}
                        onChange={(e) => setUnit(e.target.value)}
                        placeholder="م²، م³، طن، نقطة..."
                        className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-semibold text-slate-800 text-center"
                      />
                    </div>

                    <div>
                      <label className="text-xs font-bold text-slate-700 block mb-1">الكمية التعاقدية</label>
                      <input
                        type="number"
                        step="any"
                        value={quantity}
                        onChange={(e) => setQuantity(e.target.value)}
                        placeholder="1500"
                        className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-bold text-slate-800 text-center"
                      />
                    </div>

                    <div>
                      <label className="text-xs font-bold text-slate-700 block mb-1">سعر الوحدة التعاقدي</label>
                      <input
                        type="number"
                        step="any"
                        value={unitPrice}
                        onChange={(e) => setUnitPrice(e.target.value)}
                        placeholder="1200"
                        className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-bold text-slate-800 text-center"
                      />
                    </div>
                  </div>

                  {/* Estimated Cost Budget */}
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs font-bold text-slate-700 block mb-1">
                        ميزانية التكلفة المقدرة ({currency})
                      </label>
                      <input
                        type="number"
                        step="any"
                        value={estimatedBudget}
                        onChange={(e) => setEstimatedBudget(e.target.value)}
                        placeholder={(quantity && unitPrice) ? String(parseFloat(quantity) * parseFloat(unitPrice)) : 'الميزانية التقديرية للتكلفة'}
                        className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-bold text-teal-800"
                      />
                      <span className="text-[10px] text-slate-400">
                        {(quantity && unitPrice) ? `القيمة التعاقدية = ${(parseFloat(quantity) * parseFloat(unitPrice)).toLocaleString('en-US')} ${currency}` : 'تترك فارغة لحسابها تلقائياً'}
                      </span>
                    </div>

                    <div>
                      <label className="text-xs font-bold text-slate-700 block mb-1">
                        نسبة الإنجاز الميداني الفعلي (%)
                      </label>
                      <div className="flex items-center gap-2">
                        <input
                          type="range"
                          min="0"
                          max="100"
                          value={completionPercentage}
                          onChange={(e) => setCompletionPercentage(e.target.value)}
                          className="flex-1 accent-teal-600"
                        />
                        <span className="w-12 text-center text-xs font-black text-slate-800 bg-slate-100 py-1.5 rounded-lg">
                          {completionPercentage}%
                        </span>
                      </div>
                    </div>
                  </div>
                </>
              )}

              {/* Status & Category */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">حالة البند</label>
                  <select
                    value={status}
                    onChange={(e) => setStatus(e.target.value as any)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 cursor-pointer"
                  >
                    <option value="in_progress">قيد التنفيذ بالموقع</option>
                    <option value="completed">مكتمل ومسلّم</option>
                    <option value="not_started">لم يبدأ بعد</option>
                    <option value="paused">متوقف مؤقتاً</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">التصنيف الهندسي</label>
                  <input
                    type="text"
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    placeholder="تشطيبات، خرسانات، سباكة، كهرباء..."
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800"
                  />
                </div>
              </div>

              {/* Notes */}
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">ملاحظات ومواصفات البند</label>
                <textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="أي تفاصيل تعاقدية أو شروط هندسية خاصة بهذا البند..."
                  rows={2}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-hidden focus:border-teal-500 resize-none"
                />
              </div>

              </div>

              {/* Submit Buttons */}
              <div className="flex items-center justify-end gap-2.5 p-3.5 sm:p-4 border-t border-slate-100 bg-slate-50 shrink-0">
                <button
                  type="button"
                  onClick={() => setIsItemModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs transition-colors cursor-pointer"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-gradient-to-r from-teal-500 to-emerald-600 hover:from-teal-600 hover:to-emerald-700 text-slate-950 font-black rounded-xl text-xs sm:text-sm shadow-md cursor-pointer transition-all"
                >
                  {editingItem ? 'حفظ التعديلات' : 'إضافة البند'}
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 7. MODAL: Item Cost Ledger (كشف حساب تكاليف البند)                          */}
      {/* ========================================================================= */}
      {viewingLedgerItem && (() => {
        const stats = getItemStats(viewingLedgerItem);

        return (
          <div 
            className="fixed inset-0 z-[120] flex items-center justify-center bg-slate-950/70 backdrop-blur-xs p-3 sm:p-4 overflow-y-auto"
            onClick={() => setViewingLedgerItem(null)}
          >
            <div 
              className="bg-white text-slate-900 rounded-2xl max-w-3xl w-full p-5 sm:p-6 shadow-2xl border border-slate-100 my-auto text-right dir-rtl animate-in fade-in zoom-in duration-150 max-h-[90vh] flex flex-col"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Header */}
              <div className="flex items-center justify-between pb-3.5 border-b border-slate-100 shrink-0">
                <div className="flex items-center gap-2.5">
                  <div className="w-10 h-10 rounded-xl bg-teal-50 text-teal-600 flex items-center justify-center font-black">
                    {viewingLedgerItem.itemNumber}
                  </div>
                  <div>
                    <h3 className="font-extrabold text-slate-900 text-base">
                      كشف حساب تكاليف البند [{viewingLedgerItem.itemNumber}]: {viewingLedgerItem.name}
                    </h3>
                    <p className="text-xs text-slate-500">
                      البند الرئيسي: {viewingLedgerItem.parentName || viewingLedgerItem.parentItemNumber || '—'}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => handlePrintItemLedger(viewingLedgerItem)}
                    className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-bold transition-colors flex items-center gap-1.5 cursor-pointer"
                  >
                    <Printer size={14} />
                    طباعة الكشف
                  </button>

                  <button
                    type="button"
                    onClick={() => setViewingLedgerItem(null)}
                    className="w-8 h-8 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-500 flex items-center justify-center transition-colors cursor-pointer"
                  >
                    <X size={16} />
                  </button>
                </div>
              </div>

              {/* KPI Mini Row */}
              <div className="grid grid-cols-3 gap-2.5 my-3 shrink-0">
                <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200/80 text-center">
                  <span className="text-[10px] text-slate-500 font-bold block">الميزانية التقديرية</span>
                  <span className="text-xs sm:text-sm font-black text-slate-900">
                    {formatCurrency(stats.budget, currency)}
                  </span>
                </div>
                <div className="bg-sky-50 p-2.5 rounded-xl border border-sky-100 text-center">
                  <span className="text-[10px] text-sky-700 font-bold block">التكلفة المنفذة حتى الآن</span>
                  <span className="text-xs sm:text-sm font-black text-sky-800">
                    {formatCurrency(stats.actualCost, currency)}
                  </span>
                </div>
                <div className={`p-2.5 rounded-xl border text-center ${stats.variance >= 0 ? 'bg-emerald-50 border-emerald-100 text-emerald-800' : 'bg-rose-50 border-rose-100 text-rose-800'}`}>
                  <span className="text-[10px] font-bold block">{stats.variance >= 0 ? 'المتبقي (وفر)' : 'التجاوز'}</span>
                  <span className="text-xs sm:text-sm font-black">
                    {formatCurrency(stats.variance, currency)}
                  </span>
                </div>
              </div>

              {/* Transactions List */}
              <div className="flex-1 overflow-y-auto min-h-0 border border-slate-200 rounded-xl">
                {stats.directExpenses.length === 0 ? (
                  <div className="p-8 text-center text-slate-400 text-xs">
                    لم يتم تسجيل أي مصاريف أو نفقات مرتبطة بهذا البند بعد.
                    <p className="mt-1 text-[11px]">
                      يمكنك تحديد هذا البند في نموذج "إضافة نفقة" من نافذة النفقات اليومية ليتم قيد التكاليف عليه تلقائياً.
                    </p>
                  </div>
                ) : (
                  <table className="w-full text-right border-collapse text-xs">
                    <thead className="sticky top-0 bg-slate-100 text-slate-600 font-bold border-b border-slate-200">
                      <tr>
                        <th className="p-2.5 w-24 text-center">التاريخ</th>
                        <th className="p-2.5 w-28 text-center">المبلغ</th>
                        <th className="p-2.5">البيان والتفاصيل</th>
                        <th className="p-2.5 w-28 text-center">المستلم / المرحل</th>
                        <th className="p-2.5 w-20 text-center">النوع</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 font-medium">
                      {stats.directExpenses.map(exp => (
                        <tr key={exp.id} className="hover:bg-slate-50/80">
                          <td className="p-2.5 text-center text-slate-500 font-mono text-[11px]">
                            {formatDateArabic(exp.date)}
                          </td>
                          <td className="p-2.5 text-center font-black text-sky-700">
                            {formatCurrency(exp.amount, currency)}
                          </td>
                          <td className="p-2.5 text-slate-800">
                            <div className="font-bold">{exp.description}</div>
                            {exp.notes && (
                              <div className="text-[10px] text-slate-400 mt-0.5">{exp.notes}</div>
                            )}
                          </td>
                          <td className="p-2.5 text-center text-slate-600 text-[11px]">
                            {exp.recipientName || '—'}
                          </td>
                          <td className="p-2.5 text-center">
                            <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${exp.expenseType === 'direct' ? 'bg-emerald-50 text-emerald-700' : 'bg-slate-100 text-slate-600'}`}>
                              {exp.expenseType === 'direct' ? 'مباشرة' : 'غير مباشرة'}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
              </div>

              {/* Footer */}
              <div className="pt-3 mt-3 border-t border-slate-100 flex items-center justify-between shrink-0">
                <span className="text-xs text-slate-500 font-bold">
                  إجمالي العمليات: {stats.directExpenses.length} حركة
                </span>
                <button
                  type="button"
                  onClick={() => setViewingLedgerItem(null)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-bold cursor-pointer"
                >
                  إغلاق
                </button>
              </div>

            </div>
          </div>
        );
      })()}

    </div>
  );
}
