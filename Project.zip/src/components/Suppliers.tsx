/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import PageHeaderCard from './PageHeaderCard';
import { isOwnerUser } from './AttributionBadge';
import { AmountInWords } from './AmountInWords';
import { 
  PlusCircle, 
  Trash2, 
  UserPlus, 
  FileSpreadsheet, 
  FileText, 
  Calendar, 
  Truck, 
  ChevronLeft, 
  ArrowLeft, 
  Package, 
  Search,
  Filter,
  Info,
  Pencil,
  ArrowRightLeft,
  Copy,
  ChevronDown,
  ChevronUp,
  RotateCcw,
  Camera,
  Receipt,
  Eye,
  Download,
  Printer,
  X
} from 'lucide-react';
import { 
  Supplier, 
  Worker,
  Employee,
  LedgerEntry, 
  SupplierMaterialItem,
  formatCurrency, 
  formatDateArabic,
  cleanLedgerDescription,
  exportToCSV,
  exportMultiSheetXLSX,
  printPDF
} from '../types';
import { 
  generateSvgDonutChart, 
  generateSvgBalanceComparison, 
  generateMetricCardsGrid,
  generateMaterialCategoryAnalyticsHtml,
  generateSupplierItemsDetailedTableHtml
} from '../utils/reportCharts';
import AttributionBadge from './AttributionBadge';
import Calculator from './Calculator';
import ShareMenu from './ShareMenu';
import OptionsMenu from './OptionsMenu';
import PhoneNumbersInput, { PhoneNumbersDisplay } from './PhoneNumbersInput';
import ExcelColumnFilter, { ColumnFilterConfig, ActiveColumnFilter, ColumnSortState } from './ExcelColumnFilter';
import SupplierMaterialModal from './SupplierMaterialModal';
import CopyMoveLedgerModal from './CopyMoveLedgerModal';
import SupplierReportOptionsModal, { SupplierReportType } from './SupplierReportOptionsModal';
import { useBodyScrollLock } from '../utils/modalScrollLock';
import * as XLSX from 'xlsx';

interface SuppliersProps {
  suppliers: Supplier[];
  workers?: Worker[];
  employees?: Employee[];
  onAddSupplier: (supplier: Omit<Supplier, 'id' | 'ledger'>) => void;
  onDeleteSupplier: (id: string) => void;
  onUpdateSupplier?: (id: string, updatedData: Omit<Supplier, 'id' | 'ledger' | 'createdBy'>) => void;
  onAddSupplierLedgerEntry: (supplierId: string, entry: Omit<LedgerEntry, 'id'>) => void;
  onDeleteSupplierLedgerEntry: (supplierId: string, entryId: string) => void;
  onUpdateSupplierLedgerEntry?: (supplierId: string, entryId: string, updatedEntry: Omit<LedgerEntry, 'id' | 'createdBy'>) => void;
  onCopyLedgerEntry?: (sourceType: 'worker' | 'employee' | 'supplier', sourceId: string, entry: LedgerEntry, targetType: 'worker' | 'employee' | 'supplier', targetId: string) => void;
  onMoveLedgerEntry?: (sourceType: 'worker' | 'employee' | 'supplier', sourceId: string, entry: LedgerEntry, targetType: 'worker' | 'employee' | 'supplier', targetId: string) => void;
  setActiveTab?: (tab: string) => void;
  currency?: string;
  sharedRole?: string;
}

export default function Suppliers({
  suppliers,
  workers = [],
  employees = [],
  onAddSupplier,
  onDeleteSupplier,
  onUpdateSupplier,
  onAddSupplierLedgerEntry,
  onDeleteSupplierLedgerEntry,
  onUpdateSupplierLedgerEntry,
  onCopyLedgerEntry,
  onMoveLedgerEntry,
  setActiveTab,
  currency = 'YER',
  sharedRole = 'admin'
}: SuppliersProps) {
  
  // Selection states
  const [selectedSupplierId, setSelectedSupplierId] = useState<string | null>(null);

  // Edit Supplier states
  const [editingSupplier, setEditingSupplier] = useState<Supplier | null>(null);
  const [editingSupplierLedger, setEditingSupplierLedger] = useState<{ supplierId: string; entry: LedgerEntry } | null>(null);

  // Copy / Move Ledger Entry modal state
  const [copyMoveModalState, setCopyMoveModalState] = useState<{
    isOpen: boolean;
    mode: 'copy' | 'move';
    entry: LedgerEntry | null;
    supplierId: string;
    supplierName: string;
  }>({
    isOpen: false,
    mode: 'copy',
    entry: null,
    supplierId: '',
    supplierName: ''
  });

  // Material Sheet (كشف المواد) and Invoice states
  const [pendingMaterialItems, setPendingMaterialItems] = useState<SupplierMaterialItem[]>([]);
  const [pendingInvoiceNumber, setPendingInvoiceNumber] = useState('');
  const [pendingInvoiceImage, setPendingInvoiceImage] = useState('');
  const [pendingMaterialDiscount, setPendingMaterialDiscount] = useState<number | undefined>(undefined);
  const [isAddMaterialModalOpen, setIsAddMaterialModalOpen] = useState(false);
  const [viewingMaterialEntry, setViewingMaterialEntry] = useState<{ supplierId: string; entry: LedgerEntry } | null>(null);

  // Print Report Options Modal state (Detailed vs Condensed selection)
  const [printModalState, setPrintModalState] = useState<{
    isOpen: boolean;
    type: 'single' | 'all';
    supplier?: Supplier;
  }>({
    isOpen: false,
    type: 'single'
  });

  // Lock background scroll when modal is open
  useBodyScrollLock(Boolean(editingSupplier || editingSupplierLedger || isAddMaterialModalOpen || viewingMaterialEntry || printModalState.isOpen));

  // Submit handlers for editing
  const handleEditSupplierSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingSupplier) return;

    const rawPhones = editingSupplier.phoneNumbers || [];
    if (rawPhones.some(p => p.trim().length > 0 && p.trim().length < 9)) {
      alert('رقم الهاتف يجب أن يتكون من 9 أرقام (مثال: 771234567)');
      return;
    }
    const cleanPhones = rawPhones.map(p => p.trim()).filter(p => p.length === 9);

    if (onUpdateSupplier) {
      onUpdateSupplier(editingSupplier.id, {
        name: editingSupplier.name,
        materialType: editingSupplier.materialType,
        phoneNumbers: cleanPhones,
        notes: editingSupplier.notes || ''
      });
    }
    setEditingSupplier(null);
  };

  const handleEditSupplierLedgerSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingSupplierLedger) return;
    if (onUpdateSupplierLedgerEntry) {
      onUpdateSupplierLedgerEntry(editingSupplierLedger.supplierId, editingSupplierLedger.entry.id, {
        date: editingSupplierLedger.entry.date,
        amountOnHim: editingSupplierLedger.entry.amountOnHim,
        amountForHim: editingSupplierLedger.entry.amountForHim,
        description: editingSupplierLedger.entry.description,
        notes: editingSupplierLedger.entry.notes,
        currency: editingSupplierLedger.entry.currency || 'YER',
        materialItems: editingSupplierLedger.entry.materialItems,
        materialDiscount: editingSupplierLedger.entry.materialDiscount,
        invoiceNumber: editingSupplierLedger.entry.invoiceNumber,
        invoiceImage: editingSupplierLedger.entry.invoiceImage
      });
    }
    setEditingSupplierLedger(null);
  };

  // Add Supplier form
  const [showAddSupplierForm, setShowAddSupplierForm] = useState(false);
  const [newSupplierName, setNewSupplierName] = useState('');
  const [newMaterialType, setNewMaterialType] = useState('');
  const [newSupplierPhoneNumbers, setNewSupplierPhoneNumbers] = useState<string[]>(['']);
  const [newSupplierNotes, setNewSupplierNotes] = useState('');

  // Add Supplier Ledger Entry form
  const [ledgerDate, setLedgerDate] = useState(() => {
    const today = new Date();
    return today.toISOString().split('T')[0];
  });
  const [ledgerAmountOnHim, setLedgerAmountOnHim] = useState(''); // عليه (ما دفعناه له)
  const [ledgerAmountForHim, setLedgerAmountForHim] = useState(''); // له (قيمة المواد الموردة)
  const [ledgerDescription, setLedgerDescription] = useState('');
  const [ledgerNotes, setLedgerNotes] = useState('');
  const [ledgerCurrency, setLedgerCurrency] = useState(currency);
  const [showAddLedgerForm, setShowAddLedgerForm] = useState(false);

  // Search filter & sort filters
  const [searchQuery, setSearchQuery] = useState('');
  const [supplierSortOrder, setSupplierSortOrder] = useState<'asc' | 'desc'>('desc'); // Default desc: newest first
  
  // Ledger filters state
  const [isLedgerFiltersOpen, setIsLedgerFiltersOpen] = useState(false);
  const [ledgerSearchTerm, setLedgerSearchTerm] = useState('');
  const [ledgerStartDate, setLedgerStartDate] = useState('');
  const [ledgerEndDate, setLedgerEndDate] = useState('');
  const [ledgerTypeFilter, setLedgerTypeFilter] = useState<'all' | 'onHim' | 'forHim'>('all');
  const [ledgerSortOption, setLedgerSortOption] = useState<'date-desc' | 'date-asc' | 'desc-alpha' | 'amountOnHim-desc' | 'amountForHim-desc'>('date-desc');

  // Alerts
  const [supplierError, setSupplierError] = useState('');
  const [ledgerError, setLedgerError] = useState('');

  // Keep ledger currency in sync with global currency selection when prop changes
  useEffect(() => {
    setLedgerCurrency(currency);
  }, [currency]);

  // Find active supplier
  const activeSupplier = suppliers.find(s => s.id === selectedSupplierId);

  // Form submit for new supplier
  const handleAddSupplierSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSupplierError('');

    if (!newSupplierName.trim()) {
      setSupplierError('الرجاء إدخال اسم المورد.');
      return;
    }
    if (!newMaterialType.trim()) {
      setSupplierError('الرجاء إدخال نوع المواد الموردة.');
      return;
    }

    if (newSupplierPhoneNumbers.some(p => p.trim().length > 0 && p.trim().length < 9)) {
      setSupplierError('رقم الهاتف يجب أن يتكون من 9 أرقام (مثال: 771234567).');
      return;
    }

    const validPhones = newSupplierPhoneNumbers.map(p => p.trim()).filter(p => p.length === 9);

    onAddSupplier({
      name: newSupplierName.trim(),
      materialType: newMaterialType.trim(),
      phoneNumbers: validPhones,
      notes: newSupplierNotes.trim()
    });

    // Reset Form
    setNewSupplierName('');
    setNewMaterialType('');
    setNewSupplierPhoneNumbers(['']);
    setNewSupplierNotes('');
    setShowAddSupplierForm(false);
  };

  // Form submit for ledger entry
  const handleAddLedgerSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLedgerError('');

    const onHim = parseFloat(ledgerAmountOnHim) || 0;
    const forHim = parseFloat(ledgerAmountForHim) || 0;

    if (onHim === 0 && forHim === 0) {
      setLedgerError('يجب إدخال قيمة في حقل "مبلغ عليه" أو "مبلغ له".');
      return;
    }
    if (onHim < 0 || forHim < 0) {
      setLedgerError('المبالغ يجب أن تكون قيم موجبة.');
      return;
    }
    if (!ledgerDescription.trim()) {
      setLedgerError('الرجاء إدخال البيان.');
      return;
    }

    if (selectedSupplierId) {
      onAddSupplierLedgerEntry(selectedSupplierId, {
        date: ledgerDate,
        amountOnHim: onHim,
        amountForHim: forHim,
        description: ledgerDescription.trim(),
        notes: ledgerNotes.trim(),
        currency: ledgerCurrency,
        materialItems: pendingMaterialItems.length > 0 ? pendingMaterialItems : undefined,
        materialDiscount: pendingMaterialDiscount,
        invoiceNumber: pendingInvoiceNumber.trim() || undefined,
        invoiceImage: pendingInvoiceImage || undefined
      });

      // Reset fields
      setLedgerAmountOnHim('');
      setLedgerAmountForHim('');
      setLedgerDescription('');
      setLedgerNotes('');
      setPendingMaterialItems([]);
      setPendingInvoiceNumber('');
      setPendingInvoiceImage('');
      setPendingMaterialDiscount(undefined);
    }
  };

  const handleResetAddSupplierForm = () => {
    setNewSupplierName('');
    setNewMaterialType('');
    setNewSupplierPhoneNumbers(['']);
    setNewSupplierNotes('');
    setSupplierError('');
  };

  const handleResetAddLedgerForm = () => {
    setLedgerDate(new Date().toISOString().split('T')[0]);
    setLedgerAmountOnHim('');
    setLedgerAmountForHim('');
    setLedgerDescription('');
    setLedgerNotes('');
    setLedgerCurrency(currency);
    setPendingMaterialItems([]);
    setPendingInvoiceNumber('');
    setPendingInvoiceImage('');
    setPendingMaterialDiscount(undefined);
    setLedgerError('');
  };

  // Excel File upload/import handler for suppliers list
  const handleSupplierExcelImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const data = event.target?.result;
        const workbook = XLSX.read(data, { type: 'binary' });
        const sheetName = workbook.SheetNames[0];
        const sheet = workbook.Sheets[sheetName];
        const rows = XLSX.utils.sheet_to_json<any>(sheet);

        let count = 0;
        rows.forEach((row: any) => {
          // Map properties (support both Arabic and English names)
          const name = row['الاسم'] || row['اسم المورد'] || row['Name'] || row['name'] || row['المورد'] || row['الموردين'];
          const materialType = row['نوع المواد'] || row['المواد'] || row['المواد الموردة'] || row['Material Type'] || row['material_type'] || row['Type'] || row['type'] || 'مواد عامة';
          const phoneRaw = row['رقم الهاتف'] || row['الهاتف'] || row['رقم الجوال'] || row['الجوال'] || row['Phone'] || row['phone'] || '';

          const phoneNumbers: string[] = [];
          if (phoneRaw) {
            String(phoneRaw).split(/[,;/\n]+/).forEach(p => {
              const digits = p.replace(/\D/g, '').slice(0, 9);
              if (digits.length === 9) phoneNumbers.push(digits);
            });
          }

          if (name) {
            onAddSupplier({
              name: String(name).trim(),
              materialType: String(materialType).trim(),
              phoneNumbers
            });
            count++;
          }
        });

        alert(`تم استيراد ${count} مورد بنجاح من ملف Excel!`);
      } catch (err) {
        console.error("Error reading Excel for suppliers:", err);
        alert('حدث خطأ أثناء قراءة ملف Excel. يرجى التأكد من أن الأعمدة مطابقة (اسم المورد، نوع المواد الموردة).');
      }
    };
    reader.readAsBinaryString(file);
    e.target.value = '';
  };

  // Excel File upload/import handler for active supplier's ledger
  const handleLedgerExcelImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !selectedSupplierId) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const data = event.target?.result;
        const workbook = XLSX.read(data, { type: 'binary' });
        const sheetName = workbook.SheetNames[0];
        const sheet = workbook.Sheets[sheetName];
        const rows = XLSX.utils.sheet_to_json<any>(sheet);

        let count = 0;
        rows.forEach((row: any) => {
          const dateVal = row['التاريخ'] || row['تاريخ'] || row['Date'] || row['date'];
          const desc = row['البيان'] || row['التفاصيل'] || row['Description'] || row['description'] || row['Details'] || row['details'] || row['البيان/العمليات'];
          const onHim = parseFloat(row['مبلغ عليه'] || row['المسدد'] || row['سلف'] || row['عليه'] || row['On Him'] || row['Debit'] || row['on_him'] || row['debit']) || 0;
          const forHim = parseFloat(row['مبلغ له'] || row['قيمة المواد'] || row['المواد'] || row['له'] || row['For Him'] || row['Credit'] || row['for_him'] || row['credit']) || 0;
          const notes = row['ملاحظات'] || row['الملاحظات'] || row['Notes'] || row['notes'] || '';
          const cur = row['العملة'] || row['currency'] || row['Currency'] || ledgerCurrency || currency || 'YER';

          if (dateVal && desc && (onHim > 0 || forHim > 0)) {
            const parseDate = (d: any) => {
              if (!d) return new Date().toISOString().split('T')[0];
              if (typeof d === 'number') {
                const dateObj = new Date((d - 25569) * 86400 * 1000);
                return dateObj.toISOString().split('T')[0];
              }
              const stringDate = String(d).trim();
              const parsed = Date.parse(stringDate);
              if (!isNaN(parsed)) {
                return new Date(parsed).toISOString().split('T')[0];
              }
              return stringDate;
};

            onAddSupplierLedgerEntry(selectedSupplierId, {
              date: parseDate(dateVal),
              amountOnHim: onHim,
              amountForHim: forHim,
              description: String(desc).trim(),
              notes: String(notes).trim(),
              currency: String(cur).trim()
            });
            count++;
          }
        });

        alert(`تم استيراد عدد ${count} حركة مالية بنجاح إلى كشف حساب المورد!`);
      } catch (err) {
        console.error("Error reading Excel supplier ledger:", err);
        alert('حدث خطأ أثناء قراءة ملف Excel للكشف. يرجى التأكد من مطابقة الأعمدة (التاريخ، البيان، مبلغ عليه، مبلغ له، ملاحظات).');
      }
    };
    reader.readAsBinaryString(file);
    e.target.value = '';
  };

  // Export Suppliers Directory & Detailed Ledgers to Multi-sheet Excel
  const handleExportAllCSV = () => {
    // Sheet 1: Summary
    const summaryHeaders = [
      'الرقم التعريفي',
      'اسم المورد / الشركة',
      'نوع المواد الموردة',
      'رقم الهاتف',
      'إجمالي له (قيمة البضاعة المستلمة)',
      'إجمالي عليه (دفعات نقدية مسددة)',
      'صافي الرصيد الحالي',
      'الحالة المالية'
    ];

    const summaryRows = suppliers.map(s => {
      const totalOnHim = s.ledger.reduce((sum, e) => sum + e.amountOnHim, 0);
      const totalForHim = s.ledger.reduce((sum, e) => sum + e.amountForHim, 0);
      const net = totalForHim - totalOnHim;
      const netText = net === 0 ? 'خالص' : net > 0 ? `له: ${net}` : `عليه: ${Math.abs(net)}`;

      return [
        s.id,
        s.name,
        s.materialType,
        s.phoneNumbers?.join(' - ') || '-',
        totalForHim,
        totalOnHim,
        net,
        netText
      ];
    });

    // Sheet 2: Detailed ledger entries for ALL suppliers
    const ledgerHeaders = [
      'اسم المورد',
      'نوع المواد',
      'تاريخ الحركة',
      'البيان / الفاتورة / التفاصيل',
      'مبلغ له (توريد مواد)',
      'مبلغ عليه (سداد / دفعة)',
      'العملة',
      'الملاحظات',
      'بواسطة'
    ];

    const ledgerRows: (string | number)[][] = [];
    suppliers.forEach(s => {
      s.ledger.forEach(entry => {
        ledgerRows.push([
          s.name,
          s.materialType,
          entry.date,
          entry.description,
          entry.amountForHim || 0,
          entry.amountOnHim || 0,
          entry.currency || currency,
          entry.notes || '-',
          (entry.createdBy && !isOwnerUser(entry.createdBy)) ? entry.createdBy : '-'
        ]);
      });
    });
    ledgerRows.sort((a, b) => (b[2] as string).localeCompare(a[2] as string));

    // Sheet 3 & 4: Detailed material items and category summary for ALL suppliers
    const materialItemsHeaders = [
      'اسم المورد',
      'نوع المواد العام',
      'تاريخ الحركة',
      'رقم الفاتورة',
      'اسم الصنف / المادة',
      'فئة الصنف',
      'الكمية',
      'الوحدة',
      'سعر الوحدة',
      'إجمالي البند',
      'العملة',
      'الملاحظات'
    ];
    const materialItemsRows: (string | number)[][] = [];
    const categoryTotals: Record<string, { count: number; totalCost: number; suppliers: Set<string> }> = {};

    suppliers.forEach(s => {
      s.ledger.forEach(entry => {
        if (entry.materialItems && entry.materialItems.length > 0) {
          entry.materialItems.forEach(it => {
            const cat = it.category?.trim() || s.materialType || 'عام';
            const totalVal = it.total || (it.quantity * it.unitPrice) || 0;
            materialItemsRows.push([
              s.name,
              s.materialType,
              entry.date,
              entry.invoiceNumber || '-',
              it.itemName,
              cat,
              it.quantity,
              it.unit || '-',
              it.unitPrice,
              totalVal,
              entry.currency || currency,
              it.notes || '-'
            ]);

            if (!categoryTotals[cat]) {
              categoryTotals[cat] = { count: 0, totalCost: 0, suppliers: new Set() };
            }
            categoryTotals[cat].count += 1;
            categoryTotals[cat].totalCost += totalVal;
            categoryTotals[cat].suppliers.add(s.name);
          });
        }
      });
    });

    const sheets: { sheetName: string; headers: string[]; rows: (string | number)[][] }[] = [
      { sheetName: 'سجل الموردين العام', headers: summaryHeaders, rows: summaryRows },
      { sheetName: 'تفاصيل حركات كشف الموردين', headers: ledgerHeaders, rows: ledgerRows }
    ];

    if (materialItemsRows.length > 0) {
      materialItemsRows.sort((a, b) => (b[2] as string).localeCompare(a[2] as string));
      sheets.push({ sheetName: 'أصناف وفئات المواد الموردة', headers: materialItemsHeaders, rows: materialItemsRows });

      const grandMatTotal = Object.values(categoryTotals).reduce((sum, c) => sum + c.totalCost, 0);
      const categorySummaryHeaders = [
        'فئة المادة',
        'عدد الأصناف المسجلة',
        'إجمالي تكلفة الفئة',
        'النسبة المئوية من المشتريات %',
        'عدد الموردين'
      ];
      const categorySummaryRows = Object.entries(categoryTotals)
        .sort((a, b) => b[1].totalCost - a[1].totalCost)
        .map(([cat, data]) => [
          cat,
          data.count,
          data.totalCost,
          grandMatTotal > 0 ? `${((data.totalCost / grandMatTotal) * 100).toFixed(1)}%` : '0%',
          data.suppliers.size
        ]);
      sheets.push({ sheetName: 'ملخص فئات المواد الموردة', headers: categorySummaryHeaders, rows: categorySummaryRows });
    }

    exportMultiSheetXLSX(`تقرير_الموردين_التفصيلي_الشامل_${new Date().toISOString().split('T')[0]}`, sheets);
  };

  // Export Active Supplier's ledger to CSV or multi-sheet Excel
  const handleExportLedgerCSV = (supplier: Supplier) => {
    const headers = [
      'التاريخ',
      'البيان',
      'مبلغ عليه (دفعات نقدية مسددة)',
      'مبلغ له (قيمة المواد المستلمة)',
      'ملاحظات'
    ];

    const sortedLedger = [...supplier.ledger].sort((a, b) => b.date.localeCompare(a.date));
    const rows = sortedLedger.map(e => [
      e.date,
      e.description,
      e.amountOnHim.toString(),
      e.amountForHim.toString(),
      e.notes
    ]);

    // Check if supplier has material items
    const hasMaterialItems = supplier.ledger.some(e => e.materialItems && e.materialItems.length > 0);
    if (!hasMaterialItems) {
      exportToCSV(`كشف_حساب_المورد_${supplier.name.replace(/\s+/g, '_')}`, headers, rows);
      return;
    }

    // Export as rich multi-sheet XLSX with material items & category breakdown
    const matHeaders = ['تاريخ الحركة', 'رقم الفاتورة', 'اسم الصنف / المادة', 'الفئة', 'الكمية', 'الوحدة', 'سعر الوحدة', 'إجمالي البند', 'الملاحظات'];
    const matRows: (string | number)[][] = [];
    const catTotals: Record<string, { count: number; total: number }> = {};

    sortedLedger.forEach(e => {
      if (e.materialItems && e.materialItems.length > 0) {
        e.materialItems.forEach(it => {
          const cat = it.category?.trim() || supplier.materialType || 'عام';
          const totalVal = it.total || (it.quantity * it.unitPrice) || 0;
          matRows.push([
            e.date,
            e.invoiceNumber || '-',
            it.itemName,
            cat,
            it.quantity,
            it.unit || '-',
            it.unitPrice,
            totalVal,
            it.notes || '-'
          ]);
          if (!catTotals[cat]) catTotals[cat] = { count: 0, total: 0 };
          catTotals[cat].count += 1;
          catTotals[cat].total += totalVal;
        });
      }
    });

    const grandTotal = Object.values(catTotals).reduce((s, c) => s + c.total, 0);
    const catSummaryHeaders = ['فئة المادة', 'عدد الأصناف', 'إجمالي القيمة', 'النسبة المئوية %'];
    const catSummaryRows = Object.entries(catTotals)
      .sort((a, b) => b[1].total - a[1].total)
      .map(([cat, d]) => [
        cat,
        d.count,
        d.total,
        grandTotal > 0 ? `${((d.total / grandTotal) * 100).toFixed(1)}%` : '0%'
      ]);

    exportMultiSheetXLSX(`كشف_حساب_وتفاصيل_مواد_${supplier.name.replace(/\s+/g, '_')}_${new Date().toISOString().split('T')[0]}`, [
      { sheetName: 'كشف الحساب المالي', headers, rows },
      { sheetName: 'أصناف ومواد المورد', headers: matHeaders, rows: matRows },
      { sheetName: 'ملخص فئات المواد', headers: catSummaryHeaders, rows: catSummaryRows }
    ]);
  };

  // Print Active Supplier's Ledger to PDF
  const handlePrintSupplierPDF = (supplier: Supplier, reportType: SupplierReportType = 'detailed') => {
    const totalOnHim = supplier.ledger.reduce((sum, e) => sum + e.amountOnHim, 0);
    const totalForHim = supplier.ledger.reduce((sum, e) => sum + e.amountForHim, 0);
    const net = totalForHim - totalOnHim;
    const isDetailed = reportType === 'detailed';

    let ledgerRowsHtml = '';
    const sortedLedgerForPrint = [...supplier.ledger].sort((a, b) => b.date.localeCompare(a.date));
    sortedLedgerForPrint.forEach((e, idx) => {
      const hasMaterials = Boolean(e.materialItems && e.materialItems.length > 0);
      const materialDetailsHtml = (hasMaterials && isDetailed)
        ? generateSupplierItemsDetailedTableHtml(e.materialItems!, currency, e.invoiceNumber, e.materialDiscount)
        : '';

      ledgerRowsHtml += `
        <tr style="background-color: ${idx % 2 === 0 ? '#ffffff' : '#f8fafc'};">
          <td style="padding: 8px; border: 1px solid #cbd5e1; font-family: monospace; width: 14%;">${formatDateArabic(e.date)}</td>
          <td style="padding: 8px; border: 1px solid #cbd5e1; font-weight: bold; width: 38%;" class="col-statement">
            <div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 4px;">
              <span>${e.description}</span>
              ${e.invoiceNumber ? `<span style="font-family: monospace; font-size: 10px; font-weight: 800; background: #fff7ed; color: #c2410c; padding: 1.5px 6px; border-radius: 4px; border: 1px solid #fdba74;">فاتورة #${e.invoiceNumber}</span>` : ''}
            </div>
            ${hasMaterials ? `
              <div style="font-size: 9.5px; font-weight: normal; margin-top: 3px; color: ${isDetailed ? '#c2410c' : '#64748b'};">
                ${isDetailed 
                  ? `📦 تفاصيل كشف المواد (${e.materialItems!.length} صنف) موضحة بالجدول أدناه 👇` 
                  : `📦 يتضمن كشف مواد (${e.materialItems!.length} صنف)`}
              </div>
            ` : ''}
          </td>
          <td style="padding: 8px; border: 1px solid #cbd5e1; text-align: center; color: #dc2626; font-weight: bold; width: 17%;">${e.amountOnHim > 0 ? formatCurrency(e.amountOnHim, currency) : '-'}</td>
          <td style="padding: 8px; border: 1px solid #cbd5e1; text-align: center; color: #16a34a; font-weight: bold; width: 17%;">${e.amountForHim > 0 ? formatCurrency(e.amountForHim, currency) : '-'}</td>
          <td style="padding: 8px; border: 1px solid #cbd5e1; font-size: 9.5px; color: #64748b; line-height: 1.35; width: 14%;" class="col-notes">${e.notes || '-'}</td>
        </tr>
      `;

      if (hasMaterials && isDetailed && materialDetailsHtml) {
        ledgerRowsHtml += `
          <tr style="background-color: #fffdfa; break-inside: avoid; page-break-inside: avoid;">
            <td colspan="5" style="padding: 6px 12px 12px 12px; border: 1px solid #cbd5e1; border-top: 1px dashed #cbd5e1; background: #fffdfa;">
              ${materialDetailsHtml}
            </td>
          </tr>
        `;
      }
    });

    const metricCardsHtml = generateMetricCardsGrid([
      {
        title: 'نوع المواد الموردة',
        value: supplier.materialType || 'عام',
        badge: 'التصنيف الرئيسي',
        bgColor: '#f5f3ff',
        borderColor: '#ddd6fe',
        textColor: '#6d28d9'
      },
      {
        title: 'إجمالي قيمة المواد (له)',
        value: formatCurrency(totalForHim, currency),
        badge: 'فواتير ومواد',
        bgColor: '#f0fdf4',
        borderColor: '#bbf7d0',
        textColor: '#15803d'
      },
      {
        title: 'إجمالي المسدد له (عليه)',
        value: formatCurrency(totalOnHim, currency),
        badge: 'دفعات نقدية وبنكية',
        bgColor: '#fef2f2',
        borderColor: '#fecaca',
        textColor: '#b91c1c'
      },
      {
        title: 'صافي الرصيد المستحق',
        value: formatCurrency(Math.abs(net), currency),
        badge: net >= 0 ? 'مستحق للمورد' : 'دفعة فائضة لدينا',
        bgColor: net >= 0 ? '#f5f3ff' : '#fffbeb',
        borderColor: net >= 0 ? '#ddd6fe' : '#fde68a',
        textColor: net >= 0 ? '#6d28d9' : '#b45309'
      }
    ], 4);

    const balanceGaugeHtml = generateSvgBalanceComparison({
      forHim: totalForHim,
      onHim: totalOnHim,
      forHimLabel: 'قيمة المواد المستلمة (له)',
      onHimLabel: 'الدفعات المسددة للمورد (عليه)',
      forHimFormatted: formatCurrency(totalForHim, currency),
      onHimFormatted: formatCurrency(totalOnHim, currency),
      netFormatted: net >= 0 ? `له (${formatCurrency(net, currency)})` : `عليه (${formatCurrency(Math.abs(net), currency)})`,
      isPositive: net >= 0
    });

    const hasSupplierMaterialItems = supplier.ledger.some(e => e.materialItems && e.materialItems.length > 0);
    const supplierCategoryAnalyticsHtml = hasSupplierMaterialItems ? generateMaterialCategoryAnalyticsHtml({
      suppliers: [supplier],
      currency,
      panelTitle: `لوحة تحليلات ورسم بياني لفئات المواد الموردة من (${supplier.name})`,
      panelSubtitle: `ملخص التكاليف والكميات ونسب الاستهلاك بحسب فئة المادة المسجلة لهذا المورد`
    }) : '';

    const htmlContent = `
      <div style="direction: rtl; font-family: sans-serif; padding: 15px;">
        
        <!-- Header -->
        <div style="border-bottom: 2px solid #7c3aed; padding-bottom: 12px; margin-bottom: 16px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 8px;">
          <div>
            <div style="display: flex; align-items: center; gap: 8px; flex-wrap: wrap;">
              <h1 style="margin: 0; color: #1e1b4b; font-size: 19px;">📋 كشف حساب ومعاملات المورد</h1>
              <span style="background-color: ${isDetailed ? '#f5f3ff' : '#f0f9ff'}; color: ${isDetailed ? '#6d28d9' : '#0369a1'}; border: 1px solid ${isDetailed ? '#ddd6fe' : '#bae6fd'}; padding: 2px 8px; border-radius: 6px; font-size: 10.5px; font-weight: bold;">
                ${isDetailed ? '✨ تقرير تفصيلي شامل كشف المواد' : '📄 تقرير مالي مختصر'}
              </span>
            </div>
            <p style="margin: 4px 0 0 0; color: #64748b; font-size: 12px;">ورلد أوف إيليتس للتجارة والمقاولات</p>
          </div>
          <div style="text-align: left; font-size: 11.5px; color: #64748b;">
            تاريخ الطباعة: ${new Date().toLocaleDateString('ar-EG-u-nu-latn')}
          </div>
        </div>

        <!-- Supplier Info Card -->
        <div style="background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 12px 16px; margin-bottom: 16px;">
          <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 10px; font-size: 12px;">
            <div><strong>اسم المورد:</strong> ${supplier.name}</div>
            <div><strong>نوع المواد الموردة:</strong> ${supplier.materialType}</div>
          </div>
        </div>

        <!-- Analytics Visuals -->
        <div style="margin-bottom: 16px; page-break-inside: avoid;">
          ${metricCardsHtml}
          ${balanceGaugeHtml}
        </div>

        ${supplierCategoryAnalyticsHtml}

        <!-- Detailed Table -->
        <table class="report-data-table" style="width: 100%; border-collapse: collapse; font-size: 11.5px; margin-bottom: 20px;">
          <thead>
            <tr style="background-color: #7c3aed; color: white;">
              <th style="padding: 8px; border: 1px solid #cbd5e1; text-align: right; width: 14%;">التاريخ</th>
              <th style="padding: 8px; border: 1px solid #cbd5e1; text-align: right; width: 38%;" class="col-statement">البيان / الفاتورة</th>
              <th style="padding: 8px; border: 1px solid #cbd5e1; text-align: center; width: 17%;">مبلغ عليه (دفعات مسددة له)</th>
              <th style="padding: 8px; border: 1px solid #cbd5e1; text-align: center; width: 17%;">مبلغ له (قيمة مواد مستلمة)</th>
              <th style="padding: 8px; border: 1px solid #cbd5e1; text-align: right; width: 14%;" class="col-notes">ملاحظات</th>
            </tr>
          </thead>
          <tbody>
            ${supplier.ledger.length === 0 ? '<tr><td colspan="5" style="text-align: center; color: #94a3b8; padding: 12px;">لا توجد تعاملات مسجلة حالياً.</td></tr>' : ledgerRowsHtml}
          </tbody>
        </table>

        <!-- Summary Footer -->
        <div style="background-color: #f5f3ff; border-radius: 8px; padding: 12px; font-size: 12px; border: 1px solid #ddd6fe; display: flex; justify-content: space-between; align-items: center;">
          <div>إجمالي المسدد له: <strong style="color: #dc2626;">${formatCurrency(totalOnHim, currency)}</strong></div>
          <div>إجمالي قيمة المواد: <strong style="color: #16a34a;">${formatCurrency(totalForHim, currency)}</strong></div>
          <div>صافي الرصيد المستحق: <strong style="color: ${net >= 0 ? '#6d28d9' : '#b91c1c'}; font-size: 14px;">${net >= 0 ? `له (${formatCurrency(net, currency)})` : `عليه (${formatCurrency(Math.abs(net), currency)})`}</strong></div>
        </div>
      </div>
    `;

    printPDF(`كشف_حساب_${supplier.name.replace(/\s+/g, '_')}_${isDetailed ? 'تفصيلي' : 'مختصر'}`, htmlContent);
  };

  // Print all suppliers summary and detailed ledgers PDF
  const handlePrintAllSuppliersPDF = (reportType: SupplierReportType = 'detailed') => {
    const isDetailed = reportType === 'detailed';
    let grandOnHim = 0;
    let grandForHim = 0;
    const materialTypeCounts: Record<string, { count: number; totalPurchases: number }> = {};

    let supplierSummaryRowsHtml = '';
    let suppliersDetailedLedgersHtml = '';

    suppliers.forEach(s => {
      const totalOnHim = s.ledger.reduce((sum, e) => sum + e.amountOnHim, 0);
      const totalForHim = s.ledger.reduce((sum, e) => sum + e.amountForHim, 0);
      const net = totalForHim - totalOnHim;

      grandOnHim += totalOnHim;
      grandForHim += totalForHim;

      const matType = s.materialType?.trim() || 'توريدات عامة';
      if (!materialTypeCounts[matType]) {
        materialTypeCounts[matType] = { count: 0, totalPurchases: 0 };
      }
      materialTypeCounts[matType].count += 1;
      materialTypeCounts[matType].totalPurchases += totalForHim;

      // 1. Summary row
      supplierSummaryRowsHtml += `
        <tr>
          <td style="padding: 7px 8px; border: 1px solid #cbd5e1; font-weight: bold;">${s.name}</td>
          <td style="padding: 7px 8px; border: 1px solid #cbd5e1;">${s.materialType}</td>
          <td style="padding: 7px 8px; border: 1px solid #cbd5e1; color: #dc2626; font-family: monospace; text-align: center;">${formatCurrency(totalOnHim, currency)}</td>
          <td style="padding: 7px 8px; border: 1px solid #cbd5e1; color: #16a34a; font-family: monospace; text-align: center;">${formatCurrency(totalForHim, currency)}</td>
          <td style="padding: 7px 8px; border: 1px solid #cbd5e1; font-weight: bold; color: ${net >= 0 ? '#6d28d9' : '#b91c1c'}; font-family: monospace; text-align: center;">
            ${net === 0 ? 'خالص' : net > 0 ? `له (${formatCurrency(net, currency)})` : `عليه (${formatCurrency(Math.abs(net), currency)})`}
          </td>
        </tr>
      `;

      // 2. Detailed ledger table for this supplier
      let ledgerRowsHtml = '';
      const sortedLedgerForPrint = [...s.ledger].sort((a, b) => b.date.localeCompare(a.date));
      sortedLedgerForPrint.forEach(e => {
        const hasMaterials = Boolean(e.materialItems && e.materialItems.length > 0);
        const materialDetailsHtml = (hasMaterials && isDetailed)
          ? generateSupplierItemsDetailedTableHtml(e.materialItems!, currency, e.invoiceNumber, e.materialDiscount)
          : '';

        ledgerRowsHtml += `
          <tr>
            <td style="font-family: monospace; padding: 6px 8px; border: 1px solid #cbd5e1; width: 14%;">${formatDateArabic(e.date)}</td>
            <td style="font-weight: bold; padding: 6px 8px; border: 1px solid #cbd5e1; width: 38%;" class="col-statement">
              <div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 4px;">
                <span>${e.description}</span>
                ${e.invoiceNumber ? `<span style="font-family: monospace; font-size: 10px; font-weight: 800; background: #fff7ed; color: #c2410c; padding: 1.5px 6px; border-radius: 4px; border: 1px solid #fdba74;">فاتورة #${e.invoiceNumber}</span>` : ''}
              </div>
              ${hasMaterials ? `
                <div style="font-size: 9.5px; font-weight: normal; margin-top: 3px; color: ${isDetailed ? '#c2410c' : '#64748b'};">
                  ${isDetailed 
                    ? `📦 تفاصيل كشف المواد (${e.materialItems!.length} صنف) موضحة بالجدول أدناه 👇` 
                    : `📦 يتضمن كشف مواد (${e.materialItems!.length} صنف)`}
                </div>
              ` : ''}
            </td>
            <td style="color: #dc2626; font-family: monospace; padding: 6px 8px; border: 1px solid #cbd5e1; text-align: center; width: 17%;">${e.amountOnHim > 0 ? formatCurrency(e.amountOnHim, currency) : '-'}</td>
            <td style="color: #16a34a; font-family: monospace; padding: 6px 8px; border: 1px solid #cbd5e1; text-align: center; width: 17%;">${e.amountForHim > 0 ? formatCurrency(e.amountForHim, currency) : '-'}</td>
            <td style="font-size: 9.5px; color: #64748b; line-height: 1.35; padding: 6px 8px; border: 1px solid #cbd5e1; width: 14%;" class="col-notes">${e.notes || '-'}</td>
          </tr>
        `;

        if (hasMaterials && isDetailed && materialDetailsHtml) {
          ledgerRowsHtml += `
            <tr style="background-color: #fffdfa; break-inside: avoid; page-break-inside: avoid;">
              <td colspan="5" style="padding: 6px 12px 12px 12px; border: 1px solid #cbd5e1; border-top: 1px dashed #cbd5e1; background: #fffdfa;">
                ${materialDetailsHtml}
              </td>
            </tr>
          `;
        }
      });

      suppliersDetailedLedgersHtml += `
        <div style="margin-top: 14px; margin-bottom: 18px; border: 1px solid #cbd5e1; border-radius: 8px; overflow: hidden; break-inside: auto;">
          <div style="background-color: #4c1d95; color: #ffffff; padding: 8px 12px; display: flex; justify-content: space-between; align-items: center; break-after: avoid; page-break-after: avoid;">
            <div>
              <span style="font-weight: bold; font-size: 13.5px;">🚚 المورد: ${s.name}</span>
              <span style="font-size: 11.5px; color: #ddd6fe; margin-right: 8px;">(${s.materialType})</span>
            </div>
            <div style="font-size: 11.5px; font-weight: bold;">
              <span style="color: #f87171; margin-left: 8px;">دفعات مسددة له: ${formatCurrency(totalOnHim, currency)}</span> | 
              <span style="color: #4ade80; margin-left: 8px;">قيمة مواد: ${formatCurrency(totalForHim, currency)}</span> | 
              <span style="color: #c4b5fd;">الصافي: ${net >= 0 ? formatCurrency(net, currency) : `-${formatCurrency(Math.abs(net), currency)}`}</span>
            </div>
          </div>
          <table class="report-data-table" style="margin: 0; width: 100%; border-collapse: collapse; font-size: 11.5px;">
            <thead>
              <tr style="background-color: #f1f5f9; color: #1e293b; break-inside: avoid; page-break-inside: avoid;">
                <th style="padding: 6px 8px; border: 1px solid #cbd5e1; width: 14%;">التاريخ</th>
                <th style="padding: 6px 8px; border: 1px solid #cbd5e1; width: 38%;" class="col-statement">البيان / الفاتورة</th>
                <th style="padding: 6px 8px; border: 1px solid #cbd5e1; width: 17%;">عليه (دفعات مسددة له)</th>
                <th style="padding: 6px 8px; border: 1px solid #cbd5e1; width: 17%;">له (قيمة مواد)</th>
                <th style="padding: 6px 8px; border: 1px solid #cbd5e1; width: 14%;" class="col-notes">ملاحظات</th>
              </tr>
            </thead>
            <tbody>
              ${s.ledger.length === 0 ? '<tr><td colspan="5" style="text-align: center; color: #94a3b8; padding: 10px; border: 1px solid #cbd5e1;">لا توجد معاملات مسجلة لهذا المورد حالياً.</td></tr>' : ledgerRowsHtml}
            </tbody>
          </table>
        </div>
      `;
    });

    const grandNet = grandForHim - grandOnHim;

    // Materials chart
    const matColors = ['#7c3aed', '#0284c7', '#059669', '#d97706', '#ec4899', '#f97316', '#14b8a6'];
    const sortedMaterials = Object.entries(materialTypeCounts).sort((a, b) => b[1].count - a[1].count);
    const matChartData = sortedMaterials.map(([name, data], idx) => ({
      label: name,
      value: data.count,
      color: matColors[idx % matColors.length],
      formattedValue: `${data.count} مورد`,
      subText: data.totalPurchases > 0 ? formatCurrency(data.totalPurchases, currency) : undefined
    }));

    const matDonutChartHtml = generateSvgDonutChart({
      data: matChartData,
      size: 140,
      centerTitle: `${suppliers.length}`,
      centerSubtitle: 'إجمالي الموردين',
      showLegend: true
    });

    const metricCardsHtml = generateMetricCardsGrid([
      {
        title: 'إجمالي عدد الموردين المعتمدين',
        value: `${suppliers.length} مورد`,
        badge: 'سجل الموردين',
        bgColor: '#f5f3ff',
        borderColor: '#ddd6fe',
        textColor: '#6d28d9'
      },
      {
        title: 'إجمالي قيمة توريدات المواد (له)',
        value: formatCurrency(grandForHim, currency),
        badge: 'فواتير ومواد',
        bgColor: '#f0fdf4',
        borderColor: '#bbf7d0',
        textColor: '#15803d'
      },
      {
        title: 'إجمالي الدفعات المسددة (عليه)',
        value: formatCurrency(grandOnHim, currency),
        badge: 'سداد نقدي وبنكي',
        bgColor: '#fef2f2',
        borderColor: '#fecaca',
        textColor: '#b91c1c'
      },
      {
        title: 'صافي الرصيد المستحق',
        value: formatCurrency(Math.abs(grandNet), currency),
        badge: grandNet >= 0 ? 'مستحق للموردين' : 'دفعات فائضة',
        bgColor: grandNet >= 0 ? '#f5f3ff' : '#fffbeb',
        borderColor: grandNet >= 0 ? '#ddd6fe' : '#fde68a',
        textColor: grandNet >= 0 ? '#6d28d9' : '#b45309'
      }
    ], 4);

    const balanceComparisonHtml = generateSvgBalanceComparison({
      forHim: grandForHim,
      onHim: grandOnHim,
      forHimLabel: 'إجمالي قيمة المواد والتوريدات (له)',
      onHimLabel: 'إجمالي الدفعات المسددة للموردين (عليه)',
      forHimFormatted: formatCurrency(grandForHim, currency),
      onHimFormatted: formatCurrency(grandOnHim, currency),
      netFormatted: grandNet >= 0 ? `له (${formatCurrency(grandNet, currency)})` : `عليه (${formatCurrency(Math.abs(grandNet), currency)})`,
      isPositive: grandNet >= 0
    });

    const materialCategoryAnalyticsHtml = generateMaterialCategoryAnalyticsHtml({
      suppliers,
      currency,
      panelTitle: 'لوحة التحليلات والرسم البياني لإجمالي تكاليف فئات المواد والأصناف الموردة',
      panelSubtitle: 'ملخص تحليلي ورسم بياني لإجمالي تكاليف كل فئة من الفئات المدخلة من كافة الموردين بالمشروع'
    });

    const htmlContent = `
      <div style="direction: rtl; font-family: sans-serif; padding: 10px;">
        
        <!-- Header -->
        <div style="border-bottom: 2px solid #7c3aed; padding-bottom: 12px; margin-bottom: 16px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 8px;">
          <div>
            <div style="display: flex; align-items: center; gap: 8px; flex-wrap: wrap;">
              <h1 style="margin: 0; color: #1e1b4b; font-size: 19px;">📊 التقرير المالي العام للموردين وتوريدات المواد</h1>
              <span style="background-color: ${isDetailed ? '#f5f3ff' : '#f0f9ff'}; color: ${isDetailed ? '#6d28d9' : '#0369a1'}; border: 1px solid ${isDetailed ? '#ddd6fe' : '#bae6fd'}; padding: 2px 8px; border-radius: 6px; font-size: 10.5px; font-weight: bold;">
                ${isDetailed ? '✨ تقرير تفصيلي شامل كشف المواد' : '📄 تقرير مالي مختصر'}
              </span>
            </div>
            <p style="margin: 4px 0 0 0; color: #64748b; font-size: 12px;">ورلد أوف إيليتس للتجارة والمقاولات</p>
          </div>
          <div style="text-align: left; font-size: 11.5px; color: #64748b;">
            تاريخ استخراج التقرير: ${new Date().toLocaleDateString('ar-EG-u-nu-latn')}
          </div>
        </div>

        <!-- 📊 PAGE 1: EXECUTIVE ANALYTICS DASHBOARD -->
        <div style="margin-bottom: 20px; page-break-inside: avoid;">
          
          <div style="background: linear-gradient(135deg, #2e1065 0%, #4c1d95 100%); color: #ffffff; padding: 10px 14px; border-radius: 8px; margin-bottom: 12px; display: flex; justify-content: space-between; align-items: center; border-right: 4px solid #7c3aed;">
            <div>
              <h2 style="margin: 0; font-size: 14px; font-weight: 800; color: #ffffff;">لوحة التحليلات والمؤشرات البيانية لحسابات الموردين</h2>
              <div style="font-size: 9.5px; color: #ddd6fe; margin-top: 2px;">ملخص توريدات المواد، الدفعات المسددة، وتوزيع الموردين حسب نوع المادة</div>
            </div>
            <span style="font-size: 10.5px; background-color: #7c3aed; color: #ffffff; padding: 3px 8px; border-radius: 10px; font-weight: bold;">العملة: ${currency}</span>
          </div>

          <!-- Metric Cards Grid -->
          ${metricCardsHtml}

          <!-- Balance Comparison Gauge -->
          ${balanceComparisonHtml}

          <!-- Donut chart for Material Types -->
          <div style="background-color: #ffffff; border: 1px solid #cbd5e1; border-radius: 8px; padding: 10px; margin-bottom: 12px;">
            <div style="font-size: 11px; font-weight: bold; color: #1e1b4b; border-bottom: 1px solid #e2e8f0; padding-bottom: 4px; margin-bottom: 8px;">
              🍩 توزيع الموردين حسب نوع وتصنيف المواد
            </div>
            ${matDonutChartHtml}
          </div>

        </div>

        <!-- PAGE BREAK AFTER DASHBOARD -->
        <div style="page-break-before: always;"></div>

        <!-- SECTION 1: OVERALL SUMMARY TABLE -->
        <div style="margin-bottom: 25px;">
          <h3 style="font-size: 14px; font-weight: bold; color: #0f172a; border-bottom: 2px solid #6d28d9; padding-bottom: 6px; margin-bottom: 12px;">
            أولاً: جدول ملخص حسابات وأرصدة جميع الموردين
          </h3>
          <table style="width: 100%; border-collapse: collapse; font-size: 11.5px;">
            <thead>
              <tr style="background-color: #4c1d95; color: white;">
                <th style="padding: 8px; border: 1px solid #3b0764; text-align: right;">اسم المورد</th>
                <th style="padding: 8px; border: 1px solid #3b0764; text-align: right;">نوع المواد</th>
                <th style="padding: 8px; border: 1px solid #3b0764; text-align: center;">إجمالي المسدد له (عليه)</th>
                <th style="padding: 8px; border: 1px solid #3b0764; text-align: center;">إجمالي قيمة المواد (له)</th>
                <th style="padding: 8px; border: 1px solid #3b0764; text-align: center;">صافي رصيد المورد</th>
              </tr>
            </thead>
            <tbody>
              ${suppliers.length === 0 ? '<tr><td colspan="5" style="text-align: center; color: #94a3b8; padding: 12px;">لا يوجد موردين مضافين حالياً.</td></tr>' : supplierSummaryRowsHtml}
            </tbody>
            <tfoot>
              <tr style="background-color: #f5f3ff; font-weight: bold;">
                <td colspan="2" style="padding: 8px; border: 1px solid #cbd5e1; text-align: left;">المجموع الكلي:</td>
                <td style="padding: 8px; border: 1px solid #cbd5e1; color: #dc2626; text-align: center;">${formatCurrency(grandOnHim, currency)}</td>
                <td style="padding: 8px; border: 1px solid #cbd5e1; color: #16a34a; text-align: center;">${formatCurrency(grandForHim, currency)}</td>
                <td style="padding: 8px; border: 1px solid #cbd5e1; color: ${grandNet >= 0 ? '#6d28d9' : '#b91c1c'}; text-align: center;">
                  ${grandNet >= 0 ? `له: ${formatCurrency(grandNet, currency)}` : `عليه: ${formatCurrency(Math.abs(grandNet), currency)}`}
                </td>
              </tr>
            </tfoot>
          </table>
        </div>

        <!-- SECTION 2: MATERIAL CATEGORY ANALYTICS DASHBOARD -->
        <div style="margin-bottom: 25px;">
          <h3 style="font-size: 14px; font-weight: bold; color: #0f172a; border-bottom: 2px solid #6d28d9; padding-bottom: 6px; margin-top: 20px; margin-bottom: 12px; break-after: avoid; page-break-after: avoid; break-before: auto;">
            ثانياً: لوحة التحليلات والرسم البياني لإجمالي تكاليف فئات المواد والأصناف الموردة
          </h3>
          ${materialCategoryAnalyticsHtml}
        </div>

        <!-- SECTION 3: DETAILED LEDGER TABLES FOR ALL SUPPLIERS -->
        <div style="margin-bottom: 25px;">
          <h3 style="font-size: 14px; font-weight: bold; color: #0f172a; border-bottom: 2px solid #6d28d9; padding-bottom: 6px; margin-top: 20px; margin-bottom: 12px; break-after: avoid; page-break-after: avoid; break-before: auto;">
            ${isDetailed ? 'ثالثاً: كشوفات تفصيلية بكافة الحركات والعمليات المالية وكشوفات المواد الموردة لكل مورد' : 'ثالثاً: كشوفات الحسابات والعمليات المالية لكل مورد (مختصر)'}
          </h3>
          ${suppliers.length === 0 ? '<p style="text-align: center; color: #94a3b8;">لا توجد بيانات تفصيلية.</p>' : suppliersDetailedLedgersHtml}
        </div>
      </div>
    `;

    printPDF(`التقرير_المالي_العام_للموردين_${isDetailed ? 'تفصيلي' : 'مختصر'}`, htmlContent);
  };

  // Filter suppliers based on query
  const filteredSuppliers = suppliers.filter(s => 
    s.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    s.materialType.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (s.phoneNumbers && s.phoneNumbers.some(p => p.includes(searchQuery)))
  );

  // Sorted suppliers list (Default: Oldest to Newest by earliest transaction date or name)
  const sortedSuppliers = [...filteredSuppliers].sort((a, b) => {
    const earliestA = a.ledger.length > 0 ? [...a.ledger].sort((x, y) => x.date.localeCompare(y.date))[0].date : '';
    const earliestB = b.ledger.length > 0 ? [...b.ledger].sort((x, y) => x.date.localeCompare(y.date))[0].date : '';
    if (earliestA && earliestB) {
      const cmp = earliestA.localeCompare(earliestB);
      return supplierSortOrder === 'asc' ? cmp : -cmp;
    }
    const nameCmp = a.name.localeCompare(b.name, 'ar');
    return supplierSortOrder === 'asc' ? nameCmp : -nameCmp;
  });

  // Excel Column Filter State for Supplier Ledger
  const [supplierLedgerColumnFilters, setSupplierLedgerColumnFilters] = useState<Record<string, ActiveColumnFilter>>({});
  const [supplierLedgerColumnSort, setSupplierLedgerColumnSort] = useState<ColumnSortState | null>(null);

  const handleSupplierLedgerFilterChange = (key: string, filter: ActiveColumnFilter | null) => {
    setSupplierLedgerColumnFilters(prev => {
      const next = { ...prev };
      if (!filter) {
        delete next[key];
      } else {
        next[key] = filter;
      }
      return next;
    });
  };

  const handleSupplierLedgerSortChange = (sort: ColumnSortState | null) => {
    setSupplierLedgerColumnSort(sort);
  };

  const handleClearSupplierLedgerFilters = () => {
    setSupplierLedgerColumnFilters({});
    setSupplierLedgerColumnSort(null);
  };

  const supplierLedgerColumnConfigs: Record<string, ColumnFilterConfig<LedgerEntry>> = {
    date: {
      key: 'date',
      title: 'التاريخ',
      sortType: 'date',
      getValue: (e) => e.date,
      getDisplayValue: (val) => formatDateArabic(String(val))
    },
    description: {
      key: 'description',
      title: 'البيان',
      sortType: 'string',
      getValue: (e) => cleanLedgerDescription(e.description)
    },
    amountOnHim: {
      key: 'amountOnHim',
      title: 'مبلغ عليه (مسدد له)',
      sortType: 'number',
      getValue: (e) => e.amountOnHim,
      getDisplayValue: (val) => Number(val) > 0 ? formatCurrency(Number(val), currency || 'YER') : '-'
    },
    amountForHim: {
      key: 'amountForHim',
      title: 'مبلغ له (قيمة مواد)',
      sortType: 'number',
      getValue: (e) => e.amountForHim,
      getDisplayValue: (val) => Number(val) > 0 ? formatCurrency(Number(val), currency || 'YER') : '-'
    },
    notes: {
      key: 'notes',
      title: 'ملاحظات',
      sortType: 'string',
      getValue: (e) => e.notes || ''
    },
    materialItems: {
      key: 'materialItems',
      title: 'كشف المواد',
      sortType: 'string',
      getValue: (e) => (e.materialItems && e.materialItems.length > 0) ? `${e.materialItems.length} أصناف` : '(فارغ)',
      getDisplayValue: (val) => String(val)
    }
  };

  // Base filtered supplier ledger entries (matching top search, date, type filters)
  const baseFilteredLedger = useMemo(() => {
    if (!activeSupplier) return [];
    return activeSupplier.ledger.filter(entry => {
      if (ledgerSearchTerm.trim()) {
        const term = ledgerSearchTerm.trim().toLowerCase();
        const matchDesc = entry.description.toLowerCase().includes(term);
        const matchNotes = (entry.notes || '').toLowerCase().includes(term);
        if (!matchDesc && !matchNotes) return false;
      }
      if (ledgerStartDate && entry.date < ledgerStartDate) return false;
      if (ledgerEndDate && entry.date > ledgerEndDate) return false;
      if (ledgerTypeFilter === 'onHim' && !(entry.amountOnHim > 0)) return false;
      if (ledgerTypeFilter === 'forHim' && !(entry.amountForHim > 0)) return false;
      return true;
    });
  }, [activeSupplier, ledgerSearchTerm, ledgerStartDate, ledgerEndDate, ledgerTypeFilter]);

  // Filtered & Sorted active supplier ledger entries (cascading with column filters)
  const filteredLedger = useMemo(() => {
    return baseFilteredLedger.filter(entry => {
      // Apply column filters
      for (const [colKey, filter] of Object.entries(supplierLedgerColumnFilters) as [string, ActiveColumnFilter][]) {
        const config = supplierLedgerColumnConfigs[colKey];
        if (!config || !filter || !filter.selectedValues) continue;

        const allowedSet = new Set(filter.selectedValues);
        const raw = config.getValue(entry);

        if (Array.isArray(raw)) {
          if (raw.length === 0) {
            if (!allowedSet.has('(فارغ)')) return false;
          } else {
            const hasAny = raw.some(val => {
              const strVal = val !== null && val !== undefined && String(val).trim() !== '' ? String(val) : '(فارغ)';
              return allowedSet.has(strVal);
            });
            if (!hasAny) return false;
          }
        } else {
          const strVal = raw !== null && raw !== undefined && String(raw).trim() !== '' ? String(raw) : '(فارغ)';
          if (!allowedSet.has(strVal)) return false;
        }
      }

      return true;
    });
  }, [baseFilteredLedger, supplierLedgerColumnFilters, supplierLedgerColumnConfigs]);

  const sortedLedger = [...filteredLedger].sort((a, b) => {
    if (supplierLedgerColumnSort) {
      const config = supplierLedgerColumnConfigs[supplierLedgerColumnSort.key];
      if (config) {
        const rawA = config.getValue(a);
        const rawB = config.getValue(b);

        if (rawA === rawB) return 0;
        if (rawA === null || rawA === undefined || rawA === '') return 1;
        if (rawB === null || rawB === undefined || rawB === '') return -1;

        let comp = 0;
        if (config.sortType === 'number') {
          const numA = typeof rawA === 'number' ? rawA : parseFloat(String(rawA)) || 0;
          const numB = typeof rawB === 'number' ? rawB : parseFloat(String(rawB)) || 0;
          comp = numA - numB;
        } else if (config.sortType === 'date') {
          comp = String(rawA).localeCompare(String(rawB));
        } else {
          const strA = config.getDisplayValue ? config.getDisplayValue(String(rawA)) : String(rawA);
          const strB = config.getDisplayValue ? config.getDisplayValue(String(rawB)) : String(rawB);
          comp = strA.localeCompare(strB, 'ar');
        }

        return supplierLedgerColumnSort.direction === 'asc' ? comp : -comp;
      }
    }

    if (ledgerSortOption === 'date-asc') {
      return a.date.localeCompare(b.date);
    } else if (ledgerSortOption === 'desc-alpha') {
      return a.description.localeCompare(b.description, 'ar');
    } else if (ledgerSortOption === 'amountOnHim-desc') {
      return b.amountOnHim - a.amountOnHim;
    } else if (ledgerSortOption === 'amountForHim-desc') {
      return b.amountForHim - a.amountForHim;
    }
    return b.date.localeCompare(a.date);
  });

  const hasActiveSupplierLedgerColumnFilters = Object.keys(supplierLedgerColumnFilters).length > 0 || supplierLedgerColumnSort !== null;

  const isLedgerFilterActive = Boolean(
    ledgerSearchTerm || ledgerStartDate || ledgerEndDate || ledgerTypeFilter !== 'all' || ledgerSortOption !== 'date-desc' || hasActiveSupplierLedgerColumnFilters
  );

  // Calculate sum of filtered ledger entries grouped by currency
  const ledgerTotalsByCurrency = filteredLedger.reduce((acc, curr) => {
    const code = curr.currency || currency || 'YER';
    if (!acc[code]) {
      acc[code] = { onHim: 0, forHim: 0 };
    }
    acc[code].onHim += curr.amountOnHim || 0;
    acc[code].forHim += curr.amountForHim || 0;
    return acc;
  }, {} as Record<string, { onHim: number; forHim: number }>);

  return (
    <div className="space-y-4 animate-fade-in" id="suppliers-section">
      
      {/* Detail vs List views */}
      {activeSupplier ? (
        
        /* -------------------------------- DETAIL ACCOUNT VIEW -------------------------------- */
        <div className="space-y-4 animate-fade-in" id="supplier-details-pane">
          
          {/* Detail Header / Nav back */}
          <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-100 shadow-xs space-y-3">
            <div className="flex items-start justify-between gap-4 w-full">
              <div className="flex-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <h2 className="text-xl sm:text-2xl font-bold text-slate-800">{activeSupplier.name}</h2>
                  <span className="text-xs bg-amber-50 text-amber-700 border border-amber-100 px-2.5 py-0.5 rounded-full font-bold">{activeSupplier.materialType}</span>
                  <AttributionBadge createdBy={activeSupplier.createdBy} updatedBy={activeSupplier.updatedBy} />
                  {sharedRole !== 'read' && (
                    <button 
                      type="button"
                      id="edit-supplier-header-btn"
                      onClick={() => setEditingSupplier(activeSupplier)}
                      className="inline-flex items-center gap-1.5 px-3 py-1 bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200/90 rounded-lg text-xs font-bold transition-all shadow-2xs hover:shadow-xs cursor-pointer select-none active:scale-95"
                      title="تعديل بيانات المورد"
                    >
                      <Pencil size={13} className="text-amber-600 shrink-0" />
                      <span>تعديل</span>
                    </button>
                  )}
                </div>
                <p className="text-slate-500 text-xs sm:text-sm mt-1">كشف المعاملات وتفاصيل التوريد والتسديد المتبادل.</p>
                <PhoneNumbersDisplay phoneNumbers={activeSupplier.phoneNumbers} className="mt-2" />
                {activeSupplier.notes && (
                  <p className="text-xs text-slate-600 bg-slate-50 border border-slate-100 rounded-lg p-2 mt-2 max-w-xl">
                    <span className="font-bold text-slate-700">ملاحظات: </span>
                    {activeSupplier.notes}
                  </p>
                )}
              </div>

              <div className="flex flex-col items-end gap-1.5 shrink-0">
                {setActiveTab && (
                  <button 
                    onClick={() => setActiveTab('dashboard')}
                    className="h-8 px-3 bg-white hover:bg-slate-50 text-slate-800 font-bold text-[11px] border border-slate-200/90 rounded-lg shadow-2xs hover:shadow-xs transition-all duration-200 flex items-center gap-1.5 cursor-pointer shrink-0 w-full justify-center"
                    title="الرجوع للرئيسية"
                  >
                    <ArrowLeft size={14} className="text-slate-700 shrink-0" />
                    <span>الرجوع للرئيسية</span>
                  </button>
                )}

                <button 
                  onClick={() => { setSelectedSupplierId(null); setLedgerError(''); }}
                  className="h-8 px-3 bg-white hover:bg-slate-50 text-slate-800 font-bold text-[11px] border border-slate-200/90 rounded-lg shadow-2xs hover:shadow-xs transition-all duration-200 flex items-center gap-1.5 cursor-pointer shrink-0 w-full justify-center"
                  title="الرجوع لقائمة الموردين"
                >
                  <ArrowLeft size={14} className="text-slate-700 shrink-0" />
                  <span>الرجوع لقائمة الموردين</span>
                </button>

                <button
                  type="button"
                  onClick={() => setPrintModalState({ isOpen: true, type: 'single', supplier: activeSupplier })}
                  className="h-8 px-3 bg-purple-600 hover:bg-purple-700 active:scale-[0.98] text-white font-bold text-[11px] rounded-lg shadow-2xs hover:shadow-xs transition-all duration-200 flex items-center gap-1.5 cursor-pointer shrink-0 w-full justify-center"
                  title="طباعة وتصدير كشف حساب المورد (مختصر أو تفصيلي)"
                >
                  <Printer size={13} className="text-purple-200 stroke-[2.2]" />
                  <span>طباعة كشف الحساب</span>
                </button>

                <OptionsMenu 
                  onExportExcel={() => handleExportLedgerCSV(activeSupplier)}
                  onExportPDF={() => setPrintModalState({ isOpen: true, type: 'single', supplier: activeSupplier })}
                  onImportExcel={sharedRole !== 'read' ? handleLedgerExcelImport : undefined}
                  shareTitle={`كشف حساب المورد: ${activeSupplier.name}`}
                  shareText={((s) => {
                    const totalOnHim = s.ledger.reduce((sum, e) => sum + e.amountOnHim, 0);
                    const totalForHim = s.ledger.reduce((sum, e) => sum + e.amountForHim, 0);
                    const net = totalForHim - totalOnHim;
                    let netText = '';
                    if (net === 0) netText = 'خالص الطرفين';
                    else if (net > 0) netText = `له (قيمة توريدات مستحقة بذمتنا): ${formatCurrency(net, currency)}`;
                    else netText = `عليه (مسدد له زيادة): ${formatCurrency(Math.abs(net), currency)}`;

                    const lastEntries = s.ledger.slice(-10);
                    const entriesText = lastEntries.length > 0 
                      ? '\n📋 آخر العمليات المقيدة:\n' + lastEntries.map(e => {
                          const entryAmt = e.amountForHim > 0 
                            ? `له (مواد): ${formatCurrency(e.amountForHim, e.currency || currency)}` 
                            : `عليه (مسدد): ${formatCurrency(e.amountOnHim, e.currency || currency)}`;
                          return `- ${e.date} | ${e.description} ⟸ ${entryAmt}`;
                        }).join('\n')
                      : '\n(لا توجد حركات مالية مقيدة بعد)';

                    return `🚚 كشف حساب المورد: ${s.name}\n📦 نوع المواد: ${s.materialType}\n\n💰 الخلاصة المالية للمورد:\n- إجمالي قيمة التوريد (له): ${formatCurrency(totalForHim, currency)}\n- إجمالي المبالغ المسددة (عليه): ${formatCurrency(totalOnHim, currency)}\n- صافي الحساب الحالي: ${netText}\n${entriesText}\n\n*تم استخراجه من تطبيق المدير المالي*`;
                  })(activeSupplier)}
                />
              </div>
            </div>

            {/* Actions for active supplier */}
            {sharedRole !== 'read' && (
              <div className="flex items-center gap-2.5 flex-wrap w-full pt-1">
                <button 
                  type="button"
                  onClick={() => setEditingSupplier(activeSupplier)}
                  className="h-9 px-3.5 bg-white hover:bg-amber-50 text-amber-800 font-bold text-xs border border-slate-200/90 rounded-xl shadow-xs hover:shadow-md transition-all flex items-center gap-2 cursor-pointer shrink-0"
                  title="تعديل بيانات المورد"
                >
                  <Pencil size={15} className="text-amber-600 shrink-0" />
                  <span>تعديل</span>
                </button>
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            
            {/* Column 1: Metadata Summary & Transaction Entry Form */}
            <div className="space-y-6">
              
              {/* Balances Card */}
              <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-xs space-y-4">
                <h3 className="font-bold text-slate-800 text-sm flex items-center gap-2 pb-2 border-b border-slate-50">
                  <Info size={16} className="text-amber-500" />
                  حالة الحساب الجاري للمورد
                </h3>

                {/* Ledger balances summary grouped by currency */}
                <div className="space-y-3 pt-2 border-t border-slate-50">
                  {['YER', 'SAR', 'USD'].map(cur => {
                    const totalOnHim = activeSupplier.ledger.filter(e => (e.currency || 'YER') === cur).reduce((sum, e) => sum + e.amountOnHim, 0);
                    const totalForHim = activeSupplier.ledger.filter(e => (e.currency || 'YER') === cur).reduce((sum, e) => sum + e.amountForHim, 0);
                    const balance = totalForHim - totalOnHim;
                    
                    if (totalOnHim === 0 && totalForHim === 0) return null;
                    
                    return (
                      <div key={cur} className="bg-slate-50 p-2.5 rounded-xl border border-slate-100 space-y-1.5 font-mono">
                        <div className="flex justify-between items-center text-[11px] font-bold text-slate-700">
                          <span>العملة:</span>
                          <span className="bg-slate-200 text-slate-800 px-1.5 py-0.5 rounded-md text-[10px]">{cur}</span>
                        </div>
                        <div className="flex justify-between text-[10px] text-slate-500">
                          <span>عليه (مسدد له):</span>
                          <span className="font-semibold text-rose-600">{formatCurrency(totalOnHim, cur)}</span>
                        </div>
                        <div className="flex justify-between text-[10px] text-slate-500">
                          <span>له (توريد مواد):</span>
                          <span className="font-semibold text-emerald-600">{formatCurrency(totalForHim, cur)}</span>
                        </div>
                        <div className="flex justify-between text-[11px] font-bold border-t border-slate-200/50 pt-1.5 mt-1">
                          <span>صافي الرصيد له:</span>
                          <span className={balance < 0 ? 'text-rose-600' : balance > 0 ? 'text-purple-600' : 'text-slate-400'}>
                            {balance === 0 ? 'خالص' : balance > 0 ? `له: ${formatCurrency(balance, cur)}` : `عليه: ${formatCurrency(Math.abs(balance), cur)}`}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                  {activeSupplier.ledger.length === 0 && (
                    <p className="text-xs text-slate-400 text-center py-2 animate-pulse">لا توجد حركات توريد مسجلة بعد</p>
                  )}
                </div>
              </div>

              {/* Entry Form */}
              <div className="bg-white p-3.5 sm:p-4 rounded-2xl border border-emerald-100 shadow-xs transition-all duration-300">
                <button
                  type="button"
                  onClick={() => setShowAddLedgerForm(!showAddLedgerForm)}
                  className="w-full bg-gradient-to-r from-emerald-600 via-emerald-600 to-emerald-700 hover:from-emerald-700 hover:to-emerald-800 text-white font-extrabold text-sm sm:text-base p-3.5 rounded-xl shadow-md shadow-emerald-600/20 flex items-center justify-between transition-all cursor-pointer select-none active:scale-[0.99] border border-emerald-500/50 text-right"
                >
                  <div className="flex items-center gap-2.5">
                    <div className="p-1.5 bg-white/20 rounded-lg text-white shrink-0">
                      <PlusCircle size={18} />
                    </div>
                    <span className="font-extrabold tracking-wide">إضافة حركة مالية جديدة للكشف</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-950 bg-white/90 hover:bg-white px-3 py-1.5 rounded-lg transition-colors shadow-xs shrink-0">
                    <span>{showAddLedgerForm ? 'طي النموذج ▲' : 'فتح النموذج ▼'}</span>
                  </div>
                </button>

                {showAddLedgerForm && (
                  <form onSubmit={handleAddLedgerSubmit} className="space-y-3.5 mt-4 pt-3.5 border-t border-slate-100 animate-fade-in">
                    
                    {/* Date */}
                    <div className="space-y-1">
                      <label className="text-[11px] font-bold text-slate-500">التاريخ</label>
                      <input 
                        type="date"
                        value={ledgerDate}
                        onChange={(e) => setLedgerDate(e.target.value)}
                        className="w-full h-[42px] px-3 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 text-xs focus:outline-hidden focus:border-amber-500"
                        required
                      />
                    </div>

                    {/* Amounts Row & Currency Dropdown */}
                    <div className="grid grid-cols-3 gap-2">
                      <div className="space-y-1 col-span-1">
                        <label className="text-[10px] font-bold text-slate-500 block text-rose-600 truncate">عليه (مسدد)</label>
                        <div className="flex gap-1 items-center">
                          <input 
                            type="number"
                            placeholder="0"
                            value={ledgerAmountOnHim}
                            onChange={(e) => setLedgerAmountOnHim(e.target.value)}
                            className="w-full h-[42px] px-3 bg-rose-50/20 border border-slate-200 rounded-lg text-slate-700 text-xs focus:outline-hidden focus:border-rose-500 min-w-0"
                          />
                          <Calculator onApply={(val) => setLedgerAmountOnHim(String(val))} buttonTitle="حسابة مبلغ عليه" />
                        </div>
                        <AmountInWords amount={ledgerAmountOnHim} currency={ledgerCurrency} />
                      </div>
                      <div className="space-y-1 col-span-1">
                        <label className="text-[10px] font-bold text-slate-500 block text-emerald-600 truncate">له (توريد مواد)</label>
                        <div className="flex gap-1 items-center">
                          <input 
                            type="number"
                            placeholder="0"
                            value={ledgerAmountForHim}
                            onChange={(e) => setLedgerAmountForHim(e.target.value)}
                            className="w-full h-[42px] px-3 bg-emerald-50/20 border border-slate-200 rounded-lg text-slate-700 text-xs focus:outline-hidden focus:border-emerald-500 min-w-0"
                          />
                          <Calculator onApply={(val) => setLedgerAmountForHim(String(val))} buttonTitle="حسابة مبلغ له" />
                        </div>
                        <AmountInWords amount={ledgerAmountForHim} currency={ledgerCurrency} />
                      </div>
                      <div className="space-y-1 col-span-1">
                        <label className="text-[10px] font-bold text-slate-500 block truncate">العملة</label>
                        <select
                          value={ledgerCurrency}
                          onChange={(e) => setLedgerCurrency(e.target.value)}
                          className="w-full h-[42px] px-3 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 text-xs focus:outline-hidden focus:border-amber-500 cursor-pointer"
                        >
                          <option value="YER">YER</option>
                          <option value="SAR">SAR</option>
                          <option value="USD">USD</option>
                        </select>
                      </div>
                    </div>

                    {/* Statement */}
                    <div className="space-y-1">
                      <label className="text-[11px] font-bold text-slate-500">البيان (تفاصيل التوريد أو الدفعة)</label>
                      <input 
                        type="text"
                        placeholder="مثال: توريد 20 طن رمل / دفعة نقدية وصل 3"
                        value={ledgerDescription}
                        onChange={(e) => setLedgerDescription(e.target.value)}
                        className="w-full h-[42px] px-3 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 text-xs focus:outline-hidden focus:border-amber-500"
                        required
                      />
                    </div>

                    {/* Material & Invoice Sheet Button directly after Statement */}
                    <div className="pt-0.5 space-y-1">
                      <button
                        type="button"
                        onClick={() => setIsAddMaterialModalOpen(true)}
                        className={`w-full min-h-[42px] py-1.5 px-3 rounded-lg border text-xs font-bold transition-all flex items-center justify-between gap-2 cursor-pointer ${
                          pendingMaterialItems.length > 0 || pendingInvoiceNumber || pendingInvoiceImage
                            ? 'bg-amber-50 border-amber-300 text-amber-900 hover:bg-amber-100/80 shadow-2xs'
                            : 'bg-slate-50 hover:bg-slate-100 border-slate-200 text-slate-700 hover:border-slate-300'
                        }`}
                        title="إرفاق أو تعديل جدول كميات وأسعار الأصناف ورقم وصورة الفاتورة لهذه الحركة"
                      >
                        <div className="flex items-center gap-2 truncate">
                          <Package size={16} className={pendingMaterialItems.length > 0 || pendingInvoiceNumber || pendingInvoiceImage ? 'text-amber-600 shrink-0' : 'text-slate-400 shrink-0'} />
                          <div className="flex items-center gap-1.5 truncate">
                            <span className="truncate">
                              {pendingMaterialItems.length > 0
                                ? `كشف المواد المرفق (${pendingMaterialItems.length} أصناف)`
                                : 'كشف المواد والفاتورة'}
                            </span>
                            {pendingInvoiceNumber && (
                              <span className="text-[10px] bg-amber-200/90 text-amber-950 px-1.5 py-0.5 rounded font-mono font-bold shrink-0">
                                #{pendingInvoiceNumber}
                              </span>
                            )}
                            {pendingInvoiceImage && (
                              <span className="text-[10px] bg-sky-100 text-sky-800 px-1.5 py-0.5 rounded font-bold shrink-0 flex items-center gap-0.5">
                                📷 صورة
                              </span>
                            )}
                          </div>
                        </div>
                        {pendingMaterialItems.length > 0 ? (
                          <div className="flex items-center gap-1 shrink-0">
                            {pendingMaterialDiscount !== undefined && pendingMaterialDiscount > 0 && (
                              <span className="text-[10px] font-bold text-rose-700 bg-rose-100/90 px-1.5 py-0.5 rounded font-mono">
                                خصم: -{formatCurrency(pendingMaterialDiscount, ledgerCurrency)}
                              </span>
                            )}
                            <span className="text-[11px] font-extrabold text-amber-800 bg-amber-200/80 px-2 py-0.5 rounded-md font-mono">
                              {formatCurrency(Math.max(0, pendingMaterialItems.reduce((s, i) => s + i.total, 0) - (pendingMaterialDiscount || 0)), ledgerCurrency)}
                            </span>
                          </div>
                        ) : (
                          <span className="text-[10px] text-slate-400 font-medium shrink-0">
                            + كشف مواد وفاتورة
                          </span>
                        )}
                      </button>
                    </div>

                    {/* Notes */}
                    <div className="space-y-1">
                      <label className="text-[11px] font-bold text-slate-500">ملاحظات</label>
                      <textarea 
                        placeholder="أي ملاحظات تفصيلية..."
                        value={ledgerNotes}
                        onChange={(e) => setLedgerNotes(e.target.value)}
                        rows={2}
                        className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 text-xs focus:outline-hidden focus:border-amber-500 resize-none"
                      />
                    </div>

                    {ledgerError && (
                      <p className="text-[11px] text-rose-600 font-semibold bg-rose-50 p-2 rounded-lg">{ledgerError}</p>
                    )}

                    <div className="flex gap-2">
                      <button 
                        type="submit"
                        className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs py-2.5 px-4 rounded-xl shadow-md shadow-emerald-600/20 transition-colors flex items-center justify-center gap-1.5 cursor-pointer active:scale-98"
                      >
                        <PlusCircle size={15} />
                        حفظ في كشف حساب المورد
                      </button>
                      <button 
                        type="button"
                        onClick={handleResetAddLedgerForm}
                        className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold text-xs rounded-lg transition-colors flex items-center justify-center gap-1 cursor-pointer"
                        title="إلغاء وتنظيف الحقول"
                      >
                        <RotateCcw size={13} />
                        <span>إلغاء / تنظيف</span>
                      </button>
                    </div>

                  </form>
                )}
              </div>

            </div>

            {/* Column 2 & 3: Ledger log table */}
            <div className="lg:col-span-2 space-y-3">
              {/* Ledger Filters Card */}
              <div className="bg-white p-3.5 sm:p-4 rounded-2xl border border-slate-100 shadow-xs transition-all" id="supplier-ledger-filters">
                <button
                  type="button"
                  onClick={() => setIsLedgerFiltersOpen(!isLedgerFiltersOpen)}
                  className="w-full flex items-center justify-between text-right font-bold text-slate-700 text-xs sm:text-sm hover:text-slate-900 cursor-pointer select-none"
                >
                  <div className="flex items-center gap-2">
                    <Filter size={16} className="text-purple-600" />
                    <span>أدوات البحث والتصفية (سجل الكشوفات والحركات التفصيلي)</span>
                    {isLedgerFilterActive && (
                      <span className="text-[10px] font-extrabold text-purple-700 bg-purple-50 px-2 py-0.5 rounded-full border border-purple-200">
                        فلتر نشط ({sortedLedger.length} حركات)
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-1.5 text-slate-400 text-xs font-normal">
                    <span className="text-slate-400 text-xs hidden sm:inline">{isLedgerFiltersOpen ? 'إخفاء' : 'عرض الخيارات'}</span>
                    {isLedgerFiltersOpen ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
                  </div>
                </button>
                
                {isLedgerFiltersOpen && (
                  <div className="pt-3 space-y-3 border-t border-slate-100 mt-3 animate-fade-in">
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                      
                      {/* Search text */}
                      <div className="relative col-span-1 sm:col-span-2 lg:col-span-1">
                        <input 
                          type="text"
                          value={ledgerSearchTerm}
                          onChange={(e) => setLedgerSearchTerm(e.target.value)}
                          placeholder="بحث في البيان، الملاحظات..."
                          className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 text-xs pr-8 pl-8 focus:outline-hidden focus:border-purple-500 transition-colors"
                        />
                        <Search size={14} className="absolute top-1/2 -translate-y-1/2 right-2.5 text-slate-400 pointer-events-none" />
                        {ledgerSearchTerm && (
                          <button
                            type="button"
                            onClick={() => setLedgerSearchTerm('')}
                            className="absolute top-1/2 -translate-y-1/2 left-2 p-1 text-slate-400 hover:text-slate-600 hover:bg-slate-200/70 rounded-full transition-colors cursor-pointer"
                            title="إلغاء البحث ومسح النص"
                          >
                            <X size={13} className="stroke-[2.5]" />
                          </button>
                        )}
                      </div>

                      {/* Start Date */}
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-slate-500 shrink-0">من:</span>
                        <input 
                          type="date"
                          value={ledgerStartDate}
                          onChange={(e) => setLedgerStartDate(e.target.value)}
                          className="w-full h-8 px-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 text-xs focus:outline-hidden focus:border-purple-500"
                        />
                      </div>

                      {/* End Date */}
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-slate-500 shrink-0">إلى:</span>
                        <input 
                          type="date"
                          value={ledgerEndDate}
                          onChange={(e) => setLedgerEndDate(e.target.value)}
                          className="w-full h-8 px-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 text-xs focus:outline-hidden focus:border-purple-500"
                        />
                      </div>

                      {/* Sort Order Filter */}
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-slate-500 shrink-0">الترتيب:</span>
                        <select
                          value={ledgerSortOption}
                          onChange={(e) => setLedgerSortOption(e.target.value as any)}
                          className="w-full h-8 px-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 text-xs font-bold focus:outline-hidden focus:border-purple-500 cursor-pointer"
                        >
                          <option value="date-desc">الأحدث أولاً ⬇️ (افتراضي)</option>
                          <option value="date-asc">الأقدم أولاً ⬆️</option>
                          <option value="desc-alpha">أبجدياً حسب البيان (أ - ي) 🔤</option>
                          <option value="amountOnHim-desc">حسب مبلغ عليه (الأعلى أولاً) 🔴</option>
                          <option value="amountForHim-desc">حسب مبلغ له (الأعلى أولاً) 🟢</option>
                        </select>
                      </div>

                      {/* Transaction Type Filter */}
                      <div className="flex items-center gap-2 sm:col-span-2 lg:col-span-2">
                        <span className="text-xs text-slate-500 shrink-0">نوع الحركة:</span>
                        <select
                          value={ledgerTypeFilter}
                          onChange={(e) => setLedgerTypeFilter(e.target.value as 'all' | 'onHim' | 'forHim')}
                          className="w-full h-8 px-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 text-xs font-bold focus:outline-hidden focus:border-purple-500 cursor-pointer"
                        >
                          <option value="all">كافة الحركات المالية (له وعليه)</option>
                          <option value="onHim">مبالغ عليه فقط (سلف / مسحوبات)</option>
                          <option value="forHim">مبالغ له فقط (توريد مواد / مستحقات)</option>
                        </select>
                      </div>

                    </div>

                    {/* Clear filters shortcut */}
                    {isLedgerFilterActive && (
                      <div className="flex justify-end pt-1">
                        <button 
                          type="button"
                          onClick={() => {
                            setLedgerSearchTerm('');
                            setLedgerStartDate('');
                            setLedgerEndDate('');
                            setLedgerTypeFilter('all');
                            setLedgerSortOption('date-desc');
                          }}
                          className="text-[11px] text-purple-600 hover:text-purple-800 hover:underline font-bold cursor-pointer"
                        >
                          إلغاء التصفية وإعادة الضبط 🔄
                        </button>
                      </div>
                    )}
                  </div>
                )}
              </div>

              <div className="bg-white rounded-2xl border border-slate-100 shadow-xs overflow-hidden">
                <div className="p-4 border-b border-slate-100 bg-slate-50/40 flex items-center justify-between gap-3 flex-wrap">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className="font-bold text-slate-800 text-sm">سجل حساب ومعاملات المورد الجاري</h3>
                    {hasActiveSupplierLedgerColumnFilters && (
                      <div className="flex items-center gap-1.5 bg-purple-50 border border-purple-200 text-purple-800 px-2 py-0.5 rounded-lg text-xs font-bold">
                        <Filter size={12} className="fill-current text-purple-600" />
                        <span>تصفية مخصصة للأعمدة</span>
                        <button
                          type="button"
                          onClick={handleClearSupplierLedgerFilters}
                          className="text-[10px] text-purple-600 hover:text-purple-800 hover:underline mr-1 cursor-pointer font-bold"
                        >
                          إلغاء فلاتر الأعمدة ✕
                        </button>
                      </div>
                    )}
                    <span className="text-[10px] text-slate-400 font-bold bg-slate-100 px-2 py-0.5 rounded-md">
                      عدد العمليات: {sortedLedger.length}
                    </span>
                  </div>

                  <div className="text-slate-700 text-xs font-bold flex flex-wrap items-center gap-2 bg-white px-3 py-1.5 rounded-xl border border-slate-100">
                    <span>إجمالي المصفى:</span>
                    {Object.keys(ledgerTotalsByCurrency).length === 0 ? (
                      <span className="text-slate-400">0</span>
                    ) : (
                      (Object.entries(ledgerTotalsByCurrency) as [string, { onHim: number; forHim: number }][]).map(([cur, totals]) => (
                        <div key={cur} className="flex items-center gap-1.5 font-mono text-xs">
                          {totals.forHim > 0 && (
                            <span className="bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded-lg border border-emerald-100 font-extrabold" title="إجمالي له (قيمة مواد وتوريدات)">
                              له: {formatCurrency(totals.forHim, cur)}
                            </span>
                          )}
                          {totals.onHim > 0 && (
                            <span className="bg-rose-50 text-rose-700 px-2 py-0.5 rounded-lg border border-rose-100 font-extrabold" title="إجمالي عليه (مدفوعات ومسدد له)">
                              عليه: {formatCurrency(totals.onHim, cur)}
                            </span>
                          )}
                          {totals.forHim === 0 && totals.onHim === 0 && (
                            <span className="bg-slate-50 text-slate-500 px-2 py-0.5 rounded-lg border border-slate-100 font-extrabold">
                              0 {cur}
                            </span>
                          )}
                        </div>
                      ))
                    )}
                  </div>
                </div>

                <div className="overflow-x-auto">
                  {sortedLedger.length === 0 ? (
                    <div className="text-center py-12 px-4 space-y-2">
                      <p className="text-slate-400 text-sm font-medium">كشف حساب المورد خالٍ حالياً</p>
                      <p className="text-xs text-slate-300">أدخل حركة توريد أو مبالغ مسددة أو قم بترحيل نفقة لهذا المورد من شاشة النفقات.</p>
                    </div>
                  ) : (
                    <table className="w-full text-right text-xs">
                      <thead>
                        <tr className="bg-slate-50 text-slate-500 font-bold border-b border-slate-100">
                          <th className="p-3 whitespace-nowrap">
                            <div className="flex items-center justify-between gap-1">
                              <span>التاريخ</span>
                              <ExcelColumnFilter
                                config={supplierLedgerColumnConfigs.date}
                                data={baseFilteredLedger}
                                allColumnFilters={supplierLedgerColumnFilters}
                                allConfigs={supplierLedgerColumnConfigs}
                                activeFilter={supplierLedgerColumnFilters.date}
                                onFilterChange={handleSupplierLedgerFilterChange}
                                activeSort={supplierLedgerColumnSort}
                                onSortChange={handleSupplierLedgerSortChange}
                                accentColor="purple"
                              />
                            </div>
                          </th>
                          <th className="p-3">
                            <div className="flex items-center justify-between gap-1">
                              <span>البيان</span>
                              <ExcelColumnFilter
                                config={supplierLedgerColumnConfigs.description}
                                data={baseFilteredLedger}
                                allColumnFilters={supplierLedgerColumnFilters}
                                allConfigs={supplierLedgerColumnConfigs}
                                activeFilter={supplierLedgerColumnFilters.description}
                                onFilterChange={handleSupplierLedgerFilterChange}
                                activeSort={supplierLedgerColumnSort}
                                onSortChange={handleSupplierLedgerSortChange}
                                accentColor="purple"
                              />
                            </div>
                          </th>
                          <th className="p-3 text-rose-600 whitespace-nowrap">
                            <div className="flex items-center justify-between gap-1">
                              <span>مبلغ عليه (مسدد له)</span>
                              <ExcelColumnFilter
                                config={supplierLedgerColumnConfigs.amountOnHim}
                                data={baseFilteredLedger}
                                allColumnFilters={supplierLedgerColumnFilters}
                                allConfigs={supplierLedgerColumnConfigs}
                                activeFilter={supplierLedgerColumnFilters.amountOnHim}
                                onFilterChange={handleSupplierLedgerFilterChange}
                                activeSort={supplierLedgerColumnSort}
                                onSortChange={handleSupplierLedgerSortChange}
                                accentColor="rose"
                              />
                            </div>
                          </th>
                          <th className="p-3 text-emerald-600 whitespace-nowrap">
                            <div className="flex items-center justify-between gap-1">
                              <span>مبلغ له (قيمة مواد)</span>
                              <ExcelColumnFilter
                                config={supplierLedgerColumnConfigs.amountForHim}
                                data={baseFilteredLedger}
                                allColumnFilters={supplierLedgerColumnFilters}
                                allConfigs={supplierLedgerColumnConfigs}
                                activeFilter={supplierLedgerColumnFilters.amountForHim}
                                onFilterChange={handleSupplierLedgerFilterChange}
                                activeSort={supplierLedgerColumnSort}
                                onSortChange={handleSupplierLedgerSortChange}
                                accentColor="emerald"
                              />
                            </div>
                          </th>
                          <th className="p-3">
                            <div className="flex items-center justify-between gap-1">
                              <span>ملاحظات</span>
                              <ExcelColumnFilter
                                config={supplierLedgerColumnConfigs.notes}
                                data={baseFilteredLedger}
                                allColumnFilters={supplierLedgerColumnFilters}
                                allConfigs={supplierLedgerColumnConfigs}
                                activeFilter={supplierLedgerColumnFilters.notes}
                                onFilterChange={handleSupplierLedgerFilterChange}
                                activeSort={supplierLedgerColumnSort}
                                onSortChange={handleSupplierLedgerSortChange}
                                accentColor="purple"
                              />
                            </div>
                          </th>
                          <th className="p-3 text-center whitespace-nowrap">
                            <div className="flex items-center justify-center gap-1">
                              <span>كشف المواد</span>
                              <ExcelColumnFilter
                                config={supplierLedgerColumnConfigs.materialItems}
                                data={baseFilteredLedger}
                                allColumnFilters={supplierLedgerColumnFilters}
                                allConfigs={supplierLedgerColumnConfigs}
                                activeFilter={supplierLedgerColumnFilters.materialItems}
                                onFilterChange={handleSupplierLedgerFilterChange}
                                activeSort={supplierLedgerColumnSort}
                                onSortChange={handleSupplierLedgerSortChange}
                                accentColor="amber"
                              />
                            </div>
                          </th>
                          <th className="p-3 text-center whitespace-nowrap">إجراءات</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-50">
                        {sortedLedger.map((e) => (
                          <tr key={e.id} className="hover:bg-slate-50/50 transition-colors">
                            <td className="p-3 whitespace-nowrap text-slate-500">{formatDateArabic(e.date)}</td>
                            <td className="p-3 font-semibold text-slate-800 flex items-center gap-1.5 flex-wrap">
                              <span>{cleanLedgerDescription(e.description)}</span>
                              {e.isPosted && (
                                <span className="text-[9px] bg-rose-50 text-rose-700 border border-rose-100 font-bold px-1.5 py-0.5 rounded-sm">
                                  مرحلة تلقائياً من النفقات اليومية
                                </span>
                              )}
                              <AttributionBadge createdBy={e.createdBy} />
                            </td>
                            <td className="p-3 font-bold text-rose-600">
                              {e.amountOnHim > 0 ? formatCurrency(e.amountOnHim, e.currency || 'YER') : '-'}
                            </td>
                            <td className="p-3 font-bold text-emerald-600">
                              {e.amountForHim > 0 ? formatCurrency(e.amountForHim, e.currency || 'YER') : '-'}
                            </td>
                            <td className="p-3 text-slate-400 max-w-xs truncate" title={e.notes}>
                              {e.notes || '-'}
                            </td>
                            <td className="p-3 text-center whitespace-nowrap">
                              <div className="flex flex-col items-center justify-center gap-1">
                                {e.materialItems && e.materialItems.length > 0 ? (
                                  <button
                                    type="button"
                                    onClick={() => setViewingMaterialEntry({ supplierId: activeSupplier.id, entry: e })}
                                    className="inline-flex items-center gap-1 bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200/90 px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer shadow-2xs hover:shadow-xs"
                                    title={`عرض تفاصيل كشف المواد (${e.materialItems.length} صنف)`}
                                  >
                                    <Package size={13} className="text-amber-600 shrink-0" />
                                    <span>عرض المواد ({e.materialItems.length})</span>
                                  </button>
                                ) : (e.invoiceNumber || e.invoiceImage) ? (
                                  <button
                                    type="button"
                                    onClick={() => setViewingMaterialEntry({ supplierId: activeSupplier.id, entry: e })}
                                    className="inline-flex items-center gap-1 bg-slate-50 hover:bg-amber-50 text-slate-700 hover:text-amber-800 border border-slate-200 px-2.5 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer"
                                    title="عرض بيانات الفاتورة المرفقة"
                                  >
                                    <Receipt size={13} className="text-amber-600 shrink-0" />
                                    <span>مستند الفاتورة</span>
                                  </button>
                                ) : sharedRole !== 'read' ? (
                                  <button
                                    type="button"
                                    onClick={() => setViewingMaterialEntry({ supplierId: activeSupplier.id, entry: e })}
                                    className="inline-flex items-center gap-1 text-slate-400 hover:text-amber-700 hover:bg-amber-50/60 px-2 py-1 rounded-lg text-[11px] font-medium transition-colors cursor-pointer border border-dashed border-slate-200 hover:border-amber-300"
                                    title="إرفاق كشف مواد أو فاتورة لهذه الحركة"
                                  >
                                    <PlusCircle size={12} className="shrink-0" />
                                    <span>+ كشف مواد / فاتورة</span>
                                  </button>
                                ) : (
                                  <span className="text-slate-300 text-xs">-</span>
                                )}

                                {/* Invoice Number and Image Quick Indicators */}
                                {(e.invoiceNumber || e.invoiceImage) && (
                                  <div className="flex items-center gap-1 text-[10px] flex-wrap justify-center">
                                    {e.invoiceNumber && (
                                      <span className="bg-amber-100/90 text-amber-950 px-1.5 py-0.5 rounded-sm font-mono font-bold border border-amber-200" title={`رقم الفاتورة: ${e.invoiceNumber}`}>
                                        #{e.invoiceNumber}
                                      </span>
                                    )}
                                    {e.invoiceImage && (
                                      <button
                                        type="button"
                                        onClick={() => setViewingMaterialEntry({ supplierId: activeSupplier.id, entry: e })}
                                        className="bg-sky-50 hover:bg-sky-100 text-sky-800 px-1.5 py-0.5 rounded-sm font-bold border border-sky-200 cursor-pointer flex items-center gap-0.5 transition-colors"
                                        title="عرض وتكبير صورة الفاتورة المرفقة"
                                      >
                                        <Camera size={10} />
                                        <span>صورة</span>
                                      </button>
                                    )}
                                  </div>
                                )}
                              </div>
                            </td>
                            <td className="p-3 text-center flex items-center justify-center gap-1.5">
                              {sharedRole !== 'read' && (
                                <button 
                                  onClick={() => {
                                    setCopyMoveModalState({
                                      isOpen: true,
                                      mode: 'copy',
                                      entry: e,
                                      supplierId: activeSupplier.id,
                                      supplierName: activeSupplier.name
                                    });
                                  }}
                                  className="p-1 hover:bg-emerald-50 text-slate-300 hover:text-emerald-600 rounded-sm cursor-pointer transition-colors"
                                  title="نسخ العملية إلى حساب آخر"
                                >
                                  <Copy size={13} />
                                </button>
                              )}
                              {sharedRole !== 'read' && (
                                <button 
                                  onClick={() => {
                                    setCopyMoveModalState({
                                      isOpen: true,
                                      mode: 'move',
                                      entry: e,
                                      supplierId: activeSupplier.id,
                                      supplierName: activeSupplier.name
                                    });
                                  }}
                                  className="p-1 hover:bg-amber-50 text-slate-300 hover:text-amber-600 rounded-sm cursor-pointer transition-colors"
                                  title="نقل العملية إلى حساب آخر"
                                >
                                  <ArrowRightLeft size={13} />
                                </button>
                              )}
                              {sharedRole !== 'read' && (
                                <button 
                                  onClick={() => {
                                    setEditingSupplierLedger({ supplierId: activeSupplier.id, entry: e });
                                  }}
                                  className="p-1 hover:bg-slate-50 text-slate-300 hover:text-sky-600 rounded-sm cursor-pointer"
                                  title="تعديل القيد"
                                >
                                  <Pencil size={13} />
                                </button>
                              )}
                              {sharedRole !== 'read' && sharedRole !== 'add' && (
                                <button 
                                  onClick={() => {
                                    if (confirm('هل أنت متأكد من حذف هذه العملية؟ (سيتم تحديث النفقات اليومية تلقائياً إذا كانت مرحلة)')) {
                                      onDeleteSupplierLedgerEntry(activeSupplier.id, e.id);
                                    }
                                  }}
                                  className="p-1 hover:bg-rose-50 text-slate-300 hover:text-rose-500 rounded-sm cursor-pointer"
                                  title="حذف الحركة"
                                >
                                  <Trash2 size={13} />
                                </button>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  )}
                </div>
              </div>
            </div>

          </div>

        </div>

      ) : (
        
        /* -------------------------------- OVERALL DIRECTORY VIEW -------------------------------- */
        <div className="space-y-3 sm:space-y-5 animate-fade-in" id="suppliers-list-pane">
          
          {/* Header */}
          <PageHeaderCard
            title="كشف حسابات الموردين ومواد البناء"
            description="إدارة الموردين وشركات التوريد، تتبع فواتير المواد، الدفعات النقدية والأرصدة المستحقة."
            icon={<Truck size={20} />}
            onBack={setActiveTab ? () => setActiveTab('dashboard') : undefined}
            extraActions={
              <button
                type="button"
                onClick={() => setPrintModalState({ isOpen: true, type: 'all' })}
                className="py-2 px-3 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 active:scale-[0.98] text-white font-extrabold text-xs rounded-xl shadow-xs hover:shadow-md transition-all flex items-center gap-1.5 cursor-pointer shrink-0 border border-purple-500/80 whitespace-nowrap"
                title="طباعة وتصدير التقرير العام للموردين (مختصر أو تفصيلي)"
              >
                <Printer size={14} className="text-purple-200 shrink-0" />
                <span>طباعة التقرير العام</span>
              </button>
            }
            optionsMenu={
              <OptionsMenu 
                onExportExcel={handleExportAllCSV}
                onExportPDF={() => setPrintModalState({ isOpen: true, type: 'all' })}
                onImportExcel={sharedRole !== 'read' ? handleSupplierExcelImport : undefined}
                shareTitle="التقرير المالي العام لموردي الموقع"
                shareText={(() => {
                  const suppliersSummary = suppliers.map(s => {
                    const totalOnHim = s.ledger.reduce((sum, e) => sum + e.amountOnHim, 0);
                    const totalForHim = s.ledger.reduce((sum, e) => sum + e.amountForHim, 0);
                    const net = totalForHim - totalOnHim;
                    const status = net === 0 ? 'خالص' : net > 0 ? `له: ${formatCurrency(net, currency)}` : `عليه: ${formatCurrency(Math.abs(net), currency)}`;
                    return `- ${s.name} (${s.materialType}): ${status}`;
                  }).join('\n');

                  return `🚚 التقرير المالي العام لموردي الموقع وتوريد المواد\n📅 تاريخ الاستخراج: ${new Date().toLocaleDateString('ar-EG-u-nu-latn')}\n\n📊 ملخص مستحقات الموردين:\n${suppliers.length === 0 ? 'لا يوجد موردين مسجلين حالياً.' : suppliersSummary}\n\n*تم توليده ومشاركته من كشوفات المقاولات*`;
                })()}
              />
            }
          />

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-2.5 sm:gap-4">
            
            {/* Column 1: Add Supplier Form */}
            <div className="bg-white p-2.5 sm:p-3.5 rounded-xl sm:rounded-2xl border border-slate-100 shadow-xs h-fit">
              {sharedRole === 'read' ? (
                <div className="text-center py-8 space-y-3">
                  <div className="mx-auto w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center text-slate-400">
                    <Truck size={24} />
                  </div>
                  <h3 className="font-bold text-slate-800 text-sm">وضع عرض الحساب المشترك</h3>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    تمت دعوتك بصلاحية (عرض فقط). لا يمكنك إضافة موردين جدد أو تسجيل حركات مالية في هذا الكشف.
                  </p>
                </div>
              ) : (
                <>
                  <button
                    type="button"
                    onClick={() => setShowAddSupplierForm(!showAddSupplierForm)}
                    className="w-full bg-gradient-to-r from-emerald-600 via-emerald-600 to-emerald-700 hover:from-emerald-700 hover:to-emerald-800 text-white font-extrabold text-xs sm:text-sm py-2 px-2.5 sm:py-2.5 sm:px-3.5 rounded-lg sm:rounded-xl shadow-xs flex items-center justify-between transition-all cursor-pointer select-none border border-emerald-500/50"
                  >
                    <div className="flex items-center gap-2">
                      <div className="p-1 bg-white/20 rounded-md text-white shrink-0">
                        <UserPlus size={15} />
                      </div>
                      <span className="font-extrabold tracking-wide">إضافة مورد مواد جديد</span>
                    </div>
                    <span className="text-[10px] sm:text-xs px-2 py-0.5 sm:px-2.5 sm:py-1 rounded-md font-bold flex items-center gap-1 transition-all bg-white/90 text-emerald-950 shadow-xs">
                      {showAddSupplierForm ? 'إخفاء البيانات ▲' : '+ إضافة مورد جديد ▼'}
                    </span>
                  </button>

                  {showAddSupplierForm && (
                    <div className="pt-3 mt-2.5 border-t border-slate-100 animate-slide-up">
                      <form onSubmit={handleAddSupplierSubmit} className="space-y-4">
                        
                        {/* Name */}
                        <div className="space-y-1">
                          <label className="text-xs font-bold text-slate-600 block">اسم المورد / الشركة</label>
                          <div className="relative">
                            <input 
                              type="text"
                              value={newSupplierName}
                              onChange={(e) => setNewSupplierName(e.target.value)}
                              placeholder="مثال: شركة الرافدين للمواد الإنشائية"
                              className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-sm focus:outline-hidden focus:border-amber-500 transition-colors pr-9"
                              required
                            />
                            <Truck size={16} className="absolute top-1/2 -translate-y-1/2 right-3 text-slate-400 pointer-events-none" />
                          </div>
                        </div>

                        {/* Material Type */}
                        <div className="space-y-1">
                          <label className="text-xs font-bold text-slate-600 block">نوع المواد الموردة</label>
                          <div className="relative">
                            <input 
                              type="text"
                              value={newMaterialType}
                              onChange={(e) => setNewMaterialType(e.target.value)}
                              placeholder="مثال: إسمنت، حديد، رمل، طابوق..."
                              className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-sm focus:outline-hidden focus:border-amber-500 transition-colors pr-9"
                              required
                            />
                            <Package size={16} className="absolute top-1/2 -translate-y-1/2 right-3 text-slate-400 pointer-events-none" />
                          </div>
                        </div>

                        <PhoneNumbersInput 
                          phoneNumbers={newSupplierPhoneNumbers} 
                          onChange={setNewSupplierPhoneNumbers} 
                        />

                        {/* Notes */}
                        <div className="space-y-1">
                          <label className="text-xs font-bold text-slate-600 block">ملاحظات (اختياري)</label>
                          <textarea 
                            value={newSupplierNotes}
                            onChange={(e) => setNewSupplierNotes(e.target.value)}
                            placeholder="أي ملاحظات تفصيلية حول المورد أو شروط التوريد..."
                            rows={2}
                            className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-xs focus:outline-hidden focus:border-amber-500 transition-colors resize-none"
                          />
                        </div>

                        {supplierError && (
                          <p className="text-xs text-rose-600 font-semibold bg-rose-50 p-2.5 rounded-xl border border-rose-100">{supplierError}</p>
                        )}

                        <div className="flex gap-2">
                          <button 
                            type="submit"
                            className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm py-2.5 px-4 rounded-xl shadow-md shadow-emerald-600/20 transition-colors flex items-center justify-center gap-2 cursor-pointer active:scale-98"
                          >
                            <PlusCircle size={18} />
                            تسجيل المورد
                          </button>
                          <button 
                            type="button"
                            onClick={handleResetAddSupplierForm}
                            className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold text-xs rounded-xl transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                            title="إلغاء وتنظيف الحقول"
                          >
                            <RotateCcw size={15} />
                            <span>إلغاء / تنظيف</span>
                          </button>
                        </div>
                      </form>
                    </div>
                  )}
                </>
              )}
            </div>

            {/* Columns 2 & 3: Suppliers cards list */}
            <div className="lg:col-span-2 space-y-2.5 sm:space-y-4">
              
              {/* Search Card & Sort Filter */}
              <div className="bg-white p-2.5 sm:p-4 rounded-xl sm:rounded-2xl border border-slate-100 shadow-xs flex flex-col sm:flex-row items-center gap-2 sm:gap-3">
                <div className="relative flex-1 w-full">
                  <input 
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="ابحث عن مورد بالاسم أو بنوع المادة..."
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-xs pr-8 pl-8 focus:outline-hidden focus:border-amber-500 transition-colors"
                  />
                  <Search size={14} className="absolute top-1/2 -translate-y-1/2 right-2.5 text-slate-400 pointer-events-none" />
                  {searchQuery && (
                    <button
                      type="button"
                      onClick={() => setSearchQuery('')}
                      className="absolute top-1/2 -translate-y-1/2 left-2 p-1 text-slate-400 hover:text-slate-600 hover:bg-slate-200/70 rounded-full transition-colors cursor-pointer"
                      title="إلغاء البحث ومسح النص"
                    >
                      <X size={13} className="stroke-[2.5]" />
                    </button>
                  )}
                </div>

                {/* Suppliers Sort Filter */}
                <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-xs shrink-0 w-full sm:w-auto">
                  <span className="text-slate-400 font-medium">الترتيب:</span>
                  <select
                    value={supplierSortOrder}
                    onChange={(e) => setSupplierSortOrder(e.target.value as 'asc' | 'desc')}
                    className="bg-transparent text-slate-700 font-bold focus:outline-none cursor-pointer text-xs"
                  >
                    <option value="desc">تاريخ المعاملات: الأحدث أولاً ⬇️ (افتراضي)</option>
                    <option value="asc">تاريخ المعاملات: الأقدم أولاً ⬆️</option>
                  </select>
                </div>
              </div>

              {/* Suppliers cards grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5 sm:gap-3.5">
                {sortedSuppliers.length === 0 ? (
                  <div className="bg-white p-12 text-center rounded-2xl border border-slate-100 shadow-xs md:col-span-2">
                    <p className="text-slate-400 text-sm font-medium">لا يوجد موردون يطابقون البحث</p>
                    <p className="text-xs text-slate-300 mt-1">سجل موردين جدداً للبدء في تتبع التوريد</p>
                  </div>
                ) : (
                  sortedSuppliers.map(s => {
                    const totalOnHim = s.ledger.reduce((sum, e) => sum + e.amountOnHim, 0);
                    const totalForHim = s.ledger.reduce((sum, e) => sum + e.amountForHim, 0);
                    const net = totalForHim - totalOnHim;
                    
                    return (
                      <div 
                        key={s.id} 
                        className="bg-white rounded-xl sm:rounded-2xl border border-slate-100 shadow-xs p-3 sm:p-4 hover:border-amber-200 transition-all flex flex-col justify-between group relative"
                        id={`supplier-card-${s.id}`}
                      >
                        {/* Header info */}
                        <div className="space-y-1 sm:space-y-1.5">
                          <div className="flex items-start justify-between">
                            <div>
                              <div className="flex items-center gap-1.5 flex-wrap">
                                <h4 className="font-bold text-slate-800 text-sm sm:text-base">{s.name}</h4>
                                <AttributionBadge createdBy={s.createdBy} updatedBy={s.updatedBy} />
                              </div>
                              <p className="text-[11px] sm:text-xs text-slate-400 mt-0.5">{s.materialType}</p>
                            </div>
                            <span className="text-[9px] sm:text-[10px] bg-slate-50 text-amber-700 border border-amber-100 font-bold px-2 py-0.5 rounded-full shrink-0">
                              مورد مواد
                            </span>
                          </div>

                          <PhoneNumbersDisplay phoneNumbers={s.phoneNumbers} className="pt-0.5" />

                          {s.notes && (
                            <div className="mt-1 text-[10px] sm:text-[11px] text-slate-600 bg-slate-50 border border-slate-100 p-1.5 rounded-lg text-right font-medium">
                              <span className="font-bold text-slate-400 text-[9px] block mb-0.5">ملاحظات:</span>
                              {s.notes}
                            </div>
                          )}
                        </div>

                        {/* Balances per currency */}
                        {(() => {
                          const supplierBalances = s.ledger.reduce((acc, entry) => {
                            const cur = entry.currency || 'YER';
                            if (!acc[cur]) acc[cur] = { onHim: 0, forHim: 0 };
                            acc[cur].onHim += entry.amountOnHim || 0;
                            acc[cur].forHim += entry.amountForHim || 0;
                            return acc;
                          }, {} as Record<string, { onHim: number; forHim: number }>);

                          return (
                            <div className="mt-2.5 pt-2 border-t border-slate-100 space-y-1 text-xs text-right">
                              <span className="text-slate-400 block text-[9px] sm:text-[10px] font-bold">حسابات المورد بالعملة:</span>
                              {Object.keys(supplierBalances).length === 0 ? (
                                <div className="flex justify-between items-center text-[10px] sm:text-[11px] text-slate-500 font-mono">
                                  <span>YER</span>
                                  <span className="font-bold text-slate-400">خالص الطرفين</span>
                                </div>
                              ) : (
                                Object.entries(supplierBalances).map(([cur, b]) => {
                                  const netVal = b.forHim - b.onHim;
                                  return (
                                    <div key={cur} className="flex justify-between items-center border-b border-dashed border-slate-100 last:border-0 pb-0.5 last:pb-0 font-mono text-[10px] sm:text-[11px]">
                                      <span className="text-slate-500 font-bold">{cur}</span>
                                      <span className={netVal < 0 ? 'text-rose-600 font-extrabold' : netVal > 0 ? 'text-purple-600 font-extrabold' : 'text-slate-400'}>
                                        {netVal === 0 ? 'خالص' : netVal > 0 ? `له: ${formatCurrency(netVal, cur)}` : `عليه: ${formatCurrency(Math.abs(netVal), cur)}`}
                                      </span>
                                    </div>
                                  );
                                })
                              )}
                            </div>
                          );
                        })()}

                        {/* Footer details & button */}
                        <div className="flex items-center justify-between mt-2.5 pt-2 border-t border-slate-100">
                          <span className="text-[11px] sm:text-xs font-bold text-slate-400">الكشف الخاص:</span>

                          <div className="flex items-center gap-1 sm:gap-1.5">
                            <button 
                              onClick={() => setSelectedSupplierId(s.id)}
                              className="bg-slate-50 hover:bg-amber-50 text-amber-700 font-bold text-[11px] sm:text-xs py-1 px-2.5 sm:py-1.5 sm:px-3 rounded-lg border border-slate-200 group-hover:border-amber-200 transition-colors cursor-pointer flex items-center gap-1"
                            >
                              الكشف الجاري
                              <ChevronLeft size={13} className="rotate-180" />
                            </button>
                            {sharedRole !== 'read' && (
                              <button 
                                onClick={() => setEditingSupplier(s)}
                                className="p-1 sm:p-1.5 hover:bg-slate-50 text-slate-300 hover:text-slate-600 rounded-lg transition-colors cursor-pointer"
                                title="تعديل المورد"
                              >
                                <Pencil size={13} />
                              </button>
                            )}
                            {sharedRole !== 'read' && sharedRole !== 'add' && (
                              <button 
                                onClick={() => {
                                  if (confirm(`هل أنت متأكد من حذف المورد ${s.name}؟ سيتم حذف كافة سجلات الكشف الجاري الخاص به تلقائياً.`)) {
                                    onDeleteSupplier(s.id);
                                  }
                                }}
                                className="p-1 sm:p-1.5 hover:bg-rose-50 text-slate-300 hover:text-rose-600 rounded-lg transition-colors cursor-pointer"
                                title="حذف المورد"
                              >
                                <Trash2 size={13} />
                              </button>
                            )}
                          </div>
                        </div>

                      </div>
                    );
                  })
                )}
              </div>

            </div>

          </div>

        </div>
      )}

      {/* Edit Supplier Modal */}
      {editingSupplier && (
        <div 
          className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-2.5 sm:p-4 overflow-y-auto dir-rtl text-right overscroll-contain"
          onTouchMove={(e) => {
            if (e.target === e.currentTarget) e.preventDefault();
          }}
        >
          <div 
            className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-md w-full animate-scale-up my-auto max-h-[88vh] sm:max-h-[90vh] flex flex-col overflow-hidden overscroll-contain"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-4 border-b border-slate-100 flex items-center justify-between shrink-0 bg-white">
              <h3 className="font-bold text-slate-800 text-base sm:text-lg">تعديل بيانات المورد</h3>
              <button
                type="button"
                onClick={() => setEditingSupplier(null)}
                className="p-1 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100 cursor-pointer"
              >
                ✕
              </button>
            </div>
            <form onSubmit={handleEditSupplierSubmit} className="flex flex-col flex-1 overflow-hidden min-h-0">
              <div className="p-4 overflow-y-auto space-y-4 flex-1 min-h-0 overscroll-contain touch-pan-y custom-scrollbar modal-scroll-area">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-600 block">اسم المورد</label>
                  <input 
                    type="text" 
                    value={editingSupplier.name}
                    onChange={(e) => setEditingSupplier({ ...editingSupplier, name: e.target.value })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-sm focus:outline-hidden focus:border-amber-500"
                    required
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-600 block">نوع المواد الموردة</label>
                  <input 
                    type="text" 
                    value={editingSupplier.materialType}
                    onChange={(e) => setEditingSupplier({ ...editingSupplier, materialType: e.target.value })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-sm focus:outline-hidden focus:border-amber-500"
                    required
                  />
                </div>

                <PhoneNumbersInput 
                  phoneNumbers={editingSupplier.phoneNumbers && editingSupplier.phoneNumbers.length > 0 ? editingSupplier.phoneNumbers : ['']} 
                  onChange={(phones) => setEditingSupplier({ ...editingSupplier, phoneNumbers: phones })} 
                />

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-600 block">ملاحظات (اختياري)</label>
                  <textarea 
                    value={editingSupplier.notes || ''}
                    onChange={(e) => setEditingSupplier({ ...editingSupplier, notes: e.target.value })}
                    rows={2}
                    placeholder="أي ملاحظات..."
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-xs focus:outline-hidden focus:border-amber-500 resize-none"
                  />
                </div>
              </div>
              <div className="flex justify-end gap-2 p-3.5 bg-slate-50 border-t border-slate-100 shrink-0">
                <button 
                  type="button" 
                  onClick={() => setEditingSupplier(null)}
                  className="bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold text-xs py-2 px-4 rounded-xl transition-colors cursor-pointer"
                >
                  إلغاء
                </button>
                <button 
                  type="submit"
                  className="bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs py-2 px-4 rounded-xl shadow-xs transition-colors cursor-pointer"
                >
                  حفظ التعديلات
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Supplier Ledger Modal */}
      {editingSupplierLedger && (
        <div 
          className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-2.5 sm:p-4 overflow-y-auto dir-rtl text-right overscroll-contain"
          onTouchMove={(e) => {
            if (e.target === e.currentTarget) e.preventDefault();
          }}
        >
          <div 
            className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-md w-full animate-scale-up my-auto max-h-[88vh] sm:max-h-[90vh] flex flex-col overflow-hidden overscroll-contain"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-4 border-b border-slate-100 flex items-center justify-between shrink-0 bg-white">
              <h3 className="font-bold text-slate-800 text-base sm:text-lg">تعديل قيد كشف حساب المورد</h3>
              <button
                type="button"
                onClick={() => setEditingSupplierLedger(null)}
                className="p-1 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100 cursor-pointer"
              >
                ✕
              </button>
            </div>
            <form onSubmit={handleEditSupplierLedgerSubmit} className="flex flex-col flex-1 overflow-hidden min-h-0">
              <div className="p-4 overflow-y-auto space-y-4 flex-1 min-h-0 overscroll-contain touch-pan-y custom-scrollbar modal-scroll-area">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-600 block">التاريخ</label>
                  <input 
                    type="date" 
                    value={editingSupplierLedger.entry.date}
                    onChange={(e) => setEditingSupplierLedger({
                      ...editingSupplierLedger,
                      entry: { ...editingSupplierLedger.entry, date: e.target.value }
                    })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-sm focus:outline-hidden focus:border-amber-500"
                    required
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-600 block">مبلغ عليه (مسدد له)</label>
                    <input 
                      type="number" 
                      value={editingSupplierLedger.entry.amountOnHim || ''}
                      onChange={(e) => setEditingSupplierLedger({
                        ...editingSupplierLedger,
                        entry: { ...editingSupplierLedger.entry, amountOnHim: parseFloat(e.target.value) || 0 }
                      })}
                      className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-sm focus:outline-hidden focus:border-amber-500 font-mono text-left"
                      placeholder="0"
                    />
                    <AmountInWords amount={editingSupplierLedger.entry.amountOnHim} currency={editingSupplierLedger.entry.currency || 'YER'} />
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-600 block">مبلغ له (قيمة المواد)</label>
                    <input 
                      type="number" 
                      value={editingSupplierLedger.entry.amountForHim || ''}
                      onChange={(e) => setEditingSupplierLedger({
                        ...editingSupplierLedger,
                        entry: { ...editingSupplierLedger.entry, amountForHim: parseFloat(e.target.value) || 0 }
                      })}
                      className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-sm focus:outline-hidden focus:border-amber-500 font-mono text-left"
                      placeholder="0"
                    />
                    <AmountInWords amount={editingSupplierLedger.entry.amountForHim} currency={editingSupplierLedger.entry.currency || 'YER'} />
                  </div>
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-600 block">العملة</label>
                  <select 
                    value={editingSupplierLedger.entry.currency || 'YER'}
                    onChange={(e) => setEditingSupplierLedger({
                      ...editingSupplierLedger,
                      entry: { ...editingSupplierLedger.entry, currency: e.target.value }
                    })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-sm focus:outline-hidden focus:border-amber-500"
                  >
                    <option value="YER">ريال يمني (YER)</option>
                    <option value="SAR">ريال سعودي (SAR)</option>
                    <option value="USD">دولار أمريكي (USD)</option>
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-600 block">البيان (نوع الحركة)</label>
                  <input 
                    type="text" 
                    value={editingSupplierLedger.entry.description}
                    onChange={(e) => setEditingSupplierLedger({
                      ...editingSupplierLedger,
                      entry: { ...editingSupplierLedger.entry, description: e.target.value }
                    })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-sm focus:outline-hidden focus:border-amber-500"
                    required
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-600 block">ملاحظات</label>
                  <textarea 
                    value={editingSupplierLedger.entry.notes || ''}
                    onChange={(e) => setEditingSupplierLedger({
                      ...editingSupplierLedger,
                      entry: { ...editingSupplierLedger.entry, notes: e.target.value }
                    })}
                    rows={2}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-sm focus:outline-hidden focus:border-amber-500 resize-none"
                  />
                </div>

                {/* Material Sheet button inside edit modal */}
                <div className="pt-1">
                  <button
                    type="button"
                    onClick={() => {
                      setViewingMaterialEntry({ supplierId: editingSupplierLedger.supplierId, entry: editingSupplierLedger.entry });
                    }}
                    className="w-full py-2 px-3 bg-amber-50 hover:bg-amber-100/80 border border-amber-200 text-amber-900 rounded-xl text-xs font-bold transition-colors cursor-pointer flex items-center justify-between shadow-2xs"
                  >
                    <div className="flex items-center gap-1.5">
                      <Package size={15} className="text-amber-600" />
                      <span>كشف تفاصيل المواد المرفقة ({editingSupplierLedger.entry.materialItems?.length || 0} أصناف)</span>
                    </div>
                    <span className="text-[11px] font-bold text-amber-700">فتح وتعديل الكشف ✎</span>
                  </button>
                </div>

              </div>
              <div className="flex justify-end gap-2 p-3.5 bg-slate-50 border-t border-slate-100 shrink-0">
                <button 
                  type="button" 
                  onClick={() => setEditingSupplierLedger(null)}
                  className="bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold text-xs py-2 px-4 rounded-xl transition-colors cursor-pointer"
                >
                  إلغاء
                </button>
                <button 
                  type="submit"
                  className="bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs py-2 px-4 rounded-xl shadow-xs transition-colors cursor-pointer"
                >
                  حفظ التعديلات
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Supplier Material Modal for Pending New Ledger Entry */}
      <SupplierMaterialModal
        isOpen={isAddMaterialModalOpen}
        onClose={() => setIsAddMaterialModalOpen(false)}
        items={pendingMaterialItems}
        currency={ledgerCurrency}
        invoiceNumber={pendingInvoiceNumber}
        invoiceImage={pendingInvoiceImage}
        discount={pendingMaterialDiscount}
        transactionInfo={{
          supplierName: activeSupplier?.name,
          date: ledgerDate,
          description: ledgerDescription,
          amountForHim: parseFloat(ledgerAmountForHim) || 0,
          amountOnHim: parseFloat(ledgerAmountOnHim) || 0
        }}
        onSave={(updatedItems, invoiceData, discount) => {
          setPendingMaterialItems(updatedItems);
          setPendingInvoiceNumber(invoiceData?.invoiceNumber || '');
          setPendingInvoiceImage(invoiceData?.invoiceImage || '');
          setPendingMaterialDiscount(discount);
        }}
        onApplyTotalToAmount={(total) => {
          setLedgerAmountForHim(String(total));
        }}
      />

      {/* Supplier Material Modal for Viewing/Editing Existing Ledger Entry */}
      {viewingMaterialEntry && (
        <SupplierMaterialModal
          isOpen={Boolean(viewingMaterialEntry)}
          onClose={() => setViewingMaterialEntry(null)}
          items={viewingMaterialEntry.entry.materialItems || []}
          currency={viewingMaterialEntry.entry.currency || currency}
          invoiceNumber={viewingMaterialEntry.entry.invoiceNumber || ''}
          invoiceImage={viewingMaterialEntry.entry.invoiceImage || ''}
          discount={viewingMaterialEntry.entry.materialDiscount}
          transactionInfo={{
            supplierName: activeSupplier?.name,
            date: viewingMaterialEntry.entry.date,
            description: viewingMaterialEntry.entry.description,
            amountForHim: viewingMaterialEntry.entry.amountForHim,
            amountOnHim: viewingMaterialEntry.entry.amountOnHim
          }}
          readOnly={sharedRole === 'read'}
          onSave={(updatedItems, invoiceData, discount) => {
            if (viewingMaterialEntry && onUpdateSupplierLedgerEntry) {
              onUpdateSupplierLedgerEntry(viewingMaterialEntry.supplierId, viewingMaterialEntry.entry.id, {
                date: viewingMaterialEntry.entry.date,
                amountOnHim: viewingMaterialEntry.entry.amountOnHim,
                amountForHim: viewingMaterialEntry.entry.amountForHim,
                description: viewingMaterialEntry.entry.description,
                notes: viewingMaterialEntry.entry.notes,
                currency: viewingMaterialEntry.entry.currency || 'YER',
                materialItems: updatedItems.length > 0 ? updatedItems : undefined,
                materialDiscount: discount,
                invoiceNumber: invoiceData?.invoiceNumber || undefined,
                invoiceImage: invoiceData?.invoiceImage || undefined
              });
            }
            if (editingSupplierLedger && editingSupplierLedger.entry.id === viewingMaterialEntry.entry.id) {
              setEditingSupplierLedger({
                ...editingSupplierLedger,
                entry: {
                  ...editingSupplierLedger.entry,
                  materialItems: updatedItems.length > 0 ? updatedItems : undefined,
                  materialDiscount: discount,
                  invoiceNumber: invoiceData?.invoiceNumber || undefined,
                  invoiceImage: invoiceData?.invoiceImage || undefined
                }
              });
            }
            setViewingMaterialEntry(null);
          }}
          onApplyTotalToAmount={(total) => {
            if (viewingMaterialEntry && onUpdateSupplierLedgerEntry) {
              onUpdateSupplierLedgerEntry(viewingMaterialEntry.supplierId, viewingMaterialEntry.entry.id, {
                date: viewingMaterialEntry.entry.date,
                amountOnHim: viewingMaterialEntry.entry.amountOnHim,
                amountForHim: total,
                description: viewingMaterialEntry.entry.description,
                notes: viewingMaterialEntry.entry.notes,
                currency: viewingMaterialEntry.entry.currency || 'YER',
                materialItems: viewingMaterialEntry.entry.materialItems,
                materialDiscount: viewingMaterialEntry.entry.materialDiscount,
                invoiceNumber: viewingMaterialEntry.entry.invoiceNumber,
                invoiceImage: viewingMaterialEntry.entry.invoiceImage
              });
            }
            if (editingSupplierLedger && editingSupplierLedger.entry.id === viewingMaterialEntry.entry.id) {
              setEditingSupplierLedger({
                ...editingSupplierLedger,
                entry: {
                  ...editingSupplierLedger.entry,
                  amountForHim: total
                }
              });
            }
          }}
        />
      )}

      {/* Copy / Move Ledger Entry Modal */}
      <CopyMoveLedgerModal
        isOpen={copyMoveModalState.isOpen}
        mode={copyMoveModalState.mode}
        entry={copyMoveModalState.entry}
        sourceType="supplier"
        sourceId={copyMoveModalState.supplierId}
        sourceName={copyMoveModalState.supplierName}
        workers={workers}
        employees={employees}
        suppliers={suppliers}
        currency={currency}
        onClose={() => setCopyMoveModalState(prev => ({ ...prev, isOpen: false }))}
        onConfirm={(mode, sType, sId, entry, tType, tId) => {
          if (mode === 'copy') {
            onCopyLedgerEntry?.(sType, sId, entry, tType, tId);
          } else {
            onMoveLedgerEntry?.(sType, sId, entry, tType, tId);
          }
        }}
      />

      {/* Supplier Report Options Modal (Detailed vs Condensed Report) */}
      <SupplierReportOptionsModal
        isOpen={printModalState.isOpen}
        onClose={() => setPrintModalState(prev => ({ ...prev, isOpen: false }))}
        onConfirm={(reportType) => {
          if (printModalState.type === 'single' && printModalState.supplier) {
            handlePrintSupplierPDF(printModalState.supplier, reportType);
          } else {
            handlePrintAllSuppliersPDF(reportType);
          }
        }}
        title={printModalState.type === 'single' ? 'خيارات طباعة كشف حساب المورد' : 'خيارات طباعة التقرير المالي العام للموردين'}
        subtitle={
          printModalState.type === 'single'
            ? 'اختر صيغة التقرير المطلوبة لكشف حساب المورد (مختصر أو تفصيلي مع كشف الأصناف)'
            : 'اختر صيغة التقرير المطلوبة لتقرير كافة الموردين (مختصر أو تفصيلي مع كشوفات المواد)'
        }
        supplierName={printModalState.type === 'single' ? printModalState.supplier?.name : undefined}
        totalMaterialsCount={
          printModalState.type === 'single'
            ? printModalState.supplier?.ledger.reduce((acc, e) => acc + (e.materialItems?.length || 0), 0)
            : suppliers.reduce((acc, s) => acc + s.ledger.reduce((a2, e) => a2 + (e.materialItems?.length || 0), 0), 0)
        }
      />

    </div>
  );
}
