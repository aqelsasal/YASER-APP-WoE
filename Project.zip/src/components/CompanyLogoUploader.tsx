/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef } from 'react';
import { 
  Upload, 
  Image as ImageIcon, 
  RotateCcw, 
  Check, 
  FileCheck, 
  Eye, 
  Sparkles, 
  AlertCircle,
  Trash2,
  Maximize2
} from 'lucide-react';
import { COMPANY_LOGO_BASE64 } from '../companyLogo';

interface CompanyLogoUploaderProps {
  currentLogo: string;
  onLogoChange: (newLogoBase64: string) => void;
  defaultLogo?: string;
  companyName?: string;
}

export default function CompanyLogoUploader({
  currentLogo,
  onLogoChange,
  defaultLogo = COMPANY_LOGO_BASE64,
  companyName = 'اسم المؤسسة / الشركة'
}: CompanyLogoUploaderProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [previewTab, setPreviewTab] = useState<'app' | 'report'>('app');
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const isCustomLogo = Boolean(
    currentLogo && 
    currentLogo !== defaultLogo &&
    (localStorage.getItem('site_company_custom_logo') || currentLogo.startsWith('data:image'))
  );

  const processFile = (file: File) => {
    setErrorMessage(null);
    setSuccessMessage(null);

    // Validate file type
    if (!file.type.startsWith('image/')) {
      setErrorMessage('عذراً، يرجى اختيار ملف صورة صالح (PNG, JPG, JPEG, SVG, WebP).');
      return;
    }

    // Validate file size (up to 8MB)
    if (file.size > 8 * 1024 * 1024) {
      setErrorMessage('حجم الصورة كبير جداً، يرجى اختيار صورة بحجم أقل من 8 ميجابايت.');
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      const result = e.target?.result as string;
      if (result) {
        onLogoChange(result);
        localStorage.setItem('site_company_custom_logo', result);
        setSuccessMessage(`تم تحميل وتحديث الشعار بنجاح (${file.name})!`);
        if (typeof window !== 'undefined' && (window as any).showToast) {
          (window as any).showToast('🖼️ تم رفع وحفظ الشعار الأصلي وتطبيقه على كافة أجزاء التطبيق والتقارير بنجاح!');
        }
        setTimeout(() => setSuccessMessage(null), 4000);
      }
    };
    reader.onerror = () => {
      setErrorMessage('حدث خطأ أثناء قراءة ملف الصورة، يرجى المحاولة مرة أخرى.');
    };
    reader.readAsDataURL(file);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      processFile(file);
    }
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      processFile(file);
    }
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleResetToDefault = () => {
    if (window.confirm('هل أنت متأكد من رغبتك في استعادة الشعار الافتراضي للنظام؟')) {
      onLogoChange(defaultLogo);
      localStorage.removeItem('site_company_custom_logo');
      setSuccessMessage('تمت استعادة الشعار الافتراضي للنظام بنجاح.');
      if (typeof window !== 'undefined' && (window as any).showToast) {
        (window as any).showToast('🔄 تمت استعادة الشعار الافتراضي بنجاح.');
      }
      setTimeout(() => setSuccessMessage(null), 3000);
    }
  };

  return (
    <div className="space-y-4 dir-rtl text-right" id="company-logo-uploader-root">
      
      {/* Header Info */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-200/80 pb-3">
        <div>
          <h3 className="text-sm font-black text-slate-800 flex items-center gap-2">
            <ImageIcon size={18} className="text-amber-500" />
            <span>تخصيص ورفع شعار الشركة / المنشأة</span>
          </h3>
          <p className="text-xs text-slate-500 font-medium mt-0.5">
            ارفع ملف الشعار الأصلي بدقة كاملة من جهازك أو هاتفك لاعتماده في الترويسة والتقارير والسندات
          </p>
        </div>

        <div className="flex items-center gap-2">
          {isCustomLogo && (
            <button
              type="button"
              onClick={handleResetToDefault}
              className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 hover:text-slate-900 text-xs font-bold rounded-xl border border-slate-300 transition-all flex items-center gap-1.5 cursor-pointer"
              title="استعادة الشعار الافتراضي الأصلي للنظام"
            >
              <RotateCcw size={13} className="text-slate-500" />
              <span>استعادة الافتراضي</span>
            </button>
          )}
        </div>
      </div>

      {/* Status Messages */}
      {errorMessage && (
        <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 rounded-xl text-xs font-bold flex items-center gap-2 animate-fade-in">
          <AlertCircle size={16} className="shrink-0 text-rose-600" />
          <span>{errorMessage}</span>
        </div>
      )}

      {successMessage && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs font-bold flex items-center gap-2 animate-fade-in">
          <Check size={16} className="shrink-0 text-emerald-600" />
          <span>{successMessage}</span>
        </div>
      )}

      {/* Main Upload and Preview Grid */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
        
        {/* Upload Zone (7 cols on md) */}
        <div className="md:col-span-7 space-y-3">
          <div
            onDrop={handleDrop}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onClick={() => fileInputRef.current?.click()}
            className={`border-2 border-dashed rounded-2xl p-6 text-center transition-all cursor-pointer flex flex-col items-center justify-center gap-3 relative group ${
              isDragging 
                ? 'border-amber-500 bg-amber-50/80 scale-[0.99]' 
                : 'border-slate-300 hover:border-amber-500/80 bg-slate-50/70 hover:bg-amber-50/30'
            }`}
          >
            <input
              ref={fileInputRef}
              type="file"
              accept="image/png, image/jpeg, image/jpg, image/svg+xml, image/webp"
              onChange={handleFileChange}
              className="hidden"
              id="company-logo-file-input"
            />

            <div className="w-14 h-14 rounded-2xl bg-amber-100/80 text-amber-700 flex items-center justify-center group-hover:scale-110 group-hover:bg-amber-200/80 transition-transform shadow-xs">
              <Upload size={26} />
            </div>

            <div>
              <p className="text-xs sm:text-sm font-black text-slate-800">
                اضغط هنا لاختيار ملف الشعار من جهازك
              </p>
              <p className="text-[11px] text-slate-500 font-medium mt-1">
                أو قم بسحب وإفلات صورة الشعار داخل هذا المربع
              </p>
            </div>

            <div className="flex flex-wrap items-center justify-center gap-1.5 pt-1">
              <span className="px-2 py-0.5 rounded-md bg-white border border-slate-200 text-[10px] font-bold text-slate-600">
                PNG (موصى به)
              </span>
              <span className="px-2 py-0.5 rounded-md bg-white border border-slate-200 text-[10px] font-bold text-slate-600">
                JPG / JPEG
              </span>
              <span className="px-2 py-0.5 rounded-md bg-white border border-slate-200 text-[10px] font-bold text-slate-600">
                SVG
              </span>
              <span className="px-2 py-0.5 rounded-md bg-white border border-slate-200 text-[10px] font-bold text-slate-600">
                WebP
              </span>
            </div>
          </div>

          <div className="bg-amber-50/70 p-3 rounded-xl border border-amber-200/60 flex items-start gap-2 text-[11px] text-amber-900">
            <Sparkles size={15} className="text-amber-600 shrink-0 mt-0.5" />
            <p className="leading-relaxed">
              <strong>نصيحة للجودة:</strong> يفضل اختيار صورة ذات خلفية بيضاء أو شفافة وبدقة جيدة ليظهر الشعار بأفضل وضوح ممكن عند طباعة السندات والتقارير الرسمية كـ PDF.
            </p>
          </div>
        </div>

        {/* Live Preview Box (5 cols on md) */}
        <div className="md:col-span-5 flex flex-col justify-between bg-slate-900 text-white rounded-2xl p-4 border border-slate-800 shadow-md">
          
          <div>
            <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-3">
              <span className="text-xs font-black text-amber-300 flex items-center gap-1.5">
                <Eye size={14} />
                <span>معاينة الشعار المعتمد حالياً</span>
              </span>
              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                isCustomLogo 
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-400/30' 
                  : 'bg-slate-800 text-slate-300 border border-slate-700'
              }`}>
                {isCustomLogo ? 'شعار مخصص تم رفعه ✅' : 'الشعار الافتراضي'}
              </span>
            </div>

            {/* Logo Display Box */}
            <div className="w-full h-32 bg-white rounded-xl p-2.5 flex items-center justify-center border border-slate-700 shadow-inner overflow-hidden">
              <img 
                src={currentLogo || defaultLogo} 
                alt="شعار الشركة" 
                className="max-w-full max-h-full object-contain"
              />
            </div>
          </div>

          {/* Context Preview Switcher */}
          <div className="mt-3 pt-3 border-t border-slate-800">
            <div className="text-[11px] font-bold text-slate-300 mb-1.5">
              طريقة الظهور في ترويسة التطبيق:
            </div>
            <div className="bg-slate-950 p-2 rounded-xl border border-slate-800 flex items-center gap-2.5">
              <div className="w-12 h-9 rounded-lg bg-white p-0.5 flex items-center justify-center shrink-0 border border-slate-700 overflow-hidden">
                <img 
                  src={currentLogo || defaultLogo} 
                  alt="شعار الشركة" 
                  className="w-full h-full object-contain" 
                />
              </div>
              <div className="min-w-0 flex-1">
                <div className="text-xs font-bold text-white truncate leading-tight">
                  الحسابات وادارة المشاريع
                </div>
                <div className="text-[10px] text-amber-300 truncate">
                  {companyName}
                </div>
              </div>
            </div>
          </div>

        </div>

      </div>

    </div>
  );
}
