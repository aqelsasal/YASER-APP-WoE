/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo, useRef } from 'react';
import PageHeaderCard from './PageHeaderCard';
import { AmountInWords } from './AmountInWords';
import { DraggableScrollIndicator } from './DraggableScrollIndicator';
import { 
  Building2, 
  Search, 
  PlusCircle, 
  Calendar, 
  Clock, 
  CheckCircle2, 
  AlertCircle, 
  Phone, 
  Trash2, 
  Pencil, 
  X, 
  FileSpreadsheet, 
  FileText, 
  Truck, 
  ArrowUpRight, 
  ArrowDownLeft, 
  Receipt, 
  ChevronLeft,
  Filter,
  Check,
  Package,
  Wrench,
  Boxes,
  Monitor,
  Tractor,
  Layers,
  ArrowRightLeft,
  RotateCcw,
  Sparkles,
  MapPin,
  User,
  Hash,
  Activity,
  History,
  AlertTriangle,
  Info
} from 'lucide-react';
import { 
  CompanyAsset, 
  CompanyAssetMovement, 
  AssetCategory, 
  AssetCondition, 
  ASSET_CATEGORIES, 
  ASSET_CONDITIONS, 
  getAssetCategoryInfo, 
  getAssetConditionInfo, 
  formatCurrency, 
  formatDateArabic, 
  exportToXLSX, 
  printPDF,
  Project,
  Supplier,
  Employee,
  Expense
} from '../types';
import OptionsMenu from './OptionsMenu';
import { useBodyScrollLock } from '../utils/modalScrollLock';
import ExpenseAssetsPanel, { ExpenseAssetItem } from './ExpenseAssetsPanel';

interface CompanyAssetsProps {
  assets: CompanyAsset[];
  onAddAsset: (asset: Omit<CompanyAsset, 'id' | 'movements' | 'createdAt' | 'updatedAt'>) => void;
  onUpdateAsset: (id: string, updatedData: Partial<CompanyAsset>) => void;
  onDeleteAsset: (id: string) => void;
  onAddMovement: (assetId: string, movement: Omit<CompanyAssetMovement, 'id' | 'createdAt'>) => void;
  onDeleteMovement: (assetId: string, movementId: string) => void;
  projects?: Project[];
  expenses?: Expense[];
  suppliers?: Supplier[];
  employees?: Employee[];
  setActiveTab?: (tab: string) => void;
  sharedRole?: string;
  currentUser?: string;
}

export const CompanyAssets: React.FC<CompanyAssetsProps> = ({
  assets = [],
  onAddAsset,
  onUpdateAsset,
  onDeleteAsset,
  onAddMovement,
  onDeleteMovement,
  projects = [],
  expenses = [],
  suppliers = [],
  employees = [],
  setActiveTab,
  sharedRole,
  currentUser = 'المدير'
}) => {
  // Main Tab: Inventory vs Daily Expense Added Assets
  const [activeMainTab, setActiveMainTab] = useState<'inventory' | 'expense_assets'>('inventory');

  // Filter & Search States
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [conditionFilter, setConditionFilter] = useState<string>('all');
  const [currencyFilter, setCurrencyFilter] = useState<string>('all');
  const [locationFilter, setLocationFilter] = useState<string>('all');
  const [sortOrder, setSortOrder] = useState<'newest' | 'oldest' | 'highest_value' | 'name'>('newest');

  // Modals state
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedAssetId, setSelectedAssetId] = useState<string | null>(null);
  const [editingAsset, setEditingAsset] = useState<CompanyAsset | null>(null);
  const [showMovementModal, setShowMovementModal] = useState(false);

  // Lock body scroll when modals are open
  useBodyScrollLock(showAddModal || !!selectedAssetId || !!editingAsset || showMovementModal);

  // Form State for Adding / Editing Asset
  const [formName, setFormName] = useState('');
  const [formCategory, setFormCategory] = useState<AssetCategory>('heavy_machinery');
  const [formPurchaseDate, setFormPurchaseDate] = useState(new Date().toISOString().split('T')[0]);
  const [formQuantity, setFormQuantity] = useState('1');
  const [formUnit, setFormUnit] = useState('عدد');
  const [formPurchasePrice, setFormPurchasePrice] = useState('');
  const [formCurrency, setFormCurrency] = useState<'YER' | 'SAR' | 'USD'>('YER');
  const [formSupplierName, setFormSupplierName] = useState('');
  const [formCurrentLocation, setFormCurrentLocation] = useState('المخزن العام للشركة');
  const [formProjectId, setFormProjectId] = useState('');
  const [formCondition, setFormCondition] = useState<AssetCondition>('very_good');
  const [formCustodyPerson, setFormCustodyPerson] = useState('');
  const [formSerialNumber, setFormSerialNumber] = useState('');
  const [formInvoiceNumber, setFormInvoiceNumber] = useState('');
  const [formNotes, setFormNotes] = useState('');
  const [formSourceExpenseId, setFormSourceExpenseId] = useState<string | undefined>(undefined);
  const [formSourceProjectId, setFormSourceProjectId] = useState<string | undefined>(undefined);
  const [formError, setFormError] = useState('');

  // Form State for Movement/Transfer/Maintenance
  const [movType, setMovType] = useState<'transfer' | 'custody_change' | 'maintenance' | 'status_change'>('transfer');
  const [movDate, setMovDate] = useState(new Date().toISOString().split('T')[0]);
  const [movToLocation, setMovToLocation] = useState('');
  const [movToCustody, setMovToCustody] = useState('');
  const [movCost, setMovCost] = useState('');
  const [movDescription, setMovDescription] = useState('');
  const [movNotes, setMovNotes] = useState('');
  const [movError, setMovError] = useState('');

  // Selected Asset for details view
  const selectedAsset = useMemo(() => {
    return assets.find(a => a.id === selectedAssetId) || null;
  }, [assets, selectedAssetId]);

  // Financial Summaries grouped strictly by currency
  const currencySummaries = useMemo(() => {
    const result: Record<'YER' | 'SAR' | 'USD', { totalValue: number; count: number; itemsCount: number }> = {
      YER: { totalValue: 0, count: 0, itemsCount: 0 },
      SAR: { totalValue: 0, count: 0, itemsCount: 0 },
      USD: { totalValue: 0, count: 0, itemsCount: 0 }
    };

    assets.forEach(asset => {
      const curr = (asset.currency as 'YER' | 'SAR' | 'USD') || 'YER';
      if (!result[curr]) return;
      result[curr].totalValue += (Number(asset.purchasePrice) || 0);
      result[curr].count += 1;
      result[curr].itemsCount += (Number(asset.quantity) || 1);
    });

    return result;
  }, [assets]);

  // Distinct locations for filter
  const distinctLocations = useMemo(() => {
    const set = new Set<string>();
    assets.forEach(a => {
      if (a.currentLocation) set.add(a.currentLocation.trim());
    });
    return Array.from(set);
  }, [assets]);

  // Filtered and Sorted Assets List
  const filteredAssets = useMemo(() => {
    return assets.filter(asset => {
      // Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const matchName = asset.name?.toLowerCase().includes(q);
        const matchSupplier = asset.supplierName?.toLowerCase().includes(q);
        const matchLocation = asset.currentLocation?.toLowerCase().includes(q);
        const matchCustody = asset.custodyPerson?.toLowerCase().includes(q);
        const matchSerial = asset.serialNumber?.toLowerCase().includes(q);
        const matchInvoice = asset.invoiceNumber?.toLowerCase().includes(q);
        const matchNotes = asset.notes?.toLowerCase().includes(q);
        if (!matchName && !matchSupplier && !matchLocation && !matchCustody && !matchSerial && !matchInvoice && !matchNotes) {
          return false;
        }
      }

      // Category filter
      if (categoryFilter !== 'all' && asset.category !== categoryFilter) {
        return false;
      }

      // Condition filter
      if (conditionFilter !== 'all' && asset.condition !== conditionFilter) {
        return false;
      }

      // Currency filter
      if (currencyFilter !== 'all' && asset.currency !== currencyFilter) {
        return false;
      }

      // Location filter
      if (locationFilter !== 'all' && asset.currentLocation !== locationFilter) {
        return false;
      }

      return true;
    }).sort((a, b) => {
      if (sortOrder === 'newest') {
        return new Date(b.purchaseDate || b.createdAt).getTime() - new Date(a.purchaseDate || a.createdAt).getTime();
      } else if (sortOrder === 'oldest') {
        return new Date(a.purchaseDate || a.createdAt).getTime() - new Date(b.purchaseDate || b.createdAt).getTime();
      } else if (sortOrder === 'highest_value') {
        return (b.purchasePrice || 0) - (a.purchasePrice || 0);
      } else if (sortOrder === 'name') {
        return a.name.localeCompare(b.name, 'ar');
      }
      return 0;
    });
  }, [assets, searchQuery, categoryFilter, conditionFilter, currencyFilter, locationFilter, sortOrder]);

  // Open Create Asset Modal
  const handleOpenAddModal = () => {
    setFormName('');
    setFormCategory('heavy_machinery');
    setFormPurchaseDate(new Date().toISOString().split('T')[0]);
    setFormQuantity('1');
    setFormUnit('عدد');
    setFormPurchasePrice('');
    setFormCurrency('YER');
    setFormSupplierName('');
    setFormCurrentLocation('المخزن العام للشركة');
    setFormProjectId('');
    setFormCondition('very_good');
    setFormCustodyPerson('');
    setFormSerialNumber('');
    setFormInvoiceNumber('');
    setFormNotes('');
    setFormSourceExpenseId(undefined);
    setFormSourceProjectId(undefined);
    setFormError('');
    setShowAddModal(true);
  };

  // Open Add Modal pre-populated from an Expense item
  const handleOpenAddFromExpenseModal = (item: ExpenseAssetItem) => {
    setEditingAsset(null);
    setFormName(item.description || '');
    setFormCategory('tools_equipment');
    setFormPurchaseDate(item.date || new Date().toISOString().split('T')[0]);
    setFormQuantity('1');
    setFormUnit('عدد');
    setFormPurchasePrice(String(item.amount || ''));
    setFormCurrency(item.currency || 'YER');
    setFormSupplierName(item.recipientName || '');
    setFormCurrentLocation(item.projectName ? `مشروع ${item.projectName}` : 'المخزن العام للشركة');
    setFormProjectId(item.projectId || '');
    setFormCondition('very_good');
    setFormCustodyPerson('');
    setFormSerialNumber('');
    setFormInvoiceNumber('');
    setFormNotes(`${item.notes ? item.notes + ' - ' : ''}(أصل مضاف من نفقات مشروع: ${item.projectName}) [كود: ${item.expenseId}]`);
    setFormSourceExpenseId(item.expenseId);
    setFormSourceProjectId(item.projectId || undefined);
    setFormError('');
    setShowAddModal(true);
  };

  // Navigate to an asset inside the inventory list
  const handleNavigateToAsset = (assetId: string) => {
    setActiveMainTab('inventory');
    setSelectedAssetId(assetId);
    setTimeout(() => {
      const el = document.getElementById(`asset-card-${assetId}`);
      if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    }, 100);
  };

  // Open Edit Asset Modal
  const handleOpenEditModal = (asset: CompanyAsset) => {
    setEditingAsset(asset);
    setFormName(asset.name);
    setFormCategory(asset.category);
    setFormPurchaseDate(asset.purchaseDate);
    setFormQuantity(String(asset.quantity || 1));
    setFormUnit(asset.unit || 'عدد');
    setFormPurchasePrice(String(asset.purchasePrice || 0));
    setFormCurrency(asset.currency || 'YER');
    setFormSupplierName(asset.supplierName || '');
    setFormCurrentLocation(asset.currentLocation || 'المخزن العام للشركة');
    setFormProjectId(asset.projectId || '');
    setFormCondition(asset.condition || 'very_good');
    setFormCustodyPerson(asset.custodyPerson || '');
    setFormSerialNumber(asset.serialNumber || '');
    setFormInvoiceNumber(asset.invoiceNumber || '');
    setFormNotes(asset.notes || '');
    setFormSourceExpenseId(asset.sourceExpenseId);
    setFormSourceProjectId(asset.sourceProjectId);
    setFormError('');
  };

  // Save Asset Form Submit
  const handleSaveAssetSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim()) {
      setFormError('يرجى كتابة اسم الأصل / المادة');
      return;
    }
    const priceNum = Number(formPurchasePrice);
    if (isNaN(priceNum) || priceNum < 0) {
      setFormError('يرجى إدخال تكلفة أو قيمة شراء صحيحة');
      return;
    }
    const qtyNum = Number(formQuantity);
    if (isNaN(qtyNum) || qtyNum <= 0) {
      setFormError('يرجى إدخال كمية صحيحة أكبر من صفر');
      return;
    }

    if (editingAsset) {
      onUpdateAsset(editingAsset.id, {
        name: formName.trim(),
        category: formCategory,
        purchaseDate: formPurchaseDate,
        quantity: qtyNum,
        unit: formUnit.trim() || 'عدد',
        purchasePrice: priceNum,
        currency: formCurrency,
        supplierName: formSupplierName.trim(),
        currentLocation: formCurrentLocation.trim(),
        projectId: formProjectId || undefined,
        condition: formCondition,
        custodyPerson: formCustodyPerson.trim(),
        serialNumber: formSerialNumber.trim(),
        invoiceNumber: formInvoiceNumber.trim(),
        notes: formNotes.trim(),
        sourceExpenseId: formSourceExpenseId,
        sourceProjectId: formSourceProjectId
      });
      setEditingAsset(null);
      if (typeof window !== 'undefined' && (window as any).showToast) {
        (window as any).showToast('✅ تم تحديث بيانات الأصل بنجاح!');
      }
    } else {
      onAddAsset({
        name: formName.trim(),
        category: formCategory,
        purchaseDate: formPurchaseDate,
        quantity: qtyNum,
        unit: formUnit.trim() || 'عدد',
        purchasePrice: priceNum,
        currency: formCurrency,
        supplierName: formSupplierName.trim(),
        currentLocation: formCurrentLocation.trim(),
        projectId: formProjectId || undefined,
        condition: formCondition,
        custodyPerson: formCustodyPerson.trim(),
        serialNumber: formSerialNumber.trim(),
        invoiceNumber: formInvoiceNumber.trim(),
        notes: formNotes.trim(),
        sourceExpenseId: formSourceExpenseId,
        sourceProjectId: formSourceProjectId,
        createdBy: currentUser
      });
      setShowAddModal(false);
      if (typeof window !== 'undefined' && (window as any).showToast) {
        (window as any).showToast('✅ تم إضافة الأصل / المادة الجديدة بنجاح!');
      }
    }
  };

  // Submit Movement / Custody / Maintenance
  const handleSaveMovementSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedAsset) return;

    if (!movDescription.trim()) {
      setMovError('يرجى إدخال بيان الحركة / الإجراء');
      return;
    }

    const costNum = movCost ? Number(movCost) : 0;
    if (isNaN(costNum) || costNum < 0) {
      setMovError('يرجى إدخال تكلفة صحيحة');
      return;
    }

    onAddMovement(selectedAsset.id, {
      date: movDate,
      type: movType,
      fromLocation: selectedAsset.currentLocation,
      toLocation: movToLocation.trim() || selectedAsset.currentLocation,
      fromCustody: selectedAsset.custodyPerson,
      toCustody: movToCustody.trim() || selectedAsset.custodyPerson,
      cost: costNum > 0 ? costNum : undefined,
      currency: selectedAsset.currency,
      description: movDescription.trim(),
      notes: movNotes.trim(),
      createdBy: currentUser
    });

    // Update the asset's current location/custody if changed in movement
    const updates: Partial<CompanyAsset> = {};
    if (movToLocation.trim() && movToLocation.trim() !== selectedAsset.currentLocation) {
      updates.currentLocation = movToLocation.trim();
    }
    if (movToCustody.trim() && movToCustody.trim() !== selectedAsset.custodyPerson) {
      updates.custodyPerson = movToCustody.trim();
    }
    if (Object.keys(updates).length > 0) {
      onUpdateAsset(selectedAsset.id, updates);
    }

    setShowMovementModal(false);
    setMovDescription('');
    setMovCost('');
    setMovNotes('');
    setMovToLocation('');
    setMovToCustody('');
    setMovError('');
    if (typeof window !== 'undefined' && (window as any).showToast) {
      (window as any).showToast('✅ تم تسجيل حركة الأصل وتحديث موقعه بنجاح!');
    }
  };

  // Export to Excel (XLSX)
  const handleExportExcel = () => {
    const headers = [
      'اسم الأصل / المادة',
      'التصنيف والفئة',
      'تاريخ الشراء',
      'الكمية',
      'الوحدة',
      'تكلفة الشراء',
      'العملة',
      'الموقع الحالي',
      'المسؤول / العهدة',
      'الحالة التشغيلية',
      'المورد / البائع',
      'الرقم التسلسلي',
      'رقم الفاتورة',
      'ملاحظات'
    ];

    const rows = filteredAssets.map(a => {
      const cat = getAssetCategoryInfo(a.category).label;
      const cond = getAssetConditionInfo(a.condition).label;
      return [
        a.name,
        cat,
        a.purchaseDate,
        a.quantity,
        a.unit,
        a.purchasePrice,
        a.currency,
        a.currentLocation,
        a.custodyPerson || '-',
        cond,
        a.supplierName || '-',
        a.serialNumber || '-',
        a.invoiceNumber || '-',
        a.notes || '-'
      ];
    });

    exportToXLSX('سجل_أصول_ومواد_الشركة_الشامل', headers, rows, 'أصول_الشركة');
  };

  // Print PDF Official Inventory Report
  const handlePrintPDF = () => {
    const rowsHtml = filteredAssets.map((a, idx) => {
      const cat = getAssetCategoryInfo(a.category).label;
      const cond = getAssetConditionInfo(a.condition).label;
      return `
        <tr>
          <td style="text-align: center; width: 4%;">${idx + 1}</td>
          <td class="col-statement" style="width: 32%;"><strong>${a.name}</strong><br><small style="color: #64748b;">${cat}</small></td>
          <td style="text-align: center; width: 10%;">${a.quantity} ${a.unit}</td>
          <td style="text-align: left; font-weight: bold; color: #0284c7; width: 14%;">${formatCurrency(a.purchasePrice, a.currency)}</td>
          <td style="text-align: center; width: 14%;">${a.currentLocation}</td>
          <td style="text-align: center; width: 12%;">${a.custodyPerson || '-'}</td>
          <td style="text-align: center; width: 8%;">${cond}</td>
          <td style="text-align: center; width: 6%;">${formatDateArabic(a.purchaseDate)}</td>
        </tr>
      `;
    }).join('');

    const htmlContent = `
      <div style="margin-bottom: 20px;">
        <h2 style="font-size: 16px; font-weight: bold; color: #0f172a; margin-bottom: 8px;">سجل وجرد أصول ومواد الشركة والمشاريع</h2>
        <p style="font-size: 12px; color: #475569; margin: 0;">كشف تفصيلي وجرد شامل لكافة المشتريات الرأسمالية، المعدات، الآليات، والمخزون المملوك للشركة.</p>
      </div>

      <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin-bottom: 20px; text-align: center;">
        <div style="border: 1px solid #cbd5e1; padding: 10px; border-radius: 8px; background-color: #f8fafc;">
          <small style="color: #64748b; font-weight: bold;">إجمالي قيمة أصول الريال اليمني</small>
          <div style="font-size: 15px; font-weight: bold; color: #0284c7;">${formatCurrency(currencySummaries.YER.totalValue, 'YER')}</div>
          <small style="color: #64748b;">(${currencySummaries.YER.count} أصل مسجل)</small>
        </div>
        <div style="border: 1px solid #cbd5e1; padding: 10px; border-radius: 8px; background-color: #f8fafc;">
          <small style="color: #64748b; font-weight: bold;">إجمالي قيمة أصول الريال السعودي</small>
          <div style="font-size: 15px; font-weight: bold; color: #0284c7;">${formatCurrency(currencySummaries.SAR.totalValue, 'SAR')}</div>
          <small style="color: #64748b;">(${currencySummaries.SAR.count} أصل مسجل)</small>
        </div>
        <div style="border: 1px solid #cbd5e1; padding: 10px; border-radius: 8px; background-color: #f8fafc;">
          <small style="color: #64748b; font-weight: bold;">إجمالي قيمة أصول الدولار</small>
          <div style="font-size: 15px; font-weight: bold; color: #0284c7;">${formatCurrency(currencySummaries.USD.totalValue, 'USD')}</div>
          <small style="color: #64748b;">(${currencySummaries.USD.count} أصل مسجل)</small>
        </div>
      </div>

      <table>
        <thead>
          <tr>
            <th style="width: 4%;">#</th>
            <th style="width: 32%;" class="col-statement">اسم الأصل / الفئة</th>
            <th style="width: 10%;">الكمية</th>
            <th style="width: 14%;">قيمة الشراء</th>
            <th style="width: 14%;">الموقع والتواجد</th>
            <th style="width: 12%;">العهدة / المسؤول</th>
            <th style="width: 8%;">الحالة</th>
            <th style="width: 6%;">تاريخ الشراء</th>
          </tr>
        </thead>
        <tbody>
          ${rowsHtml || '<tr><td colspan="8" style="text-align: center; padding: 20px;">لا توجد أصول مسجلة</td></tr>'}
        </tbody>
      </table>
    `;

    printPDF('سجل_أصول_ومواد_الشركة_الرسمي', htmlContent);
  };

  // Helper icon renderer for categories
  const renderCategoryIcon = (cat: AssetCategory, size = 18) => {
    switch (cat) {
      case 'heavy_machinery':
        return <Tractor size={size} />;
      case 'tools_equipment':
        return <Wrench size={size} />;
      case 'materials_stock':
        return <Boxes size={size} />;
      case 'office_tech':
        return <Monitor size={size} />;
      case 'vehicles':
        return <Truck size={size} />;
      default:
        return <Package size={size} />;
    }
  };

  // Count of expenses categorized under "أصول مضافة" for tab badge
  const expenseAssetsStats = useMemo(() => {
    let total = 0;
    let unadded = 0;
    const seenIds = new Set<string>();

    const checkExp = (exp: Expense) => {
      if (!exp || !exp.id || seenIds.has(exp.id)) return;
      const cats = (exp.categories && exp.categories.length > 0) ? exp.categories : (exp.category ? [exp.category] : []);
      const isAddedAsset = cats.some(c => {
        const clean = (c || '').trim().toLowerCase();
        return clean.includes('اصول مضافة') || 
               clean.includes('أصول مضافة') || 
               clean.includes('اصول مضافه') || 
               clean.includes('أصول مضافه') ||
               clean === 'اصول مضافة' ||
               clean === 'أصول مضافة' ||
               clean === 'أصول' ||
               clean === 'اصول';
      });
      if (isAddedAsset) {
        seenIds.add(exp.id);
        total += 1;
        const matched = assets.some(a => a.sourceExpenseId === exp.id || (a.notes && a.notes.includes(exp.id)));
        if (!matched) unadded += 1;
      }
    };

    projects.forEach(p => (p.expenses || []).forEach(checkExp));
    expenses.forEach(checkExp);

    return { total, unadded };
  }, [projects, expenses, assets]);

  return (
    <div className="space-y-6 dir-rtl text-right pb-12 animate-fade-in">
      
      {/* ======================= HEADER CARD ======================= */}
      <PageHeaderCard
        title="مواد وأصول الشركة والمشاريع"
        description="سجل وإدارة المشتريات الرأسمالية، المعدات، الآليات، مواد المخزون، وتتبع حركتها والعهد"
        icon={<Boxes className="text-amber-500" size={24} />}
        onBack={setActiveTab ? () => {
          setActiveTab('main_hub');
          window.scrollTo({ top: 0, behavior: 'smooth' });
        } : undefined}
        optionsMenu={
          <OptionsMenu
            customActions={sharedRole !== 'read' ? [
              {
                label: 'إضافة أصل / مادة',
                icon: <PlusCircle size={15} className="text-amber-600 shrink-0" />,
                onClick: handleOpenAddModal,
                className: 'text-amber-700 bg-amber-50/70 hover:bg-amber-100 hover:text-amber-800'
              }
            ] : []}
            onExportExcel={handleExportExcel}
            onExportPDF={handlePrintPDF}
            shareTitle="سجل أصول ومواد الشركة"
            shareText={() => {
              const totalYer = formatCurrency(currencySummaries.YER.totalValue, 'YER');
              const totalSar = formatCurrency(currencySummaries.SAR.totalValue, 'SAR');
              const totalUsd = formatCurrency(currencySummaries.USD.totalValue, 'USD');
              return `📦 تقرير أصول ومواد الشركة والمشاريع:\n📊 إجمالي الأصول: ${assets.length} أصل\n💵 القيمة الإجمالية (YER): ${totalYer}\n💵 القيمة الإجمالية (SAR): ${totalSar}\n💵 القيمة الإجمالية (USD): ${totalUsd}\n\n*تم الاستخراج من نظام إدارة المشاريع*`;
            }}
          />
        }
      />

      {/* ======================= MAIN TABS SWITCHER ======================= */}
      <div className="flex flex-wrap items-center gap-2 p-1.5 bg-slate-100/90 rounded-2xl border border-slate-200 shadow-2xs">
        <button
          type="button"
          onClick={() => setActiveMainTab('inventory')}
          className={`flex-1 sm:flex-initial py-2.5 px-4 rounded-xl text-xs sm:text-sm font-black transition-all flex items-center justify-center gap-2 cursor-pointer ${
            activeMainTab === 'inventory'
              ? 'bg-white text-slate-900 shadow-xs border border-slate-200/80'
              : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
          }`}
        >
          <Boxes size={16} className={activeMainTab === 'inventory' ? 'text-amber-600' : 'text-slate-400'} />
          <span>سجل وجرد أصول ومواد الشركة</span>
          <span className={`text-[11px] px-2 py-0.5 rounded-full font-bold ${
            activeMainTab === 'inventory' ? 'bg-amber-100 text-amber-900' : 'bg-slate-200 text-slate-700'
          }`}>
            {assets.length}
          </span>
        </button>

        <button
          type="button"
          onClick={() => setActiveMainTab('expense_assets')}
          className={`flex-1 sm:flex-initial py-2.5 px-4 rounded-xl text-xs sm:text-sm font-black transition-all flex items-center justify-center gap-2 cursor-pointer ${
            activeMainTab === 'expense_assets'
              ? 'bg-white text-slate-900 shadow-xs border border-slate-200/80'
              : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
          }`}
        >
          <Layers size={16} className={activeMainTab === 'expense_assets' ? 'text-amber-600' : 'text-slate-400'} />
          <span>أصول النفقات اليومية المضافة</span>
          <span className={`text-[11px] px-2 py-0.5 rounded-full font-bold ${
            activeMainTab === 'expense_assets' ? 'bg-amber-100 text-amber-900' : 'bg-slate-200 text-slate-700'
          }`}>
            {expenseAssetsStats.total}
          </span>
          {expenseAssetsStats.unadded > 0 && (
            <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-amber-500 text-white font-black animate-pulse">
              {expenseAssetsStats.unadded} جديد
            </span>
          )}
        </button>
      </div>

      {/* ======================= VIEW 1: EXPENSE ASSETS VIEW ======================= */}
      {activeMainTab === 'expense_assets' && (
        <ExpenseAssetsPanel
          projects={projects}
          expenses={expenses}
          assets={assets}
          onAddAsset={onAddAsset}
          onOpenAddCustomModal={handleOpenAddFromExpenseModal}
          onNavigateToAsset={handleNavigateToAsset}
          currentUser={currentUser}
          sharedRole={sharedRole}
        />
      )}

      {/* ======================= VIEW 2: INVENTORY ASSETS VIEW ======================= */}
      {activeMainTab === 'inventory' && (
        <div className="space-y-6">

      {/* ======================= KPIS & FINANCIAL SUMMARY CARDS ======================= */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5 sm:gap-3.5">
        
        {/* Total Assets Count */}
        <div className="bg-white rounded-2xl p-3 sm:p-4 border border-slate-200/80 shadow-xs hover:shadow-md transition-all">
          <div className="flex items-center justify-between text-slate-500 mb-1.5">
            <span className="text-xs font-bold">إجمالي الأصول والمواد</span>
            <div className="p-1.5 bg-amber-50 text-amber-600 rounded-lg">
              <Boxes size={18} />
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-xl sm:text-2xl font-black text-slate-900">{assets.length}</span>
            <span className="text-[11px] font-bold text-slate-500">أصل / مادة مسجلة</span>
          </div>
        </div>

        {/* Total Value (YER) */}
        <div className="bg-white rounded-2xl p-3 sm:p-4 border border-slate-200/80 shadow-xs hover:shadow-md transition-all">
          <div className="flex items-center justify-between text-slate-500 mb-1.5">
            <span className="text-xs font-bold">قيمة الأصول (ريال يمني)</span>
            <div className="p-1.5 bg-emerald-50 text-emerald-600 rounded-lg">
              <Building2 size={18} />
            </div>
          </div>
          <div className="text-base sm:text-lg font-black text-emerald-700 truncate">
            {formatCurrency(currencySummaries.YER.totalValue, 'YER')}
          </div>
          <span className="text-[10px] text-slate-400 font-bold block mt-0.5">
            {currencySummaries.YER.count} أصل مسجل باليمني
          </span>
        </div>

        {/* Total Value (SAR) */}
        <div className="bg-white rounded-2xl p-3 sm:p-4 border border-slate-200/80 shadow-xs hover:shadow-md transition-all">
          <div className="flex items-center justify-between text-slate-500 mb-1.5">
            <span className="text-xs font-bold">قيمة الأصول (ريال سعودي)</span>
            <div className="p-1.5 bg-teal-50 text-teal-600 rounded-lg">
              <Building2 size={18} />
            </div>
          </div>
          <div className="text-base sm:text-lg font-black text-teal-700 truncate">
            {formatCurrency(currencySummaries.SAR.totalValue, 'SAR')}
          </div>
          <span className="text-[10px] text-slate-400 font-bold block mt-0.5">
            {currencySummaries.SAR.count} أصل مسجل بالسعودي
          </span>
        </div>

        {/* Total Value (USD) */}
        <div className="bg-white rounded-2xl p-3 sm:p-4 border border-slate-200/80 shadow-xs hover:shadow-md transition-all">
          <div className="flex items-center justify-between text-slate-500 mb-1.5">
            <span className="text-xs font-bold">قيمة الأصول (دولار أمريكي)</span>
            <div className="p-1.5 bg-sky-50 text-sky-600 rounded-lg">
              <Building2 size={18} />
            </div>
          </div>
          <div className="text-base sm:text-lg font-black text-sky-700 truncate">
            {formatCurrency(currencySummaries.USD.totalValue, 'USD')}
          </div>
          <span className="text-[10px] text-slate-400 font-bold block mt-0.5">
            {currencySummaries.USD.count} أصل مسجل بالدولار
          </span>
        </div>

      </div>

      {/* ======================= FILTER & SEARCH BAR ======================= */}
      <div className="bg-white rounded-2xl p-3 sm:p-4 border border-slate-200/90 shadow-xs space-y-3">
        <div className="flex flex-col sm:flex-row gap-2.5 sm:items-center justify-between">
          
          {/* Search Input */}
          <div className="relative flex-1">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="ابحث باسم الأصل، الكود، الموقع، العهدة، المورد، رقم الفاتورة..."
              className="w-full pl-3 pr-9 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm text-slate-800 placeholder-slate-400 focus:outline-hidden focus:border-amber-500 focus:bg-white transition-all"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
              >
                <X size={14} />
              </button>
            )}
          </div>

          {/* Quick Category Filter Tabs */}
          <div className="flex items-center gap-1 overflow-x-auto pb-1 sm:pb-0 scrollbar-thin">
            <button
              type="button"
              onClick={() => setCategoryFilter('all')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold shrink-0 transition-all cursor-pointer ${
                categoryFilter === 'all'
                  ? 'bg-amber-600 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              الكل ({assets.length})
            </button>
            {ASSET_CATEGORIES.map(cat => {
              const count = assets.filter(a => a.category === cat.key).length;
              return (
                <button
                  key={cat.key}
                  type="button"
                  onClick={() => setCategoryFilter(cat.key)}
                  className={`px-2.5 py-1.5 rounded-xl text-xs font-bold shrink-0 transition-all cursor-pointer flex items-center gap-1.5 ${
                    categoryFilter === cat.key
                      ? 'bg-slate-900 text-white shadow-xs'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  <span>{cat.label}</span>
                  <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${categoryFilter === cat.key ? 'bg-white/20 text-white' : 'bg-slate-200 text-slate-700'}`}>
                    {count}
                  </span>
                </button>
              );
            })}
          </div>

        </div>

        {/* Secondary Filters (Condition, Currency, Location, Sort) */}
        <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-slate-100 text-xs font-bold text-slate-600">
          <div className="flex items-center gap-1.5">
            <Filter size={14} className="text-slate-400" />
            <span className="text-slate-400 font-normal">تصفية:</span>
          </div>

          {/* Condition Filter */}
          <select
            value={conditionFilter}
            onChange={(e) => setConditionFilter(e.target.value)}
            className="bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1 text-xs text-slate-700 focus:outline-hidden focus:border-amber-500 cursor-pointer"
          >
            <option value="all">كافة الحالات التشغيلية</option>
            {ASSET_CONDITIONS.map(cond => (
              <option key={cond.key} value={cond.key}>{cond.label}</option>
            ))}
          </select>

          {/* Currency Filter */}
          <select
            value={currencyFilter}
            onChange={(e) => setCurrencyFilter(e.target.value)}
            className="bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1 text-xs text-slate-700 focus:outline-hidden focus:border-amber-500 cursor-pointer"
          >
            <option value="all">كافة العملات</option>
            <option value="YER">ريال يمني (YER)</option>
            <option value="SAR">ريال سعودي (SAR)</option>
            <option value="USD">دولار أمريكي (USD)</option>
          </select>

          {/* Location Filter */}
          {distinctLocations.length > 0 && (
            <select
              value={locationFilter}
              onChange={(e) => setLocationFilter(e.target.value)}
              className="bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1 text-xs text-slate-700 focus:outline-hidden focus:border-amber-500 cursor-pointer max-w-[150px]"
            >
              <option value="all">كافة المواقع والمخازن</option>
              {distinctLocations.map(loc => (
                <option key={loc} value={loc}>{loc}</option>
              ))}
            </select>
          )}

          {/* Sort Order */}
          <div className="mr-auto flex items-center gap-1">
            <span className="text-slate-400 font-normal">ترتيب:</span>
            <select
              value={sortOrder}
              onChange={(e) => setSortOrder(e.target.value as any)}
              className="bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1 text-xs text-slate-700 focus:outline-hidden focus:border-amber-500 cursor-pointer"
            >
              <option value="newest">الأحدث شراءً</option>
              <option value="oldest">الأقدم شراءً</option>
              <option value="highest_value">الأعلى قيمة</option>
              <option value="name">أبجدياً (أ - ي)</option>
            </select>
          </div>
        </div>

      </div>

      {/* ======================= ASSETS CARDS GRID & LIST ======================= */}
      {filteredAssets.length === 0 ? (
        <div className="bg-white rounded-3xl p-10 border border-slate-200 text-center space-y-3">
          <div className="w-16 h-16 rounded-2xl bg-amber-50 text-amber-500 mx-auto flex items-center justify-center shadow-inner">
            <Boxes size={32} />
          </div>
          <h3 className="text-base font-extrabold text-slate-800">لا توجد مواد أو أصول مسجلة حالياً</h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            يمكنك تسجيل المعدات، الآليات، أدوات العمل، مواد المخزون والمشتريات الرأسمالية للشركة وتتبع عهدها وحالتها بسهولة.
          </p>
          {sharedRole !== 'read' && (
            <button
              type="button"
              onClick={handleOpenAddModal}
              className="mt-2 bg-amber-600 hover:bg-amber-500 text-white font-bold px-4 py-2 rounded-xl text-xs inline-flex items-center gap-1.5 transition-all shadow-md shadow-amber-600/20 cursor-pointer"
            >
              <PlusCircle size={16} />
              <span>إضافة أول أصل للشركة</span>
            </button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5 sm:gap-4">
          {filteredAssets.map(asset => {
            const catInfo = getAssetCategoryInfo(asset.category);
            const condInfo = getAssetConditionInfo(asset.condition);
            const movementsCount = (asset.movements || []).length;

            return (
              <div 
                key={asset.id}
                className="bg-white rounded-3xl p-4 sm:p-5 border border-slate-200/90 shadow-xs hover:shadow-md transition-all flex flex-col justify-between group relative overflow-hidden"
              >
                {/* Top Accent bar based on condition */}
                <div className={`absolute top-0 right-0 left-0 h-1.5 ${condInfo.dotColor}`} />

                <div className="space-y-3">
                  
                  {/* Card Header: Category & Condition badges */}
                  <div className="flex items-center justify-between gap-2 pt-1">
                    <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold border ${catInfo.badgeBg} ${catInfo.badgeText} ${catInfo.badgeBorder}`}>
                      {renderCategoryIcon(asset.category, 12)}
                      <span>{catInfo.label}</span>
                    </span>

                    <span className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[10px] font-bold border ${condInfo.badgeBg} ${condInfo.badgeText} ${condInfo.badgeBorder}`}>
                      <span className={`w-1.5 h-1.5 rounded-full ${condInfo.dotColor}`} />
                      <span>{condInfo.label}</span>
                    </span>
                  </div>

                  {/* Asset Name & Serial */}
                  <div>
                    <h3 className="text-base font-black text-slate-900 group-hover:text-amber-600 transition-colors leading-snug">
                      {asset.name}
                    </h3>
                    <div className="flex items-center gap-2 text-xs text-slate-500 font-semibold mt-1">
                      <span>الكمية: <strong className="text-slate-800 font-bold">{asset.quantity} {asset.unit}</strong></span>
                      {asset.serialNumber && (
                        <>
                          <span className="text-slate-300">•</span>
                          <span className="flex items-center gap-0.5 text-[11px] text-slate-400">
                            <Hash size={11} />
                            كود: {asset.serialNumber}
                          </span>
                        </>
                      )}
                    </div>
                  </div>

                  {/* Financial Value Box */}
                  <div className="bg-slate-50 rounded-2xl p-3 border border-slate-100 flex items-center justify-between">
                    <div>
                      <span className="text-[10px] text-slate-400 font-bold block">تكلفة وقيمة الشراء</span>
                      <span className="text-base font-black text-slate-900">
                        {formatCurrency(asset.purchasePrice, asset.currency)}
                      </span>
                    </div>
                    <div className="text-left">
                      <span className="text-[10px] text-slate-400 font-bold block">تاريخ الشراء</span>
                      <span className="text-xs font-bold text-slate-600 flex items-center gap-1 justify-end">
                        <Calendar size={12} className="text-slate-400" />
                        {formatDateArabic(asset.purchaseDate)}
                      </span>
                    </div>
                  </div>

                  {/* Location & Custody Info */}
                  <div className="space-y-1.5 text-xs text-slate-600 font-medium">
                    <div className="flex items-center gap-1.5 truncate">
                      <MapPin size={13} className="text-amber-500 shrink-0" />
                      <span className="text-slate-400 font-normal">الموقع الحالي:</span>
                      <span className="font-bold text-slate-800 truncate">{asset.currentLocation}</span>
                    </div>
                    {asset.custodyPerson && (
                      <div className="flex items-center gap-1.5 truncate">
                        <User size={13} className="text-sky-500 shrink-0" />
                        <span className="text-slate-400 font-normal">العهدة / المسؤول:</span>
                        <span className="font-bold text-slate-800 truncate">{asset.custodyPerson}</span>
                      </div>
                    )}
                    {asset.supplierName && (
                      <div className="flex items-center gap-1.5 truncate">
                        <Truck size={13} className="text-emerald-500 shrink-0" />
                        <span className="text-slate-400 font-normal">المورد / البائع:</span>
                        <span className="font-bold text-slate-800 truncate">{asset.supplierName}</span>
                      </div>
                    )}
                  </div>

                </div>

                {/* Card Action Footer */}
                <div className="pt-4 mt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                  <button
                    type="button"
                    onClick={() => setSelectedAssetId(asset.id)}
                    className="flex-1 py-1.5 px-3 bg-amber-50 hover:bg-amber-100 text-amber-900 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <History size={14} />
                    <span>سجل الحركات والعهدة {movementsCount > 0 ? `(${movementsCount})` : ''}</span>
                  </button>

                  {sharedRole !== 'read' && (
                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => handleOpenEditModal(asset)}
                        title="تعديل بيانات الأصل"
                        className="p-1.5 text-slate-500 hover:text-amber-600 hover:bg-amber-50 rounded-lg transition-colors cursor-pointer"
                      >
                        <Pencil size={15} />
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          if (confirm(`هل أنت متأكد من حذف الأصل "${asset.name}" نهائياً من سجلات الشركة؟`)) {
                            onDeleteAsset(asset.id);
                          }
                        }}
                        title="حذف الأصل"
                        className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                      >
                        <Trash2 size={15} />
                      </button>
                    </div>
                  )}
                </div>

              </div>
            );
          })}
        </div>
      )}
      </div>
      )}

      {/* ======================= ADD / EDIT ASSET MODAL ======================= */}
      {(showAddModal || !!editingAsset) && (
        <div 
          className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-fade-in overflow-y-auto overscroll-contain"
          onClick={() => {
            setShowAddModal(false);
            setEditingAsset(null);
          }}
          onTouchMove={(e) => {
            if (e.target === e.currentTarget) e.preventDefault();
          }}
        >
          <div 
            className="bg-white w-full max-w-xl rounded-3xl shadow-2xl border border-slate-200 overflow-hidden my-auto max-h-[92vh] sm:max-h-[88vh] flex flex-col modal-dialog-card overscroll-contain touch-pan-y"
            onClick={e => e.stopPropagation()}
          >
            
            {/* Modal Header */}
            <div className="bg-gradient-to-r from-amber-600 to-amber-700 p-4 sm:p-5 text-white flex items-center justify-between shrink-0">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-white/20 rounded-xl text-white">
                  <Boxes size={20} />
                </div>
                <div>
                  <h3 className="text-base sm:text-lg font-black">
                    {editingAsset ? 'تعديل بيانات أصل / مادة' : 'إضافة أصل / مادة جديدة للشركة'}
                  </h3>
                  <p className="text-xs text-amber-100 font-medium">
                    تسجيل بيانات الأصل وقيمة الشراء والموقع الحالي والعهدة
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  setShowAddModal(false);
                  setEditingAsset(null);
                }}
                className="p-1.5 rounded-full hover:bg-white/20 text-white transition-colors cursor-pointer"
              >
                <X size={20} />
              </button>
            </div>

            {/* Modal Form */}
            <div className="flex-1 overflow-hidden flex flex-row min-h-0 relative">
              <form onSubmit={handleSaveAssetSubmit} className="p-4 sm:p-6 space-y-4 overflow-y-auto flex-1 min-h-0 overscroll-contain touch-pan-y custom-scrollbar modal-scroll-area">
                
                {formError && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs font-bold text-rose-700 flex items-center gap-2">
                  <AlertTriangle size={16} className="shrink-0" />
                  <span>{formError}</span>
                </div>
              )}

              {/* Asset Name */}
              <div className="space-y-1">
                <label className="block text-xs font-bold text-slate-700">
                  اسم الأصل / المادة / المعدة <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  placeholder="مثال: خلاطة خرسانة ياباني 1 كيس، رافعة ونش، 500 لوح بليوت..."
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-semibold text-slate-900 focus:outline-hidden focus:border-amber-500 focus:bg-white"
                />
              </div>

              {/* Category & Condition */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="block text-xs font-bold text-slate-700">
                    تصنيف وفئة الأصل <span className="text-rose-500">*</span>
                  </label>
                  <select
                    value={formCategory}
                    onChange={(e) => setFormCategory(e.target.value as AssetCategory)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-hidden focus:border-amber-500 focus:bg-white cursor-pointer"
                  >
                    {ASSET_CATEGORIES.map(cat => (
                      <option key={cat.key} value={cat.key}>{cat.label}</option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="block text-xs font-bold text-slate-700">
                    الحالة التشغيلية <span className="text-rose-500">*</span>
                  </label>
                  <select
                    value={formCondition}
                    onChange={(e) => setFormCondition(e.target.value as AssetCondition)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-hidden focus:border-amber-500 focus:bg-white cursor-pointer"
                  >
                    {ASSET_CONDITIONS.map(cond => (
                      <option key={cond.key} value={cond.key}>{cond.label}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Quantity, Unit & Purchase Date */}
              <div className="grid grid-cols-3 gap-2.5">
                <div className="space-y-1">
                  <label className="block text-xs font-bold text-slate-700">
                    الكمية <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="number"
                    min="1"
                    step="any"
                    required
                    value={formQuantity}
                    onChange={(e) => setFormQuantity(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 focus:outline-hidden focus:border-amber-500 focus:bg-white text-center"
                  />
                </div>

                <div className="space-y-1">
                  <label className="block text-xs font-bold text-slate-700">
                    الوحدة
                  </label>
                  <input
                    type="text"
                    value={formUnit}
                    onChange={(e) => setFormUnit(e.target.value)}
                    placeholder="عدد، طن، متر..."
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:outline-hidden focus:border-amber-500 focus:bg-white text-center"
                  />
                </div>

                <div className="space-y-1">
                  <label className="block text-xs font-bold text-slate-700">
                    تاريخ الشراء <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="date"
                    required
                    value={formPurchaseDate}
                    onChange={(e) => setFormPurchaseDate(e.target.value)}
                    className="w-full px-2.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:outline-hidden focus:border-amber-500 focus:bg-white"
                  />
                </div>
              </div>

              {/* Purchase Price & Currency */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="sm:col-span-2 space-y-1">
                  <label className="block text-xs font-bold text-slate-700">
                    إجمالي تكلفة الشراء / القيمة <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="number"
                    min="0"
                    step="any"
                    required
                    value={formPurchasePrice}
                    onChange={(e) => setFormPurchasePrice(e.target.value)}
                    placeholder="0.00"
                    className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-bold text-slate-900 focus:outline-hidden focus:border-amber-500 focus:bg-white text-left dir-ltr"
                  />
                  {Number(formPurchasePrice) > 0 && (
                    <AmountInWords amount={Number(formPurchasePrice)} currency={formCurrency} />
                  )}
                </div>

                <div className="space-y-1">
                  <label className="block text-xs font-bold text-slate-700">
                    العملة <span className="text-rose-500">*</span>
                  </label>
                  <select
                    value={formCurrency}
                    onChange={(e) => setFormCurrency(e.target.value as any)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-hidden focus:border-amber-500 focus:bg-white cursor-pointer"
                  >
                    <option value="YER">ريال يمني (YER)</option>
                    <option value="SAR">ريال سعودي (SAR)</option>
                    <option value="USD">دولار أمريكي (USD)</option>
                  </select>
                </div>
              </div>

              {/* Current Location & Project Assignment */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="block text-xs font-bold text-slate-700">
                    الموقع الحالي / مكان التواجد
                  </label>
                  <input
                    type="text"
                    value={formCurrentLocation}
                    onChange={(e) => setFormCurrentLocation(e.target.value)}
                    placeholder="مثال: المخزن العام، موقع مشروع البرج..."
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:outline-hidden focus:border-amber-500 focus:bg-white"
                  />
                </div>

                {projects.length > 0 && (
                  <div className="space-y-1">
                    <label className="block text-xs font-bold text-slate-700">
                      تخصيص لمشروع معين (اختياري)
                    </label>
                    <select
                      value={formProjectId}
                      onChange={(e) => {
                        const pid = e.target.value;
                        setFormProjectId(pid);
                        if (pid) {
                          const proj = projects.find(p => p.id === pid);
                          if (proj) setFormCurrentLocation(`مشروع ${proj.name}`);
                        }
                      }}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-hidden focus:border-amber-500 focus:bg-white cursor-pointer"
                    >
                      <option value="">ملك عام للشركة (غير مخصص لمشروع)</option>
                      {projects.map(p => (
                        <option key={p.id} value={p.id}>{p.name}</option>
                      ))}
                    </select>
                  </div>
                )}
              </div>

              {/* Custody Person & Supplier Name */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="block text-xs font-bold text-slate-700">
                    المسؤول عن العهدة / المستلم
                  </label>
                  <input
                    type="text"
                    list="employees_list"
                    value={formCustodyPerson}
                    onChange={(e) => setFormCustodyPerson(e.target.value)}
                    placeholder="اسم المهندس / المشرف / السائق..."
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:outline-hidden focus:border-amber-500 focus:bg-white"
                  />
                  <datalist id="employees_list">
                    {employees.map(emp => (
                      <option key={emp.id} value={emp.name}>{emp.profession ? `(${emp.profession})` : ''}</option>
                    ))}
                  </datalist>
                </div>

                <div className="space-y-1">
                  <label className="block text-xs font-bold text-slate-700">
                    المورد / جهة الشراء
                  </label>
                  <input
                    type="text"
                    list="suppliers_list"
                    value={formSupplierName}
                    onChange={(e) => setFormSupplierName(e.target.value)}
                    placeholder="اسم المورد أو الشركة البائعة..."
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:outline-hidden focus:border-amber-500 focus:bg-white"
                  />
                  <datalist id="suppliers_list">
                    {suppliers.map(s => (
                      <option key={s.id} value={s.name}>{s.material ? `(${s.material})` : ''}</option>
                    ))}
                  </datalist>
                </div>
              </div>

              {/* Serial & Invoice Numbers */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="block text-xs font-bold text-slate-700">
                    الرقم التسلسلي / كود الأصل (Serial Number)
                  </label>
                  <input
                    type="text"
                    value={formSerialNumber}
                    onChange={(e) => setFormSerialNumber(e.target.value)}
                    placeholder="مثال: AST-2026-001"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:outline-hidden focus:border-amber-500 focus:bg-white text-left dir-ltr"
                  />
                </div>

                <div className="space-y-1">
                  <label className="block text-xs font-bold text-slate-700">
                    رقم الفاتورة / سند الشراء
                  </label>
                  <input
                    type="text"
                    value={formInvoiceNumber}
                    onChange={(e) => setFormInvoiceNumber(e.target.value)}
                    placeholder="مثال: INV-9902"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:outline-hidden focus:border-amber-500 focus:bg-white"
                  />
                </div>
              </div>

              {/* Specifications & Notes */}
              <div className="space-y-1">
                <label className="block text-xs font-bold text-slate-700">
                  مواصفات فنية وملاحظات إضافية
                </label>
                <textarea
                  rows={2}
                  value={formNotes}
                  onChange={(e) => setFormNotes(e.target.value)}
                  placeholder="أي مواصفات تقنية، رقم الموتور، حالة الضمان، أو تعليمات الصيانة..."
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-900 focus:outline-hidden focus:border-amber-500 focus:bg-white resize-none"
                />
              </div>

              {/* Action Buttons */}
              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setShowAddModal(false);
                    setEditingAsset(null);
                  }}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition-colors cursor-pointer"
                >
                  إلغاء
                </button>

                <button
                  type="submit"
                  className="px-5 py-2 bg-amber-600 hover:bg-amber-500 text-white rounded-xl text-xs font-black shadow-md shadow-amber-600/20 transition-all cursor-pointer"
                >
                  {editingAsset ? 'حفظ التعديلات' : 'إضافة الأصل'}
                </button>
              </div>

            </form>

            <DraggableScrollIndicator
              variant="amber"
              title="مسار السحب والتنقل الفوري في استمارة الأصل"
              className="border-r border-slate-200/80 bg-slate-50/80 py-2"
            />
          </div>

          </div>
        </div>
      )}

      {/* ======================= ASSET DETAILS & MOVEMENTS LOG MODAL ======================= */}
      {selectedAsset && (
        <div 
          className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-fade-in overflow-y-auto overscroll-contain"
          onClick={() => setSelectedAssetId(null)}
          onTouchMove={(e) => {
            if (e.target === e.currentTarget) e.preventDefault();
          }}
        >
          <div 
            className="bg-white w-full max-w-2xl rounded-3xl shadow-2xl border border-slate-200 overflow-hidden my-auto max-h-[92vh] sm:max-h-[88vh] flex flex-col modal-dialog-card overscroll-contain touch-pan-y"
            onClick={e => e.stopPropagation()}
          >
            
            {/* Modal Header */}
            <div className="bg-slate-900 p-4 sm:p-5 text-white flex items-center justify-between shrink-0">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-amber-500/20 text-amber-400 rounded-xl border border-amber-500/30">
                  {renderCategoryIcon(selectedAsset.category, 22)}
                </div>
                <div>
                  <h3 className="text-base sm:text-lg font-black text-white">
                    {selectedAsset.name}
                  </h3>
                  <div className="flex items-center gap-2 text-xs text-slate-300 font-bold mt-0.5">
                    <span>{getAssetCategoryInfo(selectedAsset.category).label}</span>
                    <span>•</span>
                    <span className="text-amber-400 font-black">{formatCurrency(selectedAsset.purchasePrice, selectedAsset.currency)}</span>
                  </div>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setSelectedAssetId(null)}
                className="p-1.5 rounded-full hover:bg-slate-800 text-slate-300 hover:text-white transition-colors cursor-pointer"
              >
                <X size={20} />
              </button>
            </div>

            {/* Modal Content */}
            <div className="flex-1 overflow-hidden flex flex-row min-h-0 relative">
              <div className="p-4 sm:p-6 space-y-4 overflow-y-auto flex-1 overscroll-contain touch-pan-y custom-scrollbar modal-scroll-area">
              
              {/* Asset Specs Overview Card */}
              <div className="bg-slate-50 rounded-2xl p-3.5 border border-slate-200/80 grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                <div>
                  <span className="text-slate-400 font-normal block">الكمية والوحدة:</span>
                  <span className="font-bold text-slate-800">{selectedAsset.quantity} {selectedAsset.unit}</span>
                </div>
                <div>
                  <span className="text-slate-400 font-normal block">الحالة التشغيلية:</span>
                  <span className="font-bold text-slate-800">{getAssetConditionInfo(selectedAsset.condition).label}</span>
                </div>
                <div>
                  <span className="text-slate-400 font-normal block">الموقع الحالي:</span>
                  <span className="font-bold text-slate-800">{selectedAsset.currentLocation}</span>
                </div>
                <div>
                  <span className="text-slate-400 font-normal block">العهدة / المسؤول:</span>
                  <span className="font-bold text-slate-800">{selectedAsset.custodyPerson || '-'}</span>
                </div>
              </div>

              {/* Movement / Custody / Maintenance Section Header */}
              <div className="flex items-center justify-between pt-2">
                <div className="flex items-center gap-2">
                  <History size={18} className="text-amber-600" />
                  <h4 className="text-sm font-black text-slate-900">سجل التحويلات والعهدة والصيانة</h4>
                </div>

                {sharedRole !== 'read' && (
                  <button
                    type="button"
                    onClick={() => {
                      setMovType('transfer');
                      setMovDate(new Date().toISOString().split('T')[0]);
                      setMovToLocation(selectedAsset.currentLocation);
                      setMovToCustody(selectedAsset.custodyPerson || '');
                      setMovCost('');
                      setMovDescription('');
                      setMovNotes('');
                      setMovError('');
                      setShowMovementModal(true);
                    }}
                    className="bg-amber-600 hover:bg-amber-500 text-white font-bold px-3 py-1.5 rounded-xl text-xs flex items-center gap-1 shadow-xs cursor-pointer"
                  >
                    <PlusCircle size={14} />
                    <span>تسجيل نقل / صيانة / عهدة</span>
                  </button>
                )}
              </div>

              {/* Movements List */}
              {(!selectedAsset.movements || selectedAsset.movements.length === 0) ? (
                <div className="bg-slate-50/70 rounded-2xl p-6 border border-dashed border-slate-200 text-center text-xs text-slate-500">
                  <Activity size={24} className="mx-auto text-slate-400 mb-1.5" />
                  <span>لا توجد حركات أو سجلات صيانة مسجلة لهذا الأصل بعد.</span>
                </div>
              ) : (
                <div className="space-y-2.5">
                  {selectedAsset.movements.map((mov, idx) => {
                    let typeBadge = { label: 'نقل موقع', bg: 'bg-indigo-50 text-indigo-700 border-indigo-200' };
                    if (mov.type === 'custody_change') {
                      typeBadge = { label: 'تغيير عهدة', bg: 'bg-sky-50 text-sky-700 border-sky-200' };
                    } else if (mov.type === 'maintenance') {
                      typeBadge = { label: 'صيانة وإصلاح', bg: 'bg-amber-50 text-amber-700 border-amber-200' };
                    } else if (mov.type === 'status_change') {
                      typeBadge = { label: 'تحديث حالة', bg: 'bg-slate-100 text-slate-700 border-slate-200' };
                    }

                    return (
                      <div key={mov.id || idx} className="bg-white rounded-2xl p-3 border border-slate-200 shadow-xs flex items-start justify-between gap-3 text-xs">
                        <div className="space-y-1 flex-1">
                          <div className="flex items-center gap-2">
                            <span className={`px-2 py-0.5 rounded-md font-bold text-[10px] border ${typeBadge.bg}`}>
                              {typeBadge.label}
                            </span>
                            <span className="text-slate-400 font-semibold">{formatDateArabic(mov.date)}</span>
                            {mov.cost && mov.cost > 0 && (
                              <span className="font-bold text-rose-600 mr-auto">
                                تكلفة: {formatCurrency(mov.cost, mov.currency || selectedAsset.currency)}
                              </span>
                            )}
                          </div>

                          <p className="font-bold text-slate-800 leading-snug">{mov.description}</p>

                          {(mov.toLocation || mov.toCustody) && (
                            <div className="text-[11px] text-slate-500 flex flex-wrap items-center gap-3 pt-0.5">
                              {mov.toLocation && (
                                <span className="flex items-center gap-1">
                                  <MapPin size={11} className="text-amber-500" />
                                  إلى: <strong>{mov.toLocation}</strong>
                                </span>
                              )}
                              {mov.toCustody && (
                                <span className="flex items-center gap-1">
                                  <User size={11} className="text-sky-500" />
                                  المستلم: <strong>{mov.toCustody}</strong>
                                </span>
                              )}
                            </div>
                          )}

                          {mov.notes && (
                            <p className="text-[11px] text-slate-400 italic pt-0.5">{mov.notes}</p>
                          )}
                        </div>

                        {sharedRole !== 'read' && (
                          <button
                            type="button"
                            onClick={() => {
                              if (confirm('هل أنت متأكد من حذف هذا السجل؟')) {
                                onDeleteMovement(selectedAsset.id, mov.id);
                              }
                            }}
                            className="text-slate-400 hover:text-rose-600 p-1 cursor-pointer"
                          >
                            <Trash2 size={14} />
                          </button>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}

            </div>

            <DraggableScrollIndicator
              variant="slate"
              title="مسار السحب والتنقل الفوري في سجل كشف الأصل"
              className="border-r border-slate-200/80 bg-slate-50/80 py-2"
            />
          </div>

            {/* Modal Footer */}
            <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
              <button
                type="button"
                onClick={() => setSelectedAssetId(null)}
                className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-800 rounded-xl text-xs font-bold transition-colors cursor-pointer"
              >
                إغلاق
              </button>

              <button
                type="button"
                onClick={() => {
                  handleOpenEditModal(selectedAsset);
                  setSelectedAssetId(null);
                }}
                className="px-4 py-2 bg-amber-600 hover:bg-amber-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <Pencil size={14} />
                <span>تعديل بيانات الأصل</span>
              </button>
            </div>

          </div>
        </div>
      )}

      {/* ======================= RECORD MOVEMENT / MAINTENANCE MODAL ======================= */}
      {showMovementModal && selectedAsset && (
        <div 
          className="fixed inset-0 z-60 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-fade-in overflow-y-auto overscroll-contain"
          onClick={() => setShowMovementModal(false)}
          onTouchMove={(e) => {
            if (e.target === e.currentTarget) e.preventDefault();
          }}
        >
          <div 
            className="bg-white w-full max-w-lg rounded-3xl shadow-2xl border border-slate-200 overflow-hidden my-auto max-h-[92vh] sm:max-h-[88vh] flex flex-col modal-dialog-card overscroll-contain touch-pan-y"
            onClick={e => e.stopPropagation()}
          >
            
            {/* Header */}
            <div className="bg-gradient-to-r from-amber-600 to-amber-700 p-4 text-white flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2.5">
                <ArrowRightLeft size={18} />
                <h3 className="text-sm sm:text-base font-black">
                  تسجيل حركة / صيانة / عهدة لـ ({selectedAsset.name})
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setShowMovementModal(false)}
                className="p-1 rounded-full hover:bg-white/20 text-white cursor-pointer"
              >
                <X size={18} />
              </button>
            </div>

            {/* Movement Form */}
            <div className="flex-1 overflow-hidden flex flex-row min-h-0 relative">
              <form onSubmit={handleSaveMovementSubmit} className="p-4 sm:p-5 space-y-3.5 overflow-y-auto flex-1 overscroll-contain touch-pan-y custom-scrollbar modal-scroll-area">
                
                {movError && (
                <div className="p-2.5 bg-rose-50 border border-rose-200 rounded-xl text-xs font-bold text-rose-700">
                  {movError}
                </div>
              )}

              {/* Movement Type & Date */}
              <div className="grid grid-cols-2 gap-2.5">
                <div className="space-y-1">
                  <label className="block text-xs font-bold text-slate-700">نوع الإجراء</label>
                  <select
                    value={movType}
                    onChange={(e) => setMovType(e.target.value as any)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 cursor-pointer"
                  >
                    <option value="transfer">نقل إلى موقع / مشروع</option>
                    <option value="custody_change">تسليم / تغيير العهدة</option>
                    <option value="maintenance">صيانة دورية / إصلاح</option>
                    <option value="status_change">تحديث الحالة التشغيلية</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="block text-xs font-bold text-slate-700">تاريخ الإجراء</label>
                  <input
                    type="date"
                    required
                    value={movDate}
                    onChange={(e) => setMovDate(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900"
                  />
                </div>
              </div>

              {/* Description */}
              <div className="space-y-1">
                <label className="block text-xs font-bold text-slate-700">
                  بيان وتفاصيل الإجراء <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={movDescription}
                  onChange={(e) => setMovDescription(e.target.value)}
                  placeholder="مثال: نقل الخلاطة إلى موقع مشروع الفلل، صيانة وتغيير زيوت وفلاتر..."
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-semibold text-slate-900"
                />
              </div>

              {/* Location & Custody Targets */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <div className="space-y-1">
                  <label className="block text-xs font-bold text-slate-700">الموقع الجديد (إن وجد)</label>
                  <input
                    type="text"
                    value={movToLocation}
                    onChange={(e) => setMovToLocation(e.target.value)}
                    placeholder={selectedAsset.currentLocation}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900"
                  />
                </div>

                <div className="space-y-1">
                  <label className="block text-xs font-bold text-slate-700">المستلم / العهدة الجديدة</label>
                  <input
                    type="text"
                    value={movToCustody}
                    onChange={(e) => setMovToCustody(e.target.value)}
                    placeholder={selectedAsset.custodyPerson || 'اسم المستلم'}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900"
                  />
                </div>
              </div>

              {/* Cost (for maintenance/transport) */}
              <div className="space-y-1">
                <label className="block text-xs font-bold text-slate-700">
                  التكلفة والمصروفات المترتبة (إن وجدت)
                </label>
                <input
                  type="number"
                  min="0"
                  step="any"
                  value={movCost}
                  onChange={(e) => setMovCost(e.target.value)}
                  placeholder="0.00"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 text-left dir-ltr"
                />
              </div>

              {/* Notes */}
              <div className="space-y-1">
                <label className="block text-xs font-bold text-slate-700">ملاحظات إضافية</label>
                <input
                  type="text"
                  value={movNotes}
                  onChange={(e) => setMovNotes(e.target.value)}
                  placeholder="أي ملاحظات أو رقم سند صرف..."
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900"
                />
              </div>

              {/* Buttons */}
              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowMovementModal(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold cursor-pointer"
                >
                  إلغاء
                </button>

                <button
                  type="submit"
                  className="px-5 py-2 bg-amber-600 hover:bg-amber-500 text-white rounded-xl text-xs font-black shadow-xs cursor-pointer"
                >
                  حفظ الإجراء
                </button>
              </div>

            </form>

            <DraggableScrollIndicator
              variant="amber"
              title="مسار السحب والتنقل الفوري في حركة الأصل"
              className="border-r border-slate-200/80 bg-slate-50/80 py-2"
            />
          </div>

          </div>
        </div>
      )}

    </div>
  );
};

export default CompanyAssets;
