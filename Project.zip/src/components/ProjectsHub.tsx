/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { 
  Building2, 
  Plus, 
  Search, 
  MapPin, 
  User, 
  Calendar, 
  TrendingUp, 
  DollarSign, 
  Users, 
  Truck, 
  CheckCircle2, 
  Clock, 
  PauseCircle, 
  Edit3, 
  Trash2, 
  Copy, 
  ArrowRight, 
  FileSpreadsheet, 
  Printer, 
  Briefcase, 
  Star,
  Award,
  FileText,
  AlertCircle,
  Cloud,
  Share2,
  Lock,
  Unlock,
  RefreshCw,
  Phone,
  Layers,
  Home,
  Landmark,
  Wrench,
  Warehouse,
  HardHat,
  ArrowLeftRight,
  Check,
  Globe,
  Database,
  Download,
  Upload,
  FileJson,
  ShieldCheck,
  HardDrive,
  Info,
  Save,
  AlertTriangle,
  RotateCcw,
  Boxes,
  ArrowDown
} from 'lucide-react';
import { Project, formatCurrency, exportToXLSX, printPDF, COMPANY_LOGO_BASE64, getFormattedReportDate, ensureDateInFilename, GeneralDebt, GeneralDebtPayment } from '../types';
import { useBodyScrollLock } from '../utils/modalScrollLock';
import PageHeaderCard from './PageHeaderCard';
import OptionsMenu from './OptionsMenu';

interface ProjectsHubProps {
  projects: Project[];
  activeProjectId: string;
  onSelectProject: (id: string) => void;
  onCreateProject: (newProj: Omit<Project, 'id' | 'createdAt' | 'updatedAt'>) => void;
  onUpdateProject: (proj: Project) => void;
  onDeleteProject: (id: string) => void;
  onDuplicateProject: (id: string) => void;
  currency?: string;
  companyName?: string;
  companyAddress?: string;
  companyPhone?: string;
  designerName?: string;
  designerPhone?: string;
  projectId?: string;
  sharedRole?: string;
  syncStatus?: 'idle' | 'loading' | 'success' | 'error';
  onCreateShareLink?: (role?: 'read' | 'add' | 'full') => Promise<string>;
  onSetProjectId?: (id: string) => void;
  onCancelCloudSync?: () => Promise<void> | void;
  onMigrateEntity?: (params: {
    sourceProjectId: string;
    targetProjectId: string;
    entityType: 'worker' | 'employee' | 'supplier';
    entityId: string;
    includeLedger: boolean;
  }) => void;
  onRestoreAllProjects?: (
    data: { projects: Project[]; settings?: any; externalDebts?: any[] },
    mode: 'overwrite' | 'merge'
  ) => void;
  onRestoreOwnerRole?: () => void;
  setActiveTab?: (tab: string) => void;
  generalDebts?: GeneralDebt[];
  onAddGeneralDebt?: (debt: Omit<GeneralDebt, 'id' | 'payments' | 'createdAt' | 'updatedAt' | 'status'>) => void;
  onUpdateGeneralDebt?: (id: string, updatedData: Partial<GeneralDebt>) => void;
  onDeleteGeneralDebt?: (id: string) => void;
  onAddGeneralDebtPayment?: (debtId: string, payment: Omit<GeneralDebtPayment, 'id' | 'createdAt'>) => void;
  onDeleteGeneralDebtPayment?: (debtId: string, paymentId: string) => void;
  currentUser?: string;
}

export default function ProjectsHub({
  projects,
  activeProjectId,
  onSelectProject,
  onCreateProject,
  onUpdateProject,
  onDeleteProject,
  onDuplicateProject,
  currency = 'YER',
  companyName = 'ورلد أوف إيليتس للتجارة والمقاولات',
  companyAddress = '',
  companyPhone = '',
  designerName = 'م/ ياسر عقيل',
  designerPhone = '771999911',
  projectId,
  sharedRole,
  syncStatus,
  onCreateShareLink,
  onSetProjectId,
  onCancelCloudSync,
  onMigrateEntity,
  onRestoreAllProjects,
  onRestoreOwnerRole,
  setActiveTab,
  generalDebts = [],
  onAddGeneralDebt,
  onUpdateGeneralDebt,
  onDeleteGeneralDebt,
  onAddGeneralDebtPayment,
  onDeleteGeneralDebtPayment,
  currentUser = 'المدير'
}: ProjectsHubProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'planning' | 'paused' | 'completed'>('all');
  
  // Modal states
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [editingProject, setEditingProject] = useState<Project | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  // Migration Modal State
  const [showMigrationModal, setShowMigrationModal] = useState(false);
  const [migrationError, setMigrationError] = useState('');
  const projectBackupFileInputRef = useRef<HTMLInputElement>(null);
  const optionsBackupFileInputRef = useRef<HTMLInputElement>(null);

  // Lock background scroll when any ProjectsHub modal is open
  useBodyScrollLock(Boolean(showCreateModal || editingProject || deleteConfirmId || showMigrationModal));

  // Export / Backup Single Project JSON
  const handleBackupSingleProject = (proj: Project) => {
    try {
      const fullProj: Project = {
        ...proj,
        budget: Array.isArray(proj.budget) ? proj.budget : [],
        workers: Array.isArray(proj.workers) ? proj.workers : [],
        employees: Array.isArray(proj.employees) ? proj.employees : [],
        suppliers: Array.isArray(proj.suppliers) ? proj.suppliers : [],
        expenses: Array.isArray(proj.expenses) ? proj.expenses : [],
        contractItems: Array.isArray(proj.contractItems) ? proj.contractItems : []
      };

      const backupPayload = {
        version: '2.0',
        type: 'single_project_backup',
        exportedAt: new Date().toISOString(),
        exportedBy: currentUser || 'المدير',
        companyName: companyName || '',
        projectName: fullProj.name,
        project: fullProj
      };

      const jsonStr = JSON.stringify(backupPayload, null, 2);
      const blob = new Blob([jsonStr], { type: 'application/json;charset=utf-8' });
      const url = URL.createObjectURL(blob);

      const safeProjName = (fullProj.name || 'مشروع').trim().replace(/[\\/:*?"<>|]/g, '_');
      const filename = ensureDateInFilename(`نسخة_احتياطية_مشروع_${safeProjName}`) + '.json';

      const link = document.createElement('a');
      link.href = url;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      if (typeof window !== 'undefined' && (window as any).showToast) {
        (window as any).showToast(`✅ تم إنشاء وتنزيل نسخة احتياطية لمشروع "${fullProj.name}" بنجاح!`);
      }
    } catch (err) {
      console.error('Error creating single project backup:', err);
      alert('حدث خطأ أثناء تنزيل النسخة الاحتياطية للمشروع!');
    }
  };

  // Import single project backup JSON
  const handleImportSingleProjectBackupJSON = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const content = event.target?.result as string;
        const parsed = JSON.parse(content);

        // Case 0: Direct single project backup with `project` object
        if (parsed.project && typeof parsed.project === 'object') {
          const p = parsed.project;
          const importedName = p.name || parsed.projectName || 'مشروع مستورد من نسخة احتياطية';
          const newProjectObj: Omit<Project, 'id' | 'createdAt' | 'updatedAt'> = {
            name: importedName,
            location: p.location || '',
            client: p.client || 'العميل الرئيسي',
            status: p.status || 'active',
            startDate: p.startDate || new Date().toISOString().split('T')[0],
            endDate: p.endDate || '',
            notes: p.notes || 'مستورد من ملف نسخة احتياطية (.json)',
            budget: Array.isArray(p.budget) ? p.budget : [],
            workers: Array.isArray(p.workers) ? p.workers : [],
            employees: Array.isArray(p.employees) ? p.employees : [],
            suppliers: Array.isArray(p.suppliers) ? p.suppliers : [],
            expenses: Array.isArray(p.expenses) ? p.expenses : [],
            contractItems: Array.isArray(p.contractItems) ? p.contractItems : []
          };
          onCreateProject(newProjectObj);
          setShowCreateModal(false);
          if (typeof window !== 'undefined' && (window as any).showToast) {
            (window as any).showToast(`✅ تم استيراد مشروع "${importedName}" من النسخة الاحتياطية بنجاح!`);
          }
          return;
        }

        // Case 1: Backup contains an array of projects (`projects`)
        if (Array.isArray(parsed.projects) && parsed.projects.length > 0) {
          let importedCount = 0;
          parsed.projects.forEach((proj: Project) => {
            onCreateProject({
              name: proj.name || 'مشروع مستورد',
              location: proj.location || '',
              client: proj.client || '',
              status: proj.status || 'active',
              startDate: proj.startDate || new Date().toISOString().split('T')[0],
              endDate: proj.endDate || '',
              notes: proj.notes || 'مستورد من نسخة احتياطية',
              budget: proj.budget || [],
              workers: proj.workers || [],
              employees: proj.employees || [],
              suppliers: proj.suppliers || [],
              expenses: proj.expenses || [],
              contractItems: proj.contractItems || []
            });
            importedCount++;
          });
          setShowCreateModal(false);
          if (typeof window !== 'undefined' && (window as any).showToast) {
            (window as any).showToast(`✅ تم استيراد ${importedCount} مشروع من النسخة الاحتياطية بنجاح!`);
          }
          return;
        }

        // Case 2: Single project data or legacy backup format (parsed.data || parsed)
        const payloadData = parsed.data || parsed;
        const payloadSettings = parsed.settings || {};

        const importedName =
          parsed.name ||
          payloadSettings.projectName ||
          payloadData.projectName ||
          file.name.replace(/\.json$/i, '').replace(/^نسخة_احتياطية_مشروع_/, '').replace(/^نسخة_احتياطية_شاملة_/, '').replace(/^نسخة_احتياطية_/, '') ||
          'مشروع مستورد من نسخة احتياطية';

        const newProjectObj: Omit<Project, 'id' | 'createdAt' | 'updatedAt'> = {
          name: importedName,
          location: parsed.location || payloadSettings.companyAddress || payloadData.location || '',
          client: parsed.client || payloadData.client || 'العميل الرئيسي',
          status: parsed.status || payloadData.status || 'active',
          startDate: parsed.startDate || payloadData.startDate || new Date().toISOString().split('T')[0],
          endDate: parsed.endDate || payloadData.endDate || '',
          notes: parsed.notes || payloadData.notes || 'مستورد من ملف نسخة احتياطية (.json)',
          budget: Array.isArray(payloadData.budget) ? payloadData.budget : (Array.isArray(parsed.budget) ? parsed.budget : []),
          workers: Array.isArray(payloadData.workers) ? payloadData.workers : (Array.isArray(parsed.workers) ? parsed.workers : []),
          employees: Array.isArray(payloadData.employees) ? payloadData.employees : (Array.isArray(parsed.employees) ? parsed.employees : []),
          suppliers: Array.isArray(payloadData.suppliers) ? payloadData.suppliers : (Array.isArray(parsed.suppliers) ? parsed.suppliers : []),
          expenses: Array.isArray(payloadData.expenses) ? payloadData.expenses : (Array.isArray(parsed.expenses) ? parsed.expenses : []),
          contractItems: Array.isArray(payloadData.contractItems) ? payloadData.contractItems : (Array.isArray(parsed.contractItems) ? parsed.contractItems : [])
        };

        onCreateProject(newProjectObj);
        setShowCreateModal(false);
        if (typeof window !== 'undefined' && (window as any).showToast) {
          (window as any).showToast(`✅ تم استيراد مشروع "${importedName}" من النسخة الاحتياطية بنجاح!`);
        }
      } catch (err) {
        console.error('Error importing project backup JSON:', err);
        alert('⚠️ الملف المحدد غير صالح أو تالف! يرجى التأكد من اختيار ملف JSON صحيح مخصص لنسخة احتياطية للمشروع.');
      } finally {
        if (projectBackupFileInputRef.current) projectBackupFileInputRef.current.value = '';
        if (optionsBackupFileInputRef.current) optionsBackupFileInputRef.current.value = '';
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  // Migration Modal Form State
  const [migrationData, setMigrationData] = useState<{
    sourceProjectId: string;
    targetProjectId: string;
    entityType: 'worker' | 'employee' | 'supplier';
    entityId: string;
    includeLedger: boolean;
  }>({
    sourceProjectId: activeProjectId || (projects[0]?.id || ''),
    targetProjectId: projects.find(p => p.id !== (activeProjectId || projects[0]?.id))?.id || '',
    entityType: 'worker',
    entityId: '',
    includeLedger: false
  });

  // Keep migration target project strictly distinct from source project
  useEffect(() => {
    if (showMigrationModal && projects.length >= 2) {
      if (
        !migrationData.sourceProjectId ||
        !migrationData.targetProjectId ||
        migrationData.sourceProjectId === migrationData.targetProjectId ||
        !projects.some(p => p.id === migrationData.sourceProjectId) ||
        !projects.some(p => p.id === migrationData.targetProjectId)
      ) {
        const source = (activeProjectId && projects.some(p => p.id === activeProjectId))
          ? activeProjectId
          : projects[0].id;
        const target = projects.find(p => p.id !== source)?.id || '';
        setMigrationData(prev => ({
          ...prev,
          sourceProjectId: source,
          targetProjectId: target
        }));
      }
    }
  }, [showMigrationModal, projects, activeProjectId, migrationData.sourceProjectId, migrationData.targetProjectId]);

  // Form State for Create/Edit
  const [formData, setFormData] = useState({
    name: '',
    location: '',
    client: '',
    status: 'active' as 'active' | 'completed' | 'planning' | 'paused',
    startDate: new Date().toISOString().split('T')[0],
    endDate: '',
    initialBudgetAmount: '',
    notes: '',
    copyDataFromProjectId: ''
  });

  // Helper to render expressive project icon
  const getProjectExpressiveIcon = (projName: string, index: number) => {
    const nameLower = projName.toLowerCase();
    if (nameLower.includes('فيلا') || nameLower.includes('منزل') || nameLower.includes('بيت')) {
      return <Home size={22} className="text-amber-500 shrink-0" />;
    }
    if (nameLower.includes('برج') || nameLower.includes('طابق') || nameLower.includes('مجمع')) {
      return <Landmark size={22} className="text-purple-500 shrink-0" />;
    }
    if (nameLower.includes('طريق') || nameLower.includes('جسر') || nameLower.includes('زفلت') || nameLower.includes('بنية')) {
      return <Truck size={22} className="text-rose-500 shrink-0" />;
    }
    if (nameLower.includes('ترميم') || nameLower.includes('تشطيب') || nameLower.includes('ديكور')) {
      return <Wrench size={22} className="text-teal-500 shrink-0" />;
    }
    if (nameLower.includes('مخزن') || nameLower.includes('مستودع') || nameLower.includes('هنجر')) {
      return <Warehouse size={22} className="text-emerald-500 shrink-0" />;
    }

    // Default rotated icon set
    const icons = [
      <Building2 size={22} className="text-sky-500 shrink-0" />,
      <HardHat size={22} className="text-amber-500 shrink-0" />,
      <Landmark size={22} className="text-indigo-500 shrink-0" />,
      <Home size={22} className="text-emerald-500 shrink-0" />
    ];
    return icons[index % icons.length];
  };

  // Open Create Modal
  const handleOpenCreate = () => {
    setFormData({
      name: '',
      location: '',
      client: '',
      status: 'active',
      startDate: new Date().toISOString().split('T')[0],
      endDate: '',
      initialBudgetAmount: '',
      notes: '',
      copyDataFromProjectId: ''
    });
    setShowCreateModal(true);
  };

  // Open Edit Modal
  const handleOpenEdit = (proj: Project) => {
    setEditingProject(proj);
    const initialB = proj.budget.length > 0 ? proj.budget.reduce((acc, item) => acc + item.amount, 0) : '';
    setFormData({
      name: proj.name,
      location: proj.location || '',
      client: proj.client || '',
      status: proj.status,
      startDate: proj.startDate || new Date().toISOString().split('T')[0],
      endDate: proj.endDate || '',
      initialBudgetAmount: initialB ? String(initialB) : '',
      notes: proj.notes || '',
      copyDataFromProjectId: ''
    });
  };

  const handleResetProjectForm = () => {
    if (editingProject) {
      const initialB = editingProject.budget.length > 0 ? editingProject.budget.reduce((acc, item) => acc + item.amount, 0) : '';
      setFormData({
        name: editingProject.name,
        location: editingProject.location || '',
        client: editingProject.client || '',
        status: editingProject.status,
        startDate: editingProject.startDate || new Date().toISOString().split('T')[0],
        endDate: editingProject.endDate || '',
        initialBudgetAmount: initialB ? String(initialB) : '',
        notes: editingProject.notes || '',
        copyDataFromProjectId: ''
      });
    } else {
      setFormData({
        name: '',
        location: '',
        client: '',
        status: 'active',
        startDate: new Date().toISOString().split('T')[0],
        endDate: '',
        initialBudgetAmount: '',
        notes: '',
        copyDataFromProjectId: ''
      });
    }
  };

  // Submit Form (Create or Edit)
  const handleSubmitForm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim()) {
      alert('يرجى كتابة اسم المشروع أو موقع العمل');
      return;
    }

    if (editingProject) {
      // Update
      const updated: Project = {
        ...editingProject,
        name: formData.name.trim(),
        location: formData.location.trim(),
        client: formData.client.trim(),
        status: formData.status,
        startDate: formData.startDate,
        endDate: formData.endDate,
        notes: formData.notes.trim(),
        updatedAt: new Date().toISOString()
      };

      if (formData.initialBudgetAmount && !isNaN(Number(formData.initialBudgetAmount))) {
        const amt = Number(formData.initialBudgetAmount);
        if (updated.budget.length === 0) {
          updated.budget = [{
            id: 'bgt_' + Date.now(),
            date: formData.startDate || new Date().toISOString().split('T')[0],
            amount: amt,
            description: 'الميزانية المرصودة للمشروع',
            notes: 'تم تحديدها عند تعديل بيانات المشروع'
          }];
        }
      }

      onUpdateProject(updated);
      setEditingProject(null);
      if (typeof window !== 'undefined' && (window as any).showToast) {
        (window as any).showToast(`تم تحديث بيانات مشروع "${updated.name}" بنجاح!`);
      }
    } else {
      // Create New
      let baseWorkers: any[] = [];
      let baseEmployees: any[] = [];
      let baseSuppliers: any[] = [];

      if (formData.copyDataFromProjectId) {
        const sourceProj = projects.find(p => p.id === formData.copyDataFromProjectId);
        if (sourceProj) {
          baseWorkers = sourceProj.workers.map(w => ({ ...w, ledger: [] }));
          baseEmployees = sourceProj.employees.map(e => ({ ...e, ledger: [] }));
          baseSuppliers = sourceProj.suppliers.map(s => ({ ...s, ledger: [] }));
        }
      }

      const initialBudget = [];
      if (formData.initialBudgetAmount && !isNaN(Number(formData.initialBudgetAmount)) && Number(formData.initialBudgetAmount) > 0) {
        initialBudget.push({
          id: 'bgt_' + Date.now(),
          date: formData.startDate || new Date().toISOString().split('T')[0],
          amount: Number(formData.initialBudgetAmount),
          description: 'الميزانية المعتمدة لافتتاح المشروع',
          notes: 'ميزانية أولية مرصودة'
        });
      }

      onCreateProject({
        name: formData.name.trim(),
        location: formData.location.trim(),
        client: formData.client.trim(),
        status: formData.status,
        startDate: formData.startDate,
        endDate: formData.endDate,
        notes: formData.notes.trim(),
        budget: initialBudget,
        workers: baseWorkers,
        employees: baseEmployees,
        suppliers: baseSuppliers,
        expenses: []
      });

      setShowCreateModal(false);
      if (typeof window !== 'undefined' && (window as any).showToast) {
        (window as any).showToast(`تم إنشاء مشروع جديد ("${formData.name}") بنجاح!`);
      }
    }
  };

  // Open Migration Modal with safe initial values
  const handleOpenMigrationModal = () => {
    setMigrationError('');
    if (projects.length < 2) {
      if (typeof window !== 'undefined' && (window as any).showToast) {
        (window as any).showToast('⚠️ نقل الكوادر يتطلب وجود مشروعين مسجلين على الأقل');
      } else {
        alert('نقل الكوادر يتطلب وجود مشروعين مسجلين على الأقل في النظام. يرجى إنشاء مشروع ثانٍ أولاً.');
      }
      return;
    }

    const defaultSource = (activeProjectId && projects.some(p => p.id === activeProjectId))
      ? activeProjectId
      : projects[0].id;
    const defaultTarget = projects.find(p => p.id !== defaultSource)?.id || '';

    setMigrationData({
      sourceProjectId: defaultSource,
      targetProjectId: defaultTarget,
      entityType: 'worker',
      entityId: '',
      includeLedger: false
    });
    setShowMigrationModal(true);
  };

  // Change Source Project with automatic target project adjustment
  const handleSourceProjectChange = (newSourceId: string) => {
    setMigrationError('');
    setMigrationData(prev => {
      let nextTargetId = prev.targetProjectId;
      if (nextTargetId === newSourceId || !projects.some(p => p.id === nextTargetId && p.id !== newSourceId)) {
        const alt = projects.find(p => p.id !== newSourceId);
        nextTargetId = alt ? alt.id : '';
      }
      return {
        ...prev,
        sourceProjectId: newSourceId,
        targetProjectId: nextTargetId,
        entityId: '' // reset selected entity since source project changed
      };
    });
  };

  // Change Target Project
  const handleTargetProjectChange = (newTargetId: string) => {
    setMigrationError('');
    setMigrationData(prev => ({
      ...prev,
      targetProjectId: newTargetId
    }));
  };

  // Handle Submit Migration
  const handleExecuteMigration = (e: React.FormEvent) => {
    e.preventDefault();
    setMigrationError('');

    if (!migrationData.sourceProjectId || !migrationData.targetProjectId) {
      setMigrationError('الرجاء اختيار المشروع المصدر والمشروع الهدف');
      return;
    }
    if (migrationData.sourceProjectId === migrationData.targetProjectId) {
      setMigrationError('يرجى اختيار مشروعين مختلفين؛ لا يمكن نقل الكادر لنفس المشروع');
      return;
    }
    if (!migrationData.entityId) {
      setMigrationError('الرجاء تحديد الكادر أو الاسم المراد نقله أو تحويله');
      return;
    }

    if (onMigrateEntity) {
      onMigrateEntity(migrationData);
      setShowMigrationModal(false);
      setMigrationError('');
      if (typeof window !== 'undefined' && (window as any).showToast) {
        (window as any).showToast("تم تحويل ونقل الكادر إلى المشروع الهدف بنجاح!");
      }
    }
  };

  // Multi-Project Calculations
  const filteredProjects = projects.filter(proj => {
    const matchesSearch = 
      proj.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (proj.location && proj.location.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (proj.client && proj.client.toLowerCase().includes(searchTerm.toLowerCase()));
    
    const matchesStatus = statusFilter === 'all' || proj.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  // Sort projects so that active ('active') projects created first appear first, followed by others
  const sortedProjects = [...filteredProjects].sort((a, b) => {
    const aActive = a.status === 'active' ? 1 : 0;
    const bActive = b.status === 'active' ? 1 : 0;
    if (aActive !== bActive) {
      return bActive - aActive; // active projects first
    }
    const aTime = new Date(a.createdAt || 0).getTime();
    const bTime = new Date(b.createdAt || 0).getTime();
    return aTime - bTime; // created first comes first
  });

  const totalProjectsCount = projects.length;
  const activeProjectsCount = projects.filter(p => p.status === 'active').length;
  
  const consolidatedBudget = projects.reduce((sum, proj) => {
    return sum + (proj.budget || []).reduce((bSum, b) => bSum + (b.amount || 0), 0);
  }, 0);

  const consolidatedExpenses = projects.reduce((sum, proj) => {
    return sum + (proj.expenses || []).reduce((eSum, e) => eSum + (e.amount || 0), 0);
  }, 0);

  const consolidatedRemaining = consolidatedBudget - consolidatedExpenses;
  const totalWorkersCount = projects.reduce((sum, proj) => sum + (proj.workers || []).length, 0);
  const totalEmployeesCount = projects.reduce((sum, proj) => sum + (proj.employees || []).length, 0);

  // Status Badge Styling Helper
  const getStatusBadge = (status: Project['status']) => {
    switch (status) {
      case 'active':
        return {
          label: 'نشط وجاري العمل',
          bg: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40',
          icon: <Clock size={12} className="shrink-0 text-emerald-400" />
        };
      case 'completed':
        return {
          label: 'مكتمل ومسلم',
          bg: 'bg-sky-500/20 text-sky-300 border-sky-500/40',
          icon: <CheckCircle2 size={12} className="shrink-0 text-sky-400" />
        };
      case 'planning':
        return {
          label: 'قيد التخطيط',
          bg: 'bg-amber-500/20 text-amber-300 border-amber-500/40',
          icon: <Clock size={12} className="shrink-0 text-amber-400" />
        };
      case 'paused':
        return {
          label: 'متوقف مؤقتاً',
          bg: 'bg-slate-700/60 text-slate-300 border-slate-600/50',
          icon: <PauseCircle size={12} className="shrink-0 text-slate-400" />
        };
      default:
        return {
          label: 'نشط',
          bg: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40',
          icon: <Clock size={12} className="shrink-0 text-emerald-400" />
        };
    }
  };

  // Export Consolidated Multi-Project Excel
  const handleExportMultiProjectExcel = () => {
    const headers = [
      'اسم المشروع / موقع العمل',
      'حالة المشروع',
      'الموقع / المدينة',
      'العميل / المالك',
      'الميزانية المعتمدة',
      'إجمالي المصروفات',
      'الرصيد المتبقي',
      'نسبة الصرف %',
      'عدد العمال',
      'عدد الموظفين',
      'عدد الموردين',
      'تاريخ البدء'
    ];

    const rows = projects.map(p => {
      const bTotal = (p.budget || []).reduce((s, b) => s + b.amount, 0);
      const eTotal = (p.expenses || []).reduce((s, e) => s + e.amount, 0);
      const rem = bTotal - eTotal;
      const pct = bTotal > 0 ? ((eTotal / bTotal) * 100).toFixed(1) + '%' : '0%';
      const statusText = getStatusBadge(p.status).label;

      return [
        p.name,
        statusText,
        p.location || '-',
        p.client || '-',
        bTotal,
        eTotal,
        rem,
        pct,
        (p.workers || []).length,
        (p.employees || []).length,
        (p.suppliers || []).length,
        p.startDate || '-'
      ];
    });

    exportToXLSX('تقرير_المشاريع_المجمع_الشامل', headers, rows, 'المشاريع');
  };

  // Print Consolidated PDF
  const handlePrintMultiProjectPDF = () => {
    const tableRows = projects.map((p, idx) => {
      const bTotal = (p.budget || []).reduce((s, b) => s + b.amount, 0);
      const eTotal = (p.expenses || []).reduce((s, e) => s + e.amount, 0);
      const rem = bTotal - eTotal;
      const pct = bTotal > 0 ? ((eTotal / bTotal) * 100).toFixed(1) + '%' : '0%';

      return `
        <tr>
          <td style="text-align: center; width: 4%;">${idx + 1}</td>
          <td class="col-statement" style="width: 30%;"><strong>${p.name}</strong><br><small style="color: #64748b;">${p.location || ''}</small></td>
          <td style="text-align: center; width: 14%;">${getStatusBadge(p.status).label}</td>
          <td style="text-align: center; width: 14%;">${p.client || '-'}</td>
          <td style="text-align: left; color: #0284c7; font-weight: bold; width: 13%;">${formatCurrency(bTotal, currency)}</td>
          <td style="text-align: left; color: #e11d48; font-weight: bold; width: 13%;">${formatCurrency(eTotal, currency)}</td>
          <td style="text-align: left; color: ${rem >= 0 ? '#059669' : '#dc2626'}; font-weight: bold; width: 12%;">${formatCurrency(rem, currency)}</td>
          <td style="text-align: center; width: 8%;">${pct}</td>
        </tr>
      `;
    }).join('');

    const htmlContent = `
      <div style="margin-bottom: 20px;">
        <h2 style="font-size: 16px; font-weight: bold; color: #0f172a; margin-bottom: 8px;">تقرير ملخص الميزانية والمصروفات المجمعة لكافة المشاريع</h2>
        <p style="font-size: 12px; color: #475569; margin: 0;">يحتوي هذا التقرير على تفاصيل الميزانيات، المصروفات الفعلية، والأرصدة المتبقية لجميع مواقف وأعمال الشركات والمواقع.</p>
      </div>

      <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; margin-bottom: 20px; text-align: center;">
        <div style="border: 1px solid #cbd5e1; padding: 10px; border-radius: 8px; background-color: #f8fafc;">
          <small style="color: #64748b; font-weight: bold;">إجمالي المشاريع</small>
          <div style="font-size: 16px; font-weight: bold; color: #0f172a;">${totalProjectsCount}</div>
        </div>
        <div style="border: 1px solid #cbd5e1; padding: 10px; border-radius: 8px; background-color: #f0f9ff;">
          <small style="color: #0369a1; font-weight: bold;">الميزانية المجمعة</small>
          <div style="font-size: 15px; font-weight: bold; color: #0284c7;">${formatCurrency(consolidatedBudget, currency)}</div>
        </div>
        <div style="border: 1px solid #cbd5e1; padding: 10px; border-radius: 8px; background-color: #fff1f2;">
          <small style="color: #be123c; font-weight: bold;">إجمالي المصروفات</small>
          <div style="font-size: 15px; font-weight: bold; color: #e11d48;">${formatCurrency(consolidatedExpenses, currency)}</div>
        </div>
        <div style="border: 1px solid #cbd5e1; padding: 10px; border-radius: 8px; background-color: ${consolidatedRemaining >= 0 ? '#ecfdf5' : '#fef2f2'};">
          <small style="color: ${consolidatedRemaining >= 0 ? '#047857' : '#b91c1c'}; font-weight: bold;">الرصيد الصافي المتبقي</small>
          <div style="font-size: 15px; font-weight: bold; color: ${consolidatedRemaining >= 0 ? '#059669' : '#dc2626'};">${formatCurrency(consolidatedRemaining, currency)}</div>
        </div>
      </div>

      <table>
        <thead>
          <tr>
            <th style="width: 4%;">#</th>
            <th style="width: 30%;" class="col-statement">اسم المشروع / الموقع</th>
            <th style="width: 14%;">الحالة</th>
            <th style="width: 14%;">المالك / العميل</th>
            <th style="width: 13%;">الميزانية</th>
            <th style="width: 13%;">المصروفات</th>
            <th style="width: 12%;">المتبقي</th>
            <th style="width: 8%;">نسبة الصرف</th>
          </tr>
        </thead>
        <tbody>
          ${tableRows}
        </tbody>
      </table>
    `;

    printPDF('تقرير_المشاريع_المجمع_والاستراتيجي', htmlContent);
  };

  // Get active source project entities for migration dropdown
  const sourceProjectObj = projects.find(p => p.id === migrationData.sourceProjectId);
  const targetProjectObj = projects.find(p => p.id === migrationData.targetProjectId);

  return (
    <div className="space-y-6 dir-rtl text-right pb-12 animate-fade-in">
      
      {/* Hidden File Input for Options Menu Single Project Backup Import */}
      <input
        type="file"
        ref={optionsBackupFileInputRef}
        onChange={(e) => {
          handleImportSingleProjectBackupJSON(e);
          e.target.value = '';
        }}
        accept=".json"
        className="hidden"
      />

      {/* ======================= HEADER CARD ======================= */}
      <PageHeaderCard
        title="إدارة المشاريع الإنشائية"
        description="لوحة التحكم والمتابعة الشاملة لكافة المشاريع، الميزانيات المعتمدة، المصروفات، والكوادر الفنية"
        icon={<Building2 className="text-amber-500" size={24} />}
        onBack={setActiveTab ? () => {
          setActiveTab('main_hub');
          window.scrollTo({ top: 0, behavior: 'smooth' });
        } : undefined}
        optionsMenu={
          <OptionsMenu
            customActions={[
              {
                label: 'إضافة مشروع جديد',
                icon: <Plus size={15} className="text-amber-600 shrink-0" />,
                onClick: handleOpenCreate,
                className: 'text-amber-700 bg-amber-50/70 hover:bg-amber-100 hover:text-amber-800'
              },
              {
                label: 'استيراد مشروع من نسخة احتياطية',
                icon: <Upload size={15} className="text-emerald-600 shrink-0" />,
                onClick: () => {
                  if (optionsBackupFileInputRef.current) {
                    optionsBackupFileInputRef.current.value = '';
                    optionsBackupFileInputRef.current.click();
                  }
                },
                className: 'text-emerald-700 bg-emerald-50/70 hover:bg-emerald-100 hover:text-emerald-800 font-bold'
              }
            ]}
            onExportExcel={handleExportMultiProjectExcel}
            onExportPDF={handlePrintMultiProjectPDF}
            shareTitle="تقرير المشاريع المجمع والشامل"
            shareText={() => {
              const bYer = formatCurrency(consolidatedBudget, currency);
              const eYer = formatCurrency(consolidatedExpenses, currency);
              const remYer = formatCurrency(consolidatedRemaining, currency);
              return `🏗️ تقرير المشاريع الإنشائية المجمع:\n📊 إجمالي المشاريع: ${totalProjectsCount} (${activeProjectsCount} نشط)\n💵 الميزانية المعتمدة: ${bYer}\n💸 إجمالي المصروفات: ${eYer}\n💰 الرصيد الصافي المتبقي: ${remYer}\n👥 إجمالي الكوادر: ${totalWorkersCount + totalEmployeesCount}\n\n*تم الاستخراج من نظام إدارة المشاريع*`;
            }}
          />
        }
      />

      {/* ======================= QUICK ACCESS PROJECTS TAB BAR ======================= */}
      {projects && projects.length > 0 && (
        <div className="flex flex-wrap items-center gap-2 p-1.5 bg-slate-100/90 rounded-2xl border border-slate-200 shadow-2xs">
          {projects.map((proj) => {
            const isActive = proj.id === activeProjectId;
            return (
              <button
                key={proj.id}
                type="button"
                onClick={() => {
                  onSelectProject(proj.id);
                  if (setActiveTab) setActiveTab('dashboard');
                  window.scrollTo({ top: 0, behavior: 'instant' });
                  if (typeof window !== 'undefined' && (window as any).showToast) {
                    (window as any).showToast(`تم الانتقال إلى مشروع "${proj.name}"`);
                  }
                }}
                className={`flex-1 sm:flex-initial py-2.5 px-4 rounded-xl text-xs sm:text-sm font-black transition-all flex items-center justify-center cursor-pointer ${
                  isActive
                    ? 'bg-white text-slate-900 shadow-xs border border-slate-200/80'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
                }`}
                title={`انتقال إلى ${proj.name}`}
              >
                <span>{proj.name}</span>
              </button>
            );
          })}
        </div>
      )}

      {/* ======================= CONSOLIDATED FINANCIAL SUMMARY ======================= */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-2 sm:gap-3">
        
        {/* Total Projects Card */}
        <div className="bg-white rounded-2xl p-2.5 sm:p-3 border border-slate-200/80 shadow-xs hover:shadow-md transition-all">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-[11px] font-bold">إجمالي المشاريع</span>
            <div className="p-1.5 bg-indigo-50 text-indigo-600 rounded-lg">
              <Building2 size={16} />
            </div>
          </div>
          <div className="flex items-baseline gap-1.5">
            <span className="text-lg sm:text-xl font-black text-slate-900">{totalProjectsCount}</span>
            <span className="text-[10px] font-bold text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded-full">
              {activeProjectsCount} نشط
            </span>
          </div>
        </div>

        {/* Consolidated Budget */}
        <div className="bg-white rounded-2xl p-2.5 sm:p-3 border border-slate-200/80 shadow-xs hover:shadow-md transition-all">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-[11px] font-bold">الميزانية المجمعة</span>
            <div className="p-1.5 bg-sky-50 text-sky-600 rounded-lg">
              <DollarSign size={16} />
            </div>
          </div>
          <div className="text-base sm:text-lg font-black text-sky-700 truncate">
            {formatCurrency(consolidatedBudget, currency)}
          </div>
        </div>

        {/* Consolidated Expenses */}
        <div className="bg-white rounded-2xl p-2.5 sm:p-3 border border-slate-200/80 shadow-xs hover:shadow-md transition-all">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-[11px] font-bold">المصروفات المجمعة</span>
            <div className="p-1.5 bg-rose-50 text-rose-600 rounded-lg">
              <TrendingUp size={16} />
            </div>
          </div>
          <div className="text-base sm:text-lg font-black text-rose-600 truncate">
            {formatCurrency(consolidatedExpenses, currency)}
          </div>
        </div>

        {/* Consolidated Remaining Balance */}
        <div className="bg-white rounded-2xl p-2.5 sm:p-3 border border-slate-200/80 shadow-xs hover:shadow-md transition-all col-span-1">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-[11px] font-bold">الرصيد الصافي المتبقي</span>
            <div className={`p-1.5 rounded-lg ${consolidatedRemaining >= 0 ? 'bg-emerald-50 text-emerald-600' : 'bg-rose-50 text-rose-600'}`}>
              <DollarSign size={16} />
            </div>
          </div>
          <div className={`text-base sm:text-lg font-black truncate ${consolidatedRemaining >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
            {formatCurrency(consolidatedRemaining, currency)}
          </div>
        </div>

        {/* Total Workforce */}
        <div className="bg-white rounded-2xl p-2.5 sm:p-3 border border-slate-200/80 shadow-xs hover:shadow-md transition-all col-span-2 lg:col-span-1">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-[11px] font-bold">إجمالي الكوادر والعمال</span>
            <div className="p-1.5 bg-violet-50 text-violet-600 rounded-lg">
              <Users size={16} />
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-base sm:text-lg font-black text-slate-900">{totalWorkersCount + totalEmployeesCount}</span>
            <span className="text-[10px] font-bold text-slate-500">
              ({totalWorkersCount} عمال / {totalEmployeesCount} موظف)
            </span>
          </div>
        </div>

      </div>

      {/* ======================= MAIN PROJECTS MANAGEMENT DISPLAY PANEL ======================= */}
      <div className="bg-white rounded-3xl p-4 sm:p-6 border border-slate-200/90 shadow-sm space-y-5">
        
        {/* Panel Header Title */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-gradient-to-br from-amber-500 to-amber-600 text-white rounded-2xl shadow-md shadow-amber-500/20">
              <Building2 size={22} />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-black text-slate-900 tracking-tight">
                إدارة المشاريع الإنشائية
              </h2>
              <p className="text-xs text-slate-500 font-semibold mt-0.5">
                لوحة عرض والتحكم بكافة المشاريع الإنشائية والتنفيذية
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <button
              onClick={handleOpenCreate}
              className="bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white font-extrabold text-xs py-2 px-4 rounded-xl flex items-center gap-2 transition-all cursor-pointer shadow-sm shadow-amber-500/20 shrink-0 self-start sm:self-auto active:scale-95"
            >
              <Plus size={16} />
              <span>إضافة مشروع جديد</span>
            </button>
          </div>
        </div>

        {/* Search Input and Status Filters Bar */}
        <div className="bg-slate-50/80 rounded-2xl p-2.5 sm:p-3 border border-slate-200/80 flex flex-col md:flex-row items-center justify-between gap-2.5">
          
          {/* Search Input */}
          <div className="relative w-full md:w-80">
            <Search size={15} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="بحث باسم المشروع، الموقع، المالك..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pr-9 pl-3 py-1.5 bg-white border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 transition-all"
            />
          </div>

          {/* Status Filter Buttons */}
          <div className="flex items-center gap-1 overflow-x-auto w-full md:w-auto pb-0.5 md:pb-0 scrollbar-none">
            <button
              onClick={() => setStatusFilter('all')}
              className={`py-1.5 px-3 rounded-xl text-[11px] font-bold transition-all whitespace-nowrap cursor-pointer ${
                statusFilter === 'all'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'bg-white hover:bg-slate-200/70 text-slate-600 border border-slate-200/60'
              }`}
            >
              الكل ({projects.length})
            </button>

            <button
              onClick={() => setStatusFilter('active')}
              className={`py-1.5 px-3 rounded-xl text-[11px] font-bold transition-all whitespace-nowrap cursor-pointer ${
                statusFilter === 'active'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200/60'
              }`}
            >
              النشطة ({projects.filter(p => p.status === 'active').length})
            </button>

            <button
              onClick={() => setStatusFilter('planning')}
              className={`py-1.5 px-3 rounded-xl text-[11px] font-bold transition-all whitespace-nowrap cursor-pointer ${
                statusFilter === 'planning'
                  ? 'bg-amber-600 text-white shadow-xs'
                  : 'bg-amber-50 hover:bg-amber-100 text-amber-700 border border-amber-200/60'
              }`}
            >
              قيد التخطيط ({projects.filter(p => p.status === 'planning').length})
            </button>

            <button
              onClick={() => setStatusFilter('paused')}
              className={`py-1.5 px-3 rounded-xl text-[11px] font-bold transition-all whitespace-nowrap cursor-pointer ${
                statusFilter === 'paused'
                  ? 'bg-slate-700 text-white shadow-xs'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-600 border border-slate-200/60'
              }`}
            >
              المتوقفة ({projects.filter(p => p.status === 'paused').length})
            </button>

            <button
              onClick={() => setStatusFilter('completed')}
              className={`py-1.5 px-3 rounded-xl text-[11px] font-bold transition-all whitespace-nowrap cursor-pointer ${
                statusFilter === 'completed'
                  ? 'bg-sky-600 text-white shadow-xs'
                  : 'bg-sky-50 hover:bg-sky-100 text-sky-700 border border-sky-200/60'
              }`}
            >
              المكتملة ({projects.filter(p => p.status === 'completed').length})
            </button>
          </div>

        </div>

        {/* PROJECTS CARDS GRID */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          
          {sortedProjects.length === 0 ? null : (
            sortedProjects.map((proj, index) => {
              const isActive = proj.id === activeProjectId;
              const bTotal = (proj.budget || []).reduce((s, b) => s + b.amount, 0);
              const eTotal = (proj.expenses || []).reduce((s, e) => s + e.amount, 0);
              const remaining = bTotal - eTotal;
              const burnRate = bTotal > 0 ? Math.min(Math.round((eTotal / bTotal) * 100), 100) : 0;
              const statusInfo = getStatusBadge(proj.status);
              const expressiveIcon = getProjectExpressiveIcon(proj.name, index);

              return (
                <div 
                  key={proj.id}
                  className={`rounded-2xl transition-all duration-300 flex flex-col justify-between overflow-hidden relative group bg-white ${
                    isActive 
                      ? 'border-2 border-amber-500 shadow-xl shadow-amber-500/15 ring-2 ring-amber-400/30' 
                      : 'border-2 border-slate-200/90 hover:border-amber-400/80 hover:shadow-xl hover:shadow-slate-300/50'
                  }`}
                >
                  {/* Active Indicator Top Glow Line */}
                  {isActive && (
                    <div className="absolute top-0 inset-x-0 h-1.5 bg-gradient-to-r from-amber-400 via-amber-500 to-amber-300 z-20 shadow-xs"></div>
                  )}

                  {/* 1. Coordinated Luxury Header Band (Matching PageHeaderCard dark/amber styling) */}
                  <div className="bg-gradient-to-br from-slate-900 via-slate-900 to-amber-950/80 text-white p-3.5 sm:p-4 relative overflow-hidden border-b border-slate-800/90 shadow-xs">
                    {/* Ambient Glow */}
                    <div className="absolute -top-10 -left-10 w-28 h-28 bg-amber-500/20 rounded-full blur-xl pointer-events-none"></div>
                    <div className="absolute -bottom-8 -right-8 w-20 h-20 bg-sky-500/15 rounded-full blur-lg pointer-events-none"></div>

                    <div className="relative z-10 flex items-start gap-3">
                      {/* Project Icon with Premium Amber Box */}
                      <div className="p-2.5 bg-amber-500/25 text-amber-400 rounded-xl border border-amber-500/40 shadow-xs shrink-0 flex items-center justify-center group-hover:scale-105 transition-transform">
                        {expressiveIcon}
                      </div>

                      <div className="min-w-0 flex-1 space-y-1.5">
                        {/* Project Name + Active Badge */}
                        <div className="flex items-center justify-between gap-2">
                          <h3 
                            onClick={() => {
                              onSelectProject(proj.id);
                              if (setActiveTab) setActiveTab('dashboard');
                              window.scrollTo({ top: 0, behavior: 'instant' });
                            }}
                            className="text-sm sm:text-base font-extrabold text-white group-hover:text-amber-300 transition-colors leading-snug cursor-pointer truncate"
                            title={proj.name}
                          >
                            {proj.name}
                          </h3>
                          {isActive && (
                            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-gradient-to-r from-amber-500 to-amber-600 text-white font-extrabold text-[10px] shadow-sm shrink-0 border border-amber-300/40 animate-pulse">
                              <Star size={10} className="fill-white" />
                              <span>المشروع النشط</span>
                            </span>
                          )}
                        </div>

                        {/* Status Badge + Location / Owner */}
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10.5px] font-bold border shadow-xs backdrop-blur-xs ${statusInfo.bg}`}>
                            {statusInfo.icon}
                            <span>{statusInfo.label}</span>
                          </span>

                          {proj.location && (
                            <span className="inline-flex items-center gap-1 text-[11px] text-slate-200 font-medium bg-slate-800/90 px-2 py-0.5 rounded-md border border-slate-700/80">
                              <MapPin size={11} className="text-amber-400 shrink-0" />
                              <span className="truncate max-w-[130px]">{proj.location}</span>
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* 2. Card Body Content (Vibrant metrics and structured details) */}
                  <div className="p-3.5 sm:p-4 space-y-3 flex-1 bg-white">
                    
                    {/* Client / Owner info if available */}
                    {proj.client && (
                      <div className="flex items-center gap-1.5 text-xs text-slate-800 bg-indigo-50/50 px-2.5 py-1.5 rounded-xl border border-indigo-100/80 font-semibold">
                        <User size={13} className="text-indigo-600 shrink-0" />
                        <span className="text-slate-500 text-[11px]">المالك/العميل:</span>
                        <span className="font-bold text-indigo-950 truncate">{proj.client}</span>
                      </div>
                    )}

                    {/* Financial Mini Dashboard with Vibrant, High-Contrast Metric Pills */}
                    <div className="bg-gradient-to-b from-slate-50 to-slate-100/80 rounded-xl p-3 space-y-2.5 border border-slate-200/90 shadow-2xs">
                      <div className="grid grid-cols-3 gap-2 text-center">
                        {/* Budget */}
                        <div className="bg-white rounded-xl p-2 border-2 border-sky-100 shadow-2xs">
                          <span className="block text-[10px] font-extrabold text-sky-600 mb-0.5">الميزانية</span>
                          <span className="text-xs sm:text-sm font-black text-sky-900 truncate block">
                            {formatCurrency(bTotal, currency)}
                          </span>
                        </div>
                        {/* Expenses */}
                        <div className="bg-white rounded-xl p-2 border-2 border-rose-100 shadow-2xs">
                          <span className="block text-[10px] font-extrabold text-rose-600 mb-0.5">المصروفات</span>
                          <span className="text-xs sm:text-sm font-black text-rose-700 truncate block">
                            {formatCurrency(eTotal, currency)}
                          </span>
                        </div>
                        {/* Remaining */}
                        <div className={`rounded-xl p-2 border-2 shadow-2xs ${
                          remaining >= 0 
                            ? 'bg-emerald-50/90 border-emerald-200 text-emerald-900' 
                            : 'bg-rose-50/90 border-rose-200 text-rose-900'
                        }`}>
                          <span className={`block text-[10px] font-extrabold mb-0.5 ${remaining >= 0 ? 'text-emerald-700' : 'text-rose-700'}`}>
                            المتبقي
                          </span>
                          <span className="text-xs sm:text-sm font-black truncate block">
                            {formatCurrency(remaining, currency)}
                          </span>
                        </div>
                      </div>

                      {/* Budget Progress Bar with Vibrant Gradient */}
                      <div className="space-y-1 pt-1">
                        <div className="flex justify-between text-[11px] font-bold text-slate-600">
                          <span className="text-slate-500">نسبة الصرف:</span>
                          <span className={`font-extrabold ${burnRate > 90 ? 'text-rose-600' : burnRate > 75 ? 'text-amber-600' : 'text-emerald-700'}`}>
                            {burnRate}%
                          </span>
                        </div>
                        <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden p-0.5 shadow-inner">
                          <div 
                            className={`h-full rounded-full transition-all duration-500 ${
                              burnRate > 90 
                                ? 'bg-gradient-to-r from-rose-500 to-rose-600' 
                                : burnRate > 75 
                                ? 'bg-gradient-to-r from-amber-400 to-amber-600' 
                                : 'bg-gradient-to-r from-emerald-400 to-emerald-600'
                            }`}
                            style={{ width: `${burnRate}%` }}
                          ></div>
                        </div>
                      </div>
                    </div>

                    {/* Workforce Counts with Vibrant Color Tags */}
                    <div className="flex items-center justify-between text-[11px] pt-1">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="inline-flex items-center gap-1 font-bold px-2 py-0.5 rounded-lg bg-amber-50 text-amber-800 border border-amber-200/80 shadow-2xs">
                          <Users size={11} className="text-amber-600 shrink-0" />
                          <span>{(proj.workers || []).length} عمال</span>
                        </span>
                        <span className="inline-flex items-center gap-1 font-bold px-2 py-0.5 rounded-lg bg-indigo-50 text-indigo-800 border border-indigo-200/80 shadow-2xs">
                          <Briefcase size={11} className="text-indigo-600 shrink-0" />
                          <span>{(proj.employees || []).length} موظف</span>
                        </span>
                        <span className="inline-flex items-center gap-1 font-bold px-2 py-0.5 rounded-lg bg-purple-50 text-purple-800 border border-purple-200/80 shadow-2xs">
                          <Truck size={11} className="text-purple-600 shrink-0" />
                          <span>{(proj.suppliers || []).length} موردين</span>
                        </span>
                      </div>
                    </div>

                  </div>

                  {/* 3. Card Footer Actions */}
                  <div className="bg-slate-50/95 p-2.5 sm:p-3 border-t border-slate-200/90 flex items-center justify-between gap-2">
                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => handleOpenEdit(proj)}
                        className="p-1.5 bg-white hover:bg-amber-50 text-slate-600 hover:text-amber-700 rounded-lg border border-slate-200 hover:border-amber-300 transition-all cursor-pointer shadow-2xs"
                        title="تعديل بيانات المشروع"
                      >
                        <Edit3 size={14} />
                      </button>

                      <button
                        onClick={() => {
                          onDuplicateProject(proj.id);
                          if (typeof window !== 'undefined' && (window as any).showToast) {
                            (window as any).showToast(`تم نسخ مشروع "${proj.name}" بنجاح!`);
                          }
                        }}
                        className="p-1.5 bg-white hover:bg-slate-100 text-slate-600 rounded-lg border border-slate-200 transition-all cursor-pointer shadow-2xs"
                        title="نسخ / تكرار المشروع"
                      >
                        <Copy size={14} />
                      </button>

                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleBackupSingleProject(proj);
                        }}
                        className="p-1.5 bg-white hover:bg-emerald-50 text-slate-600 hover:text-emerald-700 rounded-lg border border-slate-200 hover:border-emerald-300 transition-all cursor-pointer shadow-2xs group/btn"
                        title="نسخة احتياطية لكافة بيانات وتفاصيل المشروع"
                      >
                        <ArrowDown size={14} className="stroke-[2.5] text-emerald-600 group-hover/btn:translate-y-0.5 transition-transform" />
                      </button>

                      {projects.length > 1 && (
                        <button
                          onClick={() => setDeleteConfirmId(proj.id)}
                          className="p-1.5 bg-white hover:bg-rose-50 text-slate-400 hover:text-rose-600 rounded-lg border border-slate-200 hover:border-rose-300 transition-all cursor-pointer shadow-2xs"
                          title="حذف المشروع"
                        >
                          <Trash2 size={14} />
                        </button>
                      )}
                    </div>

                    <button
                      onClick={() => {
                        onSelectProject(proj.id);
                        if (setActiveTab) setActiveTab('dashboard');
                        window.scrollTo({ top: 0, behavior: 'instant' });
                        if (typeof window !== 'undefined' && (window as any).showToast) {
                          (window as any).showToast(`تم الدخول لمشروع "${proj.name}" بنجاح!`);
                        }
                      }}
                      className={`py-1.5 px-3.5 rounded-xl font-black text-xs transition-all cursor-pointer flex items-center gap-1.5 shadow-sm active:scale-95 ${
                        isActive
                          ? 'bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white shadow-amber-500/20'
                          : 'bg-slate-900 hover:bg-slate-800 text-white hover:text-amber-300'
                      }`}
                    >
                      <span>الدخول للمشروع</span>
                      <ArrowRight size={13} />
                    </button>
                  </div>

                </div>
              );
            })
          )}

          {/* Add Project Big Interactive Card Button */}
          <button
            onClick={handleOpenCreate}
            className="bg-dashed-border bg-slate-50/80 hover:bg-amber-50/40 rounded-2xl border-2 border-dashed border-slate-300 hover:border-amber-500 p-5 flex flex-col items-center justify-center text-center space-y-2.5 transition-all cursor-pointer group min-h-[240px] shadow-2xs"
          >
            <div className="w-12 h-12 bg-amber-100 text-amber-600 group-hover:scale-110 group-hover:bg-amber-500 group-hover:text-white rounded-2xl flex items-center justify-center transition-all shadow-xs">
              <Plus size={24} />
            </div>
            <div>
              <h3 className="font-extrabold text-sm text-slate-800 group-hover:text-amber-700 transition-colors">
                إضافة مشروع / موقع جديد +
              </h3>
              <p className="text-[11px] text-slate-500 mt-1 max-w-xs leading-relaxed font-semibold">
                إنشاء موقع عمل منفصل مع تخصيص العمال، الموردين، والميزانية المعتمدة.
              </p>
            </div>
          </button>

        </div>

      </div>

      {/* ======================= SEPARATE ACTION BUTTONS FRAME ======================= */}
      <div className="bg-white rounded-2xl p-3 sm:p-4 border border-slate-200/90 shadow-2xs space-y-2.5">
        <div className="flex items-center gap-2 border-b border-slate-100 pb-2">
          <div className="p-1.5 bg-amber-50 text-amber-600 rounded-lg">
            <Building2 size={15} />
          </div>
          <div>
            <h3 className="font-extrabold text-xs sm:text-sm text-slate-900">
              إجراءات وخيارات إدارة المشاريع
            </h3>
            <p className="text-[10px] sm:text-[11px] text-slate-500 font-semibold">
              نقل العمالة والموردين، وتصدير التقارير المجمعة
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
          {/* Action 1: Migrate Workers & Suppliers */}
          <button
            onClick={handleOpenMigrationModal}
            className="p-2.5 bg-sky-50/70 hover:bg-sky-100/90 active:scale-[0.98] rounded-xl border border-sky-200/80 transition-all text-right flex items-center gap-2 cursor-pointer group shadow-2xs"
          >
            <div className="w-7 h-7 rounded-lg bg-sky-500 text-white flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform shadow-2xs">
              <ArrowLeftRight size={14} strokeWidth={2.5} />
            </div>
            <div className="space-y-0.5 min-w-0 flex-1">
              <span className="block font-black text-xs text-sky-950 truncate">
                نقل كوادر بين المشاريع
              </span>
              <span className="block text-[10px] font-bold text-sky-900/80 leading-tight truncate">
                تحويل العمال والموردين
              </span>
            </div>
          </button>

          {/* Action 2: Export Excel */}
          <button
            onClick={handleExportMultiProjectExcel}
            className="p-2.5 bg-emerald-50/70 hover:bg-emerald-100/90 active:scale-[0.98] rounded-xl border border-emerald-200/80 transition-all text-right flex items-center gap-2 cursor-pointer group shadow-2xs"
          >
            <div className="w-7 h-7 rounded-lg bg-emerald-600 text-white flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform shadow-2xs">
              <FileSpreadsheet size={14} strokeWidth={2.5} />
            </div>
            <div className="space-y-0.5 min-w-0 flex-1">
              <span className="block font-black text-xs text-emerald-950 truncate">
                تصدير تقرير Excel
              </span>
              <span className="block text-[10px] font-bold text-emerald-900/80 leading-tight truncate">
                تقرير إكسل مجمع وشامل
              </span>
            </div>
          </button>

          {/* Action 3: Print PDF */}
          <button
            onClick={handlePrintMultiProjectPDF}
            className="p-2.5 bg-indigo-50/70 hover:bg-indigo-100/90 active:scale-[0.98] rounded-xl border border-indigo-200/80 transition-all text-right flex items-center gap-2 cursor-pointer group shadow-2xs"
          >
            <div className="w-7 h-7 rounded-lg bg-indigo-600 text-white flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform shadow-2xs">
              <Printer size={14} strokeWidth={2.5} />
            </div>
            <div className="space-y-0.5 min-w-0 flex-1">
              <span className="block font-black text-xs text-indigo-950 truncate">
                طباعة التقرير PDF
              </span>
              <span className="block text-[10px] font-bold text-indigo-900/80 leading-tight truncate">
                معاينة وطباعة تقرير مفصل
              </span>
            </div>
          </button>
        </div>
      </div>

      {/* ======================= MODAL 3: CROSS-PROJECT ENTITY MIGRATION TOOL ======================= */}
      {showMigrationModal && (
        <div 
          className="fixed inset-0 bg-slate-900/80 backdrop-blur-xs z-[120] flex items-center justify-center p-4 dir-rtl text-right overflow-y-auto overscroll-contain"
          onTouchMove={(e) => {
            if (e.target === e.currentTarget) e.preventDefault();
          }}
        >
          <div 
            className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl space-y-6 border border-slate-100 animate-scale-up my-8 overscroll-contain"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-slate-100 pb-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-sky-50 text-sky-600 rounded-2xl flex items-center justify-center">
                  <ArrowLeftRight size={22} />
                </div>
                <div>
                  <h3 className="text-lg font-black text-slate-900">
                    أداة تحويل ونقل الكوادر بين المشاريع
                  </h3>
                  <p className="text-xs text-slate-500 font-semibold">
                    نقل أو نسخ العمال، الموظفين، أو الموردين من مشروع إلى مشروع آخر
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowMigrationModal(false)}
                className="p-2 text-slate-400 hover:text-slate-700 rounded-xl hover:bg-slate-100 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleExecuteMigration} className="space-y-4">
              {/* Migration Error Banner */}
              {migrationError && (
                <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl text-xs font-bold flex items-center gap-2 animate-shake">
                  <AlertCircle size={16} className="shrink-0 text-rose-600" />
                  <span>{migrationError}</span>
                </div>
              )}

              {/* Visual Route Indicator */}
              <div className="bg-slate-50 p-3 rounded-2xl border border-slate-200/80 flex items-center justify-between gap-3 text-xs">
                <div className="flex-1 min-w-0">
                  <span className="text-[10px] text-slate-400 block font-bold mb-0.5">المشروع المصدر (من):</span>
                  <span className="font-extrabold text-slate-800 truncate block">
                    {sourceProjectObj?.name || 'غير محدد'}
                  </span>
                </div>
                <div className="w-7 h-7 rounded-xl bg-sky-100 text-sky-600 flex items-center justify-center shrink-0">
                  <ArrowLeftRight size={15} />
                </div>
                <div className="flex-1 min-w-0 text-left dir-ltr">
                  <span className="text-[10px] text-slate-400 block font-bold mb-0.5">:(إلى) المشروع المستهدف</span>
                  <span className="font-extrabold text-slate-800 truncate block">
                    {targetProjectObj?.name || 'غير محدد'}
                  </span>
                </div>
              </div>
              
              {/* Source Project */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  من المشروع المصدر (الذي يحتوي الكادر) <span className="text-rose-500">*</span>
                </label>
                <select
                  value={migrationData.sourceProjectId}
                  onChange={(e) => handleSourceProjectChange(e.target.value)}
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-sky-500/20"
                >
                  {projects.map(p => (
                    <option key={p.id} value={p.id}>
                      {p.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Entity Type Selector */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  نوع الكادر المراد تحويله
                </label>
                <select
                  value={migrationData.entityType}
                  onChange={(e) => {
                    setMigrationError('');
                    setMigrationData({ ...migrationData, entityType: e.target.value as any, entityId: '' });
                  }}
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-sky-500/20"
                >
                  <option value="worker">عمالة يدوية / مهنية (Workers)</option>
                  <option value="employee">موظف بأجر يومي / شهري (Employees)</option>
                  <option value="supplier">مورد مواد أو آليات (Suppliers)</option>
                </select>
              </div>

              {/* Specific Entity Select */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center justify-between">
                  <span>اختر الاسم / الكادر من المشروع المصدر <span className="text-rose-500">*</span></span>
                  {sourceProjectObj && (
                    <span className="text-[11px] text-slate-400 font-normal">
                      (العدد المتاح: {
                        migrationData.entityType === 'worker' ? sourceProjectObj.workers?.length || 0 :
                        migrationData.entityType === 'employee' ? sourceProjectObj.employees?.length || 0 :
                        sourceProjectObj.suppliers?.length || 0
                      })
                    </span>
                  )}
                </label>
                <select
                  required
                  value={migrationData.entityId}
                  onChange={(e) => {
                    setMigrationError('');
                    setMigrationData({ ...migrationData, entityId: e.target.value });
                  }}
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-sky-500/20"
                >
                  <option value="">-- اختر الاسم هنا --</option>
                  {sourceProjectObj && migrationData.entityType === 'worker' && sourceProjectObj.workers?.length === 0 && (
                    <option value="" disabled>لا يوجد عمال مسجلون في هذا المشروع المصدر</option>
                  )}
                  {sourceProjectObj && migrationData.entityType === 'worker' && sourceProjectObj.workers?.map(w => (
                    <option key={w.id} value={w.id}>{w.name} ({w.profession})</option>
                  ))}
                  {sourceProjectObj && migrationData.entityType === 'employee' && sourceProjectObj.employees?.length === 0 && (
                    <option value="" disabled>لا يوجد موظفون مسجلون في هذا المشروع المصدر</option>
                  )}
                  {sourceProjectObj && migrationData.entityType === 'employee' && sourceProjectObj.employees?.map(e => (
                    <option key={e.id} value={e.id}>{e.name} ({e.profession})</option>
                  ))}
                  {sourceProjectObj && migrationData.entityType === 'supplier' && sourceProjectObj.suppliers?.length === 0 && (
                    <option value="" disabled>لا يوجد موردون مسجلون في هذا المشروع المصدر</option>
                  )}
                  {sourceProjectObj && migrationData.entityType === 'supplier' && sourceProjectObj.suppliers?.map(s => (
                    <option key={s.id} value={s.id}>{s.name} ({s.materialType})</option>
                  ))}
                </select>
              </div>

              {/* Target Project */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  إلى المشروع الهدف (الجديد) <span className="text-rose-500">*</span>
                </label>
                <select
                  required
                  value={migrationData.targetProjectId}
                  onChange={(e) => handleTargetProjectChange(e.target.value)}
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-sky-500/20"
                >
                  {projects.filter(p => p.id !== migrationData.sourceProjectId).map(p => (
                    <option key={p.id} value={p.id}>
                      {p.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Include Past Ledger Checkbox */}
              <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200 space-y-1">
                <label className="flex items-center gap-2 font-bold text-xs text-slate-800 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={migrationData.includeLedger}
                    onChange={(e) => setMigrationData({ ...migrationData, includeLedger: e.target.checked })}
                    className="w-4 h-4 rounded text-sky-600 focus:ring-sky-500"
                  />
                  <span>نسخ ونقل كشف الحساب والسجل المالي السلس كلياً</span>
                </label>
                <p className="text-[11px] text-slate-500 pr-6">
                  عند عدم التحديد، يتم إنشاء الكادر في المشروع الهدف بملف شخصي جديد ورصيد صفري (بداية جديدة للمشروع).
                </p>
              </div>

              <div className="pt-3 flex items-center justify-end gap-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowMigrationModal(false)}
                  className="py-2.5 px-5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition-all cursor-pointer"
                >
                  إلغاء
                </button>

                <button
                  type="submit"
                  className="py-2.5 px-6 bg-sky-600 hover:bg-sky-700 text-white font-bold text-xs sm:text-sm rounded-xl transition-all shadow-md cursor-pointer flex items-center gap-1.5"
                >
                  <ArrowLeftRight size={15} />
                  <span>تأكيد تحويل الكادر الآن</span>
                </button>
              </div>

            </form>

          </div>
        </div>
      )}

      {/* ======================= CREATE / EDIT PROJECT MODAL ======================= */}
      {(showCreateModal || editingProject) && (
        <div 
          className="fixed inset-0 bg-slate-900/80 backdrop-blur-xs z-[120] flex items-center justify-center p-2.5 sm:p-4 dir-rtl text-right overflow-y-auto overscroll-contain"
          onTouchMove={(e) => {
            if (e.target === e.currentTarget) e.preventDefault();
          }}
        >
          <div 
            className="bg-white rounded-2xl sm:rounded-3xl max-w-lg w-full shadow-2xl border border-slate-100 animate-scale-up max-h-[88vh] sm:max-h-[90vh] flex flex-col overflow-hidden my-auto overscroll-contain"
            onClick={(e) => e.stopPropagation()}
          >
            
            <div className="flex items-center justify-between border-b border-slate-100 p-4 sm:p-5 shrink-0 bg-white">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-sky-50 text-sky-600 rounded-2xl flex items-center justify-center shrink-0">
                  <Building2 size={22} />
                </div>
                <div>
                  <h3 className="text-base sm:text-lg font-black text-slate-900">
                    {editingProject ? 'تعديل بيانات المشروع' : 'إضافة مشروع جديد'}
                  </h3>
                  <p className="text-[11px] sm:text-xs text-slate-500 font-semibold">
                    {editingProject ? 'قم بتحديث بيانات وموقع الميزانية' : 'أدخل بيانات موقع وتفاصيل العمل الجديد'}
                  </p>
                </div>
              </div>
              <button
                onClick={() => {
                  setShowCreateModal(false);
                  setEditingProject(null);
                }}
                className="p-1.5 text-slate-400 hover:text-slate-700 rounded-xl hover:bg-slate-100 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmitForm} className="flex flex-col flex-1 overflow-hidden min-h-0">
              
              <div className="p-4 sm:p-5 overflow-y-auto space-y-3.5 flex-1 min-h-0 touch-pan-y overscroll-contain custom-scrollbar modal-scroll-area">
                {/* Import Backup Option Banner (Only on Create New Project) */}
                {!editingProject && (
                  <div className="bg-gradient-to-r from-sky-50 via-indigo-50/70 to-slate-50 p-3.5 rounded-2xl border border-sky-200/80 shadow-2xs space-y-2">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
                      <div className="flex items-center gap-2.5">
                        <div className="w-9 h-9 bg-sky-600 text-white rounded-xl flex items-center justify-center shrink-0 shadow-2xs">
                          <Upload size={18} />
                        </div>
                        <div>
                          <h4 className="font-extrabold text-xs sm:text-sm text-sky-950">
                            استيراد مشروع من نسخة احتياطية
                          </h4>
                          <p className="text-[10px] sm:text-[11px] text-slate-500 font-semibold leading-tight">
                            هل لديك ملف نسخة احتياطية (.json) لمشروع مسبق؟
                          </p>
                        </div>
                      </div>

                      <div>
                        <input
                          type="file"
                          ref={projectBackupFileInputRef}
                          onChange={handleImportSingleProjectBackupJSON}
                          accept=".json"
                          className="hidden"
                        />
                        <button
                          type="button"
                          onClick={() => projectBackupFileInputRef.current?.click()}
                          className="w-full sm:w-auto py-2 px-3.5 bg-sky-600 hover:bg-sky-700 active:scale-[0.98] text-white font-bold text-xs rounded-xl shadow-xs transition-all cursor-pointer flex items-center justify-center gap-1.5 shrink-0"
                        >
                          <FileJson size={15} />
                          <span>استيراد ملف .JSON</span>
                        </button>
                      </div>
                    </div>
                  </div>
                )}

                {/* Project Name */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    اسم المشروع / موقع العمل <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="مثال: مشروع عمارة النخبة - الستين"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500"
                  />
                </div>

                {/* Location & Client */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      الموقع / المدينة
                    </label>
                    <input
                      type="text"
                      placeholder="صنعاء - الستين"
                      value={formData.location}
                      onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      المالك / العميل
                    </label>
                    <input
                      type="text"
                      placeholder="وزارة الأشغال العامة"
                      value={formData.client}
                      onChange={(e) => setFormData({ ...formData, client: e.target.value })}
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500"
                    />
                  </div>
                </div>

                {/* Budget & Status */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      الميزانية المرصودة الأولية ({currency})
                    </label>
                    <input
                      type="number"
                      placeholder="10000000"
                      value={formData.initialBudgetAmount}
                      onChange={(e) => setFormData({ ...formData, initialBudgetAmount: e.target.value })}
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      حالة المشروع
                    </label>
                    <select
                      value={formData.status}
                      onChange={(e) => setFormData({ ...formData, status: e.target.value as any })}
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 cursor-pointer"
                    >
                      <option value="active">نشط وجاري العمل</option>
                      <option value="planning">قيد التخطيط</option>
                      <option value="paused">متوقف مؤقتاً</option>
                      <option value="completed">مكتمل ومسلم</option>
                    </select>
                  </div>
                </div>

                {/* Start and End Dates */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      تاريخ البدء
                    </label>
                    <input
                      type="date"
                      value={formData.startDate}
                      onChange={(e) => setFormData({ ...formData, startDate: e.target.value })}
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      تاريخ التسليم / الانتهاء المتوقع
                    </label>
                    <input
                      type="date"
                      value={formData.endDate}
                      onChange={(e) => setFormData({ ...formData, endDate: e.target.value })}
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500"
                    />
                  </div>
                </div>

                {/* Copy data from template (Only on Create) */}
                {!editingProject && projects.length > 0 && (
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      نسخ قائمة الكوادر والموردين الأساسية من مشروع آخر (اختياري)
                    </label>
                    <select
                      value={formData.copyDataFromProjectId}
                      onChange={(e) => setFormData({ ...formData, copyDataFromProjectId: e.target.value })}
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 cursor-pointer"
                    >
                      <option value="">-- البدء بمشروع فارغ تماماً --</option>
                      {projects.map(p => (
                        <option key={p.id} value={p.id}>
                          نسخ عمال وموردين: {p.name}
                        </option>
                      ))}
                    </select>
                  </div>
                )}

                {/* Notes */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    ملاحظات
                  </label>
                  <textarea
                    rows={2}
                    placeholder="ملاحظات تفصيلية حول عقد المشروع أو بنود الاتفاق..."
                    value={formData.notes}
                    onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 resize-none"
                  />
                </div>
              </div>

              <div className="p-3.5 sm:p-4 bg-slate-50 border-t border-slate-100 flex items-center justify-end gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => {
                    setShowCreateModal(false);
                    setEditingProject(null);
                  }}
                  className="py-2.5 px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition-all cursor-pointer"
                >
                  إلغاء
                </button>

                <button
                  type="button"
                  onClick={handleResetProjectForm}
                  className="py-2.5 px-3.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition-all cursor-pointer flex items-center gap-1.5"
                  title={editingProject ? 'إلغاء التعديلات واستعادة البيانات الأصلية' : 'تنظيف كافة الحقول'}
                >
                  <RotateCcw size={13} />
                  <span>{editingProject ? 'استعادة الأصل' : 'تنظيف'}</span>
                </button>

                <button
                  type="submit"
                  className="py-2.5 px-5 bg-sky-600 hover:bg-sky-700 text-white font-bold text-xs sm:text-sm rounded-xl transition-all shadow-md cursor-pointer"
                >
                  {editingProject ? 'حفظ التعديلات' : 'إنشاء المشروع الآن'}
                </button>
              </div>

            </form>

          </div>
        </div>
      )}

      {/* ======================= DELETE CONFIRMATION MODAL ======================= */}
      {deleteConfirmId && (
        <div 
          className="fixed inset-0 bg-slate-900/80 backdrop-blur-xs z-[120] flex items-center justify-center p-4 dir-rtl text-right overscroll-contain"
          onTouchMove={(e) => {
            if (e.target === e.currentTarget) e.preventDefault();
          }}
        >
          <div 
            className="bg-white rounded-3xl max-w-md w-full p-6 sm:p-8 shadow-2xl space-y-5 border border-rose-100 text-center animate-scale-up overscroll-contain"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="w-14 h-14 bg-rose-100 text-rose-600 rounded-2xl flex items-center justify-center mx-auto">
              <AlertCircle size={28} />
            </div>
            
            <div className="space-y-2">
              <h3 className="text-lg font-black text-slate-900">
                تأكيد حذف المشروع
              </h3>
              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed font-semibold">
                هل أنت تأكد من رغبتك في حذف هذا المشروع بالكامل؟ سيتم حذف كافة المصروفات، السجلات، والبيانات التابعة له محلياً.
              </p>
            </div>

            <div className="flex items-center justify-center gap-3 pt-2">
              <button
                onClick={() => setDeleteConfirmId(null)}
                className="w-full py-2.5 px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition-all cursor-pointer"
              >
                تراجع وإلغاء
              </button>

              <button
                onClick={() => {
                  onDeleteProject(deleteConfirmId);
                  setDeleteConfirmId(null);
                  if (typeof window !== 'undefined' && (window as any).showToast) {
                    (window as any).showToast('تم حذف المشروع بنجاح.');
                  }
                }}
                className="w-full py-2.5 px-4 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs rounded-xl transition-all shadow-md cursor-pointer"
              >
                تأكيد الحذف النهائي
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
