/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Copy, 
  ArrowRightLeft, 
  X, 
  Check, 
  Users, 
  Briefcase, 
  Truck, 
  AlertCircle,
  Calendar,
  DollarSign,
  FileText,
  HelpCircle,
  ArrowLeft
} from 'lucide-react';
import { Worker, Employee, Supplier, LedgerEntry, formatCurrency, formatDateArabic, cleanLedgerDescription } from '../types';
import { useBodyScrollLock } from '../utils/modalScrollLock';

interface CopyMoveLedgerModalProps {
  isOpen: boolean;
  mode: 'copy' | 'move';
  entry: LedgerEntry | null;
  sourceType: 'worker' | 'employee' | 'supplier';
  sourceId: string;
  sourceName?: string;
  workers: Worker[];
  employees: Employee[];
  suppliers: Supplier[];
  currency?: string;
  onClose: () => void;
  onConfirm: (
    mode: 'copy' | 'move',
    sourceType: 'worker' | 'employee' | 'supplier',
    sourceId: string,
    entry: LedgerEntry,
    targetType: 'worker' | 'employee' | 'supplier',
    targetId: string
  ) => void;
}

export default function CopyMoveLedgerModal({
  isOpen,
  mode,
  entry,
  sourceType,
  sourceId,
  sourceName,
  workers,
  employees,
  suppliers,
  currency = 'YER',
  onClose,
  onConfirm
}: CopyMoveLedgerModalProps) {
  useBodyScrollLock(isOpen);

  const [targetType, setTargetType] = useState<'worker' | 'employee' | 'supplier'>(sourceType);
  const [targetId, setTargetId] = useState<string>('');
  const [searchFilter, setSearchFilter] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  if (!isOpen || !entry) return null;

  const isPosted = Boolean(entry.isPosted || entry.id.startsWith('posted_') || entry.id.startsWith('exp_'));
  const effectiveCurrency = entry.currency || currency || 'YER';

  const getSourceTypeName = (t: 'worker' | 'employee' | 'supplier') => {
    if (t === 'worker') return 'عامل';
    if (t === 'employee') return 'موظف / مهندس';
    return 'مورد مواد';
  };

  // Filter available target accounts
  const getTargetOptions = () => {
    let list: Array<{ id: string; name: string; subtitle: string }> = [];
    if (targetType === 'worker') {
      list = workers.map(w => ({ id: w.id, name: w.name, subtitle: w.profession || 'عامل' }));
    } else if (targetType === 'employee') {
      list = employees.map(e => ({ id: e.id, name: e.name, subtitle: e.profession || 'موظف' }));
    } else if (targetType === 'supplier') {
      list = suppliers.map(s => ({ id: s.id, name: s.name, subtitle: s.materialType || 'مورد' }));
    }

    if (searchFilter.trim()) {
      const q = searchFilter.toLowerCase().trim();
      list = list.filter(item => item.name.toLowerCase().includes(q) || item.subtitle.toLowerCase().includes(q));
    }
    return list;
  };

  const targetOptions = getTargetOptions();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!targetId) {
      setErrorMsg('الرجاء اختيار الحساب المستهدف.');
      return;
    }

    if (mode === 'move' && targetType === sourceType && targetId === sourceId) {
      setErrorMsg('لا يمكن نقل العملية إلى نفس الحساب الحالي. الرجاء اختيار حساب مختلف.');
      return;
    }

    onConfirm(mode, sourceType, sourceId, entry, targetType, targetId);
    onClose();
  };

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-fade-in"
      onClick={onClose}
    >
      <div 
        className="bg-white w-full max-w-lg rounded-2xl shadow-2xl border border-slate-100 overflow-hidden flex flex-col max-h-[92vh] animate-scale-up"
        onClick={(e) => e.stopPropagation()}
        id="copy-move-ledger-modal"
      >
        {/* Modal Header */}
        <div className={`p-4 sm:p-5 flex items-center justify-between border-b ${
          mode === 'copy' 
            ? 'bg-gradient-to-r from-emerald-600 to-teal-700 text-white' 
            : 'bg-gradient-to-r from-indigo-600 to-sky-700 text-white'
        }`}>
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-white/20 backdrop-blur-xs">
              {mode === 'copy' ? <Copy size={20} className="text-white" /> : <ArrowRightLeft size={20} className="text-white" />}
            </div>
            <div>
              <h2 className="font-extrabold text-base sm:text-lg">
                {mode === 'copy' ? 'نسخ العملية المالية إلى حساب آخر' : 'نقل العملية المالية إلى حساب آخر'}
              </h2>
              <p className="text-xs text-white/80 font-medium">
                {mode === 'copy' ? 'إنشاء نسخة مطابقة من القيد في كشف حساب آخر' : 'تحويل القيد وإزالته من الحساب الحالي إلى حساب جديد'}
              </p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
            title="إغلاق"
          >
            <X size={18} />
          </button>
        </div>

        {/* Modal Body */}
        <form onSubmit={handleSubmit} className="p-4 sm:p-6 space-y-4 overflow-y-auto flex-1 text-right">
          {errorMsg && (
            <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl text-xs flex items-center gap-2 font-bold animate-shake">
              <AlertCircle size={16} className="shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Operation Details Card */}
          <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl space-y-2.5">
            <div className="flex items-center justify-between text-xs text-slate-500 border-b border-slate-200 pb-2">
              <div className="flex items-center gap-1.5">
                <Calendar size={13} className="text-slate-400" />
                <span className="font-semibold">{formatDateArabic(entry.date)}</span>
              </div>
              <span className="bg-slate-200 text-slate-700 px-2 py-0.5 rounded-md font-bold text-[11px]">
                الحساب المصدر: {sourceName ? `${sourceName} (${getSourceTypeName(sourceType)})` : getSourceTypeName(sourceType)}
              </span>
            </div>

            <div className="flex items-start justify-between gap-3">
              <div className="space-y-1">
                <p className="text-xs font-bold text-slate-800 leading-snug">
                  {cleanLedgerDescription(entry.description)}
                </p>
                {entry.notes && (
                  <p className="text-[11px] text-slate-400 truncate max-w-xs" title={entry.notes}>
                    ملاحظات: {entry.notes}
                  </p>
                )}
              </div>
              <div className="text-left shrink-0">
                {entry.amountOnHim > 0 && (
                  <div className="text-xs font-black text-rose-600 font-mono">
                    عليه: {formatCurrency(entry.amountOnHim, effectiveCurrency)}
                  </div>
                )}
                {entry.amountForHim > 0 && (
                  <div className="text-xs font-black text-emerald-600 font-mono">
                    له: {formatCurrency(entry.amountForHim, effectiveCurrency)}
                  </div>
                )}
              </div>
            </div>

            {isPosted && (
              <div className="pt-2 border-t border-slate-200/80 flex items-center gap-1.5 text-[11px] font-bold text-amber-800 bg-amber-50/80 p-2 rounded-lg border border-amber-200">
                <AlertCircle size={14} className="text-amber-600 shrink-0" />
                <span>
                  {mode === 'copy' 
                    ? 'هذه الحركة مرحّلة من النفقات اليومية: سيتم أيضاً إنشاء قيد نفقة يومية جديد مطابق مرتبط بالحساب المختار.'
                    : 'هذه الحركة مرحّلة من النفقات اليومية: سيتم تعديل سجل النفقات اليومية وتغيير المستفيد إلى الحساب الجديد تلقائياً.'}
                </span>
              </div>
            )}
          </div>

          {/* Step 1: Select Target Category */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-700 block">
              1. اختر نوع الحساب المستهدف:
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => { setTargetType('worker'); setTargetId(''); }}
                className={`p-2.5 rounded-xl border flex flex-col items-center justify-center gap-1 text-xs font-bold transition-all cursor-pointer ${
                  targetType === 'worker' 
                    ? 'border-sky-500 bg-sky-50 text-sky-800 ring-2 ring-sky-500/20 shadow-xs' 
                    : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'
                }`}
              >
                <Users size={16} className={targetType === 'worker' ? 'text-sky-600' : 'text-slate-400'} />
                <span>عمال ({workers.length})</span>
              </button>

              <button
                type="button"
                onClick={() => { setTargetType('employee'); setTargetId(''); }}
                className={`p-2.5 rounded-xl border flex flex-col items-center justify-center gap-1 text-xs font-bold transition-all cursor-pointer ${
                  targetType === 'employee' 
                    ? 'border-indigo-500 bg-indigo-50 text-indigo-800 ring-2 ring-indigo-500/20 shadow-xs' 
                    : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'
                }`}
              >
                <Briefcase size={16} className={targetType === 'employee' ? 'text-indigo-600' : 'text-slate-400'} />
                <span>موظفين ({employees.length})</span>
              </button>

              <button
                type="button"
                onClick={() => { setTargetType('supplier'); setTargetId(''); }}
                className={`p-2.5 rounded-xl border flex flex-col items-center justify-center gap-1 text-xs font-bold transition-all cursor-pointer ${
                  targetType === 'supplier' 
                    ? 'border-amber-500 bg-amber-50 text-amber-800 ring-2 ring-amber-500/20 shadow-xs' 
                    : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'
                }`}
              >
                <Truck size={16} className={targetType === 'supplier' ? 'text-amber-600' : 'text-slate-400'} />
                <span>موردين ({suppliers.length})</span>
              </button>
            </div>
          </div>

          {/* Step 2: Select Specific Target Account */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-700">
                2. اختر الحساب المستهدف بالتحديد:
              </label>
              {targetOptions.length > 5 && (
                <input 
                  type="text"
                  placeholder="تصفية بالاسم..."
                  value={searchFilter}
                  onChange={(e) => setSearchFilter(e.target.value)}
                  className="px-2 py-0.5 text-[11px] border border-slate-200 rounded-lg bg-slate-50 text-slate-700 w-28 focus:outline-hidden focus:border-sky-500"
                />
              )}
            </div>

            {targetOptions.length === 0 ? (
              <div className="p-4 bg-slate-50 border border-dashed border-slate-200 rounded-xl text-center text-xs text-slate-400">
                لا توجد حسابات مسجلة في هذا القسم.
              </div>
            ) : (
              <div className="max-h-48 overflow-y-auto space-y-1.5 border border-slate-200 p-1.5 rounded-xl bg-slate-50/50">
                {targetOptions.map((opt) => {
                  const isCurrent = (targetType === sourceType && opt.id === sourceId);
                  const isSelected = targetId === opt.id;

                  return (
                    <div
                      key={opt.id}
                      onClick={() => setTargetId(opt.id)}
                      className={`p-2 rounded-lg border text-xs flex items-center justify-between transition-all cursor-pointer ${
                        isSelected 
                          ? 'border-indigo-500 bg-white text-indigo-950 font-bold shadow-xs ring-1 ring-indigo-500' 
                          : isCurrent 
                            ? 'border-slate-200 bg-slate-100/70 text-slate-400 hover:bg-slate-100'
                            : 'border-transparent bg-white hover:bg-slate-100/60 text-slate-700'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <div className={`w-3.5 h-3.5 rounded-full border flex items-center justify-center ${
                          isSelected ? 'border-indigo-600 bg-indigo-600 text-white' : 'border-slate-300 bg-white'
                        }`}>
                          {isSelected && <Check size={10} />}
                        </div>
                        <span className="font-semibold text-slate-800">{opt.name}</span>
                        <span className="text-[10px] text-slate-400">({opt.subtitle})</span>
                      </div>
                      {isCurrent && (
                        <span className="text-[10px] bg-slate-200 text-slate-600 px-1.5 py-0.5 rounded-sm font-normal">
                          (الحساب الحالي)
                        </span>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Action Buttons */}
          <div className="pt-3 border-t border-slate-100 flex items-center gap-2">
            <button
              type="submit"
              disabled={!targetId}
              className={`flex-1 py-3 px-4 rounded-xl text-white font-bold text-xs shadow-xs transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed ${
                mode === 'copy' 
                  ? 'bg-emerald-600 hover:bg-emerald-700 active:scale-98' 
                  : 'bg-indigo-600 hover:bg-indigo-700 active:scale-98'
              }`}
            >
              {mode === 'copy' ? (
                <>
                  <Copy size={15} />
                  <span>تأكيد نسخ العملية</span>
                </>
              ) : (
                <>
                  <ArrowRightLeft size={15} />
                  <span>تأكيد نقل العملية</span>
                </>
              )}
            </button>
            <button
              type="button"
              onClick={onClose}
              className="py-3 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs transition-colors cursor-pointer"
            >
              إلغاء
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
