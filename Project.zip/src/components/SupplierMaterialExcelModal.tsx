/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useMemo } from 'react';
import * as XLSX from 'xlsx';
import { 
  FileSpreadsheet, 
  Upload, 
  X, 
  Check, 
  AlertCircle, 
  Layers, 
  ArrowRight, 
  RefreshCw,
  Eye,
  FileText,
  Sliders,
  ChevronDown
} from 'lucide-react';
import { SupplierMaterialItem, formatCurrency } from '../types';
import { useSupplierMaterialCategories } from '../utils/materialCategories';

interface SupplierMaterialExcelModalProps {
  isOpen: boolean;
  onClose: () => void;
  onImport: (
    items: SupplierMaterialItem[],
    options: { mode: 'append' | 'replace'; invoiceNumber?: string }
  ) => void;
  currency?: string;
  existingCount?: number;
}

const COMMON_UNITS = ['كيس', 'طن', 'متر', 'متر مربع', 'متر مكعب', 'حبة', 'سيارة', 'نقلة', 'رول', 'برميل', 'كيلو', 'لتر', 'شدة'];

interface DetectedColumn {
  index: number;
  label: string;
}

// Clean and convert any numeric string/number
function parseNumericValue(val: any): number {
  if (val === null || val === undefined) return 0;
  if (typeof val === 'number') return isNaN(val) ? 0 : val;
  let str = String(val).trim();
  if (!str) return 0;

  // Convert Arabic-Indic digits (٠-٩) to Western (0-9)
  str = str.replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d).toString());

  // Remove commas, spaces, currency symbols, and text
  str = str.replace(/[,،\s$£€¥a-zA-Z]/g, '');

  const num = parseFloat(str);
  return isNaN(num) ? 0 : num;
}

export default function SupplierMaterialExcelModal({
  isOpen,
  onClose,
  onImport,
  currency = 'YER',
  existingCount = 0
}: SupplierMaterialExcelModalProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);

  // File & Workbook state
  const [fileName, setFileName] = useState('');
  const [sheetNames, setSheetNames] = useState<string[]>([]);
  const [selectedSheet, setSelectedSheet] = useState('');
  const [rawRows, setRawRows] = useState<any[][]>([]);
  const [headerRowIndex, setHeaderRowIndex] = useState(0);

  // Mapping state: -1 means not mapped
  const [colItemName, setColItemName] = useState<number>(-1);
  const [colQuantity, setColQuantity] = useState<number>(-1);
  const [colUnitPrice, setColUnitPrice] = useState<number>(-1);
  const { categories } = useSupplierMaterialCategories();
  const [colUnit, setColUnit] = useState<number>(-1);
  const [defaultUnit, setDefaultUnit] = useState('حبة');
  const [colCategory, setColCategory] = useState<number>(-1);
  const [defaultCategory, setDefaultCategory] = useState<string>('مواد كهرباء');
  const [categoryMode, setCategoryMode] = useState<'column' | 'fixed'>('fixed');
  const [colNotes, setColNotes] = useState<number>(-1);
  const [colInvoiceNumber, setColInvoiceNumber] = useState<number>(-1);
  const [manualInvoiceNumber, setManualInvoiceNumber] = useState('');

  // Import mode
  const [importMode, setImportMode] = useState<'append' | 'replace'>('append');

  // UI state
  const [errorMessage, setErrorMessage] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);

  if (!isOpen) return null;

  // Read file on select
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setErrorMessage('');
    setIsProcessing(true);
    setFileName(file.name);

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const buffer = event.target?.result as ArrayBuffer;
        const workbook = XLSX.read(buffer, { type: 'array' });
        
        if (!workbook.SheetNames || workbook.SheetNames.length === 0) {
          throw new Error('الملف فارغ أو لا يحتوي على صفحات عمل.');
        }

        setSheetNames(workbook.SheetNames);
        const firstSheetName = workbook.SheetNames[0];
        setSelectedSheet(firstSheetName);

        processSheet(workbook.Sheets[firstSheetName]);
      } catch (err: any) {
        console.error('Error parsing Excel:', err);
        setErrorMessage('تعذر قراءة ملف الإكسل. يرجى التأكد من صلاحية الملف وتنسيقه (.xlsx أو .xls أو .csv).');
      } finally {
        setIsProcessing(false);
      }
    };

    reader.onerror = () => {
      setErrorMessage('حدث خطأ أثناء فتح الملف.');
      setIsProcessing(false);
    };

    reader.readAsArrayBuffer(file);
  };

  // Process a worksheet into rows and detect header
  const processSheet = (sheet: XLSX.WorkSheet) => {
    const rows: any[][] = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: '' });
    
    if (!rows || rows.length === 0) {
      setErrorMessage('ورقة العمل المحددة فارغة.');
      setRawRows([]);
      return;
    }

    setRawRows(rows);

    // Smart Header Row Detection
    const KEYWORDS = [
      'صنف', 'مادة', 'ماده', 'بيان', 'اسم', 'وصف', 'تفاصيل', 'كمية', 'كميه', 
      'سعر', 'قيمة', 'فئة', 'وحدة', 'وحده', 'اجمالي', 'إجمالي', 'ملاحظات',
      'item', 'material', 'desc', 'qty', 'price', 'unit', 'total', 'note'
    ];

    let bestRowIdx = 0;
    let highestScore = -1;

    // Inspect first 12 rows
    const searchLimit = Math.min(rows.length, 12);
    for (let r = 0; r < searchLimit; r++) {
      const row = rows[r];
      if (!Array.isArray(row) || row.length === 0) continue;
      
      let score = 0;
      let stringCellsCount = 0;

      row.forEach(cell => {
        if (typeof cell === 'string' && cell.trim()) {
          stringCellsCount++;
          const lower = cell.toLowerCase().trim();
          if (KEYWORDS.some(kw => lower.includes(kw))) {
            score += 6;
          }
        }
      });

      // Bonus if row has at least 3 labeled text columns
      if (stringCellsCount >= 3) {
        score += stringCellsCount * 2;
      }

      if (score > highestScore) {
        highestScore = score;
        bestRowIdx = r;
      }
    }

    setHeaderRowIndex(bestRowIdx);
    autoMapColumns(rows, bestRowIdx);
  };

  // Switch sheet
  const handleSheetChange = (sheetName: string) => {
    setSelectedSheet(sheetName);
    if (!fileInputRef.current?.files?.[0]) return;
    
    const file = fileInputRef.current.files[0];
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const buffer = event.target?.result as ArrayBuffer;
        const workbook = XLSX.read(buffer, { type: 'array' });
        if (workbook.Sheets[sheetName]) {
          processSheet(workbook.Sheets[sheetName]);
        }
      } catch (err) {
        console.error(err);
      }
    };
    reader.readAsArrayBuffer(file);
  };

  // Switch header row index
  const handleHeaderRowChange = (newRowIdx: number) => {
    setHeaderRowIndex(newRowIdx);
    autoMapColumns(rawRows, newRowIdx);
  };

  // Get current detected columns based on headerRowIndex
  const detectedColumns: DetectedColumn[] = useMemo(() => {
    if (!rawRows || rawRows.length <= headerRowIndex) return [];
    const headerRow = rawRows[headerRowIndex];
    if (!Array.isArray(headerRow)) return [];

    return headerRow.map((cell, idx) => {
      const label = (cell !== undefined && cell !== null && String(cell).trim()) 
        ? String(cell).trim() 
        : `العمود ${idx + 1}`;
      return { index: idx, label };
    });
  }, [rawRows, headerRowIndex]);

  // Auto-map keywords to column indices
  const autoMapColumns = (rows: any[][], headerIdx: number) => {
    if (!rows || rows.length <= headerIdx) return;
    const headerRow = rows[headerIdx];
    if (!Array.isArray(headerRow)) return;

    const findMatch = (keywords: string[]) => {
      for (const kw of keywords) {
        const foundIdx = headerRow.findIndex(cell => {
          if (!cell) return false;
          const text = String(cell).toLowerCase().trim();
          return text.includes(kw);
        });
        if (foundIdx !== -1) return foundIdx;
      }
      return -1;
    };

    // Item Name
    const itemCol = findMatch([
      'اسم الصنف', 'اسم المادة', 'المادة', 'الصنف', 'الماده', 'البيان', 'الوصف', 
      'item', 'material', 'description', 'product', 'name'
    ]);
    setColItemName(itemCol);

    // Quantity
    const qtyCol = findMatch([
      'الكمية', 'الكميه', 'كمية', 'كميه', 'العدد', 'عدد', 'qty', 'quantity', 'count'
    ]);
    setColQuantity(qtyCol);

    // Unit Price
    const priceCol = findMatch([
      'سعر الوحدة', 'سعر الوحده', 'السعر', 'سعر', 'فئة', 'الفئة', 'قيمة الوحدة', 'ثمن', 
      'price', 'unit price', 'rate', 'cost'
    ]);
    setColUnitPrice(priceCol);

    // Unit
    const unitCol = findMatch([
      'الوحدة', 'الوحده', 'نوع الوحدة', 'وحدة', 'وحده', 'unit', 'uom'
    ]);
    setColUnit(unitCol);

    // Category
    const catCol = findMatch([
      'فئة الصنف', 'الفئة', 'فئة', 'التصنيف', 'تصنيف', 'النوع', 'category', 'type'
    ]);
    if (catCol !== -1) {
      setColCategory(catCol);
      setCategoryMode('column');
    }

    // Notes
    const notesCol = findMatch([
      'ملاحظات', 'ملاحظة', 'ملاحظه', 'تفاصيل', 'بيان إضافي', 'notes', 'remarks', 'comment'
    ]);
    setColNotes(notesCol);

    // Invoice Number
    const invCol = findMatch([
      'رقم الفاتورة', 'رقم الفاتوره', 'الفاتورة', 'الفاتوره', 'سند', 'وصل', 'invoice', 'inv'
    ]);
    setColInvoiceNumber(invCol);
  };

  // Build preview items based on current mapping
  const parsedItemsPreview = useMemo(() => {
    if (!rawRows || rawRows.length <= headerRowIndex + 1) return [];
    if (colItemName === -1) return [];

    const dataRows = rawRows.slice(headerRowIndex + 1);
    const parsed: SupplierMaterialItem[] = [];

    for (let i = 0; i < dataRows.length; i++) {
      const row = dataRows[i];
      if (!Array.isArray(row)) continue;

      const rawName = colItemName !== -1 ? row[colItemName] : '';
      const name = rawName !== undefined && rawName !== null ? String(rawName).trim() : '';

      // Skip totally blank rows or rows that repeat the header
      if (!name || name === detectedColumns[colItemName]?.label) continue;

      const qty = colQuantity !== -1 ? parseNumericValue(row[colQuantity]) : 0;
      const price = colUnitPrice !== -1 ? parseNumericValue(row[colUnitPrice]) : 0;

      // Extract unit
      let unit = defaultUnit;
      if (colUnit !== -1 && row[colUnit]) {
        const u = String(row[colUnit]).trim();
        if (u) unit = u;
      }

      // Extract category
      let category = defaultCategory;
      if (categoryMode === 'column' && colCategory !== -1 && row[colCategory]) {
        const c = String(row[colCategory]).trim();
        if (c) category = c;
      }

      // Extract notes
      let notes = '';
      if (colNotes !== -1 && row[colNotes]) {
        notes = String(row[colNotes]).trim();
      }

      const total = Math.round(qty * price * 100) / 100;

      parsed.push({
        id: `import-${Date.now()}-${i}`,
        itemName: name,
        quantity: qty,
        unitPrice: price,
        unit: unit,
        category: category,
        total: total,
        notes: notes
      });
    }

    return parsed;
  }, [
    rawRows, 
    headerRowIndex, 
    colItemName, 
    colQuantity, 
    colUnitPrice, 
    colUnit, 
    defaultUnit, 
    categoryMode, 
    colCategory, 
    defaultCategory, 
    colNotes, 
    detectedColumns
  ]);

  // Total summary of parsed items
  const totalAmount = useMemo(() => {
    return parsedItemsPreview.reduce((sum, item) => sum + (item.total || 0), 0);
  }, [parsedItemsPreview]);

  // Handle final import confirmation
  const handleConfirmImport = () => {
    setErrorMessage('');

    if (colItemName === -1) {
      setErrorMessage('يرجى تحديد العمود المخصص لـ (اسم الصنف / المادة).');
      return;
    }

    if (parsedItemsPreview.length === 0) {
      setErrorMessage('لم يتم العثور على أي أصناف صالحة للاستيراد بناءً على الأعمدة المحددة.');
      return;
    }

    // Determine invoice number
    let detectedInvoice = manualInvoiceNumber.trim();
    if (!detectedInvoice && colInvoiceNumber !== -1 && rawRows.length > headerRowIndex + 1) {
      const firstRow = rawRows[headerRowIndex + 1];
      if (firstRow && firstRow[colInvoiceNumber]) {
        detectedInvoice = String(firstRow[colInvoiceNumber]).trim();
      }
    }

    onImport(parsedItemsPreview, {
      mode: importMode,
      invoiceNumber: detectedInvoice || undefined
    });

    onClose();
  };

  const resetFile = () => {
    setFileName('');
    setSheetNames([]);
    setSelectedSheet('');
    setRawRows([]);
    setHeaderRowIndex(0);
    setColItemName(-1);
    setColQuantity(-1);
    setColUnitPrice(-1);
    setColUnit(-1);
    setColCategory(-1);
    setColNotes(-1);
    setColInvoiceNumber(-1);
    setManualInvoiceNumber('');
    setErrorMessage('');
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  return (
    <div 
      className="fixed inset-0 z-[120] flex items-center justify-center bg-slate-950/70 backdrop-blur-xs p-2 sm:p-4 overflow-hidden dir-rtl text-right animate-fade-in"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
      id="supplier-material-excel-modal-backdrop"
    >
      <div 
        className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-3xl w-full animate-scale-up my-auto max-h-[94vh] sm:max-h-[90vh] h-[94vh] sm:h-auto flex flex-col overflow-hidden relative shadow-slate-950/30"
        onClick={(e) => e.stopPropagation()}
        id="supplier-material-excel-modal"
      >
        {/* Modal Header */}
        <div className="p-3.5 sm:p-4 border-b border-slate-100 flex items-center justify-between shrink-0 bg-white">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center border border-emerald-100 shadow-xs shrink-0">
              <FileSpreadsheet size={20} />
            </div>
            <div>
              <h3 className="font-bold text-slate-800 text-sm sm:text-base">
                استيراد ومطابقة أصناف الفاتورة من ملف إكسل
              </h3>
              <p className="text-xs text-slate-400">
                فحص أعمدة الجدول ومطابقتها بمرونة مع خانات كشف المواد
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 rounded-xl hover:bg-slate-100 cursor-pointer transition-colors"
            title="إغلاق"
          >
            <X size={20} />
          </button>
        </div>

        {/* Modal Scrollable Body */}
        <div className="p-3.5 sm:p-5 overflow-y-auto space-y-4 flex-1 min-h-0 modal-scroll-area custom-scrollbar bg-slate-50/40 scroll-smooth touch-pan-y">
          
          {/* File Upload Section if no file loaded */}
          {!fileName ? (
            <div className="space-y-3">
              <div 
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-emerald-300 hover:border-emerald-500 bg-emerald-50/40 hover:bg-emerald-50/80 rounded-2xl p-8 sm:p-12 text-center cursor-pointer transition-all duration-200 group"
              >
                <div className="w-14 h-14 mx-auto rounded-2xl bg-emerald-100 text-emerald-600 flex items-center justify-center mb-3 group-hover:scale-105 transition-transform shadow-xs">
                  <Upload size={28} />
                </div>
                <h4 className="font-bold text-slate-800 text-base mb-1">
                  انقر هنا لاختيار ملف الإكسل أو الفاتورة
                </h4>
                <p className="text-xs text-slate-500 mb-3">
                  يدعم ملفات العمل: Excel (.xlsx, .xls) أو ملفات (.csv)
                </p>
                <span className="inline-block bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs px-4 py-2 rounded-xl shadow-xs transition-colors">
                  تصفح الملفات من الهاتف أو الكمبيوتر
                </span>
              </div>

              <input 
                ref={fileInputRef}
                type="file" 
                accept=".xlsx, .xls, .csv" 
                onChange={handleFileChange}
                className="hidden" 
              />

              <div className="bg-white p-3.5 rounded-xl border border-slate-200/80 text-xs text-slate-600 space-y-1.5">
                <div className="font-bold text-slate-700 flex items-center gap-1.5">
                  <AlertCircle size={15} className="text-amber-500" />
                  <span>ملاحظات هامة حول استيراد الفواتير:</span>
                </div>
                <ul className="list-disc list-inside space-y-1 text-slate-500 text-[11px] pr-1">
                  <li>لا تشترط تسمية محددة للأعمدة، حيث سيقوم التطبيق بعرض كافة أعمدة ملفك لتختار منها بنفسك.</li>
                  <li>يتعرف النظام تلقائياً على الأعمدة الشائعة (اسم الصنف، الكمية، السعر، الوحدة) لتوفير وقتك.</li>
                  <li>تتم إزالة الفواصل والرموز من الأرقام تلقائياً وحساب الإجماليات بدقة.</li>
                </ul>
              </div>
            </div>
          ) : (
            /* File Loaded & Mapping Controls */
            <div className="space-y-4">
              
              {/* File Info Bar */}
              <div className="bg-white p-3 rounded-xl border border-slate-200/90 shadow-xs flex items-center justify-between gap-3 flex-wrap">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold text-xs">
                    XLS
                  </div>
                  <div>
                    <span className="text-xs font-bold text-slate-800 block truncate max-w-[200px] sm:max-w-xs">
                      {fileName}
                    </span>
                    <span className="text-[10px] text-slate-400">
                      {rawRows.length} صف تم اكتشافه بالملف
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {sheetNames.length > 1 && (
                    <div className="flex items-center gap-1">
                      <span className="text-[11px] text-slate-500 font-bold">الورقة:</span>
                      <select
                        value={selectedSheet}
                        onChange={(e) => handleSheetChange(e.target.value)}
                        className="p-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-bold text-slate-700"
                      >
                        {sheetNames.map(s => (
                          <option key={s} value={s}>{s}</option>
                        ))}
                      </select>
                    </div>
                  )}

                  <button
                    type="button"
                    onClick={resetFile}
                    className="p-1.5 text-xs text-rose-600 hover:bg-rose-50 rounded-lg transition-colors font-bold cursor-pointer"
                    title="اختيار ملف آخر"
                  >
                    تغيير الملف
                  </button>
                </div>
              </div>

              {/* Header Row Selector */}
              <div className="bg-amber-50/60 p-3 rounded-xl border border-amber-200/80 flex items-center justify-between gap-3 flex-wrap">
                <div className="flex items-center gap-2">
                  <Sliders size={16} className="text-amber-600" />
                  <div>
                    <span className="text-xs font-bold text-amber-900 block">
                      سطر عناوين الأعمدة في الملف
                    </span>
                    <span className="text-[10px] text-amber-700">
                      حدد الصف الذي يحتوي على ترويسة الجدول (أسماء الأصناف، الكمية، السعر)
                    </span>
                  </div>
                </div>

                <select
                  value={headerRowIndex}
                  onChange={(e) => handleHeaderRowChange(parseInt(e.target.value))}
                  className="p-1.5 bg-white border border-amber-300 rounded-lg text-xs font-bold text-amber-950 focus:outline-hidden focus:ring-1 focus:ring-amber-500"
                >
                  {rawRows.slice(0, Math.min(rawRows.length, 10)).map((_, idx) => (
                    <option key={idx} value={idx}>
                      الصف رقم {idx + 1} {idx === headerRowIndex ? '(المحدد حالياً)' : ''}
                    </option>
                  ))}
                </select>
              </div>

              {/* Column Mapping Grid */}
              <div className="bg-white p-3.5 sm:p-4 rounded-xl border border-slate-200 shadow-xs space-y-3.5">
                <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                  <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                    <Check size={16} className="text-emerald-600" />
                    <span>توزيع ومطابقة الأعمدة (ربط بيانات الفاتورة):</span>
                  </span>
                  <span className="text-[10px] text-slate-400">
                    * الحقول المشار إليها بإلزامية يجب تحديدها
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                  
                  {/* 1. Item Name (Required) */}
                  <div className="p-2.5 bg-slate-50/70 border border-slate-200 rounded-xl space-y-1.5">
                    <label className="text-xs font-bold text-slate-700 block">
                      اسم الصنف / المادة <span className="text-rose-500">*</span>
                    </label>
                    <select
                      value={colItemName}
                      onChange={(e) => setColItemName(parseInt(e.target.value))}
                      className="w-full p-2 bg-white border border-slate-200 rounded-lg text-xs font-bold text-slate-800 focus:border-emerald-500 focus:outline-hidden"
                    >
                      <option value={-1}>-- اختر عمود اسم الصنف --</option>
                      {detectedColumns.map(col => (
                        <option key={col.index} value={col.index}>
                          {col.label} (عمود {col.index + 1})
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* 2. Quantity (Required) */}
                  <div className="p-2.5 bg-slate-50/70 border border-slate-200 rounded-xl space-y-1.5">
                    <label className="text-xs font-bold text-slate-700 block">
                      الكمية <span className="text-rose-500">*</span>
                    </label>
                    <select
                      value={colQuantity}
                      onChange={(e) => setColQuantity(parseInt(e.target.value))}
                      className="w-full p-2 bg-white border border-slate-200 rounded-lg text-xs font-bold text-slate-800 focus:border-emerald-500 focus:outline-hidden"
                    >
                      <option value={-1}>-- اختر عمود الكمية --</option>
                      {detectedColumns.map(col => (
                        <option key={col.index} value={col.index}>
                          {col.label} (عمود {col.index + 1})
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* 3. Unit Price (Required) */}
                  <div className="p-2.5 bg-slate-50/70 border border-slate-200 rounded-xl space-y-1.5">
                    <label className="text-xs font-bold text-slate-700 block">
                      سعر الوحدة <span className="text-rose-500">*</span>
                    </label>
                    <select
                      value={colUnitPrice}
                      onChange={(e) => setColUnitPrice(parseInt(e.target.value))}
                      className="w-full p-2 bg-white border border-slate-200 rounded-lg text-xs font-bold text-slate-800 focus:border-emerald-500 focus:outline-hidden"
                    >
                      <option value={-1}>-- اختر عمود السعر --</option>
                      {detectedColumns.map(col => (
                        <option key={col.index} value={col.index}>
                          {col.label} (عمود {col.index + 1})
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* 4. Unit (Optional with fallback) */}
                  <div className="p-2.5 bg-slate-50/70 border border-slate-200 rounded-xl space-y-1.5">
                    <label className="text-xs font-bold text-slate-700 block">
                      الوحدة (اختياري)
                    </label>
                    <div className="space-y-1.5">
                      <select
                        value={colUnit}
                        onChange={(e) => setColUnit(parseInt(e.target.value))}
                        className="w-full p-2 bg-white border border-slate-200 rounded-lg text-xs text-slate-800 focus:border-emerald-500 focus:outline-hidden"
                      >
                        <option value={-1}>-- غير متوفر بالملف (استخدام الافتراضية) --</option>
                        {detectedColumns.map(col => (
                          <option key={col.index} value={col.index}>
                            {col.label} (عمود {col.index + 1})
                          </option>
                        ))}
                      </select>
                      {colUnit === -1 && (
                        <div className="flex items-center gap-1.5 text-[11px] text-slate-500">
                          <span>الوحدة الافتراضية:</span>
                          <select
                            value={defaultUnit}
                            onChange={(e) => setDefaultUnit(e.target.value)}
                            className="p-1 bg-white border border-slate-200 rounded-md text-[11px] font-bold text-slate-700"
                          >
                            {COMMON_UNITS.map(u => (
                              <option key={u} value={u}>{u}</option>
                            ))}
                          </select>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* 5. Category (Optional with fixed or column) */}
                  <div className="p-2.5 bg-slate-50/70 border border-slate-200 rounded-xl space-y-1.5">
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-bold text-slate-700 block">
                        فئة الصنف
                      </label>
                      <div className="flex items-center gap-2 text-[10px]">
                        <button
                          type="button"
                          onClick={() => setCategoryMode('fixed')}
                          className={`font-bold px-1.5 py-0.5 rounded cursor-pointer ${categoryMode === 'fixed' ? 'bg-amber-100 text-amber-800' : 'text-slate-400'}`}
                        >
                          موحدة
                        </button>
                        <button
                          type="button"
                          onClick={() => setCategoryMode('column')}
                          className={`font-bold px-1.5 py-0.5 rounded cursor-pointer ${categoryMode === 'column' ? 'bg-amber-100 text-amber-800' : 'text-slate-400'}`}
                        >
                          من عمود
                        </button>
                      </div>
                    </div>

                    {categoryMode === 'column' ? (
                      <select
                        value={colCategory}
                        onChange={(e) => setColCategory(parseInt(e.target.value))}
                        className="w-full p-2 bg-white border border-slate-200 rounded-lg text-xs text-slate-800 focus:border-emerald-500 focus:outline-hidden"
                      >
                        <option value={-1}>-- اختر عمود الفئة --</option>
                        {detectedColumns.map(col => (
                          <option key={col.index} value={col.index}>
                            {col.label} (عمود {col.index + 1})
                          </option>
                        ))}
                      </select>
                    ) : (
                      <select
                        value={defaultCategory}
                        onChange={(e) => setDefaultCategory(e.target.value)}
                        className="w-full p-2 bg-white border border-slate-200 rounded-lg text-xs font-bold text-slate-800 focus:border-emerald-500 focus:outline-hidden"
                      >
                        {categories.map(cat => (
                          <option key={cat} value={cat}>{cat}</option>
                        ))}
                      </select>
                    )}
                  </div>

                  {/* 6. Notes (Optional) */}
                  <div className="p-2.5 bg-slate-50/70 border border-slate-200 rounded-xl space-y-1.5">
                    <label className="text-xs font-bold text-slate-700 block">
                      الملاحظات (اختياري)
                    </label>
                    <select
                      value={colNotes}
                      onChange={(e) => setColNotes(parseInt(e.target.value))}
                      className="w-full p-2 bg-white border border-slate-200 rounded-lg text-xs text-slate-800 focus:border-emerald-500 focus:outline-hidden"
                    >
                      <option value={-1}>-- لا توجد ملاحظات بالملف --</option>
                      {detectedColumns.map(col => (
                        <option key={col.index} value={col.index}>
                          {col.label} (عمود {col.index + 1})
                        </option>
                      ))}
                    </select>
                  </div>

                </div>

                {/* Additional Row: Invoice Number & Import Mode */}
                <div className="pt-2 border-t border-slate-100 grid grid-cols-1 sm:grid-cols-2 gap-3">
                  
                  {/* Invoice Number */}
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-700 block">
                      رقم الفاتورة المرتبط بالكشف (اختياري)
                    </label>
                    <div className="flex gap-2">
                      <select
                        value={colInvoiceNumber}
                        onChange={(e) => setColInvoiceNumber(parseInt(e.target.value))}
                        className="flex-1 p-2 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-700"
                      >
                        <option value={-1}>-- من عمود بالملف --</option>
                        {detectedColumns.map(col => (
                          <option key={col.index} value={col.index}>
                            {col.label}
                          </option>
                        ))}
                      </select>
                      <input 
                        type="text"
                        placeholder="أو اكتب رقم الفاتورة يدويًا"
                        value={manualInvoiceNumber}
                        onChange={(e) => setManualInvoiceNumber(e.target.value)}
                        className="flex-1 p-2 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-700 placeholder:text-slate-400"
                      />
                    </div>
                  </div>

                  {/* Mode: Append vs Replace */}
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-700 block">
                      طريقة إضافة الأصناف إلى الكشف
                    </label>
                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={() => setImportMode('append')}
                        className={`flex-1 py-2 px-3 rounded-lg text-xs font-bold border transition-all cursor-pointer ${
                          importMode === 'append'
                            ? 'bg-emerald-50 border-emerald-300 text-emerald-900 shadow-2xs'
                            : 'bg-slate-50 border-slate-200 text-slate-500 hover:bg-slate-100'
                        }`}
                      >
                        ➕ إلحاق بالكشف الحالي ({existingCount} صنف)
                      </button>
                      <button
                        type="button"
                        onClick={() => setImportMode('replace')}
                        className={`flex-1 py-2 px-3 rounded-lg text-xs font-bold border transition-all cursor-pointer ${
                          importMode === 'replace'
                            ? 'bg-rose-50 border-rose-300 text-rose-900 shadow-2xs'
                            : 'bg-slate-50 border-slate-200 text-slate-500 hover:bg-slate-100'
                        }`}
                      >
                        🔄 استبدال الكشف الحالي بالكامل
                      </button>
                    </div>
                  </div>

                </div>

              </div>

              {/* Live Preview Table */}
              <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
                <div className="p-3 border-b border-slate-100 bg-slate-50 flex items-center justify-between gap-2 flex-wrap">
                  <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                    <Eye size={15} className="text-emerald-600" />
                    <span>معاينة حية للبيانات المستخرجة ({parsedItemsPreview.length} صنف جاهز للاستيراد):</span>
                  </span>
                  {parsedItemsPreview.length > 0 && (
                    <span className="text-xs font-extrabold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2.5 py-0.5 rounded-lg font-mono">
                      إجمالي القيمة: {formatCurrency(totalAmount, currency)}
                    </span>
                  )}
                </div>

                <div className="overflow-x-auto touch-pan-x touch-pan-y max-h-52">
                  {colItemName === -1 ? (
                    <div className="text-center py-8 px-4 text-xs text-slate-400">
                      حدد عمود (اسم الصنف / المادة) من القائمة أعلاه لمعاينة البيانات
                    </div>
                  ) : parsedItemsPreview.length === 0 ? (
                    <div className="text-center py-8 px-4 text-xs text-rose-500">
                      لم يتم العثور على أسطر تحتوي على أسماء أصناف في العمود المحدد.
                    </div>
                  ) : (
                    <table className="w-full text-right text-xs border-collapse">
                      <thead className="sticky top-0 bg-slate-100 text-slate-600 font-bold border-b border-slate-200">
                        <tr>
                          <th className="p-2 text-center w-10">#</th>
                          <th className="p-2 min-w-[130px]">الصنف / المادة</th>
                          <th className="p-2 text-center w-16">الوحدة</th>
                          <th className="p-2 text-center w-20">الكمية</th>
                          <th className="p-2 text-center w-24">سعر الوحدة</th>
                          <th className="p-2 text-center w-28">الإجمالي</th>
                          <th className="p-2 min-w-[100px]">الفئة</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {parsedItemsPreview.slice(0, 6).map((item, idx) => (
                          <tr key={idx} className="hover:bg-slate-50 transition-colors">
                            <td className="p-2 text-center text-slate-400 font-mono text-[11px]">{idx + 1}</td>
                            <td className="p-2 font-bold text-slate-800">{item.itemName}</td>
                            <td className="p-2 text-center text-slate-600">{item.unit}</td>
                            <td className="p-2 text-center font-mono font-bold text-slate-700">{item.quantity}</td>
                            <td className="p-2 text-center font-mono text-slate-700">{formatCurrency(item.unitPrice, currency)}</td>
                            <td className="p-2 text-center font-mono font-bold text-emerald-600">{formatCurrency(item.total, currency)}</td>
                            <td className="p-2 text-slate-500 text-[11px]">{item.category}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  )}
                </div>

                {parsedItemsPreview.length > 6 && (
                  <div className="p-2 bg-slate-50 border-t border-slate-100 text-center text-[11px] text-slate-400 font-medium">
                    يتم عرض أول 6 أصناف كمعاينة، وسيتم استيراد كافة الأصناف البالغ عددها ({parsedItemsPreview.length}) صنفاً.
                  </div>
                )}
              </div>

            </div>
          )}

          {/* Error Message */}
          {errorMessage && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-700 font-bold flex items-center gap-2">
              <AlertCircle size={16} className="shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

        </div>

        {/* Modal Footer */}
        <div className="p-3.5 sm:p-4 border-t border-slate-100 bg-white flex items-center justify-between shrink-0">
          <button
            type="button"
            onClick={onClose}
            className="bg-white border border-slate-200 hover:bg-slate-100 text-slate-700 font-bold text-xs py-2 px-4 rounded-xl transition-colors cursor-pointer"
          >
            إلغاء
          </button>

          {fileName && parsedItemsPreview.length > 0 && (
            <button
              type="button"
              onClick={handleConfirmImport}
              className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs py-2.5 px-5 rounded-xl shadow-xs transition-colors cursor-pointer flex items-center gap-1.5"
            >
              <Check size={16} />
              <span>
                تأكيد واستيراد ({parsedItemsPreview.length}) صنفاً بقيمة {formatCurrency(totalAmount, currency)}
              </span>
            </button>
          )}
        </div>

      </div>
    </div>
  );
}
