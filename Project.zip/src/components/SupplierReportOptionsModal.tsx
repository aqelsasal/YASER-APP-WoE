/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  X, 
  Printer, 
  FileSpreadsheet, 
  FileText, 
  CheckCircle2, 
  Layers, 
  Sparkles,
  ArrowRight
} from 'lucide-react';

export type SupplierReportType = 'detailed' | 'condensed';

interface SupplierReportOptionsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: (reportType: SupplierReportType) => void;
  title?: string;
  subtitle?: string;
  supplierName?: string;
  totalMaterialsCount?: number;
}

export default function SupplierReportOptionsModal({
  isOpen,
  onClose,
  onConfirm,
  title = 'خيارات طباعة كشف حساب المورد',
  subtitle = 'يرجى اختيار شكل التقرير المطلوب طباعته أو تصديره إلى PDF',
  supplierName,
  totalMaterialsCount
}: SupplierReportOptionsModalProps) {
  const [selectedType, setSelectedType] = useState<SupplierReportType>('detailed');

  if (!isOpen) return null;

  const handlePrint = (typeToUse?: SupplierReportType) => {
    const finalType = typeToUse || selectedType;
    onConfirm(finalType);
    onClose();
  };

  return (
    <div 
      className="fixed inset-0 z-[160] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-fade-in dir-rtl"
      onClick={onClose}
    >
      <div 
        className="bg-white rounded-2xl shadow-2xl max-w-lg w-full overflow-hidden border border-slate-200/80 transform transition-all animate-scale-in"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="bg-gradient-to-r from-purple-700 via-indigo-700 to-indigo-800 text-white p-5 relative">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-white/10 backdrop-blur-md rounded-xl border border-white/20 shadow-xs">
                <Printer size={22} className="text-purple-200" />
              </div>
              <div>
                <h3 className="text-base font-extrabold text-white flex items-center gap-2">
                  <span>{title}</span>
                  <span className="text-[10px] font-bold bg-white/20 text-purple-100 px-2 py-0.5 rounded-full border border-white/20">
                    PDF / طباعة
                  </span>
                </h3>
                <p className="text-xs text-purple-200 mt-0.5 font-medium">
                  {subtitle}
                </p>
              </div>
            </div>
            <button 
              type="button"
              onClick={onClose}
              className="p-1.5 text-white/80 hover:text-white hover:bg-white/15 rounded-lg transition-colors cursor-pointer"
              title="إغلاق"
            >
              <X size={18} />
            </button>
          </div>

          {supplierName && (
            <div className="mt-3 pt-3 border-t border-white/15 flex items-center justify-between text-xs">
              <div className="flex items-center gap-1.5 text-white/95">
                <span className="text-purple-200">المورد المستهدف:</span>
                <span className="font-extrabold text-white underline decoration-purple-300 underline-offset-4">
                  {supplierName}
                </span>
              </div>
              {typeof totalMaterialsCount === 'number' && totalMaterialsCount > 0 && (
                <div className="text-[11px] bg-amber-400/20 text-amber-200 border border-amber-300/30 px-2 py-0.5 rounded-md font-bold">
                  {totalMaterialsCount} صنف مادة مسجل
                </div>
              )}
            </div>
          )}
        </div>

        {/* Content Body */}
        <div className="p-5 space-y-4">
          <div className="text-xs font-bold text-slate-700">
            حدد نوع وهيئة التقرير المناسبة:
          </div>

          {/* Option 1: Detailed Report */}
          <div 
            onClick={() => setSelectedType('detailed')}
            className={`relative p-4 rounded-xl border-2 transition-all cursor-pointer text-right flex flex-col gap-2 ${
              selectedType === 'detailed'
                ? 'border-purple-600 bg-purple-50/70 shadow-xs'
                : 'border-slate-200 hover:border-purple-300 hover:bg-slate-50/70 bg-white'
            }`}
          >
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-start gap-3">
                <div className={`p-2.5 rounded-xl shrink-0 mt-0.5 ${
                  selectedType === 'detailed' 
                    ? 'bg-purple-600 text-white shadow-xs' 
                    : 'bg-purple-100 text-purple-700'
                }`}>
                  <FileSpreadsheet size={20} />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-extrabold text-sm text-slate-900">
                      تقرير تفصيلي شامل كشف المواد
                    </span>
                    <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-purple-100 text-purple-800 border border-purple-200">
                      موصى به للتدقيق
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                    يعرض كشف الحساب المالي كاملاً مع إدراج <strong className="text-purple-900">جداول تفاصيل الأصناف والمواد الموردة</strong> بصفوف مستقلة كاملة العرض (Sub-Rows) أسفل كل فاتورة لتسهيل القراءة والتدقيق.
                  </p>
                </div>
              </div>
              <div className="shrink-0 mt-1">
                {selectedType === 'detailed' ? (
                  <CheckCircle2 size={20} className="text-purple-600 fill-purple-100" />
                ) : (
                  <div className="w-5 h-5 rounded-full border-2 border-slate-300" />
                )}
              </div>
            </div>

            <div className="flex items-center gap-3 text-[11px] text-purple-800 bg-purple-100/60 rounded-lg px-2.5 py-1.5 font-medium mt-1">
              <span className="flex items-center gap-1 font-bold">
                <Layers size={13} className="text-purple-600" />
                يتضمن:
              </span>
              <span>الأصناف والكميات</span>
              <span>•</span>
              <span>أسعار الوحدات والإجماليات</span>
              <span>•</span>
              <span>الخصومات والفئات الموردة</span>
            </div>
          </div>

          {/* Option 2: Condensed / Summary Report */}
          <div 
            onClick={() => setSelectedType('condensed')}
            className={`relative p-4 rounded-xl border-2 transition-all cursor-pointer text-right flex flex-col gap-2 ${
              selectedType === 'condensed'
                ? 'border-sky-600 bg-sky-50/70 shadow-xs'
                : 'border-slate-200 hover:border-sky-300 hover:bg-slate-50/70 bg-white'
            }`}
          >
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-start gap-3">
                <div className={`p-2.5 rounded-xl shrink-0 mt-0.5 ${
                  selectedType === 'condensed' 
                    ? 'bg-sky-600 text-white shadow-xs' 
                    : 'bg-sky-100 text-sky-700'
                }`}>
                  <FileText size={20} />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-extrabold text-sm text-slate-900">
                      تقرير مالي مختصر (كشف حساب مالي فقط)
                    </span>
                    <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-sky-100 text-sky-800 border border-sky-200">
                      موجز واقتصادي
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                    يعرض ملخص الحركات المالية والقيود والفواتير والدفعات فقط دون جداول كشف المواد الداخلية (يوفر الصفحات لتقديم خلاصة مالية سريعة).
                  </p>
                </div>
              </div>
              <div className="shrink-0 mt-1">
                {selectedType === 'condensed' ? (
                  <CheckCircle2 size={20} className="text-sky-600 fill-sky-100" />
                ) : (
                  <div className="w-5 h-5 rounded-full border-2 border-slate-300" />
                )}
              </div>
            </div>

            <div className="flex items-center gap-3 text-[11px] text-sky-800 bg-sky-100/60 rounded-lg px-2.5 py-1.5 font-medium mt-1">
              <span className="flex items-center gap-1 font-bold">
                <Sparkles size={13} className="text-sky-600" />
                المزايا:
              </span>
              <span>عدد صفحات أقل</span>
              <span>•</span>
              <span>مطابقة سريعة للأرصدة</span>
              <span>•</span>
              <span>مناسب للمراسلات السريعة</span>
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-bold text-slate-600 hover:text-slate-800 bg-white hover:bg-slate-100 border border-slate-300 rounded-xl transition-colors cursor-pointer"
          >
            إلغاء
          </button>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => handlePrint('condensed')}
              className="px-3.5 py-2 text-xs font-bold text-sky-800 bg-sky-50 hover:bg-sky-100 border border-sky-200 rounded-xl transition-all cursor-pointer shadow-2xs"
              title="طباعة مختصرة مباشرة"
            >
              طباعة مختصر
            </button>
            <button
              type="button"
              onClick={() => handlePrint('detailed')}
              className="px-5 py-2 text-xs font-extrabold text-white bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 rounded-xl shadow-xs hover:shadow-md transition-all flex items-center gap-1.5 cursor-pointer"
              title="طباعة تقرير تفصيلي"
            >
              <Printer size={15} />
              <span>طباعة تفصيلي شامل</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
