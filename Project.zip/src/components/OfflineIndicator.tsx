import React, { useState, useEffect } from 'react';
import { WifiOff } from 'lucide-react';

export const OfflineIndicator: React.FC = () => {
  const [isOnline, setIsOnline] = useState(
    typeof navigator !== 'undefined' ? navigator.onLine : true
  );

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  if (isOnline) return null;

  return (
    <div
      className="fixed bottom-4 left-4 z-50 flex items-center gap-2 rounded-xl bg-slate-900/90 text-amber-400 border border-amber-500/40 px-3.5 py-2 text-xs font-bold shadow-2xl backdrop-blur-xs animate-bounce"
      dir="rtl"
    >
      <WifiOff size={15} className="text-amber-400" />
      <span>أنت تعمل حالياً بدون إنترنت (Offline) — البيانات تُحفظ في ذاكرة الهاتف</span>
    </div>
  );
};
