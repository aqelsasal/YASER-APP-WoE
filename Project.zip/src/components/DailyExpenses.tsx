/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo, useRef } from 'react';
import PageHeaderCard from './PageHeaderCard';
import { 
  PlusCircle, 
  Trash2, 
  Search, 
  Calendar, 
  ArrowLeftRight, 
  Tag, 
  Filter,
  DollarSign,
  AlertCircle,
  ArrowLeft,
  Pencil,
  FileSpreadsheet,
  FileText,
  Check,
  TrendingUp,
  ChevronDown,
  ChevronUp,
  RotateCcw,
  CalendarClock,
  FolderCog
} from 'lucide-react';
import { AmountInWords } from './AmountInWords';
import { 
  Expense, 
  Worker, 
  Supplier, 
  Employee,
  ContractItem,
  formatCurrency, 
  formatDateArabic,
  getTodayDateString,
  exportToCSV,
  printPDF,
  createOfficialReportHtml
} from '../types';
import { 
  generateSvgDonutChart, 
  generateSvgHorizontalBars, 
  generateMetricCardsGrid 
} from '../utils/reportCharts';
import AttributionBadge from './AttributionBadge';
import Calculator from './Calculator';
import ShareMenu from './ShareMenu';
import OptionsMenu from './OptionsMenu';
import { PostingAccountSelect } from './PostingAccountSelect';
import ExcelColumnFilter, { ColumnFilterConfig, ActiveColumnFilter, ColumnSortState } from './ExcelColumnFilter';
import { useBodyScrollLock } from '../utils/modalScrollLock';
import * as XLSX from 'xlsx';
import CategoryManagerModal from './CategoryManagerModal';
import { useExpenseCategories, DEFAULT_EXPENSE_CATEGORIES } from '../utils/expenseCategories';
import { useExpenseTypes } from '../utils/expenseTypes';

interface DailyExpensesProps {
  expenses: Expense[];
  workers: Worker[];
  suppliers: Supplier[];
  employees?: Employee[];
  contractItems?: ContractItem[];
  onAddExpense: (expense: Omit<Expense, 'id'>) => void;
  onDeleteExpense: (id: string) => void;
  onUpdateExpense?: (id: string, updatedData: Omit<Expense, 'id' | 'createdBy'>) => void;
  onAddWorker?: (worker: Omit<Worker, 'id' | 'ledger'>) => Worker | void;
  onAddEmployee?: (employee: Omit<Employee, 'id' | 'ledger'>) => Employee | void;
  onAddSupplier?: (supplier: Omit<Supplier, 'id' | 'ledger'>) => Supplier | void;
  setActiveTab?: (tab: string) => void;
  currency?: string;
  sharedRole?: string;
}

// Category Options (defaults)
export const EXPENSE_CATEGORIES = DEFAULT_EXPENSE_CATEGORIES;

/**
 * Returns effective categories for an expense.
 * If user already provided categories, use them.
 * Otherwise, if recipientType is employee -> ['مرتبات وموظفين'], if worker -> ['أجور وعمالة'].
 */
export const getEffectiveExpenseCategories = (exp: {
  categories?: string[];
  category?: string;
  recipientType?: 'worker' | 'employee' | 'supplier' | 'none';
}): string[] => {
  if (exp.categories && exp.categories.length > 0) {
    return exp.categories;
  }
  if (exp.category && exp.category.trim() !== '') {
    return [exp.category];
  }
  if (exp.recipientType === 'employee') {
    return ['مرتبات وموظفين'];
  }
  if (exp.recipientType === 'worker') {
    return ['أجور وعمالة'];
  }
  return [];
};

interface AddExpenseCardProps {
  onAddExpense: (expense: Omit<Expense, 'id'>) => void;
  workers: Worker[];
  suppliers: Supplier[];
  employees: Employee[];
  contractItems?: ContractItem[];
  currency: string;
  sharedRole: string;
  onAddWorker?: (worker: Omit<Worker, 'id' | 'ledger'>) => Worker | void;
  onAddEmployee?: (employee: Omit<Employee, 'id' | 'ledger'>) => Employee | void;
  onAddSupplier?: (supplier: Omit<Supplier, 'id' | 'ledger'>) => Supplier | void;
  expenses?: Expense[];
  onUpdateExpense?: (id: string, updatedData: Omit<Expense, 'id' | 'createdBy'>) => void;
}

// Sub-component for Add Expense Form with isolated state to guarantee zero typing latency
const AddExpenseCard: React.FC<AddExpenseCardProps> = React.memo(({
  onAddExpense,
  workers,
  suppliers,
  employees,
  contractItems = [],
  currency,
  sharedRole,
  onAddWorker,
  onAddEmployee,
  onAddSupplier,
  expenses = [],
  onUpdateExpense
}) => {
  const getTodayString = () => {
    const today = new Date();
    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, '0');
    const day = String(today.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  const amountInputRef = useRef<HTMLInputElement>(null);
  const descriptionInputRef = useRef<HTMLInputElement>(null);

  const { 
    categories: expenseCategories, 
    addCategory, 
    editCategory, 
    deleteCategory, 
    resetDefaults: resetExpenseCategories 
  } = useExpenseCategories();

  const { 
    expenseTypes, 
    addExpenseType, 
    editExpenseType, 
    deleteExpenseType, 
    resetDefaults: resetExpenseTypes 
  } = useExpenseTypes();

  const [showCategoryModal, setShowCategoryModal] = useState(false);
  const [showExpenseTypeModal, setShowExpenseTypeModal] = useState(false);

  // Form states isolated inside this component
  const [isAddExpenseOpen, setIsAddExpenseOpen] = useState(false);
  const [date, setDate] = useState(getTodayString);
  const [amount, setAmount] = useState('');
  const [description, setDescription] = useState('');
  const [expenseType, setExpenseType] = useState<string>('direct');
  const [categories, setCategories] = useState<string[]>([]);
  const [hasManuallySelectedCategories, setHasManuallySelectedCategories] = useState(false);
  const [notes, setNotes] = useState('');
  const [postTo, setPostTo] = useState('');
  const [contractItemId, setContractItemId] = useState('');
  const [contractItemNumber, setContractItemNumber] = useState('');
  const [contractItemName, setContractItemName] = useState('');
  const [itemCurrency, setItemCurrency] = useState(currency);
  const [successMsg, setSuccessMsg] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  useEffect(() => {
    setItemCurrency(currency);
  }, [currency]);

  // Handler for changing recipient posting account with smart auto-categorization
  const handlePostToChange = (newPostTo: string) => {
    setPostTo(newPostTo);

    // Only auto-assign category if user hasn't explicitly customized categories
    if (!hasManuallySelectedCategories) {
      if (newPostTo && newPostTo !== 'none') {
        const [type] = newPostTo.split(':');
        if (type === 'employee') {
          setCategories(['مرتبات وموظفين']);
        } else if (type === 'worker') {
          setCategories(['أجور وعمالة']);
        } else if (type === 'supplier') {
          setCategories(['مواد بناء وكهرباء']);
        } else {
          setCategories([]);
        }
      } else {
        setCategories([]);
      }
    }
  };

  const toggleCategory = (cat: string) => {
    setHasManuallySelectedCategories(true);
    setCategories(prev =>
      prev.includes(cat) ? prev.filter(c => c !== cat) : [...prev, cat]
    );
  };

  const handleResetExpenseForm = () => {
    setDate(getTodayString());
    setAmount('');
    setDescription('');
    setExpenseType('direct');
    setCategories([]);
    setHasManuallySelectedCategories(false);
    setNotes('');
    setPostTo('');
    setContractItemId('');
    setContractItemNumber('');
    setContractItemName('');
    setItemCurrency(currency);
    setErrorMsg('');
    setTimeout(() => {
      amountInputRef.current?.focus();
    }, 50);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    const parsedAmount = parseFloat(amount);
    if (isNaN(parsedAmount) || parsedAmount <= 0) {
      setErrorMsg('الرجاء إدخال مبلغ صحيح أكبر من الصفر.');
      amountInputRef.current?.focus();
      return;
    }

    if (!description.trim()) {
      setErrorMsg('الرجاء إدخال البيان.');
      descriptionInputRef.current?.focus();
      return;
    }

    let recipientId = '';
    let recipientType: 'worker' | 'employee' | 'supplier' | 'none' = 'none';
    let recipientName = '';

    if (postTo && postTo !== 'none') {
      const [type, id] = postTo.split(':');
      recipientId = id;
      if (type === 'worker') {
        recipientType = 'worker';
        const w = workers.find(item => item.id === id);
        recipientName = w ? w.name : '';
      } else if (type === 'employee') {
        recipientType = 'employee';
        const emp = employees.find(item => item.id === id);
        recipientName = emp ? emp.name : '';
      } else if (type === 'supplier') {
        recipientType = 'supplier';
        const s = suppliers.find(item => item.id === id);
        recipientName = s ? s.name : '';
      }
    }

    // Determine final categories: use categories if selected, otherwise fallback to auto-category based on recipient
    let finalCategories = [...categories];
    if (finalCategories.length === 0) {
      if (recipientType === 'employee') {
        finalCategories = ['مرتبات وموظفين'];
      } else if (recipientType === 'worker') {
        finalCategories = ['أجور وعمالة'];
      } else if (recipientType === 'supplier') {
        finalCategories = ['مواد بناء وكهرباء'];
      }
    }

    onAddExpense({
      date,
      amount: parsedAmount,
      description: description.trim(),
      expenseType,
      categories: finalCategories,
      notes: notes.trim(),
      recipientId,
      recipientType,
      recipientName,
      currency: itemCurrency,
      contractItemId: contractItemId || undefined,
      contractItemNumber: contractItemNumber || undefined,
      contractItemName: contractItemName || undefined,
      recordedDate: getTodayString()
    });

    // Reset Form
    setAmount('');
    setDescription('');
    setExpenseType('direct');
    setCategories([]);
    setHasManuallySelectedCategories(false);
    setNotes('');
    setPostTo('');
    setContractItemId('');
    setContractItemNumber('');
    setContractItemName('');
    setSuccessMsg('تم تسجيل النفقة وترحيلها بنجاح!');

    // Automatically shift typing cursor back to the Amount input field
    setTimeout(() => {
      if (amountInputRef.current) {
        amountInputRef.current.focus();
        amountInputRef.current.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      }
    }, 50);

    setTimeout(() => setSuccessMsg(''), 4000);
  };

  return (
    <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-xs h-fit" id="expense-form-container">
      {sharedRole === 'read' ? (
        <div className="text-center py-8 space-y-3">
          <div className="mx-auto w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center text-slate-400">
            <Tag size={24} />
          </div>
          <h3 className="font-bold text-slate-800 text-sm">وضع عرض الحساب المشترك</h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            تمت دعوتك بصلاحية (عرض فقط). لا يمكنك إضافة نفقات جديدة أو ترحيل مبالغ لحسابات العمال والموردين.
          </p>
        </div>
      ) : (
        <>
          <button
            type="button"
            onClick={() => {
              setIsAddExpenseOpen(prev => {
                const next = !prev;
                if (next) {
                  setTimeout(() => amountInputRef.current?.focus(), 100);
                }
                return next;
              });
            }}
            className="w-full bg-gradient-to-r from-emerald-600 via-emerald-600 to-emerald-700 hover:from-emerald-700 hover:to-emerald-800 text-white font-black text-sm sm:text-base p-3.5 rounded-xl shadow-md shadow-emerald-600/20 flex items-center justify-between transition-all cursor-pointer select-none active:scale-[0.99] border border-emerald-500/50 text-right"
          >
            <div className="flex items-center gap-2.5">
              <div className="p-1.5 bg-white/20 rounded-lg text-white shrink-0">
                <PlusCircle size={20} />
              </div>
              <span className="font-extrabold tracking-wide">إضافة نفقة جديدة</span>
            </div>
            <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-950 bg-white/90 hover:bg-white px-3 py-1.5 rounded-lg transition-colors shadow-xs shrink-0">
              <span className="hidden sm:inline">{isAddExpenseOpen ? 'طي النموذج ▲' : 'إظهار النموذج ▼'}</span>
              <span className="sm:hidden">{isAddExpenseOpen ? 'طي ▲' : 'إظهار ▼'}</span>
            </div>
          </button>

          {isAddExpenseOpen && (
            <form onSubmit={handleSubmit} className="space-y-4 pt-4 border-t border-slate-100 mt-3">
              {/* Date Picker */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-600 block">التاريخ</label>
                <div className="relative">
                  <input 
                    type="date" 
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full h-[42px] px-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-sm focus:outline-hidden focus:border-rose-500 transition-colors pr-10"
                    required
                  />
                  <Calendar size={18} className="absolute top-1/2 -translate-y-1/2 right-3.5 text-slate-400 pointer-events-none" />
                </div>
                <span className="text-[10px] text-slate-400">يتم تحديد التاريخ تلقائياً ويمكنك تعديله من التقويم.</span>
              </div>

              {/* Amount & Currency */}
              <div className="grid grid-cols-3 gap-3">
                <div className="col-span-2 space-y-1.5">
                  <label className="text-xs font-bold text-slate-600 block">المبلغ</label>
                  <div className="flex gap-1.5 items-center">
                    <input 
                      ref={amountInputRef}
                      type="number" 
                      value={amount}
                      onChange={(e) => setAmount(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault();
                          descriptionInputRef.current?.focus();
                        }
                      }}
                      placeholder="مثال: 50000"
                      className="w-full h-[42px] px-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-sm focus:outline-hidden focus:border-rose-500 transition-colors"
                      required
                      min="1"
                    />
                    <Calculator onApply={(val) => setAmount(String(val))} />
                  </div>
                  <AmountInWords amount={amount} currency={itemCurrency} />
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-600 block">العملة</label>
                  <select
                    value={itemCurrency}
                    onChange={(e) => setItemCurrency(e.target.value)}
                    tabIndex={-1}
                    className="w-full h-[42px] px-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-sm focus:outline-hidden focus:border-rose-500 transition-colors cursor-pointer"
                  >
                    <option value="YER">﷼ يمني</option>
                    <option value="SAR">﷼ سعودي</option>
                    <option value="USD">$ دولار</option>
                  </select>
                </div>
              </div>

              {/* Description / Statement */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-600 block">البيان</label>
                <input 
                  ref={descriptionInputRef}
                  type="text" 
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="مثال: شراء إسمنت مقاوم / دفعة أجور"
                  className="w-full h-[42px] px-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-sm focus:outline-hidden focus:border-rose-500 transition-colors"
                  required
                />
              </div>

              {/* Post / Transfer To Account Dropdown - positioned above Expense Type and below Description */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-600 flex items-center gap-1">
                  <ArrowLeftRight size={14} className="text-rose-500" />
                  ترحيل إلى حساب (اختياري)
                </label>
                <PostingAccountSelect 
                  value={postTo}
                  onChange={handlePostToChange}
                  workers={workers}
                  employees={employees}
                  suppliers={suppliers}
                  currency={currency}
                  sharedRole={sharedRole}
                  onAddWorker={onAddWorker}
                  onAddEmployee={onAddEmployee}
                  onAddSupplier={onAddSupplier}
                />
                <span className="text-[10px] text-slate-400 leading-relaxed block">
                  عند اختيار عامل، موظف، أو مورد، سيتم ترحيل المبلغ كـ <strong>"مبلغ عليه"</strong> في كشف حسابه تلقائياً مع الاحتفاظ بنسخة هنا.
                </span>
              </div>

              {/* Contract / BOQ Item Link (جدول الكميات وبنود العقد) */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-600 flex items-center justify-between">
                  <span className="flex items-center gap-1">
                    <FileSpreadsheet size={14} className="text-teal-600" />
                    بند العقد / جدول الكميات (اختياري)
                  </span>
                  {contractItemId && (
                    <button
                      type="button"
                      onClick={() => {
                        setContractItemId('');
                        setContractItemNumber('');
                        setContractItemName('');
                      }}
                      className="text-[10px] text-rose-500 hover:underline font-bold cursor-pointer"
                    >
                      إلغاء الربط ✕
                    </button>
                  )}
                </label>
                <select
                  value={contractItemId}
                  onChange={(e) => {
                    const id = e.target.value;
                    setContractItemId(id);
                    const matched = contractItems.find(c => c.id === id);
                    if (matched) {
                      setContractItemNumber(matched.itemNumber);
                      setContractItemName(matched.name);
                    } else {
                      setContractItemNumber('');
                      setContractItemName('');
                    }
                  }}
                  className="w-full h-[42px] px-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-xs sm:text-sm font-semibold focus:outline-hidden focus:border-teal-500 transition-colors cursor-pointer"
                >
                  <option value="">-- غير مرتبط ببند عقد محدد (مصروف عام) --</option>
                  {contractItems.map(item => (
                    <option key={item.id} value={item.id}>
                      {item.isMainItem ? `[بند رئيسي ${item.itemNumber}] ${item.name}` : `[فقرة ${item.itemNumber}] ${item.name} (${item.parentName || 'بند ' + (item.parentItemNumber || '')})`}
                    </option>
                  ))}
                </select>
                <span className="text-[10px] text-slate-400 leading-relaxed block">
                  ربط هذا المصروف ببند أو فقرة من جدول الكميات لاحتساب تكلفته الفعلية تلقائياً.
                </span>
              </div>

              {/* Expense Type Selector */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <label className="text-xs font-bold text-slate-600 block">نوع النفقة</label>
                    <span className="text-[10px] text-slate-400">(نفقات مباشرة / غير مباشرة)</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setShowExpenseTypeModal(true)}
                    className="text-[11px] font-bold text-amber-800 hover:text-amber-900 flex items-center gap-1.5 bg-amber-50 hover:bg-amber-100/90 px-2.5 py-1 rounded-lg border border-amber-300/80 transition-all shadow-2xs hover:shadow-xs active:scale-95 cursor-pointer"
                    title="إدارة أنواع النفقات (إضافة - تعديل - حذف)"
                  >
                    <FolderCog size={13} className="text-amber-700 stroke-[2.2]" />
                    <span>إدارة الفئة</span>
                  </button>
                </div>
                <div className="grid grid-cols-2 gap-2 bg-slate-50 p-2.5 rounded-xl border border-slate-200">
                  {expenseTypes.map((t) => {
                    const isSelected = expenseType === t.id || expenseType === t.name;
                    return (
                      <button
                        key={t.id}
                        type="button"
                        onClick={() => setExpenseType(t.id)}
                        className={`flex items-center gap-2 p-2 rounded-lg transition-all cursor-pointer select-none text-xs font-bold ${
                          isSelected
                            ? 'bg-rose-50 border border-rose-200 text-rose-800'
                            : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100/50'
                        }`}
                      >
                        <div className={`w-4 h-4 rounded-xs border flex items-center justify-center transition-all shrink-0 ${
                          isSelected 
                            ? 'bg-rose-600 border-rose-600 text-white shadow-2xs' 
                            : 'border-slate-300 bg-white text-transparent hover:border-slate-400'
                        }`}>
                          <Check size={12} strokeWidth={3} className={isSelected ? 'opacity-100' : 'opacity-0'} />
                        </div>
                        <span className="truncate">{t.name}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Category ("الفئة") Multi-Select Section */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <label className="text-xs font-bold text-slate-600">الفئة</label>
                    <span className="text-[10px] text-slate-400">(يمكنك اختيار أكثر من خيار)</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setShowCategoryModal(true)}
                    className="text-[11px] font-bold text-amber-800 hover:text-amber-900 flex items-center gap-1.5 bg-amber-50 hover:bg-amber-100/90 px-2.5 py-1 rounded-lg border border-amber-300/80 transition-all shadow-2xs hover:shadow-xs active:scale-95 cursor-pointer"
                    title="إدارة فئات النفقات (إضافة - تعديل - حذف)"
                  >
                    <FolderCog size={13} className="text-amber-700 stroke-[2.2]" />
                    <span>إدارة الفئة</span>
                  </button>
                </div>
                <div className="grid grid-cols-2 gap-2 bg-slate-50 p-2.5 rounded-xl border border-slate-200">
                  {expenseCategories.map((cat) => {
                    const isSelected = categories.includes(cat);
                    return (
                      <button
                        key={cat}
                        type="button"
                        onClick={() => toggleCategory(cat)}
                        className={`flex items-center gap-2 p-2 rounded-lg transition-all cursor-pointer select-none text-xs font-bold ${
                          isSelected
                            ? 'bg-rose-50 border border-rose-300 text-rose-800'
                            : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100/50'
                        }`}
                      >
                        <div className={`w-4 h-4 rounded-xs border flex items-center justify-center transition-all shrink-0 ${
                          isSelected 
                            ? 'bg-rose-600 border-rose-600 text-white shadow-2xs' 
                            : 'border-slate-300 bg-white text-transparent hover:border-slate-400'
                        }`}>
                          <Check size={12} strokeWidth={3} className={isSelected ? 'opacity-100' : 'opacity-0'} />
                        </div>
                        <span className="truncate">{cat}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Notes */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-600 block">ملاحظات</label>
                <textarea 
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="ملاحظات إضافية حول العملية..."
                  rows={2}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-sm focus:outline-hidden focus:border-rose-500 transition-colors resize-none"
                />
              </div>

              {/* Alerts */}
              {errorMsg && (
                <div className="p-3 bg-rose-50 border border-rose-100 text-rose-700 rounded-xl text-xs flex items-center gap-2">
                  <AlertCircle size={16} />
                  <span>{errorMsg}</span>
                </div>
              )}

              {successMsg && (
                <div className="p-3 bg-emerald-50 border border-emerald-100 text-emerald-700 rounded-xl text-xs flex items-center gap-2">
                  <AlertCircle size={16} className="text-emerald-600" />
                  <span>{successMsg}</span>
                </div>
              )}

              {/* Submit and Cancel / Reset Buttons */}
              <div className="flex gap-2">
                <button 
                  type="submit"
                  className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm py-2.5 px-4 rounded-xl shadow-md shadow-emerald-600/20 transition-colors flex items-center justify-center gap-2 cursor-pointer active:scale-98"
                >
                  <PlusCircle size={18} />
                  إضافة النفقة وترحيلها
                </button>
                <button 
                  type="button"
                  onClick={handleResetExpenseForm}
                  className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold text-xs rounded-xl transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                  title="إلغاء وتنظيف الحقول"
                >
                  <RotateCcw size={15} />
                  <span>إلغاء / تنظيف</span>
                </button>
              </div>
            </form>
          )}
        </>
      )}

      {/* Category Manager Modal for Expense Categories */}
      <CategoryManagerModal
        isOpen={showCategoryModal}
        onClose={() => setShowCategoryModal(false)}
        title="إدارة فئات النفقات"
        subtitle="إضافة وتعديل وحذف فئات النفقات المتاحة في النظام وتحديث السجلات المرتبطة"
        categories={expenseCategories.map(cat => ({
          id: cat,
          name: cat,
          count: expenses.filter(e => {
            const cats = getEffectiveExpenseCategories(e);
            return cats.includes(cat);
          }).length
        }))}
        onAddCategory={(name) => addCategory(name)}
        onEditCategory={(item, newName) => {
          const res = editCategory(item.name, newName);
          if (res.success) {
            setCategories(prev => prev.map(c => c === item.name ? newName : c));
            if (onUpdateExpense) {
              expenses.forEach(exp => {
                const cats = exp.categories || (exp.category ? [exp.category] : []);
                if (cats.includes(item.name)) {
                  const updatedCats = cats.map(c => c === item.name ? newName : c);
                  const { id, createdBy, ...rest } = exp;
                  onUpdateExpense(id, { ...rest, categories: updatedCats, category: updatedCats[0] || '' });
                }
              });
            }
          }
          return res;
        }}
        onDeleteCategory={(item) => {
          const res = deleteCategory(item.name);
          if (res.success) {
            setCategories(prev => prev.filter(c => c !== item.name));
          }
          return res;
        }}
        onResetDefaults={resetExpenseCategories}
        entityUnitLabel="مصروف"
      />

      {/* Category Manager Modal for Expense Types */}
      <CategoryManagerModal
        isOpen={showExpenseTypeModal}
        onClose={() => setShowExpenseTypeModal(false)}
        title="إدارة نوع النفقة"
        subtitle="إضافة وتعديل وحذف أنواع النفقات (نفقات مباشرة / غير مباشرة أو مخصصة)"
        categories={expenseTypes.map(t => ({
          id: t.id,
          name: t.name,
          isDefault: t.isDefault,
          count: expenses.filter(e => e.expenseType === t.id || e.expenseType === t.name).length
        }))}
        onAddCategory={(name) => addExpenseType(name)}
        onEditCategory={(item, newName) => {
          const res = editExpenseType(item.id, newName);
          if (res.success) {
            if (expenseType === item.id || expenseType === item.name) {
              setExpenseType(item.id);
            }
            if (onUpdateExpense) {
              expenses.forEach(exp => {
                if (exp.expenseType === item.id || exp.expenseType === item.name) {
                  const { id, createdBy, ...rest } = exp;
                  onUpdateExpense(id, { ...rest, expenseType: newName });
                }
              });
            }
          }
          return res;
        }}
        onDeleteCategory={(item) => {
          const res = deleteExpenseType(item.id);
          if (res.success && (expenseType === item.id || expenseType === item.name)) {
            setExpenseType('direct');
          }
          return res;
        }}
        onResetDefaults={resetExpenseTypes}
        entityUnitLabel="مصروف"
      />
    </div>
  );
});

// Memoized Expense Table Row component for peak scrolling and filtering performance
interface ExpenseRowProps {
  exp: Expense;
  currency: string;
  sharedRole: string;
  onEdit: (exp: Expense) => void;
  onDelete: (id: string) => void;
}

const ExpenseRow: React.FC<ExpenseRowProps> = React.memo(({
  exp,
  currency,
  sharedRole,
  onEdit,
  onDelete
}) => {
  return (
    <tr className="hover:bg-slate-50/50 transition-colors text-slate-700">
      {/* Date */}
      <td className="p-4 whitespace-nowrap text-xs font-medium">
        {formatDateArabic(exp.date)}
      </td>
      
      {/* Statement */}
      <td className="p-4 font-semibold text-slate-800 min-w-[280px] sm:min-w-[380px]">
        <div className="flex items-center gap-1.5 flex-wrap">
          <span>{exp.description}</span>
          {exp.contractItemNumber && (
            <span 
              className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold bg-teal-50 text-teal-700 border border-teal-200" 
              title={`بند العقد: ${exp.contractItemName || ''}`}
            >
              <FileSpreadsheet size={11} className="text-teal-600 shrink-0" />
              <span>بند {exp.contractItemNumber}</span>
              {exp.contractItemName && <span className="text-teal-600/80 font-normal">({exp.contractItemName})</span>}
            </span>
          )}
          <AttributionBadge createdBy={exp.createdBy} />
        </div>
      </td>

      {/* Expense Type Badge */}
      <td className="p-4 whitespace-nowrap text-xs">
        <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-[11px] font-bold ${
          (exp.expenseType || 'direct') === 'direct'
            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
            : 'bg-amber-50 text-amber-700 border border-amber-200'
        }`}>
          {(exp.expenseType || 'direct') === 'direct' ? 'نفقات مباشرة' : 'نفقات غير مباشرة'}
        </span>
      </td>

      {/* Categories Badges */}
      <td className="p-4 whitespace-nowrap text-xs">
        {(() => {
          const effectiveCats = getEffectiveExpenseCategories(exp);
          if (effectiveCats.length > 0) {
            return (
              <div className="flex flex-wrap gap-1 max-w-[200px]">
                {effectiveCats.map((cat) => (
                  <span key={cat} className="inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-bold bg-slate-100 text-slate-700 border border-slate-200">
                    {cat}
                  </span>
                ))}
              </div>
            );
          }
          return <span className="text-slate-300 text-xs">-</span>;
        })()}
      </td>

      {/* Recipient posted */}
      <td className="p-4 whitespace-nowrap text-xs">
        {exp.recipientType !== 'none' ? (
          <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg font-semibold ${
            exp.recipientType === 'worker' 
              ? 'bg-sky-50 text-sky-700 border border-sky-100' 
              : exp.recipientType === 'employee'
              ? 'bg-indigo-50 text-indigo-700 border border-indigo-100'
              : 'bg-amber-50 text-amber-700 border border-amber-100'
          }`}>
            <Tag size={12} />
            {exp.recipientName}
            <span className="text-[9px] opacity-70">
              ({exp.recipientType === 'worker' ? 'عامل' : exp.recipientType === 'employee' ? 'موظف' : 'مورد'})
            </span>
          </span>
        ) : (
          <span className="text-slate-400 text-xs">- مصروف عام -</span>
        )}
      </td>

      {/* Amount */}
      <td className="p-4 whitespace-nowrap font-bold text-slate-900">
        {formatCurrency(exp.amount, exp.currency || 'YER')}
      </td>

      {/* Notes */}
      <td className="p-4 text-slate-500 text-xs max-w-[160px] truncate" title={exp.notes}>
        {exp.notes || <span className="text-slate-300">-</span>}
      </td>

      {/* Recorded / Last Modified Date (Phone/Device date) */}
      <td className="p-4 whitespace-nowrap text-xs text-slate-500 font-medium">
        <div className="flex items-center gap-1.5" title="تاريخ إضافة أو آخر تعديل للنفقة (تاريخ الهاتف)">
          <CalendarClock size={13} className="text-slate-400 shrink-0" />
          <span>{formatDateArabic(exp.recordedDate || exp.date)}</span>
        </div>
      </td>

      {/* Actions */}
      <td className="p-4 whitespace-nowrap text-center flex items-center justify-center gap-1.5">
        {sharedRole !== 'read' && (
          <button 
            onClick={() => onEdit(exp)}
            className="p-1.5 hover:bg-slate-50 text-slate-400 hover:text-slate-600 rounded-lg transition-colors cursor-pointer"
            title="تعديل النفقة"
          >
            <Pencil size={16} />
          </button>
        )}
        {sharedRole !== 'read' && sharedRole !== 'add' && (
          <button 
            onClick={() => onDelete(exp.id)}
            className="p-1.5 hover:bg-rose-50 text-slate-400 hover:text-rose-600 rounded-lg transition-colors cursor-pointer"
            title="حذف النفقة"
          >
            <Trash2 size={16} />
          </button>
        )}
      </td>
    </tr>
  );
});

export default function DailyExpenses({
  expenses,
  workers,
  suppliers,
  employees = [],
  contractItems = [],
  onAddExpense,
  onDeleteExpense,
  onUpdateExpense,
  onAddWorker,
  onAddEmployee,
  onAddSupplier,
  setActiveTab,
  currency = 'YER',
  sharedRole = 'admin'
}: DailyExpensesProps) {
  // Edit Expense State
  const [editingExpense, setEditingExpense] = useState<Expense | null>(null);
  const [editingPostTo, setEditingPostTo] = useState('');

  const { 
    categories: expenseCategories, 
    addCategory, 
    editCategory, 
    deleteCategory, 
    resetDefaults: resetExpenseCategories 
  } = useExpenseCategories(expenses.flatMap(e => e.categories || (e.category ? [e.category] : [])));

  const { 
    expenseTypes, 
    getTypeName,
    addExpenseType, 
    editExpenseType, 
    deleteExpenseType, 
    resetDefaults: resetExpenseTypes 
  } = useExpenseTypes();

  const [showEditExpenseCategoryModal, setShowEditExpenseCategoryModal] = useState(false);
  const [showEditExpenseTypeModal, setShowEditExpenseTypeModal] = useState(false);

  // Pagination State for high performance rendering
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(50);

  // Lock background scroll when modal is open
  useBodyScrollLock(Boolean(editingExpense));

  const toggleEditingCategory = (cat: string) => {
    if (!editingExpense) return;
    const current = editingExpense.categories || [];
    const updated = current.includes(cat)
      ? current.filter(c => c !== cat)
      : [...current, cat];
    setEditingExpense({ ...editingExpense, categories: updated });
  };

  // Submit handler for edit expense
  const handleEditExpenseSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingExpense) return;

    let recipientType: 'worker' | 'employee' | 'supplier' | 'none' = 'none';
    let recipientId = '';
    let recipientName = '';

    if (editingPostTo) {
      const [type, id] = editingPostTo.split(':');
      if (type === 'worker') {
        const worker = workers.find(w => w.id === id);
        if (worker) {
          recipientType = 'worker';
          recipientId = id;
          recipientName = worker.name;
        }
      } else if (type === 'employee') {
        const emp = employees.find(e => e.id === id);
        if (emp) {
          recipientType = 'employee';
          recipientId = id;
          recipientName = emp.name;
        }
      } else if (type === 'supplier') {
        const supplier = suppliers.find(s => s.id === id);
        if (supplier) {
          recipientType = 'supplier';
          recipientId = id;
          recipientName = supplier.name;
        }
      }
    }

    // Determine final categories: use categories if present, otherwise auto fallback based on recipient
    let finalCategories = editingExpense.categories || [];
    if (finalCategories.length === 0) {
      if (recipientType === 'employee') {
        finalCategories = ['مرتبات وموظفين'];
      } else if (recipientType === 'worker') {
        finalCategories = ['أجور وعمالة'];
      } else if (recipientType === 'supplier') {
        finalCategories = ['مواد بناء وكهرباء'];
      }
    }

    if (onUpdateExpense) {
      onUpdateExpense(editingExpense.id, {
        date: editingExpense.date,
        amount: editingExpense.amount,
        description: editingExpense.description,
        expenseType: editingExpense.expenseType || 'direct',
        categories: finalCategories,
        notes: editingExpense.notes,
        recipientType,
        recipientId,
        recipientName,
        currency: editingExpense.currency || 'YER',
        contractItemId: editingExpense.contractItemId,
        contractItemNumber: editingExpense.contractItemNumber,
        contractItemName: editingExpense.contractItemName,
        recordedDate: getTodayDateString()
      });
    }
    setEditingExpense(null);
  };

  // Filter states
  const [isFiltersOpen, setIsFiltersOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [startDateFilter, setStartDateFilter] = useState('');
  const [endDateFilter, setEndDateFilter] = useState('');
  const [expenseTypeFilter, setExpenseTypeFilter] = useState<string>('all');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [contractItemFilter, setContractItemFilter] = useState<string>('all');
  type ExpenseSortOption = 'date-desc' | 'date-asc' | 'desc-alpha' | 'recipient-alpha' | 'amount-desc';
  const [sortOrder, setSortOrder] = useState<ExpenseSortOption>('date-desc');

  // Excel Column Filter State
  const [columnFilters, setColumnFilters] = useState<Record<string, ActiveColumnFilter>>({});
  const [activeColumnSort, setActiveColumnSort] = useState<ColumnSortState | null>(null);

  const handleColumnFilterChange = (key: string, filter: ActiveColumnFilter | null) => {
    setColumnFilters(prev => {
      const next = { ...prev };
      if (!filter) {
        delete next[key];
      } else {
        next[key] = filter;
      }
      return next;
    });
  };

  const handleColumnSortChange = (sort: ColumnSortState | null) => {
    setActiveColumnSort(sort);
  };

  const handleClearAllColumnFilters = () => {
    setColumnFilters({});
    setActiveColumnSort(null);
  };

  // Column Configurations for Excel Filtering - memoized to prevent infinite re-render loops
  const columnConfigs: Record<string, ColumnFilterConfig<Expense>> = useMemo(() => ({
    date: {
      key: 'date',
      title: 'التاريخ',
      sortType: 'date',
      getValue: (e) => e.date,
      getDisplayValue: (val) => formatDateArabic(String(val))
    },
    recordedDate: {
      key: 'recordedDate',
      title: 'تاريخ الإضافة/التعديل',
      sortType: 'date',
      getValue: (e) => e.recordedDate || e.date,
      getDisplayValue: (val) => formatDateArabic(String(val))
    },
    description: {
      key: 'description',
      title: 'البيان',
      sortType: 'string',
      getValue: (e) => e.description
    },
    expenseType: {
      key: 'expenseType',
      title: 'نوع النفقة',
      sortType: 'string',
      getValue: (e) => getTypeName(e.expenseType),
      getDisplayValue: (val) => getTypeName(String(val))
    },
    categories: {
      key: 'categories',
      title: 'الفئة',
      sortType: 'string',
      getValue: (e) => getEffectiveExpenseCategories(e)
    },
    recipient: {
      key: 'recipient',
      title: 'الترحيل',
      sortType: 'string',
      getValue: (e) => {
        if (e.recipientType === 'worker') return `عامل: ${e.recipientName || ''}`;
        if (e.recipientType === 'employee') return `موظف: ${e.recipientName || ''}`;
        if (e.recipientType === 'supplier') return `مورد: ${e.recipientName || ''}`;
        return 'مصروف عام (غير مرحل)';
      }
    },
    amount: {
      key: 'amount',
      title: 'المبلغ',
      sortType: 'number',
      getValue: (e) => e.amount,
      getDisplayValue: (val) => formatCurrency(Number(val), currency)
    },
    notes: {
      key: 'notes',
      title: 'ملاحظات',
      sortType: 'string',
      getValue: (e) => e.notes || ''
    }
  }), [currency, getTypeName]);

  // Base filtered expenses matching top search & filter tools
  const baseFilteredExpenses = useMemo(() => {
    return expenses.filter(exp => {
      const effectiveCats = getEffectiveExpenseCategories(exp);
      const matchesSearch = 
        !searchTerm ||
        exp.description.toLowerCase().includes(searchTerm.toLowerCase()) || 
        exp.notes.toLowerCase().includes(searchTerm.toLowerCase()) ||
        exp.recipientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (exp.contractItemNumber && exp.contractItemNumber.toLowerCase().includes(searchTerm.toLowerCase())) ||
        (exp.contractItemName && exp.contractItemName.toLowerCase().includes(searchTerm.toLowerCase())) ||
        effectiveCats.some(c => c.toLowerCase().includes(searchTerm.toLowerCase()));

      const matchesStartDate = !startDateFilter || exp.date >= startDateFilter;
      const matchesEndDate = !endDateFilter || exp.date <= endDateFilter;
      const matchesExpenseType = expenseTypeFilter === 'all' || 
        exp.expenseType === expenseTypeFilter || 
        (expenseTypeFilter === 'direct' && (!exp.expenseType || exp.expenseType === 'direct')) ||
        (expenseTypeFilter === 'indirect' && exp.expenseType === 'indirect');
      const matchesCategory = categoryFilter === 'all' || 
        effectiveCats.includes(categoryFilter);
      const matchesContractItem = contractItemFilter === 'all' ||
        (contractItemFilter === 'unlinked' ? (!exp.contractItemId && !exp.contractItemNumber) : (exp.contractItemId === contractItemFilter || exp.contractItemNumber === contractItemFilter));

      return matchesSearch && matchesStartDate && matchesEndDate && matchesExpenseType && matchesCategory && matchesContractItem;
    });
  }, [expenses, searchTerm, startDateFilter, endDateFilter, expenseTypeFilter, categoryFilter, contractItemFilter]);

  // Filtered Expenses logic (cascading with column filters)
  const filteredExpenses = useMemo(() => {
    return baseFilteredExpenses.filter(exp => {
      // Apply Excel column filters
      for (const [colKey, filter] of Object.entries(columnFilters) as [string, ActiveColumnFilter][]) {
        const config = columnConfigs[colKey];
        if (!config || !filter || !filter.selectedValues) continue;

        const allowedSet = new Set(filter.selectedValues);
        const raw = config.getValue(exp);

        if (Array.isArray(raw)) {
          if (raw.length === 0) {
            if (!allowedSet.has('(فارغ)')) return false;
          } else {
            const hasAny = raw.some(val => {
              const strVal = val !== null && val !== undefined && String(val).trim() !== '' ? String(val) : '(فارغ)';
              return allowedSet.has(strVal);
            });
            if (!hasAny) return false;
          }
        } else {
          const strVal = raw !== null && raw !== undefined && String(raw).trim() !== '' ? String(raw) : '(فارغ)';
          if (!allowedSet.has(strVal)) return false;
        }
      }

      return true;
    });
  }, [baseFilteredExpenses, columnFilters, columnConfigs]);

  // Sorted Expenses logic (Active Column Sort overrides general sortOrder) - memoized
  const sortedExpenses = useMemo(() => {
    return [...filteredExpenses].sort((a, b) => {
      if (activeColumnSort) {
        const config = columnConfigs[activeColumnSort.key];
        if (config) {
          const rawA = config.getValue(a);
          const rawB = config.getValue(b);

          if (rawA === rawB) return 0;
          if (rawA === null || rawA === undefined || rawA === '') return 1;
          if (rawB === null || rawB === undefined || rawB === '') return -1;

          let comp = 0;
          if (config.sortType === 'number') {
            const numA = typeof rawA === 'number' ? rawA : parseFloat(String(rawA)) || 0;
            const numB = typeof rawB === 'number' ? rawB : parseFloat(String(rawB)) || 0;
            comp = numA - numB;
          } else if (config.sortType === 'date') {
            comp = String(rawA).localeCompare(String(rawB));
          } else {
            const strA = config.getDisplayValue ? config.getDisplayValue(String(rawA)) : String(rawA);
            const strB = config.getDisplayValue ? config.getDisplayValue(String(rawB)) : String(rawB);
            comp = strA.localeCompare(strB, 'ar');
          }

          return activeColumnSort.direction === 'asc' ? comp : -comp;
        }
      }

      if (sortOrder === 'date-asc') {
        return a.date.localeCompare(b.date);
      }
      if (sortOrder === 'desc-alpha') {
        return (a.description || '').localeCompare(b.description || '', 'ar');
      }
      if (sortOrder === 'recipient-alpha') {
        const getRecipientLabel = (item: typeof a) => {
          if (item.recipientType === 'worker') return `عامل: ${item.recipientName || ''}`;
          if (item.recipientType === 'employee') return `موظف: ${item.recipientName || ''}`;
          if (item.recipientType === 'supplier') return `مورد: ${item.recipientName || ''}`;
          return 'مصروف عام';
        };
        return getRecipientLabel(a).localeCompare(getRecipientLabel(b), 'ar');
      }
      if (sortOrder === 'amount-desc') {
        return b.amount - a.amount;
      }
      // Default: date-desc (من الأحدث للأقدم)
      return b.date.localeCompare(a.date);
    });
  }, [filteredExpenses, activeColumnSort, sortOrder, columnConfigs]);

  const hasActiveColumnFilters = Object.keys(columnFilters).length > 0 || activeColumnSort !== null;

  // Reset page to 1 when filters or sort changes
  useEffect(() => {
    setCurrentPage(1);
  }, [searchTerm, startDateFilter, endDateFilter, sortOrder, expenseTypeFilter, categoryFilter, columnFilters, activeColumnSort]);

  // Paginated expenses subset for the active page
  const totalPages = Math.max(1, Math.ceil(sortedExpenses.length / pageSize));
  const paginatedExpenses = useMemo(() => {
    if (pageSize >= sortedExpenses.length) return sortedExpenses;
    const startIndex = (currentPage - 1) * pageSize;
    return sortedExpenses.slice(startIndex, startIndex + pageSize);
  }, [sortedExpenses, currentPage, pageSize]);

  // Calculate sum of filtered grouped by currency - memoized
  const totalsByCurrency = useMemo(() => {
    return filteredExpenses.reduce((acc, curr) => {
      const code = curr.currency || 'YER';
      acc[code] = (acc[code] || 0) + curr.amount;
      return acc;
    }, {} as Record<string, number>);
  }, [filteredExpenses]);

  // Memoized handlers for edit & delete to prevent unnecessary row re-renders
  const handleEditClick = React.useCallback((exp: Expense) => {
    setEditingExpense(exp);
    setEditingPostTo(exp.recipientType !== 'none' ? `${exp.recipientType}:${exp.recipientId}` : '');
  }, []);

  const handleDeleteClick = React.useCallback((id: string) => {
    if (confirm('هل أنت متأكد من حذف هذه النفقة؟ سيتم إلغاء ترحيلها من حساب العامل/المورد تلقائياً إذا كانت مرحلة.')) {
      onDeleteExpense(id);
    }
  }, [onDeleteExpense]);

  // Excel File upload/import handler
  const handleExcelImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const data = event.target?.result;
        const workbook = XLSX.read(data, { type: 'binary' });
        const sheetName = workbook.SheetNames[0];
        const sheet = workbook.Sheets[sheetName];
        const rows = XLSX.utils.sheet_to_json<any>(sheet);

        let count = 0;
        rows.forEach((row: any) => {
          const dateVal = row['التاريخ'] || row['تاريخ'] || row['Date'] || row['date'];
          const desc = row['البيان'] || row['البيان اليومي'] || row['الوصف'] || row['Description'] || row['description'] || row['statement'];
          const amt = parseFloat(row['المبلغ'] || row['القيمة'] || row['Amount'] || row['amount']);
          const cur = row['العملة'] || row['currency'] || row['Currency'] || currency || 'YER';
          const noteVal = row['الملاحظات'] || row['ملاحظات'] || row['Notes'] || row['notes'] || '';
          const recipientVal = row['الترحيل'] || row['الاسم المرحل إليه'] || row['اسم الطرف الآخر'] || row['اسم العامل'] || row['اسم المورد'] || row['Recipient'] || row['recipient'];

          const categoryVal = row['الفئة'] || row['فئة'] || row['Category'] || row['category'];
          let importedCategories: string[] = [];
          if (categoryVal) {
            importedCategories = String(categoryVal).split(/[,;/\n]+/).map(s => s.trim()).filter(Boolean);
          }

          if (dateVal && desc && !isNaN(amt) && amt > 0) {
            const parseDate = (d: any) => {
              if (!d) return new Date().toISOString().split('T')[0];
              if (typeof d === 'number') {
                const dateObj = new Date((d - 25569) * 86400 * 1000);
                return dateObj.toISOString().split('T')[0];
              }
              const stringDate = String(d).trim();
              const parsed = Date.parse(stringDate);
              if (!isNaN(parsed)) {
                return new Date(parsed).toISOString().split('T')[0];
              }
              return stringDate;
            };

            const parsedDate = parseDate(dateVal);

            let recipientType: 'worker' | 'supplier' | 'none' = 'none';
            let recipientId = '';
            let recipientName = '';
            let extraNotes = String(noteVal).trim();

            if (recipientVal) {
              const cleanRecName = String(recipientVal).trim().toLowerCase();
              const matchedWorker = workers.find(w => w.name.trim().toLowerCase() === cleanRecName);
              if (matchedWorker) {
                recipientType = 'worker';
                recipientId = matchedWorker.id;
                recipientName = matchedWorker.name;
              } else {
                const matchedSupplier = suppliers.find(s => s.name.trim().toLowerCase() === cleanRecName);
                if (matchedSupplier) {
                  recipientType = 'supplier';
                  recipientId = matchedSupplier.id;
                  recipientName = matchedSupplier.name;
                } else {
                  const importedNameStr = `[مستلم مستورد: ${recipientVal}]`;
                  extraNotes = extraNotes ? `${extraNotes} | ${importedNameStr}` : importedNameStr;
                }
              }
            }

            onAddExpense({
              date: parsedDate,
              amount: amt,
              description: String(desc).trim(),
              categories: importedCategories,
              notes: extraNotes,
              recipientId,
              recipientType,
              recipientName,
              currency: String(cur).trim(),
              recordedDate: getTodayDateString()
            });
            count++;
          }
        });

        alert(`تم استيراد ${count} عملية صرف بنجاح من ملف Excel!`);
      } catch (err) {
        console.error("Error reading Excel expenses:", err);
        alert('حدث خطأ أثناء قراءة ملف Excel للنفقات. يرجى التأكد من أن الأعمدة مطابقة (التاريخ، البيان، المبلغ، العملة، ملاحظات، الترحيل).');
      }
    };
    reader.readAsBinaryString(file);
    e.target.value = '';
  };

  const handleExportExcel = () => {
    const headers = [
      'التاريخ',
      'البيان',
      'نوع النفقة',
      'الفئة',
      'الترحيل',
      'نوع الترحيل',
      'المبلغ',
      'العملة',
      'الملاحظات'
    ];

    const rows = sortedExpenses.map(exp => {
      let recipientTypeStr = 'مصروف عام';
      if (exp.recipientType === 'worker') {
        recipientTypeStr = 'عامل';
      } else if (exp.recipientType === 'supplier') {
        recipientTypeStr = 'مورد';
      } else if (exp.recipientType === 'employee') {
        recipientTypeStr = 'موظف';
      }

      const typeStr = (exp.expenseType || 'direct') === 'indirect' ? 'نفقات غير مباشرة' : 'نفقات مباشرة';
      const effectiveCats = getEffectiveExpenseCategories(exp);
      const categoryStr = effectiveCats.length ? effectiveCats.join(' - ') : '-';

      return [
        exp.date,
        exp.description,
        typeStr,
        categoryStr,
        exp.recipientName || '-',
        recipientTypeStr,
        exp.amount.toString(),
        exp.currency || 'YER',
        exp.notes || '-'
      ];
    });

    exportToCSV('سجل_النفقات_اليومية_المصفى', headers, rows);
  };

  const handlePrintAllExpensesPDF = () => {
    // 1. Group expenses by date and compute analytical metrics
    const dailyMap: Record<string, {
      date: string;
      directAmount: Record<string, number>;
      indirectAmount: Record<string, number>;
      totalAmount: Record<string, number>;
      count: number;
      items: Expense[];
    }> = {};

    const totalExpensesByCur: Record<string, number> = {};
    const directExpensesByCur: Record<string, number> = {};
    const indirectExpensesByCur: Record<string, number> = {};
    const categoriesMap: Record<string, { amount: Record<string, number>; count: number }> = {};
    const recipientDistribution: Record<string, { amount: Record<string, number>; count: number }> = {
      worker: { amount: {}, count: 0 },
      employee: { amount: {}, count: 0 },
      supplier: { amount: {}, count: 0 },
      none: { amount: {}, count: 0 }
    };

    sortedExpenses.forEach(exp => {
      const d = exp.date;
      const cur = exp.currency || currency || 'YER';
      const isIndirect = (exp.expenseType || 'direct') === 'indirect';

      // Totals
      totalExpensesByCur[cur] = (totalExpensesByCur[cur] || 0) + exp.amount;
      if (isIndirect) {
        indirectExpensesByCur[cur] = (indirectExpensesByCur[cur] || 0) + exp.amount;
      } else {
        directExpensesByCur[cur] = (directExpensesByCur[cur] || 0) + exp.amount;
      }

      // Categories
      const effectiveCats = getEffectiveExpenseCategories(exp);
      const catList = effectiveCats.length > 0 ? effectiveCats : ['مصاريف موقع عامة'];
      const splitAmount = exp.amount / catList.length;
      catList.forEach(c => {
        if (!categoriesMap[c]) {
          categoriesMap[c] = { amount: {}, count: 0 };
        }
        categoriesMap[c].amount[cur] = (categoriesMap[c].amount[cur] || 0) + splitAmount;
        categoriesMap[c].count += 1;
      });

      // Recipient
      const rType = exp.recipientType || 'none';
      if (!recipientDistribution[rType]) {
        recipientDistribution[rType] = { amount: {}, count: 0 };
      }
      recipientDistribution[rType].amount[cur] = (recipientDistribution[rType].amount[cur] || 0) + exp.amount;
      recipientDistribution[rType].count += 1;

      // Daily Map
      if (!dailyMap[d]) {
        dailyMap[d] = {
          date: d,
          directAmount: {},
          indirectAmount: {},
          totalAmount: {},
          count: 0,
          items: []
        };
      }

      const entry = dailyMap[d];
      entry.items.push(exp);
      entry.count += 1;

      if (isIndirect) {
        entry.indirectAmount[cur] = (entry.indirectAmount[cur] || 0) + exp.amount;
      } else {
        entry.directAmount[cur] = (entry.directAmount[cur] || 0) + exp.amount;
      }
      entry.totalAmount[cur] = (entry.totalAmount[cur] || 0) + exp.amount;
    });

    const sortedDays = Object.values(dailyMap).sort((a, b) => b.date.localeCompare(a.date));
    const primaryCurrency = currency || 'YER';
    const mainTotal = totalExpensesByCur[primaryCurrency] || 0;
    const mainDirect = directExpensesByCur[primaryCurrency] || 0;
    const mainIndirect = indirectExpensesByCur[primaryCurrency] || 0;
    const directPct = mainTotal > 0 ? Math.round((mainDirect / mainTotal) * 100) : 0;
    const indirectPct = 100 - directPct;

    // Categories color scheme
    const categoryColors: Record<string, string> = {
      'مرتبات وموظفين': '#4f46e5',
      'أجور وعمالة': '#0284c7',
      'مواد بناء وكهرباء': '#059669',
      'مواد غذائية': '#ea580c',
      'مواد استهلاكية': '#d97706',
      'اصول مضافة': '#7c3aed',
      'نقل وشحن': '#0891b2',
      'معدات وإيجارات': '#e11d48',
      'مصاريف موقع عامة': '#64748b'
    };

    // Sort categories by amount desc in primary currency
    const sortedCategories = Object.entries(categoriesMap).sort((a, b) => {
      const valA = a[1].amount[primaryCurrency] || 0;
      const valB = b[1].amount[primaryCurrency] || 0;
      return valB - valA;
    });

    // Top 4 spending days
    const topSpendingDays = [...sortedDays].sort((a, b) => {
      const valA = a.totalAmount[primaryCurrency] || 0;
      const valB = b.totalAmount[primaryCurrency] || 0;
      return valB - valA;
    }).slice(0, 4);

    const maxDayVal = topSpendingDays.length > 0 ? (topSpendingDays[0].totalAmount[primaryCurrency] || 1) : 1;

    // Multi-color category distribution bar segments
    const categoryBarSegmentsHtml = sortedCategories.map(([cat, data]) => {
      const catVal = data.amount[primaryCurrency] || 0;
      const pct = mainTotal > 0 ? ((catVal / mainTotal) * 100).toFixed(1) : '0';
      if (Number(pct) <= 0) return '';
      const color = categoryColors[cat] || '#64748b';
      return `<div style="width: ${pct}%; background-color: ${color}; height: 100%;" title="${cat}: ${pct}%"></div>`;
    }).join('');

    // Category Grid Cards
    const categoriesCardsHtml = sortedCategories.map(([cat, data]) => {
      const catVal = data.amount[primaryCurrency] || 0;
      const pct = mainTotal > 0 ? Math.round((catVal / mainTotal) * 100) : 0;
      const color = categoryColors[cat] || '#64748b';
      return `
        <div style="background-color: #ffffff; border: 1px solid #e2e8f0; border-radius: 6px; padding: 7px 10px; display: flex; flex-direction: column; justify-content: space-between;">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 4px;">
            <span style="font-size: 11px; font-weight: bold; color: #1e293b; display: flex; align-items: center; gap: 4px;">
              <span style="display: inline-block; width: 8px; height: 8px; border-radius: 50%; background-color: ${color};"></span>
              ${cat}
            </span>
            <span style="font-size: 10.5px; font-weight: 800; color: ${color};">${pct}%</span>
          </div>
          <div style="width: 100%; height: 5px; background-color: #f1f5f9; border-radius: 3px; overflow: hidden; margin-bottom: 4px;">
            <div style="width: ${pct}%; height: 100%; background-color: ${color};"></div>
          </div>
          <div style="display: flex; justify-content: space-between; font-size: 10px; color: #64748b;">
            <span style="font-weight: bold; font-family: monospace; color: #0f172a;">${formatCurrency(catVal, primaryCurrency)}</span>
            <span>${data.count} عملية</span>
          </div>
        </div>
      `;
    }).join('');

    // Parties distribution calculation
    const workerVal = recipientDistribution.worker?.amount[primaryCurrency] || 0;
    const employeeVal = recipientDistribution.employee?.amount[primaryCurrency] || 0;
    const supplierVal = recipientDistribution.supplier?.amount[primaryCurrency] || 0;
    const generalVal = recipientDistribution.none?.amount[primaryCurrency] || 0;

    const workerPct = mainTotal > 0 ? Math.round((workerVal / mainTotal) * 100) : 0;
    const employeePct = mainTotal > 0 ? Math.round((employeeVal / mainTotal) * 100) : 0;
    const supplierPct = mainTotal > 0 ? Math.round((supplierVal / mainTotal) * 100) : 0;
    const generalPct = mainTotal > 0 ? Math.round((generalVal / mainTotal) * 100) : 0;

    const categoryDonutData = sortedCategories.map(([cat, data]) => ({
      label: cat,
      value: data.amount[primaryCurrency] || 0,
      color: categoryColors[cat] || '#0284c7',
      formattedValue: formatCurrency(data.amount[primaryCurrency] || 0, primaryCurrency)
    })).filter(c => c.value > 0);

    const categoryDonutChartHtml = generateSvgDonutChart({
      data: categoryDonutData,
      size: 110,
      centerTitle: formatCurrency(mainTotal, primaryCurrency),
      centerSubtitle: 'إجمالي النفقات',
      showLegend: true
    });

    // PAGE 1: VISUAL ANALYTICS & CHARTS DASHBOARD (Balanced to fit in single page)
    const firstPageAnalyticsHtml = `
      <div class="first-page-dashboard chart-single-page" style="background-color: #f8fafc; border: 1px solid #cbd5e1; border-radius: 8px; padding: 10px 12px; margin-bottom: 14px; break-inside: avoid; page-break-inside: avoid;">
        <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #e2e8f0; padding-bottom: 6px; margin-bottom: 10px;">
          <h3 style="margin: 0; font-size: 12.5px; color: #0369a1; font-weight: 800;">📊 لوحة العرض والتحليل البياني للنفقات (Executive Expenses Analytics)</h3>
          <span style="font-size: 9.5px; background-color: #e0f2fe; color: #0369a1; padding: 2px 7px; border-radius: 10px; font-weight: bold;">العملة الأساسية: ${primaryCurrency}</span>
        </div>

        <!-- 1. KPI Cards Row -->
        <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 6px; margin-bottom: 10px;">
          <div style="background-color: #ffffff; border: 1px solid #e2e8f0; border-radius: 6px; padding: 6px 8px;">
            <div style="font-size: 9.5px; color: #64748b; font-weight: bold;">إجمالي المصاريف (${primaryCurrency})</div>
            <div style="font-size: 12px; font-weight: 800; color: #b91c1c; margin-top: 2px; font-family: monospace;">${formatCurrency(mainTotal, primaryCurrency)}</div>
          </div>
          <div style="background-color: #ffffff; border: 1px solid #e2e8f0; border-radius: 6px; padding: 6px 8px;">
            <div style="font-size: 9.5px; color: #64748b; font-weight: bold;">نفقات مباشرة (موقع/مواد)</div>
            <div style="font-size: 12px; font-weight: 800; color: #059669; margin-top: 2px; font-family: monospace;">${formatCurrency(mainDirect, primaryCurrency)} (${directPct}%)</div>
          </div>
          <div style="background-color: #ffffff; border: 1px solid #e2e8f0; border-radius: 6px; padding: 6px 8px;">
            <div style="font-size: 9.5px; color: #64748b; font-weight: bold;">نفقات غير مباشرة (إدارية)</div>
            <div style="font-size: 12px; font-weight: 800; color: #d97706; margin-top: 2px; font-family: monospace;">${formatCurrency(mainIndirect, primaryCurrency)} (${indirectPct}%)</div>
          </div>
          <div style="background-color: #ffffff; border: 1px solid #e2e8f0; border-radius: 6px; padding: 6px 8px;">
            <div style="font-size: 9.5px; color: #64748b; font-weight: bold;">حجم العمليات / الأيام</div>
            <div style="font-size: 12px; font-weight: 800; color: #0284c7; margin-top: 2px;">${filteredExpenses.length} عملية / ${sortedDays.length} يوم</div>
          </div>
        </div>

        <!-- 2. Direct vs Indirect Gauge & Stacked Bar -->
        <div style="background-color: #ffffff; border: 1px solid #e2e8f0; border-radius: 6px; padding: 8px 10px; margin-bottom: 10px;">
          <div style="display: flex; justify-content: space-between; align-items: center; font-size: 10.5px; font-weight: bold; margin-bottom: 4px;">
            <span style="color: #0f172a;">⚖️ هيكل نوع النفقة: نفقات مباشرة مقابل غير مباشرة</span>
            <span>
              <span style="color: #059669; margin-left: 10px;">🟢 مباشرة: ${directPct}%</span>
              <span style="color: #d97706;">🟠 غير مباشرة: ${indirectPct}%</span>
            </span>
          </div>
          <div style="width: 100%; height: 9px; background-color: #f1f5f9; border-radius: 5px; overflow: hidden; display: flex;">
            <div style="width: ${directPct}%; background-color: #059669; height: 100%;" title="نفقات مباشرة: ${directPct}%"></div>
            <div style="width: ${indirectPct}%; background-color: #d97706; height: 100%;" title="نفقات غير مباشرة: ${indirectPct}%"></div>
          </div>
        </div>

        <!-- 3. Category Breakdown Section (Visual SVG Donut Chart & Cards) -->
        <div style="background-color: #ffffff; border: 1px solid #e2e8f0; border-radius: 6px; padding: 8px 10px; margin-bottom: 10px;">
          <div style="display: flex; justify-content: space-between; align-items: center; font-size: 10.5px; font-weight: bold; margin-bottom: 6px;">
            <span style="color: #0f172a;">🍩 المخطط البياني لتوزيع المصاريف حسب الفئات والبنود (${primaryCurrency})</span>
            <span style="font-size: 9.5px; color: #64748b;">${sortedCategories.length} فئات نشطة</span>
          </div>
          
          <div style="margin-bottom: 8px;">
            ${categoryDonutChartHtml}
          </div>

          <!-- Category Cards Grid -->
          <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 6px;">
            ${categoriesCardsHtml}
          </div>
        </div>

        <!-- 4. Bottom Row: Parties Distribution + Top Spending Days -->
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px;">
          
          <!-- Parties Distribution -->
          <div style="background-color: #ffffff; border: 1px solid #e2e8f0; border-radius: 6px; padding: 8px 10px;">
            <div style="font-size: 10.5px; font-weight: bold; color: #0f172a; margin-bottom: 5px;">👥 توزيع الصرف حسب جهات الترحيل:</div>
            
            <div style="space-y: 4px; font-size: 9.5px;">
              <div style="margin-bottom: 4px;">
                <div style="display: flex; justify-content: space-between; color: #334155; margin-bottom: 2px;">
                  <span>👷 أجور وسلف العمال</span>
                  <span style="font-weight: bold; font-family: monospace;">${formatCurrency(workerVal, primaryCurrency)} (${workerPct}%)</span>
                </div>
                <div style="width: 100%; height: 4px; background: #f1f5f9; border-radius: 2px; overflow: hidden;">
                  <div style="width: ${workerPct}%; height: 100%; background: #0284c7;"></div>
                </div>
              </div>

              <div style="margin-bottom: 4px;">
                <div style="display: flex; justify-content: space-between; color: #334155; margin-bottom: 2px;">
                  <span>👔 رواتب وسلف الموظفين</span>
                  <span style="font-weight: bold; font-family: monospace;">${formatCurrency(employeeVal, primaryCurrency)} (${employeePct}%)</span>
                </div>
                <div style="width: 100%; height: 4px; background: #f1f5f9; border-radius: 2px; overflow: hidden;">
                  <div style="width: ${employeePct}%; height: 100%; background: #4f46e5;"></div>
                </div>
              </div>

              <div style="margin-bottom: 4px;">
                <div style="display: flex; justify-content: space-between; color: #334155; margin-bottom: 2px;">
                  <span>🚚 دفعات وتوريد الموردين</span>
                  <span style="font-weight: bold; font-family: monospace;">${formatCurrency(supplierVal, primaryCurrency)} (${supplierPct}%)</span>
                </div>
                <div style="width: 100%; height: 4px; background: #f1f5f9; border-radius: 2px; overflow: hidden;">
                  <div style="width: ${supplierPct}%; height: 100%; background: #d97706;"></div>
                </div>
              </div>

              <div>
                <div style="display: flex; justify-content: space-between; color: #334155; margin-bottom: 2px;">
                  <span>📦 مصاريف موقع عامة ونثريات</span>
                  <span style="font-weight: bold; font-family: monospace;">${formatCurrency(generalVal, primaryCurrency)} (${generalPct}%)</span>
                </div>
                <div style="width: 100%; height: 4px; background: #f1f5f9; border-radius: 2px; overflow: hidden;">
                  <div style="width: ${generalPct}%; height: 100%; background: #64748b;"></div>
                </div>
              </div>
            </div>
          </div>

          <!-- Top Spending Days Highlights -->
          <div style="background-color: #ffffff; border: 1px solid #e2e8f0; border-radius: 6px; padding: 8px 10px;">
            <div style="font-size: 10.5px; font-weight: bold; color: #0f172a; margin-bottom: 5px;">📈 أعلى أيام الصرف المالي في الفترة:</div>
            <div style="space-y: 4px; font-size: 9.5px;">
              ${topSpendingDays.length === 0 ? '<p style="color: #94a3b8; font-size: 9.5px; text-align: center;">لا توجد بيانات كافية</p>' : topSpendingDays.map(d => {
                const dayVal = d.totalAmount[primaryCurrency] || 0;
                const barPct = Math.round((dayVal / maxDayVal) * 100);
                return `
                  <div style="margin-bottom: 4px;">
                    <div style="display: flex; justify-content: space-between; color: #334155; margin-bottom: 2px;">
                      <span>📅 ${formatDateArabic(d.date)} (${d.count} عملية)</span>
                      <span style="font-weight: bold; font-family: monospace; color: #b91c1c;">${formatCurrency(dayVal, primaryCurrency)}</span>
                    </div>
                    <div style="width: 100%; height: 4px; background: #f1f5f9; border-radius: 2px; overflow: hidden;">
                      <div style="width: ${barPct}%; height: 100%; background: #ef4444;"></div>
                    </div>
                  </div>
                `;
              }).join('')}
            </div>
          </div>

        </div>

      </div>

      <!-- PAGE BREAK AFTER FIRST PAGE DASHBOARD -->
      <div style="page-break-before: always;"></div>
    `;

    // Summary table rows (Second section: Summary by Day)
    let dailySummaryRowsHtml = '';
    sortedDays.forEach(day => {
      const totalCurrencies = Object.keys(day.totalAmount);
      totalCurrencies.forEach(cur => {
        const directVal = day.directAmount[cur] || 0;
        const indirectVal = day.indirectAmount[cur] || 0;
        const totalVal = day.totalAmount[cur] || 0;

        dailySummaryRowsHtml += `
          <tr>
            <td style="font-weight: bold;">${formatDateArabic(day.date)}</td>
            <td style="text-align: center; font-weight: bold;">${day.count} عملية</td>
            <td style="color: #059669; font-weight: bold;">${formatCurrency(directVal, cur)}</td>
            <td style="color: #d97706; font-weight: bold;">${formatCurrency(indirectVal, cur)}</td>
            <td style="color: #b91c1c; font-weight: bold; font-size: 13px;">${formatCurrency(totalVal, cur)}</td>
            <td style="font-size: 11px; font-weight: bold;">${cur}</td>
          </tr>
        `;
      });
    });

    // Detailed separate tables for each day
    let dailyDetailedTablesHtml = '';
    sortedDays.forEach(day => {
      const dayTotalsStr = Object.entries(day.totalAmount)
        .map(([c, v]) => formatCurrency(v, c))
        .join(' | ');

      let dayItemsRows = '';
      day.items.forEach(exp => {
        let recipientStr = '- مصروف عام -';
        if (exp.recipientType === 'worker') {
          recipientStr = `${exp.recipientName} (عامل)`;
        } else if (exp.recipientType === 'supplier') {
          recipientStr = `${exp.recipientName} (مورد)`;
        } else if (exp.recipientType === 'employee') {
          recipientStr = `${exp.recipientName} (موظف)`;
        }

        const typeStr = (exp.expenseType || 'direct') === 'indirect' ? 'غير مباشرة' : 'مباشرة';
        const typeBadgeColor = (exp.expenseType || 'direct') === 'indirect' ? '#d97706' : '#059669';
        const typeBgColor = (exp.expenseType || 'direct') === 'indirect' ? '#fef3c7' : '#d1fae5';
        const effectiveCats = getEffectiveExpenseCategories(exp);
        const categoryStr = effectiveCats.length ? effectiveCats.join('، ') : '-';

        dayItemsRows += `
          <tr>
            <td style="font-weight: bold; width: 38%;" class="col-statement">${exp.description}</td>
            <td style="text-align: center; width: 12%;"><span style="background-color: ${typeBgColor}; color: ${typeBadgeColor}; font-weight: bold; font-size: 11px; padding: 2px 8px; border-radius: 4px;">${typeStr}</span></td>
            <td style="font-size: 11px; width: 12%;">${categoryStr}</td>
            <td style="width: 12%;">${recipientStr}</td>
            <td style="font-weight: bold; color: #b91c1c; width: 12%;">${formatCurrency(exp.amount, exp.currency || currency || 'YER')}</td>
            <td style="font-size: 9.5px; color: #64748b; line-height: 1.35; width: 14%;" class="col-notes">${exp.notes || '-'}</td>
          </tr>
        `;
      });

      dailyDetailedTablesHtml += `
        <div style="margin-top: 14px; margin-bottom: 16px; border: 1px solid #cbd5e1; border-radius: 8px; overflow: hidden; break-inside: auto;">
          <div style="background-color: #0f172a; color: #ffffff; padding: 8px 12px; display: flex; justify-content: space-between; align-items: center; break-after: avoid; page-break-after: avoid;">
            <span style="font-weight: bold; font-size: 12.5px;">📅 العمليات المالية ليوم: ${formatDateArabic(day.date)} (${day.count} عملية)</span>
            <span style="background-color: #2563eb; color: #ffffff; padding: 2px 8px; border-radius: 12px; font-weight: bold; font-size: 11px;">إجمالي اليوم: ${dayTotalsStr}</span>
          </div>
          <table class="report-data-table" style="margin: 0; width: 100%; border-collapse: collapse; font-size: 11.5px;">
            <thead>
              <tr style="background-color: #f1f5f9; color: #1e293b; break-inside: avoid; page-break-inside: avoid;">
                <th style="padding: 6px 8px; border: 1px solid #cbd5e1; width: 38%;" class="col-statement">البيان (المصروف)</th>
                <th style="padding: 6px 8px; border: 1px solid #cbd5e1; text-align: center; width: 12%;">نوع النفقة</th>
                <th style="padding: 6px 8px; border: 1px solid #cbd5e1; width: 12%;">الفئة</th>
                <th style="padding: 6px 8px; border: 1px solid #cbd5e1; width: 12%;">الترحيل لحساب</th>
                <th style="padding: 6px 8px; border: 1px solid #cbd5e1; width: 12%;">المبلغ</th>
                <th style="padding: 6px 8px; border: 1px solid #cbd5e1; width: 14%;" class="col-notes">ملاحظات</th>
              </tr>
            </thead>
            <tbody>
              ${dayItemsRows}
            </tbody>
          </table>
        </div>
      `;
    });

    const totalText = Object.entries(totalsByCurrency)
      .map(([cur, val]) => `<strong>${formatCurrency(Number(val), cur)}</strong>`)
      .join(' | ');

    const dateRangeStr = `الفترة المحددة: من ${startDateFilter ? formatDateArabic(startDateFilter) : 'بداية العمليات'} إلى ${endDateFilter ? formatDateArabic(endDateFilter) : 'اليوم الحاضر'}`;

    const bodyHtml = `
      <!-- PAGE 1: CHARTS & ANALYTICS DASHBOARD -->
      ${firstPageAnalyticsHtml}

      <!-- SECTION 2: DAILY SUMMARY TABLE -->
      <div style="margin-bottom: 25px;">
        <h3 class="report-section-title">
          أولاً: جدول ملخص إجمالي النفقات لكل يوم
        </h3>
        <table class="report-data-table">
          <thead>
            <tr>
              <th>التاريخ</th>
              <th style="text-align: center;">عدد العمليات</th>
              <th>نفقات مباشرة</th>
              <th>نفقات غير مباشرة</th>
              <th>إجمالي اليوم</th>
              <th>العملة</th>
            </tr>
          </thead>
          <tbody>
            ${filteredExpenses.length === 0 ? '<tr><td colspan="6" style="text-align: center; color: #94a3b8; padding: 12px;">لا توجد مصاريف مسجلة حالياً.</td></tr>' : dailySummaryRowsHtml}
          </tbody>
        </table>
      </div>

      <!-- SECTION 3: DETAILED SEPARATE TABLES FOR EACH DAY -->
      <div style="margin-bottom: 25px;">
        <h3 class="report-section-title" style="margin-top: 20px; break-after: avoid; page-break-after: avoid; break-before: auto;">
          ثانياً: جداول منفصلة لكافة العمليات المالية التفصيلية لكل يوم
        </h3>
        ${filteredExpenses.length === 0 ? '<p style="text-align: center; color: #94a3b8;">لا توجد بيانات تفصيلية.</p>' : dailyDetailedTablesHtml}
      </div>

      <!-- TOTAL SUMMARY FOOTER -->
      <div style="margin-top: 25px; padding: 15px; background-color: #fef2f2; border: 1px solid #fecaca; border-radius: 8px; text-align: center; page-break-inside: avoid;">
        <span style="font-size: 14px; font-weight: bold; color: #991b1b;">إجمالي النفقات والمصاريف الكلي: </span>
        <span style="font-size: 18px; font-weight: 800; color: #b91c1c; margin-right: 10px;">${totalText || '0'}</span>
      </div>
    `;

    const reportHtml = createOfficialReportHtml({
      title: 'كشف النفقات والمصاريف اليومية الشامل التفصيلي',
      subtitle: dateRangeStr,
      bodyHtml
    });

    printPDF('تقرير النفقات والمصاريف اليومية للموقع', reportHtml);
  };

  return (
    <div className="space-y-4 animate-fade-in" id="expenses-section">
      {/* Page Header */}
      <PageHeaderCard
        title="سجل المصاريف والنفقات اليومية"
        description="تسجيل المصاريف والمدفوعات اليومية للموقع والنثريات وترحيلها مباشرة لحسابات العمال والموردين."
        icon={<TrendingUp size={20} />}
        onBack={setActiveTab ? () => setActiveTab('dashboard') : undefined}
        optionsMenu={
          <OptionsMenu 
            onExportExcel={handleExportExcel}
            onExportPDF={handlePrintAllExpensesPDF}
            onImportExcel={sharedRole !== 'read' ? handleExcelImport : undefined}
            shareTitle="تقرير النفقات والمصاريف اليومية للموقع"
            shareText={() => {
              const totalText = Object.entries(totalsByCurrency)
                .map(([cur, val]) => `${formatCurrency(Number(val), cur)}`)
                .join(' | ');

              const lastEntries = sortedExpenses.slice(0, 15);
              const entriesText = lastEntries.length > 0
                ? '\n📋 تفاصيل أحدث المصاريف المقيدة:\n' + lastEntries.map(e => {
                    const recipientStr = e.recipientType !== 'none' ? ` [مرحل لـ: ${e.recipientName}]` : '';
                    return `- ${e.date} | ${e.description} ⟸ ${formatCurrency(e.amount, e.currency || currency)}${recipientStr}`;
                  }).join('\n')
                : '\n(لا توجد نفقات مطابقة)';

              return `💸 تقرير المصاريف والنفقات اليومية للموقع\n📅 تاريخ الاستخراج: ${new Date().toLocaleDateString('ar-EG-u-nu-latn')}\n\n📊 ملخص إجمالي المصاريف:\nإجمالي المجموع: ${totalText || '0'}\nعدد العمليات: ${filteredExpenses.length} عملية\n${entriesText}\n\n*تم استخراجه ومشاركته من كشوفات المقاولات*`;
            }}
          />
        }
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        
        {/* Expense Entry Form */}
        <AddExpenseCard
          onAddExpense={onAddExpense}
          onUpdateExpense={onUpdateExpense}
          expenses={expenses}
          workers={workers}
          suppliers={suppliers}
          employees={employees}
          contractItems={contractItems}
          currency={currency}
          sharedRole={sharedRole}
          onAddWorker={onAddWorker}
          onAddEmployee={onAddEmployee}
          onAddSupplier={onAddSupplier}
        />

        {/* Expenses List & Filters */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Filters card */}
          <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-100 shadow-xs transition-all" id="expenses-filters">
            <button
              type="button"
              onClick={() => setIsFiltersOpen(!isFiltersOpen)}
              className="w-full flex items-center justify-between text-right font-bold text-slate-700 text-sm hover:text-slate-900 cursor-pointer select-none"
            >
              <div className="flex items-center gap-2">
                <Filter size={16} className="text-slate-400" />
                <span>أدوات البحث والتصفية</span>
                {(searchTerm || startDateFilter || endDateFilter || sortOrder !== 'date-desc' || expenseTypeFilter !== 'all') && (
                  <span className="text-[10px] font-extrabold text-rose-600 bg-rose-50 px-2 py-0.5 rounded-full border border-rose-200">
                    فلتر نشط
                  </span>
                )}
              </div>
              <div className="flex items-center gap-1.5 text-slate-400 text-xs font-normal">
                <span className="text-slate-400 text-xs hidden sm:inline">{isFiltersOpen ? 'إخفاء' : 'عرض الخيارات'}</span>
                {isFiltersOpen ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
              </div>
            </button>
            
            {isFiltersOpen && (
              <div className="pt-3 space-y-4 border-t border-slate-100 mt-3">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  
                  {/* Search text */}
                  <div className="relative">
                    <input 
                      type="text"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      placeholder="بحث في البيان، الملاحظات..."
                      className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 text-xs pr-8 focus:outline-hidden focus:border-rose-500 transition-colors"
                    />
                    <Search size={14} className="absolute top-1/2 -translate-y-1/2 right-2.5 text-slate-400" />
                  </div>

                  {/* Start Date */}
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-slate-500 shrink-0">من:</span>
                    <input 
                      type="date"
                      value={startDateFilter}
                      onChange={(e) => setStartDateFilter(e.target.value)}
                      className="w-full h-9 px-2.5 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 text-xs focus:outline-hidden focus:border-rose-500"
                    />
                  </div>

                  {/* End Date */}
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-slate-500 shrink-0">إلى:</span>
                    <input 
                      type="date"
                      value={endDateFilter}
                      onChange={(e) => setEndDateFilter(e.target.value)}
                      className="w-full h-9 px-2.5 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 text-xs focus:outline-hidden focus:border-rose-500"
                    />
                  </div>

                  {/* Sort Order Filter */}
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-slate-500 shrink-0">الترتيب:</span>
                    <select
                      value={sortOrder}
                      onChange={(e) => setSortOrder(e.target.value as ExpenseSortOption)}
                      className="w-full h-9 px-2.5 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 text-xs font-bold focus:outline-hidden focus:border-rose-500 cursor-pointer"
                    >
                      <option value="date-desc">من الأحدث إلى الأقدم ⬇️ (افتراضي)</option>
                      <option value="date-asc">من الأقبل إلى الأحدث ⬆️</option>
                      <option value="desc-alpha">أبجدياً حسب البيان (أ - ي) 🔤</option>
                      <option value="recipient-alpha">أبجدياً حسب الترحيل والاسم 👤</option>
                      <option value="amount-desc">حسب المبلغ (الأعلى أولاً) 💰</option>
                    </select>
                  </div>

                  {/* Expense Type Filter */}
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-slate-500 shrink-0">نوع النفقة:</span>
                    <select
                      value={expenseTypeFilter}
                      onChange={(e) => setExpenseTypeFilter(e.target.value)}
                      className="w-full h-9 px-2.5 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 text-xs font-bold focus:outline-hidden focus:border-rose-500 cursor-pointer"
                    >
                      <option value="all">كافة أنواع النفقات</option>
                      {expenseTypes.map((t) => (
                        <option key={t.id} value={t.id}>{t.name}</option>
                      ))}
                    </select>
                  </div>

                  {/* Category Filter */}
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-slate-500 shrink-0">الفئة:</span>
                    <select
                      value={categoryFilter}
                      onChange={(e) => setCategoryFilter(e.target.value)}
                      className="w-full h-9 px-2.5 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 text-xs font-bold focus:outline-hidden focus:border-rose-500 cursor-pointer"
                    >
                      <option value="all">كافة الفئات</option>
                      {expenseCategories.map((cat) => (
                        <option key={cat} value={cat}>{cat}</option>
                      ))}
                    </select>
                  </div>

                  {/* Contract Item / BOQ Filter */}
                  {(contractItems && contractItems.length > 0) && (
                    <div className="flex items-center gap-2 sm:col-span-2">
                      <span className="text-xs text-slate-500 shrink-0">بند العقد:</span>
                      <select
                        value={contractItemFilter}
                        onChange={(e) => setContractItemFilter(e.target.value)}
                        className="w-full h-9 px-2.5 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 text-xs font-bold focus:outline-hidden focus:border-teal-500 cursor-pointer"
                      >
                        <option value="all">كافة بنود العقد والمصاريف العامة</option>
                        <option value="unlinked">المصاريف غير المرتبطة ببند عقد</option>
                        {contractItems.map((item) => (
                          <option key={item.id} value={item.id}>
                            {item.isMainItem ? `[بند ${item.itemNumber}] ${item.name}` : `[فقرة ${item.itemNumber}] ${item.name}`}
                          </option>
                        ))}
                      </select>
                    </div>
                  )}
                </div>

                {/* Clear filters shortcut */}
                {(searchTerm || startDateFilter || endDateFilter || sortOrder !== 'date-desc' || expenseTypeFilter !== 'all' || categoryFilter !== 'all' || contractItemFilter !== 'all') && (
                  <div className="flex justify-end">
                    <button 
                      onClick={() => {
                        setSearchTerm('');
                        setStartDateFilter('');
                        setEndDateFilter('');
                        setSortOrder('date-desc');
                        setExpenseTypeFilter('all');
                        setCategoryFilter('all');
                        setContractItemFilter('all');
                      }}
                      className="text-[11px] text-rose-600 hover:underline font-bold cursor-pointer"
                    >
                      إعادة تعيين الفلاتر
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Expenses Ledger Table */}
          <div className="bg-white rounded-2xl border border-slate-100 shadow-xs overflow-hidden" id="expenses-table-card">
            
            {/* Table Header / Totals */}
            <div className="p-5 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-slate-50/50">
              <div className="flex items-center gap-2 flex-wrap">
                <h4 className="font-bold text-slate-800 text-base">سجل النفقات اليومية</h4>
                <span className="text-xs bg-rose-100 text-rose-700 font-bold px-2 py-0.5 rounded-full">
                  {sortedExpenses.length} عمليات
                </span>
                {hasActiveColumnFilters && (
                  <div className="flex items-center gap-1.5 bg-rose-50 border border-rose-200 text-rose-800 px-2 py-0.5 rounded-lg text-xs font-bold">
                    <Filter size={12} className="fill-current text-rose-600" />
                    <span>تصفية مخصصة للأعمدة</span>
                    <button
                      type="button"
                      onClick={handleClearAllColumnFilters}
                      className="text-[10px] text-rose-600 hover:text-rose-800 hover:underline mr-1 cursor-pointer font-bold"
                    >
                      إلغاء فلاتر الأعمدة ✕
                    </button>
                  </div>
                )}
                <span className="text-[10px] text-slate-400 font-bold bg-slate-100 px-2 py-0.5 rounded-md">
                  {activeColumnSort ? `مرتبة حسب عمود: ${columnConfigs[activeColumnSort.key]?.title} (${activeColumnSort.direction === 'asc' ? 'تصاعدي' : 'تنازلي'})` :
                   sortOrder === 'date-desc' ? 'مرتبة من الأحدث للأقدم' :
                   sortOrder === 'date-asc' ? 'مرتبة من الأقدم للأحدث' :
                   sortOrder === 'desc-alpha' ? 'مرتبة أبجدياً حسب البيان' :
                   sortOrder === 'recipient-alpha' ? 'مرتبة أبجدياً حسب الترحيل' :
                   'مرتبة حسب المبلغ الأكبر'}
                </span>
              </div>
              <div className="text-slate-700 text-xs font-bold flex flex-wrap items-center gap-2 bg-white px-3 py-1.5 rounded-xl border border-slate-100">
                <span>المجموع المصفى:</span>
                {Object.keys(totalsByCurrency).length === 0 ? (
                  <span className="text-slate-400">0</span>
                ) : (
                  Object.entries(totalsByCurrency).map(([cur, val]) => (
                    <span key={cur} className="bg-rose-50 text-rose-700 px-2 py-0.5 rounded-lg border border-rose-100 text-xs font-extrabold font-mono">
                      {formatCurrency(Number(val), cur)}
                    </span>
                  ))
                )}
              </div>
            </div>

            {/* Desktop & Mobile Responsive view */}
            <div className="overflow-x-auto">
              {sortedExpenses.length === 0 ? (
                <div className="text-center py-12 px-4 space-y-2">
                  <p className="text-slate-400 text-sm font-medium">لا توجد مصاريف مطابقة لخيارات البحث</p>
                  <p className="text-xs text-slate-300">أدخل نفقات جديدة أو قم بتغيير فلاتر التصفية</p>
                </div>
              ) : (
                <table className="w-full text-right text-sm border-collapse">
                  <thead>
                    <tr className="bg-slate-50/70 border-b border-slate-100 text-slate-500 text-xs font-bold">
                      <th className="p-3.5 whitespace-nowrap">
                        <div className="flex items-center justify-between gap-1">
                          <span>التاريخ</span>
                          <ExcelColumnFilter
                            config={columnConfigs.date}
                            data={baseFilteredExpenses}
                            allColumnFilters={columnFilters}
                            allConfigs={columnConfigs}
                            activeFilter={columnFilters.date}
                            onFilterChange={handleColumnFilterChange}
                            activeSort={activeColumnSort}
                            onSortChange={handleColumnSortChange}
                            accentColor="rose"
                          />
                        </div>
                      </th>
                      <th className="p-3.5 min-w-[280px] sm:min-w-[380px]">
                        <div className="flex items-center justify-between gap-1">
                          <span>البيان</span>
                          <ExcelColumnFilter
                            config={columnConfigs.description}
                            data={baseFilteredExpenses}
                            allColumnFilters={columnFilters}
                            allConfigs={columnConfigs}
                            activeFilter={columnFilters.description}
                            onFilterChange={handleColumnFilterChange}
                            activeSort={activeColumnSort}
                            onSortChange={handleColumnSortChange}
                            accentColor="rose"
                          />
                        </div>
                      </th>
                      <th className="p-3.5 whitespace-nowrap">
                        <div className="flex items-center justify-between gap-1">
                          <span>نوع النفقة</span>
                          <ExcelColumnFilter
                            config={columnConfigs.expenseType}
                            data={baseFilteredExpenses}
                            allColumnFilters={columnFilters}
                            allConfigs={columnConfigs}
                            activeFilter={columnFilters.expenseType}
                            onFilterChange={handleColumnFilterChange}
                            activeSort={activeColumnSort}
                            onSortChange={handleColumnSortChange}
                            accentColor="rose"
                          />
                        </div>
                      </th>
                      <th className="p-3.5 whitespace-nowrap">
                        <div className="flex items-center justify-between gap-1">
                          <span>الفئة</span>
                          <ExcelColumnFilter
                            config={columnConfigs.categories}
                            data={baseFilteredExpenses}
                            allColumnFilters={columnFilters}
                            allConfigs={columnConfigs}
                            activeFilter={columnFilters.categories}
                            onFilterChange={handleColumnFilterChange}
                            activeSort={activeColumnSort}
                            onSortChange={handleColumnSortChange}
                            accentColor="rose"
                          />
                        </div>
                      </th>
                      <th className="p-3.5 whitespace-nowrap">
                        <div className="flex items-center justify-between gap-1">
                          <span>الترحيل</span>
                          <ExcelColumnFilter
                            config={columnConfigs.recipient}
                            data={baseFilteredExpenses}
                            allColumnFilters={columnFilters}
                            allConfigs={columnConfigs}
                            activeFilter={columnFilters.recipient}
                            onFilterChange={handleColumnFilterChange}
                            activeSort={activeColumnSort}
                            onSortChange={handleColumnSortChange}
                            accentColor="rose"
                          />
                        </div>
                      </th>
                      <th className="p-3.5 whitespace-nowrap">
                        <div className="flex items-center justify-between gap-1">
                          <span>المبلغ</span>
                          <ExcelColumnFilter
                            config={columnConfigs.amount}
                            data={baseFilteredExpenses}
                            allColumnFilters={columnFilters}
                            allConfigs={columnConfigs}
                            activeFilter={columnFilters.amount}
                            onFilterChange={handleColumnFilterChange}
                            activeSort={activeColumnSort}
                            onSortChange={handleColumnSortChange}
                            accentColor="rose"
                          />
                        </div>
                      </th>
                      <th className="p-3.5 max-w-[160px]">
                        <div className="flex items-center justify-between gap-1">
                          <span>ملاحظات</span>
                          <ExcelColumnFilter
                            config={columnConfigs.notes}
                            data={baseFilteredExpenses}
                            allColumnFilters={columnFilters}
                            allConfigs={columnConfigs}
                            activeFilter={columnFilters.notes}
                            onFilterChange={handleColumnFilterChange}
                            activeSort={activeColumnSort}
                            onSortChange={handleColumnSortChange}
                            accentColor="rose"
                          />
                        </div>
                      </th>
                      <th className="p-3.5 whitespace-nowrap">
                        <div className="flex items-center justify-between gap-1">
                          <span>تاريخ الإضافة/التعديل</span>
                          <ExcelColumnFilter
                            config={columnConfigs.recordedDate}
                            data={baseFilteredExpenses}
                            allColumnFilters={columnFilters}
                            allConfigs={columnConfigs}
                            activeFilter={columnFilters.recordedDate}
                            onFilterChange={handleColumnFilterChange}
                            activeSort={activeColumnSort}
                            onSortChange={handleColumnSortChange}
                            accentColor="rose"
                          />
                        </div>
                      </th>
                      <th className="p-3.5 text-center whitespace-nowrap">إجراءات</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {paginatedExpenses.map((exp) => (
                      <ExpenseRow
                        key={exp.id}
                        exp={exp}
                        currency={currency}
                        sharedRole={sharedRole}
                        onEdit={handleEditClick}
                        onDelete={handleDeleteClick}
                      />
                    ))}
                  </tbody>
                </table>
              )}
            </div>

            {/* Pagination Controls */}
            {sortedExpenses.length > 0 && (
              <div className="p-3.5 sm:p-4 border-t border-slate-100 bg-slate-50/40 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-600 font-medium select-none">
                <div className="flex items-center gap-3">
                  <span>
                    عرض{' '}
                    <strong className="text-slate-800 font-bold">
                      {Math.min(sortedExpenses.length, (currentPage - 1) * pageSize + 1)}
                    </strong>
                    {' '}-{' '}
                    <strong className="text-slate-800 font-bold">
                      {Math.min(sortedExpenses.length, currentPage * pageSize)}
                    </strong>
                    {' '}من أصل{' '}
                    <strong className="text-rose-700 font-bold">{sortedExpenses.length}</strong> عملية
                  </span>

                  <div className="flex items-center gap-1.5 mr-2">
                    <span className="text-slate-400">في الصفحة:</span>
                    <select
                      value={pageSize}
                      onChange={(e) => {
                        setPageSize(Number(e.target.value));
                        setCurrentPage(1);
                      }}
                      className="bg-white border border-slate-200 rounded-lg px-2 py-1 text-xs font-bold text-slate-700 focus:outline-hidden focus:border-rose-500 cursor-pointer"
                    >
                      <option value={25}>25</option>
                      <option value={50}>50</option>
                      <option value={100}>100</option>
                      <option value={250}>250</option>
                      <option value={1000}>الكل</option>
                    </select>
                  </div>
                </div>

                {totalPages > 1 && (
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      disabled={currentPage === 1}
                      onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                      className="px-2.5 py-1 rounded-lg border border-slate-200 bg-white text-slate-700 hover:bg-slate-100 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer transition-colors font-bold"
                    >
                      السابق
                    </button>
                    
                    <div className="flex items-center gap-1 px-2">
                      <span className="font-bold text-rose-700">{currentPage}</span>
                      <span className="text-slate-400">/</span>
                      <span className="text-slate-600">{totalPages}</span>
                    </div>

                    <button
                      type="button"
                      disabled={currentPage >= totalPages}
                      onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
                      className="px-2.5 py-1 rounded-lg border border-slate-200 bg-white text-slate-700 hover:bg-slate-100 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer transition-colors font-bold"
                    >
                      التالي
                    </button>
                  </div>
                )}
              </div>
            )}

          </div>

        </div>

      </div>

      {/* Edit Expense Modal */}
      {editingExpense && (
        <div 
          className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-2.5 sm:p-4 overflow-y-auto dir-rtl text-right overscroll-contain"
          onTouchMove={(e) => {
            if (e.target === e.currentTarget) e.preventDefault();
          }}
        >
          <div 
            className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-md w-full animate-scale-up my-auto max-h-[88vh] sm:max-h-[90vh] flex flex-col overflow-hidden overscroll-contain"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-4 border-b border-slate-100 flex items-center justify-between shrink-0 bg-white">
              <h3 className="font-bold text-slate-800 text-base sm:text-lg">تعديل النفقة اليومية</h3>
              <button 
                type="button"
                onClick={() => setEditingExpense(null)}
                className="p-1 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100 cursor-pointer"
              >
                ✕
              </button>
            </div>
            <form onSubmit={handleEditExpenseSubmit} className="flex flex-col flex-1 overflow-hidden min-h-0">
              <div className="p-4 overflow-y-auto space-y-4 flex-1 min-h-0 overscroll-contain touch-pan-y custom-scrollbar modal-scroll-area">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-600 block">التاريخ</label>
                  <input 
                    type="date" 
                    value={editingExpense.date}
                    onChange={(e) => setEditingExpense({ ...editingExpense, date: e.target.value })}
                    className="w-full h-[42px] px-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-sm focus:outline-hidden focus:border-rose-500"
                    required
                  />
                </div>
                <div className="grid grid-cols-3 gap-3">
                  <div className="col-span-2 space-y-1">
                    <label className="text-xs font-bold text-slate-600 block">المبلغ</label>
                    <div className="flex gap-1.5 items-center">
                      <input 
                        type="number" 
                        value={editingExpense.amount}
                        onChange={(e) => setEditingExpense({ ...editingExpense, amount: parseFloat(e.target.value) || 0 })}
                        className="w-full h-[42px] px-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-sm focus:outline-hidden focus:border-rose-500 font-mono text-left"
                        required
                        min="1"
                      />
                      <Calculator onApply={(val) => setEditingExpense({ ...editingExpense, amount: val })} />
                    </div>
                    <AmountInWords amount={editingExpense.amount} currency={editingExpense.currency || 'YER'} />
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-600 block">العملة</label>
                    <select 
                      value={editingExpense.currency || 'YER'}
                      onChange={(e) => setEditingExpense({ ...editingExpense, currency: e.target.value })}
                      className="w-full h-[42px] px-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-sm focus:outline-hidden focus:border-rose-500 cursor-pointer"
                    >
                      <option value="YER">﷼ يمني</option>
                      <option value="SAR">﷼ سعودي</option>
                      <option value="USD">$ دولار</option>
                    </select>
                  </div>
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-600 block">البيان</label>
                  <input 
                    type="text" 
                    value={editingExpense.description}
                    onChange={(e) => setEditingExpense({ ...editingExpense, description: e.target.value })}
                    className="w-full h-[42px] px-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-sm focus:outline-hidden focus:border-rose-500"
                    required
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-600 block">ترحيل إلى حساب</label>
                  <PostingAccountSelect 
                    value={editingPostTo}
                    onChange={(newPostTo) => {
                      setEditingPostTo(newPostTo);
                      if (newPostTo && newPostTo !== 'none') {
                        const [type] = newPostTo.split(':');
                        if (type === 'employee' && (!editingExpense.categories || editingExpense.categories.length === 0)) {
                          setEditingExpense(prev => prev ? { ...prev, categories: ['مرتبات وموظفين'] } : null);
                        } else if (type === 'worker' && (!editingExpense.categories || editingExpense.categories.length === 0)) {
                          setEditingExpense(prev => prev ? { ...prev, categories: ['أجور وعمالة'] } : null);
                        } else if (type === 'supplier' && (!editingExpense.categories || editingExpense.categories.length === 0)) {
                          setEditingExpense(prev => prev ? { ...prev, categories: ['مواد بناء وكهرباء'] } : null);
                        }
                      }
                    }}
                    workers={workers}
                    employees={employees}
                    suppliers={suppliers}
                    currency={currency}
                    sharedRole={sharedRole}
                    onAddWorker={onAddWorker}
                    onAddEmployee={onAddEmployee}
                    onAddSupplier={onAddSupplier}
                  />
                </div>

                {/* Expense Type Selector in Edit Modal */}
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5">
                      <label className="text-xs font-bold text-slate-600 block">نوع النفقة</label>
                      <span className="text-[10px] text-slate-400">(نفقات مباشرة / غير مباشرة)</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => setShowEditExpenseTypeModal(true)}
                      className="text-[11px] font-bold text-amber-800 hover:text-amber-900 flex items-center gap-1.5 bg-amber-50 hover:bg-amber-100/90 px-2.5 py-1 rounded-lg border border-amber-300/80 transition-all shadow-2xs hover:shadow-xs active:scale-95 cursor-pointer"
                      title="إدارة أنواع النفقات (إضافة - تعديل - حذف)"
                    >
                      <FolderCog size={13} className="text-amber-700 stroke-[2.2]" />
                      <span>إدارة الفئة</span>
                    </button>
                  </div>
                  <div className="grid grid-cols-2 gap-2 bg-slate-50 p-2 rounded-xl border border-slate-200">
                    {expenseTypes.map((t) => {
                      const isSelected = (editingExpense.expenseType || 'direct') === t.id || editingExpense.expenseType === t.name;
                      return (
                        <button
                          key={t.id}
                          type="button"
                          onClick={() => setEditingExpense({ ...editingExpense, expenseType: t.id })}
                          className={`flex items-center gap-2 p-2 rounded-lg transition-all cursor-pointer select-none text-xs font-bold ${
                            isSelected
                              ? 'bg-rose-50 border border-rose-200 text-rose-800'
                              : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100/50'
                          }`}
                        >
                          <div className={`w-4 h-4 rounded-xs border flex items-center justify-center transition-all shrink-0 ${
                            isSelected 
                              ? 'bg-rose-600 border-rose-600 text-white shadow-2xs' 
                              : 'border-slate-300 bg-white text-transparent hover:border-slate-400'
                          }`}>
                            <Check size={12} strokeWidth={3} className={isSelected ? 'opacity-100' : 'opacity-0'} />
                          </div>
                          <span className="truncate">{t.name}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Category ("الفئة") Multi-Select Section in Edit Modal */}
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5">
                      <label className="text-xs font-bold text-slate-600">الفئة</label>
                      <span className="text-[10px] text-slate-400">(يمكنك اختيار أكثر من خيار)</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => setShowEditExpenseCategoryModal(true)}
                      className="text-[11px] font-bold text-amber-800 hover:text-amber-900 flex items-center gap-1.5 bg-amber-50 hover:bg-amber-100/90 px-2.5 py-1 rounded-lg border border-amber-300/80 transition-all shadow-2xs hover:shadow-xs active:scale-95 cursor-pointer"
                      title="إدارة فئات النفقات (إضافة - تعديل - حذف)"
                    >
                      <FolderCog size={13} className="text-amber-700 stroke-[2.2]" />
                      <span>إدارة الفئة</span>
                    </button>
                  </div>
                  <div className="grid grid-cols-2 gap-2 bg-slate-50 p-2.5 rounded-xl border border-slate-200">
                    {expenseCategories.map((cat) => {
                      const isSelected = (editingExpense.categories || []).includes(cat);
                      return (
                        <button
                          key={cat}
                          type="button"
                          onClick={() => toggleEditingCategory(cat)}
                          className={`flex items-center gap-2 p-2 rounded-lg transition-all cursor-pointer select-none text-xs font-bold ${
                            isSelected
                              ? 'bg-rose-50 border border-rose-300 text-rose-800'
                              : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100/50'
                          }`}
                        >
                          <div className={`w-4 h-4 rounded-xs border flex items-center justify-center transition-all shrink-0 ${
                            isSelected 
                              ? 'bg-rose-600 border-rose-600 text-white shadow-2xs' 
                              : 'border-slate-300 bg-white text-transparent hover:border-slate-400'
                          }`}>
                            <Check size={12} strokeWidth={3} className={isSelected ? 'opacity-100' : 'opacity-0'} />
                          </div>
                          <span className="truncate">{cat}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Contract / BOQ Item Link */}
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-600 flex items-center justify-between">
                    <span className="flex items-center gap-1">
                      <FileSpreadsheet size={13} className="text-teal-600" />
                      بند العقد / جدول الكميات (اختياري)
                    </span>
                    {editingExpense.contractItemId && (
                      <button
                        type="button"
                        onClick={() => setEditingExpense({ 
                          ...editingExpense, 
                          contractItemId: undefined, 
                          contractItemNumber: undefined, 
                          contractItemName: undefined 
                        })}
                        className="text-[10px] text-rose-500 hover:underline font-bold cursor-pointer"
                      >
                        إلغاء الربط ✕
                      </button>
                    )}
                  </label>
                  <select
                    value={editingExpense.contractItemId || ''}
                    onChange={(e) => {
                      const id = e.target.value;
                      const matched = (contractItems || []).find(c => c.id === id);
                      setEditingExpense({
                        ...editingExpense,
                        contractItemId: id || undefined,
                        contractItemNumber: matched?.itemNumber || undefined,
                        contractItemName: matched?.name || undefined
                      });
                    }}
                    className="w-full h-9 px-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-xs font-semibold focus:outline-hidden focus:border-teal-500 cursor-pointer"
                  >
                    <option value="">-- غير مرتبط ببند عقد محدد (مصروف عام) --</option>
                    {(contractItems || []).map(item => (
                      <option key={item.id} value={item.id}>
                        {item.isMainItem ? `[بند رئيسي ${item.itemNumber}] ${item.name}` : `[فقرة ${item.itemNumber}] ${item.name}`}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-600 block">ملاحظات</label>
                  <textarea 
                    value={editingExpense.notes || ''}
                    onChange={(e) => setEditingExpense({ ...editingExpense, notes: e.target.value })}
                    rows={2}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-sm focus:outline-hidden focus:border-rose-500 resize-none"
                  />
                </div>
              </div>
              <div className="flex justify-end gap-2 p-3.5 bg-slate-50 border-t border-slate-100 shrink-0">
                <button 
                  type="button" 
                  onClick={() => setEditingExpense(null)}
                  className="bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold text-xs py-2 px-4 rounded-xl transition-colors cursor-pointer"
                >
                  إلغاء
                </button>
                <button 
                  type="submit" 
                  className="bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs py-2 px-4 rounded-xl shadow-xs transition-colors cursor-pointer"
                >
                  حفظ التعديلات
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Category Manager Modal for Expense Categories (from Edit Modal) */}
      <CategoryManagerModal
        isOpen={showEditExpenseCategoryModal}
        onClose={() => setShowEditExpenseCategoryModal(false)}
        title="إدارة فئات النفقات"
        subtitle="إضافة وتعديل وحذف فئات النفقات المتاحة في النظام وتحديث السجلات المرتبطة"
        categories={expenseCategories.map(cat => ({
          id: cat,
          name: cat,
          count: expenses.filter(e => {
            const cats = getEffectiveExpenseCategories(e);
            return cats.includes(cat);
          }).length
        }))}
        onAddCategory={(name) => addCategory(name)}
        onEditCategory={(item, newName) => {
          const res = editCategory(item.name, newName);
          if (res.success) {
            if (editingExpense && editingExpense.categories?.includes(item.name)) {
              setEditingExpense(prev => prev ? {
                ...prev,
                categories: prev.categories?.map(c => c === item.name ? newName : c)
              } : null);
            }
            if (onUpdateExpense) {
              expenses.forEach(exp => {
                const cats = exp.categories || (exp.category ? [exp.category] : []);
                if (cats.includes(item.name)) {
                  const updatedCats = cats.map(c => c === item.name ? newName : c);
                  const { id, createdBy, ...rest } = exp;
                  onUpdateExpense(id, { ...rest, categories: updatedCats, category: updatedCats[0] || '' });
                }
              });
            }
          }
          return res;
        }}
        onDeleteCategory={(item) => {
          const res = deleteCategory(item.name);
          if (res.success && editingExpense && editingExpense.categories?.includes(item.name)) {
            setEditingExpense(prev => prev ? {
              ...prev,
              categories: prev.categories?.filter(c => c !== item.name)
            } : null);
          }
          return res;
        }}
        onResetDefaults={resetExpenseCategories}
        entityUnitLabel="مصروف"
      />

      {/* Category Manager Modal for Expense Types (from Edit Modal) */}
      <CategoryManagerModal
        isOpen={showEditExpenseTypeModal}
        onClose={() => setShowEditExpenseTypeModal(false)}
        title="إدارة نوع النفقة"
        subtitle="إضافة وتعديل وحذف أنواع النفقات (نفقات مباشرة / غير مباشرة أو مخصصة)"
        categories={expenseTypes.map(t => ({
          id: t.id,
          name: t.name,
          isDefault: t.isDefault,
          count: expenses.filter(e => e.expenseType === t.id || e.expenseType === t.name).length
        }))}
        onAddCategory={(name) => addExpenseType(name)}
        onEditCategory={(item, newName) => {
          const res = editExpenseType(item.id, newName);
          if (res.success) {
            if (editingExpense && (editingExpense.expenseType === item.id || editingExpense.expenseType === item.name)) {
              setEditingExpense(prev => prev ? { ...prev, expenseType: item.id } : null);
            }
            if (onUpdateExpense) {
              expenses.forEach(exp => {
                if (exp.expenseType === item.id || exp.expenseType === item.name) {
                  const { id, createdBy, ...rest } = exp;
                  onUpdateExpense(id, { ...rest, expenseType: newName });
                }
              });
            }
          }
          return res;
        }}
        onDeleteCategory={(item) => {
          const res = deleteExpenseType(item.id);
          if (res.success && editingExpense && (editingExpense.expenseType === item.id || editingExpense.expenseType === item.name)) {
            setEditingExpense(prev => prev ? { ...prev, expenseType: 'direct' } : null);
          }
          return res;
        }}
        onResetDefaults={resetExpenseTypes}
        entityUnitLabel="مصروف"
      />

    </div>
  );
}
